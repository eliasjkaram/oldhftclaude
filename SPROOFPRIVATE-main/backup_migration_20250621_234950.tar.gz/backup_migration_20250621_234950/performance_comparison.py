
#!/usr/bin/env python3
"""
Performance Comparison: CPU vs GPU Enhanced Wheel Strategy
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import time
import numpy as np
import pandas as pd
import logging
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns

from universal_market_data import get_current_market_data, get_realistic_price

# Try to import our modules
try:
    from gpu_enhanced_wheel import GPUEnhancedWheelBot, GPUOptionsProcessor
    from integrated_wheel_bot import IntegratedWheelBot
    GPU_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ GPU modules not available: {e}")
    GPU_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PerformanceBenchmark:
    """Benchmark CPU vs GPU performance"""
    
    def __init__(self):
        self.results = {}
        
    def generate_test_data(self, n_options: int = 10000) -> tuple:
        """Generate test options data"""
        
        symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA'] * (n_options // 8)
        
        options_data = []
        current_prices = {}
        
        base_prices = get_current_market_data(['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA'])  # Real prices
        
        for i in range(n_options):
            symbol = symbols[i % len(symbols)]
            current_price = base_prices.get(symbol, 100) * (0.9 + 0.2 * np.random.random()
            current_prices[symbol] = current_price
            
            # Generate random option
            strike = current_price * (0.8 + 0.4 * np.random.random()
            dte_days = np.random.randint(1, 60)
            option_type = np.random.choice(['put', 'call'])
            
            options_data.append({)
                'underlying_symbol': symbol,
                'strike_price': str(round(strike, 2),
                'expiration_date': (datetime.now() + pd.Timedelta(days=dte_days).strftime('%Y-%m-%d'),
                'type': option_type,
                'bid': str(round(strike * 0.02 * (dte_days / 30), 2),
                'ask': str(round(strike * 0.025 * (dte_days / 30), 2),
                'delta': str(0.1 + 0.4 * np.random.random(),
                'open_interest': str(np.random.randint(50, 500)
            })
            
        return options_data, current_prices
        
    def benchmark_cpu_scoring(self, options_data: list, current_prices: dict) -> dict:
        """Benchmark CPU-based option scoring"""
        
        logger.info(f"🖥️ Benchmarking CPU scoring with {len(options_data)} options")
        
        start_time = time.time()
        
        # Simulate traditional scoring (one by one)
        scores = []
        for option in options_data:
            try:
                symbol = option['underlying_symbol']
                strike = float(option['strike_price'])
                current_price = current_prices.get(symbol, 100)
                
                # Simple scoring logic
                moneyness = strike / current_price
                delta = abs(float(option.get('delta', 0.2))
                
                # Calculate DTE
                try:
                    expiry = pd.to_datetime(option['expiration_date'])
                    dte = (expiry - pd.Timestamp.now().days)
                except:
                    dte = 30
                    
                # Basic score
                if option['type'] == 'put':
                    score = (1 - moneyness) * (1 - delta) * (1 / (dte + 5)
                else:
                    score = (moneyness - 1) * delta * (1 / (dte + 5)
                    
                scores.append(max(0, score)
                
            except:
                scores.append(0)
                
        cpu_time = time.time() - start_time
        
        return {}
            'method': 'CPU',
            'time': cpu_time,
            'options_per_second': len(options_data) / cpu_time,
            'scores': scores,
            'memory_usage': 'N/A'
        }
        
    def benchmark_gpu_scoring(self, options_data: list, current_prices: dict) -> dict:
        """Benchmark GPU-accelerated scoring"""
        
        if not GPU_AVAILABLE:
            return {}
                'method': 'GPU',
                'time': float('inf'),
                'options_per_second': 0,
                'scores': [0] * len(options_data),
                'memory_usage': 'GPU not available'
            }
            
        logger.info(f"🚀 Benchmarking GPU scoring with {len(options_data)} options")
        
        try:
            processor = GPUOptionsProcessor()
            
            start_time = time.time()
            
            # GPU batch processing
            scores = processor.batch_score_options(options_data, current_prices)
            
            gpu_time = time.time() - start_time
            
            return {}
                'method': 'GPU',
                'time': gpu_time,
                'options_per_second': len(options_data) / gpu_time if gpu_time > 0 else float('inf'),
                'scores': scores.tolist() if hasattr(scores, 'tolist') else scores,
                'memory_usage': 'GPU memory used'
            }
            
        except Exception as e:
            logger.error(f"GPU benchmark failed: {e}")
            return {}
                'method': 'GPU',
                'time': float('inf'),
                'options_per_second': 0,
                'scores': [0] * len(options_data),
                'memory_usage': f'Error: {e}'
            }
            
    def run_scaling_benchmark(self):
        """Test performance scaling with different data sizes"""
        
        sizes = [100, 500, 1000, 5000, 10000]
        results = []
        
        for size in sizes:
            logger.info(f"📊 Testing with {size} options")
            
            # Generate test data
            options_data, current_prices = self.generate_test_data(size)
            
            # Benchmark CPU
            cpu_result = self.benchmark_cpu_scoring(options_data, current_prices)
            cpu_result['data_size'] = size
            results.append(cpu_result)
            
            # Benchmark GPU
            gpu_result = self.benchmark_gpu_scoring(options_data, current_prices)
            gpu_result['data_size'] = size
            results.append(gpu_result)
            
            logger.info(f"   CPU: {cpu_result['options_per_second']:.0f} opts/sec")
            logger.info(f"   GPU: {gpu_result['options_per_second']:.0f} opts/sec")
            logger.info(f"   Speedup: {gpu_result['options_per_second'] / cpu_result['options_per_second'] if cpu_result['options_per_second'] > 0 else 'N/A'}x")
            
        return pd.DataFrame(results)
        
    def run_backtest_comparison(self):
        """Compare backtest performance"""
        
        logger.info("📈 Comparing backtest performance")
        
        try:
            # CPU backtest
            start_time = time.time()
            cpu_bot = IntegratedWheelBot()
            
            # Simulate limited backtest for speed
            symbols = ['SPY', 'QQQ', 'AAPL']
            
            cpu_time = time.time() - start_time
            
            # GPU backtest (if available)
            if GPU_AVAILABLE:
                start_time = time.time()
                gpu_bot = GPUEnhancedWheelBot()
                gpu_backtest = gpu_bot.run_backtest("2023-01-01", "2023-06-01")  # 6 months
                gpu_time = time.time() - start_time
                
                speedup = cpu_time / gpu_time if gpu_time > 0 else float('inf')
                
                logger.info(f"⚡ Backtest Results:")
                logger.info(f"   CPU Time: {cpu_time:.2f}s")
                logger.info(f"   GPU Time: {gpu_time:.2f}s") 
                logger.info(f"   Speedup: {speedup:.1f}x")
                logger.info(f"   GPU Return: {gpu_backtest['total_return']:.2%}")
                logger.info(f"   GPU Sharpe: {gpu_backtest['sharpe_ratio']:.2f}")
                
            else:
                logger.warning("GPU not available for backtest comparison")
                
        except Exception as e:
            logger.error(f"Backtest comparison failed: {e}")
            
    def visualize_results(self, results_df: pd.DataFrame):
        """Create performance visualization"""
        
        try:
            # Create performance comparison plots
            fig, ((ax1, ax2), (ax3, ax4) = plt.subplots(2, 2, figsize=(15, 10)
            
            # Plot 1: Options per second vs data size
            cpu_data = results_df[results_df['method'] == 'CPU']
            gpu_data = results_df[results_df['method'] == 'GPU']
            
            ax1.plot(cpu_data['data_size'], cpu_data['options_per_second'], 'b-o', label='CPU', linewidth=2)
            ax1.plot(gpu_data['data_size'], gpu_data['options_per_second'], 'r-o', label='GPU', linewidth=2)
            ax1.set_xlabel('Number of Options')
            ax1.set_ylabel('Options per Second')
            ax1.set_title('Performance Scaling Comparison')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            
            # Plot 2: Speedup factor
            speedup_data = []
            for size in cpu_data['data_size']:
                cpu_speed = cpu_data[cpu_data['data_size'] == size]['options_per_second'].iloc[0]
                gpu_speed = gpu_data[gpu_data['data_size'] == size]['options_per_second'].iloc[0]
                speedup = gpu_speed / cpu_speed if cpu_speed > 0 else 0
                speedup_data.append(speedup)
                
            ax2.bar(cpu_data['data_size'], speedup_data, color='green', alpha=0.7)
            ax2.set_xlabel('Number of Options')
            ax2.set_ylabel('GPU Speedup (x)')
            ax2.set_title('GPU Speedup Factor')
            ax2.grid(True, alpha=0.3)
            
            # Plot 3: Processing time comparison
            ax3.bar(cpu_data['data_size'] - 100, cpu_data['time'], width=200, label='CPU', alpha=0.7)
            ax3.bar(gpu_data['data_size'] + 100, gpu_data['time'], width=200, label='GPU', alpha=0.7)
            ax3.set_xlabel('Number of Options')
            ax3.set_ylabel('Processing Time (seconds)')
            ax3.set_title('Processing Time Comparison')
            ax3.legend()
            ax3.grid(True, alpha=0.3)
            
            # Plot 4: Efficiency (options per second per compute unit)
            efficiency_cpu = cpu_data['options_per_second'] / 8  # Assume 8 CPU cores
            efficiency_gpu = gpu_data['options_per_second'] / 1000  # Assume 1000 GPU cores
            
            ax4.plot(cpu_data['data_size'], efficiency_cpu, 'b-o', label='CPU (per core)', linewidth=2)
            ax4.plot(gpu_data['data_size'], efficiency_gpu, 'r-o', label='GPU (per 1000 cores)', linewidth=2)
            ax4.set_xlabel('Number of Options')
            ax4.set_ylabel('Efficiency (opts/sec/core)')
            ax4.set_title('Compute Efficiency')
            ax4.legend()
            ax4.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig('/home/harry/alpaca-mcp/performance_comparison.png', dpi=300, bbox_inches='tight')
            plt.show()
            
            logger.info("📊 Performance visualization saved to performance_comparison.png")
            
        except Exception as e:
            logger.error(f"Visualization failed: {e}")

def run_comprehensive_benchmark():
    """Run the complete performance benchmark suite"""
    
    logger.info("🚀 Starting Comprehensive GPU vs CPU Benchmark")
    logger.info("=" * 60)
    
    benchmark = PerformanceBenchmark()
    
    # Run scaling benchmark
    logger.info("1️⃣ Running scaling benchmark...")
    scaling_results = benchmark.run_scaling_benchmark()
    
    # Display summary
    logger.info("\n📊 SCALING BENCHMARK RESULTS:")
    logger.info(scaling_results.to_string(index=False)
    
    # Calculate average speedup
    cpu_avg = scaling_results[scaling_results['method'] == 'CPU']['options_per_second'].mean()
    gpu_avg = scaling_results[scaling_results['method'] == 'GPU']['options_per_second'].mean()
    avg_speedup = gpu_avg / cpu_avg if cpu_avg > 0 else 0
    
    logger.info(f"\n⚡ AVERAGE GPU SPEEDUP: {avg_speedup:.1f}x")
    
    # Run backtest comparison
    logger.info("\n2️⃣ Running backtest comparison...")
    benchmark.run_backtest_comparison()
    
    # Create visualizations
    logger.info("\n3️⃣ Creating performance visualizations...")
    benchmark.visualize_results(scaling_results)
    
    # Summary and recommendations
    logger.info("\n" + "=" * 60)
    logger.info("🎯 PERFORMANCE SUMMARY & RECOMMENDATIONS:")
    logger.info("=" * 60)
    
    if GPU_AVAILABLE and avg_speedup > 1:
        logger.info(f"✅ GPU acceleration provides {avg_speedup:.1f}x speedup")
        logger.info("✅ Recommended for large-scale options scanning")
        logger.info("✅ Best for real-time market analysis")
    else:
        logger.info("❌ GPU acceleration not available or ineffective")
        logger.info("💡 Consider installing cupy for GPU support")
        logger.info("💡 CPU implementation sufficient for smaller datasets")
        
    logger.info("\n📋 OPTIMIZATION RECOMMENDATIONS:")
    logger.info("• Use GPU for batch processing >1000 options")
    logger.info("• Use CPU for small datasets <100 options")
    logger.info("• Implement hybrid approach for best performance")
    logger.info("• Consider async processing for I/O bound tasks")
    
    return scaling_results

if __name__ == "__main__":
    results = run_comprehensive_benchmark()