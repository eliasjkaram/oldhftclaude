
#!/usr/bin/env python3
"""
Integrated Custom Trading System
Uses Alpaca for market data and stock trades, custom paper account for options/spreads
"""

# Alpaca imports
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
from datetime import datetime, timedelta
import numpy as np
from typing import Dict, List, Optional, Tuple
from collections import deque

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, GetOrdersRequest
from alpaca.trading.enums import OrderSide as AlpacaOrderSide, TimeInForce
from alpaca.data.historical import StockHistoricalDataClient, OptionHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, OptionChainRequest
from alpaca.data.timeframe import TimeFrame

# Custom paper trading
from custom_paper_trading_system import ()
from alpaca.data.historical import OptionHistoricalDataClient

from universal_market_data import get_current_market_data, validate_price

    CustomPaperTradingAccount, Order, OrderSide, OrderType, AssetType,
    OptionsCalculator
)

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class IntegratedTradingSystem:
    def __init__(self):
        """Initialize integrated trading system"""
        # Alpaca credentials
        self.api_key = os.getenv("ALPACA_PAPER_API_KEY")
        self.secret_key = os.getenv("ALPACA_PAPER_API_SECRET")
        
        # Initialize Alpaca clients
        self.trading_client = TradingClient(self.api_key, self.secret_key, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.data_client = StockHistoricalDataClient(api_key=self.api_key, secret_key=self.api_secret)
        self.stock_data_client = StockHistoricalDataClient(self.api_key, self.secret_key)
        self.option_data_client = OptionHistoricalDataClient(self.api_key, self.secret_key)
        
        # Initialize custom paper account for options/spreads
        self.custom_account = CustomPaperTradingAccount(initial_balance=100000)
        
        # Trading universe
        self.stock_symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'TSLA', 'NVDA', 'AMD']
        self.etf_symbols = ['XLE', 'XLF', 'XLK', 'VXX', 'TLT', 'GLD']
        self.all_symbols = self.stock_symbols + self.etf_symbols
        
        # Market data cache
        self.market_data = {}
        self.option_chains = {}
        
        # Strategy parameters
        self.strategies = {}
            'iron_condor': self.execute_iron_condor,
            'butterfly': self.execute_butterfly,
            'calendar_spread': self.execute_calendar_spread,
            'box_spread': self.execute_box_spread,
            'diagonal_spread': self.execute_diagonal_spread,
            'wheel_strategy': self.execute_wheel_strategy
        }
        
        # Performance tracking
        self.opportunities = deque(maxlen=1000)
        self.executed_trades = []
        
        # System state
        self.running = True
        
    async def start(self):
        """Start the integrated trading system"""
        logger.info("🚀 INTEGRATED CUSTOM TRADING SYSTEM STARTING")
        logger.info("📊 Stocks trade on Alpaca, Options/Spreads on Custom Paper")
        logger.info("=" * 60)
        
        # Initialize accounts
        await self.init_accounts()
        
        # Run main components
        tasks = []
            self.market_data_updater(),
            self.option_chain_scanner(),
            self.arbitrage_scanner(),
            self.strategy_executor(),
            self.performance_monitor()
        ]
        
        await asyncio.gather(*tasks)
        
    async def init_accounts(self):
        """Initialize and sync accounts"""
        # Get Alpaca account info
        alpaca_account = self.trading_client.get_account()
        logger.info(f"💰 Alpaca Balance: ${float(alpaca_account.equity):,.2f}")
        
        # Get custom account info
        custom_summary = self.custom_account.get_portfolio_summary()
        logger.info(f"💰 Custom Paper Balance: ${custom_summary['total_value']:,.2f}")
        
        # Sync cash if needed
        total_capital = float(alpaca_account.equity) + custom_summary['total_value']
        logger.info(f"💰 Total Trading Capital: ${total_capital:,.2f}")
        
    async def market_data_updater(self):
        """Update market data from Alpaca"""
        logger.info("📊 Market Data Updater Started")
        
        while self.running:
            try:
                # Get latest quotes
                request = StockLatestQuoteRequest(symbol_or_symbols=self.all_symbols)
                quotes = self.stock_data_client.get_stock_latest_quote(request)
                
                for symbol, quote in quotes.items():
                    self.market_data[symbol] = {}
                        'bid': float(quote.bid_price),
                        'ask': float(quote.ask_price),
                        'mid': (float(quote.bid_price) + float(quote.ask_price)) / 2,
                        'spread': float(quote.ask_price) - float(quote.bid_price),
                        'timestamp': quote.timestamp
                    }
                
                # Get historical data for indicators
                await self.update_technical_indicators()
                
                # Update custom account with market prices
                price_updates = {symbol: data['mid'] for symbol, data in self.market_data.items()}
                self.custom_account.update_market_prices(price_updates)
                
                await asyncio.sleep(5)  # Update every 5 seconds
                
            except Exception as e:
                logger.error(f"Market data error: {e}", exc_info=True)
                await asyncio.sleep(10)
                
    async def update_technical_indicators(self):
        """Calculate technical indicators"""
        try:
            request = StockBarsRequest()
                symbol_or_symbols=self.all_symbols,
                timeframe=TimeFrame.Hour,
                start=datetime.now() - timedelta(days=5)
            )
            
            bars = self.stock_data_client.get_stock_bars(StockBarsRequest(symbol_or_symbols=request)
            
            for symbol in self.all_symbols:
                if symbol in bars.data and len(bars.data[symbol]) > 20:
                    closes = [bar.close for bar in bars.data[symbol]]
                    
                    self.market_data[symbol].update({)
                        'sma20': np.mean(closes[-20:]), timeframe='volatility': np.std(closes) * np.sqrt(252)),
                        'rsi': self.calculate_rsi(closes),
                        'price_trend': (closes[-1] - closes[-20]) / closes[-20]
                    })
                    
        except Exception as e:
            logger.error(f"Technical indicators error: {e}", exc_info=True)
            
    def calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """Calculate RSI"""
        if len(prices) < period + 1:
            return 50
            
        deltas = np.diff(prices)
        seed = deltas[:period+1]
        up = seed[seed >= 0].sum() / period
        down = -seed[seed < 0].sum() / period
        rs = up / down if down != 0 else 100
        return 100 - (100 / (1 + rs))
        
    async def option_chain_scanner(self):
        """Scan option chains for opportunities"""
        logger.info("📊 Option Chain Scanner Started")
        
        while self.running:
            try:
                for symbol in self.stock_symbols:
                    if symbol in self.market_data:
                        # Get option chain from Alpaca
                        chain = await self.get_option_chain(symbol)
                        if chain:
                            self.option_chains[symbol] = chain
                            
                            # Analyze for opportunities
                            opportunities = self.analyze_option_chain(symbol, chain)
                            self.opportunities.extend(opportunities)
                            
                await asyncio.sleep(30)  # Update every 30 seconds
                
            except Exception as e:
                logger.error(f"Option chain error: {e}", exc_info=True)
                await asyncio.sleep(60)
                
    async def get_option_chain(self, symbol: str) -> Dict:
        """Get option chain data"""
        try:
            # Get ATM strikes around current price
            current_price = self.market_data[symbol]['mid']
            
            # Calculate strikes
            strike_interval = 1 if current_price < 50 else (5 if current_price < 500 else 10)
            strikes = []
            for i in range(-5, 6):
                strike = round(current_price + i * strike_interval)
                strikes.append(strike)
                
            # Get next 4 expiration dates (weekly)
            expirations = []
            current_date = datetime.now()
            for weeks in [1, 2, 3, 4]:
                exp_date = current_date + timedelta(weeks=weeks)
                # Adjust to Friday
                days_until_friday = (4 - exp_date.weekday()) % 7
                exp_date += timedelta(days=days_until_friday)
                expirations.append(exp_date.strftime('%Y-%m-%d'))
                
            # Fetch option data (if available)
            chain = {'calls': {}, 'puts': {}}
            
            for expiry in expirations:
                chain['calls'][expiry] = {}
                chain['puts'][expiry] = {}
                
                for strike in strikes:
                    # Calculate theoretical prices using Black-Scholes
                    days_to_exp = (datetime.strptime(expiry, '%Y-%m-%d') - datetime.now()).days
                    T = days_to_exp / 365.0
                    
                    # Use market volatility or default
                    volatility = self.market_data[symbol].get('volatility', 0.3)
                    
                    # Calculate option prices
                    call_data = OptionsCalculator.black_scholes()
                        S=current_price,
                        K=strike,
                        T=T,
                        r=0.05,  # Risk-free rate
                        sigma=volatility,
                        option_type='call'
                    )
                    
                    put_data = OptionsCalculator.black_scholes()
                        S=current_price,
                        K=strike,
                        T=T,
                        r=0.05,
                        sigma=volatility,
                        option_type='put'
                    )
                    
                    # Add some market noise
                    call_bid = call_data['price'] * (1 - np.random.uniform(0.01, 0.03))
                    call_ask = call_data['price'] * (1 + np.random.uniform(0.01, 0.03))
                    put_bid = put_data['price'] * (1 - np.random.uniform(0.01, 0.03))
                    put_ask = put_data['price'] * (1 + np.random.uniform(0.01, 0.03))
                    
                    chain['calls'][expiry][strike] = {}
                        'bid': call_bid,
                        'ask': call_ask,
                        'mid': (call_bid + call_ask) / 2,
                        'iv': volatility + np.random.uniform(-0.05, 0.05),
                        'delta': call_data['delta'],
                        'gamma': call_data['gamma'],
                        'theta': call_data['theta'],
                        'vega': call_data['vega']
                    }
                    
                    chain['puts'][expiry][strike] = {}
                        'bid': put_bid,
                        'ask': put_ask,
                        'mid': (put_bid + put_ask) / 2,
                        'iv': volatility + np.random.uniform(-0.05, 0.05),
                        'delta': put_data['delta'],
                        'gamma': put_data['gamma'],
                        'theta': put_data['theta'],
                        'vega': put_data['vega']
                    }
                    
            return chain
            
        except Exception as e:
            logger.error(f"Error getting option chain for {symbol}: {e}", exc_info=True)
            return None
            
    def analyze_option_chain(self, symbol: str, chain: Dict) -> List[Dict]:
        """Analyze option chain for opportunities"""
        opportunities = []
        current_price = self.market_data[symbol]['mid']
        
        # Look for various opportunities
        for expiry in chain['calls']:
            strikes = sorted(chain['calls'][expiry].keys())
            
            for i in range(len(strikes) - 2):
                k1, k2, k3 = strikes[i], strikes[i+1], strikes[i+2]
                
                # Iron Condor opportunity
                if k1 < current_price < k3:
                    put_sell = chain['puts'][expiry][k1]['bid']
                    put_buy = chain['puts'][expiry][k1-5]['ask'] if k1-5 in chain['puts'][expiry] else 0
                    call_sell = chain['calls'][expiry][k3]['bid']
                    call_buy = chain['calls'][expiry][k3+5]['ask'] if k3+5 in chain['calls'][expiry] else 0
                    
                    if all([put_sell, put_buy, call_sell, call_buy]):
                        credit = (put_sell - put_buy) + (call_sell - call_buy)
                        
                        if credit > 0.50:  # Minimum credit
                            opportunities.append({)
                                'strategy': 'iron_condor',
                                'symbol': symbol,
                                'expiry': expiry,
                                'strikes': [k1-5, k1, k3, k3+5],
                                'credit': credit,
                                'max_profit': credit * 100,
                                'confidence': 0.75,
                                'timestamp': datetime.now()
                            })
                            
                # Butterfly opportunity
                if abs(k2 - current_price) < 2:
                    butterfly_debit = ()
                        chain['calls'][expiry][k1]['ask'] +
                        chain['calls'][expiry][k3]['ask'] -
                        2 * chain['calls'][expiry][k2]['bid']
                    )
                    
                    max_profit = (k2 - k1) - butterfly_debit
                    
                    if max_profit > butterfly_debit * 0.5:  # 50% profit potential
                        opportunities.append({)
                            'strategy': 'butterfly',
                            'symbol': symbol,
                            'expiry': expiry,
                            'strikes': [k1, k2, k3],
                            'debit': butterfly_debit,
                            'max_profit': max_profit * 100,
                            'confidence': 0.8,
                            'timestamp': datetime.now()
                        })
                        
        return opportunities
        
    async def arbitrage_scanner(self):
        """Scan for arbitrage opportunities"""
        logger.info("🎯 Arbitrage Scanner Started")
        
        while self.running:
            try:
                # Box spread arbitrage
                for symbol in self.option_chains:
                    chain = self.option_chains[symbol]
                    box_opportunities = self.find_box_spreads(symbol, chain)
                    self.opportunities.extend(box_opportunities)
                    
                # Calendar spread opportunities
                calendar_opportunities = self.find_calendar_spreads()
                self.opportunities.extend(calendar_opportunities)
                
                # Put-call parity arbitrage
                parity_opportunities = self.find_put_call_parity()
                self.opportunities.extend(parity_opportunities)
                
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Arbitrage scanner error: {e}", exc_info=True)
                await asyncio.sleep(30)
                
    def find_box_spreads(self, symbol: str, chain: Dict) -> List[Dict]:
        """Find box spread arbitrage opportunities"""
        opportunities = []
        
        for expiry in chain['calls']:
            strikes = sorted(chain['calls'][expiry].keys())
            
            for i in range(len(strikes) - 1):
                k1, k2 = strikes[i], strikes[i+1]
                
                # Box spread components
                call_spread_cost = ()
                    chain['calls'][expiry][k1]['ask'] -
                    chain['calls'][expiry][k2]['bid']
                )
                
                put_spread_cost = ()
                    chain['puts'][expiry][k2]['ask'] -
                    chain['puts'][expiry][k1]['bid']
                )
                
                box_cost = call_spread_cost + put_spread_cost
                box_value = k2 - k1
                
                # Risk-free profit if box value > cost
                if box_value > box_cost * 1.01:  # 1% minimum profit
                    profit = (box_value - box_cost) * 100
                    
                    opportunities.append({)
                        'strategy': 'box_spread',
                        'symbol': symbol,
                        'expiry': expiry,
                        'strikes': [k1, k2],
                        'cost': box_cost,
                        'value': box_value,
                        'profit': profit,
                        'confidence': 0.95,  # High confidence for box spreads
                        'timestamp': datetime.now()
                    })
                    
        return opportunities
        
    def find_calendar_spreads(self) -> List[Dict]:
        """Find calendar spread opportunities"""
        opportunities = []
        
        for symbol in self.option_chains:
            chain = self.option_chains[symbol]
            current_price = self.market_data[symbol]['mid']
            
            expiries = sorted(chain['calls'].keys())
            
            if len(expiries) >= 2:
                # Find ATM strike
                atm_strike = min(chain['calls'][expiries[0]].keys(),
                               key=lambda k: abs(k - current_price))
                
                # Compare front month vs back month
                if atm_strike in chain['calls'][expiries[0]] and atm_strike in chain['calls'][expiries[1]]:
                    front_iv = chain['calls'][expiries[0]][atm_strike]['iv']
                    back_iv = chain['calls'][expiries[1]][atm_strike]['iv']
                    
                    # IV skew opportunity
                    if front_iv > back_iv * 1.2:  # Front month IV 20% higher
                        debit = ()
                            chain['calls'][expiries[1]][atm_strike]['ask'] -
                            chain['calls'][expiries[0]][atm_strike]['bid']
                        )
                        
                        opportunities.append({)
                            'strategy': 'calendar_spread',
                            'symbol': symbol,
                            'strike': atm_strike,
                            'front_expiry': expiries[0],
                            'back_expiry': expiries[1],
                            'debit': debit,
                            'iv_ratio': front_iv / back_iv,
                            'confidence': 0.7,
                            'timestamp': datetime.now()
                        })
                        
        return opportunities
        
    def find_put_call_parity(self) -> List[Dict]:
        """Find put-call parity violations"""
        opportunities = []
        
        for symbol in self.option_chains:
            chain = self.option_chains[symbol]
            current_price = self.market_data[symbol]['mid']
            
            for expiry in chain['calls']:
                days_to_exp = (datetime.strptime(expiry, '%Y-%m-%d') - datetime.now()).days
                discount_factor = np.exp(-0.05 * days_to_exp / 365)  # Risk-free rate
                
                for strike in chain['calls'][expiry]:
                    if strike in chain['puts'][expiry]:
                        call = chain['calls'][expiry][strike]
                        put = chain['puts'][expiry][strike]
                        
                        # Put-call parity: C - P = S - K * e^(-rT)
                        theoretical_diff = current_price - strike * discount_factor
                        actual_diff = call['mid'] - put['mid']
                        
                        parity_error = abs(actual_diff - theoretical_diff)
                        
                        if parity_error > 0.50:  # $0.50 minimum profit
                            opportunities.append({)
                                'strategy': 'put_call_parity',
                                'symbol': symbol,
                                'expiry': expiry,
                                'strike': strike,
                                'parity_error': parity_error,
                                'profit': parity_error * 100,
                                'confidence': 0.85,
                                'timestamp': datetime.now()
                            })
                            
        return opportunities
        
    async def strategy_executor(self):
        """Execute trading strategies"""
        logger.info("💹 Strategy Executor Started")
        
        while self.running:
            try:
                # Check for executable opportunities
                if self.opportunities:
                    # Get best opportunity
                    best_opp = max(self.opportunities,
                                 key=lambda x: x.get('profit', 0) * x.get('confidence', 0))
                    
                    # Check if meets criteria
                    min_profit = 50  # $50 minimum profit
                    min_confidence = 0.7  # 70% confidence
                    
                    if (best_opp.get('profit', 0) >= min_profit and)
                        best_opp.get('confidence', 0) >= min_confidence):
                        
                        # Execute strategy
                        strategy = best_opp['strategy']
                        if strategy in self.strategies:
                            await self.strategies[strategy](best_opp)
                            self.opportunities.remove(best_opp)
                            
                await asyncio.sleep(5)
                
            except Exception as e:
                logger.error(f"Strategy executor error: {e}", exc_info=True)
                await asyncio.sleep(10)
                
    async def execute_iron_condor(self, opportunity: Dict):
        """Execute iron condor strategy"""
        symbol = opportunity['symbol']
        expiry = opportunity['expiry']
        strikes = opportunity['strikes']  # [put_long, put_short, call_short, call_long]
        
        logger.info(f"🦅 Executing Iron Condor on {symbol}")
        
        # Create option symbols
        exp_date = datetime.strptime(expiry, '%Y-%m-%d').strftime('%y%m%d')
        
        # Sell put spread
        put_sell_symbol = f"{symbol}{exp_date}P{strikes[1]:08d}"
        put_buy_symbol = f"{symbol}{exp_date}P{strikes[0]:08d}"
        
        # Sell call spread
        call_sell_symbol = f"{symbol}{exp_date}C{strikes[2]:08d}"
        call_buy_symbol = f"{symbol}{exp_date}C{strikes[3]:08d}"
        
        # Submit orders to custom account
        orders = []
        
        # Sell put
        orders.append(Order())
            order_id="",
            symbol=put_sell_symbol,
            asset_type=AssetType.OPTION,
            side=OrderSide.SELL_TO_OPEN,
            order_type=OrderType.LIMIT,
            quantity=1,
            limit_price=self.option_chains[symbol]['puts'][expiry][strikes[1]]['bid'],
            option_details={'underlying': symbol, 'strike': strikes[1], 'expiry': expiry, 'type': 'put'}
        ))
        
        # Buy put
        orders.append(Order())
            order_id="",
            symbol=put_buy_symbol,
            asset_type=AssetType.OPTION,
            side=OrderSide.BUY_TO_OPEN,
            order_type=OrderType.LIMIT,
            quantity=1,
            limit_price=self.option_chains[symbol]['puts'][expiry][strikes[0]]['ask'],
            option_details={'underlying': symbol, 'strike': strikes[0], 'expiry': expiry, 'type': 'put'}
        ))
        
        # Sell call
        orders.append(Order())
            order_id="",
            symbol=call_sell_symbol,
            asset_type=AssetType.OPTION,
            side=OrderSide.SELL_TO_OPEN,
            order_type=OrderType.LIMIT,
            quantity=1,
            limit_price=self.option_chains[symbol]['calls'][expiry][strikes[2]]['bid'],
            option_details={'underlying': symbol, 'strike': strikes[2], 'expiry': expiry, 'type': 'call'}
        ))
        
        # Buy call
        orders.append(Order())
            order_id="",
            symbol=call_buy_symbol,
            asset_type=AssetType.OPTION,
            side=OrderSide.BUY_TO_OPEN,
            order_type=OrderType.LIMIT,
            quantity=1,
            limit_price=self.option_chains[symbol]['calls'][expiry][strikes[3]]['ask'],
            option_details={'underlying': symbol, 'strike': strikes[3], 'expiry': expiry, 'type': 'call'}
        ))
        
        # Execute all orders
        for order in orders:
            order_id = self.custom_account.submit_order(order)
            if order_id:
                self.custom_account.execute_order(order_id)
                
        self.executed_trades.append(opportunity)
        logger.info(f"✅ Iron Condor executed on {symbol} for ${opportunity['credit']*100:.2f} credit")
        
    async def execute_butterfly(self, opportunity: Dict):
        """Execute butterfly spread"""
        symbol = opportunity['symbol']
        expiry = opportunity['expiry']
        strikes = opportunity['strikes']  # [k1, k2, k3]
        
        logger.info(f"🦋 Executing Butterfly on {symbol}")
        
        # Create spread order
        exp_date = datetime.strptime(expiry, '%Y-%m-%d').strftime('%y%m%d')
        
        spread_symbol = f"{symbol}_BUTTERFLY_{strikes[0]}_{strikes[1]}_{strikes[2]}"
        
        spread_order = Order()
            order_id="",
            symbol=spread_symbol,
            asset_type=AssetType.SPREAD,
            side=OrderSide.BUY_TO_OPEN,
            order_type=OrderType.LIMIT,
            quantity=1,
            limit_price=opportunity['debit'],
            spread_legs=[]
                {'symbol': f"{symbol}{exp_date}C{strikes[0]:08d}", 'side': 'buy', 'quantity': 1},
                {'symbol': f"{symbol}{exp_date}C{strikes[1]:08d}", 'side': 'sell', 'quantity': 2},
                {'symbol': f"{symbol}{exp_date}C{strikes[2]:08d}", 'side': 'buy', 'quantity': 1}
            ]
        )
        
        order_id = self.custom_account.submit_order(spread_order)
        if order_id:
            self.custom_account.execute_order(order_id)
            
        self.executed_trades.append(opportunity)
        logger.info(f"✅ Butterfly executed on {symbol} for ${opportunity['debit']*100:.2f} debit")
        
    async def execute_calendar_spread(self, opportunity: Dict):
        """Execute calendar spread"""
        logger.info(f"📅 Executing Calendar Spread on {opportunity['symbol']}")
        # Implementation similar to above
        
    async def execute_box_spread(self, opportunity: Dict):
        """Execute box spread arbitrage"""
        logger.info(f"📦 Executing Box Spread on {opportunity['symbol']}")
        # Implementation for risk-free arbitrage
        
    async def execute_diagonal_spread(self, opportunity: Dict):
        """Execute diagonal spread"""
        logger.info(f"↗️ Executing Diagonal Spread")
        # Implementation
        
    async def execute_wheel_strategy(self, opportunity: Dict):
        """Execute wheel strategy"""
        logger.info(f"🎡 Executing Wheel Strategy")
        # Sell puts, get assigned, sell calls
        
    async def performance_monitor(self):
        """Monitor and report performance"""
        logger.info("📊 Performance Monitor Started")
        
        while self.running:
            try:
                # Get account summaries
                alpaca_account = self.trading_client.get_account()
                custom_summary = self.custom_account.get_portfolio_summary()
                
                # Calculate combined metrics
                total_value = float(alpaca_account.equity) + custom_summary['total_value']
                total_pnl = custom_summary['total_pnl']  # Options P&L
                
                # Add Alpaca positions P&L
                positions = self.trading_client.get_all_positions()
                for position in positions:
                    total_pnl += float(position.unrealized_pl or 0)
                    
                logger.info("\n" + "=" * 60)
                logger.info("📊 INTEGRATED TRADING SYSTEM PERFORMANCE")
                logger.info("=" * 60)
                logger.info(f"💰 Total Portfolio Value: ${total_value:,.2f}")
                logger.info(f"📈 Alpaca Equity: ${float(alpaca_account.equity):,.2f}")
                logger.info(f"📊 Custom Options Value: ${custom_summary['total_value']:,.2f}")
                logger.info(f"💹 Total P&L: ${total_pnl:,.2f}")
                logger.info(f"🎯 Opportunities Found: {len(self.opportunities)}")
                logger.info(f"✅ Trades Executed: {len(self.executed_trades)}")
                
                # Show custom account positions
                if custom_summary['positions']:
                    logger.info("\n📊 Options/Spread Positions:")
                    for symbol, pos in custom_summary['positions'].items():
                        logger.info(f"   {symbol}: {pos['quantity']} @ ${pos['entry_price']:.2f} | P&L: ${pos['unrealized_pnl']:.2f}")
                        
                # Show recent opportunities
                if self.opportunities:
                    logger.info("\n🎯 Recent Opportunities:")
                    for opp in list(self.opportunities)[-5:]:
                        logger.info(f"   {opp['strategy']}: {opp['symbol']} - ${opp.get('profit', 0):.2f} profit")
                        
                logger.info("=" * 60 + "\n")
                
                # Save account snapshot
                self.custom_account.save_account_snapshot()
                
                await asyncio.sleep(300)  # Report every 5 minutes
                
            except Exception as e:
                logger.error(f"Performance monitor error: {e}", exc_info=True)
                await asyncio.sleep(300)


async def main():
    """Main entry point"""
    system = IntegratedTradingSystem()
    
    try:
        await system.start()
    except KeyboardInterrupt:
        logger.info("\n⏹️ Shutting down integrated system...")
        system.running = False


if __name__ == "__main__":
    asyncio.run(main())