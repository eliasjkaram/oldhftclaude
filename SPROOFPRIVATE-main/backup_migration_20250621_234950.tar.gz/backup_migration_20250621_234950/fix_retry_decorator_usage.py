#!/usr/bin/env python3
"""
Fix @retry decorator usage with ErrorCategory parameters
Replace with @handle_errors which supports those parameters
"""

import os
import re

def fix_retry_decorators(filepath):
    """Fix @retry decorators that use ErrorCategory parameters"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return False
    
    original_content = content
    
    # Pattern to match @retry with ErrorCategory parameters
    # e.g., @retry("name", ErrorCategory.XXX, ErrorSeverity.YYY)
    pattern = r'@retry\s*\(\s*([^)]+ErrorCategory[^)]+)\s*\)'
    
    # Replace with @handle_errors
    content = re.sub(pattern, r'@handle_errors(\1)', content)
    
    # Write back if changed
    if content != original_content:
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Fixed: {filepath}")
            return True
        except Exception as e:
            print(f"Error writing {filepath}: {e}")
            return False
    
    return False

def main():
    """Main function to fix all files"""
    files_to_fix = []
        'term_structure_analysis.py',
        'integrated_backtesting.py',
        'trade_reconciliation_system.py',
        'pinn_black_scholes.py',
        'pnl_tracking_system.py',
        'volatility_surface_modeling.py',
        'drift_detection_monitoring.py',
        'greeks_calculator.py',
        'multi_leg_strategy_analyzer.py',
        'continual_learning_pipeline.py',
        'live_trading_integration.py',
        'low_latency_inference_endpoint.py',
        'market_microstructure_features.py',
        'model_performance_evaluation.py',
        'model_serving_infrastructure.py',
        'options_data_pipeline.py',
        'order_management_system.py',
        'reinforcement_learning_agent.py',
        'transformer_options_model.py',
        'unified_configuration.py'
    ]
    
    fixed_count = 0
    for filename in files_to_fix:
        filepath = f'/home/harry/alpaca-mcp/{filename}'
        if os.path.exists(filepath):
            if fix_retry_decorators(filepath):
                fixed_count += 1
        else:
            print(f"File not found: {filepath}")
    
    print(f"\nTotal files fixed: {fixed_count}")

if __name__ == "__main__":
    main()