#!/usr/bin/env python3
"""
Final Security Audit Script V2
Verifies that all credentials have been properly migrated
"""

import os
import re
import json
from pathlib import Path
from datetime import datetime
import subprocess

class FinalSecurityAuditV2:
    def __init__(self):
        self.root_dir = Path('/home/harry/alpaca-mcp')
        self.report = {}
            'audit_time': datetime.now().isoformat(),
            'issues_found': [],
            'files_scanned': 0,
            'secure_files': 0,
            'vulnerable_files': 0,
            'recommendations': []
        }
        
        # Known sensitive patterns - look for hardcoded values only
        self.sensitive_patterns = []
            # Alpaca specific keys
            ("<ALPACA_PAPER_KEY>", "Hardcoded Alpaca Paper API Key"),
            ("<ALPACA_PAPER_SECRET>", "Hardcoded Alpaca Paper Secret"),
            ("<ALPACA_LIVE_KEY>", "Hardcoded Alpaca Live API Key"),
            ("<ALPACA_LIVE_SECRET>", "Hardcoded Alpaca Live Secret"),
            
            # MinIO credentials
            ("<MINIO_ACCESS_KEY>", "Hardcoded MinIO Access Key"),
            ("<MINIO_SECRET_KEY>", "Hardcoded MinIO Secret"),
            ("<MINIO_ROOT_USER>", "Hardcoded MinIO Root User"),
            ("<MINIO_ROOT_PASSWORD>", "Hardcoded MinIO Root Password"),
            
            # OpenRouter
            ("<OPENROUTER_KEY>", "Hardcoded OpenRouter Key"),
        ]
        
        # Regex patterns for generic credentials
        self.regex_patterns = []
            (r'api_key\s*=\s*["\'][A-Za-z0-9]{10,}["\']', "Potential API Key"),
            (r'secret_key\s*=\s*["\'][A-Za-z0-9!@#$%^&*()]{10,}["\']', "Potential Secret Key"),
            (r'password\s*=\s*["\'][^"\']+["\']', "Potential Password"),
        ]
    
    def scan_file(self, filepath: Path) -> list:
        """Scan a single file for security issues"""
        issues = []
        
        # Skip certain files and directories
        skip_patterns = []
            '__pycache__', '.git', 'venv', '.env', 'node_modules',
            'backup', '.pyc', '.pyo', '.so', '.dll', '.exe',
            'security_audit', 'credential_migration_report'
        ]
        
        if any(pattern in str(filepath) for pattern in skip_patterns):
            return issues
            
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.splitlines()
            
            for line_num, line in enumerate(lines, 1):
                # Skip if it's using os.getenv (properly secured)
                if 'os.getenv' in line:
                    continue
                
                # Check for hardcoded values
                for value, description in self.sensitive_patterns:
                    if value in line:
                        # Additional check - skip if it's in a comment or docstring
                        stripped_line = line.strip()
                        if not (stripped_line.startswith('#') or)
                               stripped_line.startswith('"""') or 
                               stripped_line.startswith("'''")):
                            issues.append({)
                                'file': str(filepath),
                                'line': line_num,
                                'type': description,
                                'preview': line.strip()[:100]
                            })
                
                # Check regex patterns
                for pattern, description in self.regex_patterns:
                    match = re.search(pattern, line)
                    if match:
                        # Skip common false positives
                        if 'example' in line.lower() or 'test' in line.lower():
                            continue
                        issues.append({)
                            'file': str(filepath),
                            'line': line_num,
                            'type': description,
                            'preview': line.strip()[:100]
                        })
                        
        except Exception as e:
            pass
            
        return issues
    
    def scan_directory(self):
        """Scan entire directory structure"""
        print("🔍 Starting comprehensive security audit...")
        
        for ext in ['*.py', '*.json', '*.yaml', '*.yml', '*.conf', '*.ini']:
            for filepath in self.root_dir.rglob(ext):
                self.report['files_scanned'] += 1
                issues = self.scan_file(filepath)
                
                if issues:
                    self.report['vulnerable_files'] += 1
                    self.report['issues_found'].extend(issues)
                else:
                    self.report['secure_files'] += 1
    
    def check_environment_setup(self):
        """Check if environment is properly configured"""
        env_checks = {}
            '.env': "Environment file exists",
            '.env.example': "Environment template exists", 
            '.gitignore': "Gitignore configured"
        }
        
        env_status = {}
        for file, description in env_checks.items():
            path = self.root_dir / file
            env_status[file] = {}
                'exists': path.exists(),
                'description': description
            }
            
            # Check .gitignore content
            if file == '.gitignore' and path.exists():
                with open(path, 'r') as f:
                    content = f.read()
                    env_status[file]['has_env_rules'] = '.env' in content
                    env_status[file]['has_backup_rules'] = '*.backup' in content
                    env_status[file]['has_json_rules'] = 'alpaca_config.json' in content
                    
        self.report['environment_setup'] = env_status
    
    def generate_recommendations(self):
        """Generate security recommendations"""
        if not self.report['issues_found']:
            self.report['recommendations'].append("✅ No hardcoded credentials found in the codebase!")
        else:
            self.report['recommendations'].append(f"⚠️  Found {len(self.report['issues_found'])} potential security issues")
            self.report['recommendations'].append("🔧 Review and fix the identified issues immediately")
        
        # Environment recommendations
        env_setup = self.report.get('environment_setup', {})
        if env_setup.get('.env', {}).get('exists'):
            self.report['recommendations'].append("✅ .env file exists - ensure it contains your actual credentials")
        else:
            self.report['recommendations'].append("📝 Create .env file: cp .env.example .env")
            
        if not env_setup.get('.gitignore', {}).get('has_json_rules'):
            self.report['recommendations'].append("🚫 Add alpaca_config.json to .gitignore")
            
        # Additional security recommendations
        self.report['recommendations'].append("🔐 Remember to:")
        self.report['recommendations'].append("   - Never commit .env files to version control")
        self.report['recommendations'].append("   - Rotate API keys regularly")
        self.report['recommendations'].append("   - Use environment variables in production")
        self.report['recommendations'].append("   - Enable 2FA on all trading accounts")
    
    def generate_report(self):
        """Generate final audit report"""
        self.scan_directory()
        self.check_environment_setup()
        self.generate_recommendations()
        
        # Save report
        report_path = self.root_dir / 'security_audit_final_v2.json'
        with open(report_path, 'w') as f:
            json.dump(self.report, f, indent=2)
        
        # Print summary
        print("\n" + "="*60)
        print("🔒 SECURITY AUDIT COMPLETE")
        print("="*60)
        print(f"📊 Files scanned: {self.report['files_scanned']}")
        print(f"✅ Secure files: {self.report['secure_files']}")
        print(f"⚠️  Vulnerable files: {self.report['vulnerable_files']}")
        print(f"🔍 Issues found: {len(self.report['issues_found'])}")
        
        if self.report['issues_found']:
            print("\n❌ SECURITY ISSUES FOUND:")
            # Group by file
            files_with_issues = {}
            for issue in self.report['issues_found']:
                filepath = issue['file']
                if filepath not in files_with_issues:
                    files_with_issues[filepath] = []
                files_with_issues[filepath].append(issue)
            
            # Show first 5 files
            for filepath, issues in list(files_with_issues.items())[:5]:
                print(f"\n📄 {filepath}:")
                for issue in issues[:2]:
                    print(f"   Line {issue['line']}: {issue['type']}")
                if len(issues) > 2:
                    print(f"   ... and {len(issues) - 2} more issues")
                    
            if len(files_with_issues) > 5:
                print(f"\n... and {len(files_with_issues) - 5} more files with issues")
        else:
            print("\n✅ NO SECURITY ISSUES FOUND!")
            print("🎉 All credentials are properly secured using environment variables!")
        
        print("\n📋 RECOMMENDATIONS:")
        for rec in self.report['recommendations']:
            print(f"   {rec}")
            
        print(f"\n📊 Full report saved to: {report_path}")
        
        return len(self.report['issues_found']) == 0

if __name__ == '__main__':
    auditor = FinalSecurityAuditV2()
    success = auditor.generate_report()
    
    if success:
        print("\n✅ SYSTEM IS SECURE - No credentials found in code!")
        exit(0)
    else:
        print("\n❌ SECURITY ISSUES REMAIN - Please fix before deployment!")
        exit(1)