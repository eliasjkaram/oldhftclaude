#!/usr/bin/env python3
import pandas as pd
import numpy as np

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Load the cached options file
df = pd.read_csv('/home/harry/alpaca-mcp/minio_cache/2008-01-02options.csv')

print('=== Sample Options Data Analysis (2008-01-02) ===')
print(f'Date: {df["quote_date"].iloc[0]}')
print(f'Total contracts: {len(df):,}')
print(f'Unique underlyings: {df["underlying"].nunique():,}')
print(f'Total volume: {df["volume"].sum():,}')

print('\nTop 10 Most Active Underlyings:')
top_symbols = df["underlying"].value_counts().head(10)
for symbol, count in top_symbols.items():
    total_vol = df[df["underlying"] == symbol]["volume"].sum()
    print(f'  {symbol}: {count:,} contracts, {total_vol:,} volume')

print('\nImplied Volatility Statistics:')
iv_stats = df["implied_volatility"].describe()
print(f'  Mean IV: {iv_stats["mean"]*100:.2f}%')
print(f'  Median IV: {iv_stats["50%"]*100:.2f}%')
print(f'  Max IV: {iv_stats["max"]*100:.2f}%')

# Sample AAPL analysis
aapl_data = df[df['underlying'] == 'AAPL']
if len(aapl_data) > 0:
    print(f'\n=== AAPL Options Analysis ===')
    print(f'Total AAPL contracts: {len(aapl_data):,}')
    calls = aapl_data[aapl_data['type'] == 'call']
    puts = aapl_data[aapl_data['type'] == 'put']
    print(f'Calls: {len(calls):,}, Puts: {len(puts):,}')
    print(f'Strike range: ${aapl_data["strike"].min():.0f} - ${aapl_data["strike"].max():.0f}')
    print(f'Total AAPL volume: {aapl_data["volume"].sum():,}')
    print(f'Mean IV: {aapl_data["implied_volatility"].mean()*100:.2f}%')

# High IV contracts
high_iv = df[df['implied_volatility'] > 0.5]  # IV > 50%
print(f'\nHigh Volatility Contracts (IV > 50%): {len(high_iv):,} ({len(high_iv)/len(df)*100:.1f}% of all contracts)')

# Put/Call analysis
call_volume = df[df['type'] == 'call']['volume'].sum()
put_volume = df[df['type'] == 'put']['volume'].sum()
put_call_ratio = put_volume / call_volume if call_volume > 0 else 0
print(f'\nPut/Call Volume Ratio: {put_call_ratio:.3f}')
print(f'  Call volume: {call_volume:,}')
print(f'  Put volume: {put_volume:,}')