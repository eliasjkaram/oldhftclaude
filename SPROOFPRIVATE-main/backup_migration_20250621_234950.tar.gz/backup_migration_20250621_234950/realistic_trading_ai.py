
#!/usr/bin/env python3
# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
import time
import warnings

from universal_market_data import get_current_market_data, get_realistic_price
warnings.filterwarnings('ignore')

class RealisticTradingAI:
    def __init__(self, symbols=['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA'], sequence_length=30):
        self.symbols = symbols
        self.sequence_length = sequence_length
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.scalers = {}
        self.models = {}
        
        print(f"🎯 Realistic GPU Trading AI")
        print(f"Device: {self.device}")
        if torch.cuda.is_available():
            print(f"GPU: {torch.cuda.get_device_name(0)}")
    
    def generate_realistic_data(self, symbol, periods=1440):  # 5 days of 5-min data
        """Generate realistic financial data with proper scaling"""
        np.random.seed(hash(symbol) % 2**32)
        
        # Realistic base prices and volatilities
        base_prices = get_current_market_data(['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA'])  # Real prices
        daily_vols = {'AAPL': 0.015, 'GOOGL': 0.018, 'MSFT': 0.012, 'TSLA': 0.030, 'NVDA': 0.025}
        
        base_price = base_prices.get(symbol, 200.0)
        daily_vol = daily_vols.get(symbol, 0.02)
        
        # Convert to 5-minute volatility (scale down)
        vol_5min = daily_vol / np.sqrt(288)  # 288 = 5-min periods in a day
        
        # Generate realistic returns
        returns = np.random.normal(0, vol_5min, periods)
        
        # Add small trend and mean reversion
        trend = np.linspace(-0.001, 0.001, periods)  # Small trend
        mean_reversion = -0.1 * np.cumsum(returns)  # Mean reversion
        
        returns = returns + trend + mean_reversion * 0.01
        
        # Generate prices using geometric Brownian motion
        prices = [base_price]
        for i in range(1, periods):
            price = prices[-1] * np.exp(returns[i])
            prices.append(price)
        
        # Generate OHLCV with realistic spreads
        data = []
        for i, price in enumerate(prices):
            # Small random spread around close price
            spread = price * np.random.uniform(0.001, 0.003)
            
            open_price = price + np.random.uniform(-spread/2, spread/2)
            high_price = price + np.random.uniform(0, spread)
            low_price = price - np.random.uniform(0, spread)
            close_price = price
            volume = int(np.random.lognormal(14, 0.5)  # Realistic volume)
            
            data.append({)
                'Open': open_price,
                'High': high_price, 
                'Low': low_price,
                'Close': close_price,
                'Volume': volume
            })
        
        df = pd.DataFrame(data)
        
        # Add technical indicators
        df['Returns'] = df['Close'].pct_change()
        df['SMA_10'] = df['Close'].rolling(10).mean()
        df['RSI'] = self.calculate_rsi(df['Close'])
        df['MACD'] = self.calculate_macd(df['Close'])
        df['BB_upper'], df['BB_lower'] = self.calculate_bollinger_bands(df['Close'])
        
        df.dropna(inplace=True)
        return df

    def calculate_rsi(self, prices, window=14):
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window).mean())
        rs = gain / loss
        return 100 - (100 / (1 + rs)

    def calculate_macd(self, prices, fast=12, slow=26):
        exp1 = prices.ewm(span=fast).mean()
        exp2 = prices.ewm(span=slow).mean()
        return exp1 - exp2

    def calculate_bollinger_bands(self, prices, window=20):
        sma = prices.rolling(window).mean()
        std = prices.rolling(window).std()
        upper = sma + (std * 2)
        lower = sma - (std * 2)
        return upper, lower

class SimpleNN(nn.Module):
    def __init__(self, input_size=6, hidden_size=64):
        super(SimpleNN, self).__init__()
        self.net = nn.Sequential()
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_size, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
    
    def forward(self, x):
        return self.net(x.view(x.size(0), -1)
    
    def train_realistic_model(self, symbol, data, epochs=100):
        """Train with realistic constraints"""
        print(f"\n📈 Training realistic model for {symbol}...")
        
        # Use percentage returns as target (much more stable)
        features = ['Returns', 'RSI', 'MACD']
        available_features = [f for f in features if f in data.columns and not data[f].isna().all()]
        
        if len(available_features) < 2:
            print(f"  ❌ Insufficient features for {symbol}")
            return None
        
        X = data[available_features].values[1:]  # Skip first row (NaN)
        y = data['Returns'].values[1:]  # Predict next return
        
        # Remove any remaining NaN values
        mask = ~(np.isnan(X).any(axis=1) | np.isnan(y)
        X, y = X[mask], y[mask]
        
        if len(X) < 100:
            print(f"  ❌ Insufficient clean data for {symbol} ({len(X)} samples)")
            return None
        
        # Split data
        split = int(0.8 * len(X)
        X_train, X_test = X[:split], X[split:]
        y_train, y_test = y[:split], y[split:]
        
        # Scale features
        scaler_X = MinMaxScaler()
        X_train_scaled = scaler_X.fit_transform(X_train)
        X_test_scaled = scaler_X.transform(X_test)
        
        # Convert to tensors
        X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
        y_train_tensor = torch.FloatTensor(y_train).to(self.device)
        X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
        y_test_tensor = torch.FloatTensor(y_test).to(self.device)
        
        # Create model
        model = SimpleNN(input_size=len(available_features).to(self.device)
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)
        
        # Training
        model.train()
        for epoch in range(epochs):
            optimizer.zero_grad()
            outputs = model(X_train_tensor)
            loss = criterion(outputs.squeeze(), y_train_tensor)
            loss.backward()
            optimizer.step()
            
            if epoch % 20 == 0:
                print(f"    Epoch {epoch}: Loss = {loss.item():.8f}")
        
        # Evaluation
        model.eval()
        with torch.no_grad():
            train_pred = model(X_train_tensor).cpu().numpy()
            test_pred = model(X_test_tensor).cpu().numpy()
            
            train_mse = mean_squared_error(y_train, train_pred)
            test_mse = mean_squared_error(y_test, test_pred)
            
            # Direction accuracy (more meaningful for trading)
            actual_direction = np.sign(y_test)
            pred_direction = np.sign(test_pred.flatten()
            direction_accuracy = np.mean(actual_direction == pred_direction) * 100
            
            print(f"    ✅ MSE: {test_mse:.8f}, Direction Accuracy: {direction_accuracy:.1f}%")
        
        self.models[symbol] = model
        self.scalers[symbol] = scaler_X
        
        return {}
            'model': model,
            'scaler': scaler_X,
            'features': available_features,
            'test_mse': test_mse,
            'direction_accuracy': direction_accuracy
        }

    def predict_realistic_returns(self, symbol, data, current_price):
        """Make realistic return predictions"""
        if symbol not in self.models:
            return None
        
        model = self.models[symbol]
        scaler = self.scalers[symbol]
        
        # Get last values for prediction
        last_data = data.iloc[-1]
        features = ['Returns', 'RSI', 'MACD']
        available_features = [f for f in features if f in data.columns]
        
        last_values = np.array([last_data[f] for f in available_features]).reshape(1, -1)
        last_scaled = scaler.transform(last_values)
        
        model.eval()
        with torch.no_grad():
            input_tensor = torch.FloatTensor(last_scaled).to(self.device)
            pred_return = model(input_tensor).cpu().numpy()[0, 0]
            
            # Apply realistic constraints
            pred_return = np.clip(pred_return, -0.05, 0.05)  # Max 5% move
            
            predicted_price = current_price * (1 + pred_return)
            
        return {}
            'predicted_return': pred_return * 100,  # As percentage
            'predicted_price': predicted_price,
            'confidence': min(abs(pred_return) * 1000, 100)  # Simple confidence metric
        }

    def run_realistic_analysis(self):
        """Run realistic trading analysis"""
        print("🎯 Realistic GPU Trading AI Analysis")
        print("=" * 50)
        
        # Generate data
        print("\n📊 Generating realistic market data...")
        all_data = {}
        for symbol in self.symbols:
            data = self.generate_realistic_data(symbol)
            all_data[symbol] = data
            print(f"    {symbol}: {len(data)} periods, price range ${data['Close'].min():.2f}-${data['Close'].max():.2f}")
        
        # Train models
        print(f"\n🔥 Training realistic models...")
        results = {}
        for symbol in all_data:
            result = self.train_realistic_model(symbol, all_data[symbol])
            if result:
                results[symbol] = result
        
        # Make realistic predictions
        print(f"\n🔮 Realistic Predictions (Next 5-minute period)...")
        print("-" * 60)
        
        for symbol in results:
            current_price = all_data[symbol]['Close'].iloc[-1]
            prediction = self.predict_realistic_returns(symbol, all_data[symbol], current_price)
            
            if prediction:
                pred_price = prediction['predicted_price']
                pred_return = prediction['predicted_return']
                confidence = prediction['confidence']
                
                direction = "📈" if pred_return > 0 else "📉"
                print(f"{symbol:5s}: ${current_price:7.2f} → ${pred_price:7.2f} ({pred_return:+5.2f}%) {direction} Conf: {confidence:.0f}%")
        
        # Summary
        avg_accuracy = np.mean([r['direction_accuracy'] for r in results.values()])
        print(f"\n📊 Summary:")
        print(f"    Models trained: {len(results)}")
        print(f"    Average direction accuracy: {avg_accuracy:.1f}%")
        print(f"    Realistic return predictions: ±0.1% to ±2%")
        
        return results

if __name__ == "__main__":
    ai = RealisticTradingAI()
    results = ai.run_realistic_analysis()