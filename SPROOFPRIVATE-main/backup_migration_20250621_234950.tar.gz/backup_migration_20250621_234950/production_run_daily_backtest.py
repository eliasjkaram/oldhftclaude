from datetime import datetime, timedelta
import json
import sys
from config import config
#!/usr/bin/env python3
"""
Run backtest using daily data instead of hourly to avoid data issues
"""

import asyncio

import logging
from datetime import datetime
from v21_alpaca_backtest_system import BacktestConfig, AlpacaBacktester, AlpacaDataFetcher
import os
import pandas as pd

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class DailyDataFetcher(AlpacaDataFetcher):
    """Override to use daily data"""
    
    def fetch_data(self, symbol: str, timeframe: str = "1D") -> pd.DataFrame:
        """Force daily timeframe"""
        return super().fetch_data(symbol, "1D")

async def run_daily_backtest():
    """Run backtest with daily data"""
    
    # Use 2023 data
    config = BacktestConfig()
        start_date = config.get("start_date", datetime.now() - timedelta(days=365)),
        end_date='2023-12-31',
        initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000")),
        commission=0.001,
        slippage=0.0005,
        data_cache_dir='daily_data_cache',
        use_minio=False
    )
    
    # Create cache directory
    os.makedirs(config.data_cache_dir, exist_ok=True)
    
    # Core symbols
    symbols = []
        'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META',
        'NVDA', 'TSLA', 'JPM', 'BAC',
        'SPY', 'QQQ', 'IWM', 'GLD', 'USO'
    ]
    
    # Test key algorithms
    algorithms = []
        'RSI_Oversold',
        'MACD_Crossover',
        'Bollinger_Squeeze',
        'Mean_Reversion',
        'Momentum_Alpha',
        'Volume_Breakout',
        'Support_Resistance',
        'Trend_Following'
    ]
    
    logger.info("\n" + "="*80)
    logger.info("🚀 DAILY DATA BACKTEST - 2023")
    logger.info("="*80)
    logger.info(f"📅 Period: {config.start_date} to {config.end_date}")
    logger.info(f"💰 Initial Capital: ${config.initial_capital:,}")
    logger.info(f"📊 Symbols: {len(symbols)}")
    logger.info(f"🤖 Algorithms: {len(algorithms)}")
    logger.info(f"📈 Timeframe: Daily")
    logger.info("="*80 + "\n")
    
    # Initialize backtester with custom data fetcher
    backtester = AlpacaBacktester(config)
    
    # Override the data fetcher to use daily
    from alpaca_trade_api import TimeFrame
    
    # Patch the fetch method
    original_fetch = backtester.data_fetcher.fetch_data
    
    def fetch_daily(symbol, timeframe="1D"):
        if backtester.data_fetcher.alpaca_client:
            try:
                # Check cache first
                cached = backtester.data_fetcher.storage.load_data(symbol, "1D")
                if cached is not None:
                    return cached
                
                # Fetch daily bars
                bars = backtester.data_fetcher.alpaca_client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=config.start_date,
                    end=config.end_date,
                    adjustment='raw'
                ).df
                
                if not bars.empty:
                    bars.columns = ['open', 'high', 'low', 'close', 'volume', 'trade_count', 'vwap']
                    
                    # Clean data
                    bars = bars.dropna(subset=['open', 'high', 'low', 'close'])
                    
                    # Validate price ranges
                    # Filter out anomalous prices (e.g., > $10,000 for most stocks)
                    max_reasonable_price = 10000
                    bars = bars[(bars['close'] > 0) & (bars['close'] < max_reasonable_price)]
                    
                    # Save to cache
                    backtester.data_fetcher.storage.save_data(symbol, "1D", bars)
                    
                    logger.info(f"✅ {symbol}: {len(bars)} days, price range ${bars['close'].min():.2f}-${bars['close'].max():.2f}")
                    return bars
            except Exception as e:
                logger.error("❌ Error fetching {symbol}: {e}")
        return None
    
    backtester.data_fetcher.fetch_data = fetch_daily
    
    if not backtester.data_fetcher.alpaca_client:
        logger.info("❌ Alpaca client not initialized. Check credentials.")
        return
    
    # Run backtest
    logger.info("\nFetching daily data...\n")
    await backtester.run_backtest(symbols, algorithms)
    
    # Generate report
    report = backtester.generate_report()
    
    # Generate plots
    backtester.plot_results()
    
    # Print results
    if report and 'summary' in report:
        logger.info("\n" + "="*80)
        logger.info("📊 BACKTEST RESULTS")
        logger.info("="*80)
        
        summary = report['summary']
        logger.info(f"\n📈 Best Algorithm: {summary.get('best_algorithm', 'N/A')}")
        logger.info(f"   Return: {summary.get('best_return', 0):.2%}")
        logger.info(f"\n📊 Average Performance:")
        logger.info(f"   Return: {summary.get('average_return', 0):.2%}")
        logger.info(f"   Sharpe: {summary.get('average_sharpe', 0):.2f}")
        
        if 'top_performers' in report:
            logger.info("\n🏆 TOP PERFORMERS:")
            logger.info(f"{'Algorithm':<25} {'Return':<12} {'Sharpe':<10} {'Win Rate':<10} {'Trades':<10}")
            logger.info("-" * 70)
            
            for algo in report['top_performers'][:8]:
                print(f"{algo['algorithm']:<25} {algo['return']:>10.2%} ")
                      f"{algo['sharpe']:>8.2f} {algo['win_rate']:>8.1%} {algo['trades']:>8}")
        
        logger.info("\n✅ Daily backtest complete!")
        logger.info("\n📁 Results saved to:")
        logger.info("  • v21_backtest_report.json")
        logger.info("  • v21_backtest_results.png")
    else:
        logger.info("\n❌ No results generated")

if __name__ == "__main__":
    asyncio.run(run_daily_backtest()