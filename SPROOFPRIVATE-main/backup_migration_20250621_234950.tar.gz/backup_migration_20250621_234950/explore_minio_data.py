
#!/usr/bin/env python3
"""
MinIO Stock Database Explorer
Connects to MinIO stockdb bucket and creates a comprehensive inventory report
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
from datetime import datetime
from collections import defaultdict
import json
from typing import Dict, List, Tuple
import re

try:
    from minio import Minio
    from minio.error import S3Error
except ImportError:
    print("Error: minio package not installed. Please install with: pip install minio")
    sys.exit(1)

class MinIOExplorer:
    def __init__(self, endpoint: str, access_key: str, secret_key: str, secure: bool = True):
        """Initialize MinIO client"""
        self.client = Minio()
            endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure
        )
        self.bucket_name = "stockdb"
        self.inventory = {}
            'total_objects': 0,
            'total_size': 0,
            'data_types': defaultdict(int),
            'file_formats': defaultdict(int),
            'date_ranges': {},
            'objects_by_type': defaultdict(list),
            'size_by_type': defaultdict(int),
            'size_by_format': defaultdict(int)
        }
    
    def explore_bucket(self):
        """Main method to explore the bucket"""
        print(f"Exploring bucket: {self.bucket_name}")
        print("-" * 50)
        
        try:
            # Check if bucket exists
            if not self.client.bucket_exists(self.bucket_name):
                print(f"Error: Bucket '{self.bucket_name}' does not exist")
                return
            
            # List all objects
            objects = self.client.list_objects(self.bucket_name, recursive=True)
            
            for obj in objects:
                self.process_object(obj)
            
            # Generate report
            self.generate_report()
            
        except S3Error as e:
            print(f"MinIO Error: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")
    
    def process_object(self, obj):
        """Process individual object and update inventory"""
        self.inventory['total_objects'] += 1
        self.inventory['total_size'] += obj.size
        
        # Extract object details
        object_name = obj.object_name
        size = obj.size
        last_modified = obj.last_modified
        
        # Determine data type and file format
        data_type = self.identify_data_type(object_name)
        file_format = self.identify_file_format(object_name)
        
        # Update counters
        self.inventory['data_types'][data_type] += 1
        self.inventory['file_formats'][file_format] += 1
        self.inventory['size_by_type'][data_type] += size
        self.inventory['size_by_format'][file_format] += size
        
        # Store object info
        self.inventory['objects_by_type'][data_type].append({)
            'name': object_name,
            'size': size,
            'last_modified': last_modified.isoformat() if last_modified else None
        })
        
        # Extract and update date ranges
        self.update_date_ranges(object_name, data_type)
    
    def identify_data_type(self, object_name: str) -> str:
        """Identify data type based on object name patterns"""
        name_lower = object_name.lower()
        
        # Common patterns for different data types
        if 'option' in name_lower or 'opt' in name_lower:
            return 'options'
        elif 'stock' in name_lower or 'equity' in name_lower or 'ticker' in name_lower:
            return 'stocks'
        elif 'minute' in name_lower or '1min' in name_lower or 'intraday' in name_lower:
            return 'intraday'
        elif 'daily' in name_lower or 'day' in name_lower or 'eod' in name_lower:
            return 'daily'
        elif 'fundamental' in name_lower or 'financials' in name_lower:
            return 'fundamentals'
        elif 'news' in name_lower:
            return 'news'
        elif 'index' in name_lower or 'indices' in name_lower:
            return 'indices'
        else:
            # Try to identify by path structure
            parts = object_name.split('/')
            if len(parts) > 1:
                return parts[0]  # Use first directory as type
            return 'unknown'
    
    def identify_file_format(self, object_name: str) -> str:
        """Identify file format from extension"""
        _, ext = os.path.splitext(object_name)
        if ext:
            return ext.lower().lstrip('.')
        return 'no_extension'
    
    def update_date_ranges(self, object_name: str, data_type: str):
        """Extract dates from object name and update date ranges"""
        # Common date patterns in filenames
        date_patterns = []
            r'(\d{4}-\d{2}-\d{2})',  # YYYY-MM-DD
            r'(\d{4}\d{2}\d{2})',     # YYYYMMDD
            r'(\d{8})',               # YYYYMMDD
            r'(\d{4}_\d{2}_\d{2})',   # YYYY_MM_DD
        ]
        
        dates_found = []
        for pattern in date_patterns:
            matches = re.findall(pattern, object_name)
            for match in matches:
                try:
                    # Try to parse the date
                    if '-' in match:
                        date_obj = datetime.strptime(match, '%Y-%m-%d')
                    elif '_' in match:
                        date_obj = datetime.strptime(match, '%Y_%m_%d')
                    elif len(match) == 8:
                        date_obj = datetime.strptime(match, '%Y%m%d')
                    else:
                        continue
                    dates_found.append(date_obj)
                except ValueError:
                    continue
        
        # Update date ranges for this data type
        if dates_found:
            if data_type not in self.inventory['date_ranges']:
                self.inventory['date_ranges'][data_type] = {}
                    'min_date': min(dates_found),
                    'max_date': max(dates_found)
                }
            else:
                current_min = self.inventory['date_ranges'][data_type]['min_date']
                current_max = self.inventory['date_ranges'][data_type]['max_date']
                self.inventory['date_ranges'][data_type]['min_date'] = min(current_min, min(dates_found)
                self.inventory['date_ranges'][data_type]['max_date'] = max(current_max, max(dates_found)
    
    def format_size(self, size_bytes: int) -> str:
        """Format size in human-readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} PB"
    
    def generate_report(self):
        """Generate and display comprehensive inventory report"""
        print("\n" + "=" * 60)
        print("MINIO STOCKDB INVENTORY REPORT")
        print("=" * 60)
        print(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("\n")
        
        # Overall Statistics
        print("OVERALL STATISTICS")
        print("-" * 30)
        print(f"Total Objects: {self.inventory['total_objects']:,}")
        print(f"Total Size: {self.format_size(self.inventory['total_size'])}")
        print(f"Average Object Size: {self.format_size(self.inventory['total_size'] // max(1, self.inventory['total_objects'])}")
        print("\n")
        
        # Data Types Summary
        print("DATA TYPES SUMMARY")
        print("-" * 30)
        print(f"{'Data Type':<20} {'Count':>10} {'Size':>15} {'Avg Size':>15}")
        print("-" * 60)
        for data_type, count in sorted(self.inventory['data_types'].items():
            size = self.inventory['size_by_type'][data_type]
            avg_size = size // max(1, count)
            print(f"{data_type:<20} {count:>10,} {self.format_size(size):>15} {self.format_size(avg_size):>15}")
        print("\n")
        
        # File Formats Summary
        print("FILE FORMATS SUMMARY")
        print("-" * 30)
        print(f"{'Format':<15} {'Count':>10} {'Size':>15} {'% of Total':>15}")
        print("-" * 55)
        for format_type, count in sorted(self.inventory['file_formats'].items(), key=lambda x: x[1], reverse=True):
            size = self.inventory['size_by_format'][format_type]
            percentage = (size / max(1, self.inventory['total_size']) * 100)
            print(f"{format_type:<15} {count:>10,} {self.format_size(size):>15} {percentage:>14.1f}%")
        print("\n")
        
        # Date Ranges
        print("DATE RANGES BY DATA TYPE")
        print("-" * 30)
        if self.inventory['date_ranges']:
            print(f"{'Data Type':<20} {'Start Date':<15} {'End Date':<15} {'Days Covered':>12}")
            print("-" * 62)
            for data_type, dates in sorted(self.inventory['date_ranges'].items():
                start_date = dates['min_date'].strftime('%Y-%m-%d')
                end_date = dates['max_date'].strftime('%Y-%m-%d')
                days_covered = (dates['max_date'] - dates['min_date']).days + 1
                print(f"{data_type:<20} {start_date:<15} {end_date:<15} {days_covered:>12,}")
        else:
            print("No date information found in object names")
        print("\n")
        
        # Sample Objects by Type
        print("SAMPLE OBJECTS BY TYPE (First 3 of each)")
        print("-" * 30)
        for data_type, objects in sorted(self.inventory['objects_by_type'].items():
            print(f"\n{data_type.upper()}:")
            for obj in objects[:3]:
                print(f"  - {obj['name']} ({self.format_size(obj['size'])})")
            if len(objects) > 3:
                print(f"  ... and {len(objects) - 3} more objects")
        
        # Save detailed report to file
        self.save_detailed_report()
    
    def save_detailed_report(self):
        """Save detailed inventory to JSON file"""
        report_file = "minio_inventory_report.json"
        
        # Prepare report data
        report_data = {}
            'generated_at': datetime.now().isoformat(),
            'bucket_name': self.bucket_name,
            'summary': {}
                'total_objects': self.inventory['total_objects'],
                'total_size_bytes': self.inventory['total_size'],
                'total_size_human': self.format_size(self.inventory['total_size']),
                'data_types_count': dict(self.inventory['data_types']),
                'file_formats_count': dict(self.inventory['file_formats'])
            },
            'date_ranges': {}
                data_type: {}
                    'start_date': dates['min_date'].isoformat(),
                    'end_date': dates['max_date'].isoformat(),
                    'days_covered': (dates['max_date'] - dates['min_date']).days + 1
                } for data_type, dates in self.inventory['date_ranges'].items()
            },
            'size_by_type': {}
                data_type: {}
                    'bytes': size,
                    'human_readable': self.format_size(size)
                } for data_type, size in self.inventory['size_by_type'].items()
            },
            'objects_list': dict(self.inventory['objects_by_type'])
        }
        
        # Save to file
        try:
            with open(report_file, 'w') as f:
                json.dump(report_data, f, indent=2, default=str)
            print(f"\nDetailed report saved to: {report_file}")
        except Exception as e:
            print(f"Error saving report: {e}")


def main():
    """Main function"""
    # MinIO connection parameters
    # Update these with your actual MinIO credentials
    MINIO_ENDPOINT = os.getenv('MINIO_ENDPOINT', 'localhost:9000')
    MINIO_ACCESS_KEY = os.getenv('MINIO_ACCESS_KEY', 'minioadmin')
    MINIO_SECRET_KEY = os.getenv('MINIO_SECRET_KEY', 'minioadmin')
    MINIO_SECURE = os.getenv('MINIO_SECURE', 'False').lower() == 'true'
    
    print("MinIO Stock Database Explorer")
    print("=" * 50)
    print(f"Endpoint: {MINIO_ENDPOINT}")
    print(f"Secure: {MINIO_SECURE}")
    print("=" * 50)
    
    # Create explorer and run
    explorer = MinIOExplorer()
        endpoint=MINIO_ENDPOINT,
        access_key=MINIO_ACCESS_KEY,
        secret_key=MINIO_SECRET_KEY,
        secure=MINIO_SECURE
    )
    
    explorer.explore_bucket()


if __name__ == "__main__":
    main()