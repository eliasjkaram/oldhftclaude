#!/usr/bin/env python3
"""
Comprehensive Trading System Launcher
=====================================
Launches all 100+ components of the AI-Enhanced High-Frequency Trading System
"""

import os
import sys
import asyncio
import signal
import logging
import traceback
from datetime import datetime
from typing import Dict, List, Optional, Set, Any
from dataclasses import dataclass, field
from enum import Enum
import json
import time
import psutil
import requests
from concurrent.futures import ThreadPoolExecutor
import subprocess
import argparse
import numpy as np

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('comprehensive_system.log')
    ]
)
logger = logging.getLogger(__name__)

class TradingMode(Enum):
    PAPER = "paper_trading"
    LIVE = "live_trading"
    BACKTEST = "backtesting"
    RESEARCH = "research"

@dataclass
class ComponentConfig:
    """Configuration for a system component"""
    name: str
    module: str
    class_name: str
    dependencies: List[str] = field(default_factory=list)
    required: bool = True
    category: str = "core"
    restart_on_failure: bool = True
    health_check_endpoint: Optional[str] = None
    config_overrides: Dict = field(default_factory=dict)
    startup_delay: float = 0.0

class ComponentState(Enum):
    NOT_STARTED = "not_started"
    STARTING = "starting"
    RUNNING = "running"
    ERROR = "error"
    STOPPED = "stopped"
    RESTARTING = "restarting"

@dataclass
class SystemComponent:
    """Represents a running system component"""
    config: ComponentConfig
    state: ComponentState = ComponentState.NOT_STARTED
    instance: Optional[Any] = None
    error: Optional[str] = None
    start_time: Optional[datetime] = None
    restart_count: int = 0
    last_health_check: Optional[datetime] = None
    health_check_failures: int = 0

class ComprehensiveSystemLauncher:
    """Manages all trading system components"""
    
    def __init__(self, mode: TradingMode = TradingMode.PAPER, config_path: Optional[str] = None):
        self.mode = mode
        self.config_path = config_path
        self.components: Dict[str, SystemComponent] = {}
        self.running = False
        self.start_time = None
        self.shutdown_event = asyncio.Event()
        self.monitoring_task = None
        self.health_check_executor = ThreadPoolExecutor(max_workers=5)
        
        # Metrics
        self.metrics = {}
            'opportunities_found': 0,
            'trades_executed': 0,
            'pnl': 0.0,
            'errors_handled': 0,
            'component_restarts': {}
        }
        
        # Initialize all components
        self._initialize_all_components()
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _initialize_all_components(self):
        """Initialize configuration for all 100+ components"""
        
        # Define all components with proper categories
        all_components = []
            # Core Infrastructure (Required)
            ComponentConfig()
                name="health_monitor",
                module="health_monitoring",
                class_name="HealthMonitor",
                category="infrastructure",
                required=True
            ),
            ComponentConfig()
                name="logging_system",
                module="logging_config",
                class_name="LoggingSystem",
                category="infrastructure",
                required=True
            ),
            ComponentConfig()
                name="configuration_manager",
                module="configuration_manager",
                class_name="ConfigurationManager",
                category="infrastructure",
                required=True
            ),
            ComponentConfig()
                name="secrets_manager",
                module="secrets_manager",
                class_name="SecretsManager",
                dependencies=["configuration_manager"],
                category="infrastructure",
                required=True
            ),
            
            # Core Trading Infrastructure
            ComponentConfig()
                name="alpaca_client",
                module="alpaca_integration",
                class_name="AlpacaClientWrapper",
                dependencies=["secrets_manager"],
                category="trading_core",
                required=True
            ),
            ComponentConfig()
                name="market_data_collector",
                module="market_data_collector",
                class_name="MarketDataCollector",
                dependencies=["alpaca_client"],
                category="trading_core",
                required=True
            ),
            ComponentConfig()
                name="order_executor",
                module="order_executor",
                class_name="OrderExecutor",
                dependencies=["alpaca_client"],
                category="trading_core",
                required=True
            ),
            ComponentConfig()
                name="position_manager",
                module="position_manager",
                class_name="PositionManager",
                dependencies=["order_executor"],
                category="trading_core",
                required=True
            ),
            ComponentConfig()
                name="risk_management",
                module="advanced_risk_management_system",
                class_name="AdvancedRiskManager",
                dependencies=["position_manager"],
                category="risk",
                required=True
            ),
            ComponentConfig()
                name="performance_tracker",
                module="performance_tracker",
                class_name="PerformanceTracker",
                dependencies=["position_manager"],
                category="monitoring",
                required=True
            ),
            
            # Data Pipeline Components
            ComponentConfig()
                name="minio_pipeline",
                module="DATA_PIPELINE_MINIO_wrapper",
                class_name="MinIODataPipeline",
                dependencies=["market_data_collector"],
                category="data_pipeline",
                required=False
            ),
            ComponentConfig()
                name="historical_data_engine",
                module="historical_data_engine",
                class_name="HistoricalDataEngine",
                dependencies=["minio_pipeline"],
                category="data_pipeline",
                required=False
            ),
            ComponentConfig()
                name="feature_engineering",
                module="feature_engineering_pipeline",
                class_name="FeatureEngineeringPipeline",
                dependencies=["historical_data_engine"],
                category="ml_pipeline",
                required=False
            ),
            ComponentConfig()
                name="data_quality_validator",
                module="data_quality_validator",
                class_name="DataQualityValidator",
                dependencies=["minio_pipeline"],
                category="data_pipeline",
                required=False
            ),
            
            # Core AI Components
            ComponentConfig()
                name="ai_arbitrage_agent",
                module="autonomous_ai_arbitrage_agent",
                class_name="AutonomousAIAgent",
                dependencies=["market_data_collector"],
                category="ai_core",
                required=False
            ),
            ComponentConfig()
                name="strategy_optimizer",
                module="advanced_strategy_optimizer",
                class_name="AdvancedStrategyOptimizer",
                dependencies=["ai_arbitrage_agent", "market_data_collector"],
                category="ai_core",
                required=False
            ),
            ComponentConfig()
                name="ai_hft_system",
                module="integrated_ai_hft_system",
                class_name="IntegratedAIHFTSystem",
                dependencies=["ai_arbitrage_agent", "strategy_optimizer"],
                category="ai_core",
                required=False
            ),
            
            # Options Trading Systems
            ComponentConfig()
                name="options_trader",
                module="advanced_options_strategy_system",
                class_name="AdvancedOptionsStrategy",
                dependencies=["order_executor", "market_data_collector"],
                category="options",
                required=False
            ),
            ComponentConfig()
                name="options_arbitrage",
                module="advanced_options_arbitrage_system",
                class_name="OptionsArbitrageSystem",
                dependencies=["options_trader", "market_data_collector"],
                category="options",
                required=False
            ),
            ComponentConfig()
                name="ai_options_bot",
                module="ai_enhanced_options_bot",
                class_name="AIEnhancedOptionsBot",
                dependencies=["options_trader", "ai_arbitrage_agent"],
                category="options",
                required=False
            ),
            ComponentConfig()
                name="options_spreads",
                module="OPTIONS_SPREADS_TRADING_SYSTEM",
                class_name="OptionsSpreadsSystem",
                dependencies=["options_trader"],
                category="options",
                required=False
            ),
            ComponentConfig()
                name="wheel_bot",
                module="integrated_wheel_bot",
                class_name="WheelStrategyBot",
                dependencies=["options_trader"],
                category="options",
                required=False
            ),
            
            # Arbitrage & Scanning Systems
            ComponentConfig()
                name="arbitrage_scanner",
                module="arbitrage_scanner",
                class_name="ArbitrageScanner",
                dependencies=["market_data_collector"],
                category="arbitrage",
                required=False
            ),
            ComponentConfig()
                name="leaps_arbitrage",
                module="leaps_arbitrage_scanner",
                class_name="LEAPSArbitrageScanner",
                dependencies=["options_trader", "arbitrage_scanner"],
                category="arbitrage",
                required=False
            ),
            ComponentConfig()
                name="cross_exchange_arbitrage",
                module="cross_exchange_arbitrage_engine",
                class_name="CrossExchangeEngine",
                dependencies=["arbitrage_scanner"],
                category="arbitrage",
                required=False
            ),
            ComponentConfig()
                name="options_scanner",
                module="options_scanner",
                class_name="OptionsScanner",
                dependencies=["options_trader"],
                category="arbitrage",
                required=False
            ),
            ComponentConfig()
                name="mega_scanner",
                module="mega_scanner",
                class_name="MegaScanner",
                dependencies=["arbitrage_scanner", "options_scanner"],
                category="arbitrage",
                required=False
            ),
            
            # Advanced Trading Bots
            ComponentConfig()
                name="premium_bot",
                module="advanced_premium_bot",
                class_name="PremiumHarvestBot",
                dependencies=["options_trader"],
                category="bots",
                required=False
            ),
            ComponentConfig()
                name="multi_strategy_bot",
                module="enhanced_multi_strategy_bot",
                class_name="MultiStrategyBot",
                dependencies=["strategy_optimizer"],
                category="bots",
                required=False
            ),
            ComponentConfig()
                name="enhanced_options_bot",
                module="enhanced_options_bot",
                class_name="EnhancedOptionsBot",
                dependencies=["options_trader"],
                category="bots",
                required=False
            ),
            ComponentConfig()
                name="ultimate_bot",
                module="enhanced_ultimate_bot",
                class_name="UltimateBot",
                dependencies=["ai_hft_system", "options_trader"],
                category="bots",
                required=False
            ),
            
            # Market Analysis Systems
            ComponentConfig()
                name="market_regime_detector",
                module="market_regime_detection_system",
                class_name="MarketRegimeDetector",
                dependencies=["market_data_collector"],
                category="analysis",
                required=False
            ),
            ComponentConfig()
                name="market_impact_predictor",
                module="market_impact_prediction_system",
                class_name="MarketImpactPredictor",
                dependencies=["market_data_collector"],
                category="analysis",
                required=False
            ),
            ComponentConfig()
                name="sentiment_analyzer",
                module="sentiment_analysis_system",
                class_name="SentimentAnalysisSystem",
                dependencies=["market_data_collector"],
                category="analysis",
                required=False
            ),
            ComponentConfig()
                name="microstructure_analyzer",
                module="market_microstructure_features",
                class_name="MicrostructureAnalyzer",
                dependencies=["market_data_collector"],
                category="analysis",
                required=False
            ),
            
            # ML & Prediction Systems
            ComponentConfig()
                name="transformer_predictor",
                module="transformer_prediction_system",
                class_name="TransformerPredictionSystem",
                dependencies=["feature_engineering"],
                category="ml_models",
                required=False
            ),
            ComponentConfig()
                name="ml_trading_pipeline",
                module="ML_TRADING_PIPELINE",
                class_name="MLTradingPipeline",
                dependencies=["feature_engineering"],
                category="ml_models",
                required=False
            ),
            ComponentConfig()
                name="ensemble_model",
                module="ensemble_model_system",
                class_name="EnsembleModelSystem",
                dependencies=["transformer_predictor"],
                category="ml_models",
                required=False
            ),
            ComponentConfig()
                name="reinforcement_agent",
                module="reinforcement_learning_agent",
                class_name="ReinforcementLearningAgent",
                dependencies=["ml_trading_pipeline"],
                category="ml_models",
                required=False
            ),
            
            # Risk & Portfolio Management
            ComponentConfig()
                name="realtime_risk_monitor",
                module="realtime_risk_monitoring_system",
                class_name="RealtimeRiskMonitor",
                dependencies=["risk_management"],
                category="risk",
                required=False
            ),
            ComponentConfig()
                name="position_management_system",
                module="position_management_system",
                class_name="PositionManagementSystem",
                dependencies=["position_manager"],
                category="risk",
                required=False
            ),
            ComponentConfig()
                name="pnl_tracker",
                module="pnl_tracking_system",
                class_name="PnLTracker",
                dependencies=["position_manager"],
                category="risk",
                required=False
            ),
            ComponentConfig()
                name="stress_tester",
                module="stress_testing_framework",
                class_name="StressTestingFramework",
                dependencies=["risk_management"],
                category="risk",
                required=False
            ),
            ComponentConfig()
                name="portfolio_optimizer",
                module="portfolio_optimization_engine",
                class_name="PortfolioOptimizer",
                dependencies=["position_manager"],
                category="risk",
                required=False
            ),
            
            # Monitoring & Dashboard Systems
            ComponentConfig()
                name="realtime_monitor",
                module="realtime_monitor_wrapper",
                class_name="RealtimeMonitor",
                dependencies=["health_monitor"],
                category="monitoring",
                required=False,
                health_check_endpoint="http://localhost:8080/status"
            ),
            ComponentConfig()
                name="model_monitor",
                module="automated_model_monitoring_dashboard",
                class_name="ModelMonitoringDashboard",
                dependencies=["ml_trading_pipeline"],
                category="monitoring",
                required=False
            ),
            ComponentConfig()
                name="system_monitor",
                module="system_monitor",
                class_name="SystemMonitor",
                dependencies=["health_monitor"],
                category="monitoring",
                required=False
            ),
            ComponentConfig()
                name="orchestrator_dashboard",
                module="orchestrator_dashboard",
                class_name="OrchestratorDashboard",
                dependencies=["realtime_monitor"],
                category="monitoring",
                required=False
            ),
            ComponentConfig()
                name="ai_systems_dashboard",
                module="ai_systems_dashboard",
                class_name="AISystemsDashboard",
                dependencies=["ai_hft_system"],
                category="monitoring",
                required=False
            ),
            
            # Trading Engines
            ComponentConfig()
                name="autonomous_engine",
                module="autonomous_trading_engine",
                class_name="AutonomousTradingEngine",
                dependencies=["ai_hft_system"],
                category="engines",
                required=False
            ),
            ComponentConfig()
                name="option_execution_engine",
                module="option_execution_engine",
                class_name="OptionExecutionEngine",
                dependencies=["options_trader"],
                category="engines",
                required=False
            ),
            ComponentConfig()
                name="spread_execution_engine",
                module="spread_execution_engine",
                class_name="SpreadExecutionEngine",
                dependencies=["options_spreads"],
                category="engines",
                required=False
            ),
            ComponentConfig()
                name="dsg_engine",
                module="dsg_core_engine",
                class_name="DSGCoreEngine",
                dependencies=["ai_hft_system"],
                category="engines",
                required=False
            ),
            
            # GPU & High-Performance Systems
            ComponentConfig()
                name="gpu_cluster",
                module="gpu_cluster_deployment_system",
                class_name="GPUClusterWrapper",
                dependencies=["ai_hft_system"],
                category="gpu",
                required=False
            ),
            ComponentConfig()
                name="gpu_trading_system",
                module="gpu_accelerated_trading_system",
                class_name="GPUTradingSystem",
                dependencies=["gpu_cluster"],
                category="gpu",
                required=False
            ),
            ComponentConfig()
                name="gpu_hft_engine",
                module="gpu_cluster_hft_engine",
                class_name="GPUClusterHFTEngine",
                dependencies=["gpu_cluster"],
                category="gpu",
                required=False
            ),
            ComponentConfig()
                name="gpu_options_trader",
                module="gpu_options_trader",
                class_name="GPUOptionsTrader",
                dependencies=["gpu_cluster", "options_trader"],
                category="gpu",
                required=False
            ),
            
            # Backtesting & Historical Systems
            ComponentConfig()
                name="backtesting_framework",
                module="robust_backtesting_framework",
                class_name="BacktestingFramework",
                dependencies=["historical_data_engine"],
                category="backtesting",
                required=False
            ),
            ComponentConfig()
                name="monte_carlo_backtester",
                module="monte_carlo_backtesting",
                class_name="MonteCarloBacktester",
                dependencies=["backtesting_framework"],
                category="backtesting",
                required=False
            ),
            ComponentConfig()
                name="llm_backtester",
                module="llm_augmented_backtesting_system",
                class_name="LLMAugmentedBacktester",
                dependencies=["backtesting_framework", "ai_arbitrage_agent"],
                category="backtesting",
                required=False
            ),
            
            # Continuous Learning Systems
            ComponentConfig()
                name="continual_learning",
                module="continual_learning_master_system",
                class_name="ContinualLearningSystem",
                dependencies=["ml_trading_pipeline"],
                category="ml_optimization",
                required=False
            ),
            ComponentConfig()
                name="improvement_engine",
                module="continuous_improvement_engine",
                class_name="ImprovementEngine",
                dependencies=["performance_tracker"],
                category="ml_optimization",
                required=False
            ),
            ComponentConfig()
                name="strategy_enhancement",
                module="strategy_enhancement_engine",
                class_name="StrategyEnhancementEngine",
                dependencies=["strategy_optimizer"],
                category="ml_optimization",
                required=False
            ),
            
            # Master Systems
            ComponentConfig()
                name="master_orchestrator",
                module="master_orchestrator",
                class_name="MasterOrchestrator",
                dependencies=["ai_hft_system", "options_trader", "arbitrage_scanner"],
                category="master_systems",
                required=False
            ),
            ComponentConfig()
                name="master_integration",
                module="MASTER_INTEGRATION_SYSTEM",
                class_name="MasterIntegrationSystem",
                dependencies=["master_orchestrator"],
                category="master_systems",
                required=False
            ),
            
            # Production Systems
            ComponentConfig()
                name="production_trading",
                module="PRODUCTION_TRADING_SYSTEM_FINAL",
                class_name="ProductionTradingSystem",
                dependencies=["master_integration"],
                category="production",
                required=False
            ),
            ComponentConfig()
                name="production_ml_system",
                module="PRODUCTION_MINIO_ML_TRADING_SYSTEM",
                class_name="MinioMLTradingSystem",
                dependencies=["minio_pipeline", "ml_trading_pipeline"],
                category="production",
                required=False
            ),
            
            # Paper Trading Systems
            ComponentConfig()
                name="paper_trading_system",
                module="alpaca_paper_trading_system",
                class_name="AlpacaPaperTradingSystem",
                dependencies=["alpaca_client"],
                category="paper_trading",
                required=False
            ),
            ComponentConfig()
                name="paper_trading_bot",
                module="paper_trading_bot",
                class_name="PaperTradingBot",
                dependencies=["paper_trading_system"],
                category="paper_trading",
                required=False
            ),
            
            # Infrastructure Support
            ComponentConfig()
                name="health_check_system",
                module="health_check_system",
                class_name="HealthCheckSystem",
                dependencies=["health_monitor"],
                category="infrastructure",
                required=False
            ),
            ComponentConfig()
                name="recovery_system",
                module="automated_recovery_system",
                class_name="AutomatedRecoverySystem",
                dependencies=["health_check_system"],
                category="infrastructure",
                required=False
            ),
            ComponentConfig()
                name="distributed_framework",
                module="distributed_computing_framework",
                class_name="DistributedFramework",
                dependencies=["configuration_manager"],
                category="infrastructure",
                required=False
            ),
        ]
        
        # Create component instances
        for config in all_components:
            self.components[config.name] = SystemComponent(config=config)
        
        logger.info(f"Initialized {len(self.components)} components across {len(set(c.config.category for c in self.components.values()))} categories")
    
    async def start(self):
        """Start all system components"""
        logger.info("="*80)
        logger.info("STARTING COMPREHENSIVE TRADING SYSTEM")
        logger.info(f"Mode: {self.mode.value}")
        logger.info(f"Total Components: {len(self.components)}")
        logger.info(f"Time: {datetime.now()}")
        logger.info("="*80)
        
        self.running = True
        self.start_time = datetime.now()
        
        try:
            # Create necessary directories
            self._create_directories()
            
            # Perform pre-flight checks
            if not await self._preflight_checks():
                raise RuntimeError("Pre-flight checks failed")
            
            # Start components by category and dependency order
            await self._start_components_ordered()
            
            # Start monitoring
            self._start_monitoring()
            
            # Display system status
            self._display_system_status()
            
            logger.info("\n✅ COMPREHENSIVE SYSTEM STARTUP COMPLETE\n")
            logger.info("System is running. Press Ctrl+C to shutdown.")
            
            # Keep running until shutdown
            await self.shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"System startup failed: {e}")
            logger.error(traceback.format_exc())
            await self.shutdown()
            raise
    
    def _create_directories(self):
        """Create necessary directories"""
        directories = []
            'logs', 'data', 'models', 'cache', 'config',
            'backtest_results', 'monitoring', 'reports',
            'data/historical', 'data/realtime', 'data/processed'
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
        
        logger.info("Created necessary directories")
    
    async def _preflight_checks(self) -> bool:
        """Perform system pre-flight checks"""
        logger.info("\nPerforming pre-flight checks...")
        
        checks_passed = True
        
        # Check Python version
        py_version = sys.version_info
        if py_version.major >= 3 and py_version.minor >= 8:
            logger.info("  Python version: ✅ PASS")
        else:
            logger.error(f"  Python version: ❌ FAIL (Need 3.8+, got {py_version.major}.{py_version.minor})")
            checks_passed = False
        
        # Check system resources
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        logger.info(f"    CPU: {cpu_percent}%, Memory: {memory.percent}%, Disk: {disk.percent}%")
        
        if cpu_percent < 90 and memory.percent < 90 and disk.percent < 95:
            logger.info("  System resources: ✅ PASS")
        else:
            logger.error("  System resources: ❌ FAIL (Insufficient resources)")
            checks_passed = False
        
        # Check network connectivity
        try:
            response = requests.get('https://api.alpaca.markets/v2/clock', timeout=5)
            if response.status_code == 200:
                logger.info("  Network connectivity: ✅ PASS")
            else:
                logger.warning("  Network connectivity: ⚠️  WARNING (API returned status {response.status_code})")
                # Don't fail - allow offline mode
        except Exception as e:
            logger.warning(f"  Network connectivity: ⚠️  WARNING ({e}) - Running in offline mode")
            # Don't fail - allow offline mode
        
        # Check GPU availability (optional)
        try:
            import torch
            if torch.cuda.is_available():
                logger.info(f"  GPU available: ✅ PASS ({torch.cuda.device_count()} GPUs)")
            else:
                logger.info("  GPU available: ⚠️  WARNING (No GPU detected, GPU components will run in CPU mode)")
        except ImportError:
            logger.info("  GPU available: ⚠️  WARNING (PyTorch not installed)")
        
        return checks_passed
    
    async def _start_components_ordered(self):
        """Start components in dependency order"""
        logger.info("\nStarting system components...")
        
        # Get components by category order
        category_order = []
            "infrastructure",
            "trading_core", 
            "data_pipeline",
            "risk",
            "ai_core",
            "ml_pipeline",
            "ml_models",
            "analysis",
            "options",
            "arbitrage",
            "bots",
            "engines",
            "monitoring",
            "gpu",
            "backtesting",
            "ml_optimization",
            "paper_trading",
            "master_systems",
            "production"
        ]
        
        started_components = set()
        total_components = len(self.components)
        started_count = 0
        
        for category in category_order:
            category_components = []
                name for name, comp in self.components.items() 
                if comp.config.category == category
            ]
            
            if category_components:
                logger.info(f"\n--- Starting {category.upper()} components ---")
                
                for component_name in category_components:
                    if component_name not in started_components:
                        success = await self._start_component_with_deps()
                            component_name, 
                            started_components
                        )
                        if success:
                            started_count += 1
                            logger.info(f"Progress: {started_count}/{total_components} components started")
        
        # Start any remaining components
        remaining = set(self.components.keys()) - started_components
        if remaining:
            logger.info(f"\n--- Starting remaining components ---")
            for component_name in remaining:
                success = await self._start_component_with_deps()
                    component_name,
                    started_components
                )
                if success:
                    started_count += 1
                    logger.info(f"Progress: {started_count}/{total_components} components started")
        
        logger.info(f"\n✅ Started {len(started_components)} out of {total_components} components")
        
        # Log failed components
        failed = [name for name, comp in self.components.items()]
                 if comp.state == ComponentState.ERROR]
        if failed:
            logger.warning(f"⚠️  Failed to start {len(failed)} components: {', '.join(failed)}")
    
    async def _start_component_with_deps(self, component_name: str, 
                                       started_components: Set[str]) -> bool:
        """Start a component and its dependencies"""
        component = self.components[component_name]
        
        # Skip if already started or attempted
        if component_name in started_components:
            return True
        
        # Start dependencies first
        for dep in component.config.dependencies:
            if dep not in started_components and dep in self.components:
                await self._start_component_with_deps(dep, started_components)
        
        # Start the component
        success = await self._start_single_component(component)
        
        if success:
            started_components.add(component_name)
            return True
        else:
            # Mark as attempted even if failed
            started_components.add(component_name)
            return False
    
    async def _start_single_component(self, component: SystemComponent) -> bool:
        """Start a single component"""
        logger.info(f"Starting {component.config.name}...")
        component.state = ComponentState.STARTING
        
        try:
            # Import the module
            module = __import__(component.config.module, fromlist=[component.config.class_name])
            component_class = getattr(module, component.config.class_name)
            
            # Create instance with config overrides
            config = component.config.config_overrides
            
            # Try different initialization patterns
            try:
                # Try with config dict
                instance = component_class(**config)
            except TypeError:
                try:
                    # Try with no args
                    instance = component_class()
                except TypeError:
                    # Try with minimal args
                    instance = component_class(config=config)
            
            # Start the component if it has a start method
            if hasattr(instance, 'start'):
                await instance.start() if asyncio.iscoroutinefunction(instance.start) else instance.start()
            
            # Apply startup delay if configured
            if component.config.startup_delay > 0:
                await asyncio.sleep(component.config.startup_delay)
            
            component.instance = instance
            component.state = ComponentState.RUNNING
            component.start_time = datetime.now()
            
            logger.info(f"  ✅ {component.config.name} started successfully")
            return True
            
        except Exception as e:
            component.state = ComponentState.ERROR
            component.error = str(e)
            self.metrics['errors_handled'] += 1
            
            if component.config.required:
                logger.error(f"  ❌ {component.config.name} failed to start (REQUIRED): {e}")
                logger.error(traceback.format_exc())
            else:
                logger.warning(f"  ⚠️  {component.config.name} failed to start (optional): {e}")
            
            return False
    
    def _start_monitoring(self):
        """Start monitoring thread"""
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
        logger.info("Started monitoring thread")
    
    async def _monitoring_loop(self):
        """Monitoring loop for health checks and metrics"""
        while self.running:
            try:
                # Perform health checks
                await self._perform_health_checks()
                
                # Update metrics
                self._update_metrics()
                
                # Check for component restarts
                await self._check_component_restarts()
                
                # Log periodic status
                if int(time.time()) % 60 == 0:  # Every minute
                    self._display_system_status()
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(10)
    
    async def _perform_health_checks(self):
        """Perform health checks on all running components"""
        for name, component in self.components.items():
            if component.state == ComponentState.RUNNING:
                try:
                    # Check if component has health check method
                    if hasattr(component.instance, 'health_check'):
                        is_healthy = await component.instance.health_check() \
                            if asyncio.iscoroutinefunction(component.instance.health_check) \
                            else component.instance.health_check()
                        
                        if not is_healthy:
                            component.health_check_failures += 1
                            logger.warning(f"Health check failed for {name}")
                        else:
                            component.health_check_failures = 0
                    
                    # Check HTTP endpoint if configured
                    elif component.config.health_check_endpoint:
                        response = requests.get()
                            component.config.health_check_endpoint,
                            timeout=5
                        )
                        if response.status_code != 200:
                            component.health_check_failures += 1
                            logger.warning(f"Health check failed for {name}")
                        else:
                            component.health_check_failures = 0
                    
                    component.last_health_check = datetime.now()
                    
                except Exception as e:
                    component.health_check_failures += 1
                    logger.error(f"Health check error for {name}: {e}")
    
    async def _check_component_restarts(self):
        """Check and restart failed components if needed"""
        for name, component in self.components.items():
            # Restart if component failed and restart is enabled
            if (component.state == ComponentState.ERROR and)
                component.config.restart_on_failure and
                component.restart_count < 3):
                
                logger.info(f"Attempting to restart {name} (attempt {component.restart_count + 1})")
                component.state = ComponentState.RESTARTING
                
                # Wait before restart
                await asyncio.sleep(5 * (component.restart_count + 1))
                
                # Try to restart
                success = await self._start_single_component(component)
                
                if success:
                    component.restart_count += 1
                    self.metrics['component_restarts'][name] = component.restart_count
                    logger.info(f"Successfully restarted {name}")
                else:
                    logger.error(f"Failed to restart {name}")
            
            # Check if component needs restart due to health check failures
            elif (component.state == ComponentState.RUNNING and)
                  component.health_check_failures > 5 and
                  component.config.restart_on_failure):
                
                logger.warning(f"{name} has failed {component.health_check_failures} health checks, restarting...")
                
                # Stop the component
                await self._stop_component(component)
                
                # Restart
                component.state = ComponentState.RESTARTING
                await asyncio.sleep(5)
                await self._start_single_component(component)
    
    def _update_metrics(self):
        """Update system metrics"""
        # This would normally pull metrics from components
        # For now, just increment some sample metrics
        if self.running:
            self.metrics['opportunities_found'] += int(np.random.random() * 10)
            self.metrics['trades_executed'] += int(np.random.random() * 5)
            self.metrics['pnl'] += np.random.normal(100, 50)
    
    def _display_system_status(self):
        """Display current system status"""
        logger.info("\n" + "="*80)
        logger.info("SYSTEM STATUS")
        logger.info("="*80)
        
        # Component status by category
        categories = {}
        for name, component in self.components.items():
            category = component.config.category
            if category not in categories:
                categories[category] = {"running": 0, "error": 0, "total": 0}
            
            categories[category]["total"] += 1
            if component.state == ComponentState.RUNNING:
                categories[category]["running"] += 1
            elif component.state == ComponentState.ERROR:
                categories[category]["error"] += 1
        
        logger.info("\nComponents by Category:")
        for category, stats in sorted(categories.items()):
            status = f"✅ {stats['running']}/{stats['total']}" if stats['running'] == stats['total'] else \
                    f"⚠️  {stats['running']}/{stats['total']} ({stats['error']} failed)"
            logger.info(f"  {category:25} {status}")
        
        # Overall statistics
        total_running = sum(1 for c in self.components.values() if c.state == ComponentState.RUNNING)
        total_components = len(self.components)
        
        logger.info(f"\nOverall: {total_running}/{total_components} components running")
        
        # Metrics
        logger.info("\nMetrics:")
        if self.start_time:
            uptime = int((datetime.now() - self.start_time).total_seconds())
            logger.info(f"  Uptime: {uptime} seconds")
        logger.info(f"  Opportunities Found: {self.metrics['opportunities_found']}")
        logger.info(f"  Trades Executed: {self.metrics['trades_executed']}")
        logger.info(f"  P&L: ${self.metrics['pnl']:.2f}")
        logger.info(f"  Errors Handled: {self.metrics['errors_handled']}")
        
        # Resource usage
        logger.info("\nResource Usage:")
        logger.info(f"  CPU: {psutil.cpu_percent()}%")
        logger.info(f"  Memory: {psutil.virtual_memory().percent}%")
        logger.info(f"  Disk: {psutil.disk_usage('/').percent}%")
        
        logger.info("="*80 + "\n")
    
    async def shutdown(self):
        """Shutdown all components gracefully"""
        logger.info("\n" + "="*80)
        logger.info("SHUTTING DOWN COMPREHENSIVE SYSTEM")
        logger.info("="*80)
        
        self.running = False
        
        # Stop monitoring
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        
        # Stop components in reverse order
        stopped_count = 0
        total_to_stop = sum(1 for c in self.components.values() 
                          if c.state == ComponentState.RUNNING)
        
        category_order = []
            "production", "master_systems", "paper_trading",
            "ml_optimization", "backtesting", "gpu",
            "monitoring", "engines", "bots", "arbitrage",
            "options", "analysis", "ml_models", "ml_pipeline",
            "ai_core", "risk", "data_pipeline", "trading_core",
            "infrastructure"
        ]
        
        for category in category_order:
            category_components = []
                (name, comp) for name, comp in self.components.items()
                if comp.config.category == category and comp.state == ComponentState.RUNNING
            ]
            
            if category_components:
                logger.info(f"\n--- Stopping {category.upper()} components ---")
                
                for name, component in category_components:
                    await self._stop_component(component)
                    stopped_count += 1
                    logger.info(f"  ✅ {name} stopped ({stopped_count}/{total_to_stop})")
        
        # Final metrics
        logger.info("\nFinal System Metrics:")
        if self.start_time:
            runtime = int((datetime.now() - self.start_time).total_seconds())
            logger.info(f"  Total Runtime: {runtime} seconds")
        logger.info(f"  Total Opportunities: {self.metrics['opportunities_found']}")
        logger.info(f"  Total Trades: {self.metrics['trades_executed']}")
        logger.info(f"  Final P&L: ${self.metrics['pnl']:.2f}")
        logger.info(f"  Total Errors: {self.metrics['errors_handled']}")
        logger.info(f"  Component Restarts: {self.metrics['component_restarts']}")
        
        logger.info("\n✅ SHUTDOWN COMPLETE\n")
        self.shutdown_event.set()
    
    async def _stop_component(self, component: SystemComponent):
        """Stop a single component"""
        try:
            if component.instance and hasattr(component.instance, 'stop'):
                await component.instance.stop() \
                    if asyncio.iscoroutinefunction(component.instance.stop) \
                    else component.instance.stop()
            
            component.state = ComponentState.STOPPED
            component.instance = None
            
        except Exception as e:
            logger.error(f"Error stopping {component.config.name}: {e}")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"\nReceived signal {signum}. Starting graceful shutdown...")
        asyncio.create_task(self.shutdown())
    
    def get_component_status(self) -> Dict[str, Dict]:
        """Get status of all components"""
        status = {}
        for name, component in self.components.items():
            status[name] = {}
                'state': component.state.value,
                'category': component.config.category,
                'required': component.config.required,
                'uptime': str(datetime.now() - component.start_time) if component.start_time else None,
                'restart_count': component.restart_count,
                'health_check_failures': component.health_check_failures,
                'error': component.error
            }
        return status

async def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Comprehensive Trading System Launcher')
    parser.add_argument('--mode', type=str, choices=['paper', 'live', 'backtest', 'research'],
                       default='paper', help='Trading mode')
    parser.add_argument('--config', type=str, help='Path to configuration file')
    parser.add_argument('--categories', type=str, nargs='+', 
                       help='Specific categories to start (e.g., ai_core options)')
    parser.add_argument('--exclude-categories', type=str, nargs='+',
                       help='Categories to exclude')
    parser.add_argument('--required-only', action='store_true',
                       help='Start only required components')
    parser.add_argument('--status-port', type=int, default=8080,
                       help='Port for status API')
    
    args = parser.parse_args()
    
    # Create launcher
    mode = TradingMode.PAPER if args.mode == 'paper' else \
           TradingMode.LIVE if args.mode == 'live' else \
           TradingMode.BACKTEST if args.mode == 'backtest' else \
           TradingMode.RESEARCH
    
    launcher = ComprehensiveSystemLauncher(mode=mode, config_path=args.config)
    
    # Filter components if specified
    if args.categories:
        launcher.components = {}
            name: comp for name, comp in launcher.components.items()
            if comp.config.category in args.categories
        }
        logger.info(f"Filtered to categories: {args.categories}")
    
    if args.exclude_categories:
        launcher.components = {}
            name: comp for name, comp in launcher.components.items()
            if comp.config.category not in args.exclude_categories
        }
        logger.info(f"Excluded categories: {args.exclude_categories}")
    
    if args.required_only:
        launcher.components = {}
            name: comp for name, comp in launcher.components.items()
            if comp.config.required
        }
        logger.info("Starting only required components")
    
    try:
        await launcher.start()
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.error(f"System error: {e}")
        logger.error(traceback.format_exc())
    finally:
        await launcher.shutdown()

if __name__ == "__main__":
    # Create event loop and run
    try:
        asyncio.run(main())
    except RuntimeError as e:
        if "cannot be called from a running event loop" not in str(e):
            raise
        # Handle Jupyter notebook environment
        loop = asyncio.get_event_loop()
        loop.run_until_complete(main())