#!/usr/bin/env python3
"""
Low-Latency Inference Endpoint for Options Trading
==================================================
High-performance inference service optimized for ultra-low latency
model serving with support for batching, caching, and hardware acceleration.
"""

import asyncio
import time
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass, field
from collections import deque
import threading
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor
import logging
import json
import pickle
import lmdb
import redis
import msgpack
import pyarrow as pa
import pyarrow.plasma as plasma
from numba import jit, cuda
import tensorrt as trt
import onnx
import onnxruntime as ort
from tritonclient.grpc import InferenceServerClient, InferInput, InferRequestedOutput
import grpc
from grpc import aio
import uvloop
import aiohttp
from aiohttp import web
import prometheus_client
from prometheus_client import Counter, Histogram, Gauge

# Internal imports
from unified_logging import get_logger
# TODO: Review handle_errors usage - available decorators are: retry, circuit_breaker, timeout
# from unified_error_handling import retry, circuit_breaker, timeout, ErrorCategory, ErrorSeverity

logger = get_logger(__name__)

# Set up uvloop for better async performance
asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())


@dataclass
class InferenceConfig:
    """Configuration for low-latency inference"""
    # Model settings
    model_path: str
    model_type: str = "pytorch"  # pytorch, onnx, tensorrt
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    
    # Batching
    max_batch_size: int = 64
    batch_timeout_us: int = 1000  # 1ms
    dynamic_batching: bool = True
    
    # Caching
    enable_cache: bool = True
    cache_type: str = "redis"  # redis, lmdb, plasma
    cache_size_gb: float = 4.0
    cache_ttl_seconds: int = 300
    
    # Performance
    num_workers: int = 4
    num_threads: int = 8
    use_tensorrt: bool = True
    use_fp16: bool = True
    use_int8: bool = False
    
    # Network
    grpc_port: int = 8001
    http_port: int = 8000
    max_message_size: int = 100 * 1024 * 1024  # 100MB
    
    # Monitoring
    enable_metrics: bool = True
    metrics_port: int = 9090
    
    # Hardware optimization
    pin_memory: bool = True
    cuda_graphs: bool = True
    torch_compile: bool = True
    numa_node: Optional[int] = None


@dataclass
class InferenceRequest:
    """Single inference request"""
    request_id: str
    features: np.ndarray
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    priority: int = 0
    timeout_ms: Optional[float] = None


@dataclass
class InferenceResponse:
    """Inference response"""
    request_id: str
    predictions: np.ndarray
    latency_ms: float
    model_version: str
    cached: bool = False
    batch_size: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)


class ModelOptimizer:
    """Optimize models for low-latency inference"""
    
    def __init__(self, config: InferenceConfig):
        self.config = config
        self.trt_logger = trt.Logger(trt.Logger.WARNING)
        
    def optimize_pytorch_model(self, model: nn.Module) -> nn.Module:
        """Optimize PyTorch model"""
        model.eval()
        
        # Move to device
        model = model.to(self.config.device)
        
        # Torch compile for faster inference
        if self.config.torch_compile and hasattr(torch, 'compile'):
            model = torch.compile(model, mode="reduce-overhead")
        
        # Enable cuDNN autotuner
        if self.config.device == "cuda":
            torch.backends.cudnn.benchmark = True
            torch.backends.cudnn.deterministic = False
        
        # Half precision
        if self.config.use_fp16:
            model = model.half()
        
        return model
    
    def convert_to_tensorrt(self, model: nn.Module, input_shape: Tuple[int, ...]) -> Any:
        """Convert PyTorch model to TensorRT"""
        # Export to ONNX first
        dummy_input = torch.randn(1, *input_shape[1:]).to(self.config.device)
        onnx_path = f"{self.config.model_path}.onnx"
        
        torch.onnx.export()
            model,
            dummy_input,
            onnx_path,
            export_params=True,
            opset_version=11,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['output'],
            dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}}
        )
        
        # Build TensorRT engine
        builder = trt.Builder(self.trt_logger)
        network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
        parser = trt.OnnxParser(network, self.trt_logger)
        
        with open(onnx_path, 'rb') as f:
            parser.parse(f.read())
        
        config = builder.create_builder_config()
        config.max_workspace_size = 1 << 30  # 1GB
        
        if self.config.use_fp16:
            config.set_flag(trt.BuilderFlag.FP16)
        if self.config.use_int8:
            config.set_flag(trt.BuilderFlag.INT8)
        
        # Dynamic shapes
        profile = builder.create_optimization_profile()
        profile.set_shape()
            'input',
            (1, *input_shape[1:]),  # min
            (self.config.max_batch_size // 2, *input_shape[1:]),  # opt
            (self.config.max_batch_size, *input_shape[1:])  # max
        )
        config.add_optimization_profile(profile)
        
        # Build engine
        engine = builder.build_engine(network, config)
        
        return engine
    
    def optimize_onnx_model(self, model_path: str) -> ort.InferenceSession:
        """Optimize ONNX model for inference"""
        # Session options
        sess_options = ort.SessionOptions()
        sess_options.intra_op_num_threads = self.config.num_threads
        sess_options.execution_mode = ort.ExecutionMode.ORT_PARALLEL
        sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        # Providers
        providers = []
        if self.config.device == "cuda":
            providers.append(('CUDAExecutionProvider', {))
                'device_id': 0,
                'arena_extend_strategy': 'kNextPowerOfTwo',
                'gpu_mem_limit': 2 * 1024 * 1024 * 1024,  # 2GB
                'cudnn_conv_algo_search': 'EXHAUSTIVE',
                'do_copy_in_default_stream': True,
            }))
        providers.append('CPUExecutionProvider')
        
        # Create session
        session = ort.InferenceSession(model_path, sess_options, providers=providers)
        
        return session


class DynamicBatcher:
    """Dynamic batching for inference requests"""
    
    def __init__(self, config: InferenceConfig):
        self.config = config
        self.queue: deque[InferenceRequest] = deque()
        self.lock = threading.Lock()
        self.condition = threading.Condition(self.lock)
        self.last_batch_time = time.time()
        
    def add_request(self, request: InferenceRequest) -> None:
        """Add request to batch queue"""
        with self.lock:
            self.queue.append(request)
            self.condition.notify()
    
    def get_batch(self) -> Optional[List[InferenceRequest]]:
        """Get batch of requests"""
        with self.lock:
            # Wait for requests or timeout
            while len(self.queue) == 0:
                timeout = self.config.batch_timeout_us / 1_000_000  # Convert to seconds
                if not self.condition.wait(timeout):
                    # Timeout reached
                    if len(self.queue) > 0:
                        break
                    return None
            
            # Check if we should form a batch
            current_time = time.time()
            time_since_last = (current_time - self.last_batch_time) * 1_000_000  # Convert to microseconds
            
            if len(self.queue) >= self.config.max_batch_size or time_since_last >= self.config.batch_timeout_us:
                # Form batch
                batch_size = min(len(self.queue), self.config.max_batch_size)
                batch = [self.queue.popleft() for _ in range(batch_size)]
                self.last_batch_time = current_time
                return batch
            
            return None


class InferenceCache:
    """High-performance inference cache"""
    
    def __init__(self, config: InferenceConfig):
        self.config = config
        self.cache = self._init_cache()
        
        # Metrics
        self.hits = 0
        self.misses = 0
        
    def _init_cache(self) -> Any:
        """Initialize cache backend"""
        if self.config.cache_type == "redis":
            return redis.Redis()
                host='localhost',
                port=6379,
                decode_responses=False,
                socket_keepalive=True,
                socket_keepalive_options={}
            )
        elif self.config.cache_type == "lmdb":
            env = lmdb.open()
                '/tmp/inference_cache',
                map_size=int(self.config.cache_size_gb * 1024 * 1024 * 1024),
                max_dbs=1,
                writemap=True,
                map_async=True,
                metasync=False
            )
            return env
        elif self.config.cache_type == "plasma":
            # Connect to Plasma store
            client = plasma.connect("/tmp/plasma")
            return client
        else:
            raise ValueError(f"Unknown cache type: {self.config.cache_type}")
    
    def get(self, key: str) -> Optional[np.ndarray]:
        """Get cached prediction"""
        try:
            if self.config.cache_type == "redis":
                data = self.cache.get(key)
                if data:
                    self.hits += 1
                    return msgpack.unpackb(data, raw=False)
            elif self.config.cache_type == "lmdb":
                with self.cache.begin() as txn:
                    data = txn.get(key.encode())
                    if data:
                        self.hits += 1
                        return pickle.loads(data)
            elif self.config.cache_type == "plasma":
                obj_id = plasma.ObjectID(key.encode()[:20].ljust(20, b'\0'))
                if self.cache.contains(obj_id):
                    self.hits += 1
                    return self.cache.get(obj_id)
            
            self.misses += 1
            return None
            
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            return None
    
    def put(self, key: str, value: np.ndarray) -> None:
        """Cache prediction"""
        try:
            if self.config.cache_type == "redis":
                data = msgpack.packb(value.tolist())
                self.cache.setex(key, self.config.cache_ttl_seconds, data)
            elif self.config.cache_type == "lmdb":
                with self.cache.begin(write=True) as txn:
                    txn.put(key.encode(), pickle.dumps(value))
            elif self.config.cache_type == "plasma":
                obj_id = plasma.ObjectID(key.encode()[:20].ljust(20, b'\0'))
                self.cache.put(value, obj_id)
                
        except Exception as e:
            logger.error(f"Cache put error: {e}")
    
    def get_hit_rate(self) -> float:
        """Get cache hit rate"""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0


class LowLatencyInferenceServer:
    """Ultra low-latency inference server"""
    
    def __init__(self, config: InferenceConfig):
        self.config = config
        
        # Components
        self.optimizer = ModelOptimizer(config)
        self.batcher = DynamicBatcher(config)
        self.cache = InferenceCache(config) if config.enable_cache else None
        
        # Model
        self.model = None
        self.model_lock = threading.Lock()
        self.model_version = "1.0.0"
        
        # Workers
        self.executor = ThreadPoolExecutor(max_workers=config.num_workers)
        self.batch_processor = None
        
        # Metrics
        self._init_metrics()
        
        # State
        self.running = False
        
    def _init_metrics(self):
        """Initialize Prometheus metrics"""
        self.inference_counter = Counter()
            'inference_requests_total',
            'Total number of inference requests'
        )
        self.inference_latency = Histogram()
            'inference_latency_milliseconds',
            'Inference latency in milliseconds',
            buckets=(0.1, 0.5, 1, 2, 5, 10, 20, 50, 100)
        )
        self.batch_size_histogram = Histogram()
            'inference_batch_size',
            'Batch size for inference',
            buckets=(1, 2, 4, 8, 16, 32, 64)
        )
        self.cache_hit_rate = Gauge()
            'inference_cache_hit_rate',
            'Cache hit rate'
        )
        self.model_load_time = Gauge()
            'model_load_time_seconds',
            'Model loading time in seconds'
        )
        
    async def load_model(self, model_path: str) -> None:
        """Load and optimize model"""
        start_time = time.time()
        
        with self.model_lock:
            if self.config.model_type == "pytorch":
                # Load PyTorch model
                model = torch.load(model_path, map_location=self.config.device)
                self.model = self.optimizer.optimize_pytorch_model(model)
                
            elif self.config.model_type == "onnx":
                # Load ONNX model
                self.model = self.optimizer.optimize_onnx_model(model_path)
                
            elif self.config.model_type == "tensorrt":
                # Load or convert to TensorRT
                if model_path.endswith('.engine'):
                    # Load existing engine
                    with open(model_path, 'rb') as f:
                        self.model = trt.Runtime(self.optimizer.trt_logger).deserialize_cuda_engine(f.read())
                else:
                    # Convert PyTorch model
                    pytorch_model = torch.load(model_path)
                    input_shape = (self.config.max_batch_size, 256)  # Adjust based on your model
                    self.model = self.optimizer.convert_to_tensorrt(pytorch_model, input_shape)
        
        load_time = time.time() - start_time
        self.model_load_time.set(load_time)
        logger.info(f"Model loaded in {load_time:.2f} seconds")
    
    @torch.cuda.nvtx.range("inference")
    def _run_inference(self, features: np.ndarray) -> np.ndarray:
        """Run model inference"""
        with self.model_lock:
            if self.config.model_type == "pytorch":
                with torch.no_grad():
                    # Move to device
                    x = torch.from_numpy(features).to(self.config.device)
                    if self.config.use_fp16:
                        x = x.half()
                    
                    # Pin memory for faster transfer
                    if self.config.pin_memory and self.config.device == "cuda":
                        x = x.pin_memory()
                    
                    # Run inference
                    if self.config.cuda_graphs and self.config.device == "cuda":
                        # Use CUDA graphs for lower latency
                        if not hasattr(self, '_cuda_graph'):
                            self._cuda_graph = torch.cuda.CUDAGraph()
                            with torch.cuda.graph(self._cuda_graph):
                                output = self.model(x)
                        else:
                            output = self._cuda_graph.replay()
                    else:
                        output = self.model(x)
                    
                    return output.cpu().numpy()
                    
            elif self.config.model_type == "onnx":
                # Run ONNX inference
                input_name = self.model.get_inputs()[0].name
                output = self.model.run(None, {input_name: features})
                return output[0]
                
            elif self.config.model_type == "tensorrt":
                # Run TensorRT inference
                context = self.model.create_execution_context()
                
                # Allocate buffers
                inputs, outputs, bindings = [], [], []
                for binding in self.model:
                    size = trt.volume(self.model.get_binding_shape(binding)) * features.shape[0]
                    dtype = trt.nptype(self.model.get_binding_dtype(binding))
                    
                    # Allocate host and device buffers
                    host_mem = cuda.pagelocked_empty(size, dtype)
                    device_mem = cuda.mem_alloc(host_mem.nbytes)
                    
                    bindings.append(int(device_mem))
                    
                    if self.model.binding_is_input(binding):
                        inputs.append((host_mem, device_mem))
                    else:
                        outputs.append((host_mem, device_mem))
                
                # Transfer input data
                np.copyto(inputs[0][0], features.ravel())
                cuda.memcpy_htod(inputs[0][1], inputs[0][0])
                
                # Run inference
                context.execute(batch_size=features.shape[0], bindings=bindings)
                
                # Transfer output data
                cuda.memcpy_dtoh(outputs[0][0], outputs[0][1])
                
                return outputs[0][0].reshape(features.shape[0], -1)
    
    async def _process_batch(self) -> None:
        """Process batched requests"""
        while self.running:
            try:
                # Get batch
                batch = self.batcher.get_batch()
                if not batch:
                    await asyncio.sleep(0.0001)  # 100us
                    continue
                
                # Extract features
                batch_features = np.vstack([req.features for req in batch])
                batch_size = len(batch)
                
                # Check cache for each request
                cached_indices = []
                cached_results = {}
                
                if self.cache:
                    for i, req in enumerate(batch):
                        cache_key = f"{req.metadata.get('symbol', '')}:{req.features.tobytes()}"
                        cached = self.cache.get(cache_key)
                        if cached is not None:
                            cached_indices.append(i)
                            cached_results[i] = cached
                
                # Process uncached requests
                if len(cached_indices) < batch_size:
                    # Get uncached indices
                    uncached_indices = [i for i in range(batch_size) if i not in cached_indices]
                    uncached_features = batch_features[uncached_indices]
                    
                    # Run inference
                    start_time = time.time()
                    predictions = await asyncio.get_event_loop().run_in_executor()
                        self.executor,
                        self._run_inference,
                        uncached_features
                    )
                    inference_time = (time.time() - start_time) * 1000
                    
                    # Update metrics
                    self.inference_latency.observe(inference_time)
                    self.batch_size_histogram.observe(len(uncached_indices))
                    
                    # Cache results
                    if self.cache:
                        for i, idx in enumerate(uncached_indices):
                            req = batch[idx]
                            cache_key = f"{req.metadata.get('symbol', '')}:{req.features.tobytes()}"
                            self.cache.put(cache_key, predictions[i])
                    
                    # Combine results
                    all_predictions = np.zeros((batch_size, predictions.shape[1]))
                    for i, idx in enumerate(uncached_indices):
                        all_predictions[idx] = predictions[i]
                    for idx, cached in cached_results.items():
                        all_predictions[idx] = cached
                else:
                    # All cached
                    all_predictions = np.vstack([cached_results[i] for i in range(batch_size)])
                    inference_time = 0.1  # Minimal time for cache hits
                
                # Send responses
                for i, req in enumerate(batch):
                    response = InferenceResponse()
                        request_id=req.request_id,
                        predictions=all_predictions[i],
                        latency_ms=inference_time / len(batch),
                        model_version=self.model_version,
                        cached=(i in cached_indices),
                        batch_size=batch_size
                    )
                    
                    # Send response (would be implemented based on transport)
                    await self._send_response(req, response)
                
                # Update cache metrics
                if self.cache:
                    self.cache_hit_rate.set(self.cache.get_hit_rate())
                
            except Exception as e:
                logger.error(f"Batch processing error: {e}")
                await asyncio.sleep(0.001)
    
    async def _send_response(self, request: InferenceRequest, response: InferenceResponse) -> None:
        """Send response to client"""
        # Implementation depends on transport (gRPC, HTTP, etc.)
        # This is a placeholder
        self.inference_counter.inc()
    
    async def start(self) -> None:
        """Start inference server"""
        self.running = True
        
        # Start batch processor
        self.batch_processor = asyncio.create_task(self._process_batch())
        
        # Start gRPC server
        if self.config.grpc_port:
            await self._start_grpc_server()
        
        # Start HTTP server
        if self.config.http_port:
            await self._start_http_server()
        
        # Start metrics server
        if self.config.enable_metrics:
            prometheus_client.start_http_server(self.config.metrics_port)
        
        logger.info("Low-latency inference server started")
    
    async def stop(self) -> None:
        """Stop inference server"""
        self.running = False
        
        if self.batch_processor:
            self.batch_processor.cancel()
            await asyncio.gather(self.batch_processor, return_exceptions=True)
        
        self.executor.shutdown(wait=True)
        
        logger.info("Low-latency inference server stopped")
    
    async def _start_grpc_server(self) -> None:
        """Start gRPC server for inference"""
        # Implement gRPC service
        # This is a placeholder for the actual implementation
        pass
    
    async def _start_http_server(self) -> None:
        """Start HTTP server for inference"""
        app = web.Application()
        app.router.add_post('/v1/models/{model_name}/infer', self._handle_http_inference)
        app.router.add_get('/health', self._handle_health_check)
        app.router.add_get('/metrics', self._handle_metrics)
        
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, '0.0.0.0', self.config.http_port)
        await site.start()
    
    async def _handle_http_inference(self, request: web.Request) -> web.Response:
        """Handle HTTP inference request"""
        try:
            data = await request.json()
            
            # Create inference request
            inf_request = InferenceRequest()
                request_id=data.get('id', str(time.time())),
                features=np.array(data['inputs']),
                metadata=data.get('metadata', {})
            )
            
            # Add to batch queue
            self.batcher.add_request(inf_request)
            
            # Wait for response (in production, use async response)
            # This is simplified for demonstration
            await asyncio.sleep(0.01)  # Simulate wait
            
            return web.json_response({)
                'id': inf_request.request_id,
                'model_name': request.match_info['model_name'],
                'model_version': self.model_version,
                'outputs': [[1.0, 2.0, 3.0, 4.0, 5.0]]  # Placeholder
            })
            
        except Exception as e:
            return web.json_response({'error': str(e)}, status=400)
    
    async def _handle_health_check(self, request: web.Request) -> web.Response:
        """Handle health check"""
        return web.json_response({)
            'status': 'healthy',
            'model_loaded': self.model is not None,
            'cache_enabled': self.cache is not None,
            'uptime': time.time()
        })
    
    async def _handle_metrics(self, request: web.Request) -> web.Response:
        """Handle metrics request"""
        metrics = {}
            'total_requests': self.inference_counter._value._value,
            'cache_hit_rate': self.cache.get_hit_rate() if self.cache else 0,
            'model_version': self.model_version
        }
        return web.json_response(metrics)


# GPU Optimization utilities
class GPUOptimizer:
    """GPU-specific optimizations"""
    
    @staticmethod
    def set_gpu_flags():
        """Set optimal GPU flags"""
        # Enable TF32 for Ampere GPUs
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        
        # Set memory fraction
        torch.cuda.set_per_process_memory_fraction(0.8)
        
        # Enable async execution
        torch.cuda.set_stream(torch.cuda.Stream())
    
    @staticmethod
    @jit
    def preprocess_features_cuda(features: np.ndarray) -> np.ndarray:
        """GPU-accelerated preprocessing"""
        # Normalize features
        mean = features.mean(axis=1, keepdims=True)
        std = features.std(axis=1, keepdims=True) + 1e-8
        return (features - mean) / std
    
    @staticmethod
    def optimize_kernel_launch(batch_size: int) -> Tuple[int, int]:
        """Calculate optimal kernel launch parameters"""
        # Get GPU properties
        device = torch.cuda.current_device()
        props = torch.cuda.get_device_properties(device)
        
        # Calculate optimal block and grid sizes
        threads_per_block = min(batch_size, props.max_threads_per_block)
        blocks_per_grid = (batch_size + threads_per_block - 1) // threads_per_block
        
        return blocks_per_grid, threads_per_block


# Triton Inference Server Client
class TritonInferenceClient:
    """Client for NVIDIA Triton Inference Server"""
    
    def __init__(self, url: str = "localhost:8001", model_name: str = "options_model"):
        self.client = InferenceServerClient(url)
        self.model_name = model_name
        
    async def infer(self, features: np.ndarray) -> np.ndarray:
        """Run inference via Triton"""
        # Create input tensor
        inputs = []
        inputs.append(InferInput('input', features.shape, "FP32"))
        inputs[0].set_data_from_numpy(features.astype(np.float32))
        
        # Create output request
        outputs = []
        outputs.append(InferRequestedOutput('output'))
        
        # Run inference
        response = await asyncio.get_event_loop().run_in_executor()
            None,
            self.client.infer,
            self.model_name,
            inputs,
            outputs=outputs
        )
        
        # Get results
        return response.as_numpy('output')
    
    def get_model_metadata(self) -> Dict[str, Any]:
        """Get model metadata"""
        return self.client.get_model_metadata(self.model_name)
    
    def is_model_ready(self) -> bool:
        """Check if model is ready"""
        return self.client.is_model_ready(self.model_name)


# Benchmarking utilities
class InferenceBenchmark:
    """Benchmark inference performance"""
    
    def __init__(self, server: LowLatencyInferenceServer):
        self.server = server
        self.results = []
        
    async def run_benchmark()
        self,
        num_requests: int = 10000,
        batch_sizes: List[int] = [1, 8, 16, 32, 64],
        feature_dim: int = 256
    ) -> Dict[str, Any]:
        """Run comprehensive benchmark"""
        logger.info(f"Starting benchmark: {num_requests} requests")
        
        results = {}
        
        for batch_size in batch_sizes:
            logger.info(f"Testing batch size: {batch_size}")
            
            # Generate test data
            features = np.random.randn(num_requests, feature_dim).astype(np.float32)
            
            # Warmup
            for _ in range(100):
                await self._send_request(features[:batch_size])
            
            # Benchmark
            latencies = []
            start_time = time.time()
            
            for i in range(0, num_requests, batch_size):
                batch = features[i:i+batch_size]
                req_start = time.time()
                
                # Send request
                request = InferenceRequest()
                    request_id=f"bench_{i}",
                    features=batch
                )
                self.server.batcher.add_request(request)
                
                # Measure latency
                latency = (time.time() - req_start) * 1000
                latencies.append(latency)
            
            total_time = time.time() - start_time
            throughput = num_requests / total_time
            
            # Calculate statistics
            results[f"batch_{batch_size}"] = {}
                'throughput_qps': throughput,
                'avg_latency_ms': np.mean(latencies),
                'p50_latency_ms': np.percentile(latencies, 50),
                'p95_latency_ms': np.percentile(latencies, 95),
                'p99_latency_ms': np.percentile(latencies, 99),
                'min_latency_ms': np.min(latencies),
                'max_latency_ms': np.max(latencies)
            }
        
        return results
    
    async def _send_request(self, features: np.ndarray) -> None:
        """Send single inference request"""
        request = InferenceRequest()
            request_id=f"warmup_{time.time()}",
            features=features
        )
        self.server.batcher.add_request(request)
        await asyncio.sleep(0.001)
    
    def print_results(self, results: Dict[str, Any]) -> None:
        """Print benchmark results"""
        print("\nInference Benchmark Results")
        print("=" * 60)
        
        for batch_size, metrics in results.items():
            print(f"\n{batch_size}:")
            print(f"  Throughput: {metrics['throughput_qps']:.2f} QPS")
            print(f"  Avg Latency: {metrics['avg_latency_ms']:.2f} ms")
            print(f"  P50 Latency: {metrics['p50_latency_ms']:.2f} ms")
            print(f"  P95 Latency: {metrics['p95_latency_ms']:.2f} ms")
            print(f"  P99 Latency: {metrics['p99_latency_ms']:.2f} ms")


# Example usage and demonstration
async def demo_low_latency_inference():
    """Demonstrate low-latency inference"""
    
    # Configuration
    config = InferenceConfig()
        model_path="/models/options_model.pth",
        model_type="pytorch",
        device="cuda" if torch.cuda.is_available() else "cpu",
        max_batch_size=64,
        batch_timeout_us=500,  # 0.5ms
        enable_cache=True,
        cache_type="redis",
        use_tensorrt=torch.cuda.is_available(),
        use_fp16=True
    )
    
    # Set GPU optimizations
    if config.device == "cuda":
        GPUOptimizer.set_gpu_flags()
    
    # Create server
    server = LowLatencyInferenceServer(config)
    
    try:
        # Start server
        await server.start()
        
        print("Low-Latency Inference Server Demo")
        print("=" * 50)
        print(f"Device: {config.device}")
        print(f"Batch Size: {config.max_batch_size}")
        print(f"Batch Timeout: {config.batch_timeout_us} μs")
        print(f"Cache: {config.cache_type if config.enable_cache else 'Disabled'}")
        print(f"FP16: {config.use_fp16}")
        print(f"TensorRT: {config.use_tensorrt}")
        
        # Simulate model (for demo)
        class DemoModel(nn.Module):
            def __init__(self, input_dim=256, output_dim=5):
                super().__init__()
                self.fc1 = nn.Linear(input_dim, 512)
                self.fc2 = nn.Linear(512, 256)
                self.fc3 = nn.Linear(256, output_dim)
                self.relu = nn.ReLU()
                
            def forward(self, x):
                x = self.relu(self.fc1(x))
                x = self.relu(self.fc2(x))
                return self.fc3(x)
        
        # Load demo model
        demo_model = DemoModel()
        if config.device == "cuda":
            demo_model = demo_model.cuda()
        
        # Save and load model
        torch.save(demo_model, "/tmp/demo_model.pth")
        await server.load_model("/tmp/demo_model.pth")
        
        print("\nModel loaded successfully")
        
        # Run single inference
        print("\nRunning single inference...")
        features = np.random.randn(1, 256).astype(np.float32)
        
        request = InferenceRequest()
            request_id="demo_001",
            features=features,
            metadata={'symbol': 'AAPL'}
        )
        
        start_time = time.time()
        server.batcher.add_request(request)
        await asyncio.sleep(0.01)  # Wait for processing
        latency = (time.time() - start_time) * 1000
        
        print(f"Single inference latency: {latency:.2f} ms")
        
        # Run batch inference
        print("\nRunning batch inference...")
        batch_features = np.random.randn(32, 256).astype(np.float32)
        
        requests = []
        for i in range(32):
            req = InferenceRequest()
                request_id=f"batch_{i}",
                features=batch_features[i:i+1]
            )
            requests.append(req)
        
        start_time = time.time()
        for req in requests:
            server.batcher.add_request(req)
        
        await asyncio.sleep(0.02)  # Wait for batch processing
        batch_latency = (time.time() - start_time) * 1000
        
        print(f"Batch inference latency: {batch_latency:.2f} ms for 32 requests")
        print(f"Average per request: {batch_latency/32:.2f} ms")
        
        # Run benchmark
        if input("\nRun full benchmark? (y/n): ").lower() == 'y':
            benchmark = InferenceBenchmark(server)
            results = await benchmark.run_benchmark()
                num_requests=1000,
                batch_sizes=[1, 8, 16, 32],
                feature_dim=256
            )
            benchmark.print_results(results)
        
        # Cache statistics
        if server.cache:
            print(f"\nCache Hit Rate: {server.cache.get_hit_rate():.2%}")
        
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        await server.stop()
        print("\nServer stopped")


if __name__ == "__main__":
    # Check for GPU
    print(f"CUDA Available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    
    print("\nLow-Latency Inference Features:")
    print("- Dynamic batching with microsecond timeout")
    print("- Multi-backend support (PyTorch, ONNX, TensorRT)")
    print("- Hardware acceleration (GPU, FP16, INT8)")
    print("- High-performance caching (Redis, LMDB, Plasma)")
    print("- CUDA graphs for minimal kernel launch overhead")
    print("- Zero-copy memory transfers")
    print("- Triton Inference Server integration")
    print("- Prometheus metrics and monitoring")
    print("- gRPC and HTTP endpoints")
    
    print("\nTarget Performance:")
    print("- Latency: < 1ms P99")
    print("- Throughput: > 100,000 QPS")
    print("- Batch efficiency: > 90% GPU utilization")
    
    # Run demo (requires dependencies)
    # asyncio.run(demo_low_latency_inference())