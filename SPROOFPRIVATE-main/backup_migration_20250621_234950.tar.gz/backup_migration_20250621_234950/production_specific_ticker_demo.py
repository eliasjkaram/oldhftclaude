#!/usr/bin/env python3
"""
Specific Option Ticker Recommendations Demo
==========================================
Shows exact option tickers and expiration dates for trading strategies
"""

import sys
import os
import pandas as pd
import numpy as np

import logging
from datetime import datetime, timedelta

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class SpecificTickerDemo:
    def __init__(self, symbol="SPY", current_price=None)  # Use real price:
    try:
            self.symbol = symbol
            self.current_price = current_price
            self.current_iv = 0.20  # 20% IV
        
        def get_third_friday(self, year, month):
            """Calculate third Friday of month (standard option expiration)"""
            first = datetime(year, month, 1)
            first_friday = first + timedelta(days=(4 - first.weekday() % 7)
            return first_friday + timedelta(days=14)
    
        def get_next_expiration(self, horizon_days=30):
            """Get appropriate expiration based on time horizon"""
            today = datetime.now()
            current_month = today.month
            current_year = today.year
        
            if horizon_days <= 45:
                # Next monthly expiration
                if today.day > 15:  # Past current month's expiration
                    exp_month = current_month + 1 if current_month < 12 else 1
                    exp_year = current_year if current_month < 12 else current_year + 1
                else:
                    exp_month = current_month
                    exp_year = current_year
            elif horizon_days <= 90:
                # 2 months out
                exp_month = current_month + 2 if current_month <= 10 else current_month + 2 - 12
                exp_year = current_year if current_month <= 10 else current_year + 1
            else:
                # LEAPS or 3+ months
                if horizon_days > 180:
                    exp_month = 1  # January LEAPS
                    exp_year = current_year + 1 if current_month < 12 else current_year + 2
                else:
                    exp_month = current_month + 3 if current_month <= 9 else current_month + 3 - 12
                    exp_year = current_year if current_month <= 9 else current_year + 1
        
            expiration_date = self.get_third_friday(exp_year, exp_month)
            return expiration_date
    
        def generate_call_trade(self, horizon_days=30):
            """Generate specific call option trade"""
            exp_date = self.get_next_expiration(horizon_days)
            exp_str = exp_date.strftime("%b %d, %Y")
            exp_code = exp_date.strftime("%y%m%d")
            days_to_exp = (exp_date - datetime.now().days)
        
            # Calculate strike (5% OTM)
            strike = round(self.current_price * 1.05, 0)
            if self.current_price > 100:
                strike = round(strike, 0)
            else:
                strike = round(strike * 2) / 2
        
            # Create option ticker
            strike_str = f"{int(strike):05d}"
            option_ticker = f"{self.symbol}{exp_code}C{strike_str}"
        
            # Estimate premium
            time_value = np.sqrt(days_to_exp / 365) * self.current_iv * self.current_price
            premium = time_value * 0.3
        
            return {}
                'ticker': option_ticker,
                'description': f"{self.symbol} {exp_str} ${strike:.0f} Call",
                'strike': strike,
                'expiration': exp_str,
                'days_to_exp': days_to_exp,
                'premium': premium,
                'current_price': self.current_price
            }
    
        def generate_bull_call_spread(self, horizon_days=30):
            """Generate specific bull call spread"""
            exp_date = self.get_next_expiration(horizon_days)
            exp_str = exp_date.strftime("%b %d, %Y")
            exp_code = exp_date.strftime("%y%m%d")
            days_to_exp = (exp_date - datetime.now().days)
        
            # Calculate strikes
            long_strike = round(self.current_price * 1.02, 0)
            short_strike = round(self.current_price * 1.08, 0)
        
            # Create option tickers
            long_ticker = f"{self.symbol}{exp_code}C{int(long_strike):05d}"
            short_ticker = f"{self.symbol}{exp_code}C{int(short_strike):05d}"
        
            # Estimate premiums
            long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.4
            short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.2
            net_debit = long_premium - short_premium
            max_profit = (short_strike - long_strike) - net_debit
        
            return {}
                'long_ticker': long_ticker,
                'short_ticker': short_ticker,
                'long_description': f"{self.symbol} {exp_str} ${long_strike:.0f} Call",
                'short_description': f"{self.symbol} {exp_str} ${short_strike:.0f} Call",
                'expiration': exp_str,
                'days_to_exp': days_to_exp,
                'net_debit': net_debit,
                'max_profit': max_profit,
                'long_premium': long_premium,
                'short_premium': short_premium
            }
    
        def generate_iron_condor(self, horizon_days=30):
            """Generate specific iron condor trade"""
            exp_date = self.get_next_expiration(horizon_days)
            exp_str = exp_date.strftime("%b %d, %Y")
            exp_code = exp_date.strftime("%y%m%d")
            days_to_exp = (exp_date - datetime.now().days)
        
            # Calculate strikes
            put_short = round(self.current_price * 0.95, 0)
            put_long = round(self.current_price * 0.90, 0)
            call_short = round(self.current_price * 1.05, 0)
            call_long = round(self.current_price * 1.10, 0)
        
            # Create option tickers
            tickers = {}
                'put_short': f"{self.symbol}{exp_code}P{int(put_short):05d}",
                'put_long': f"{self.symbol}{exp_code}P{int(put_long):05d}",
                'call_short': f"{self.symbol}{exp_code}C{int(call_short):05d}",
                'call_long': f"{self.symbol}{exp_code}C{int(call_long):05d}"
            }
        
            # Estimate premiums
            put_short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.25
            put_long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.10
            call_short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.25
            call_long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.10
        
            net_credit = (put_short_premium - put_long_premium) + (call_short_premium - call_long_premium)
        
            return {}
                'tickers': tickers,
                'strikes': {}
                    'put_short': put_short,
                    'put_long': put_long,
                    'call_short': call_short,
                    'call_long': call_long
                },
                'expiration': exp_str,
                'days_to_exp': days_to_exp,
                'net_credit': net_credit,
                'premiums': {}
                    'put_short': put_short_premium,
                    'put_long': put_long_premium,
                    'call_short': call_short_premium,
                    'call_long': call_long_premium
                }
            }

    except Exception as e:
        logger.error(f"Error in __init__: {str(e)}")
        raise

def main():
    try:
        """Demonstrate specific ticker recommendations"""
    
        logger.info("🎯 SPECIFIC OPTION TICKER RECOMMENDATIONS")
        logger.info("=" * 80)
        logger.info()
    
        # Test with multiple symbols - including any user can enter
        symbols = []
            ("SPY", 480.0, "S&P 500 ETF"),
            ("BTC-USD", 65000.0, "Bitcoin USD"),
            ("NVDA", 800.0, "NVIDIA Corporation"),
            ("META", 350.0, "Meta Platforms"),
            ("EXOTIC123", 45.0, "Any Custom Symbol")
        ]
    
        for symbol, price, description in symbols:
            logger.info(f"📊 {symbol} - {description} (Current: ${price:.2f})")
            logger.info("-" * 60)
        
            demo = SpecificTickerDemo(symbol, price)
        
            # 1. Long Call Trade
            call_trade = demo.generate_call_trade(60)  # 60-day horizon
            logger.info(f"📈 LONG CALL RECOMMENDATION:")
            logger.info(f"   Ticker: {call_trade['ticker']}")
            logger.info(f"   Description: {call_trade['description']}")
            logger.info(f"   Expiration: {call_trade['expiration']} ({call_trade['days_to_exp']} days)")
            logger.info(f"   Premium: ~${call_trade['premium']:.2f} per share")
            logger.info()
        
            # 2. Bull Call Spread
            spread_trade = demo.generate_bull_call_spread(45)  # 45-day horizon
            logger.info(f"📊 BULL CALL SPREAD:")
            logger.info(f"   BUY:  {spread_trade['long_ticker']} @ ${spread_trade['long_premium']:.2f}")
            logger.info(f"   SELL: {spread_trade['short_ticker']} @ ${spread_trade['short_premium']:.2f}")
            logger.info(f"   Net Debit: ${spread_trade['net_debit']:.2f}")
            logger.info(f"   Max Profit: ${spread_trade['max_profit']:.2f}")
            logger.info(f"   Expiration: {spread_trade['expiration']}")
            logger.info()
        
            # 3. Iron Condor (for range-bound view)
            condor = demo.generate_iron_condor(35)  # 35-day horizon
            logger.info(f"🦅 IRON CONDOR (Range-Bound):")
            logger.info(f"   SELL: {condor['tickers']['put_short']} @ ${condor['premiums']['put_short']:.2f}")
            logger.info(f"   BUY:  {condor['tickers']['put_long']} @ ${condor['premiums']['put_long']:.2f}")
            logger.info(f"   SELL: {condor['tickers']['call_short']} @ ${condor['premiums']['call_short']:.2f}")
            logger.info(f"   BUY:  {condor['tickers']['call_long']} @ ${condor['premiums']['call_long']:.2f}")
            logger.info(f"   Net Credit: ${condor['net_credit']:.2f}")
            logger.info(f"   Profit Zone: ${condor['strikes']['put_short']:.0f} - ${condor['strikes']['call_short']:.0f}")
            logger.info()
            logger.info("=" * 80)
            logger.info()
    
        logger.info("✅ All recommendations include:")
        logger.info("   • Exact option tickers for broker entry")
        logger.info("   • Standard expiration dates (3rd Friday)")  
        logger.info("   • Strike prices rounded to exchange standards")
        logger.info("   • Estimated premiums based on current IV")
        logger.info("   • Complete trade specifications")
        logger.info()
        logger.info("📋 Next Steps:")
        logger.info("   1. Verify option chain availability in your broker")
        logger.info("   2. Check actual bid/ask spreads for liquidity")
        logger.info("   3. Confirm margin requirements for spreads")
        logger.info("   4. Set up alerts for price targets")
        logger.info("   5. Plan exit strategy before entering trades")

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise
    main()