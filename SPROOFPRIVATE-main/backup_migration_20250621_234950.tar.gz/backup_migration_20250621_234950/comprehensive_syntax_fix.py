#!/usr/bin/env python3
"""Comprehensive syntax fix for all remaining errors"""

import ast
import re
import os

def find_syntax_errors(filename):
    """Find all syntax errors in a file"""
    try:
        with open(filename, 'r') as f:
            content = f.read()
        ast.parse(content)
        return None
    except SyntaxError as e:
        return {}
            'line': e.lineno,
            'offset': e.offset,
            'text': e.text,
            'msg': e.msg
        }

def fix_common_patterns(content):
    """Fix common syntax error patterns"""
    lines = content.split('\n')
    fixed_lines = []
    
    for i, line in enumerate(lines):
        # Fix missing closing parentheses at end of line
        open_count = line.count('(') - line.count(')')
        if open_count > 0 and not line.strip().endswith(':'):
            # Check if it's likely missing a closing parenthesis
            if any(line.strip().endswith(x) for x in [',', '=', '>', '<', '+', '-', '*', '/']):
                line = line.rstrip() + ')' * open_count
        
        # Fix missing closing brackets
        bracket_count = line.count('[') - line.count(']')
        if bracket_count > 0 and not line.strip().endswith(':'):
            line = line.rstrip() + ']' * bracket_count
            
        # Fix missing closing braces
        brace_count = line.count('{') - line.count('}')
        if brace_count > 0 and not line.strip().endswith(':'):
            line = line.rstrip() + '}' * brace_count
            
        fixed_lines.append(line)
    
    return '\n'.join(fixed_lines)

def fix_file(filename):
    """Fix syntax errors in a file"""
    print(f"\nProcessing {filename}...")
    
    # Read the file
    with open(filename, 'r') as f:
        content = f.read()
    
    # Try to fix common patterns
    fixed_content = fix_common_patterns(content)
    
    # Write back if changed
    if fixed_content != content:
        with open(filename, 'w') as f:
            f.write(fixed_content)
        print(f"✓ Fixed common patterns in {filename}")
        
        # Check if still has errors
        error = find_syntax_errors(filename)
        if error:
            print(f"  ⚠️  Still has error on line {error['line']}: {error['msg']}")
            if error['text']:
                print(f"     {error['text'].strip()}")
            return False
        else:
            print(f"  ✓ All syntax errors fixed!")
            return True
    else:
        error = find_syntax_errors(filename)
        if error:
            print(f"✗ Error on line {error['line']}: {error['msg']}")
            if error['text']:
                print(f"   {error['text'].strip()}")
            return False
        else:
            print(f"✓ No syntax errors found")
            return True

# Files to fix
files = []
    'core/paper_trading_simulator.py',
    'multi_agent_trading_system.py',
    'neural_architecture_search_trading.py',
    'options_market_scraper.py',
    'risk_calculator.py',
    'adaptive_bias_strategy_optimizer.py',
    'comprehensive_spread_strategies.py',
    'comprehensive_backtesting_suite.py',
    'monte_carlo_backtesting.py',
    'continuous_backtest_training_system.py',
    'system_health_monitor.py',
    'comprehensive_monitoring_system.py',
    'algorithm_performance_dashboard.py',
    'quantum_inspired_trading.py',
    'swarm_intelligence_trading.py',
    'gpu_trading_ai.py',
    'distributed_computing_framework.py'
]

print("Starting comprehensive syntax fix...")
print("=" * 60)

success_count = 0
for file in files:
    if os.path.exists(file):
        if fix_file(file):
            success_count += 1
    else:
        print(f"✗ File not found: {file}")

print("\n" + "=" * 60)
print(f"Fixed {success_count}/{len(files)} files successfully")

if success_count < len(files):
    print("\nNote: Some files may need manual inspection for complex syntax errors.")
    print("Common issues to check:")
    print("- Unclosed strings or docstrings")
    print("- Mismatched quotes")
    print("- Invalid indentation")
    print("- Missing colons after function/class definitions")