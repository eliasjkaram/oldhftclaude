#!/usr/bin/env python3
"""
MACHINE LEARNING TRADING PIPELINE
=================================
Complete ML pipeline with historical data, real-time predictions,
and automated trade execution for stocks, options, and spreads.
"""

import os
import sys
import json
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import asyncio
import joblib
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce, AssetClass
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame

# Technical indicators
import talib

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('ml_trading_pipeline.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class PredictionResult:
    """Prediction result with confidence"""
    symbol: str
    prediction_type: str  # 'price', 'direction', 'volatility'
    value: float
    confidence: float
    timestamp: datetime
    features_used: Dict
    
@dataclass
class OptionGreeks:
    """Option Greeks calculation result"""
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float
    iv: float  # Implied volatility

class MLTradingPipeline:
    """Complete ML trading pipeline"""
    
    def __init__(self):
        # API credentials
        self.api_key = os.getenv('ALPACA_API_KEY', 'PKEP9PIBDKOSUGHHY44Z')
        self.api_secret = os.getenv('ALPACA_API_SECRET', 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ')
        
        # Initialize clients
        self.trading_client = TradingClient(self.api_key, self.api_secret, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        # ML models
        self.price_model = None
        self.direction_model = None
        self.volatility_model = None
        self.scaler = StandardScaler()
        
        # Model performance tracking
        self.model_performance = {}
            'price': {'mae': 0, 'accuracy': 0, 'predictions': 0},
            'direction': {'accuracy': 0, 'precision': 0, 'predictions': 0},
            'volatility': {'mae': 0, 'accuracy': 0, 'predictions': 0}
        }
        
        # Trading parameters
        self.min_confidence = 0.7
        self.max_position_size = 5000
        self.risk_per_trade = 0.02  # 2% risk per trade
        
        # Feature engineering parameters
        self.lookback_periods = [5, 10, 20, 50, 200]  # SMA periods
        self.rsi_period = 14
        self.macd_params = (12, 26, 9)
        
        # Track predictions and trades
        self.predictions_log = []
        self.trades_executed = []
        
        logger.info("ML Trading Pipeline initialized")
    
    def fetch_historical_data(self, symbol: str, days: int = 365) -> pd.DataFrame:
        """Fetch historical data from Alpaca"""
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            request = StockBarsRequest()
                symbol_or_symbols=symbol,
                timeframe=TimeFrame.Day,
                start=start_date,
                end=end_date
            )
            
            bars = self.data_client.get_stock_bars(request)
            
            # Convert to DataFrame
            data = []
            for bar in bars[symbol]:
                data.append({)
                    'timestamp': bar.timestamp,
                    'open': bar.open,
                    'high': bar.high,
                    'low': bar.low,
                    'close': bar.close,
                    'volume': bar.volume,
                    'vwap': bar.vwap
                })
            
            df = pd.DataFrame(data)
            df.set_index('timestamp', inplace=True)
            
            logger.info(f"Fetched {len(df)} days of data for {symbol}")
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Engineer features for ML models"""
        try:
            # Price-based features
            df['returns'] = df['close'].pct_change()
            df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
            
            # Moving averages
            for period in self.lookback_periods:
                df[f'sma_{period}'] = df['close'].rolling(window=period).mean()
                df[f'sma_ratio_{period}'] = df['close'] / df[f'sma_{period}']
            
            # Exponential moving averages
            df['ema_12'] = df['close'].ewm(span=12).mean()
            df['ema_26'] = df['close'].ewm(span=26).mean()
            
            # Technical indicators
            df['rsi'] = talib.RSI(df['close'].values, timeperiod=self.rsi_period)
            
            # MACD
            macd, signal, hist = talib.MACD(df['close'].values, 
                                           fastperiod=self.macd_params[0],
                                           slowperiod=self.macd_params[1],
                                           signalperiod=self.macd_params[2])
            df['macd'] = macd
            df['macd_signal'] = signal
            df['macd_hist'] = hist
            
            # Bollinger Bands
            upper, middle, lower = talib.BBANDS(df['close'].values, timeperiod=20)
            df['bb_upper'] = upper
            df['bb_middle'] = middle
            df['bb_lower'] = lower
            df['bb_width'] = upper - lower
            df['bb_position'] = (df['close'] - lower) / (upper - lower)
            
            # Volume indicators
            df['volume_sma'] = df['volume'].rolling(window=20).mean()
            df['volume_ratio'] = df['volume'] / df['volume_sma']
            
            # Volatility
            df['volatility'] = df['returns'].rolling(window=20).std()
            df['atr'] = talib.ATR(df['high'].values, df['low'].values, df['close'].values)
            
            # Price patterns
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_open_ratio'] = df['close'] / df['open']
            
            # Momentum
            df['momentum_10'] = df['close'] - df['close'].shift(10)
            df['roc_10'] = ((df['close'] - df['close'].shift(10)) / df['close'].shift(10)) * 100
            
            # Support/Resistance levels
            df['resistance'] = df['high'].rolling(window=20).max()
            df['support'] = df['low'].rolling(window=20).min()
            df['sr_position'] = (df['close'] - df['support']) / (df['resistance'] - df['support'])
            
            # Target variables
            df['future_return'] = df['returns'].shift(-1)
            df['future_direction'] = (df['future_return'] > 0).astype(int)
            df['future_volatility'] = df['returns'].shift(-1).rolling(window=5).std()
            
            # Clean data
            df.dropna(inplace=True)
            
            logger.info(f"Engineered {len(df.columns)} features")
            return df
            
        except Exception as e:
            logger.error(f"Error engineering features: {e}")
            return df
    
    def train_models(self, symbols: List[str]):
        """Train ML models on historical data"""
        logger.info("Training ML models...")
        
        # Combine data from multiple symbols
        all_data = []
        
        for symbol in symbols:
            df = self.fetch_historical_data(symbol)
            if not df.empty:
                df = self.engineer_features(df)
                df['symbol'] = symbol
                all_data.append(df)
        
        if not all_data:
            logger.error("No data available for training")
            return
        
        # Combine all data
        combined_df = pd.concat(all_data)
        
        # Define features (exclude targets and identifiers)
        feature_cols = [col for col in combined_df.columns]
                       if col not in ['symbol', 'future_return', 'future_direction', 
                                     'future_volatility', 'open', 'high', 'low', 'close', 'volume']]
        
        X = combined_df[feature_cols]
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train price prediction model
        logger.info("Training price prediction model...")
        y_price = combined_df['future_return']
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_price, test_size=0.2, random_state=42)
        
        self.price_model = GradientBoostingRegressor()
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        self.price_model.fit(X_train, y_train)
        
        # Evaluate
        train_score = self.price_model.score(X_train, y_train)
        test_score = self.price_model.score(X_test, y_test)
        logger.info(f"Price model - Train R²: {train_score:.3f}, Test R²: {test_score:.3f}")
        
        # Train direction prediction model
        logger.info("Training direction prediction model...")
        y_direction = combined_df['future_direction']
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_direction, test_size=0.2, random_state=42)
        
        self.direction_model = RandomForestRegressor()
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.direction_model.fit(X_train, y_train)
        
        # Evaluate
        train_acc = (self.direction_model.predict(X_train).round() == y_train).mean()
        test_acc = (self.direction_model.predict(X_test).round() == y_test).mean()
        logger.info(f"Direction model - Train Acc: {train_acc:.3f}, Test Acc: {test_acc:.3f}")
        
        # Train volatility prediction model
        logger.info("Training volatility prediction model...")
        y_vol = combined_df['future_volatility'].fillna(combined_df['volatility'])
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_vol, test_size=0.2, random_state=42)
        
        self.volatility_model = GradientBoostingRegressor()
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        self.volatility_model.fit(X_train, y_train)
        
        # Evaluate
        train_score = self.volatility_model.score(X_train, y_train)
        test_score = self.volatility_model.score(X_test, y_test)
        logger.info(f"Volatility model - Train R²: {train_score:.3f}, Test R²: {test_score:.3f}")
        
        # Save models
        self.save_models()
        
        logger.info("Model training completed")
    
    def save_models(self):
        """Save trained models"""
        try:
            joblib.dump(self.price_model, 'ml_price_model.pkl')
            joblib.dump(self.direction_model, 'ml_direction_model.pkl')
            joblib.dump(self.volatility_model, 'ml_volatility_model.pkl')
            joblib.dump(self.scaler, 'ml_scaler.pkl')
            logger.info("Models saved successfully")
        except Exception as e:
            logger.error(f"Error saving models: {e}")
    
    def load_models(self):
        """Load pre-trained models"""
        try:
            if os.path.exists('ml_price_model.pkl'):
                self.price_model = joblib.load('ml_price_model.pkl')
                self.direction_model = joblib.load('ml_direction_model.pkl')
                self.volatility_model = joblib.load('ml_volatility_model.pkl')
                self.scaler = joblib.load('ml_scaler.pkl')
                logger.info("Models loaded successfully")
                return True
        except Exception as e:
            logger.error(f"Error loading models: {e}")
        return False
    
    def make_predictions(self, symbol: str) -> Optional[Dict[str, PredictionResult]]:
        """Make real-time predictions for a symbol"""
        try:
            # Get recent data
            df = self.fetch_historical_data(symbol, days=100)
            if df.empty:
                return None
            
            # Engineer features
            df = self.engineer_features(df)
            if df.empty:
                return None
            
            # Get latest features
            feature_cols = [col for col in df.columns]
                          if col not in ['symbol', 'future_return', 'future_direction', 
                                        'future_volatility', 'open', 'high', 'low', 'close', 'volume']]
            
            latest_features = df[feature_cols].iloc[-1].values.reshape(1, -1)
            latest_features_scaled = self.scaler.transform(latest_features)
            
            # Make predictions
            predictions = {}
            
            # Price prediction
            if self.price_model:
                price_pred = self.price_model.predict(latest_features_scaled)[0]
                price_confidence = min(0.95, abs(self.price_model.score(latest_features_scaled, [price_pred])))
                
                predictions['price'] = PredictionResult()
                    symbol=symbol,
                    prediction_type='price',
                    value=price_pred,
                    confidence=price_confidence,
                    timestamp=datetime.now(),
                    features_used={'current_price': df['close'].iloc[-1]}
                )
            
            # Direction prediction
            if self.direction_model:
                direction_pred = self.direction_model.predict(latest_features_scaled)[0]
                direction_confidence = min(0.95, abs(direction_pred))
                
                predictions['direction'] = PredictionResult()
                    symbol=symbol,
                    prediction_type='direction',
                    value=1 if direction_pred > 0.5 else -1,
                    confidence=direction_confidence,
                    timestamp=datetime.now(),
                    features_used={'rsi': df['rsi'].iloc[-1], 'macd': df['macd'].iloc[-1]}
                )
            
            # Volatility prediction
            if self.volatility_model:
                vol_pred = self.volatility_model.predict(latest_features_scaled)[0]
                vol_confidence = min(0.95, 1 - abs(vol_pred - df['volatility'].iloc[-1]))
                
                predictions['volatility'] = PredictionResult()
                    symbol=symbol,
                    prediction_type='volatility',
                    value=vol_pred,
                    confidence=vol_confidence,
                    timestamp=datetime.now(),
                    features_used={'current_vol': df['volatility'].iloc[-1]}
                )
            
            # Log predictions
            self.predictions_log.append({)
                'timestamp': datetime.now(),
                'symbol': symbol,
                'predictions': predictions
            })
            
            return predictions
            
        except Exception as e:
            logger.error(f"Error making predictions for {symbol}: {e}")
            return None
    
    def calculate_option_greeks(self, spot: float, strike: float, days_to_expiry: int, 
                               volatility: float, risk_free_rate: float = 0.05) -> OptionGreeks:
        """Calculate option Greeks using Black-Scholes approximation"""
        try:
            from scipy.stats import norm
            
            # Convert to years
            T = days_to_expiry / 365.0
            
            # Calculate d1 and d2
            d1 = (np.log(spot / strike) + (risk_free_rate + 0.5 * volatility**2) * T) / (volatility * np.sqrt(T))
            d2 = d1 - volatility * np.sqrt(T)
            
            # Greeks for call option
            delta = norm.cdf(d1)
            gamma = norm.pdf(d1) / (spot * volatility * np.sqrt(T))
            theta = -(spot * norm.pdf(d1) * volatility) / (2 * np.sqrt(T)) - risk_free_rate * strike * np.exp(-risk_free_rate * T) * norm.cdf(d2)
            vega = spot * norm.pdf(d1) * np.sqrt(T) / 100  # Divided by 100 for percentage
            rho = strike * T * np.exp(-risk_free_rate * T) * norm.cdf(d2) / 100  # Divided by 100 for percentage
            
            return OptionGreeks()
                delta=delta,
                gamma=gamma,
                theta=theta / 365,  # Convert to daily
                vega=vega,
                rho=rho,
                iv=volatility
            )
            
        except Exception as e:
            logger.error(f"Error calculating Greeks: {e}")
            return OptionGreeks(0, 0, 0, 0, 0, 0)
    
    def execute_stock_trade(self, symbol: str, predictions: Dict[str, PredictionResult]) -> bool:
        """Execute stock trade based on predictions"""
        try:
            # Check predictions
            price_pred = predictions.get('price')
            direction_pred = predictions.get('direction')
            
            if not direction_pred or direction_pred.confidence < self.min_confidence:
                logger.info(f"Confidence too low for {symbol}: {direction_pred.confidence if direction_pred else 0}")
                return False
            
            # Get current price
            request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            quotes = self.data_client.get_stock_latest_quote(request)
            current_price = float(quotes[symbol].ask_price)
            
            # Determine position size
            account = self.trading_client.get_account()
            cash = float(account.cash)
            position_size = min(self.max_position_size, cash * self.risk_per_trade)
            quantity = int(position_size / current_price)
            
            if quantity < 1:
                return False
            
            # Place order
            side = OrderSide.BUY if direction_pred.value > 0 else OrderSide.SELL
            
            order_data = MarketOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=side,
                time_in_force=TimeInForce.DAY
            )
            
            order = self.trading_client.submit_order(order_data)
            
            logger.info(f"✅ ML TRADE: {side.value} {quantity} {symbol} @ ${current_price:.2f}")
            logger.info(f"   Confidence: {direction_pred.confidence:.1%}")
            logger.info(f"   Expected return: {price_pred.value:.2%}" if price_pred else "")
            
            # Track trade
            self.trades_executed.append({)
                'timestamp': datetime.now(),
                'symbol': symbol,
                'side': side.value,
                'quantity': quantity,
                'price': current_price,
                'prediction': direction_pred.value,
                'confidence': direction_pred.confidence,
                'order_id': order.id
            })
            
            return True
            
        except Exception as e:
            logger.error(f"Error executing stock trade: {e}")
            return False
    
    def execute_option_strategy(self, symbol: str, predictions: Dict[str, PredictionResult]) -> bool:
        """Execute option strategy based on predictions"""
        try:
            vol_pred = predictions.get('volatility')
            direction_pred = predictions.get('direction')
            
            if not vol_pred or not direction_pred:
                return False
            
            # High volatility + direction = Long options
            # High volatility + neutral = Straddle/Strangle
            # Low volatility = Sell options/spreads
            
            logger.info(f"Option strategy for {symbol}:")
            logger.info(f"  Volatility: {vol_pred.value:.3f} (conf: {vol_pred.confidence:.1%})")
            logger.info(f"  Direction: {direction_pred.value} (conf: {direction_pred.confidence:.1%})")
            
            # For now, log the recommended strategy
            if vol_pred.value > 0.02:  # High volatility
                if direction_pred.value > 0 and direction_pred.confidence > 0.7:
                    logger.info("  Strategy: LONG CALL")
                elif direction_pred.value < 0 and direction_pred.confidence > 0.7:
                    logger.info("  Strategy: LONG PUT")
                else:
                    logger.info("  Strategy: STRADDLE")
            else:  # Low volatility
                logger.info("  Strategy: IRON CONDOR or CREDIT SPREAD")
            
            return True
            
        except Exception as e:
            logger.error(f"Error executing option strategy: {e}")
            return False
    
    async def run_ml_trading_loop(self):
        """Main ML trading loop"""
        logger.info("Starting ML Trading Pipeline")
        
        # Load or train models
        if not self.load_models():
            logger.info("Training new models...")
            training_symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'SPY', 'QQQ']
            self.train_models(training_symbols)
        
        # Trading symbols
        symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'META', 'NVDA', 'SPY', 'QQQ']
        
        iteration = 0
        
        while True:
            try:
                iteration += 1
                
                os.system('clear' if os.name != 'nt' else 'cls')
                
                print("=" * 100)
                print("🤖 ML TRADING PIPELINE - REAL-TIME PREDICTIONS & EXECUTION")
                print("=" * 100)
                print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"Iteration: {iteration}")
                print("=" * 100)
                
                # Account status
                account = self.trading_client.get_account()
                print(f"\n💰 Account Status:")
                print(f"   Cash: ${float(account.cash):,.2f}")
                print(f"   Portfolio Value: ${float(account.portfolio_value):,.2f}")
                
                # Model performance
                print(f"\n📊 Model Performance:")
                for model_name, perf in self.model_performance.items():
                    if perf['predictions'] > 0:
                        print(f"   {model_name}: Accuracy: {perf['accuracy']:.1%}, ")
                              f"Predictions: {perf['predictions']}")
                
                # Make predictions and trade
                print(f"\n🔮 Making Predictions...")
                trades_this_round = 0
                
                for symbol in symbols:
                    predictions = self.make_predictions(symbol)
                    
                    if predictions:
                        # Display predictions
                        print(f"\n{symbol}:")
                        
                        if 'price' in predictions:
                            pred = predictions['price']
                            print(f"  Price Return: {pred.value:+.2%} (conf: {pred.confidence:.1%})")
                        
                        if 'direction' in predictions:
                            pred = predictions['direction']
                            direction = "UP" if pred.value > 0 else "DOWN"
                            print(f"  Direction: {direction} (conf: {pred.confidence:.1%})")
                        
                        if 'volatility' in predictions:
                            pred = predictions['volatility']
                            print(f"  Volatility: {pred.value:.3f} (conf: {pred.confidence:.1%})")
                        
                        # Execute trades if confidence is high
                        if predictions.get('direction') and predictions['direction'].confidence > self.min_confidence:
                            if self.execute_stock_trade(symbol, predictions):
                                trades_this_round += 1
                                print(f"  ✅ Trade executed!")
                        
                        # Option strategy recommendation
                        self.execute_option_strategy(symbol, predictions)
                
                # Summary
                print(f"\n📈 Trading Summary:")
                print(f"   Predictions Made: {len(self.predictions_log)}")
                print(f"   Trades This Round: {trades_this_round}")
                print(f"   Total Trades: {len(self.trades_executed)}")
                
                # Recent trades
                if self.trades_executed:
                    print(f"\n📋 Recent Trades:")
                    for trade in self.trades_executed[-5:]:
                        print(f"   {trade['timestamp'].strftime('%H:%M')} - ")
                              f"{trade['side']} {trade['quantity']} {trade['symbol']} "
                              f"@ ${trade['price']:.2f} (conf: {trade['confidence']:.1%})")
                
                print(f"\n⏳ Next prediction cycle in 60 seconds... (Press Ctrl+C to stop)")
                await asyncio.sleep(60)
                
            except KeyboardInterrupt:
                print("\n\n🛑 Stopping ML Trading Pipeline...")
                break
            except Exception as e:
                logger.error(f"Main loop error: {e}")
                await asyncio.sleep(60)
        
        # Final summary
        print(f"\n{'=' * 100}")
        print("📊 ML TRADING SUMMARY")
        print("=" * 100)
        print(f"Total Predictions: {len(self.predictions_log)}")
        print(f"Total Trades: {len(self.trades_executed)}")
        
        if self.trades_executed:
            success_rate = sum(1 for t in self.trades_executed if t['confidence'] > 0.7) / len(self.trades_executed)
            print(f"High Confidence Rate: {success_rate:.1%}")

async def main():
    """Main entry point"""
    print("=" * 100)
    print("🤖 MACHINE LEARNING TRADING PIPELINE")
    print("=" * 100)
    print("\nFeatures:")
    print("  ✅ Historical data processing with feature engineering")
    print("  ✅ Multiple ML models (price, direction, volatility)")
    print("  ✅ Real-time predictions with confidence scores")
    print("  ✅ Automated trade execution")
    print("  ✅ Options Greeks calculation")
    print("  ✅ Strategy recommendations")
    print("\n⚠️  Using Alpaca PAPER trading account")
    
    pipeline = MLTradingPipeline()
    await pipeline.run_ml_trading_loop()

if __name__ == "__main__":
    asyncio.run(main())