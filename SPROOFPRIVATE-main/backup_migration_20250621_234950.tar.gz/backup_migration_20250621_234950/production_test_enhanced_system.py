from datetime import datetime, timedelta
import os
#!/usr/bin/env python3
"""
Test Enhanced Trading System Components
======================================

Quick test to verify all enhanced components work correctly
"""

import sys
import traceback

import logging
from datetime import datetime

def test_enhanced_data_fetcher():
    """Test enhanced data fetcher"""
    try:
        from enhanced_data_fetcher import EnhancedDataFetcher
        
        config = {}
            'paper_api_key': 'test_key',
            'paper_secret_key': 'test_secret',
            'cache_duration_minutes': 5
        }
        
        fetcher = EnhancedDataFetcher(config)
        
        # Test mock data generation
        data = fetcher.generate_synthetic_data('AAPL', '1d', '1mo')
        
        if data is not None and not data.empty:
            logger.info("✅ Enhanced Data Fetcher: OK")
            logger.info(f"   Generated {len(data)} data points")
            return True
        else:
            logger.info("❌ Enhanced Data Fetcher: Failed - No data generated")
            return False
            
    except Exception as e:
        logger.error("❌ Enhanced Data Fetcher: Error - {e}")
        traceback.print_exc()
        return False

def test_enhanced_backtesting():
    """Test enhanced backtesting system"""
    try:
        from enhanced_backtesting_system import EnhancedBacktester, MomentumStrategy
        import pandas as pd
        import numpy as np
        
        # Create test data
        dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='D')
        np.random.seed(42)
        prices = 100 * np.exp(np.cumsum(self.get_price_distribution(0.001, 0.02, len(dates))))
        
        data = pd.DataFrame({)
            'open': prices * (1 + self.get_price_distribution(0, 0.01, len(dates))),
            'high': prices * (1 + np.abs(self.get_price_distribution(0.01, 0.01, len(dates)))),
            'low': prices * (1 - np.abs(self.get_price_distribution(0.01, 0.01, len(dates)))),
            'close': prices,
            'volume': np.random.randint(1000000, 10000000, len(dates))
        }, index=dates)
        
        # Test backtester
        backtester = EnhancedBacktester(initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000")))
        strategy = MomentumStrategy({'lookback': 20, 'threshold': 0.02})
        
        results = backtester.run_backtest(strategy, data)
        
        if 'error' not in results and 'total_return' in results:
            logger.info("✅ Enhanced Backtesting: OK")
            logger.info(f"   Total Return: {results['total_return']:.2%}")
            logger.info(f"   Sharpe Ratio: {results['sharpe_ratio']:.2f}")
            logger.info(f"   Number of Trades: {results['num_trades']}")
            return True
        else:
            logger.info("❌ Enhanced Backtesting: Failed - Invalid results")
            return False
            
    except Exception as e:
        logger.error("❌ Enhanced Backtesting: Error - {e}")
        traceback.print_exc()
        return False

def test_gui_imports():
    """Test GUI imports without launching"""
    try:
        from enhanced_trading_gui import EnhancedTradingGUI
        logger.info("✅ Enhanced GUI Import: OK")
        return True
    except Exception as e:
        logger.error("❌ Enhanced GUI Import: Error - {e}")
        return False

def test_existing_components():
    """Test existing trading components"""
    components_status = {}
    
    # Test components
    test_imports = []
        ('portfolio_optimization_mpt', 'Portfolio Optimization'),
        ('advanced_risk_management_system', 'Risk Management'),
        ('v27_lightweight_ml_models', 'ML Models'),
        ('sentiment_analysis_system', 'Sentiment Analysis'),
        ('system_verification_validator', 'System Validator')
    ]
    
    for module, name in test_imports:
        try:
            __import__(module)
            logger.info(f"✅ {name}: OK")
            components_status[name] = True
        except ImportError:
            logger.info(f"❌ {name}: Not Available")
            components_status[name] = False
        except Exception as e:
            logger.error("⚠️  {name}: Error - {e}")
            components_status[name] = False
    
    return components_status

def test_dependencies():
    """Test required dependencies"""
    dependencies = []
        ('pandas', 'Pandas'),
        ('numpy', 'NumPy'),
        ('matplotlib', 'Matplotlib'),
        ('tkinter', 'Tkinter'),
        ('scipy', 'SciPy'),
        ('seaborn', 'Seaborn')
    ]
    
    dep_status = {}
    
    for module, name in dependencies:
        try:
            __import__(module)
            logger.info(f"✅ {name}: OK")
            dep_status[name] = True
        except ImportError:
            logger.info(f"❌ {name}: Missing")
            dep_status[name] = False
    
    return dep_status

def main():
    """Run all tests"""
    logger.info("="*70)
    logger.info("🧪 ENHANCED TRADING SYSTEM COMPONENT TEST")
    logger.info("="*70)
    logger.info(f"Test started: {datetime.now()}")
    logger.info()
    
    # Test dependencies
    logger.info("📦 Testing Dependencies:")
    dep_status = test_dependencies()
    logger.info()
    
    # Test existing components
    logger.info("🔧 Testing Existing Components:")
    comp_status = test_existing_components()
    logger.info()
    
    # Test enhanced components
    logger.info("🚀 Testing Enhanced Components:")
    
    # Test enhanced data fetcher
    data_fetcher_ok = test_enhanced_data_fetcher()
    logger.info()
    
    # Test enhanced backtesting
    backtesting_ok = test_enhanced_backtesting()
    logger.info()
    
    # Test GUI imports
    gui_ok = test_gui_imports()
    logger.info()
    
    # Summary
    logger.info("="*70)
    logger.info("📊 TEST SUMMARY")
    logger.info("="*70)
    
    total_deps = len(dep_status)
    working_deps = sum(dep_status.values())
    logger.info(f"Dependencies: {working_deps}/{total_deps} working")
    
    total_comps = len(comp_status)
    working_comps = sum(comp_status.values())
    logger.info(f"Existing Components: {working_comps}/{total_comps} working")
    
    enhanced_tests = []
        ('Enhanced Data Fetcher', data_fetcher_ok),
        ('Enhanced Backtesting', backtesting_ok),
        ('Enhanced GUI Import', gui_ok)
    ]
    
    working_enhanced = sum(test[1] for test in enhanced_tests)
    total_enhanced = len(enhanced_tests)
    
    logger.info(f"Enhanced Components: {working_enhanced}/{total_enhanced} working")
    
    overall_score = (working_deps + working_comps + working_enhanced) / (total_deps + total_comps + total_enhanced)
    logger.info(f"\nOverall System Health: {overall_score:.1%}")
    
    if overall_score >= 0.8:
        logger.info("🎉 System is ready for launch!")
    elif overall_score >= 0.6:
        logger.info("⚠️  System has some issues but should be functional")
    else:
        logger.info("❌ System has significant issues")
    
    logger.info(f"\nTest completed: {datetime.now()}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.info(f"❌ Test suite failed: {e}")
        traceback.print_exc()