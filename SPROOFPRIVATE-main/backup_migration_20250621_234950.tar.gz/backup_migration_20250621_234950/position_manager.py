
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Position Manager
Complete implementation for position management
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import logging
from typing import Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass
import json

logger = logging.getLogger(__name__)

@dataclass
class Position:
    symbol: str
    quantity: float
    entry_price: float
    current_price: float
    entry_time: datetime
    position_type: str  # 'long' or 'short'
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    
    @property
    def unrealized_pnl(self) -> float:
        if self.position_type == 'long':
            return (self.current_price - self.entry_price) * self.quantity
        else:
            return (self.entry_price - self.current_price) * self.quantity
            
    @property
    def pnl_percentage(self) -> float:
        if self.entry_price == 0:
            return 0
        return self.unrealized_pnl / (self.entry_price * abs(self.quantity)) * 100

class PositionManager:
    """Manage all trading positions"""
    
    def __init__(self, max_positions: int = 10):
        self.positions: Dict[str, Position] = {}
        self.max_positions = max_positions
        self.closed_positions = []
        
    def can_open_position(self) -> bool:
        """Check if we can open a new position"""
        return len(self.positions) < self.max_positions
        
    def open_position(self, symbol: str, quantity: float, price: float, 
                     position_type: str = 'long', stop_loss: Optional[float] = None,
                     take_profit: Optional[float] = None) -> bool:
        """Open a new position"""
        if not self.can_open_position():
            logger.warning(f"Cannot open position: max positions ({self.max_positions}) reached")
            return False
            
        if symbol in self.positions:
            logger.warning(f"Position already exists for {symbol}")
            return False
            
        position = Position()
            symbol=symbol,
            quantity=quantity,
            entry_price=price,
            current_price=price,
            entry_time=datetime.now(),
            position_type=position_type,
            stop_loss=stop_loss,
            take_profit=take_profit
        )
        
        self.positions[symbol] = position
        logger.info(f"Opened {position_type} position: {symbol} qty={quantity} @ ${price}")
        return True
        
    def close_position(self, symbol: str, exit_price: float) -> Optional[float]:
        """Close a position and return realized PnL"""
        if symbol not in self.positions:
            logger.error(f"No position found for {symbol}")
            return None
            
        position = self.positions[symbol]
        position.current_price = exit_price
        realized_pnl = position.unrealized_pnl
        
        # Record closed position
        closed_record = {}
            'symbol': symbol,
            'entry_time': position.entry_time.isoformat(),
            'exit_time': datetime.now().isoformat(),
            'entry_price': position.entry_price,
            'exit_price': exit_price,
            'quantity': position.quantity,
            'position_type': position.position_type,
            'realized_pnl': realized_pnl,
            'pnl_percentage': position.pnl_percentage
        }
        self.closed_positions.append(closed_record)
        
        # Remove from active positions
        del self.positions[symbol]
        
        logger.info(f"Closed position: {symbol} PnL=${realized_pnl:.2f} ({position.pnl_percentage:.2f}%)")
        return realized_pnl
        
    def update_position_price(self, symbol: str, current_price: float):
        """Update current price for a position"""
        if symbol in self.positions:
            self.positions[symbol].current_price = current_price
            
    def check_stop_loss_take_profit(self) -> List[str]:
        """Check positions for stop loss or take profit triggers"""
        triggered_positions = []
        
        for symbol, position in self.positions.items():
            if position.position_type == 'long':
                if position.stop_loss and position.current_price <= position.stop_loss:
                    triggered_positions.append(symbol)
                    logger.warning(f"Stop loss triggered for {symbol}")
                elif position.take_profit and position.current_price >= position.take_profit:
                    triggered_positions.append(symbol)
                    logger.info(f"Take profit triggered for {symbol}")
            else:  # short position
                if position.stop_loss and position.current_price >= position.stop_loss:
                    triggered_positions.append(symbol)
                    logger.warning(f"Stop loss triggered for {symbol}")
                elif position.take_profit and position.current_price <= position.take_profit:
                    triggered_positions.append(symbol)
                    logger.info(f"Take profit triggered for {symbol}")
                    
        return triggered_positions
        
    def get_total_exposure(self) -> float:
        """Get total portfolio exposure"""
        total = 0
        for position in self.positions.values():
            total += abs(position.quantity * position.current_price)
        return total
        
    def get_position_summary(self) -> Dict:
        """Get summary of all positions"""
        total_pnl = sum(p.unrealized_pnl for p in self.positions.values())
        
        return {}
            'active_positions': len(self.positions),
            'total_exposure': self.get_total_exposure(),
            'total_unrealized_pnl': total_pnl,
            'positions': {}
                symbol: {}
                    'quantity': pos.quantity,
                    'entry_price': pos.entry_price,
                    'current_price': pos.current_price,
                    'pnl': pos.unrealized_pnl,
                    'pnl_pct': pos.pnl_percentage
                }
                for symbol, pos in self.positions.items()
            }
        }
