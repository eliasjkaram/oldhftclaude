#!/usr/bin/env python3
"""
Production-Ready Distributed Training Framework for ML Models

This framework provides a comprehensive solution for distributed training with support for:
- Multiple training frameworks (PyTorch, TensorFlow, Horovod)
- Data and model parallelism
- Fault tolerance and elastic training
- Resource optimization and monitoring
- Production deployment features
"""

import os
import sys
import json
import time
import pickle
import logging
import threading
import multiprocessing
from typing import Dict, List, Any, Optional, Tuple, Callable, Union
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from contextlib import contextmanager
from datetime import datetime, timedelta
import subprocess
import signal
import socket
import psutil
import numpy as np
from enum import Enum
import yaml
import tempfile
import shutil
from pathlib import Path

# Deep Learning Frameworks
try:
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel as DDP
    from torch.distributed.fsdp import FullyShardedDataParallel as FSDP
    from torch.distributed.elastic.multiprocessing.errors import record
    from torch.cuda.amp import autocast, GradScaler
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import tensorflow as tf
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False

try:
    import horovod.torch as hvd_torch
    import horovod.tensorflow as hvd_tf
    HOROVOD_AVAILABLE = True
except ImportError:
    HOROVOD_AVAILABLE = False

# Cloud and orchestration
try:
    from kubernetes import client, config
    K8S_AVAILABLE = True
except ImportError:
    K8S_AVAILABLE = False

# Monitoring and experiment tracking
try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False

try:
    import mlflow
    MLFLOW_AVAILABLE = True
except ImportError:
    MLFLOW_AVAILABLE = False

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class TrainingFramework(Enum):
    """Supported training frameworks"""
    PYTORCH_DDP = "pytorch_ddp"
    PYTORCH_FSDP = "pytorch_fsdp"
    TENSORFLOW = "tensorflow"
    HOROVOD = "horovod"
    CUSTOM = "custom"


class ParallelismStrategy(Enum):
    """Parallelism strategies"""
    DATA = "data"
    MODEL = "model"
    PIPELINE = "pipeline"
    HYBRID = "hybrid"


@dataclass
class DistributedConfig:
    """Configuration for distributed training"""
    framework: TrainingFramework = TrainingFramework.PYTORCH_DDP
    parallelism: ParallelismStrategy = ParallelismStrategy.DATA
    
    # Cluster configuration
    world_size: int = 1
    rank: int = 0
    local_rank: int = 0
    master_addr: str = "localhost"
    master_port: int = 29500
    backend: str = "nccl"  # nccl, gloo, mpi
    
    # Resource configuration
    gpus_per_node: int = 1
    nodes: int = 1
    workers_per_gpu: int = 1
    cpu_workers: int = 4
    
    # Training configuration
    batch_size: int = 32
    gradient_accumulation_steps: int = 1
    mixed_precision: bool = True
    gradient_compression: bool = True
    
    # Elastic training
    elastic_training: bool = False
    min_nodes: int = 1
    max_nodes: int = 4
    elastic_timeout: int = 600
    
    # Checkpointing
    checkpoint_dir: str = "./checkpoints"
    checkpoint_frequency: int = 1000  # steps
    keep_last_n_checkpoints: int = 3
    
    # Monitoring
    log_frequency: int = 10
    profile: bool = False
    trace_dir: str = "./traces"
    
    # Kubernetes
    k8s_namespace: str = "default"
    k8s_job_name: str = "distributed-training"
    use_spot_instances: bool = False
    
    # Experiment tracking
    experiment_name: str = "distributed_training"
    tracking_uri: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)


class ResourceMonitor:
    """Monitor system resources during training"""
    
    def __init__(self, interval: float = 1.0):
        self.interval = interval
        self.monitoring = False
        self.metrics = []
        self.monitor_thread = None
        
    def start(self):
        """Start monitoring resources"""
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
    def stop(self):
        """Stop monitoring resources"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join()
            
    def _monitor_loop(self):
        """Monitor loop running in separate thread"""
        while self.monitoring:
            metrics = self._collect_metrics()
            self.metrics.append(metrics)
            time.sleep(self.interval)
            
    def _collect_metrics(self) -> Dict[str, Any]:
        """Collect current system metrics"""
        metrics = {}
            'timestamp': datetime.now().isoformat(),
            'cpu_percent': psutil.cpu_percent(interval=0.1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_usage_percent': psutil.disk_usage('/').percent,
        }
        
        # GPU metrics if available
        if TORCH_AVAILABLE and torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                metrics[f'gpu_{i}_memory_used'] = torch.cuda.memory_allocated(i)
                metrics[f'gpu_{i}_memory_total'] = torch.cuda.get_device_properties(i).total_memory
                
        return metrics
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of collected metrics"""
        if not self.metrics:
            return {}
            
        summary = {}
            'duration': ()
                datetime.fromisoformat(self.metrics[-1]['timestamp']) -
                datetime.fromisoformat(self.metrics[0]['timestamp'])
            ).total_seconds(),
            'avg_cpu_percent': np.mean([m['cpu_percent'] for m in self.metrics]),
            'max_cpu_percent': np.max([m['cpu_percent'] for m in self.metrics]),
            'avg_memory_percent': np.mean([m['memory_percent'] for m in self.metrics]),
            'max_memory_percent': np.max([m['memory_percent'] for m in self.metrics]),
        }
        
        # GPU summary
        if TORCH_AVAILABLE and torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                gpu_memory_used = [m.get(f'gpu_{i}_memory_used', 0) for m in self.metrics]
                summary[f'gpu_{i}_avg_memory_gb'] = np.mean(gpu_memory_used) / 1e9
                summary[f'gpu_{i}_max_memory_gb'] = np.max(gpu_memory_used) / 1e9
                
        return summary


class CheckpointManager:
    """Manage model checkpoints with fault tolerance"""
    
    def __init__(self, checkpoint_dir: str, keep_last_n: int = 3):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.keep_last_n = keep_last_n
        self.checkpoints = []
        self._load_checkpoint_history()
        
    def _load_checkpoint_history(self):
        """Load existing checkpoint history"""
        history_file = self.checkpoint_dir / "checkpoint_history.json"
        if history_file.exists():
            with open(history_file, 'r') as f:
                self.checkpoints = json.load(f)
                
    def _save_checkpoint_history(self):
        """Save checkpoint history"""
        history_file = self.checkpoint_dir / "checkpoint_history.json"
        with open(history_file, 'w') as f:
            json.dump(self.checkpoints, f, indent=2)
            
    def save_checkpoint()
        self,
        state_dict: Dict[str, Any],
        step: int,
        metrics: Optional[Dict[str, float]] = None,
        is_best: bool = False
    ) -> str:
        """Save a checkpoint"""
        checkpoint_name = f"checkpoint_step_{step}.pt"
        checkpoint_path = self.checkpoint_dir / checkpoint_name
        
        checkpoint_data = {}
            'step': step,
            'state_dict': state_dict,
            'metrics': metrics or {},
            'timestamp': datetime.now().isoformat(),
        }
        
        # Save checkpoint
        if TORCH_AVAILABLE:
            torch.save(checkpoint_data, checkpoint_path)
        else:
            with open(checkpoint_path, 'wb') as f:
                pickle.dump(checkpoint_data, f)
                
        # Update history
        self.checkpoints.append({)
            'name': checkpoint_name,
            'step': step,
            'metrics': metrics or {},
            'timestamp': checkpoint_data['timestamp'],
            'is_best': is_best,
        })
        
        # Save best checkpoint
        if is_best:
            best_path = self.checkpoint_dir / "best_checkpoint.pt"
            shutil.copy2(checkpoint_path, best_path)
            
        # Clean old checkpoints
        self._cleanup_old_checkpoints()
        self._save_checkpoint_history()
        
        logger.info(f"Saved checkpoint at step {step}: {checkpoint_path}")
        return str(checkpoint_path)
        
    def _cleanup_old_checkpoints(self):
        """Remove old checkpoints keeping only the last N"""
        if len(self.checkpoints) > self.keep_last_n:
            # Sort by step
            sorted_checkpoints = sorted(self.checkpoints, key=lambda x: x['step'])
            
            # Keep best and last N
            to_keep = set()
            for ckpt in sorted_checkpoints:
                if ckpt['is_best']:
                    to_keep.add(ckpt['name'])
                    
            to_keep.update([ckpt['name'] for ckpt in sorted_checkpoints[-self.keep_last_n:]])
            
            # Remove old checkpoints
            for ckpt in sorted_checkpoints:
                if ckpt['name'] not in to_keep:
                    checkpoint_path = self.checkpoint_dir / ckpt['name']
                    if checkpoint_path.exists():
                        checkpoint_path.unlink()
                        
            # Update checkpoint list
            self.checkpoints = [ckpt for ckpt in self.checkpoints if ckpt['name'] in to_keep]
            
    def load_checkpoint(self, checkpoint_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Load a checkpoint"""
        if checkpoint_path is None:
            # Load latest checkpoint
            if not self.checkpoints:
                return None
            latest = max(self.checkpoints, key=lambda x: x['step'])
            checkpoint_path = self.checkpoint_dir / latest['name']
        else:
            checkpoint_path = Path(checkpoint_path)
            
        if not checkpoint_path.exists():
            logger.warning(f"Checkpoint not found: {checkpoint_path}")
            return None
            
        if TORCH_AVAILABLE:
            return torch.load(checkpoint_path, map_location='cpu')
        else:
            with open(checkpoint_path, 'rb') as f:
                return pickle.load(f)


class DistributedDataLoader:
    """Distributed data loader with sharding support"""
    
    def __init__()
        self,
        dataset: Any,
        batch_size: int,
        world_size: int,
        rank: int,
        shuffle: bool = True,
        num_workers: int = 4,
        pin_memory: bool = True,
        drop_last: bool = True,
    ):
        self.dataset = dataset
        self.batch_size = batch_size
        self.world_size = world_size
        self.rank = rank
        self.shuffle = shuffle
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.drop_last = drop_last
        
    def get_dataloader(self):
        """Get framework-specific distributed dataloader"""
        if TORCH_AVAILABLE:
            sampler = torch.utils.data.distributed.DistributedSampler()
                self.dataset,
                num_replicas=self.world_size,
                rank=self.rank,
                shuffle=self.shuffle,
            )
            
            return torch.utils.data.DataLoader()
                self.dataset,
                batch_size=self.batch_size,
                sampler=sampler,
                num_workers=self.num_workers,
                pin_memory=self.pin_memory,
                drop_last=self.drop_last,
            )
        else:
            # Implement manual sharding for other frameworks
            total_size = len(self.dataset)
            indices = list(range(total_size))
            
            if self.shuffle:
                np.random.shuffle(indices)
                
            # Shard data
            per_replica = total_size // self.world_size
            start_idx = self.rank * per_replica
            end_idx = start_idx + per_replica if self.rank < self.world_size - 1 else total_size
            
            shard_indices = indices[start_idx:end_idx]
            return [self.dataset[i] for i in shard_indices]


class GradientAggregator:
    """Handle gradient aggregation and compression"""
    
    def __init__()
        self,
        compression: bool = True,
        compression_ratio: float = 0.1,
        backend: str = "nccl"
    ):
        self.compression = compression
        self.compression_ratio = compression_ratio
        self.backend = backend
        
    def compress_gradient(self, gradient: Any) -> Any:
        """Compress gradient for efficient communication"""
        if not self.compression:
            return gradient
            
        if TORCH_AVAILABLE and isinstance(gradient, torch.Tensor):
            # Top-k sparsification
            k = int(gradient.numel() * self.compression_ratio)
            values, indices = torch.topk(gradient.abs().flatten(), k)
            compressed = torch.zeros_like(gradient).flatten()
            compressed[indices] = gradient.flatten()[indices]
            return compressed.reshape(gradient.shape)
        else:
            # NumPy compression
            flat = gradient.flatten()
            k = int(len(flat) * self.compression_ratio)
            indices = np.argpartition(np.abs(flat), -k)[-k:]
            compressed = np.zeros_like(flat)
            compressed[indices] = flat[indices]
            return compressed.reshape(gradient.shape)
            
    def aggregate_gradients()
        self,
        gradients: List[Any],
        aggregation_method: str = "mean"
    ) -> Any:
        """Aggregate gradients from multiple workers"""
        if aggregation_method == "mean":
            if TORCH_AVAILABLE and all(isinstance(g, torch.Tensor) for g in gradients):
                return torch.stack(gradients).mean(dim=0)
            else:
                return np.mean(gradients, axis=0)
        elif aggregation_method == "sum":
            if TORCH_AVAILABLE and all(isinstance(g, torch.Tensor) for g in gradients):
                return torch.stack(gradients).sum(dim=0)
            else:
                return np.sum(gradients, axis=0)
        else:
            raise ValueError(f"Unknown aggregation method: {aggregation_method}")


class BaseDistributedTrainer(ABC):
    """Base class for distributed trainers"""
    
    def __init__(self, config: DistributedConfig):
        self.config = config
        self.checkpoint_manager = CheckpointManager()
            config.checkpoint_dir,
            config.keep_last_n_checkpoints
        )
        self.resource_monitor = ResourceMonitor()
        self.gradient_aggregator = GradientAggregator()
            compression=config.gradient_compression,
            backend=config.backend
        )
        
    @abstractmethod
    def setup_distributed(self):
        """Setup distributed training environment"""
        pass
        
    @abstractmethod
    def create_model(self, model: Any) -> Any:
        """Create distributed model"""
        pass
        
    @abstractmethod
    def train_step(self, model: Any, batch: Any) -> Dict[str, float]:
        """Execute single training step"""
        pass
        
    @abstractmethod
    def cleanup(self):
        """Cleanup distributed resources"""
        pass
        
    def train()
        self,
        model: Any,
        train_dataloader: Any,
        val_dataloader: Optional[Any] = None,
        num_epochs: int = 10,
        optimizer: Optional[Any] = None,
        scheduler: Optional[Any] = None,
        callbacks: Optional[List[Callable]] = None,
    ) -> Dict[str, Any]:
        """Main training loop"""
        # Setup distributed environment
        self.setup_distributed()
        
        # Create distributed model
        model = self.create_model(model)
        
        # Start resource monitoring
        self.resource_monitor.start()
        
        # Training metrics
        metrics = {}
            'train_loss': [],
            'val_loss': [],
            'learning_rate': [],
            'epoch_times': [],
        }
        
        global_step = 0
        best_val_loss = float('inf')
        
        try:
            for epoch in range(num_epochs):
                epoch_start = time.time()
                epoch_loss = 0.0
                num_batches = 0
                
                # Training loop
                model.train()
                for batch_idx, batch in enumerate(train_dataloader):
                    # Training step
                    step_metrics = self.train_step(model, batch)
                    epoch_loss += step_metrics['loss']
                    num_batches += 1
                    global_step += 1
                    
                    # Log metrics
                    if global_step % self.config.log_frequency == 0:
                        self._log_metrics(step_metrics, global_step)
                        
                    # Save checkpoint
                    if global_step % self.config.checkpoint_frequency == 0:
                        self._save_checkpoint()
                            model, optimizer, scheduler, global_step, metrics
                        )
                        
                    # Run callbacks
                    if callbacks:
                        for callback in callbacks:
                            callback(model, step_metrics, global_step)
                            
                # Epoch metrics
                avg_epoch_loss = epoch_loss / num_batches
                metrics['train_loss'].append(avg_epoch_loss)
                
                # Validation
                if val_dataloader:
                    val_loss = self._validate(model, val_dataloader)
                    metrics['val_loss'].append(val_loss)
                    
                    # Save best model
                    if val_loss < best_val_loss:
                        best_val_loss = val_loss
                        self._save_checkpoint()
                            model, optimizer, scheduler, global_step, metrics, is_best=True
                        )
                        
                # Update learning rate
                if scheduler:
                    scheduler.step()
                    metrics['learning_rate'].append(scheduler.get_last_lr()[0])
                    
                epoch_time = time.time() - epoch_start
                metrics['epoch_times'].append(epoch_time)
                
                logger.info()
                    f"Epoch {epoch+1}/{num_epochs} - "
                    f"Train Loss: {avg_epoch_loss:.4f} - "
                    f"Val Loss: {val_loss:.4f} - "
                    f"Time: {epoch_time:.2f}s"
                )
                
        except Exception as e:
            logger.error(f"Training failed: {str(e)}")
            raise
        finally:
            # Stop monitoring and cleanup
            self.resource_monitor.stop()
            self.cleanup()
            
        # Get resource summary
        metrics['resource_summary'] = self.resource_monitor.get_summary()
        
        return metrics
        
    def _validate(self, model: Any, val_dataloader: Any) -> float:
        """Validation loop"""
        model.eval()
        total_loss = 0.0
        num_batches = 0
        
        with torch.no_grad() if TORCH_AVAILABLE else contextmanager():
            for batch in val_dataloader:
                loss = self.train_step(model, batch)['loss']
                total_loss += loss
                num_batches += 1
                
        return total_loss / num_batches
        
    def _save_checkpoint()
        self,
        model: Any,
        optimizer: Any,
        scheduler: Any,
        step: int,
        metrics: Dict[str, Any],
        is_best: bool = False
    ):
        """Save training checkpoint"""
        state_dict = {}
            'model': model.state_dict() if hasattr(model, 'state_dict') else model,
            'optimizer': optimizer.state_dict() if optimizer and hasattr(optimizer, 'state_dict') else None,
            'scheduler': scheduler.state_dict() if scheduler and hasattr(scheduler, 'state_dict') else None,
            'config': self.config.__dict__,
            'metrics': metrics,
        }
        
        self.checkpoint_manager.save_checkpoint(state_dict, step, metrics, is_best)
        
    def _log_metrics(self, metrics: Dict[str, float], step: int):
        """Log training metrics"""
        # Console logging
        log_str = f"Step {step} - "
        log_str += " - ".join([f"{k}: {v:.4f}" for k, v in metrics.items()])
        logger.info(log_str)
        
        # Wandb logging
        if WANDB_AVAILABLE and wandb.run:
            wandb.log(metrics, step=step)
            
        # MLflow logging
        if MLFLOW_AVAILABLE and mlflow.active_run():
            for key, value in metrics.items():
                mlflow.log_metric(key, value, step=step)


class PyTorchDDPTrainer(BaseDistributedTrainer):
    """PyTorch DistributedDataParallel trainer"""
    
    def setup_distributed(self):
        """Setup PyTorch distributed environment"""
        if not TORCH_AVAILABLE:
            raise RuntimeError("PyTorch is not available")
            
        # Initialize process group
        dist.init_process_group()
            backend=self.config.backend,
            init_method=f"tcp://{self.config.master_addr}:{self.config.master_port}",
            world_size=self.config.world_size,
            rank=self.config.rank,
        )
        
        # Set device
        if torch.cuda.is_available():
            torch.cuda.set_device(self.config.local_rank)
            
    def create_model(self, model: torch.nn.Module) -> torch.nn.Module:
        """Create DDP model"""
        device = torch.device(f"cuda:{self.config.local_rank}" if torch.cuda.is_available() else "cpu")
        model = model.to(device)
        
        if self.config.world_size > 1:
            model = DDP()
                model,
                device_ids=[self.config.local_rank] if torch.cuda.is_available() else None,
                output_device=self.config.local_rank if torch.cuda.is_available() else None,
            )
            
        return model
        
    def train_step(self, model: torch.nn.Module, batch: Any) -> Dict[str, float]:
        """Execute single training step"""
        # This is a template - implement actual training logic
        device = next(model.parameters()).device
        
        # Move batch to device
        if isinstance(batch, (list, tuple)):
            inputs, targets = batch
            inputs = inputs.to(device)
            targets = targets.to(device)
        else:
            inputs = batch.to(device)
            targets = None
            
        # Forward pass
        outputs = model(inputs)
        
        # Compute loss (placeholder - implement actual loss computation)
        if targets is not None:
            loss = torch.nn.functional.mse_loss(outputs, targets)
        else:
            loss = outputs.mean()  # Placeholder
            
        # Backward pass
        loss.backward()
        
        return {'loss': loss.item()}
        
    def cleanup(self):
        """Cleanup PyTorch distributed resources"""
        if dist.is_initialized():
            dist.destroy_process_group()


class PyTorchFSDPTrainer(BaseDistributedTrainer):
    """PyTorch FullyShardedDataParallel trainer"""
    
    def setup_distributed(self):
        """Setup PyTorch distributed environment"""
        if not TORCH_AVAILABLE:
            raise RuntimeError("PyTorch is not available")
            
        # Initialize process group
        dist.init_process_group()
            backend=self.config.backend,
            init_method=f"tcp://{self.config.master_addr}:{self.config.master_port}",
            world_size=self.config.world_size,
            rank=self.config.rank,
        )
        
        # Set device
        if torch.cuda.is_available():
            torch.cuda.set_device(self.config.local_rank)
            
    def create_model(self, model: torch.nn.Module) -> torch.nn.Module:
        """Create FSDP model"""
        device = torch.device(f"cuda:{self.config.local_rank}" if torch.cuda.is_available() else "cpu")
        
        if self.config.world_size > 1:
            model = FSDP()
                model,
                device_id=self.config.local_rank if torch.cuda.is_available() else None,
                auto_wrap_policy=None,  # Configure based on model architecture
                mixed_precision=self.config.mixed_precision,
            )
        else:
            model = model.to(device)
            
        return model
        
    def train_step(self, model: torch.nn.Module, batch: Any) -> Dict[str, float]:
        """Execute single training step with FSDP"""
        # Similar to DDP but with FSDP-specific optimizations
        return super().train_step(model, batch)
        
    def cleanup(self):
        """Cleanup PyTorch distributed resources"""
        if dist.is_initialized():
            dist.destroy_process_group()


class TensorFlowDistributedTrainer(BaseDistributedTrainer):
    """TensorFlow distributed trainer"""
    
    def setup_distributed(self):
        """Setup TensorFlow distributed environment"""
        if not TF_AVAILABLE:
            raise RuntimeError("TensorFlow is not available")
            
        # Setup TF distributed strategy
        if self.config.world_size > 1:
            self.strategy = tf.distribute.MirroredStrategy()
        else:
            self.strategy = tf.distribute.get_strategy()
            
    def create_model(self, model: Any) -> Any:
        """Create distributed TensorFlow model"""
        with self.strategy.scope():
            return model
            
    def train_step(self, model: Any, batch: Any) -> Dict[str, float]:
        """Execute single training step"""
        # Implement TensorFlow training step
        pass
        
    def cleanup(self):
        """Cleanup TensorFlow resources"""
        pass


class HorovodTrainer(BaseDistributedTrainer):
    """Horovod distributed trainer"""
    
    def setup_distributed(self):
        """Setup Horovod environment"""
        if not HOROVOD_AVAILABLE:
            raise RuntimeError("Horovod is not available")
            
        if TORCH_AVAILABLE:
            hvd_torch.init()
            if torch.cuda.is_available():
                torch.cuda.set_device(hvd_torch.local_rank())
        elif TF_AVAILABLE:
            hvd_tf.init()
            
    def create_model(self, model: Any) -> Any:
        """Create Horovod distributed model"""
        return model
        
    def train_step(self, model: Any, batch: Any) -> Dict[str, float]:
        """Execute single training step with Horovod"""
        # Implement Horovod training step
        pass
        
    def cleanup(self):
        """Cleanup Horovod resources"""
        pass


class ElasticTrainingManager:
    """Manage elastic training with dynamic worker allocation"""
    
    def __init__(self, config: DistributedConfig):
        self.config = config
        self.active_workers = set()
        self.worker_stats = {}
        self.relaunch_count = 0
        
    def add_worker(self, worker_id: str, worker_info: Dict[str, Any]):
        """Add a new worker to the training cluster"""
        self.active_workers.add(worker_id)
        self.worker_stats[worker_id] = {}
            'join_time': datetime.now(),
            'info': worker_info,
            'failures': 0,
        }
        logger.info(f"Added worker {worker_id} to cluster")
        
    def remove_worker(self, worker_id: str):
        """Remove a worker from the training cluster"""
        if worker_id in self.active_workers:
            self.active_workers.remove(worker_id)
            leave_time = datetime.now()
            if worker_id in self.worker_stats:
                duration = leave_time - self.worker_stats[worker_id]['join_time']
                logger.info(f"Removed worker {worker_id} after {duration}")
                
    def handle_worker_failure(self, worker_id: str, error: Exception):
        """Handle worker failure with recovery"""
        logger.error(f"Worker {worker_id} failed: {str(error)}")
        
        if worker_id in self.worker_stats:
            self.worker_stats[worker_id]['failures'] += 1
            
        # Remove failed worker
        self.remove_worker(worker_id)
        
        # Check if we need to relaunch
        if len(self.active_workers) < self.config.min_nodes:
            self.relaunch_workers()
            
    def relaunch_workers(self):
        """Relaunch workers to maintain minimum cluster size"""
        self.relaunch_count += 1
        needed_workers = self.config.min_nodes - len(self.active_workers)
        
        logger.info(f"Relaunching {needed_workers} workers (attempt {self.relaunch_count})")
        
        # Implement worker relaunch logic based on orchestrator
        if K8S_AVAILABLE and self.config.k8s_job_name:
            self._relaunch_k8s_workers(needed_workers)
            
    def _relaunch_k8s_workers(self, count: int):
        """Relaunch workers in Kubernetes"""
        try:
            config.load_incluster_config()
            v1 = client.BatchV1Api()
            
            # Scale up job
            job = v1.read_namespaced_job()
                name=self.config.k8s_job_name,
                namespace=self.config.k8s_namespace
            )
            job.spec.parallelism += count
            
            v1.patch_namespaced_job()
                name=self.config.k8s_job_name,
                namespace=self.config.k8s_namespace,
                body=job
            )
            
            logger.info(f"Scaled up K8s job by {count} workers")
            
        except Exception as e:
            logger.error(f"Failed to relaunch K8s workers: {str(e)}")


class KubernetesOrchestrator:
    """Orchestrate distributed training on Kubernetes"""
    
    def __init__(self, config: DistributedConfig):
        self.config = config
        
        if not K8S_AVAILABLE:
            raise RuntimeError("Kubernetes client is not available")
            
        # Load K8s config
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()
            
        self.batch_v1 = client.BatchV1Api()
        self.core_v1 = client.CoreV1Api()
        
    def create_training_job()
        self,
        image: str,
        command: List[str],
        resources: Dict[str, Any],
        volumes: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Create a distributed training job in Kubernetes"""
        
        # Job specification
        job_spec = {}
            "apiVersion": "batch/v1",
            "kind": "Job",
            "metadata": {}
                "name": self.config.k8s_job_name,
                "namespace": self.config.k8s_namespace,
                "labels": {}
                    "app": "distributed-training",
                    "framework": self.config.framework.value,
                }
            },
            "spec": {}
                "parallelism": self.config.nodes,
                "completions": self.config.nodes,
                "backoffLimit": 3,
                "template": {}
                    "metadata": {}
                        "labels": {}
                            "app": "distributed-training",
                            "job-name": self.config.k8s_job_name,
                        }
                    },
                    "spec": {}
                        "restartPolicy": "OnFailure",
                        "containers": [{]
                            "name": "training",
                            "image": image,
                            "command": command,
                            "resources": resources,
                            "env": self._get_env_vars(),
                            "volumeMounts": self._get_volume_mounts(volumes),
                        }],
                        "volumes": volumes or [],
                    }
                }
            }
        }
        
        # Add spot instance toleration if enabled
        if self.config.use_spot_instances:
            job_spec["spec"]["template"]["spec"]["tolerations"] = [{]
                "key": "spot-instance",
                "operator": "Equal",
                "value": "true",
                "effect": "NoSchedule"
            }]
            
        # Create job
        try:
            self.batch_v1.create_namespaced_job()
                namespace=self.config.k8s_namespace,
                body=job_spec
            )
            logger.info(f"Created K8s job: {self.config.k8s_job_name}")
            return self.config.k8s_job_name
            
        except Exception as e:
            logger.error(f"Failed to create K8s job: {str(e)}")
            raise
            
    def _get_env_vars(self) -> List[Dict[str, str]]:
        """Get environment variables for distributed training"""
        return []
            {"name": "WORLD_SIZE", "value": str(self.config.world_size)},
            {"name": "MASTER_ADDR", "value": self.config.master_addr},
            {"name": "MASTER_PORT", "value": str(self.config.master_port)},
            {"name": "BACKEND", "value": self.config.backend},
            {"name": "TRAINING_FRAMEWORK", "value": self.config.framework.value},
        ]
        
    def _get_volume_mounts(self, volumes: Optional[List[Dict[str, Any]]]) -> List[Dict[str, str]]:
        """Get volume mounts for containers"""
        mounts = []
        if volumes:
            for volume in volumes:
                mounts.append({)
                    "name": volume["name"],
                    "mountPath": volume.get("mountPath", f"/mnt/{volume['name']}")
                })
        return mounts
        
    def monitor_job(self, job_name: str) -> Dict[str, Any]:
        """Monitor the status of a training job"""
        try:
            job = self.batch_v1.read_namespaced_job()
                name=job_name,
                namespace=self.config.k8s_namespace
            )
            
            status = {}
                "active": job.status.active or 0,
                "succeeded": job.status.succeeded or 0,
                "failed": job.status.failed or 0,
                "conditions": job.status.conditions or [],
            }
            
            # Get pod logs
            pods = self.core_v1.list_namespaced_pod()
                namespace=self.config.k8s_namespace,
                label_selector=f"job-name={job_name}"
            )
            
            status["pods"] = []
            for pod in pods.items:
                status["pods"].append({)
                    "name": pod.metadata.name,
                    "phase": pod.status.phase,
                    "node": pod.spec.node_name,
                })
                
            return status
            
        except Exception as e:
            logger.error(f"Failed to monitor job: {str(e)}")
            return {}
            
    def cleanup_job(self, job_name: str):
        """Clean up a completed or failed job"""
        try:
            self.batch_v1.delete_namespaced_job()
                name=job_name,
                namespace=self.config.k8s_namespace,
                body=client.V1DeleteOptions(propagation_policy='Foreground')
            )
            logger.info(f"Cleaned up job: {job_name}")
            
        except Exception as e:
            logger.error(f"Failed to cleanup job: {str(e)}")


class CostOptimizer:
    """Optimize training costs with spot instances and resource allocation"""
    
    def __init__(self, config: DistributedConfig):
        self.config = config
        self.cost_history = []
        self.spot_savings = 0.0
        
    def estimate_cost()
        self,
        instance_type: str,
        hours: float,
        is_spot: bool = False
    ) -> float:
        """Estimate training cost for given configuration"""
        # Instance pricing (example rates - replace with actual pricing)
        on_demand_prices = {}
            "p3.2xlarge": 3.06,  # $/hour
            "p3.8xlarge": 12.24,
            "p3.16xlarge": 24.48,
            "p4d.24xlarge": 32.77,
        }
        
        spot_discount = 0.7  # 70% discount for spot instances
        
        base_price = on_demand_prices.get(instance_type, 3.06)
        if is_spot:
            price = base_price * (1 - spot_discount)
            self.spot_savings += base_price * spot_discount * hours
        else:
            price = base_price
            
        total_cost = price * hours * self.config.nodes
        
        self.cost_history.append({)
            'timestamp': datetime.now(),
            'instance_type': instance_type,
            'hours': hours,
            'nodes': self.config.nodes,
            'is_spot': is_spot,
            'cost': total_cost,
        })
        
        return total_cost
        
    def get_optimal_configuration()
        self,
        model_size: int,
        dataset_size: int,
        target_time_hours: float,
        budget: float
    ) -> Dict[str, Any]:
        """Get optimal training configuration within budget"""
        configurations = []
        
        # Generate candidate configurations
        instance_types = ["p3.2xlarge", "p3.8xlarge", "p3.16xlarge", "p4d.24xlarge"]
        node_counts = [1, 2, 4, 8, 16]
        
        for instance in instance_types:
            for nodes in node_counts:
                # Estimate training time (simplified)
                base_time = model_size * dataset_size / (nodes * 1e9)  # Hours
                
                # Calculate costs
                on_demand_cost = self.estimate_cost(instance, base_time, is_spot=False)
                spot_cost = self.estimate_cost(instance, base_time, is_spot=True)
                
                if on_demand_cost <= budget:
                    configurations.append({)
                        'instance_type': instance,
                        'nodes': nodes,
                        'use_spot': False,
                        'estimated_time': base_time,
                        'estimated_cost': on_demand_cost,
                        'cost_per_hour': on_demand_cost / base_time,
                    })
                    
                if spot_cost <= budget:
                    configurations.append({)
                        'instance_type': instance,
                        'nodes': nodes,
                        'use_spot': True,
                        'estimated_time': base_time,
                        'estimated_cost': spot_cost,
                        'cost_per_hour': spot_cost / base_time,
                    })
                    
        # Sort by time (fastest first) and filter by target time
        valid_configs = []
            c for c in configurations
            if c['estimated_time'] <= target_time_hours
        ]
        
        if not valid_configs:
            # Return cheapest if no config meets time constraint
            return min(configurations, key=lambda x: x['estimated_cost'])
            
        # Return fastest configuration within budget
        return min(valid_configs, key=lambda x: x['estimated_time'])
        
    def get_cost_summary(self) -> Dict[str, Any]:
        """Get summary of training costs"""
        if not self.cost_history:
            return {}
            
        total_cost = sum(h['cost'] for h in self.cost_history)
        total_hours = sum(h['hours'] for h in self.cost_history)
        
        return {}
            'total_cost': total_cost,
            'total_hours': total_hours,
            'average_cost_per_hour': total_cost / total_hours if total_hours > 0 else 0,
            'spot_savings': self.spot_savings,
            'cost_history': self.cost_history,
        }


class ExperimentTracker:
    """Track experiments with MLflow/Wandb integration"""
    
    def __init__(self, config: DistributedConfig):
        self.config = config
        self.run_id = None
        
        # Initialize tracking backends
        if MLFLOW_AVAILABLE and config.tracking_uri:
            mlflow.set_tracking_uri(config.tracking_uri)
            mlflow.set_experiment(config.experiment_name)
            
        if WANDB_AVAILABLE:
            wandb.init()
                project=config.experiment_name,
                config=config.__dict__,
                tags=list(config.tags.values()),
                reinit=True,
            )
            
    def start_run(self, run_name: Optional[str] = None):
        """Start a new experiment run"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_name = run_name or f"distributed_training_{timestamp}"
        
        if MLFLOW_AVAILABLE:
            mlflow.start_run(run_name=run_name)
            self.run_id = mlflow.active_run().info.run_id
            
            # Log configuration
            mlflow.log_params({)
                'framework': self.config.framework.value,
                'world_size': self.config.world_size,
                'batch_size': self.config.batch_size,
                'mixed_precision': self.config.mixed_precision,
                'elastic_training': self.config.elastic_training,
            })
            
            # Log tags
            for key, value in self.config.tags.items():
                mlflow.set_tag(key, value)
                
    def log_metrics(self, metrics: Dict[str, float], step: int):
        """Log training metrics"""
        if MLFLOW_AVAILABLE and mlflow.active_run():
            for key, value in metrics.items():
                mlflow.log_metric(key, value, step=step)
                
        if WANDB_AVAILABLE and wandb.run:
            wandb.log(metrics, step=step)
            
    def log_artifact(self, artifact_path: str, artifact_type: str = "model"):
        """Log training artifacts"""
        if MLFLOW_AVAILABLE and mlflow.active_run():
            mlflow.log_artifact(artifact_path)
            
        if WANDB_AVAILABLE and wandb.run:
            artifact = wandb.Artifact()
                name=f"{artifact_type}_{self.run_id}",
                type=artifact_type
            )
            artifact.add_file(artifact_path)
            wandb.log_artifact(artifact)
            
    def end_run(self):
        """End the current experiment run"""
        if MLFLOW_AVAILABLE and mlflow.active_run():
            mlflow.end_run()
            
        if WANDB_AVAILABLE and wandb.run:
            wandb.finish()


class DistributedTrainingFramework:
    """Main distributed training framework orchestrator"""
    
    def __init__(self, config: Optional[Union[Dict[str, Any], DistributedConfig]] = None):
        if isinstance(config, dict) or config is None:
            self.config = DistributedConfig(**(config or {}))
        else:
            self.config = config
        self.trainer = self._create_trainer()
        self.experiment_tracker = ExperimentTracker(self.config)
        self.cost_optimizer = CostOptimizer(self.config)
        self.elastic_manager = ElasticTrainingManager(self.config) if self.config.elastic_training else None
        
        # Setup Kubernetes orchestrator if needed
        self.k8s_orchestrator = None
        if K8S_AVAILABLE and self.config.k8s_job_name:
            self.k8s_orchestrator = KubernetesOrchestrator(config)
            
    def _create_trainer(self) -> BaseDistributedTrainer:
        """Create appropriate trainer based on configuration"""
        if self.config.framework == TrainingFramework.PYTORCH_DDP:
            return PyTorchDDPTrainer(self.config)
        elif self.config.framework == TrainingFramework.PYTORCH_FSDP:
            return PyTorchFSDPTrainer(self.config)
        elif self.config.framework == TrainingFramework.TENSORFLOW:
            return TensorFlowDistributedTrainer(self.config)
        elif self.config.framework == TrainingFramework.HOROVOD:
            return HorovodTrainer(self.config)
        else:
            raise ValueError(f"Unsupported framework: {self.config.framework}")
            
    def train()
        self,
        model: Any,
        train_dataset: Any,
        val_dataset: Optional[Any] = None,
        num_epochs: int = 10,
        optimizer: Optional[Any] = None,
        scheduler: Optional[Any] = None,
        callbacks: Optional[List[Callable]] = None,
    ) -> Dict[str, Any]:
        """Execute distributed training"""
        logger.info(f"Starting distributed training with {self.config.framework.value}")
        
        # Start experiment tracking
        self.experiment_tracker.start_run()
        
        # Create distributed data loaders
        train_loader = DistributedDataLoader()
            train_dataset,
            batch_size=self.config.batch_size,
            world_size=self.config.world_size,
            rank=self.config.rank,
            shuffle=True,
            num_workers=self.config.cpu_workers,
        ).get_dataloader()
        
        val_loader = None
        if val_dataset:
            val_loader = DistributedDataLoader()
                val_dataset,
                batch_size=self.config.batch_size,
                world_size=self.config.world_size,
                rank=self.config.rank,
                shuffle=False,
                num_workers=self.config.cpu_workers,
            ).get_dataloader()
            
        # Estimate and log training cost
        if hasattr(train_dataset, '__len__'):
            estimated_hours = (len(train_dataset) * num_epochs) / (self.config.batch_size * 3600)
            estimated_cost = self.cost_optimizer.estimate_cost()
                instance_type="p3.2xlarge",  # Example
                hours=estimated_hours,
                is_spot=self.config.use_spot_instances
            )
            logger.info(f"Estimated training cost: ${estimated_cost:.2f}")
            
        # Execute training
        try:
            metrics = self.trainer.train()
                model=model,
                train_dataloader=train_loader,
                val_dataloader=val_loader,
                num_epochs=num_epochs,
                optimizer=optimizer,
                scheduler=scheduler,
                callbacks=callbacks,
            )
            
            # Log final metrics
            self.experiment_tracker.log_metrics()
                {}
                    'final_train_loss': metrics['train_loss'][-1] if metrics['train_loss'] else 0,
                    'final_val_loss': metrics['val_loss'][-1] if metrics['val_loss'] else 0,
                    'total_training_time': sum(metrics['epoch_times']),
                    'avg_epoch_time': np.mean(metrics['epoch_times']),
                },
                step=num_epochs
            )
            
            # Log cost summary
            cost_summary = self.cost_optimizer.get_cost_summary()
            if cost_summary:
                self.experiment_tracker.log_metrics()
                    {}
                        'total_cost': cost_summary['total_cost'],
                        'spot_savings': cost_summary['spot_savings'],
                    },
                    step=num_epochs
                )
                
            # Save final model
            if self.config.rank == 0:  # Only save from main process
                model_path = os.path.join(self.config.checkpoint_dir, "final_model.pt")
                if TORCH_AVAILABLE and isinstance(model, torch.nn.Module):
                    torch.save(model.state_dict(), model_path)
                else:
                    with open(model_path, 'wb') as f:
                        pickle.dump(model, f)
                        
                self.experiment_tracker.log_artifact(model_path, "model")
                
            return metrics
            
        except Exception as e:
            logger.error(f"Training failed: {str(e)}")
            raise
        finally:
            # End experiment tracking
            self.experiment_tracker.end_run()
            
    def launch_distributed_job()
        self,
        image: str,
        command: List[str],
        resources: Dict[str, Any],
        volumes: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Launch distributed training job on Kubernetes"""
        if not self.k8s_orchestrator:
            raise RuntimeError("Kubernetes orchestrator not available")
            
        job_name = self.k8s_orchestrator.create_training_job()
            image=image,
            command=command,
            resources=resources,
            volumes=volumes,
        )
        
        # Monitor job
        while True:
            status = self.k8s_orchestrator.monitor_job(job_name)
            logger.info(f"Job status: {status}")
            
            if status.get('succeeded', 0) == self.config.nodes:
                logger.info("All workers completed successfully")
                break
            elif status.get('failed', 0) > 0:
                logger.error("Some workers failed")
                break
                
            time.sleep(30)
            
        return job_name
        
    def optimize_configuration()
        self,
        model_size: int,
        dataset_size: int,
        target_time_hours: float,
        budget: float
    ) -> Dict[str, Any]:
        """Get optimal training configuration"""
        return self.cost_optimizer.get_optimal_configuration()
            model_size=model_size,
            dataset_size=dataset_size,
            target_time_hours=target_time_hours,
            budget=budget,
        )


# Example usage and utilities
def create_config_from_env() -> DistributedConfig:
    """Create configuration from environment variables"""
    config = DistributedConfig()
    
    # Read from environment
    config.world_size = int(os.environ.get('WORLD_SIZE', '1'))
    config.rank = int(os.environ.get('RANK', '0'))
    config.local_rank = int(os.environ.get('LOCAL_RANK', '0'))
    config.master_addr = os.environ.get('MASTER_ADDR', 'localhost')
    config.master_port = int(os.environ.get('MASTER_PORT', '29500'))
    config.backend = os.environ.get('BACKEND', 'nccl')
    
    framework_str = os.environ.get('TRAINING_FRAMEWORK', 'pytorch_ddp')
    config.framework = TrainingFramework(framework_str)
    
    return config


def main():
    """Example main function for distributed training"""
    # Create configuration
    config = create_config_from_env()
    
    # Initialize framework
    framework = DistributedTrainingFramework(config)
    
    # Create model (example)
    if TORCH_AVAILABLE:
        model = torch.nn.Sequential()
            torch.nn.Linear(784, 256),
            torch.nn.ReLU(),
            torch.nn.Linear(256, 10),
        )
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    else:
        model = None
        optimizer = None
        
    # Create dummy dataset (replace with actual data)
    train_dataset = list(range(10000))
    val_dataset = list(range(1000))
    
    # Train model
    metrics = framework.train()
        model=model,
        train_dataset=train_dataset,
        val_dataset=val_dataset,
        num_epochs=10,
        optimizer=optimizer,
    )
    
    logger.info(f"Training completed. Final metrics: {metrics}")


if __name__ == "__main__":
    main()