#!/usr/bin/env python3
"""
Complete GUI Integration Test
============================

This script tests all the integrated components of the Ultimate Trading GUI
to ensure everything works together seamlessly and handles edge cases properly.
"""

from datetime import datetime, timedelta
import sys
import os
import traceback
import json

import logging
from datetime import datetime

def test_imports():
    """Test all module imports"""
    logger.info("Testing imports...")
    
    try:
        # Core GUI components
        from ultimate_trading_gui import TradingSystemGUI
        logger.info("✅ Main GUI imported successfully")
        
        # Complete implementations
        from COMPLETE_GUI_IMPLEMENTATION import ()
            RiskManagementSystem,
            TechnicalAnalysisSystem,
            OptionsTradinSystem,
            BacktestingLaboratory,
            dialog_implementations
        )
        logger.info("✅ Complete implementations imported successfully")
        
        # Trading system components
        from robust_data_fetcher import RobustDataFetcher
        from portfolio_optimization_mpt import ModernPortfolioTheory
        logger.info("✅ Trading components imported successfully")
        
        return True
        
    except ImportError as e:
        logger.info(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        logger.info(f"❌ Unexpected error during import: {e}")
        return False

def test_config_file():
    """Test configuration file"""
    logger.info("\nTesting configuration...")
    
    config_path = 'alpaca_config.json'
    
    if not os.path.exists(config_path):
        logger.info("⚠️  Config file not found, creating sample config...")
        
        sample_config = {}
            "paper_api_key": "SAMPLE_API_KEY",
            "paper_secret_key": "SAMPLE_SECRET_KEY", 
            "paper_base_url": "https://paper-api.alpaca.markets",
            "live_api_key": "",
            "live_secret_key": "",
            "live_base_url": "https://api.alpaca.markets"
        }
        
        try:
            with open(config_path, 'w') as f:
                json.dump(sample_config, f, indent=2)
            logger.info("✅ Sample config created")
            return True
        except Exception as e:
            logger.info(f"❌ Failed to create config: {e}")
            return False
    else:
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            logger.info("✅ Config file loaded successfully")
            return True
        except Exception as e:
            logger.info(f"❌ Failed to load config: {e}")
            return False

def test_risk_management_system():
    """Test risk management system functionality"""
    logger.info("\nTesting Risk Management System...")
    
    try:
        from COMPLETE_GUI_IMPLEMENTATION import RiskManagementSystem
        
        # Create mock portfolio manager
# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

        class MockPortfolioManager:
            def get_portfolio_summary(self):
                return {}
                    'total_value': 100000,
                    'cash_balance': 50000,
                    'positions': []
                        {}
                            'symbol': 'AAPL',
                            'market_value': 25000,
                            'shares': 100
                        },
                        {}
                            'symbol': 'MSFT', 
                            'market_value': 25000,
                            'shares': 80
                        }
                    ]
                }
        
        mock_portfolio = MockPortfolioManager()
        risk_system = RiskManagementSystem(mock_portfolio)
        
        # Test VaR calculation
        var_result = risk_system.calculate_portfolio_var()
        if 'error' not in var_result or var_result.get('var_amount') is not None:
            logger.info("✅ VaR calculation working")
        else:
            logger.info(f"⚠️  VaR calculation returned: {var_result}")
        
        # Test stress testing
        stress_result = risk_system.stress_test_portfolio()
        if 'error' not in stress_result:
            logger.info("✅ Stress testing working")
        else:
            logger.info(f"⚠️  Stress testing returned: {stress_result}")
        
        # Test Monte Carlo
        mc_result = risk_system.monte_carlo_simulation(num_simulations=100)
        if 'error' not in mc_result:
            logger.info("✅ Monte Carlo simulation working")
        else:
            logger.info(f"⚠️  Monte Carlo returned: {mc_result}")
        
        # Test risk limits check
        risk_check = risk_system.check_risk_limits()
        if 'error' not in risk_check:
            logger.info("✅ Risk limits checking working")
        else:
            logger.info(f"⚠️  Risk check returned: {risk_check}")
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Risk Management System test failed: {e}")
        traceback.print_exc()
        return False

def test_technical_analysis_system():
    """Test technical analysis system"""
    logger.info("\nTesting Technical Analysis System...")
    
    try:
        from COMPLETE_GUI_IMPLEMENTATION import TechnicalAnalysisSystem
        
        ta_system = TechnicalAnalysisSystem()
        
        # Test with a known symbol
        result = ta_system.calculate_all_indicators('AAPL', period='3mo')
        
        if 'error' not in result and 'indicators' in result:
            logger.info("✅ Technical analysis working")
            logger.info(f"   Found {len(result['indicators'])} indicator categories")
        else:
            logger.info(f"⚠️  Technical analysis returned: {result}")
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Technical Analysis System test failed: {e}")
        traceback.print_exc()
        return False

def test_options_trading_system():
    """Test options trading system"""
    logger.info("\nTesting Options Trading System...")
    
    try:
        from COMPLETE_GUI_IMPLEMENTATION import OptionsTradinSystem
        
        options_system = OptionsTradinSystem()
        
        # Test options chain retrieval
        chain_result = options_system.get_options_chain('AAPL')
        
        if 'error' not in chain_result:
            logger.info("✅ Options chain retrieval working")
        else:
            logger.info(f"⚠️  Options chain returned: {chain_result}")
        
        # Test Greeks calculation
        greeks_result = options_system.calculate_greeks()
            'CALL', 150, 155, 0.25, 0.05, 0.3
        )
        
        if 'error' not in greeks_result and 'delta' in greeks_result:
            logger.info("✅ Greeks calculation working")
        else:
            logger.info(f"⚠️  Greeks calculation returned: {greeks_result}")
        
        # Test strategy analysis
        test_legs = []
            {}
                'option_type': 'CALL',
                'strike': 150,
                'premium': 5.0,
                'quantity': 1,
                'side': 'BUY',
                'greeks': {'delta': 0.6, 'gamma': 0.05, 'theta': -0.1, 'vega': 0.2}
            }
        ]
        
        strategy_result = options_system.analyze_option_strategy('covered_call', test_legs)
        
        if 'error' not in strategy_result:
            logger.info("✅ Options strategy analysis working")
        else:
            logger.info(f"⚠️  Strategy analysis returned: {strategy_result}")
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Options Trading System test failed: {e}")
        traceback.print_exc()
        return False

def test_backtesting_laboratory():
    """Test backtesting laboratory"""
    logger.info("\nTesting Backtesting Laboratory...")
    
    try:
        from COMPLETE_GUI_IMPLEMENTATION import BacktestingLaboratory
        
        # Create mock strategy manager
        class MockStrategyManager:
            def __init__(self):
                self.strategies = {}
                    'momentum': {}
                        'category': 'momentum',
                        'parameters': {'lookback': 20}
                    },
                    'mean_reversion': {}
                        'category': 'mean_reversion',
                        'parameters': {'lookback': 50, 'entry_zscore': 2.0}
                    }
                }
        
        mock_strategy_manager = MockStrategyManager()
        backtest_lab = BacktestingLaboratory(mock_strategy_manager)
        
        # Test single backtest
        result = backtest_lab.run_backtest()
            'momentum', 'AAPL', '2023-01-01', '2023-06-01', 100000
        )
        
        if 'error' not in result and 'performance_metrics' in result:
            logger.info("✅ Backtesting working")
            metrics = result['performance_metrics']
            logger.info(f"   Total return: {metrics['total_return_pct']:.2f}%")
        else:
            logger.info(f"⚠️  Backtesting returned: {result}")
        
        # Test strategy comparison
        comparison_result = backtest_lab.compare_strategies()
            ['momentum', 'mean_reversion'], 'AAPL', '2023-01-01', '2023-06-01'
        )
        
        if 'error' not in comparison_result:
            logger.info("✅ Strategy comparison working")
        else:
            logger.info(f"⚠️  Strategy comparison returned: {comparison_result}")
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Backtesting Laboratory test failed: {e}")
        traceback.print_exc()
        return False

def test_dialog_implementations():
    """Test dialog implementations"""
    logger.info("\nTesting Dialog Implementations...")
    
    try:
        from COMPLETE_GUI_IMPLEMENTATION import dialog_implementations
        
        # Check that all expected dialogs are available
        expected_dialogs = []
            'settings_dialog',
            'technical_analysis', 
            'options_trading',
            'risk_analysis',
            'backtesting_lab'
        ]
        
        for dialog_name in expected_dialogs:
            if dialog_name in dialog_implementations:
                logger.info(f"✅ {dialog_name} dialog available")
            else:
                logger.info(f"❌ {dialog_name} dialog missing")
                return False
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Dialog implementations test failed: {e}")
        traceback.print_exc()
        return False

def test_edge_cases():
    """Test edge cases and error handling"""
    logger.info("\nTesting Edge Cases...")
    
    try:
        from COMPLETE_GUI_IMPLEMENTATION import RiskManagementSystem, TechnicalAnalysisSystem
        
        # Test with empty portfolio
        class EmptyPortfolioManager:
            def get_portfolio_summary(self):
                return {}
                    'total_value': 0,
                    'cash_balance': 0,
                    'positions': []
                }
        
        empty_portfolio = EmptyPortfolioManager()
        risk_system = RiskManagementSystem(empty_portfolio)
        
        # Test VaR with empty portfolio
        var_result = risk_system.calculate_portfolio_var()
        if 'error' in var_result or var_result.get('var') == 0.0:
            logger.info("✅ Empty portfolio VaR handled correctly")
        else:
            logger.info(f"⚠️  Empty portfolio VaR: {var_result}")
        
        # Test technical analysis with invalid symbol
        ta_system = TechnicalAnalysisSystem()
        invalid_result = ta_system.calculate_all_indicators('INVALID_SYMBOL')
        
        if 'error' in invalid_result:
            logger.info("✅ Invalid symbol handled correctly")
        else:
            logger.info(f"⚠️  Invalid symbol result: {invalid_result}")
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Edge cases test failed: {e}")
        traceback.print_exc()
        return False

def test_gui_initialization():
    """Test GUI initialization without actually showing it"""
    logger.info("\nTesting GUI Initialization...")
    
    try:
        import tkinter as tk
        
        # Test if GUI can be created (but don't run mainloop)
        root = tk.Tk()
        root.withdraw()  # Hide the window
        
        # Create GUI components without showing
        gui = TradingSystemGUI()
        gui.root.withdraw()  # Hide this window too
        
        # Test that all components are initialized
        required_components = []
            'data_fetcher', 'portfolio_optimizer', 'risk_manager',
            'ml_ensemble', 'sentiment_analyzer', 'backtester',
            'risk_management_system', 'technical_analysis_system',
            'options_trading_system', 'backtesting_laboratory'
        ]
        
        missing_components = []
        for component in required_components:
            if not hasattr(gui, component):
                missing_components.append(component)
        
        if not missing_components:
            logger.info("✅ GUI initialization successful")
            logger.info("✅ All components initialized")
        else:
            logger.info(f"❌ Missing components: {missing_components}")
            return False
        
        # Clean up
        gui.root.destroy()
        root.destroy()
        
        return True
        
    except Exception as e:
        logger.info(f"❌ GUI initialization test failed: {e}")
        traceback.print_exc()
        return False

def run_all_tests():
    """Run all tests and provide summary"""
    logger.info("="*60)
    logger.info("COMPLETE GUI INTEGRATION TEST SUITE")
    logger.info("="*60)
    logger.info(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info()
    
    tests = []
        ("Imports", test_imports),
        ("Configuration", test_config_file),
        ("Risk Management", test_risk_management_system),
        ("Technical Analysis", test_technical_analysis_system),
        ("Options Trading", test_options_trading_system),
        ("Backtesting Laboratory", test_backtesting_laboratory),
        ("Dialog Implementations", test_dialog_implementations),
        ("Edge Cases", test_edge_cases),
        ("GUI Initialization", test_gui_initialization)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            logger.info(f"❌ {test_name} test crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    logger.info("\n" + "="*60)
    logger.info("TEST SUMMARY")
    logger.info("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        logger.info(f"{test_name:.<30} {status}")
    
    logger.info(f"\nOverall: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        logger.info("\n🎉 ALL TESTS PASSED! The complete GUI integration is working properly.")
        logger.info("\nThe system is ready for production use with:")
        logger.info("- Comprehensive risk management")
        logger.info("- Advanced technical analysis")
        logger.info("- Options trading with Greeks")
        logger.info("- Backtesting laboratory")
        logger.info("- All edge cases handled")
    else:
        logger.info(f"\n⚠️  {total - passed} tests failed. Please review the issues above.")
    
    logger.info(f"\nCompleted at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    run_all_tests()