#!/usr/bin/env python3
"""
Search for Missing 2023 Options Data
====================================

Focused search to find the missing 2023 data that would complete the coverage
"""

import json
import logging
from datetime import datetime
from minio import Minio
from minio.error import S3Error
import re
import zipfile
import gzip
import io

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class Search2023Data:
    def __init__(self):
        """Initialize MinIO client connection."""
        self.endpoint = "uschristmas.us"
        self.bucket_name = "stockdb"
        self.client = None
        
    def connect_to_minio(self):
        """Establish connection to MinIO bucket."""
        try:
            self.client = Minio(self.endpoint, secure=True)
            exists = self.client.bucket_exists(self.bucket_name)
            if exists:
                logger.info(f"✅ Connected to MinIO bucket: {self.bucket_name}")
                return True
            else:
                logger.error(f"❌ Bucket {self.bucket_name} does not exist")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to connect to MinIO: {e}")
            return False
    
    def search_compressed_files_for_2023(self):
        """Search all compressed files for 2023 data."""
        logger.info("🔍 Searching compressed files for 2023 data...")
        
        compressed_with_2023 = []
        
        try:
            # Search all directories for compressed files
            objects = self.client.list_objects(self.bucket_name, recursive=True)
            
            for obj in objects:
                if obj.object_name.endswith(('.zip', '.gz', '.tar', '.bz2', '.7z'):
                    # Check if filename contains 2023
                    if '2023' in obj.object_name:
                        logger.info(f"📦 Found compressed file with 2023 in name: {obj.object_name}")
                        compressed_with_2023.append({)
                            "file": obj.object_name,
                            "size_mb": obj.size / (1024**2),
                            "type": "filename_match"
                        })
                    
                    # For ZIP files, check contents
                    elif obj.object_name.endswith('.zip') and obj.size < 100 * 1024**2:  # Only check files < 100MB
                        try:
                            response = self.client.get_object(self.bucket_name, obj.object_name)
                            content = response.read()
                            
                            with zipfile.ZipFile(io.BytesIO(content) as zf:
                                for info in zf.infolist():
                                    if '2023' in info.filename:
                                        logger.info(f"📦 Found 2023 file inside ZIP: {obj.object_name} -> {info.filename}")
                                        compressed_with_2023.append({)
                                            "file": obj.object_name,
                                            "internal_file": info.filename,
                                            "size_mb": obj.size / (1024**2),
                                            "type": "zip_contents"
                                        })
                                        break
                        except Exception as e:
                            logger.debug(f"Could not inspect ZIP {obj.object_name}: {e}")
                            
        except Exception as e:
            logger.error(f"Error searching compressed files: {e}")
            
        return compressed_with_2023
    
    def search_all_files_for_2023(self):
        """Search all files for any 2023 references."""
        logger.info("🔍 Searching all files for 2023 references...")
        
        files_with_2023 = []
        
        try:
            objects = self.client.list_objects(self.bucket_name, recursive=True)
            
            for obj in objects:
                if obj.object_name.endswith('/'):
                    continue
                    
                # Check filename for 2023
                if '2023' in obj.object_name:
                    files_with_2023.append({)
                        "file": obj.object_name,
                        "size_mb": obj.size / (1024**2),
                        "last_modified": obj.last_modified.isoformat() if obj.last_modified else None,
                        "type": "filename"
                    })
                    logger.info(f"📄 Found file with 2023 in name: {obj.object_name}")
                    
        except Exception as e:
            logger.error(f"Error searching files: {e}")
            
        return files_with_2023
    
    def check_recent_additions(self):
        """Check for any files added in the last 60 days that might contain 2023 data."""
        logger.info("🔍 Checking recent additions (last 60 days)...")
        
        recent_files = []
        cutoff_date = datetime.now().replace(tzinfo=None) - timedelta(days=60)
        
        try:
            objects = self.client.list_objects(self.bucket_name, recursive=True)
            
            for obj in objects:
                if obj.object_name.endswith('/'):
                    continue
                    
                if obj.last_modified and obj.last_modified.replace(tzinfo=None) > cutoff_date:
                    recent_files.append({)
                        "file": obj.object_name,
                        "size_mb": obj.size / (1024**2),
                        "last_modified": obj.last_modified.isoformat(),
                        "days_ago": (datetime.now().replace(tzinfo=None) - obj.last_modified.replace(tzinfo=None).days)
                    })
                    
        except Exception as e:
            logger.error(f"Error checking recent files: {e}")
            
        return sorted(recent_files, key=lambda x: x["days_ago"])
    
    def run_2023_search(self):
        """Run comprehensive search for 2023 data."""
        logger.info("🚀 Starting comprehensive search for 2023 options data...")
        
        if not self.connect_to_minio():
            return None
        
        results = {}
            "search_timestamp": datetime.now().isoformat(),
            "target": "2023 options data",
            "files_with_2023": [],
            "compressed_with_2023": [],
            "recent_additions": [],
            "search_summary": {}
        }
        
        # Search for files with 2023 in name
        results["files_with_2023"] = self.search_all_files_for_2023()
        
        # Search compressed files
        results["compressed_with_2023"] = self.search_compressed_files_for_2023()
        
        # Check recent additions
        from datetime import timedelta
        results["recent_additions"] = self.check_recent_additions()
        
        # Summary
        results["search_summary"] = {}
            "total_files_with_2023": len(results["files_with_2023"]),
            "total_compressed_with_2023": len(results["compressed_with_2023"]),
            "total_recent_files": len(results["recent_additions"]),
            "found_2023_data": len(results["files_with_2023"]) > 0 or len(results["compressed_with_2023"]) > 0
        }
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"search_2023_data_{timestamp}.json"
        
        with open(report_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info(f"✅ 2023 search complete. Report saved to: {report_file}")
        return results

def main():
    """Main execution function."""
    searcher = Search2023Data()
    results = searcher.run_2023_search()
    
    if results:
        print("\n" + "="*80)
        print("SEARCH FOR MISSING 2023 OPTIONS DATA")
        print("="*80)
        
        summary = results["search_summary"]
        print(f"\n🎯 TARGET: 2023 options data (the missing year)")
        print(f"📄 Files with '2023' in name: {summary['total_files_with_2023']}")
        print(f"📦 Compressed files with 2023: {summary['total_compressed_with_2023']}")
        print(f"🆕 Recent additions (60 days): {summary['total_recent_files']}")
        
        if summary["found_2023_data"]:
            print(f"\n✅ FOUND 2023 DATA!")
            
            if results["files_with_2023"]:
                print(f"\n📄 FILES WITH 2023:")
                for file_info in results["files_with_2023"][:10]:  # Show first 10
                    print(f"   📁 {file_info['file']} ({file_info['size_mb']:.1f}MB)")
            
            if results["compressed_with_2023"]:
                print(f"\n📦 COMPRESSED FILES WITH 2023:")
                for comp_info in results["compressed_with_2023"]:
                    print(f"   📦 {comp_info['file']} ({comp_info['size_mb']:.1f}MB)")
                    if "internal_file" in comp_info:
                        print(f"      Contains: {comp_info['internal_file']}")
        else:
            print(f"\n❌ NO 2023 DATA FOUND")
            print(f"   2023 appears to be truly missing from the bucket")
        
        if results["recent_additions"]:
            print(f"\n🆕 RECENT ADDITIONS (might contain 2023 data):")
            for recent in results["recent_additions"][:5]:  # Show first 5
                print(f"   📁 {recent['file']} ({recent['days_ago']} days ago, {recent['size_mb']:.1f}MB)")
        
        print("\n" + "="*80)
        
        # Update the overall status
        if summary["found_2023_data"]:
            print("🎉 UPDATE: If 2023 data was found, coverage is now 100% complete!")
        else:
            print("ℹ️ STATUS: 2023 remains the only missing year (94.4% coverage)")
        
    else:
        print("❌ Search failed - could not connect to MinIO bucket")

if __name__ == "__main__":
    main()