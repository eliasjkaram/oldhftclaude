#!/usr/bin/env python3
"""
Test if algorithms generate signals with daily data
"""

import sys
import os
import pandas as pd
import numpy as np

import logging
from v21_alpaca_backtest_system import TradingAlgorithms

# Load some cached daily data
try:
    aapl_data = pd.read_pickle('daily_2024_cache/AAPL_1D_2024-01-01_2024-12-31.pkl')
    logger.info(f"Loaded AAPL data: {len(aapl_data)} days")
    logger.info(f"Date range: {aapl_data.index[0]} to {aapl_data.index[-1]}")
    logger.info(f"Price range: ${aapl_data['close'].min():.2f} - ${aapl_data['close'].max():.2f}")
    
    # Initialize algorithms
    algos = TradingAlgorithms()
    
    # Test a few algorithms
    test_algos = ['RSI_Oversold', 'MACD_Crossover', 'Mean_Reversion', 'Volume_Breakout']
    
    logger.info("\nTesting algorithm signals:\n")
    
    for algo_name in test_algos:
        if hasattr(algos, algo_name):
            algo_func = getattr(algos, algo_name)
            try:
                signals = algo_func(aapl_data)
                
                # Count signals
                buy_signals = (signals == 1).sum()
                sell_signals = (signals == -1).sum()
                hold_signals = (signals == 0).sum()
                
                logger.info(f"{algo_name}:")
                logger.info(f"  Buy signals: {buy_signals}")
                logger.info(f"  Sell signals: {sell_signals}")
                logger.info(f"  Hold signals: {hold_signals}")
                
                # Show first few non-zero signals
                non_zero = signals[signals != 0]
                if len(non_zero) > 0:
                    logger.info(f"  First signal at: {non_zero.index[0]}")
                    logger.info(f"  Signal dates: {len(non_zero)} total")
                logger.info()
                
            except Exception as e:
                logger.error("{algo_name}: Error - {e}\n")
    
    # Check data columns
    logger.info("\nData columns:", list(aapl_data.columns))
    logger.info("\nFirst 5 rows:")
    logger.info(aapl_data.head())
    
except Exception as e:
    logger.error("Error loading data: {e}")