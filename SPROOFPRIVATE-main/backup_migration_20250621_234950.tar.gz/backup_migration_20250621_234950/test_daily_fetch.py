#!/usr/bin/env python3
"""
Test fetching daily data directly from Alpaca
"""

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import json
from datetime import datetime

# Load config
with open('alpaca_config.json', 'r') as f:
    config = json.load(f)

# Initialize client
client = TradingClient()
    config.get('paper_api_key'),
    config.get('paper_secret_key'),
    config.get('paper_base_url')
)

# Test with AAPL for recent data
symbol = 'AAPL'
print(f"\nFetching daily data for {symbol}...")

# Try different date ranges
test_ranges = []
    ("2024-01-01", "2024-12-31", "2024"),
    ("2023-01-01", "2023-12-31", "2023"),
    ("2022-01-01", "2022-12-31", "2022"),
]

for start, end, year in test_ranges:
    try:
        bars = client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=start,
            end=end,
            adjustment='raw'
        ).df
        
        if not bars.empty:
            print(f"\n{year}: Found {len(bars)} daily bars")
            print(f"Price range: ${bars['close'].min():.2f} - ${bars['close'].max():.2f}")
            print(f"First date: {bars.index[0]}")
            print(f"Last date: {bars.index[-1]}")
        else:
            print(f"\n{year}: No data found")
    except Exception as e:
        print(f"\n{year}: Error - {e}")