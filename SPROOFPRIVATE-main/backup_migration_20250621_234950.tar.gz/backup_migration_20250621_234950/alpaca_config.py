#!/usr/bin/env python3
"""
Alpaca Configuration - Production API credentials and configuration settings
Central configuration for Alpaca Trading Bot with secure credential management
"""

import os
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
from datetime import timedelta

from configuration_manager import get_config_manager, ConfigFormat, FileConfigProvider
from secrets_manager import get_secrets_manager, SecretType
from unified_logging import get_logger


class TradingEnvironment(Enum):
    """Trading environment types"""
    PAPER = "paper"
    LIVE = "live"


class MarketDataPlan(Enum):
    """Alpaca market data subscription plans"""
    FREE = "free"
    UNLIMITED = "unlimited"


@dataclass
class AlpacaCredentials:
    """Alpaca API credentials"""
    api_key: str
    secret_key: str
    base_url: str
    
    
@dataclass
class TradingConfig:
    """Trading configuration parameters"""
    # Risk management
    max_position_size: float
    max_portfolio_risk: float
    max_single_trade_risk: float
    stop_loss_percentage: float
    take_profit_percentage: float
    
    # Position sizing
    position_sizing_method: str  # fixed, kelly, risk_parity
    default_position_size: float
    
    # Trading hours
    enable_premarket: bool
    enable_afterhours: bool
    
    # Order defaults
    default_order_type: str  # market, limit, stop, stop_limit
    default_time_in_force: str  # day, gtc, ioc, fok
    
    # Execution
    max_slippage: float
    min_order_size: float
    max_order_retries: int
    
    
@dataclass
class StrategyConfig:
    """Strategy configuration parameters"""
    # Enabled strategies
    enabled_strategies: list
    
    # Strategy parameters
    momentum_lookback: int
    mean_reversion_threshold: float
    trend_following_period: int
    
    # Signal generation
    min_signal_strength: float
    signal_combination_method: str  # vote, weighted, ml
    
    # Portfolio management
    max_positions: int
    rebalance_frequency: str  # daily, weekly, monthly
    
    
@dataclass
class DataConfig:
    """Data configuration parameters"""
    # Market data
    market_data_plan: MarketDataPlan
    data_providers: list  # alpaca, polygon, yahoo
    
    # Historical data
    historical_lookback_days: int
    cache_historical_data: bool
    
    # Real-time data
    enable_streaming: bool
    streaming_symbols: list
    
    # Data quality
    min_data_quality_score: float
    handle_missing_data: str  # drop, interpolate, forward_fill
    
    
@dataclass
class SystemConfig:
    """System configuration parameters"""
    # Performance
    worker_threads: int
    async_operations: bool
    
    # Monitoring
    enable_monitoring: bool
    metrics_port: int
    health_check_interval: int
    
    # Logging
    log_level: str
    log_to_file: bool
    log_rotation_size: int
    log_retention_days: int
    
    # Database
    database_url: str
    connection_pool_size: int
    
    # Notifications
    enable_notifications: bool
    notification_channels: list  # email, slack, webhook
    
    
class AlpacaConfig:
    """
    Central configuration manager for Alpaca Trading Bot
    Handles all configuration and credential management
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
        
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
            
        self._initialized = True
        self.logger = get_logger("alpaca_config")
        self.config_manager = get_config_manager()
        self.secrets_manager = get_secrets_manager()
        
        # Initialize configuration
        self._setup_configuration()
        self._setup_secrets()
        
        # Cache for frequently accessed values
        self._credentials_cache = {}
        self._config_cache = {}
        
    def _setup_configuration(self):
        """Setup configuration sources and defaults"""
        # Add configuration file if exists
        config_file = os.getenv("ALPACA_CONFIG_FILE", "config/alpaca_config.yaml")
        if os.path.exists(config_file):
            self.config_manager.add_provider()
                "alpaca_config",
                FileConfigProvider(config_file, ConfigFormat.YAML),
                priority=10
            )
            
        # Load configuration
        self.config_manager.load_all()
        
        # Set defaults if not present
        self._set_default_configuration()
        
    def _set_default_configuration(self):
        """Set default configuration values"""
        defaults = {}
            # Environment
            "environment": TradingEnvironment.PAPER.value,
            
            # Trading configuration
            "trading.max_position_size": 10000.0,
            "trading.max_portfolio_risk": 0.02,  # 2%
            "trading.max_single_trade_risk": 0.01,  # 1%
            "trading.stop_loss_percentage": 0.02,  # 2%
            "trading.take_profit_percentage": 0.05,  # 5%
            "trading.position_sizing_method": "risk_parity",
            "trading.default_position_size": 1000.0,
            "trading.enable_premarket": False,
            "trading.enable_afterhours": False,
            "trading.default_order_type": "limit",
            "trading.default_time_in_force": "day",
            "trading.max_slippage": 0.001,  # 0.1%
            "trading.min_order_size": 1,
            "trading.max_order_retries": 3,
            
            # Strategy configuration
            "strategy.enabled_strategies": ["momentum", "mean_reversion"],
            "strategy.momentum_lookback": 20,
            "strategy.mean_reversion_threshold": 2.0,
            "strategy.trend_following_period": 50,
            "strategy.min_signal_strength": 0.6,
            "strategy.signal_combination_method": "weighted",
            "strategy.max_positions": 10,
            "strategy.rebalance_frequency": "daily",
            
            # Data configuration
            "data.market_data_plan": MarketDataPlan.FREE.value,
            "data.data_providers": ["alpaca"],
            "data.historical_lookback_days": 365,
            "data.cache_historical_data": True,
            "data.enable_streaming": True,
            "data.streaming_symbols": [],
            "data.min_data_quality_score": 0.95,
            "data.handle_missing_data": "forward_fill",
            
            # System configuration
            "system.worker_threads": 4,
            "system.async_operations": True,
            "system.enable_monitoring": True,
            "system.metrics_port": 9090,
            "system.health_check_interval": 60,
            "system.log_level": "INFO",
            "system.log_to_file": True,
            "system.log_rotation_size": 104857600,  # 100MB
            "system.log_retention_days": 30,
            "system.database_url": "postgresql://localhost/alpaca_trading",
            "system.connection_pool_size": 10,
            "system.enable_notifications": True,
            "system.notification_channels": ["email", "webhook"],
            
            # Alpaca API configuration
            "alpaca.rate_limit_requests": 200,
            "alpaca.rate_limit_window": 60,
            "alpaca.request_timeout": 30,
            "alpaca.max_retries": 3,
            "alpaca.retry_delay": 1,
            
            # Watchlist configuration
            "watchlist.default_symbols": ["AAPL", "GOOGL", "MSFT", "AMZN", "TSLA"],
            "watchlist.sector_weights": {}
                "technology": 0.3,
                "healthcare": 0.2,
                "finance": 0.2,
                "consumer": 0.15,
                "industrials": 0.15
            }
        }
        
        # Apply defaults
        for key, value in defaults.items():
            if self.config_manager.get(key) is None:
                self.config_manager.set(key, value)
                
    def _setup_secrets(self):
        """Setup secret management"""
        # Check if credentials are already stored
        if not self.secrets_manager.get_secret("alpaca_api_key"):
            # Try to load from environment variables
            api_key = os.getenv("ALPACA_API_KEY")
            secret_key = os.getenv("ALPACA_SECRET_KEY")
            
            if api_key and secret_key:
                self.secrets_manager.set_secret()
                    "alpaca_api_key",
                    api_key,
                    type=SecretType.API_KEY,
                    description="Alpaca API Key",
                    rotation_period=timedelta(days=90)
                )
                
                self.secrets_manager.set_secret()
                    "alpaca_secret_key",
                    secret_key,
                    type=SecretType.API_KEY,
                    description="Alpaca Secret Key",
                    rotation_period=timedelta(days=90)
                )
                
                self.logger.info("Loaded Alpaca credentials from environment")
            else:
                self.logger.warning("Alpaca credentials not found. Please configure them.")
                
    def get_credentials(self, environment: Optional[TradingEnvironment] = None) -> AlpacaCredentials:
        """Get Alpaca API credentials"""
        env = environment or self.get_environment()
        
        # Check cache
        if env in self._credentials_cache:
            return self._credentials_cache[env]
            
        # Get credentials from secrets manager
        api_key = self.secrets_manager.get_secret(f"alpaca_api_key_{env.value}")
        secret_key = self.secrets_manager.get_secret(f"alpaca_secret_key_{env.value}")
        
        # Fall back to default credentials
        if not api_key:
            api_key = self.secrets_manager.get_secret("alpaca_api_key")
        if not secret_key:
            secret_key = self.secrets_manager.get_secret("alpaca_secret_key")
            
        if not api_key or not secret_key:
            raise ValueError(f"Alpaca credentials not configured for {env.value} environment")
            
        # Determine base URL
        if env == TradingEnvironment.PAPER:
            base_url = "https://paper-api.alpaca.markets"
        else:
            base_url = "https://api.alpaca.markets"
            
        credentials = AlpacaCredentials()
            api_key=api_key,
            secret_key=secret_key,
            base_url=base_url
        )
        
        # Cache credentials
        self._credentials_cache[env] = credentials
        
        return credentials
        
    def get_environment(self) -> TradingEnvironment:
        """Get current trading environment"""
        env_str = self.config_manager.get("environment", TradingEnvironment.PAPER.value)
        return TradingEnvironment(env_str)
        
    def set_environment(self, environment: TradingEnvironment):
        """Set trading environment"""
        self.config_manager.set("environment", environment.value)
        # Clear credentials cache
        self._credentials_cache.clear()
        self.logger.info(f"Switched to {environment.value} environment")
        
    def get_trading_config(self) -> TradingConfig:
        """Get trading configuration"""
        return TradingConfig()
            max_position_size=self.config_manager.get("trading.max_position_size"),
            max_portfolio_risk=self.config_manager.get("trading.max_portfolio_risk"),
            max_single_trade_risk=self.config_manager.get("trading.max_single_trade_risk"),
            stop_loss_percentage=self.config_manager.get("trading.stop_loss_percentage"),
            take_profit_percentage=self.config_manager.get("trading.take_profit_percentage"),
            position_sizing_method=self.config_manager.get("trading.position_sizing_method"),
            default_position_size=self.config_manager.get("trading.default_position_size"),
            enable_premarket=self.config_manager.get("trading.enable_premarket"),
            enable_afterhours=self.config_manager.get("trading.enable_afterhours"),
            default_order_type=self.config_manager.get("trading.default_order_type"),
            default_time_in_force=self.config_manager.get("trading.default_time_in_force"),
            max_slippage=self.config_manager.get("trading.max_slippage"),
            min_order_size=self.config_manager.get("trading.min_order_size"),
            max_order_retries=self.config_manager.get("trading.max_order_retries")
        )
        
    def get_strategy_config(self) -> StrategyConfig:
        """Get strategy configuration"""
        return StrategyConfig()
            enabled_strategies=self.config_manager.get("strategy.enabled_strategies"),
            momentum_lookback=self.config_manager.get("strategy.momentum_lookback"),
            mean_reversion_threshold=self.config_manager.get("strategy.mean_reversion_threshold"),
            trend_following_period=self.config_manager.get("strategy.trend_following_period"),
            min_signal_strength=self.config_manager.get("strategy.min_signal_strength"),
            signal_combination_method=self.config_manager.get("strategy.signal_combination_method"),
            max_positions=self.config_manager.get("strategy.max_positions"),
            rebalance_frequency=self.config_manager.get("strategy.rebalance_frequency")
        )
        
    def get_data_config(self) -> DataConfig:
        """Get data configuration"""
        return DataConfig()
            market_data_plan=MarketDataPlan(self.config_manager.get("data.market_data_plan")),
            data_providers=self.config_manager.get("data.data_providers"),
            historical_lookback_days=self.config_manager.get("data.historical_lookback_days"),
            cache_historical_data=self.config_manager.get("data.cache_historical_data"),
            enable_streaming=self.config_manager.get("data.enable_streaming"),
            streaming_symbols=self.config_manager.get("data.streaming_symbols"),
            min_data_quality_score=self.config_manager.get("data.min_data_quality_score"),
            handle_missing_data=self.config_manager.get("data.handle_missing_data")
        )
        
    def get_system_config(self) -> SystemConfig:
        """Get system configuration"""
        return SystemConfig()
            worker_threads=self.config_manager.get("system.worker_threads"),
            async_operations=self.config_manager.get("system.async_operations"),
            enable_monitoring=self.config_manager.get("system.enable_monitoring"),
            metrics_port=self.config_manager.get("system.metrics_port"),
            health_check_interval=self.config_manager.get("system.health_check_interval"),
            log_level=self.config_manager.get("system.log_level"),
            log_to_file=self.config_manager.get("system.log_to_file"),
            log_rotation_size=self.config_manager.get("system.log_rotation_size"),
            log_retention_days=self.config_manager.get("system.log_retention_days"),
            database_url=self.config_manager.get("system.database_url"),
            connection_pool_size=self.config_manager.get("system.connection_pool_size"),
            enable_notifications=self.config_manager.get("system.enable_notifications"),
            notification_channels=self.config_manager.get("system.notification_channels")
        )
        
    def get_watchlist_symbols(self) -> list:
        """Get watchlist symbols"""
        return self.config_manager.get("watchlist.default_symbols", [])
        
    def get_sector_weights(self) -> Dict[str, float]:
        """Get sector allocation weights"""
        return self.config_manager.get("watchlist.sector_weights", {})
        
    def validate_configuration(self) -> bool:
        """Validate all configuration settings"""
        try:
            # Check credentials
            credentials = self.get_credentials()
            if not credentials.api_key or not credentials.secret_key:
                self.logger.error("Missing API credentials")
                return False
                
            # Validate trading config
            trading_config = self.get_trading_config()
            if trading_config.max_position_size <= 0:
                self.logger.error("Invalid max position size")
                return False
                
            if trading_config.max_portfolio_risk <= 0 or trading_config.max_portfolio_risk > 1:
                self.logger.error("Invalid portfolio risk setting")
                return False
                
            # Validate strategy config
            strategy_config = self.get_strategy_config()
            if not strategy_config.enabled_strategies:
                self.logger.warning("No strategies enabled")
                
            # Validate data config
            data_config = self.get_data_config()
            if data_config.historical_lookback_days <= 0:
                self.logger.error("Invalid historical lookback period")
                return False
                
            self.logger.info("Configuration validation passed")
            return True
            
        except Exception as e:
            self.logger.error(f"Configuration validation failed: {e}")
            return False
            
    def export_configuration(self, include_secrets: bool = False) -> Dict[str, Any]:
        """Export current configuration"""
        config = self.config_manager.get_all()
        
        if include_secrets:
            # Add sanitized credentials
            try:
                credentials = self.get_credentials()
                config['credentials'] = {}
                    'api_key': credentials.api_key[:10] + "..." if credentials.api_key else None,
                    'has_secret_key': bool(credentials.secret_key),
                    'base_url': credentials.base_url
                }
            except:
                config['credentials'] = {'error': 'Not configured'}
                
        return config


# Singleton instance
_alpaca_config = None

def get_alpaca_config() -> AlpacaConfig:
    """Get the Alpaca configuration instance"""
    global _alpaca_config
    if _alpaca_config is None:
        _alpaca_config = AlpacaConfig()
    return _alpaca_config


# Convenience functions
def get_api_credentials() -> AlpacaCredentials:
    """Get current API credentials"""
    return get_alpaca_config().get_credentials()

def get_trading_params() -> TradingConfig:
    """Get trading parameters"""
    return get_alpaca_config().get_trading_config()

def get_strategy_params() -> StrategyConfig:
    """Get strategy parameters"""
    return get_alpaca_config().get_strategy_config()

def is_paper_trading() -> bool:
    """Check if using paper trading"""
    return get_alpaca_config().get_environment() == TradingEnvironment.PAPER


# Example usage
if __name__ == "__main__":
    # Initialize configuration
    config = get_alpaca_config()
    
    # Validate configuration
    if config.validate_configuration():
        print("Configuration is valid")
    else:
        print("Configuration validation failed")
        
    # Get various configurations
    print("\nEnvironment:", config.get_environment().value)
    
    try:
        credentials = config.get_credentials()
        print(f"API Key: {credentials.api_key[:10]}...")
        print(f"Base URL: {credentials.base_url}")
    except ValueError as e:
        print(f"Credentials error: {e}")
        
    # Trading configuration
    trading_config = config.get_trading_config()
    print(f"\nTrading Configuration:")
    print(f"  Max Position Size: ${trading_config.max_position_size:,.2f}")
    print(f"  Max Portfolio Risk: {trading_config.max_portfolio_risk:.1%}")
    print(f"  Position Sizing: {trading_config.position_sizing_method}")
    
    # Strategy configuration
    strategy_config = config.get_strategy_config()
    print(f"\nStrategy Configuration:")
    print(f"  Enabled Strategies: {', '.join(strategy_config.enabled_strategies)}")
    print(f"  Max Positions: {strategy_config.max_positions}")
    print(f"  Rebalance Frequency: {strategy_config.rebalance_frequency}")
    
    # Data configuration
    data_config = config.get_data_config()
    print(f"\nData Configuration:")
    print(f"  Market Data Plan: {data_config.market_data_plan.value}")
    print(f"  Historical Lookback: {data_config.historical_lookback_days} days")
    print(f"  Streaming Enabled: {data_config.enable_streaming}")
    
    # System configuration
    system_config = config.get_system_config()
    print(f"\nSystem Configuration:")
    print(f"  Worker Threads: {system_config.worker_threads}")
    print(f"  Monitoring Enabled: {system_config.enable_monitoring}")
    print(f"  Log Level: {system_config.log_level}")
    
    # Watchlist
    print(f"\nWatchlist Symbols: {', '.join(config.get_watchlist_symbols())}")
    
    # Export configuration
    print("\nExported Configuration (without secrets):")
    import json
    print(json.dumps(config.export_configuration(include_secrets=False), indent=2))

# Create default configuration instance lazily when needed
default_config = None

def get_default_config():
    global default_config
    if default_config is None:
        default_config = AlpacaConfig()
    return default_config
