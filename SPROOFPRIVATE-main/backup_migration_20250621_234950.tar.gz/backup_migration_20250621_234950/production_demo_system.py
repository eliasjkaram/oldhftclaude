
#!/usr/bin/env python3
"""
Demo Script for Comprehensive Options Trading System
Shows system capabilities without GUI
"""

# Alpaca imports
from datetime import datetime, timedelta
import sys
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import time
import pandas as pd
import numpy as np
from datetime import datetime
import logging

from universal_market_data import get_current_market_data, validate_price


# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

logger.info("🚀 " + "="*60)
logger.info("    COMPREHENSIVE OPTIONS TRADING SYSTEM DEMO")
logger.info("="*60)

logger.info("\n📊 System Components Loading...")

# Try to import our modules
components_loaded = {}

try:
    from strategy_selection_bot import StrategySelectionBot, TradingStrategy, MarketRegime
    components_loaded['Strategy Bot'] = True
    logger.info("✅ Strategy Selection Bot - LOADED")
except Exception as e:
    components_loaded['Strategy Bot'] = False
    logger.error("⚠️  Strategy Selection Bot - Error: {e}")

try:
    from market_data_engine import MarketDataProcessor
    components_loaded['Market Data'] = True
    logger.info("✅ Market Data Engine - LOADED")
except Exception as e:
    components_loaded['Market Data'] = False
    logger.error("⚠️  Market Data Engine - Error: {e}")

try:
    from spread_execution_engine import SpreadExecutionEngine
    components_loaded['Execution Engine'] = True
    logger.info("✅ Spread Execution Engine - LOADED")
except Exception as e:
    components_loaded['Execution Engine'] = False
    logger.error("⚠️  Spread Execution Engine - Error: {e}")

try:
    from advanced_options_strategies import AdvancedOptionsEngine
    components_loaded['Options Strategies'] = True
    logger.info("✅ Advanced Options Strategies - LOADED")
except Exception as e:
    components_loaded['Options Strategies'] = False
    logger.error("⚠️  Advanced Options Strategies - Error: {e}")

try:
    from advanced_pricing_models import AdvancedPricingEngine
    components_loaded['Pricing Models'] = True
    logger.info("✅ Advanced Pricing Models - LOADED")
except Exception as e:
    components_loaded['Pricing Models'] = False
    logger.error("⚠️  Advanced Pricing Models - Error: {e}")

logger.info(f"\n📈 System Status: {sum(components_loaded.values()}/{len(components_loaded)} components loaded")

logger.info("\n🎯 " + "="*50)
logger.info("    INTELLIGENT STRATEGY SELECTION DEMO")
logger.info("="*50)

# Demo the strategy selection system
async def self.get_production_config() else 'Bull Weak' if symbol == 'QQQ' else 'Volatile'}")
        logger.info(f"📈 Current Price: ${np.self.get_price_in_range(90, 110):.2f}")
        logger.info(f"📊 Volatility: {np.self.get_price_in_range(15, 35):.1f}%")
        logger.info(f"🎯 RSI: {np.self.get_price_in_range(30, 70):.1f}")
        
        logger.info(f"\n🎯 Top Strategy Recommendations:")
        
        # Randomize and show top 2 strategies
        selected_strategies = np.random.choice(len(strategies), 2, replace=False)
        
        for i, idx in enumerate(selected_strategies, 1):
            strategy, confidence, ret, win_prob, rationale = strategies[idx]
            # Add some randomness
            confidence += np.self.get_price_in_range(-0.05, 0.05)
            ret += np.self.get_price_in_range(-0.02, 0.02)
            
            logger.info(f"   {i}. {strategy}")
            logger.info(f"      Confidence: {confidence:.1%}")
            logger.info(f"      Expected Return: {ret:.1%}")
            logger.info(f"      Win Probability: {win_prob:.1%}")
            logger.info(f"      Rationale: {rationale}")
            
        logger.info(f"⚠️  Risk Level: {'Low' if symbol == 'SPY' else 'Moderate'}")
        logger.info("-" * 50)

def self.get_production_config()    EXECUTION ENGINE DEMO")
    logger.info("="*50)
    
    if not components_loaded.get('Execution Engine', False):
        logger.info("⚠️  Execution Engine not available - showing simulation")
        return self.get_production_config(    ADVANCED PRICING MODELS DEMO")
    logger.info("="*50)
    
    if not components_loaded.get('Pricing Models', False):
        logger.info("⚠️  Pricing Models not available - showing simulation")
        return self.get_production_config(    MARKET DATA ENGINE DEMO")
    logger.info("="*50)
    
    if not components_loaded.get('Market Data', False):
        logger.info("⚠️  Market Data Engine not available - showing simulation")
        return self.get_production_config(    COMPREHENSIVE GUI FEATURES")
    logger.info("="*50)
    
    logger.info("\n🎯 Strategy Selection Tab:")
    logger.info("   • Real-time market condition analysis")
    logger.info("   • Intelligent strategy recommendations with confidence scores")
    logger.info("   • Detailed rationale and parameter suggestions")
    logger.info("   • One-click strategy execution")
    
    logger.info("\n📊 Market Analysis Tab:")
    logger.info("   • Live price charts with technical indicators")
    logger.info("   • Volatility analysis and regime detection")
    logger.info("   • Options flow and sentiment metrics")
    logger.info("   • Support/resistance level identification")
    
    logger.info("\n⚡ Execution Tab:")
    logger.info("   • Multi-leg spread order entry")
    logger.info("   • 6 advanced execution algorithms")
    logger.info("   • Real-time order monitoring and management")
    logger.info("   • Execution history and performance tracking")
    
    logger.info("\n📈 Analytics Tab:")
    logger.info("   • Portfolio performance metrics")
    logger.info("   • Risk analytics dashboard with VaR")
    logger.info("   • Greeks monitoring and visualization")
    logger.info("   • Real-time P&L tracking")
    
    logger.info("\n💼 Positions Tab:")
    logger.info("   • Active positions monitoring")
    logger.info("   • Portfolio summary with key metrics")
    logger.info("   • Position-level Greeks and P&L")
    logger.info("   • Risk exposure analysis")
    
    logger.info("\n⚙️  Settings Tab:")
    logger.info("   • API configuration and testing")
    logger.info("   • Trading parameter customization")
    logger.info("   • System preferences and themes")
    logger.info("   • Performance optimization settings")

async def main():
    try:
        """Main demo function"""
        logger.info("\n🚀 Starting Comprehensive System Demo...\n")
    
        # Demo strategy selection
        await self.get_production_config()    DEMO COMPLETE - SYSTEM READY FOR TRADING!")
        logger.info("="*60)
    
        logger.info("\n🚀 To launch the full GUI interface, run:")
        logger.info("   python comprehensive_trading_gui.py")
    
        logger.info("\n📚 Key Files Created:")
        logger.info("   • strategy_selection_bot.py - Intelligent strategy selection")
        logger.info("   • market_data_engine.py - Level 1/2/3 data processing")
        logger.info("   • spread_execution_engine.py - Multi-leg execution")
        logger.info("   • advanced_options_strategies.py - 20+ spread strategies")
        logger.info("   • advanced_pricing_models.py - Multiple pricing models")
        logger.info("   • comprehensive_trading_gui.py - Complete GUI interface")
    
        logger.info("\n🎯 System Features:")
        logger.info("   ✅ Intelligent strategy selection based on market conditions")
        logger.info("   ✅ Real-time data from multiple sources (Yahoo, OptionData.org, etc.)")
        logger.info("   ✅ Advanced execution algorithms with slippage control")
        logger.info("   ✅ Professional-grade risk management and monitoring")
        logger.info("   ✅ Comprehensive analytics and performance tracking")
        logger.info("   ✅ Modern GUI with real-time updates and dark theme")
    
        logger.info(f"\n🎊 SUCCESS! Your comprehensive options trading platform is ready!")

    if __name__ == "__main__":
        # Run the demo

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise
    asyncio.run(main()