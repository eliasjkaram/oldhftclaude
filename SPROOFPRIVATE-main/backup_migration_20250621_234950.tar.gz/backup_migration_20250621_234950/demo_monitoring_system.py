#!/usr/bin/env python3
"""
MONITORING SYSTEM DEMONSTRATION
==============================

This script demonstrates the comprehensive monitoring system in action,
showing how to use structured logging, correlation IDs, audit logs,
and performance metrics in a trading context.
"""

import asyncio
import time
import random
from datetime import datetime, timedelta
from typing import Dict, List

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Import monitoring components
from comprehensive_monitoring_system import ()
    get_monitoring_system,
    get_trading_monitor,
    MonitoredLogger
)
from monitoring_integration import ()

from universal_market_data import get_current_market_data, validate_price

    monitor_class,
    monitor_trading_operation,
    monitor_api_call,
    monitor_ml_prediction
)

# Initialize monitoring
monitoring = get_monitoring_system()
trading_monitor = get_trading_monitor()

@monitor_class
class DemoTradingSystem:
    """Demo trading system with comprehensive monitoring"""
    
    def __init__(self):
        self.portfolio_value = 100000.0
        self.positions = {}
        self.logger = MonitoredLogger('DemoTradingSystem')
    
    @monitor_trading_operation("market_analysis")
    def analyze_market(self, symbols: List[str]) -> Dict[str, Dict]:
        """Analyze multiple symbols for trading opportunities"""
        self.logger.info("Starting market analysis", 
                        symbols=symbols,
                        symbol_count=len(symbols)
        
        results = {}
        for symbol in symbols:
            # Simulate analysis
            time.sleep(0.1)
            
            signal = random.choice(['buy', 'sell', 'hold'])
            confidence = random.uniform(0.5, 0.95)
            
            results[symbol] = {}
                'signal': signal,
                'confidence': confidence,
                'rsi': random.uniform(20, 80),
                'macd': random.uniform(-1, 1)
            }
            
            self.logger.info(f"Analysis complete for {symbol}",
                           symbol=symbol,
                           signal=signal,
                           confidence=confidence)
        
        return results
    
    @monitor_ml_prediction("momentum_predictor")
    def predict_momentum(self, symbol: str, features: Dict) -> Dict:
        """Use ML model to predict momentum"""
        # Simulate ML prediction
        time.sleep(0.2)
        
        prediction = {}
            'type': 'momentum',
            'direction': random.choice(['up', 'down']),
            'confidence': random.uniform(0.6, 0.9),
            'timeframe': '1h'
        }
        
        # Update model accuracy metric
        monitoring.metrics.update_model_accuracy()
            'momentum_predictor',
            random.uniform(0.7, 0.85)
        )
        
        return prediction
    
    @monitor_trading_operation("place_order")
    def place_order(self, symbol: str, side: str, quantity: int, order_type: str = 'market'):
        """Place an order with full monitoring"""
        
        # Use the trading monitor for order execution
        with trading_monitor.monitor_order_execution()
            order_type, symbol, side, quantity
        ) as order_id:
            
            self.logger.info(f"Placing {side} order",
                           order_id=order_id,
                           symbol=symbol,
                           quantity=quantity,
                           order_type=order_type)
            
            # Simulate order execution
            time.sleep(random.uniform(0.1, 0.5)
            
            # Random success/failure for demo
            if random.random() > 0.1:  # 90% success rate
                # Update positions
                if side == 'buy':
                    self.positions[symbol] = self.positions.get(symbol, 0) + quantity
                else:
                    self.positions[symbol] = max(0, self.positions.get(symbol, 0) - quantity)
                
                # Update portfolio value (simulate price impact)
                price_impact = random.uniform(-0.001, 0.001)
                self.portfolio_value *= (1 + price_impact)
                
                self.logger.info(f"Order executed successfully",
                               order_id=order_id,
                               fill_price=100 * (1 + price_impact)
                
                return {}
                    'order_id': order_id,
                    'status': 'filled',
                    'fill_price': 100 * (1 + price_impact)
                }
            else:
                # Simulate order failure
                raise Exception("Order rejected by broker")
    
    def update_portfolio_metrics(self):
        """Update portfolio metrics in monitoring system"""
        trading_monitor.monitor_portfolio_update()
            self.portfolio_value,
            self.positions
        )
        
        self.logger.info("Portfolio updated",
                        value=self.portfolio_value,
                        positions=len(self.positions)
    
    @monitor_api_call("market_data/quote", "GET")
    def get_market_quote(self, symbol: str) -> Dict:
        """Get market quote with API monitoring"""
        # Simulate API call
        time.sleep(random.uniform(0.05, 0.15)
        
        return {}
            'symbol': symbol,
            'bid': 100 + random.uniform(-1, 1),
            'ask': 100 + random.uniform(0, 2),
            'last': 100 + random.uniform(-0.5, 0.5),
            'volume': random.randint(1000000, 5000000)
        }
    
    def run_backtest(self, strategy: str, start_date: str, end_date: str):
        """Run a backtest with monitoring"""
        self.logger.info(f"Starting backtest",
                        strategy=strategy,
                        date_range=f"{start_date} to {end_date}")
        
        # Simulate backtest execution
        time.sleep(1)
        
        # Generate random backtest results
        results = {}
            'total_return': random.uniform(-0.1, 0.3),
            'sharpe_ratio': random.uniform(0.5, 2.0),
            'max_drawdown': random.uniform(-0.2, -0.05),
            'win_rate': random.uniform(0.4, 0.7),
            'profit_factor': random.uniform(0.8, 2.5)
        }
        
        # Monitor backtest results
        trading_monitor.monitor_backtest()
            strategy, start_date, end_date, results
        )
        
        return results

async def simulate_trading_session():
    """Simulate a complete trading session with monitoring"""
    
    print("=" * 60)
    print("MONITORING SYSTEM DEMONSTRATION")
    print("=" * 60)
    print(f"Started at: {datetime.now()}")
    print(f"Monitoring Dashboard: http://localhost:5000")
    print(f"Prometheus Metrics: http://localhost:9090/metrics")
    print("=" * 60)
    
    # Create demo trading system
    trading_system = DemoTradingSystem()
    
    # Symbols to trade
    symbols = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA']
    
    # Run trading simulation
    for i in range(5):
        print(f"\n--- Trading Cycle {i+1} ---")
        
        with monitoring.track_request(f'trading_cycle_{i+1}', 
                                    cycle=i+1,
                                    timestamp=datetime.now().isoformat():
            
            # 1. Get market quotes
            print("Fetching market quotes...")
            quotes = {}
            for symbol in symbols:
                quotes[symbol] = trading_system.get_market_quote(symbol)
            
            # 2. Analyze market
            print("Analyzing market conditions...")
            analysis_results = trading_system.analyze_market(symbols)
            
            # 3. ML predictions
            print("Running ML predictions...")
            for symbol in symbols[:3]:  # Run predictions for top 3 symbols
                features = {}
                    'price': quotes[symbol]['last'],
                    'volume': quotes[symbol]['volume'],
                    'rsi': analysis_results[symbol]['rsi']
                }
                prediction = trading_system.predict_momentum(symbol, features)
                print(f"  {symbol}: {prediction['direction']} (confidence: {prediction['confidence']:.2f})")
            
            # 4. Execute trades
            print("Executing trades...")
            for symbol, analysis in analysis_results.items():
                if analysis['confidence'] > 0.8 and analysis['signal'] != 'hold':
                    try:
                        result = trading_system.place_order()
                            symbol=symbol,
                            side=analysis['signal'],
                            quantity=random.randint(10, 100),
                            order_type='market'
                        )
                        print(f"  ✓ {analysis['signal'].upper()} {symbol}: Order {result['order_id'][:8]}...")
                    except Exception as e:
                        print(f"  ✗ Failed to {analysis['signal']} {symbol}: {e}")
            
            # 5. Update portfolio metrics
            trading_system.update_portfolio_metrics()
            print(f"Portfolio Value: ${trading_system.portfolio_value:,.2f}")
            
            # Wait before next cycle
            await asyncio.sleep(2)
    
    # Run a backtest
    print("\n--- Running Backtest ---")
    backtest_results = trading_system.run_backtest()
        'momentum_strategy',
        '2023-01-01',
        '2023-12-31'
    )
    
    print("\nBacktest Results:")
    for metric, value in backtest_results.items():
        print(f"  {metric}: {value:.4f}")
    
    # Check system health
    print("\n--- System Health Check ---")
    health_results = await monitoring.run_health_checks()
    print(f"Overall Status: {health_results['status']}")
    for check_name, check_result in health_results['checks'].items():
        print(f"  {check_name}: {check_result['status']}")
    
    # Display some metrics
    print("\n--- Performance Metrics ---")
    if not monitoring.metrics.PROMETHEUS_AVAILABLE:
        metrics_json = monitoring.metrics.get_metrics()
        print("Sample metrics:")
        print(f"  Orders placed: {monitoring.metrics.local_metrics['orders']}")
        print(f"  API calls: {len(monitoring.metrics.local_metrics['api_requests'])}")
        print(f"  Errors: {len(monitoring.metrics.local_metrics['errors'])}")
    else:
        print("Metrics available at: http://localhost:9090/metrics")
    
    print("\n" + "=" * 60)
    print("DEMONSTRATION COMPLETE")
    print("=" * 60)

def demonstrate_audit_logging():
    """Demonstrate audit logging capabilities"""
    print("\n--- Audit Logging Examples ---")
    
    # Risk limit change
    monitoring.logger.audit()
        'RISK_LIMIT_CHANGED',
        {}
            'user': 'admin',
            'old_limit': 10000,
            'new_limit': 15000,
            'reason': 'Increased trading capital',
            'approval': 'AUTO'
        },
        user='admin',
        ip_address='192.168.1.100'
    )
    print("✓ Logged risk limit change")
    
    # Strategy activation
    monitoring.logger.audit()
        'STRATEGY_ACTIVATED',
        {}
            'strategy': 'mean_reversion_v2',
            'parameters': {}
                'lookback': 20,
                'threshold': 2.0,
                'max_positions': 5
            },
            'activated_by': 'system'
        },
        user='system'
    )
    print("✓ Logged strategy activation")
    
    # Compliance check
    monitoring.logger.audit()
        'COMPLIANCE_CHECK',
        {}
            'check_type': 'position_limits',
            'result': 'PASSED',
            'details': {}
                'total_positions': 8,
                'max_allowed': 10,
                'margin_used': 0.45
            }
        },
        user='compliance_engine'
    )
    print("✓ Logged compliance check")

def demonstrate_correlation_tracking():
    """Demonstrate correlation ID tracking"""
    print("\n--- Correlation ID Tracking ---")
    
    # Simulate a complex operation with multiple steps
    with monitoring.track_request('complex_trade_execution',
                                strategy='pairs_trading',
                                pair=['AAPL', 'MSFT']) as correlation_id:
        
        print(f"Starting complex operation with correlation ID: {correlation_id}")
        
        # Step 1: Analyze correlation
        monitoring.logger.info("Analyzing pair correlation",
                             step=1,
                             pair=['AAPL', 'MSFT'])
        time.sleep(0.1)
        
        # Step 2: Calculate hedge ratio
        monitoring.logger.info("Calculating hedge ratio",
                             step=2,
                             ratio=1.2)
        time.sleep(0.1)
        
        # Step 3: Execute trades
        monitoring.logger.info("Executing pair trades",
                             step=3,
                             trades=[]
                                 {'symbol': 'AAPL', 'side': 'buy', 'quantity': 100},
                                 {'symbol': 'MSFT', 'side': 'sell', 'quantity': 120}
                             ])
        time.sleep(0.1)
        
        print(f"Complex operation completed. All logs have correlation ID: {correlation_id}")

async def main():
    """Main demonstration function"""
    
    # Start monitoring dashboard (in production, this would be separate)
    print("Starting monitoring dashboard on http://localhost:5000")
    
    # Run demonstrations
    demonstrate_audit_logging()
    demonstrate_correlation_tracking()
    
    # Run trading simulation
    await simulate_trading_session()
    
    print("\nCheck the following files for results:")
    print("- monitoring.log: Structured JSON logs")
    print("- orchestration.db: System metrics and events")
    print("\nVisit http://localhost:5000 for the monitoring dashboard")

if __name__ == "__main__":
    try:
        # Run the demonstration
        asyncio.run(main()
    except KeyboardInterrupt:
        print("\nDemonstration stopped by user")
    finally:
        # Stop monitoring
        monitoring.stop_monitoring()
        print("\nMonitoring system stopped")