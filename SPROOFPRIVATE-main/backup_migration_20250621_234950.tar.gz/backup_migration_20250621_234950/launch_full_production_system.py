#!/usr/bin/env python3
"""
LAUNCH FULL PRODUCTION TRADING SYSTEM
=====================================
Start all components for live trading with real money.

WARNING: This will execute REAL trades with REAL money!
Make sure you understand the risks before proceeding.
"""

import os
import sys
import subprocess
import time
import threading
from datetime import datetime
import signal
import atexit

# Global process list for cleanup
processes = []

def cleanup():
    """Clean up all processes on exit"""
    print("\n🛑 Shutting down trading systems...")
    for proc in processes:
        try:
            proc.terminate()
        except:
            pass
    time.sleep(2)
    for proc in processes:
        try:
            proc.kill()
        except:
            pass
    print("✅ All systems stopped")

# Register cleanup
atexit.register(cleanup)
signal.signal(signal.SIGINT, lambda x, y: sys.exit(0))

def check_prerequisites():
    """Check all prerequisites before launching"""
    print("🔍 Checking prerequisites...")
    
    # Check for API credentials
    checks = {}
        'ALPACA_API_KEY': os.getenv('ALPACA_API_KEY'),
        'ALPACA_API_SECRET': os.getenv('ALPACA_API_SECRET'),
        'OPENROUTER_API_KEY': os.getenv('OPENROUTER_API_KEY'),
    }
    
    missing = [k for k, v in checks.items() if not v]
    if missing:
        print(f"❌ Missing credentials: {', '.join(missing)}")
        print("\n📝 Please set up your .env file with:")
        print("   ALPACA_API_KEY=your_key")
        print("   ALPACA_API_SECRET=your_secret")
        print("   OPENROUTER_API_KEY=your_key")
        return False
    
    # Check if using paper or live trading
    if os.getenv('ALPACA_PAPER_TRADING', 'true').lower() == 'true':
        print("📋 Using PAPER trading account (safe mode)")
    else:
        print("💰 Using LIVE trading account (REAL MONEY)")
        response = input("\n⚠️  WARNING: This will trade with REAL MONEY. Continue? (yes/no): ")
        if response.lower() != 'yes':
            print("❌ Cancelled by user")
            return False
    
    print("✅ All prerequisites met")
    return True

def start_component(name, command, critical=True):
    """Start a system component"""
    print(f"\n🚀 Starting {name}...")
    try:
        proc = subprocess.Popen()
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        processes.append(proc)
        
        # Check if process started successfully
        time.sleep(2)
        if proc.poll() is not None:
            print(f"❌ {name} failed to start")
            if critical:
                return False
        else:
            print(f"✅ {name} running (PID: {proc.pid})")
        return True
    except Exception as e:
        print(f"❌ Error starting {name}: {e}")
        return False

def monitor_system():
    """Monitor system health in background"""
    def monitor_loop():
        while True:
            try:
                # Check process health
                for i, proc in enumerate(processes):
                    if proc.poll() is not None:
                        print(f"\n⚠️  Process {i} has stopped")
                
                time.sleep(30)
            except:
                break
    
    monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
    monitor_thread.start()

def show_system_status():
    """Display current system status"""
    print("\n" + "=" * 80)
    print("📊 SYSTEM STATUS")
    print("=" * 80)
    
    try:
        from universal_market_data import get_current_market_data
        
        # Get current market prices
        symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'SPY']
        data = get_current_market_data(symbols)
        
        print("\n🔴 LIVE MARKET PRICES:")
        for symbol, info in data.items():
            print(f"  {symbol}: ${info['price']:.2f}")
        
        # Check account status
        from alpaca.trading.client import TradingClient
        api_key = os.getenv('ALPACA_API_KEY')
        api_secret = os.getenv('ALPACA_API_SECRET')
        paper = os.getenv('ALPACA_PAPER_TRADING', 'true').lower() == 'true'
        
        trading_client = TradingClient(api_key, api_secret, paper=paper)
        account = trading_client.get_account()
        
        print(f"\n💰 ACCOUNT STATUS:")
        print(f"  Buying Power: ${float(account.buying_power):,.2f}")
        print(f"  Portfolio Value: ${float(account.portfolio_value):,.2f}")
        print(f"  Cash: ${float(account.cash):,.2f}")
        print(f"  Day Trading Allowed: {'Yes' if account.pattern_day_trader else 'No'}")
        
    except Exception as e:
        print(f"\n❌ Error getting status: {e}")

def main():
    print("=" * 80)
    print("🚀 ALPACA TRADING SYSTEM - FULL PRODUCTION LAUNCH")
    print("=" * 80)
    print(f"Timestamp: {datetime.now()}")
    print("=" * 80)
    
    # Check prerequisites
    if not check_prerequisites():
        return
    
    # Kill any existing processes
    print("\n🔄 Cleaning up existing processes...")
    subprocess.run("pkill -f 'python.*trading'", shell=True, stderr=subprocess.DEVNULL)
    subprocess.run("pkill -f 'python.*ai.*discovery'", shell=True, stderr=subprocess.DEVNULL)
    subprocess.run("pkill -f 'python.*monitor'", shell=True, stderr=subprocess.DEVNULL)
    time.sleep(3)
    
    # Start core components in order
    components = []
        ("Market Data Provider", "python universal_market_data.py --daemon", True),
        ("AI Discovery System", "python fix_ai_discovery_system.py", True),
        ("AI Trading Engine", "python realtime_ai_trading.py", True),
        ("Production Trading System", "python PRODUCTION_DEPLOYMENT_FINAL.py", True),
        ("Risk Management System", "python production_risk_management.py", True),
        ("Portfolio Optimizer", "python production_optimization_system.py", False),
        ("Options Trading System", "python advanced_options_strategies.py", False),
        ("Monitoring Dashboard", "python unified_monitoring_dashboard.py", False),
    ]
    
    print("\n🎯 STARTING ALL SYSTEMS...")
    print("=" * 80)
    
    success_count = 0
    for name, command, critical in components:
        if start_component(name, command, critical):
            success_count += 1
        elif critical:
            print("\n❌ Critical component failed. Aborting launch.")
            cleanup()
            return
        time.sleep(3)
    
    print(f"\n✅ Successfully started {success_count}/{len(components)} components")
    
    # Start system monitoring
    monitor_system()
    
    # Show system status
    show_system_status()
    
    # Launch GUI if available
    print("\n🖥️  Launching Trading GUI...")
    try:
        gui_proc = subprocess.Popen()
            "python ULTIMATE_PRODUCTION_TRADING_GUI.py",
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        processes.append(gui_proc)
        print("✅ GUI launched")
    except:
        print("⚠️  GUI launch failed (optional component)")
    
    print("\n" + "=" * 80)
    print("🎉 FULL PRODUCTION SYSTEM LAUNCHED!")
    print("=" * 80)
    print("\n📊 LIVE TRADING ACTIVE - MAKING MONEY 24/7")
    print("\n🔍 Monitor with:")
    print("  • GUI: Check the opened window")
    print("  • Logs: tail -f trading_*.log")
    print("  • Dashboard: http://localhost:8080")
    print("\n⚠️  IMPORTANT:")
    print("  • System is now executing REAL trades")
    print("  • Monitor your positions carefully")
    print("  • Set appropriate risk limits")
    print("  • Press Ctrl+C to stop all systems")
    
    # Keep main process alive
    try:
        while True:
            time.sleep(60)
            # Periodic status update
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] System running... {len([p for p in processes if p.poll() is None])}/{len(processes)} components active")
    except KeyboardInterrupt:
        print("\n\n🛑 Shutdown requested...")
        cleanup()

if __name__ == "__main__":
    main()