#!/usr/bin/env python3
"""
Fix Remaining Hardcoded Credentials
===================================
This script fixes all remaining hardcoded credentials in Python files.
"""

import os
import re
import sys
from pathlib import Path
from typing import List, Dict, Tuple

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Import the SecureConfigManager
sys.path.append(os.path.dirname(os.path.abspath(__file__))
from PRODUCTION_FIXES import SecureConfigManager

# Files to skip (already fixed or templates)
SKIP_FILES = {}
    'market_data_collector.py',
    'core/config_manager.py',
    'fix_all_credentials.py',
    'fix_remaining_credentials.py',
    'PRODUCTION_FIXES.py',
    'fix_security.py',  # This file contains credential patterns as examples
}

def should_skip_file(filepath: str) -> bool:
    """Check if file should be skipped"""
    # Skip if in skip list
    for skip in SKIP_FILES:
        if filepath.endswith(skip):
            return True
    
    # Skip test files and backups
    if '/test' in filepath or '/backup' in filepath or '/.git' in filepath:
        return True
    
    return False

def fix_alpaca_credentials(content: str) -> str:
    """Fix Alpaca API credentials in content"""
    # Fix paper API key
    content = re.sub()
        r"['\"]<ALPACA_PAPER_KEY>['\"]",
        "secure_config.get_credential('ALPACA_PAPER_KEY')",
        content
    )
    
    # Fix paper API secret
    content = re.sub()
        r"['\"]<ALPACA_PAPER_SECRET>['\"]",
        "secure_config.get_credential('ALPACA_PAPER_SECRET')",
        content
    )
    
    # Fix live API key
    content = re.sub()
        r".*?<ALPACA_LIVE_KEY>.*?"]",
        "secure_config.get_credential('ALPACA_LIVE_KEY')",
        content
    )
    
    # Fix live API secret
    content = re.sub()
        r"['\"]<ALPACA_LIVE_SECRET>['\"]",
        "secure_config.get_credential('ALPACA_LIVE_SECRET')",
        content
    )
    
    # Fix other API key patterns
    content = re.sub()
        r".*?<ALPACA_PAPER_KEY>.*?"]",
        "secure_config.get_credential('ALPACA_PAPER_KEY')",
        content
    )
    
    return content

def fix_minio_credentials(content: str) -> str:
    """Fix MinIO credentials in content"""
    # Fix access key patterns
    patterns = []
        (r'access_key\s*=\s*["\']minioadmin["\']', 'access_key=secure_config.get_credential("MINIO_ACCESS_KEY")'),
        (r'secret_key\s*=\s*["\']minioadmin["\']', 'secret_key=secure_config.get_credential("MINIO_SECRET_KEY")'),
        (r"os\.getenv\('MINIO_ACCESS_KEY',\s*'minioadmin'\)", 'secure_config.get_credential("MINIO_ACCESS_KEY")'),
        (r"os\.getenv\('MINIO_SECRET_KEY',\s*'minioadmin'\)", 'secure_config.get_credential("MINIO_SECRET_KEY")'),
    ]
    
    for pattern, replacement in patterns:
        content = re.sub(pattern, replacement, content)
    
    return content

def add_secure_config_import(content: str, filepath: str) -> str:
    """Add SecureConfigManager import if needed"""
    # Check if SecureConfigManager is used but not imported
    if 'secure_config' in content and 'from PRODUCTION_FIXES import SecureConfigManager' not in content:
        lines = content.split('\n')
        
        # Find where to insert the import
        import_index = 0
        for i, line in enumerate(lines):
            if line.startswith('import ') or line.startswith('from '):
                import_index = i + 1
            elif import_index > 0 and line.strip() and not line.startswith('#'):
                # Found first non-import line after imports
                break
        
        # Insert the import
        lines.insert(import_index, 'from PRODUCTION_FIXES import SecureConfigManager')
        
        # Also add initialization if needed
        init_needed = True
        for line in lines:
            if 'secure_config = SecureConfigManager()' in line:
                init_needed = False
                break
        
        if init_needed:
            # Find where to initialize (usually at the beginning of a class or function)
            for i, line in enumerate(lines):
                if 'secure_config.get_credential' in line:
                    # Find the context (class or function) where it's used
                    j = i
                    while j > 0:
                        if lines[j].strip().startswith('def ') or lines[j].strip().startswith('class '):
                            # Insert after the definition line
                            indent = '    ' if lines[j].strip().startswith('def ') else '        '
                            lines.insert(j + 1, f'{indent}secure_config = SecureConfigManager()')
                            break
                        j -= 1
                    break
        
        content = '\n'.join(lines)
    
    return content

def fix_file(filepath: str) -> bool:
    """Fix credentials in a single file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            original_content = f.read()
        
        # Skip if no credentials found
        if not any(cred in original_content for cred in [)
            '<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_SECRET>',
            os.getenv('ALPACA_LIVE_API_KEY'), os.getenv('ALPACA_LIVE_API_SECRET'),
            'minioadmin', os.getenv('ALPACA_PAPER_API_KEY')
        ]):
            return False
        
        # Fix credentials
        content = fix_alpaca_credentials(original_content)
        content = fix_minio_credentials(content)
        
        # Add imports if needed
        if content != original_content:
            content = add_secure_config_import(content, filepath)
        
        # Write back if changed
        if content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        
        return False
        
    except Exception as e:
        print(f"Error processing {filepath}: {e}")
        return False

def main():
    """Main function to fix remaining credentials"""
    print("🔐 Fixing remaining hardcoded credentials...")
    print("=" * 60)
    
    # Find all Python files
    python_files = []
    for path in Path('/home/harry/alpaca-mcp').rglob('*.py'):
        if not should_skip_file(str(path):
            python_files.append(str(path)
    
    print(f"Found {len(python_files)} Python files to check...")
    
    fixed_count = 0
    for filepath in python_files:
        if fix_file(filepath):
            print(f"✅ Fixed: {filepath}")
            fixed_count += 1
    
    print("\n" + "=" * 60)
    print(f"✅ Fixed {fixed_count} files")
    
    # Create a secure config template
    create_secure_config_template()
    
    print("\n📋 NEXT STEPS:")
    print("1. Review the changes to ensure they're correct")
    print("2. Test that all services can connect with environment variables")
    print("3. Set up your .env file with actual credentials")
    print("4. Never commit the .env file to version control!")

def create_secure_config_template():
    """Create a template for secure configuration"""
    template = """#!/usr/bin/env python3
\"\"\"
Secure Configuration Template
============================
Example of how to use SecureConfigManager in your code
\"\"\"

from PRODUCTION_FIXES import SecureConfigManager

# Initialize secure config manager
secure_config = SecureConfigManager()

# Example: Initialize Alpaca client
from alpaca.trading.client import TradingClient

# Paper trading client
paper_client = TradingClient()
    secure_config.get_credential('ALPACA_PAPER_KEY'),
    secure_config.get_credential('ALPACA_PAPER_SECRET'),
    paper=True
)

# Live trading client
live_client = TradingClient()
    secure_config.get_credential('ALPACA_LIVE_KEY'),
    secure_config.get_credential('ALPACA_LIVE_SECRET'),
    paper=False
)

# Example: Initialize MinIO client
from minio import Minio

from universal_market_data import get_current_market_data, validate_price


minio_client = Minio()
    'your-minio-endpoint.com',
    access_key=secure_config.get_credential('MINIO_ACCESS_KEY'),
    secret_key=secure_config.get_credential('MINIO_SECRET_KEY'),
    secure=True
)

print("✅ All credentials loaded securely from environment!")
"""
    
    with open('/home/harry/alpaca-mcp/secure_config_example.py', 'w') as f:
        f.write(template)
    
    print("\n📄 Created secure_config_example.py with usage examples")

if __name__ == "__main__":
    main()