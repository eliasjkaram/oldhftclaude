#!/usr/bin/env python3
"""
DATA PIPELINE WITH MINIO STORAGE
================================
Complete data pipeline: MinIO → Feature Engineering → ML Training → Real-time Trading
"""

import os
import sys
import json
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple
import asyncio
import joblib
from io import BytesIO
import pickle

# MinIO client
from minio import Minio
from minio.error import S3Error

# ML libraries
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import train_test_split, TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, r2_score
import xgboost as xgb
import lightgbm as lgb

# Alpaca
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient, OptionHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame

# Technical analysis
import talib

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DataPipelineMinIO:
    """Complete data pipeline with MinIO storage"""
    
    def __init__(self):
        # MinIO configuration
        self.minio_endpoint = os.getenv('MINIO_ENDPOINT', 'localhost:9000')
        self.minio_access_key = os.getenv('MINIO_ACCESS_KEY', 'minioadmin')
        self.minio_secret_key = os.getenv('MINIO_SECRET_KEY', 'minioadmin')
        
        # Initialize MinIO client
        try:
            self.minio_client = Minio()
                self.minio_endpoint,
                access_key=self.minio_access_key,
                secret_key=self.minio_secret_key,
                secure=False  # Set to True for HTTPS
            )
            
            # Create buckets if they don't exist
            buckets = ['historical-data', 'features', 'models', 'predictions', 'trades']
            for bucket in buckets:
                if not self.minio_client.bucket_exists(bucket):
                    self.minio_client.make_bucket(bucket)
                    logger.info(f"Created MinIO bucket: {bucket}")
            
            logger.info("✅ MinIO connection established")
            
        except Exception as e:
            logger.error(f"MinIO connection failed: {e}")
            logger.info("Continuing without MinIO storage")
            self.minio_client = None
        
        # Alpaca configuration
        self.api_key = os.getenv('ALPACA_API_KEY', 'PKEP9PIBDKOSUGHHY44Z')
        self.api_secret = os.getenv('ALPACA_API_SECRET', 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ')
        
        # Initialize Alpaca clients
        self.trading_client = TradingClient(self.api_key, self.api_secret, paper=True)
        self.stock_data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        # ML models
        self.models = {}
            'xgboost': None,
            'lightgbm': None,
            'random_forest': None,
            'neural_network': None,
            'ensemble': None
        }
        
        self.scalers = {}
            'standard': StandardScaler(),
            'robust': RobustScaler()
        }
        
        # Feature engineering parameters
        self.technical_indicators = {}
            'sma': [5, 10, 20, 50, 200],
            'ema': [12, 26],
            'rsi': [14],
            'macd': [(12, 26, 9)],
            'bb': [20],
            'atr': [14],
            'adx': [14],
            'cci': [20],
            'mfi': [14],
            'obv': [],
            'stoch': [(14, 3, 3)]
        }
        
        logger.info("Data Pipeline initialized")
    
    def store_to_minio(self, bucket: str, object_name: str, data):
        """Store data to MinIO"""
        if not self.minio_client:
            return False
            
        try:
            # Convert data to bytes
            if isinstance(data, pd.DataFrame):
                buffer = BytesIO()
                data.to_parquet(buffer)
                data_bytes = buffer.getvalue()
            elif isinstance(data, dict):
                data_bytes = json.dumps(data).encode('utf-8')
            else:
                data_bytes = pickle.dumps(data)
            
            # Upload to MinIO
            self.minio_client.put_object()
                bucket,
                object_name,
                BytesIO(data_bytes),
                length=len(data_bytes)
            )
            
            logger.info(f"Stored {object_name} to MinIO bucket: {bucket}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing to MinIO: {e}")
            return False
    
    def load_from_minio(self, bucket: str, object_name: str):
        """Load data from MinIO"""
        if not self.minio_client:
            return None
            
        try:
            # Get object
            response = self.minio_client.get_object(bucket, object_name)
            data_bytes = response.read()
            
            # Decode based on file extension
            if object_name.endswith('.parquet'):
                return pd.read_parquet(BytesIO(data_bytes))
            elif object_name.endswith('.json'):
                return json.loads(data_bytes.decode('utf-8'))
            else:
                return pickle.loads(data_bytes)
                
        except Exception as e:
            logger.error(f"Error loading from MinIO: {e}")
            return None
    
    def get_stock_data(self, symbol: str, start_date: str, end_date: str) -> Optional[pd.DataFrame]:
        """Get historical stock data from MinIO or fetch if not available"""
        if not self.minio_client:
            return None
            
        try:
            # Convert dates to datetime
            start_dt = pd.to_datetime(start_date)
            end_dt = pd.to_datetime(end_date)
            
            # Try to load from MinIO first
            object_name = f"{symbol}_historical_{end_dt.strftime('%Y%m%d')}.parquet"
            df = self.load_from_minio('historical-data', object_name)
            
            if df is not None:
                # Filter by date range
                df = df[(df.index >= start_dt) & (df.index <= end_dt)]
                if not df.empty:
                    logger.info(f"Retrieved {len(df)} records from MinIO for {symbol}")
                    return df
            
            # If not in MinIO, fetch from Alpaca
            logger.info(f"Data not in MinIO, fetching from Alpaca for {symbol}")
            self.fetch_and_store_historical_data([symbol], days=(end_dt - start_dt).days)
            
            # Try loading again
            df = self.load_from_minio('historical-data', object_name)
            if df is not None:
                df = df[(df.index >= start_dt) & (df.index <= end_dt)]
                return df
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting stock data: {e}")
            return None
    
    def fetch_and_store_historical_data(self, symbols: List[str], days: int = 365):
        """Fetch historical data and store in MinIO"""
        for symbol in symbols:
            try:
                # Check if data already exists in MinIO
                object_name = f"{symbol}_historical_{datetime.now().strftime('%Y%m%d')}.parquet"
                existing_data = self.load_from_minio('historical-data', object_name)
                
                if existing_data is not None:
                    logger.info(f"Historical data for {symbol} already exists in MinIO")
                    continue
                
                # Fetch from Alpaca
                end_date = datetime.now()
                start_date = end_date - timedelta(days=days)
                
                request = StockBarsRequest()
                    symbol_or_symbols=symbol,
                    timeframe=TimeFrame.Day,
                    start=start_date,
                    end=end_date
                )
                
                bars = self.stock_data_client.get_stock_bars(request)
                
                # Convert to DataFrame
                data = []
                for bar in bars[symbol]:
                    data.append({)
                        'timestamp': bar.timestamp,
                        'open': bar.open,
                        'high': bar.high,
                        'low': bar.low,
                        'close': bar.close,
                        'volume': bar.volume,
                        'vwap': bar.vwap
                    })
                
                df = pd.DataFrame(data)
                df.set_index('timestamp', inplace=True)
                
                # Store to MinIO
                self.store_to_minio('historical-data', object_name, df)
                
                logger.info(f"Fetched and stored {len(df)} days of data for {symbol}")
                
            except Exception as e:
                logger.error(f"Error fetching data for {symbol}: {e}")
    
    def engineer_features(self, df: pd.DataFrame, symbol: str) -> pd.DataFrame:
        """Comprehensive feature engineering"""
        try:
            # Basic price features
            df['returns'] = df['close'].pct_change()
            df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_open_ratio'] = df['close'] / df['open']
            
            # Moving averages
            for period in self.technical_indicators['sma']:
                df[f'sma_{period}'] = talib.SMA(df['close'].values, timeperiod=period)
                df[f'sma_ratio_{period}'] = df['close'] / df[f'sma_{period}']
            
            for period in self.technical_indicators['ema']:
                df[f'ema_{period}'] = talib.EMA(df['close'].values, timeperiod=period)
            
            # RSI
            for period in self.technical_indicators['rsi']:
                df[f'rsi_{period}'] = talib.RSI(df['close'].values, timeperiod=period)
            
            # MACD
            for fast, slow, signal in self.technical_indicators['macd']:
                macd, macdsignal, macdhist = talib.MACD(df['close'].values, 
                                                        fastperiod=fast, 
                                                        slowperiod=slow, 
                                                        signalperiod=signal)
                df['macd'] = macd
                df['macd_signal'] = macdsignal
                df['macd_hist'] = macdhist
            
            # Bollinger Bands
            for period in self.technical_indicators['bb']:
                upper, middle, lower = talib.BBANDS(df['close'].values, timeperiod=period)
                df['bb_upper'] = upper
                df['bb_middle'] = middle
                df['bb_lower'] = lower
                df['bb_width'] = upper - lower
                df['bb_position'] = (df['close'] - lower) / (upper - lower)
            
            # ATR (Average True Range)
            for period in self.technical_indicators['atr']:
                df[f'atr_{period}'] = talib.ATR(df['high'].values, df['low'].values, 
                                                df['close'].values, timeperiod=period)
            
            # ADX (Average Directional Index)
            for period in self.technical_indicators['adx']:
                df[f'adx_{period}'] = talib.ADX(df['high'].values, df['low'].values, 
                                                df['close'].values, timeperiod=period)
            
            # CCI (Commodity Channel Index)
            for period in self.technical_indicators['cci']:
                df[f'cci_{period}'] = talib.CCI(df['high'].values, df['low'].values, 
                                                df['close'].values, timeperiod=period)
            
            # MFI (Money Flow Index)
            for period in self.technical_indicators['mfi']:
                df[f'mfi_{period}'] = talib.MFI(df['high'].values, df['low'].values, 
                                                df['close'].values, df['volume'].values, 
                                                timeperiod=period)
            
            # OBV (On Balance Volume)
            df['obv'] = talib.OBV(df['close'].values, df['volume'].values)
            
            # Stochastic
            for fastk, slowk, slowd in self.technical_indicators['stoch']:
                slowk, slowd = talib.STOCH(df['high'].values, df['low'].values, df['close'].values,
                                          fastk_period=fastk, slowk_period=slowk, slowd_period=slowd)
                df['stoch_k'] = slowk
                df['stoch_d'] = slowd
            
            # Volume features
            df['volume_sma'] = df['volume'].rolling(window=20).mean()
            df['volume_ratio'] = df['volume'] / df['volume_sma']
            
            # Volatility features
            df['volatility_20'] = df['returns'].rolling(window=20).std()
            df['volatility_60'] = df['returns'].rolling(window=60).std()
            
            # Price patterns
            df['resistance_20'] = df['high'].rolling(window=20).max()
            df['support_20'] = df['low'].rolling(window=20).min()
            df['sr_position'] = (df['close'] - df['support_20']) / (df['resistance_20'] - df['support_20'])
            
            # Momentum
            df['momentum_10'] = df['close'] - df['close'].shift(10)
            df['roc_10'] = talib.ROC(df['close'].values, timeperiod=10)
            
            # Market microstructure
            df['spread'] = df['high'] - df['low']
            df['spread_pct'] = df['spread'] / df['close']
            
            # Time features
            df['day_of_week'] = df.index.dayofweek
            df['month'] = df.index.month
            df['quarter'] = df.index.quarter
            
            # Target variables for ML
            df['future_return_1d'] = df['returns'].shift(-1)
            df['future_return_5d'] = df['close'].shift(-5) / df['close'] - 1
            df['future_direction'] = (df['future_return_1d'] > 0).astype(int)
            df['future_volatility'] = df['returns'].shift(-5).rolling(window=5).std()
            
            # Clean data
            df.dropna(inplace=True)
            
            # Store engineered features to MinIO
            feature_name = f"{symbol}_features_{datetime.now().strftime('%Y%m%d')}.parquet"
            self.store_to_minio('features', feature_name, df)
            
            logger.info(f"Engineered {len(df.columns)} features for {symbol}")
            return df
            
        except Exception as e:
            logger.error(f"Error engineering features: {e}")
            return df
    
    def train_ensemble_models(self, symbols: List[str]):
        """Train ensemble of ML models"""
        logger.info("Training ensemble models...")
        
        # Collect all feature data
        all_features = []
        
        for symbol in symbols:
            # Load features from MinIO
            feature_name = f"{symbol}_features_{datetime.now().strftime('%Y%m%d')}.parquet"
            df = self.load_from_minio('features', feature_name)
            
            if df is None:
                # If not in MinIO, generate features
                hist_data = self.load_from_minio('historical-data', 
                                                f"{symbol}_historical_{datetime.now().strftime('%Y%m%d')}.parquet")
                if hist_data is not None:
                    df = self.engineer_features(hist_data, symbol)
                    all_features.append(df)
            else:
                all_features.append(df)
        
        if not all_features:
            logger.error("No feature data available for training")
            return
        
        # Combine all data
        combined_df = pd.concat(all_features)
        
        # Define features
        feature_cols = [col for col in combined_df.columns]
                       if not col.startswith('future_') and col not in ['open', 'high', 'low', 'close', 'volume']]
        
        X = combined_df[feature_cols]
        y_return = combined_df['future_return_1d']
        y_direction = combined_df['future_direction']
        
        # Scale features
        X_scaled = self.scalers['standard'].fit_transform(X)
        
        # Time series split
        tscv = TimeSeriesSplit(n_splits=5)
        
        # Train XGBoost
        logger.info("Training XGBoost...")
        self.models['xgboost'] = xgb.XGBRegressor()
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        self.models['xgboost'].fit(X_scaled, y_return)
        
        # Train LightGBM
        logger.info("Training LightGBM...")
        self.models['lightgbm'] = lgb.LGBMRegressor()
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        self.models['lightgbm'].fit(X_scaled, y_return)
        
        # Train Random Forest
        logger.info("Training Random Forest...")
        self.models['random_forest'] = RandomForestRegressor()
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.models['random_forest'].fit(X_scaled, y_return)
        
        # Train Neural Network
        logger.info("Training Neural Network...")
        self.models['neural_network'] = MLPRegressor()
            hidden_layer_sizes=(100, 50),
            activation='relu',
            max_iter=500,
            random_state=42
        )
        self.models['neural_network'].fit(X_scaled, y_return)
        
        # Save models to MinIO
        for model_name, model in self.models.items():
            if model is not None:
                model_filename = f"{model_name}_model_{datetime.now().strftime('%Y%m%d')}.pkl"
                self.store_to_minio('models', model_filename, model)
        
        # Save scalers
        self.store_to_minio('models', 'scalers.pkl', self.scalers)
        
        logger.info("Model training completed and saved to MinIO")
    
    def make_ensemble_prediction(self, symbol: str) -> Dict:
        """Make prediction using ensemble of models"""
        try:
            # Get latest features
            feature_name = f"{symbol}_features_{datetime.now().strftime('%Y%m%d')}.parquet"
            df = self.load_from_minio('features', feature_name)
            
            if df is None:
                # Generate features if not available
                hist_data = self.fetch_and_store_historical_data([symbol], days=100)
                df = self.engineer_features(hist_data, symbol)
            
            # Get latest row
            feature_cols = [col for col in df.columns]
                          if not col.startswith('future_') and col not in ['open', 'high', 'low', 'close', 'volume']]
            
            latest_features = df[feature_cols].iloc[-1].values.reshape(1, -1)
            latest_features_scaled = self.scalers['standard'].transform(latest_features)
            
            # Make predictions from all models
            predictions = {}
            confidences = []
            
            for model_name, model in self.models.items():
                if model is not None:
                    pred = model.predict(latest_features_scaled)[0]
                    predictions[model_name] = pred
                    
                    # Simple confidence based on model type
                    if model_name == 'xgboost':
                        confidences.append(0.3)
                    elif model_name == 'lightgbm':
                        confidences.append(0.3)
                    elif model_name == 'random_forest':
                        confidences.append(0.2)
                    elif model_name == 'neural_network':
                        confidences.append(0.2)
            
            # Ensemble prediction (weighted average)
            ensemble_pred = np.average(list(predictions.values()), weights=confidences)
            
            # Calculate overall confidence
            pred_std = np.std(list(predictions.values()))
            confidence = max(0.5, min(0.95, 1 - pred_std * 10))
            
            result = {}
                'symbol': symbol,
                'timestamp': datetime.now(),
                'ensemble_prediction': ensemble_pred,
                'confidence': confidence,
                'individual_predictions': predictions,
                'current_price': df['close'].iloc[-1],
                'features': {}
                    'rsi': df['rsi_14'].iloc[-1] if 'rsi_14' in df else None,
                    'macd': df['macd'].iloc[-1] if 'macd' in df else None,
                    'bb_position': df['bb_position'].iloc[-1] if 'bb_position' in df else None,
                    'volume_ratio': df['volume_ratio'].iloc[-1] if 'volume_ratio' in df else None
                }
            }
            
            # Store prediction to MinIO
            pred_filename = f"prediction_{symbol}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            self.store_to_minio('predictions', pred_filename, result)
            
            return result
            
        except Exception as e:
            logger.error(f"Error making prediction for {symbol}: {e}")
            return None
    
    async def run_pipeline(self):
        """Run the complete data pipeline"""
        logger.info("Starting Data Pipeline with MinIO")
        
        # Symbols to trade
        symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'META', 'NVDA', 'SPY', 'QQQ']
        
        # Step 1: Fetch and store historical data
        logger.info("Step 1: Fetching historical data...")
        self.fetch_and_store_historical_data(symbols)
        
        # Step 2: Engineer features
        logger.info("Step 2: Engineering features...")
        for symbol in symbols:
            hist_data = self.load_from_minio('historical-data', 
                                           f"{symbol}_historical_{datetime.now().strftime('%Y%m%d')}.parquet")
            if hist_data is not None:
                self.engineer_features(hist_data, symbol)
        
        # Step 3: Train models
        logger.info("Step 3: Training models...")
        self.train_ensemble_models(symbols)
        
        # Step 4: Real-time prediction loop
        logger.info("Step 4: Starting real-time predictions...")
        
        iteration = 0
        while True:
            try:
                iteration += 1
                
                print(f"\n{'=' * 100}")
                print(f"🔄 DATA PIPELINE - Iteration {iteration}")
                print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print("=" * 100)
                
                # Make predictions for all symbols
                predictions = []
                for symbol in symbols:
                    pred = self.make_ensemble_prediction(symbol)
                    if pred:
                        predictions.append(pred)
                
                # Display predictions
                print("\n📊 ENSEMBLE PREDICTIONS:")
                print(f"{'Symbol':^10} | {'Prediction':^12} | {'Confidence':^10} | {'Current Price':^12}")
                print("-" * 60)
                
                for pred in predictions:
                    direction = "↑" if pred['ensemble_prediction'] > 0 else "↓"
                    print(f"{pred['symbol']:^10} | ")
                          f"{direction} {abs(pred['ensemble_prediction']*100):>6.2f}% | "
                          f"{pred['confidence']:.1%} | "
                          f"${pred['current_price']:>10.2f}")
                
                # Show model consensus
                print("\n🤖 MODEL CONSENSUS:")
                for pred in predictions[:5]:  # Top 5
                    print(f"\n{pred['symbol']}:")
                    for model, value in pred['individual_predictions'].items():
                        print(f"  {model}: {value*100:+.2f}%")
                
                # Feature insights
                print("\n📈 TECHNICAL INDICATORS:")
                for pred in predictions[:5]:
                    print(f"\n{pred['symbol']}:")
                    for feat, value in pred['features'].items():
                        if value is not None:
                            print(f"  {feat}: {value:.2f}")
                
                print(f"\n⏳ Next prediction cycle in 60 seconds...")
                await asyncio.sleep(60)
                
            except KeyboardInterrupt:
                print("\n\n🛑 Stopping Data Pipeline...")
                break
            except Exception as e:
                logger.error(f"Pipeline error: {e}")
                await asyncio.sleep(60)

async def main():
    """Main entry point"""
    print("=" * 100)
    print("📊 DATA PIPELINE WITH MINIO STORAGE")
    print("=" * 100)
    print("\nPipeline Flow:")
    print("  1️⃣  Historical Data → MinIO Storage")
    print("  2️⃣  Feature Engineering (50+ indicators)")
    print("  3️⃣  ML Training (XGBoost, LightGBM, RF, NN)")
    print("  4️⃣  Real-time Predictions")
    print("  5️⃣  Trade Execution")
    print("\n✅ Features:")
    print("  • MinIO object storage for scalability")
    print("  • Ensemble model predictions")
    print("  • Comprehensive technical indicators")
    print("  • Real-time confidence scoring")
    print("  • Historical data caching")
    
    pipeline = DataPipelineMinIO()
    await pipeline.run_pipeline()

if __name__ == "__main__":
    asyncio.run(main())