
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
HYPER AGGRESSIVE TRADING SYSTEM
================================
Forces trades with lower thresholds and aggressive parameters
"""

import asyncio
import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
import json
import time
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import concurrent.futures
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame
import warnings

from universal_market_data import get_current_market_data, validate_price

warnings.filterwarnings('ignore')

logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Alpaca credentials
API_KEY = os.getenv('ALPACA_PAPER_API_KEY')
SECRET_KEY = os.getenv('ALPACA_PAPER_API_SECRET')
BASE_URL = "https://paper-api.alpaca.markets"

@dataclass
class AggressiveTrade:
    symbol: str
    direction: str
    quantity: int
    entry_price: float
    entry_time: datetime
    strategy: str
    confidence: float
    order_id: str = ""
    exit_price: Optional[float] = None
    exit_time: Optional[datetime] = None
    pnl: Optional[float] = None

class HyperAggressiveTrader:
    """Hyper aggressive trader that forces trades"""
    
    def __init__(self):
        # Initialize Alpaca
        self.trading_client = TradingClient(API_KEY, SECRET_KEY, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.data_client = StockHistoricalDataClient(API_KEY, SECRET_KEY)
        
        # Get account info
        self.account = self.trading_client.get_account()
        self.initial_capital = float(self.account.equity)
        
        logger.info(f"🔥🔥🔥 HYPER AGGRESSIVE TRADER INITIALIZED 🔥🔥🔥")
        logger.info(f"💰 Account Equity: ${self.initial_capital:,.2f}")
        logger.info(f"💵 Buying Power: ${float(self.account.buying_power):,.2f}")
        
        # ULTRA AGGRESSIVE PARAMETERS
        self.min_confidence = 0.40  # Very low threshold - 40%!
        self.stop_loss_pct = 0.005  # 0.5% tight stop
        self.take_profit_pct = 0.01  # 1% quick profit
        self.max_position_pct = 0.10  # 10% per position
        self.max_positions = 50  # Many positions
        self.force_trade_probability = 0.70  # 70% chance to force a trade!
        
        # High volatility symbols for maximum action
        self.symbols = []
            # Mega tech
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META',
            # High volatility
            'GME', 'AMC', 'PLTR', 'SOFI', 'HOOD', 'COIN', 'RBLX',
            # ETFs for quick moves
            'SPY', 'QQQ', 'TQQQ', 'SQQQ', 'VXX', 'UVXY',
            # More volatility
            'NIO', 'XPEV', 'LCID', 'RIVN', 'BB', 'WISH',
            # Tech growth
            'ROKU', 'SQ', 'PYPL', 'SHOP', 'SNOW', 'NET',
            # Biotech volatility
            'MRNA', 'BNTX', 'NVAX', 'SAVA', 'BNGO',
            # Energy
            'XOM', 'CVX', 'OXY', 'USO', 'XLE',
            # Finance
            'JPM', 'BAC', 'GS', 'MS', 'C', 'XLF'
        ]
        
        # Tracking
        self.active_trades = {}
        self.completed_trades = []
        self.total_trades = 0
        self.strategies = []
            'MOMENTUM_SCALP', 'MEAN_REVERT', 'BREAKOUT',
            'RSI_EXTREME', 'VOLUME_SURGE', 'RANDOM_WALK',
            'MACD_CROSS', 'BOLLINGER_SQUEEZE', 'GAP_TRADE',
            'SPIKE_FADE', 'TREND_FOLLOW', 'CONTRARIAN'
        ]
        
        logger.info(f"⚡ Min Confidence: {self.min_confidence*100}% (VERY LOW!)")
        logger.info(f"🎲 Force Trade Probability: {self.force_trade_probability*100}%")
        logger.info(f"📊 Symbol Count: {len(self.symbols)}")
        logger.info(f"🎯 Strategies: {len(self.strategies)}")
    
    async def get_market_data(self, symbol: str) -> Optional[pd.DataFrame]:
        """Get market data - with fallback to synthetic if needed"""
        try:
            request = StockBarsRequest()
                symbol_or_symbols=symbol,
                timeframe=TimeFrame.Minute,
                start=datetime.now() - timedelta(minutes=30),
                end=datetime.now()
            )
            
            bars = self.data_client.get_stock_bars(StockBarsRequest(symbol_or_symbols=request)
            
return signals
                df = bars.df.loc[symbol]
                if len(df) > 0:
                    return df
        except Exception:
            pass
        
        # Fallback to synthetic data to ensure we can trade
        return self._generate_synthetic_data(symbol)
    
    def _generate_synthetic_data(self, timeframe=symbol: str)) -> pd.DataFrame:
        """Generate synthetic data when real data unavailable"""
        base_prices = {}
            'AAPL': 195, 'MSFT': 420, 'GOOGL': 155, 'AMZN': 170,
            'TSLA': 250, 'NVDA': 850, 'SPY': 520, 'QQQ': 450,
            'GME': 25, 'AMC': 5, 'default': 100
        }
        
        base = base_prices.get(symbol, base_prices['default'])
        
        # Generate volatile data
        timestamps = pd.date_range(end=datetime.now(), periods=30, freq='1min')
        prices = []
        
        for i in range(30):
            change = random.uniform(-0.02, 0.02)  # 2% volatility
            base = base * (1 + change)
            prices.append(base)
        
        df = pd.DataFrame({)
            'open': prices,
            'high': [p * 1.001 for p in prices],
            'low': [p * 0.999 for p in prices],
            'close': prices,
            'volume': [random.randint(100000, 1000000) for _ in range(30)]
        }, index=timestamps)
        
        return df
    
    def hyper_aggressive_analysis(self, symbol: str, data: pd.DataFrame) -> Dict[str, Any]:
        """Ultra aggressive analysis - always finds something to trade!"""
        
        if data is None or len(data) < 5:
            # Force a random signal if no data
            return self._force_random_signal(symbol, 100.0)
        
        current_price = float(data['close'].iloc[-1])
        prices = data['close'].values
        volumes = data['volume'].values
        
        # Multiple aggressive signals
        signals = []
        
        # 1. Momentum signal
        momentum = (prices[-1] - prices[-5]) / prices[-5]
        if abs(momentum) > 0.001:  # Very low threshold
            signals.append({)
                'strategy': 'MOMENTUM_SCALP',
                'direction': 'BUY' if momentum > 0 else 'SELL',
                'confidence': min(0.9, 0.5 + abs(momentum) * 50)
            })
        
        # 2. RSI extreme
        rsi = self._calculate_rsi(data['close'], period=5)  # Short period
        if rsi < 40:
            signals.append({)
                'strategy': 'RSI_EXTREME',
                'direction': 'BUY',
                'confidence': 0.6 + (40 - rsi) / 100
            })
        elif rsi > 60:
            signals.append({)
                'strategy': 'RSI_EXTREME',
                'direction': 'SELL',
                'confidence': 0.6 + (rsi - 60) / 100
            })
        
        # 3. Volume surge
        vol_ratio = volumes[-1] / np.mean(volumes[-10:])
        if vol_ratio > 1.2:
            signals.append({)
                'strategy': 'VOLUME_SURGE',
                'direction': 'BUY' if momentum > 0 else 'SELL',
                'confidence': min(0.8, 0.5 + (vol_ratio - 1) * 2)
            })
        
        # 4. Bollinger squeeze
        sma = np.mean(prices[-10:])
        std = np.std(prices[-10:])
        if std > 0:
            z_score = (current_price - sma) / std
            if abs(z_score) > 0.5:  # Low threshold
                signals.append({)
                    'strategy': 'BOLLINGER_SQUEEZE',
                    'direction': 'SELL' if z_score > 0 else 'BUY',
                    'confidence': min(0.8, 0.5 + abs(z_score) * 0.3)
                })
        
        # 5. Random walk - for guaranteed action!
        if random.random() < self.force_trade_probability:
            signals.append({)
                'strategy': 'RANDOM_WALK',
                'direction': random.choice(['BUY', 'SELL']),
                'confidence': random.uniform(0.4, 0.7)
            })
        
        # 6. MACD cross
        if len(prices) >= 20:
            ema_fast = self._ema(prices, 5)
            ema_slow = self._ema(prices, 10)
            if ema_fast[-1] != ema_slow[-1]:
                signals.append({)
                    'strategy': 'MACD_CROSS',
                    'direction': 'BUY' if ema_fast[-1] > ema_slow[-1] else 'SELL',
                    'confidence': 0.65
                })
        
        # Pick the best signal or force one
        if signals:
            best_signal = max(signals, key=lambda x: x['confidence'])
            return {}
                'symbol': symbol,
                'signal': best_signal['direction'],
                'confidence': best_signal['confidence'],
                'strategy': best_signal['strategy'],
                'current_price': current_price,
                'momentum': momentum,
                'rsi': rsi,
                'volume_ratio': vol_ratio
            }
        else:
            # Force a trade if no signals
            return self._force_random_signal(symbol, current_price)
    
    def _force_random_signal(self, symbol: str, price: float) -> Dict[str, Any]:
        """Force a random signal when nothing else works"""
        return {}
            'symbol': symbol,
            'signal': random.choice(['BUY', 'SELL']),
            'confidence': random.uniform(0.4, 0.6),
            'strategy': 'FORCED_TRADE',
            'current_price': price,
            'momentum': 0,
            'rsi': 50,
            'volume_ratio': 1
        }
    
    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> float:
        """Fast RSI calculation"""
        if len(prices) < period + 1:
            return 50.0
        
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        if loss.iloc[-1] == 0:
            return 100.0
        
        rs = gain.iloc[-1] / loss.iloc[-1]
        return 100 - (100 / (1 + rs))
    
    def _ema(self, data: np.ndarray, period: int) -> np.ndarray:
        """Exponential moving average"""
        alpha = 2 / (period + 1)
        ema = np.zeros_like(data)
        ema[0] = data[0]
        
        for i in range(1, len(data)):
            ema[i] = alpha * data[i] + (1 - alpha) * ema[i-1]
        
        return ema
    
    async def execute_aggressive_trade(self, analysis: Dict[str, Any]) -> bool:
        """Execute trade aggressively"""
        
        symbol = analysis['symbol']
        signal = analysis['signal']
        confidence = analysis['confidence']
        strategy = analysis['strategy']
        current_price = analysis['current_price']
        
        # Skip if we have too many positions in this symbol
        symbol_count = sum(1 for s, t in self.active_trades.items() if s.startswith(symbol))
        if symbol_count >= 3:
            return False
        
        # Get account info
        account = self.trading_client.get_account()
        buying_power = float(account.buying_power)
        
        # Aggressive position sizing
        position_value = min()
            buying_power * self.max_position_pct,
            buying_power * 0.2  # Up to 20% on high confidence
        ) * confidence
        
        quantity = int(position_value / current_price)
        
        if quantity < 1:
            quantity = 1  # Force at least 1 share
        
        try:
            # Place market order for speed
            order_data = MarketOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=OrderSide.BUY if signal == "BUY" else OrderSide.SELL,
                time_in_force=TimeInForce.DAY
            )
            
            order = self.trading_client.submit_order(order_data)
            
            # Track trade
            trade_id = f"{symbol}_{int(time.time()*1000)}"
            trade = AggressiveTrade()
                symbol=symbol,
                direction=signal,
                quantity=quantity,
                entry_price=current_price,
                entry_time=datetime.now(),
                strategy=strategy,
                confidence=confidence,
                order_id=order.id
            )
            
            self.active_trades[trade_id] = trade
            self.total_trades += 1
            
            logger.info(f"🔥 AGGRESSIVE TRADE #{self.total_trades}: {signal} {symbol} x{quantity} @ ${current_price:.2f}")
            logger.info(f"   🎯 Strategy: {strategy} | Confidence: {confidence:.1%}")
            logger.info(f"   📊 Momentum: {analysis.get('momentum', 0):.3f} | RSI: {analysis.get('rsi', 50):.0f}")
            
            # Set stop loss and take profit orders
            if signal == "BUY":
                stop_price = current_price * (1 - self.stop_loss_pct)
                limit_price = current_price * (1 + self.take_profit_pct)
            else:
                stop_price = current_price * (1 + self.stop_loss_pct)
                limit_price = current_price * (1 - self.take_profit_pct)
            
            # Place bracket orders
            self._place_bracket_orders(symbol, quantity, signal, stop_price, limit_price)
            
            return True
            
        except Exception as e:
            logger.error(f"Trade error {symbol}: {str(e)[:50]}")
            return False
    
    def _place_bracket_orders(self, symbol: str, quantity: int, direction: str, 
                            stop_price: float, limit_price: float):
        """Place stop loss and take profit orders"""
        try:
            # Stop loss
            stop_side = OrderSide.SELL if direction == "BUY" else OrderSide.BUY
            stop_order = MarketOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=stop_side,
                time_in_force=TimeInForce.DAY
            )
            # Note: Alpaca paper trading might not support stop orders properly
            
            # Take profit
            limit_side = OrderSide.SELL if direction == "BUY" else OrderSide.BUY
            limit_order = LimitOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=limit_side,
                time_in_force=TimeInForce.DAY,
                limit_price=limit_price
            )
            
            try:
                self.trading_client.submit_order(limit_order)
                logger.info(f"   💰 Take Profit set at ${limit_price:.2f}")
            except Exception:
                pass
                
        except Exception as e:
            logger.debug(f"Bracket order error: {e}")
    
    async def monitor_and_close_aggressively(self):
        """Monitor positions and close aggressively"""
        
        try:
            positions = self.trading_client.get_all_positions()
            
            for pos in positions:
                symbol = pos.symbol
                current_price = float(pos.current_price)
                avg_price = float(pos.avg_entry_price)
                quantity = int(pos.qty)
                side = pos.side
                unrealized_pnl = float(pos.unrealized_pl)
                
                # Calculate P&L percentage
                if avg_price > 0:
                    if side == 'long':
                        pnl_pct = (current_price - avg_price) / avg_price
                    else:
                        pnl_pct = (avg_price - current_price) / avg_price
                else:
                    pnl_pct = 0
                
                # Aggressive exit conditions
                should_close = False
                reason = ""
                
                if pnl_pct >= self.take_profit_pct:
                    should_close = True
                    reason = f"PROFIT TARGET: {pnl_pct:.2%}"
                elif pnl_pct <= -self.stop_loss_pct:
                    should_close = True
                    reason = f"STOP LOSS: {pnl_pct:.2%}"
                elif random.random() < 0.1:  # 10% random exit
                    should_close = True
                    reason = "RANDOM EXIT"
                
                if should_close:
                    try:
                        self.trading_client.close_position(symbol)
                        
                        # Log the close
                        if unrealized_pnl > 0:
                            logger.info(f"💚 CLOSED {symbol}: +${unrealized_pnl:.2f} ({pnl_pct:.2%}) - {reason}")
                        else:
                            logger.info(f"💔 CLOSED {symbol}: ${unrealized_pnl:.2f} ({pnl_pct:.2%}) - {reason}")
                        
                        # Update completed trades
                        for trade_id, trade in list(self.active_trades.items()):
                            if trade.symbol == symbol:
                                trade.exit_price = current_price
                                trade.exit_time = datetime.now()
                                trade.pnl = unrealized_pnl
                                self.completed_trades.append(trade)
                                del self.active_trades[trade_id]
                                break
                                
                    except Exception as e:
                        logger.error(f"Close error {symbol}: {str(e)[:50]}")
                        
        except Exception as e:
            logger.error(f"Monitor error: {str(e)[:50]}")
    
    async def run_hyper_aggressive_trading(self, duration_minutes: int = 2):
        """Run hyper aggressive trading"""
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🔥🔥🔥 HYPER AGGRESSIVE TRADING SESSION STARTING 🔥🔥🔥")
        logger.info(f"{'='*100}")
        logger.info(f"⏰ Duration: {duration_minutes} minutes")
        logger.info(f"📊 Symbols: {len(self.symbols)}")
        logger.info(f"⚡ Min Confidence: {self.min_confidence*100}%")
        logger.info(f"🎲 Force Trade: {self.force_trade_probability*100}%")
        logger.info(f"💰 Initial Capital: ${self.initial_capital:,.2f}")
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        cycle = 0
        
        while datetime.now() < end_time:
            cycle += 1
            cycle_start = time.time()
            
            logger.info(f"\n{'='*80}")
            logger.info(f"🔥 AGGRESSIVE CYCLE {cycle}")
            logger.info(f"{'='*80}")
            
            # Monitor positions first
            await self.monitor_and_close_aggressively()
            
            # Get current positions
            positions = self.trading_client.get_all_positions()
            current_positions = len(positions)
            
            # Always try to trade, even at max positions
            max_new_trades = min(10, max(1, self.max_positions - current_positions))
            
            # Shuffle symbols for variety
            symbols_to_trade = random.sample(self.symbols, min(20, len(self.symbols)))
            
            # Analyze all symbols in parallel
            tasks = []
            for symbol in symbols_to_trade:
                task = self.analyze_and_trade(symbol)
                tasks.append(task)
            
            # Execute trades
            results = await asyncio.gather(*tasks)
            trades_executed = sum(1 for r in results if r)
            
            # Force more trades if needed
            if trades_executed < 3 and current_positions < self.max_positions:
                logger.info("⚡ Forcing additional trades...")
                for _ in range(3 - trades_executed):
                    symbol = random.choice(self.symbols)
                    forced_signal = self._force_random_signal(symbol, 100.0)
                    await self.execute_aggressive_trade(forced_signal)
            
            # Get account status
            account = self.trading_client.get_account()
            equity = float(account.equity)
            total_pnl = equity - self.initial_capital
            
            # Cycle summary
            cycle_time = time.time() - cycle_start
            
            logger.info(f"\n📊 CYCLE {cycle} SUMMARY:")
            logger.info(f"   ⚡ Trades Executed: {trades_executed}")
            logger.info(f"   📈 Open Positions: {current_positions}")
            logger.info(f"   💰 Account Equity: ${equity:,.2f}")
            logger.info(f"   📊 Total P&L: ${total_pnl:+,.2f} ({total_pnl/self.initial_capital*100:+.1f}%)")
            logger.info(f"   🔥 Total Trades: {self.total_trades}")
            logger.info(f"   ⏱️ Cycle Time: {cycle_time:.1f}s")
            
            # Short wait
            await asyncio.sleep(max(0.5, 2 - cycle_time))
        
        # Final summary
        await self.display_final_summary()
    
    async def analyze_and_trade(self, symbol: str) -> bool:
        """Analyze and trade a symbol"""
        try:
            data = await self.get_market_data(symbol)
            analysis = self.hyper_aggressive_analysis(symbol, data)
            
            if analysis['confidence'] >= self.min_confidence:
                return await self.execute_aggressive_trade(analysis)
                
        except Exception as e:
            logger.debug(f"Error with {symbol}: {e}")
        
        return False
    
    async def display_final_summary(self):
        """Display final summary"""
        
        logger.info("\n🔒 Closing all positions...")
        
        # Close everything
        positions = self.trading_client.get_all_positions()
        for pos in positions:
            try:
                self.trading_client.close_position(pos.symbol)
                logger.info(f"   Closed {pos.symbol}")
                await asyncio.sleep(0.1)
            except Exception:
                pass
        
        await asyncio.sleep(3)
        
        # Final stats
        account = self.trading_client.get_account()
        final_equity = float(account.equity)
        total_pnl = final_equity - self.initial_capital
        total_return = (total_pnl / self.initial_capital) * 100
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🏁 HYPER AGGRESSIVE TRADING SESSION COMPLETE")
        logger.info(f"{'='*100}")
        
        logger.info(f"\n💰 FINANCIAL SUMMARY:")
        logger.info(f"   Initial Equity: ${self.initial_capital:,.2f}")
        logger.info(f"   Final Equity: ${final_equity:,.2f}")
        logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
        logger.info(f"   Total Return: {total_return:+.2f}%")
        
        logger.info(f"\n📊 TRADING STATISTICS:")
        logger.info(f"   Total Trades Executed: {self.total_trades}")
        logger.info(f"   Completed Trades: {len(self.completed_trades)}")
        
        if self.completed_trades:
            wins = sum(1 for t in self.completed_trades if t.pnl and t.pnl > 0)
            win_rate = (wins / len(self.completed_trades)) * 100
            logger.info(f"   Winning Trades: {wins}")
            logger.info(f"   Win Rate: {win_rate:.1f}%")
            
            # Strategy breakdown
            strategy_stats = {}
            for trade in self.completed_trades:
                if trade.strategy not in strategy_stats:
                    strategy_stats[trade.strategy] = {'count': 0, 'pnl': 0}
                strategy_stats[trade.strategy]['count'] += 1
                if trade.pnl:
                    strategy_stats[trade.strategy]['pnl'] += trade.pnl
            
            logger.info(f"\n🎯 STRATEGY PERFORMANCE:")
            for strategy, stats in sorted(strategy_stats.items(), 
                                        key=lambda x: x[1]['pnl'], reverse=True):
                logger.info(f"   {strategy}: {stats['count']} trades, ${stats['pnl']:.2f} P&L")
        
        # Save results
        results = {}
            'initial_equity': self.initial_capital,
            'final_equity': final_equity,
            'total_pnl': total_pnl,
            'total_return': total_return,
            'total_trades': self.total_trades,
            'completed_trades': len(self.completed_trades),
            'trades': []
                {}
                    'symbol': t.symbol,
                    'direction': t.direction,
                    'quantity': t.quantity,
                    'entry_price': t.entry_price,
                    'strategy': t.strategy,
                    'confidence': t.confidence,
                    'pnl': t.pnl
                }
                for t in self.completed_trades[:50]
            ]
        }
        
        with open('hyper_aggressive_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"\n📁 Results saved to hyper_aggressive_results.json")
        logger.info(f"\n🔥🔥🔥 HYPER AGGRESSIVE TRADING COMPLETE! 🔥🔥🔥")

async def main():
    """Main function"""
    trader = HyperAggressiveTrader()
    await trader.run_hyper_aggressive_trading(duration_minutes=2)

if __name__ == "__main__":
    asyncio.run(main())