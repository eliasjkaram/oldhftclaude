
#!/usr/bin/env python3
"""
Paper Trading Bot
Automated trading system for Alpaca paper trading account
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
import signal
import sys
import json
import numpy as np
from datetime import datetime, timedelta
from alpaca.trading.client import TradingClient
from typing import Dict, List, Optional, Any
import sqlite3
import os

# Add parent directory
sys.path.append('/home/harry/alpaca-mcp')

# Import our systems
from transformer_prediction_system import TransformerPredictionSystem
from market_data_engine import MarketDataEngine
from performance_tracker import PerformanceTracker

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/paper_trading.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class PaperTradingBot:
    """Automated paper trading bot with AI predictions"""
    
    def __init__(self):
        # Alpaca Paper API
        self.trading_client = TradingClient('<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_SECRET>', paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        # Initialize components
        self.transformer_system = TransformerPredictionSystem()
        self.market_data = MarketDataEngine()
        self.performance = PerformanceTracker()
        
        # Trading parameters
        self.max_positions = 10
        self.position_size_pct = 0.1  # 10% per position
        self.stop_loss_pct = 0.02  # 2% stop loss
        self.take_profit_pct = 0.05  # 5% take profit
        self.min_confidence = 0.7  # 70% minimum confidence
        
        # State
        self.running = False
        self.positions = {}
        self.pending_orders = {}
        
        # Database
        self.init_database()
        
    def init_database(self):
        """Initialize paper trading database"""
        self.db = sqlite3.connect('/home/harry/alpaca-mcp/paper_trading.db')
        cursor = self.db.cursor()
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS trades ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                side TEXT,
                quantity INTEGER,
                price REAL,
                order_id TEXT,
                status TEXT,
                strategy TEXT,
                confidence REAL,
                profit_loss REAL,
                notes TEXT
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS performance ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE,
                starting_balance REAL,
                ending_balance REAL,
                trades_count INTEGER,
                win_rate REAL,
                total_pnl REAL,
                sharpe_ratio REAL,
                max_drawdown REAL
            )
        ''')
        
        self.db.commit()
        
    async def start(self):
        """Start the trading bot"""
        logger.info("Starting Paper Trading Bot...")
        self.running = True
        
        # Check account
        account = self.trading_client.get_account()
        logger.info(f"Account Balance: ${account.buying_power}")
        logger.info(f"Portfolio Value: ${account.portfolio_value}")
        
        # Cancel any open orders
        self.trading_client.cancel_orders()
        
        # Main trading loop
        try:
            while self.running:
                await self.trading_cycle()
                await asyncio.sleep(60)  # Run every minute
                
        except KeyboardInterrupt:
            logger.info("Shutdown requested...")
        except Exception as e:
            logger.error(f"Trading bot error: {e}", exc_info=True)
        finally:
            await self.shutdown()
            
    async def trading_cycle(self):
        """Execute one trading cycle"""
        try:
            # Check if market is open
            clock = self.trading_client.get_clock()
            if not clock.is_open:
                logger.info("Market is closed")
                return
                
            # Update positions
            await self.update_positions()
            
            # Get predictions
            predictions = await self.get_predictions()
            
            # Find opportunities
            opportunities = self.find_trading_opportunities(predictions)
            
            # Execute trades
            await self.execute_trades(opportunities)
            
            # Manage existing positions
            await self.manage_positions()
            
            # Log performance
            self.log_performance()
            
        except Exception as e:
            logger.error(f"Trading cycle error: {e}", exc_info=True)
            
    async def get_predictions(self):
        """Get AI predictions for trading"""
        try:
            # Run transformer predictions
            results = await self.transformer_system.run_prediction_cycle()
            predictions = results.get('predictions', {})
            
            # Filter by confidence
            filtered = {}
                symbol: pred for symbol, pred in predictions.items()
                if pred and pred.confidence >= self.min_confidence
            }
            
            logger.info(f"Got {len(filtered)} high-confidence predictions")
            return filtered
            
        except Exception as e:
            logger.error(f"Prediction error: {e}", exc_info=True)
            return {}
            
    def find_trading_opportunities(self, predictions):
        """Find the best trading opportunities"""
        opportunities = []
        
        # Get current positions
        positions = self.trading_client.get_all_positions()
        position_symbols = {p.symbol for p in positions}
        
        # Check account balance
        account = self.trading_client.get_account()
        buying_power = float(account.buying_power)
        max_position_value = buying_power * self.position_size_pct
        
        # Rank predictions by expected return
        sorted_preds = sorted()
            predictions.items(),
            key=lambda x: abs(x[1].predicted_return) * x[1].confidence,
            reverse=True
        )
        
        for symbol, pred in sorted_preds:
            # Skip if already have position
            if symbol in position_symbols:
                continue
                
            # Skip if too many positions
            if len(position_symbols) >= self.max_positions:
                break
                
            # Create opportunity
            if pred.predicted_direction in ['up', 'down']:
                opportunities.append({)
                    'symbol': symbol,
                    'side': 'buy' if pred.predicted_direction == 'up' else 'sell',
                    'confidence': pred.confidence,
                    'expected_return': pred.predicted_return,
                    'risk_score': pred.risk_score,
                    'max_position_value': max_position_value,
                    'strategy': 'transformer_prediction'
                })
                
        return opportunities[:3]  # Top 3 opportunities
        
    async def execute_trades(self, opportunities):
        """Execute trading opportunities"""
        for opp in opportunities:
            try:
                symbol = opp['symbol']
                side = opp['side']
                
                # Get current price
                quote = self.data_client.get_stock_latest_quote(symbol)
                price = quote.ask_price if side == 'buy' else quote.bid_price
                
                # Calculate quantity
                quantity = int(opp['max_position_value'] / price)
                if quantity < 1:
                    continue
                    
                # Place order
orders = self.get_orders()
                    limit_price=price,
                    client_order_id=f"PT_{symbol}_{datetime.now().timestamp()}"
                )
                
                logger.info(f"Placed {side} order: {quantity} {symbol} @ ${price}")
                
                # Record trade
                self.record_trade({)
                    'symbol': symbol,
                    'side': side,
                    'quantity': quantity,
                    'price': price,
                    'order_id': order.id,
                    'status': 'pending',
                    'strategy': opp['strategy'],
                    'confidence': opp['confidence']
                })
                
                # Store pending order
                self.pending_orders[order.id] = {}
                    'symbol': symbol,
                    'side': side,
                    'quantity': quantity,
                    'price': price,
                    'stop_loss': price * (1 - self.stop_loss_pct) if side == 'buy' else price * (1 + self.stop_loss_pct),
                    'take_profit': price * (1 + self.take_profit_pct) if side == 'buy' else price * (1 - self.take_profit_pct)
                }
                
            except Exception as e:
                logger.error(f"Trade execution error for {opp['symbol']}: {e}", exc_info=True)
                
    async def manage_positions(self):
        """Manage existing positions with stops and targets"""
        positions = self.trading_client.get_all_positions()
        
        for position in positions:
            try:
                symbol = position.symbol
                qty = int(position.qty)
                side = 'sell' if position.side == 'long' else 'buy'
                avg_price = float(position.avg_entry_price)
                current_price = float(position.current_price)
                unrealized_pl = float(position.unrealized_pl)
                
                # Check stop loss
                if position.side == 'long':
                    if current_price <= avg_price * (1 - self.stop_loss_pct):
                        logger.info(f"Stop loss triggered for {symbol}")
                        self.close_position(symbol, qty, side, 'stop_loss')
                        continue
                        
                    # Check take profit
                    if current_price >= avg_price * (1 + self.take_profit_pct):
                        logger.info(f"Take profit triggered for {symbol}")
                        self.close_position(symbol, qty, side, 'take_profit')
                        continue
                else:  # short position
                    if current_price >= avg_price * (1 + self.stop_loss_pct):
                        logger.info(f"Stop loss triggered for {symbol}")
                        self.close_position(symbol, qty, side, 'stop_loss')
                        continue
                        
                    if current_price <= avg_price * (1 - self.take_profit_pct):
                        logger.info(f"Take profit triggered for {symbol}")
                        self.close_position(symbol, qty, side, 'take_profit')
                        continue
                        
                # Check for new predictions
                latest_prediction = await self.get_latest_prediction(symbol)
                if latest_prediction:
                    # Close if prediction reversed
                    if (position.side == 'long' and latest_prediction.predicted_direction == 'down') or \
                       (position.side == 'short' and latest_prediction.predicted_direction == 'up'):
                        logger.info(f"Prediction reversed for {symbol}, closing position")
                        self.close_position(symbol, qty, side, 'prediction_reversal')
                        
            except Exception as e:
                logger.error(f"Position management error for {symbol}: {e}", exc_info=True)
                
    def close_position(self, symbol, qty, side, reason):
        """Close a position"""
        try:
            order = self.trading_client.submit_order(order_data=MarketOrderRequest(symbol=symbol, qty=qty, side=side, time_in_force='day',
                client_order_id=f"PT_CLOSE_{symbol}_{datetime.now().timestamp()}"
            )
            
            logger.info(f"Closing position: {qty} {symbol} ({reason})")
            
            # Record closing trade
            self.record_trade({)
                'symbol': symbol,
                'side': side,
                'quantity': qty,
                'price': None,  # Market order
                'order_id': order.id,
                'status': 'closing',
                'strategy': reason,
                'confidence': None
            })
            
        except Exception as e:
            logger.error(f"Error closing position {symbol}: {e}", exc_info=True)
            
    async def update_positions(self):
        """Update position tracking"""
        positions = self.trading_client.get_all_positions()
        self.positions = {p.symbol: p for p in positions}
        
        # Check filled orders
        orders = self.trading_client.get_orders(status='filled', limit=50)
        for order in orders:
            if order.id in self.pending_orders:
                # Update trade record
                self.update_trade_status(order.id, 'filled', float(order.filled_avg_price))
                del self.pending_orders[order.id]
                
    async def get_latest_prediction(self, symbol):
        """Get latest prediction for symbol"""
        try:
            # Fetch latest data
            data = await self.transformer_system.fetch_market_data(symbol)
            if not data.empty:
                return self.transformer_system.make_prediction(symbol, data)
        except Exception:
            pass
        return None
        
    def record_trade(self, trade_data):
        """Record trade in database"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO trades 
            (symbol, side, quantity, price, order_id, status, strategy, confidence)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', ()
            trade_data['symbol'],
            trade_data['side'],
            trade_data['quantity'],
            trade_data['price'],
            trade_data['order_id'],
            trade_data['status'],
            trade_data['strategy'],
            trade_data.get('confidence')
        ))
        self.db.commit()
        
    def update_trade_status(self, order_id, status, filled_price=None):
        """Update trade status in database"""
        cursor = self.db.cursor()
        if filled_price:
            cursor.execute(''')
                UPDATE trades 
                SET status = ?, price = ?
                WHERE order_id = ?
            ''', (status, filled_price, order_id))
        else:
            cursor.execute(''')
                UPDATE trades 
                SET status = ?
                WHERE order_id = ?
            ''', (status, order_id))
        self.db.commit()
        
    def log_performance(self):
        """Log daily performance metrics"""
        try:
            account = self.trading_client.get_account()
            
            # Get today's trades
            cursor = self.db.cursor()
            cursor.execute(''')
                SELECT COUNT(*) FROM trades 
                WHERE DATE(timestamp) = DATE('now')
            ''')
            trades_count = cursor.fetchone()[0]
            
            # Calculate metrics
            portfolio_value = float(account.portfolio_value)
            cash = float(account.cash)
            
            logger.info(f"Portfolio Value: ${portfolio_value:,.2f}")
            logger.info(f"Cash: ${cash:,.2f}")
            logger.info(f"Today's Trades: {trades_count}")
            logger.info(f"Open Positions: {len(self.positions)}")
            
        except Exception as e:
            logger.error(f"Performance logging error: {e}", exc_info=True)
            
    async def shutdown(self):
        """Graceful shutdown"""
        logger.info("Shutting down Paper Trading Bot...")
        self.running = False
        
        # Cancel pending orders
        try:
            self.trading_client.cancel_orders()
        except Exception:
            pass
            
        # Close database
        self.db.close()
        
        logger.info("Paper Trading Bot stopped")

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info("Received shutdown signal")
    sys.exit(0)

async def main():
    """Main function"""
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create and start bot
    bot = PaperTradingBot()
    await bot.start()

if __name__ == "__main__":
    # Create logs directory
    os.makedirs('/home/harry/alpaca-mcp/logs', exist_ok=True)
    
    # Run bot
    asyncio.run(main())