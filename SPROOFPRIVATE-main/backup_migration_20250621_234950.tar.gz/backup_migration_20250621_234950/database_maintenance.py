
#!/usr/bin/env python3
"""
Database Maintenance
Performs regular database maintenance tasks
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import sqlite3
import logging
import os
import sys
from datetime import datetime, timedelta
import shutil

from universal_market_data import get_current_market_data, validate_price


logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/db_maintenance.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DatabaseMaintenance:
    """Database maintenance and optimization"""
    
    def __init__(self):
        self.db_dir = '/home/harry/alpaca-mcp'
        self.backup_dir = '/home/harry/alpaca-mcp/backups'
        os.makedirs(self.backup_dir, exist_ok=True)
        
        self.databases = []
            'transformer_performance.db',
            'strategy_performance.db',
            'trading_performance.db',
            'arbitrage_scanner.db',
            'data_validation.db',
            'paper_trading.db',
            'live_trading.db',
            'market_data.db',
            'options_scanner.db',
            'continuous_improvement.db',
            'system_monitoring.db'
        ]
        
        self.retention_days = {}
            'market_data.db': 90,  # 3 months
            'system_monitoring.db': 30,  # 1 month
            'data_validation.db': 7,  # 1 week
            'default': 180  # 6 months default
        }
        
    def run_maintenance(self):
        """Run all maintenance tasks"""
        logger.info("Starting database maintenance...")
        
        for db_name in self.databases:
            db_path = os.path.join(self.db_dir, db_name)
            if os.path.exists(db_path):
                logger.info(f"Maintaining {db_name}...")
                
                # Backup
                self.backup_database(db_name)
                
                # Clean old data
                self.clean_old_data(db_name)
                
                # Optimize
                self.optimize_database(db_name)
                
                # Analyze
                self.analyze_database(db_name)
                
        # Clean old backups
        self.clean_old_backups()
        
        logger.info("Database maintenance complete")
        
    def backup_database(self, db_name):
        """Create database backup"""
        try:
            source_path = os.path.join(self.db_dir, db_name)
            backup_name = f"{db_name}.{datetime.now().strftime('%Y%m%d_%H%M%S')}.backup"
            backup_path = os.path.join(self.backup_dir, backup_name)
            
            shutil.copy2(source_path, backup_path)
            logger.info(f"Backed up {db_name} to {backup_name}")
            
        except Exception as e:
            logger.error(f"Backup failed for {db_name}: {e}")
            
    def clean_old_data(self, db_name):
        """Clean old data based on retention policy"""
        try:
            db_path = os.path.join(self.db_dir, db_name)
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get retention days
            retention = self.retention_days.get(db_name, self.retention_days['default'])
            cutoff_date = datetime.now() - timedelta(days=retention)
            
            # Get tables with timestamp columns
            cursor.execute(""")
                SELECT name FROM sqlite_master 
                WHERE type='table' 
                AND sql LIKE '%timestamp%'
            """)
            tables = cursor.fetchall()
            
            total_deleted = 0
            
            for (table_name,) in tables:
                try:
                    # Delete old records
                    cursor.execute(f""")
                        DELETE FROM {table_name}
                        WHERE timestamp < ?
                    """, (cutoff_date,)
                    
                    deleted = cursor.rowcount
                    if deleted > 0:
                        total_deleted += deleted
                        logger.info(f"Deleted {deleted} old records from {table_name}")
                        
                except Exception as e:
                    logger.error(f"Error cleaning {table_name}: {e}")
                    
            conn.commit()
            conn.close()
            
            if total_deleted > 0:
                logger.info(f"Total records deleted from {db_name}: {total_deleted}")
                
        except Exception as e:
            logger.error(f"Error cleaning {db_name}: {e}")
            
    def optimize_database(self, db_name):
        """Optimize database performance"""
        try:
            db_path = os.path.join(self.db_dir, db_name)
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get initial size
            initial_size = os.path.getsize(db_path) / (1024 * 1024)  # MB
            
            # VACUUM to reclaim space
            cursor.execute("VACUUM")
            
            # ANALYZE to update statistics
            cursor.execute("ANALYZE")
            
            conn.close()
            
            # Get final size
            final_size = os.path.getsize(db_path) / (1024 * 1024)  # MB
            
            space_saved = initial_size - final_size
            if space_saved > 0:
                logger.info(f"Optimized {db_name}: {initial_size:.1f}MB -> {final_size:.1f}MB ")
                          f"(saved {space_saved:.1f}MB)")
            else:
                logger.info(f"Optimized {db_name}: {final_size:.1f}MB")
                
        except Exception as e:
            logger.error(f"Error optimizing {db_name}: {e}")
            
    def analyze_database(self, db_name):
        """Analyze database health and performance"""
        try:
            db_path = os.path.join(self.db_dir, db_name)
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Check integrity
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            
            if result[0] != 'ok':
                logger.warning(f"Integrity check failed for {db_name}: {result[0]}")
            else:
                logger.info(f"Integrity check passed for {db_name}")
                
            # Get database stats
            cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
            table_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index'")
            index_count = cursor.fetchone()[0]
            
            # Get total row count (approximate)
            total_rows = 0
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            
            for (table_name,) in tables:
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    total_rows += cursor.fetchone()[0]
                except Exception:
                    pass
                    
            logger.info(f"{db_name} stats: {table_count} tables, {index_count} indexes, ")
                      f"~{total_rows:,} total rows")
                      
            conn.close()
            
        except Exception as e:
            logger.error(f"Error analyzing {db_name}: {e}")
            
    def clean_old_backups(self):
        """Remove old backup files"""
        try:
            # Keep backups for 7 days
            cutoff_date = datetime.now() - timedelta(days=7)
            
            for filename in os.listdir(self.backup_dir):
                if filename.endswith('.backup'):
                    file_path = os.path.join(self.backup_dir, filename)
                    file_time = datetime.fromtimestamp(os.path.getmtime(file_path)
                    
                    if file_time < cutoff_date:
                        os.remove(file_path)
                        logger.info(f"Removed old backup: {filename}")
                        
        except Exception as e:
            logger.error(f"Error cleaning backups: {e}")
            
    def generate_maintenance_report(self):
        """Generate maintenance report"""
        report = f"""
DATABASE MAINTENANCE REPORT
==========================
Generated: {datetime.now()}

DATABASE SUMMARY:
"""
        
        total_size = 0
        for db_name in self.databases:
            db_path = os.path.join(self.db_dir, db_name)
            if os.path.exists(db_path):
                size_mb = os.path.getsize(db_path) / (1024 * 1024)
                total_size += size_mb
                report += f"\n{db_name}: {size_mb:.1f} MB"
                
        report += f"\n\nTotal Size: {total_size:.1f} MB"
        
        # Backup status
        backup_count = len([f for f in os.listdir(self.backup_dir) if f.endswith('.backup')])
        backup_size = sum(os.path.getsize(os.path.join(self.backup_dir, f) 
                         for f in os.listdir(self.backup_dir) 
                         if f.endswith('.backup') / (1024 * 1024)
        
        report += f"\n\nBACKUP STATUS:"
        report += f"\nBackup Count: {backup_count}"
        report += f"\nBackup Size: {backup_size:.1f} MB"
        
        # Save report
        with open('/home/harry/alpaca-mcp/logs/maintenance_report.txt', 'w') as f:
            f.write(report)
            
        return report

def main():
    """Run database maintenance"""
    maintenance = DatabaseMaintenance()
    maintenance.run_maintenance()
    report = maintenance.generate_maintenance_report()
    
    print("\n" + "="*50)
    print("DATABASE MAINTENANCE COMPLETE")
    print("="*50)
    print(report)

if __name__ == "__main__":
    main()