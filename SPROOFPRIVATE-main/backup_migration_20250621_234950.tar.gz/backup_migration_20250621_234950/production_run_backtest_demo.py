#!/usr/bin/env python3
"""
Demonstration of V17 Backtesting Features
Shows comprehensive backtesting with visualization outputs
"""

from datetime import datetime, timedelta
import os
import asyncio
import matplotlib.pyplot as plt
import matplotlib

import logging

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

matplotlib.use('Agg')  # Non-interactive backend
import seaborn as sns
import pandas as pd
import numpy as np
from datetime import datetime
import sys

sys.path.append('/home/harry/alpaca-mcp')

# Import the enhanced backtester
from v17_ultimate_backtest_gui import ()
    EnhancedBacktester, AlpacaTradingSystem, BacktestResult,
    GPU_AVAILABLE, GPU_DEVICE
)

async def run_backtest_demo():
    try:
        """Run comprehensive backtest and generate report with visualizations"""
    
        logger.info("\n" + "="*80)
        logger.info("🚀 COMPREHENSIVE BACKTESTING DEMONSTRATION")
        logger.info("="*80)
        logger.info(f"📅 Period: 2024-01-01 to 2024-12-31")
        logger.info(f"🖥️  GPU: {'ENABLED - ' + GPU_DEVICE if GPU_AVAILABLE else 'NOT AVAILABLE'}")
        logger.info(f"📊 Testing: 76+ Algorithms, 70+ Spreads, HFT, AI Arbitrage")
        logger.info("="*80 + "\n")
    
        # Initialize system
        trading_system = AlpacaTradingSystem(paper_trading=True)
    
        # Progress callback
        async def progress_callback(progress: int, message: str):
            logger.info(f"[{progress:3d}%] {message}")
    
        # Create backtester
        backtester = EnhancedBacktester(trading_system, progress_callback)
    
        # Run comprehensive backtest
        symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA', 'AMD',
                   'JPM', 'BAC', 'SPY', 'QQQ', 'IWM', 'VTI', 'GME', 'AMC']
    
        results = await backtester.run_comprehensive_backtest()
            start_date="2024-01-01",
            end_date="2024-12-31",
            symbols=symbols
        )
    
        # Generate visualizations
        logger.info("\n📈 GENERATING PERFORMANCE VISUALIZATIONS...\n")
    
        # 1. Algorithm Performance Chart
        fig, ((ax1, ax2), (ax3, ax4) = plt.subplots(2, 2, figsize=(16, 12)
        fig.suptitle('Comprehensive Backtest Results - Algorithm Performance', fontsize=16)
    
        # Top algorithms by return
        algo_returns = [(name, data.get('total_return', 0) * 100) 
                       for name, data in results.algorithms_performance.items()]
        algo_returns.sort(key=lambda x: x[1], reverse=True)
        top_20 = algo_returns[:20]
    
        names = [a[0][:15] for a in top_20]
        returns = [a[1] for a in top_20]
    
        bars = ax1.bar(range(len(names), returns, 
                       color=['green' if r > 0 else 'red' for r in returns])
        ax1.set_xticks(range(len(names))
        ax1.set_xticklabels(names, rotation=45, ha='right')
        ax1.set_ylabel('Return (%)')
        ax1.set_title('Top 20 Algorithm Returns')
        ax1.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        ax1.grid(True, alpha=0.3)
    
        # Algorithm categories
        categories = {}
            'Technical': 0,
            'ML/AI': 0,
            'Statistical': 0,
            'Options': 0,
            'HFT': 0
        }
    
        for name, ret in algo_returns:
            if any(x in name for x in ['RSI', 'MACD', 'Bollinger']):
                categories['Technical'] += ret
            elif any(x in name for x in ['Neural', 'Forest', 'LSTM', 'Deep']):
                categories['ML/AI'] += ret
            elif any(x in name for x in ['Mean', 'Pairs', 'Statistical']):
                categories['Statistical'] += ret
            elif any(x in name for x in ['Volatility', 'Greeks', 'Gamma']):
                categories['Options'] += ret
            elif any(x in name for x in ['HFT', 'Order', 'Market']):
                categories['HFT'] += ret
    
        # Category performance pie chart
        ax2.pie(categories.values(), labels=categories.keys(), autopct='%1.1f%%',
                colors=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FDCB6E'])
        ax2.set_title('Returns by Algorithm Category')
    
        # Spread performance
        spread_returns = [(name, data.get('total_return', 0) * 100)
                         for name, data in results.spreads_performance.items()]
        spread_returns.sort(key=lambda x: x[1], reverse=True)
    
        if spread_returns:
            spread_names = [s[0].replace('_', ' ') for s in spread_returns[:10]]
            spread_vals = [s[1] for s in spread_returns[:10]]
        
            bars = ax3.barh(range(len(spread_names), spread_vals,
                           color=['green' if v > 0 else 'red' for v in spread_vals])
            ax3.set_yticks(range(len(spread_names))
            ax3.set_yticklabels(spread_names)
            ax3.set_xlabel('Return (%)')
            ax3.set_title('Top 10 Option Spread Strategies')
            ax3.axvline(x=0, color='black', linestyle='-', linewidth=0.5)
            ax3.grid(True, alpha=0.3)
    
        # Overall metrics
        overall = results.overall_metrics
        metrics_text = f"""BACKTEST SUMMARY
    
    Total Return: {overall['total_return']:.2%}
    Sharpe Ratio: {overall['sharpe_ratio']:.2f}
    Win Rate: {overall['win_rate']:.1%}
    Total Trades: {overall['total_trades']:,}

    HFT Contribution: ${overall['hft_contribution']:,.2f}
    AI Contribution: ${overall['ai_contribution']:,.2f}
    GPU Speedup: {overall.get('gpu_speedup', 1.0):.1f}x"""
    
        ax4.text(0.1, 0.5, metrics_text, fontsize=12, verticalalignment='center',
                 transform=ax4.transAxes, fontfamily='monospace',
                 bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray", alpha=0.5)
        ax4.axis('off')
    
        plt.tight_layout()
        plt.savefig('backtest_algorithms.png', dpi=150, bbox_inches='tight')
        logger.info("✅ Saved: backtest_algorithms.png")
    
        # 2. Equity Curve and Risk Metrics
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 10), sharex=True)
        fig.suptitle('Equity Curve and Risk Analysis', fontsize=16)
    
        if results.equity_curve is not None:
            # Equity curve
            ax1.plot(results.equity_curve['date'], results.equity_curve['equity'], 
                    'b-', linewidth=2)
            ax1.fill_between(results.equity_curve['date'], 100000, results.equity_curve['equity'],
                           where=(results.equity_curve['equity'] >= 100000), 
                           color='green', alpha=0.3)
            ax1.fill_between(results.equity_curve['date'], 100000, results.equity_curve['equity'],
                           where=(results.equity_curve['equity'] < 100000), 
                           color='red', alpha=0.3)
            ax1.axhline(y=100000, color='black', linestyle='--', alpha=0.5)
            ax1.set_ylabel('Portfolio Value ($)')
            ax1.set_title('Portfolio Equity Curve')
            ax1.grid(True, alpha=0.3)
        
            # Daily returns
            ax2.bar(results.equity_curve['date'], results.equity_curve['returns'] * 100,
                   color=['green' if r > 0 else 'red' for r in results.equity_curve['returns']],
                   width=1)
            ax2.set_ylabel('Daily Return (%)')
            ax2.set_title('Daily Returns Distribution')
            ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
            ax2.grid(True, alpha=0.3)
        
            # Drawdown
            ax3.fill_between(results.equity_curve['date'], 0, results.equity_curve['drawdown'] * 100,
                           color='red', alpha=0.7)
            ax3.set_ylabel('Drawdown (%)')
            ax3.set_xlabel('Date')
            ax3.set_title('Portfolio Drawdown')
            ax3.grid(True, alpha=0.3)
    
        plt.tight_layout()
        plt.savefig('backtest_equity_curve.png', dpi=150, bbox_inches='tight')
        logger.info("✅ Saved: backtest_equity_curve.png")
    
        # 3. HFT and AI Performance
        fig, ((ax1, ax2), (ax3, ax4) = plt.subplots(2, 2, figsize=(14, 10)
        fig.suptitle('HFT and AI Arbitrage Performance', fontsize=16)
    
        # HFT metrics
        hft = results.hft_metrics
        hft_metrics = ['Total Trades', 'Win Rate', 'Avg Hold Time', 'Trades/Sec']
        hft_values = []
            hft.get('total_trades', 0),
            hft.get('win_rate', 0) * 100,
            hft.get('avg_hold_time_ms', 0),
            hft.get('trades_per_second', 0)
        ]
    
        ax1.bar(hft_metrics, hft_values, color='skyblue')
        ax1.set_title('HFT Performance Metrics')
        ax1.set_ylabel('Value')
        for i, v in enumerate(hft_values):
            ax1.text(i, v + max(hft_values)*0.01, f'{v:.1f}', ha='center')
    
        # Latency impact
        latencies = list(hft['latency_stats'].keys()
        latency_vals = list(hft['latency_stats'].values()
    
        ax2.plot(latencies, latency_vals, 'ro-', linewidth=2, markersize=8)
        ax2.set_xlabel('Latency Percentile')
        ax2.set_ylabel('Latency (ms)')
        ax2.set_title('HFT Latency Distribution')
        ax2.grid(True, alpha=0.3)
    
        # AI Arbitrage metrics
        ai = results.ai_metrics
        ai_metrics = ['Found', 'Executed', 'Success Rate', 'Avg Profit']
        ai_values = []
            ai.get('opportunities_found', 0),
            ai.get('opportunities_executed', 0),
            (ai.get('opportunities_executed', 0) / max(1, ai.get('opportunities_found', 1)) * 100,
            ai.get('total_profit', 0) / max(1, ai.get('opportunities_executed', 1)
        ]
    
        ax3.bar(ai_metrics, ai_values, color='lightgreen')
        ax3.set_title('AI Arbitrage Performance')
        ax3.set_ylabel('Value')
        for i, v in enumerate(ai_values):
            ax3.text(i, v + max(ai_values)*0.01, f'{v:.1f}', ha='center')
    
        # GPU Performance
        if GPU_AVAILABLE and results.gpu_metrics.get('speedup_metrics'):
            algos = list(results.gpu_metrics['speedup_metrics'].keys()
            speedups = [m['speedup'] for m in results.gpu_metrics['speedup_metrics'].values()]
        
            ax4.barh(range(len(algos), speedups, color='orange')
            ax4.set_yticks(range(len(algos))
            ax4.set_yticklabels(algos)
            ax4.set_xlabel('Speedup Factor')
            ax4.set_title('GPU Acceleration by Algorithm')
            ax4.axvline(x=1, color='red', linestyle='--', alpha=0.5, label='No speedup')
            for i, s in enumerate(speedups):
                ax4.text(s + 0.1, i, f'{s:.1f}x', va='center')
        else:
            ax4.text(0.5, 0.5, 'GPU Not Available', ha='center', va='center',
                    transform=ax4.transAxes, fontsize=16)
            ax4.axis('off')
    
        plt.tight_layout()
        plt.savefig('backtest_hft_ai.png', dpi=150, bbox_inches='tight')
        logger.info("✅ Saved: backtest_hft_ai.png")
    
        # Print summary report
        logger.info("\n" + "="*80)
        logger.info("📊 BACKTEST SUMMARY REPORT")
        logger.info("="*80)
        logger.info(f"Duration: {results.duration_seconds:.1f} seconds")
        logger.info(f"Symbols Tested: {len(results.symbols_tested)}")
        logger.info(f"Algorithms Tested: {len(results.algorithms_performance)}")
        logger.info(f"Spreads Tested: {len(results.spreads_performance)}")
        logger.info("\nFINANCIAL PERFORMANCE:")
        logger.info(f"  Total Return: {overall['total_return']:.2%}")
        logger.info(f"  Sharpe Ratio: {overall['sharpe_ratio']:.2f}")
        logger.info(f"  Win Rate: {overall['win_rate']:.1%}")
        logger.info(f"  Total Trades: {overall['total_trades']:,}")
        logger.info("\nTOP 5 ALGORITHMS:")
        for i, (name, ret) in enumerate(algo_returns[:5], 1):
            logger.info(f"  {i}. {name}: {ret:.2f}%")
        logger.info("\nTOP 5 SPREADS:")
        for i, (name, ret) in enumerate(spread_returns[:5], 1):
            logger.info(f"  {i}. {name}: {ret:.2f}%")
        logger.info(f"\nHFT PERFORMANCE:")
        logger.info(f"  Total Trades: {hft.get('total_trades', 0):,}")
        logger.info(f"  Win Rate: {hft.get('win_rate', 0):.1%}")
        logger.info(f"  Daily P&L: ${hft.get('total_pnl', 0) / 252:.2f}")
        logger.info(f"\nAI ARBITRAGE:")
        logger.info(f"  Opportunities: {ai.get('opportunities_found', 0)}")
        logger.info(f"  Executed: {ai.get('opportunities_executed', 0)}")
        logger.info(f"  Total Profit: ${ai.get('total_profit', 0):,.2f}")
        if GPU_AVAILABLE:
            logger.info(f"\nGPU ACCELERATION:")
            logger.info(f"  Device: {GPU_DEVICE}")
            logger.info(f"  Average Speedup: {overall.get('gpu_speedup', 1.0):.1f}x")
        logger.info("="*80)
    
        # Save detailed results to JSON
        import json
    
        # Convert BacktestResult to dict
        results_dict = {}
            'timestamp': str(results.timestamp),
            'duration_seconds': results.duration_seconds,
            'symbols_tested': results.symbols_tested,
            'algorithms_performance': results.algorithms_performance,
            'spreads_performance': results.spreads_performance,
            'hft_metrics': results.hft_metrics,
            'ai_metrics': results.ai_metrics,
            'gpu_metrics': results.gpu_metrics,
            'overall_metrics': results.overall_metrics
        }
    
        with open('backtest_results_v17.json', 'w') as f:
            json.dump(results_dict, f, indent=2)
        logger.info("\n✅ Detailed results saved to: backtest_results_v17.json")
    
        return results

    if __name__ == "__main__":
        # Run the demonstration

    except Exception as e:
        logger.error(f"Error in run_backtest_demo: {str(e)}")
        raise
    asyncio.run(run_backtest_demo()