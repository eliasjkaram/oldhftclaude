
#!/usr/bin/env python3
"""
Ultimate Bot Launcher
====================
Simplified launcher for the Ultimate Unified Bot with safety checks
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
import subprocess
import psutil
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class UltimateBotLauncher:
    def __init__(self):
        self.bot_process = None
        
    def check_gpu_status(self):
        """Check GPU availability and memory"""
        try:
            import torch
            if torch.cuda.is_available():
                gpu_name = torch.cuda.get_device_name()
                gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1e9
                logger.info(f"✅ GPU Available: {gpu_name} ({gpu_memory:.1f} GB)")
                return True
            else:
                logger.warning("⚠️ GPU not available - will use CPU")
                return False
        except ImportError:
            logger.warning("⚠️ PyTorch not installed - GPU acceleration disabled")
            return False
    
    def check_system_resources(self):
        """Check system resources"""
        # CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        logger.info(f"💻 CPU Usage: {cpu_percent}%")
        
        # Memory
        memory = psutil.virtual_memory()
        logger.info(f"🧠 Memory: {memory.percent}% used ({memory.available / 1e9:.1f} GB available)")
        
        # Disk
        disk = psutil.disk_usage('/')
        logger.info(f"💾 Disk: {disk.percent}% used ({disk.free / 1e9:.1f} GB free)")
        
        # Check if resources are sufficient
        if memory.available < 4e9:  # Less than 4GB
            logger.warning("⚠️ Low memory available!")
            return False
        
        return True
    
    def check_dependencies(self):
        """Check if all required dependencies are installed"""
        required_modules = []
            'alpaca_trade_api',
            'pandas',
            'numpy',
            'yfinance',
            'sqlite3',
            'dotenv'
        ]
        
        missing = []
        for module in required_modules:
            try:
                __import__(module)
            except ImportError:
                missing.append(module)
        
        if missing:
            logger.error(f"❌ Missing dependencies: {', '.join(missing)}")
            logger.info("Install with: pip install alpaca-trade-api pandas numpy yfinance python-dotenv")
            return False
        
        logger.info("✅ All dependencies installed")
        return True
    
    def check_api_credentials(self):
        """Check if API credentials are configured"""
        from dotenv import load_dotenv
        load_dotenv()
        
        paper_key = os.getenv('ALPACA_PAPER_API_KEY')
        paper_secret = os.getenv('ALPACA_PAPER_API_SECRET')
        
        if not paper_key or not paper_secret:
            logger.error("❌ Alpaca API credentials not found in .env file")
            return False
        
        logger.info("✅ API credentials configured")
        return True
    
    def kill_existing_bots(self):
        """Kill any existing bot processes"""
        killed = 0
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                cmdline = proc.info.get('cmdline', [])
                if cmdline and 'ultimate_unified_bot.py' in ' '.join(cmdline):
                    logger.info(f"Killing existing bot process: {proc.info['pid']}")
                    proc.kill()
                    killed += 1
            except Exception:
                pass
        
        if killed > 0:
            logger.info(f"✅ Killed {killed} existing bot processes")
    
    def launch_bot(self, mode='paper', use_gpu=True):
        """Launch the ultimate unified bot"""
        logger.info("\n" + "="*60)
        logger.info("🚀 LAUNCHING ULTIMATE UNIFIED BOT")
        logger.info("="*60)
        logger.info(f"Mode: {mode.upper()}")
        logger.info(f"GPU: {'Enabled' if use_gpu else 'Disabled'}")
        logger.info(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("="*60 + "\n")
        
        # Build command
        cmd = [sys.executable, 'ultimate_unified_bot.py', '--mode', mode]
        if not use_gpu:
            cmd.append('--no-gpu')
        
        # Launch bot
        self.bot_process = subprocess.Popen(cmd)
        logger.info(f"✅ Bot launched with PID: {self.bot_process.pid}")
        
        return self.bot_process
    
    def monitor_bot(self):
        """Monitor bot status"""
        import time
        
        logger.info("\n📊 Monitoring bot status...")
        logger.info("Press Ctrl+C to stop\n")
        
        try:
            while True:
                if self.bot_process.poll() is not None:
                    logger.warning("⚠️ Bot process terminated!")
                    break
                
                # Check resource usage
                try:
                    proc = psutil.Process(self.bot_process.pid)
                    cpu = proc.cpu_percent(interval=1)
                    memory = proc.memory_info().rss / 1e9
                    
                    print(f"\r💻 CPU: {cpu:.1f}% | 🧠 Memory: {memory:.2f} GB | ⏱️ Runtime: {datetime.now().strftime('%H:%M:%S')}", end='')
                except Exception:
                    pass
                
                time.sleep(5)
                
        except KeyboardInterrupt:
            logger.info("\n\nShutting down bot...")
            self.bot_process.terminate()
            self.bot_process.wait(timeout=10)
            logger.info("✅ Bot stopped")
    
    def run_diagnostics(self):
        """Run full system diagnostics"""
        logger.info("🔍 Running system diagnostics...\n")
        
        checks = []
            ("Dependencies", self.check_dependencies(),
            ("API Credentials", self.check_api_credentials(),
            ("System Resources", self.check_system_resources(),
            ("GPU Status", self.check_gpu_status()
        ]
        
        all_passed = all(result for _, result in checks)
        
        logger.info("\n📋 Diagnostic Summary:")
        for check, result in checks:
            status = "✅ PASS" if result else "❌ FAIL"
            logger.info(f"  {check}: {status}")
        
        return all_passed
    
    def quick_start(self):
        """Quick start with minimal checks"""
        logger.info("⚡ Quick start mode\n")
        
        # Kill existing bots
        self.kill_existing_bots()
        
        # Check credentials
        if not self.check_api_credentials():
            return
        
        # Check GPU
        use_gpu = self.check_gpu_status()
        
        # Launch bot
        self.launch_bot(mode='paper', use_gpu=use_gpu)
        
        # Monitor
        self.monitor_bot()

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Ultimate Bot Launcher')
    parser.add_argument('--mode', choices=['paper', 'live'], default='paper',
                       help='Trading mode')
    parser.add_argument('--quick', action='store_true',
                       help='Quick start with minimal checks')
    parser.add_argument('--diagnose', action='store_true',
                       help='Run diagnostics only')
    parser.add_argument('--no-gpu', action='store_true',
                       help='Disable GPU acceleration')
    
    args = parser.parse_args()
    
    launcher = UltimateBotLauncher()
    
    if args.diagnose:
        # Run diagnostics only
        launcher.run_diagnostics()
        return
    
    if args.quick:
        # Quick start
        launcher.quick_start()
        return
    
    # Full launch sequence
    logger.info("🚀 Ultimate Unified Bot Launcher\n")
    
    # Run diagnostics
    if not launcher.run_diagnostics():
        logger.error("\n❌ Diagnostics failed! Fix issues before launching.")
        return
    
    # Kill existing bots
    launcher.kill_existing_bots()
    
    # Safety check for live mode
    if args.mode == 'live':
        logger.warning("\n⚠️  WARNING: LIVE TRADING MODE!")
        logger.warning("This will trade with REAL MONEY!")
        response = input("Type 'CONFIRM LIVE TRADING' to continue: ")
        if response != 'CONFIRM LIVE TRADING':
            logger.info("Aborting...")
            return
    
    # Launch bot
    use_gpu = not args.no_gpu and launcher.check_gpu_status()
    launcher.launch_bot(mode=args.mode, use_gpu=use_gpu)
    
    # Monitor
    launcher.monitor_bot()

if __name__ == "__main__":
    main()