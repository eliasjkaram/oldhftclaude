#!/usr/bin/env python3
"""
Verify Trade Execution
======================
Check if trades are actually being executed and fix any issues.
"""

import os
import json
from datetime import datetime, timedelta
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import GetOrdersRequest
from alpaca.trading.enums import QueryOrderStatus
from dotenv import load_dotenv
import pandas as pd

load_dotenv()

class TradeVerifier:
    def __init__(self):
        self.api_key = os.getenv('ALPACA_API_KEY', 'PKEP9PIBDKOSUGHHY44Z')
        self.api_secret = os.getenv('ALPACA_API_SECRET', 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ')
        self.client = TradingClient(self.api_key, self.api_secret, paper=True)
    
    def check_recent_orders(self, hours=24):
        """Check orders from the last N hours"""
        print(f"\n📋 Checking orders from last {hours} hours...")
        
        request = GetOrdersRequest()
            status=QueryOrderStatus.ALL,
            after=datetime.now() - timedelta(hours=hours),
            limit=500
        )
        
        orders = self.client.get_orders(request)
        
        if not orders:
            print("❌ NO ORDERS FOUND!")
            return None
        
        # Analyze orders
        order_data = []
        for order in orders:
            order_data.append({)
                'created_at': order.created_at,
                'symbol': order.symbol,
                'side': order.side.value,
                'qty': order.qty,
                'type': order.order_type.value,
                'status': order.status.value,
                'filled_qty': order.filled_qty,
                'filled_avg_price': order.filled_avg_price
            })
        
        df = pd.DataFrame(order_data)
        
        print(f"\n✅ Found {len(df)} orders")
        print(f"\nOrder Status Breakdown:")
        print(df['status'].value_counts())
        
        print(f"\nSymbols Traded:")
        print(df['symbol'].value_counts().head(10))
        
        return df
    
    def check_positions(self):
        """Check current positions"""
        print("\n📊 Current Positions:")
        
        positions = self.client.get_all_positions()
        
        if not positions:
            print("No open positions")
            return
        
        total_value = 0
        for pos in positions:
            value = float(pos.qty) * float(pos.current_price if hasattr(pos, 'current_price') else pos.avg_entry_price)
            total_value += value
            
            print(f"\n{pos.symbol}:")
            print(f"  Quantity: {pos.qty}")
            print(f"  Avg Price: ${float(pos.avg_entry_price):.2f}")
            print(f"  Value: ${value:,.2f}")
        
        print(f"\nTotal Position Value: ${total_value:,.2f}")
    
    def check_execution_logs(self):
        """Check execution logs"""
        print("\n📝 Checking execution logs...")
        
        log_file = 'trade_execution_log.json'
        if not os.path.exists(log_file):
            print("❌ No execution log file found!")
            print("This suggests trades are NOT being logged properly")
            return
        
        # Read last 100 lines
        with open(log_file, 'r') as f:
            lines = f.readlines()[-100:]
        
        if not lines:
            print("❌ Log file is empty!")
            return
        
        # Parse logs
        executions = []
        for line in lines:
            try:
                executions.append(json.loads(line))
            except:
                pass
        
        if executions:
            print(f"✅ Found {len(executions)} logged executions")
            
            # Show recent executions
            print("\nRecent Executions:")
            for exec in executions[-5:]:
                print(f"\n{exec.get('timestamp', 'Unknown time')}:")
                print(f"  Symbol: {exec.get('symbol', 'N/A')}")
                print(f"  Strategy: {exec.get('strategy', 'N/A')}")
                print(f"  Expected Profit: ${exec.get('expected_profit', 0):.2f}")
                print(f"  Status: {exec.get('status', 'N/A')}")
        else:
            print("❌ No valid executions in log!")
    
    def diagnose_issues(self):
        """Diagnose why trades might not be executing"""
        print("\n🔍 Diagnosing potential issues...")
        
        account = self.client.get_account()
        
        issues = []
        
        # Check account status
        if account.trading_blocked:
            issues.append("❌ Trading is BLOCKED on this account!")
        
        if account.account_blocked:
            issues.append("❌ Account is BLOCKED!")
        
        # Check buying power
        buying_power = float(account.buying_power)
        if buying_power < 100:
            issues.append(f"⚠️  Low buying power: ${buying_power:.2f}")
        
        # Check day trading
        if not account.pattern_day_trader and float(account.daytrade_count) >= 3:
            issues.append("⚠️  Approaching day trade limit (non-PDT account)")
        
        # Check if market is open
        from datetime import datetime
        now = datetime.now()
        if now.weekday() >= 5:  # Weekend
            issues.append("ℹ️  Market is closed (weekend)")
        elif now.hour < 9 or now.hour >= 16:  # Outside market hours
            issues.append("ℹ️  Market is closed (outside hours)")
        
        if issues:
            print("\nFound issues:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("✅ No obvious issues found")
        
        return issues

def main():
    print("=" * 80)
    print("🔍 TRADE EXECUTION VERIFICATION")
    print("=" * 80)
    print(f"Time: {datetime.now()}")
    print("=" * 80)
    
    verifier = TradeVerifier()
    
    # 1. Check account
    account = verifier.client.get_account()
    print(f"\n💳 Account Status:")
    print(f"   Number: {account.account_number}")
    print(f"   Status: {'ACTIVE' if not account.account_blocked else 'BLOCKED'}")
    print(f"   Cash: ${float(account.cash):,.2f}")
    print(f"   Buying Power: ${float(account.buying_power):,.2f}")
    print(f"   Can Trade: {'YES' if not account.trading_blocked else 'NO'}")
    
    # 2. Check recent orders
    orders_df = verifier.check_recent_orders(hours=24)
    
    # 3. Check positions
    verifier.check_positions()
    
    # 4. Check execution logs
    verifier.check_execution_logs()
    
    # 5. Diagnose issues
    verifier.diagnose_issues()
    
    # 6. Recommendations
    print("\n" + "=" * 80)
    print("📌 RECOMMENDATIONS:")
    print("=" * 80)
    
    if orders_df is None or orders_df.empty:
        print("\n❌ NO TRADES ARE BEING EXECUTED!")
        print("\nTo fix this:")
        print("1. Stop current systems: pkill -f python")
        print("2. Run the fixed execution system:")
        print("   python fix_trade_execution_system.py")
    else:
        filled_orders = orders_df[orders_df['status'] == 'filled']
        if filled_orders.empty:
            print("\n⚠️  Orders are being placed but NOT FILLED")
            print("Possible reasons:")
            print("  • Limit prices too far from market")
            print("  • Insufficient buying power")
            print("  • Market closed")
        else:
            print(f"\n✅ {len(filled_orders)} orders were filled successfully!")
    
    print("\n💡 To ensure proper execution:")
    print("1. Use the enhanced execution system")
    print("2. Monitor logs: tail -f trade_execution.log")
    print("3. Expand symbol universe for more opportunities")
    print("4. Ensure AI discoveries trigger real orders")
    
    print("\n" + "=" * 80)

if __name__ == "__main__":
    main()