
#!/usr/bin/env python3
"""
Real Alpaca API Integration Module
Provides live market data and trading capabilities
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import requests
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pandas as pd
import numpy as np
from dataclasses import dataclass
import asyncio
import aiohttp

from universal_market_data import get_current_market_data, validate_price


logger = logging.getLogger('alpaca_integration')

@dataclass
class AlpacaConfig:
    """Alpaca API configuration"""
    endpoint: str
    key: str
    secret: str
    
class AlpacaClient:
    """Enhanced Alpaca API client with comprehensive features"""
    
    def __init__(self, config: AlpacaConfig):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({)
            'APCA-API-KEY-ID': config.key,
            'APCA-API-SECRET-KEY': config.secret,
            'Content-Type': 'application/json'
        })
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 0.2  # 200ms between requests
        
    def _rate_limit(self):
        """Implement rate limiting"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
            
        self.last_request_time = time.time()
        
    def _make_request(self, method: str, endpoint: str, params: Dict = None, data: Dict = None) -> Dict:
        """Make authenticated API request"""
        self._rate_limit()
        
        url = f"{self.config.endpoint}/{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(url, params=params)
            elif method.upper() == 'POST':
                response = self.session.post(url, json=data)
            elif method.upper() == 'DELETE':
                response = self.session.delete(url)
            else:
                raise ValueError(f"Unsupported method: {method}")
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response: {e.response.text}")
            raise
            
    def get_account(self) -> Dict:
        """Get account information"""
        return self._make_request('GET', 'account')
        
    def get_positions(self) -> List[Dict]:
        """Get all positions"""
        return self._make_request('GET', 'positions')
        
    def get_orders(self, status: str = 'all') -> List[Dict]:
        """Get orders"""
        params = {'status': status}
        return self._make_request('GET', 'orders', params=params)
        
    def get_market_data(self, symbol: str, timeframe: str = '1Day', 
                       start: str = None, end: str = None) -> Dict:
        """Get market data for symbol"""
        # Use data API v2
        data_endpoint = self.config.endpoint.replace('/v2', '/v2/stocks')
        
        params = {}
            'symbols': symbol,
            'timeframe': timeframe,
            'adjustment': 'all'
        }
        
        if start:
            params['start'] = start
        if end:
            params['end'] = end
            
        url = f"{data_endpoint}/{symbol}/bars"
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Market data request failed: {e}")
            return self._simulate_market_data(symbol)
            
    def get_latest_quote(self, symbol: str) -> Dict:
        """Get latest quote for symbol"""
        try:
            data_endpoint = self.config.endpoint.replace('/v2', '/v2/stocks')
            url = f"{data_endpoint}/{symbol}/quotes/latest"
            
            response = self.session.get(url)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Quote request failed: {e}")
            return self._simulate_quote(symbol)
            
    def get_latest_trade(self, symbol: str) -> Dict:
        """Get latest trade for symbol"""
        try:
            data_endpoint = self.config.endpoint.replace('/v2', '/v2/stocks')
            url = f"{data_endpoint}/{symbol}/trades/latest"
            
            response = self.session.get(url)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Trade request failed: {e}")
            return self._simulate_trade(symbol)
            
    def get_options_chain(self, symbol: str) -> Dict:
        """Get options chain for symbol"""
        try:
            # Note: Alpaca options API endpoint
            options_endpoint = self.config.endpoint.replace('/v2', '/v1beta1/options')
            url = f"{options_endpoint}/contracts"
            
            params = {}
                'underlying_symbol': symbol,
                'status': 'active'
            }
            
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Options chain request failed: {e}")
            return self._simulate_options_chain(symbol)
            
    def submit_order(self, symbol: str, qty: int, side: str, order_type: str = 'market',
                    time_in_force: str = 'day', limit_price: float = None) -> Dict:
        """Submit order"""
        order_data = {}
            'symbol': symbol,
            'qty': qty,
            'side': side,
            'type': order_type,
            'time_in_force': time_in_force
        }
        
        if limit_price and order_type == 'limit':
            order_data['limit_price'] = str(limit_price)
            
        logger.info(f"Submitting order: {order_data}")
        return self._make_request('POST', 'orders', data=order_data)
        
    def cancel_order(self, order_id: str) -> Dict:
        """Cancel order"""
        return self._make_request('DELETE', f'orders/{order_id}')
        
    def get_portfolio_history(self, period: str = '1M') -> Dict:
        """Get portfolio history"""
        params = {'period': period, 'timeframe': '1D'}
        return self._make_request('GET', 'account/portfolio/history', params=params)
        
    def _simulate_market_data(self, symbol: str) -> Dict:
        """Simulate market data when API fails"""
        logger.warning(f"Simulating market data for {symbol}")
        
        # Generate realistic OHLCV data
        prices = [get_realistic_price(s) for s in symbols]
        dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
        
        bars = []
        current_price = base_price
        
        for date in dates:
            # Random walk with some volatility
            change = np.random.normal(0, 0.02)
            current_price *= (1 + change)
            
            high = current_price * (1 + abs(np.random.normal(0, 0.01)))
            low = current_price * (1 - abs(np.random.normal(0, 0.01)))
            open_price = current_price * (1 + np.random.normal(0, 0.005))
            volume = np.random.randint(100000, 5000000)
            
            bars.append({)
                't': date.isoformat(),
                'o': round(open_price, 2),
                'h': round(high, 2),
                'l': round(low, 2),
                'c': round(current_price, 2),
                'v': volume
            })
            
        return {}
            'bars': {symbol: bars},
            'next_page_token': None
        }
        
    def _simulate_quote(self, symbol: str) -> Dict:
        """Simulate quote data"""
        prices = [get_realistic_price(s) for s in symbols]
        spread = price * 0.001  # 0.1% spread
        
        return {}
            'quote': {}
                'ap': round(price + spread/2, 2),  # Ask price
                'as': np.random.randint(1, 10) * 100,  # Ask size
                'bp': round(price - spread/2, 2),  # Bid price
                'bs': np.random.randint(1, 10) * 100,  # Bid size
                't': datetime.now().isoformat()
            }
        }
        
    def _simulate_trade(self, symbol: str) -> Dict:
        """Simulate trade data"""
        prices = [get_realistic_price(s) for s in symbols]
        
        return {}
            'trade': {}
                'p': round(price, 2),  # Price
                's': np.random.randint(1, 1000) * 100,  # Size
                't': datetime.now().isoformat()
            }
        }
        
    def _simulate_options_chain(self, symbol: str) -> Dict:
        """Simulate options chain"""
        logger.warning(f"Simulating options chain for {symbol}")
        
        # Get current price
        prices = [get_realistic_price(s) for s in symbols]
        
        contracts = []
        
        # Generate contracts for next 3 expirations
        for weeks in [1, 2, 4]:
            expiry = datetime.now() + timedelta(weeks=weeks)
            
            # Generate strikes around current price
            strikes = np.arange()
                round(current_price * 0.8, 0),
                round(current_price * 1.2, 0),
                5
            )
            
            for strike in strikes:
                for option_type in ['call', 'put']:
                    # Calculate theoretical option price
                    moneyness = strike / current_price
                    time_value = weeks / 52.0  # Time to expiry in years
                    
                    if option_type == 'call':
                        intrinsic = max(0, current_price - strike)
                    else:
                        intrinsic = max(0, strike - current_price)
                        
                    # Simple time value calculation
                    time_premium = current_price * 0.25 * np.sqrt(time_value) * 0.4
                    price = intrinsic + time_premium
                    
                    contracts.append({)
                        'id': f"{symbol}{expiry.strftime('%y%m%d')}{option_type[0].upper()}{int(strike):08d}",
                        'symbol': symbol,
                        'name': f"{symbol} {expiry.strftime('%m/%d/%y')} {strike} {option_type.title()}",
                        'status': 'active',
                        'tradable': True,
                        'expiration_date': expiry.strftime('%Y-%m-%d'),
                        'strike_price': str(strike),
                        'option_type': option_type,
                        'underlying_symbol': symbol,
                        'bid': round(max(0.01, price * 0.95), 2),
                        'ask': round(price * 1.05, 2),
                        'last': round(price, 2),
                        'volume': np.random.randint(0, 1000),
                        'open_interest': np.random.randint(100, 10000),
                        'implied_volatility': round(np.random.uniform(0.2, 0.6), 3),
                        'delta': round(np.random.uniform(-1, 1), 3),
                        'gamma': round(np.random.uniform(0, 0.1), 4),
                        'theta': round(np.random.uniform(-0.1, 0), 4),
                        'vega': round(np.random.uniform(0, 0.5), 3)
                    })
                    
        return {'options_contracts': contracts}

class EnhancedMarketScanner:
    """Enhanced market scanner with real Alpaca data"""
    
    def __init__(self, alpaca_client: AlpacaClient):
        self.alpaca = alpaca_client
        self.logger = logging.getLogger('market_scanner')
        
        # Comprehensive symbol lists
        self.symbol_lists = {}
            'SPY_ETFs': ['SPY', 'QQQ', 'IWM', 'EFA', 'EEM', 'VTI', 'VEA', 'VWO', 'GLD', 'SLV'],
            'FAANG_Plus': ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA', 'NFLX', 'CRM', 'ADBE'],
            'Blue_Chips': ['JPM', 'JNJ', 'PG', 'KO', 'DIS', 'WMT', 'HD', 'V', 'MA', 'UNH', 'BAC', 'XOM'],
            'High_Volume': ['SPY', 'QQQ', 'TSLA', 'AAPL', 'AMD', 'F', 'BAC', 'PFE', 'T', 'PLTR'],
            'Meme_Stocks': ['GME', 'AMC', 'BB', 'NOK', 'WISH', 'CLOV', 'SNDL', 'NAKD'],
            'Growth_Tech': ['ARKK', 'ARKQ', 'ARKW', 'PLTR', 'SNOW', 'COIN', 'RBLX', 'ZM', 'PTON', 'ROKU'],
            'Financials': ['JPM', 'BAC', 'WFC', 'C', 'GS', 'MS', 'USB', 'PNC', 'TFC', 'COF'],
            'Energy': ['XOM', 'CVX', 'COP', 'EOG', 'SLB', 'MPC', 'VLO', 'PSX', 'KMI', 'OKE'],
            'Healthcare': ['JNJ', 'PFE', 'ABT', 'TMO', 'DHR', 'BMY', 'AMGN', 'GILD', 'MDT', 'CI'],
            'Consumer': ['AMZN', 'WMT', 'HD', 'MCD', 'NKE', 'SBUX', 'TGT', 'LOW', 'TJX', 'DG']
        }
        
    async def scan_all_markets(self, callback=None) -> Dict[str, Dict]:
        """Comprehensive market scan with real data"""
        self.logger.info("Starting comprehensive market scan with real data")
        
        all_symbols = set()
        for category, symbols in self.symbol_lists.items():
            all_symbols.update(symbols)
            
        all_symbols = list(all_symbols)
        self.logger.info(f"Scanning {len(all_symbols)} unique symbols")
        
        results = {}
        
        # Process in batches to avoid overwhelming API
        batch_size = 10
        for i in range(0, len(all_symbols), batch_size):
            batch = all_symbols[i:i+batch_size]
            
            # Process batch concurrently
            tasks = [self._analyze_symbol_comprehensive(symbol) for symbol in batch]
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for symbol, result in zip(batch, batch_results):
                if isinstance(result, Exception):
                    self.logger.error(f"Error analyzing {symbol}: {result}")
                    continue
                    
                results[symbol] = result
                
                if callback:
account = self.trading_client.get_account()
                    
            # Small delay between batches
            await asyncio.sleep(1)
            
        self.logger.info(f"Market scan complete. Analyzed {len(results)} symbols")
        return results
        
    async def _analyze_symbol_comprehensive(self, symbol: str) -> Dict:
        """Comprehensive analysis of individual symbol"""
        try:
            # Get market data
            market_data = self.alpaca.get_market_data(symbol, timeframe='1Day')
            quote_data = self.alpaca.get_latest_quote(symbol)
            trade_data = self.alpaca.get_latest_trade(symbol)
            
            # Extract current price and volume
            if 'bars' in market_data and symbol in market_data['bars']:
                bars = market_data['bars'][symbol]
                if bars:
                    latest_bar = bars[-1]
                    current_price = latest_bar['c']
                    volume = latest_bar['v']
                    
                    # Calculate volatility from recent bars
                    if len(bars) >= 20:
                        prices = [bar['c'] for bar in bars[-20:]]
                        returns = np.diff(np.log(prices)
                        volatility = np.std(returns) * np.sqrt(252)
                    else:
                        volatility = 0.25  # Default
                else:
                    current_price = 100.0
                    volume = 1000000
                    volatility = 0.25
            else:
                current_price = 100.0
                volume = 1000000
                volatility = 0.25
                
            # Technical analysis
            technical_analysis = self._calculate_technical_indicators(market_data, symbol)
            
            # Market regime detection
            regime = self._detect_market_regime(technical_analysis, volatility)
            
            # Strategy recommendations
            strategy_recommendations = self._recommend_strategies()
                symbol, current_price, volatility, technical_analysis, regime
            )
            
            # Options analysis
            options_analysis = await self._analyze_options(symbol, current_price)
            
            return {}
                'symbol': symbol,
                'price': current_price,
                'volume': volume,
                'volatility': volatility,
                'technical': technical_analysis,
                'regime': regime,
                'strategies': strategy_recommendations,
                'options': options_analysis,
                'timestamp': datetime.now().isoformat(),
                'data_source': 'alpaca_live'
            }
            
        except Exception as e:
            self.logger.error(f"Error in comprehensive analysis for {symbol}: {e}")
            return self._fallback_analysis(symbol)
            
    def _calculate_technical_indicators(self, market_data: Dict, symbol: str) -> Dict:
        """Calculate technical indicators from market data"""
        try:
            if 'bars' not in market_data or symbol not in market_data['bars']:
                return self._default_technical_indicators()
                
            bars = market_data['bars'][symbol]
            if len(bars) < 20:
                return self._default_technical_indicators()
                
            # Convert to DataFrame
            df = pd.DataFrame(bars)
            df['close'] = df['c']
            df['high'] = df['h']
            df['low'] = df['l']
            df['volume'] = df['v']
            
            # Calculate indicators
            indicators = {}
            
            # Moving averages
            indicators['sma_20'] = df['close'].rolling(20).mean().iloc[-1]
            indicators['sma_50'] = df['close'].rolling(50).mean().iloc[-1] if len(df) >= 50 else indicators['sma_20']
            
            # RSI
            delta = df['close'].diff()
            gain = (delta.where(delta > 0, 0).rolling(14).mean())
            loss = (-delta.where(delta < 0, 0).rolling(14).mean())
            rs = gain / loss
            indicators['rsi'] = 100 - (100 / (1 + rs).iloc[-1]
            
            # MACD
            ema_12 = df['close'].ewm(span=12).mean()
            ema_26 = df['close'].ewm(span=26).mean()
            indicators['macd'] = (ema_12 - ema_26).iloc[-1]
            indicators['macd_signal'] = (ema_12 - ema_26).ewm(span=9).mean().iloc[-1]
            
            # Bollinger Bands
            bb_middle = df['close'].rolling(20).mean()
            bb_std = df['close'].rolling(20).std()
            indicators['bb_upper'] = (bb_middle + 2 * bb_std).iloc[-1]
            indicators['bb_lower'] = (bb_middle - 2 * bb_std).iloc[-1]
            
            # Support/Resistance
            indicators['support'] = df['low'].rolling(20).min().iloc[-1]
            indicators['resistance'] = df['high'].rolling(20).max().iloc[-1]
            
            # Volume trend
            volume_ma = df['volume'].rolling(10).mean()
            indicators['volume_trend'] = 'increasing' if df['volume'].iloc[-1] > volume_ma.iloc[-1] else 'decreasing'
            
            return indicators
            
        except Exception as e:
            self.logger.error(f"Error calculating technical indicators: {e}")
            return self._default_technical_indicators()
            
    def _default_technical_indicators(self) -> Dict:
        """Default technical indicators when calculation fails"""
        return {}
            'sma_20': 100.0,
            'sma_50': 100.0,
            'rsi': 50.0,
            'macd': 0.0,
            'macd_signal': 0.0,
            'bb_upper': 105.0,
            'bb_lower': 95.0,
            'support': 95.0,
            'resistance': 105.0,
            'volume_trend': 'neutral'
        }
        
    def _detect_market_regime(self, technical: Dict, volatility: float) -> str:
        """Detect market regime based on technical indicators"""
        try:
            # Price trend
            if technical['sma_20'] > technical['sma_50'] * 1.02:
                trend = 'bullish'
            elif technical['sma_20'] < technical['sma_50'] * 0.98:
                trend = 'bearish'
            else:
                trend = 'sideways'
                
            # Volatility regime
            if volatility > 0.4:
                vol_regime = 'high'
            elif volatility < 0.2:
                vol_regime = 'low'
            else:
                vol_regime = 'normal'
                
            # RSI momentum
            if technical['rsi'] > 70:
                momentum = 'overbought'
            elif technical['rsi'] < 30:
                momentum = 'oversold'
            else:
                momentum = 'neutral'
                
            # Combine into regime
            if vol_regime == 'high':
                return 'high_volatility'
            elif vol_regime == 'low' and trend == 'sideways':
                return 'low_volatility_sideways'
            elif trend == 'bullish' and momentum != 'overbought':
                return 'bull_trend'
            elif trend == 'bearish' and momentum != 'oversold':
                return 'bear_trend'
            else:
                return 'sideways'
                
        except Exception as e:
            self.logger.error(f"Error detecting market regime: {e}")
            return 'uncertain'
            
    def _recommend_strategies(self, symbol: str, price: float, volatility: float, 
                            technical: Dict, regime: str) -> List[Dict]:
        """Recommend trading strategies based on analysis"""
        strategies = []
        
        try:
            # Wheel Strategy
            if regime in ['sideways', 'low_volatility_sideways'] and 30 <= technical['rsi'] <= 70:
                strategies.append({)
                    'name': 'wheel_strategy',
                    'confidence': 0.85 + (0.1 if volatility > 0.25 else 0),
                    'expected_return': 0.15,
                    'rationale': f"Sideways market with {volatility:.1%} volatility ideal for wheel strategy"
                })
                
            # Iron Condor
            if regime in ['sideways', 'low_volatility_sideways'] and volatility < 0.3:
                strategies.append({)
                    'name': 'iron_condor',
                    'confidence': 0.80,
                    'expected_return': 0.12,
                    'rationale': f"Low volatility ({volatility:.1%}) favors neutral strategies"
                })
                
            # Bull Call Spread
            if regime == 'bull_trend' and technical['rsi'] < 70:
                strategies.append({)
                    'name': 'bull_call_spread',
                    'confidence': 0.75,
                    'expected_return': 0.25,
                    'rationale': "Bullish trend detected with room for upward movement"
                })
                
            # Long Straddle
            if regime == 'high_volatility' or volatility > 0.4:
                strategies.append({)
                    'name': 'long_straddle',
                    'confidence': 0.70,
                    'expected_return': 0.30,
                    'rationale': f"High volatility ({volatility:.1%}) creates opportunities for large moves"
                })
                
            # Covered Call
            if regime in ['bull_trend', 'sideways'] and technical['rsi'] > 50:
                strategies.append({)
                    'name': 'covered_call',
                    'confidence': 0.65,
                    'expected_return': 0.08,
                    'rationale': "Moderate bullish conditions favor income generation"
                })
                
            # Sort by confidence
            strategies.sort(key=lambda x: x['confidence'], reverse=True)
            
            return strategies[:3]  # Return top 3
            
        except Exception as e:
            self.logger.error(f"Error recommending strategies: {e}")
            return [{]
                'name': 'wheel_strategy',
                'confidence': 0.70,
                'expected_return': 0.15,
                'rationale': 'Default conservative strategy'
            }]
            
    async def _analyze_options(self, symbol: str, current_price: float) -> Dict:
        """Analyze options for the symbol"""
        try:
            options_chain = self.alpaca.get_options_chain(symbol)
            
            if 'options_contracts' not in options_chain:
                return {'available': False, 'reason': 'No options data'}
                
            contracts = options_chain['options_contracts']
            
            # Filter for liquid options
            liquid_contracts = []
                c for c in contracts 
                if c.get('volume', 0) > 10 and c.get('open_interest', 0) > 100
            ]
            
            # Find ATM options
            atm_calls = []
                c for c in liquid_contracts 
                if c['option_type'] == 'call' and 
                abs(float(c['strike_price']) - current_price) < current_price * 0.05
            ]
            
            atm_puts = []
                c for c in liquid_contracts 
                if c['option_type'] == 'put' and 
                abs(float(c['strike_price']) - current_price) < current_price * 0.05
            ]
            
            # Calculate average IV
            all_ivs = [float(c.get('implied_volatility', 0.25)) for c in liquid_contracts if c.get('implied_volatility')]
            avg_iv = np.mean(all_ivs) if all_ivs else 0.25
            
            return {}
                'available': True,
                'total_contracts': len(contracts),
                'liquid_contracts': len(liquid_contracts),
                'atm_calls': len(atm_calls),
                'atm_puts': len(atm_puts),
                'avg_implied_volatility': avg_iv,
                'iv_percentile': self._calculate_iv_percentile(avg_iv),
                'recommended_dte': self._recommend_dte(contracts)
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing options for {symbol}: {e}")
            return {}
                'available': False,
                'reason': f'Analysis failed: {str(e)}'
            }
            
    def _calculate_iv_percentile(self, current_iv: float) -> float:
        """Calculate IV percentile (simplified)"""
        # Simplified calculation - in practice would use historical IV data
        if current_iv < 0.2:
            return 20.0
        elif current_iv < 0.3:
            return 50.0
        elif current_iv < 0.4:
            return 75.0
        else:
            return 90.0
            
    def _recommend_dte(self, contracts: List[Dict]) -> int:
        """Recommend optimal DTE based on available contracts"""
        try:
            # Get unique expiration dates
            expiry_dates = list(set(c['expiration_date'] for c in contracts)
            
            # Calculate DTE for each
            dtes = []
            for expiry in expiry_dates:
                expiry_dt = datetime.strptime(expiry, '%Y-%m-%d')
                dte = (expiry_dt - datetime.now().days)
                if 7 <= dte <= 60:  # Reasonable range
                    dtes.append(dte)
                    
            # Recommend 30-45 day range if available
            preferred_dtes = [dte for dte in dtes if 30 <= dte <= 45]
            if preferred_dtes:
                return min(preferred_dtes)
            elif dtes:
                return min(dtes, key=lambda x: abs(x - 35)  # Closest to 35 days)
            else:
                return 30  # Default
                
        except Exception as e:
            self.logger.error(f"Error recommending DTE: {e}")
            return 30
            
    def _fallback_analysis(self, symbol: str) -> Dict:
        """Fallback analysis when API fails"""
        self.logger.warning(f"Using fallback analysis for {symbol}")
        
        return {}
            'symbol': symbol,
            'price': np.random.uniform(50, 200),
            'volume': np.random.randint(100000, 5000000),
            'volatility': np.random.uniform(0.15, 0.45),
            'technical': self._default_technical_indicators(),
            'regime': 'sideways',
            'strategies': [{]
                'name': 'wheel_strategy',
                'confidence': 0.70,
                'expected_return': 0.15,
                'rationale': 'Default strategy for market neutral conditions'
            }],
            'options': {'available': False, 'reason': 'Fallback mode'},
            'timestamp': datetime.now().isoformat(),
            'data_source': 'simulated'
        }

# Automated trading engine
class AutomatedTradingEngine:
    """Automated trading engine with risk management"""
    
    def __init__(self, alpaca_client: AlpacaClient):
        self.alpaca = alpaca_client
        self.logger = logging.getLogger('auto_trading')
        self.active_trades = {}
        self.trading_enabled = False
        
        # Risk parameters
        self.max_position_size = 1000  # $1000 max per position
        self.max_daily_trades = 10
        self.max_portfolio_risk = 0.05  # 5% max portfolio risk
        self.daily_trade_count = 0
        self.last_trade_date = datetime.now().date()
        
    def enable_trading(self):
        """Enable automated trading"""
        self.trading_enabled = True
        self.logger.info("Automated trading ENABLED")
        
    def disable_trading(self):
        """Disable automated trading"""
        self.trading_enabled = False
        self.logger.info("Automated trading DISABLED")
        
    def reset_daily_counters(self):
        """Reset daily trade counters"""
        current_date = datetime.now().date()
        if current_date != self.last_trade_date:
            self.daily_trade_count = 0
            self.last_trade_date = current_date
            self.logger.info("Daily trade counters reset")
            
    def execute_strategy(self, symbol: str, strategy: Dict, market_analysis: Dict) -> Dict:
        """Execute trading strategy"""
        if not self.trading_enabled:
            return {'success': False, 'reason': 'Trading disabled'}
            
        self.reset_daily_counters()
        
        if self.daily_trade_count >= self.max_daily_trades:
            return {'success': False, 'reason': 'Daily trade limit reached'}
            
        try:
            strategy_name = strategy['name']
            confidence = strategy['confidence']
            
            # Risk check
            if confidence < 0.70:
                return {'success': False, 'reason': 'Confidence too low'}
                
            # Execute based on strategy type
            if strategy_name == 'wheel_strategy':
                return self._execute_wheel_strategy(symbol, market_analysis)
            elif strategy_name == 'iron_condor':
                return self._execute_iron_condor(symbol, market_analysis)
            elif strategy_name == 'covered_call':
                return self._execute_covered_call(symbol, market_analysis)
            else:
                return {'success': False, 'reason': f'Strategy {strategy_name} not implemented'}
                
        except Exception as e:
            self.logger.error(f"Error executing strategy: {e}")
            return {'success': False, 'reason': str(e)}
            
    def _execute_wheel_strategy(self, symbol: str, analysis: Dict) -> Dict:
        """Execute wheel strategy (simplified)"""
        try:
            # For demo purposes, we'll simulate the order
            current_price = analysis['price']
            strike = round(current_price * 0.95, 0)  # 5% OTM put
            
            self.logger.info(f"Executing wheel strategy on {symbol}: Sell {strike} put")
            
            # In real implementation, would place actual options order
            trade_result = {}
                'symbol': symbol,
                'strategy': 'wheel_strategy',
                'action': 'sell_put',
                'strike': strike,
                'premium': current_price * 0.02,  # Estimated premium
                'timestamp': datetime.now().isoformat(),
                'simulated': True
            }
            
            self.active_trades[f"{symbol}_wheel"] = trade_result
            self.daily_trade_count += 1
            
            return {'success': True, 'trade': trade_result}
            
        except Exception as e:
            self.logger.error(f"Error executing wheel strategy: {e}")
            return {'success': False, 'reason': str(e)}
            
    def _execute_iron_condor(self, symbol: str, analysis: Dict) -> Dict:
        """Execute iron condor strategy (simplified)"""
        try:
            current_price = analysis['price']
            
            # Iron condor strikes
            call_strike_short = round(current_price * 1.05, 0)
            call_strike_long = round(current_price * 1.10, 0)
            put_strike_short = round(current_price * 0.95, 0)
            put_strike_long = round(current_price * 0.90, 0)
            
            self.logger.info(f"Executing iron condor on {symbol}")
            
            trade_result = {}
                'symbol': symbol,
                'strategy': 'iron_condor',
                'call_strikes': [call_strike_short, call_strike_long],
                'put_strikes': [put_strike_short, put_strike_long],
                'net_credit': current_price * 0.015,  # Estimated credit
                'timestamp': datetime.now().isoformat(),
                'simulated': True
            }
            
            self.active_trades[f"{symbol}_condor"] = trade_result
            self.daily_trade_count += 1
            
            return {'success': True, 'trade': trade_result}
            
        except Exception as e:
            self.logger.error(f"Error executing iron condor: {e}")
            return {'success': False, 'reason': str(e)}
            
    def _execute_covered_call(self, symbol: str, analysis: Dict) -> Dict:
        """Execute covered call strategy (simplified)"""
        try:
            current_price = analysis['price']
            
            # Check if we own the stock (simplified check)
            positions = self.alpaca.get_positions()
            has_stock = any(pos['symbol'] == symbol and int(pos['qty']) >= 100)
                          for pos in positions)
            
            if not has_stock:
                # Buy 100 shares first
                self.logger.info(f"Buying 100 shares of {symbol} for covered call")
                # In real implementation, would place stock order
                
            call_strike = round(current_price * 1.05, 0)  # 5% OTM call
            
            self.logger.info(f"Executing covered call on {symbol}: Sell {call_strike} call")
            
            trade_result = {}
                'symbol': symbol,
                'strategy': 'covered_call',
                'shares': 100,
                'call_strike': call_strike,
                'premium': current_price * 0.01,  # Estimated premium
                'timestamp': datetime.now().isoformat(),
                'simulated': True
            }
            
            self.active_trades[f"{symbol}_cc"] = trade_result
            self.daily_trade_count += 1
            
            return {'success': True, 'trade': trade_result}
            
        except Exception as e:
            self.logger.error(f"Error executing covered call: {e}")
            return {'success': False, 'reason': str(e)}
            
    def get_active_trades(self) -> List[Dict]:
        """Get all active trades"""
        return list(self.active_trades.values()
        
    def get_portfolio_summary(self) -> Dict:
        """Get portfolio summary"""
        try:
            account = self.alpaca.get_account()
            positions = self.alpaca.get_positions()
            
            return {}
                'equity': float(account.get('equity', 0)),
                'buying_power': float(account.get('buying_power', 0)),
                'day_trade_buying_power': float(account.get('day_trade_buying_power', 0)),
                'position_count': len(positions),
                'active_trades': len(self.active_trades),
                'daily_trades': self.daily_trade_count,
                'trading_enabled': self.trading_enabled
            }
            
        except Exception as e:
            self.logger.error(f"Error getting portfolio summary: {e}")
            return {}
                'equity': 0,
                'buying_power': 0,
                'position_count': 0,
                'active_trades': len(self.active_trades),
                'daily_trades': self.daily_trade_count,
                'trading_enabled': self.trading_enabled
            }