#!/usr/bin/env python3
"""
Launcher for V7 Simple Trading System
Checks dependencies and runs the trading system
"""

import subprocess
import sys

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


def check_and_install_dependencies():
    """Check if required packages are installed, install if missing"""
    required_packages = {}
        'yfinance': 'yfinance',
        'matplotlib': 'matplotlib'
    }
    
    missing_packages = []
    
    for package_import, package_name in required_packages.items():
        try:
            __import__(package_import)
            print(f"✓ {package_name} is installed")
        except ImportError:
            missing_packages.append(package_name)
            print(f"✗ {package_name} is not installed")
    
    if missing_packages:
        print("\nInstalling missing packages...")
        for package in missing_packages:
            print(f"Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print("\nAll dependencies installed successfully!")
    else:
        print("\nAll dependencies are already installed!")
    
    return True

def main():
    print("V7 Simple Trading System Launcher")
    print("=================================\n")
    
    print("Checking dependencies...")
    if check_and_install_dependencies():
        print("\nLaunching V7 Simple Trading System...\n")
        
        # Import and run the trading system
        try:
            from v7_simple_trading_system import main as run_trading_system
            run_trading_system()
        except Exception as e:
            print(f"Error launching trading system: {e}")
            sys.exit(1)
    else:
        print("Failed to setup dependencies")
        sys.exit(1)

if __name__ == "__main__":
    main()