
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Demo of historical data trading when markets are closed
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
import os
import json

class HistoricalTradingDemo:
    def __init__(self):
        self.results = []
        
    def is_market_open(self):
        """Check if US markets are open"""
        now = datetime.now()
        weekday = now.weekday()
        hour = now.hour
        
        # Simple check: Mon-Fri, 9:30 AM - 4 PM ET (adjust for your timezone)
        # For CEST (UTC+2), US market hours are roughly 15:30 - 22:00
        if weekday >= 5:  # Weekend
            return False, "Weekend"
        elif hour < 15 or hour >= 22:  # Adjust for CEST
            return False, f"Outside market hours (current hour: {hour})"
        else:
            return True, "Market hours"
    
    def get_random_historical_period(self):
        """Get a random 5-day period from 2022-2023"""
        start_year = random.choice([2022, 2023])
        start_month = random.randint(1, 12)
        start_day = random.randint(1, 20)  # Avoid month-end issues
        
        try:
            start_date = datetime(start_year, start_month, start_day)
        except:
            start_date = datetime(start_year, start_month, 1)
        
        # Find next Monday if not already
        while start_date.weekday() != 0:  # 0 is Monday
            start_date += timedelta(days=1)
        
        end_date = start_date + timedelta(days=4)  # 5 trading days
        
        return start_date, end_date
    
    def download_historical_data(self, symbol, start_date, end_date):
        """Download historical data from yfinance"""
        try:
            print(f"  Downloading {symbol} data...")
            data = YFinanceWrapper().download(symbol, start=start_date, end=end_date, progress=False)
            if data.empty:
                # Generate mock data if download fails
                dates = pd.date_range(start=start_date, end=end_date, freq='B')[:5]
                data = pd.DataFrame({)
                    'Open': np.random.uniform(100, 110, len(dates),
                    'High': np.random.uniform(110, 115, len(dates),
                    'Low': np.random.uniform(95, 100, len(dates),
                    'Close': np.random.uniform(100, 110, len(dates),
                    'Volume': np.random.randint(1000000, 5000000, len(dates)
                }, index=dates)
            return data
        except Exception as e:
            print(f"  Error downloading {symbol}: {e}")
            # Return mock data
            dates = pd.date_range(start=start_date, end=end_date, freq='B')[:5]
            return pd.DataFrame({)
                'Open': np.random.uniform(100, 110, len(dates),
                'High': np.random.uniform(110, 115, len(dates),
                'Low': np.random.uniform(95, 100, len(dates),
                'Close': np.random.uniform(100, 110, len(dates),
                'Volume': np.random.randint(1000000, 5000000, len(dates)
            }, index=dates)
    
    def run_momentum_strategy(self, data):
        """Simple momentum strategy"""
        if len(data) < 2:
            return []
        
        trades = []
        position = 0
        
        for i in range(1, len(data):
            price_change = (data['Close'].iloc[i] - data['Close'].iloc[i-1]) / data['Close'].iloc[i-1]
            
            if price_change > 0.01 and position <= 0:  # Buy signal
                trades.append({)
                    'date': data.index[i],
                    'action': 'BUY',
                    'price': data['Close'].iloc[i],
                    'reason': f'Momentum up {price_change:.2%}'
                })
                position = 100
            elif price_change < -0.01 and position > 0:  # Sell signal
                trades.append({)
                    'date': data.index[i],
                    'action': 'SELL',
                    'price': data['Close'].iloc[i],
                    'reason': f'Momentum down {price_change:.2%}'
                })
                position = 0
        
        return trades
    
    def run_mean_reversion_strategy(self, data):
        """Simple mean reversion strategy"""
        if len(data) < 3:
            return []
        
        trades = []
        position = 0
        mean_price = data['Close'].mean()
        
        for i in range(len(data):
            current_price = data['Close'].iloc[i]
            deviation = (current_price - mean_price) / mean_price
            
            if deviation < -0.02 and position <= 0:  # Buy when oversold
                trades.append({)
                    'date': data.index[i],
                    'action': 'BUY',
                    'price': current_price,
                    'reason': f'Oversold {deviation:.2%} below mean'
                })
                position = 100
            elif deviation > 0.02 and position > 0:  # Sell when overbought
                trades.append({)
                    'date': data.index[i],
                    'action': 'SELL',
                    'price': current_price,
                    'reason': f'Overbought {deviation:.2%} above mean'
                })
                position = 0
        
        return trades
    
    def calculate_performance(self, trades, initial_price, final_price):
        """Calculate strategy performance"""
        if not trades:
            return {}
                'num_trades': 0,
                'total_return': 0,
                'win_rate': 0,
                'buy_hold_return': (final_price - initial_price) / initial_price
            }
        
        # Calculate returns
        total_return = 0
        wins = 0
        
        for i in range(0, len(trades) - 1, 2):
            if i + 1 < len(trades):
                buy_price = trades[i]['price']
                sell_price = trades[i + 1]['price']
                trade_return = (sell_price - buy_price) / buy_price
                total_return += trade_return
                if trade_return > 0:
                    wins += 1
        
        num_complete_trades = len(trades) // 2
        win_rate = wins / num_complete_trades if num_complete_trades > 0 else 0
        buy_hold_return = (final_price - initial_price) / initial_price
        
        return {}
            'num_trades': len(trades),
            'total_return': total_return,
            'win_rate': win_rate,
            'buy_hold_return': buy_hold_return
        }

def main():
    print("🚀 Historical Data Trading Demo")
    print("=" * 60)
    
    demo = HistoricalTradingDemo()
    
    # Check market status
    is_open, reason = demo.is_market_open()
    print(f"\n📊 Market Status: {'OPEN' if is_open else 'CLOSED'}")
    print(f"📝 Reason: {reason}")
    
    # Determine mode
    if is_open:
        print("\n✅ Markets are open - would use LIVE data")
        print("📝 (Demo will use historical data for illustration)")
    else:
        print("\n🌙 Markets are closed - using HISTORICAL data")
    
    # Get random historical period
    start_date, end_date = demo.get_random_historical_period()
    print(f"\n📅 Selected Historical Period:")
    print(f"   Start: {start_date.strftime('%Y-%m-%d')} (Monday)")
    print(f"   End: {end_date.strftime('%Y-%m-%d')} (Friday)")
    
    # Test multiple symbols
    symbols = ['SPY', 'AAPL', 'MSFT', 'GOOGL', 'TSLA']
    print(f"\n📈 Testing Algorithms on: {', '.join(symbols)}")
    
    all_results = []
    
    for symbol in symbols:
        print(f"\n{'='*40}")
        print(f"Testing {symbol}")
        print('='*40)
        
        # Download data
        data = demo.download_historical_data(symbol, start_date, end_date)
        print(f"  Data points: {len(data)}")
        print(f"  Price range: ${data['Close'].min():.2f} - ${data['Close'].max():.2f}")
        
        # Run strategies
        print("\n  Running Momentum Strategy...")
        momentum_trades = demo.run_momentum_strategy(data)
        for trade in momentum_trades:
            print(f"    {trade['date'].strftime('%Y-%m-%d')}: {trade['action']} at ${trade['price']:.2f} - {trade['reason']}")
        
        print("\n  Running Mean Reversion Strategy...")
        mean_rev_trades = demo.run_mean_reversion_strategy(data)
        for trade in mean_rev_trades:
            print(f"    {trade['date'].strftime('%Y-%m-%d')}: {trade['action']} at ${trade['price']:.2f} - {trade['reason']}")
        
        # Calculate performance
        initial_price = data['Close'].iloc[0]
        final_price = data['Close'].iloc[-1]
        
        momentum_perf = demo.calculate_performance(momentum_trades, initial_price, final_price)
        mean_rev_perf = demo.calculate_performance(mean_rev_trades, initial_price, final_price)
        
        print(f"\n  📊 Performance Summary:")
        print(f"    Momentum Strategy:")
        print(f"      Trades: {momentum_perf['num_trades']}")
        print(f"      Return: {momentum_perf['total_return']:.2%}")
        print(f"      Win Rate: {momentum_perf['win_rate']:.1%}")
        
        print(f"    Mean Reversion Strategy:")
        print(f"      Trades: {mean_rev_perf['num_trades']}")
        print(f"      Return: {mean_rev_perf['total_return']:.2%}")
        print(f"      Win Rate: {mean_rev_perf['win_rate']:.1%}")
        
        print(f"    Buy & Hold Return: {momentum_perf['buy_hold_return']:.2%}")
        
        # Store results
        all_results.append({)
            'symbol': symbol,
            'period': f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
            'momentum': momentum_perf,
            'mean_reversion': mean_rev_perf
        })
    
    # Summary
    print(f"\n{'='*60}")
    print("📊 OVERALL SUMMARY")
    print('='*60)
    
    total_momentum_return = sum(r['momentum']['total_return'] for r in all_results) / len(all_results)
    total_mean_rev_return = sum(r['mean_reversion']['total_return'] for r in all_results) / len(all_results)
    total_buy_hold_return = sum(r['momentum']['buy_hold_return'] for r in all_results) / len(all_results)
    
    print(f"Average Returns (5-day period):")
    print(f"  Momentum Strategy: {total_momentum_return:.2%}")
    print(f"  Mean Reversion: {total_mean_rev_return:.2%}")
    print(f"  Buy & Hold: {total_buy_hold_return:.2%}")
    
    best_performer = max(all_results, key=lambda x: x['momentum']['total_return'])
    print(f"\nBest Performer: {best_performer['symbol']} with {best_performer['momentum']['total_return']:.2%} return")
    
    # Save results
    results_file = f"historical_test_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(results_file, 'w') as f:
        json.dump({)
            'test_time': datetime.now().isoformat(),
            'market_status': {'is_open': is_open, 'reason': reason},
            'period': {'start': start_date.isoformat(), 'end': end_date.isoformat()},
            'results': all_results
        }, f, indent=2, default=str)
    
    print(f"\n💾 Results saved to: {results_file}")
    
    print("\n✅ Demo Complete!")
    print("\n💡 Key Insights:")
    print("• When markets are closed, the system automatically uses historical data")
    print("• Random 5-day periods from 2022-2023 provide diverse market conditions")
    print("• Algorithms continue learning and testing 24/7")
    print("• Performance metrics help validate strategies before live trading")

if __name__ == "__main__":
    main()