import sys
from config import config

from universal_market_data import get_current_market_data, get_realistic_price
#!/usr/bin/env python3
"""
Comprehensive Test Suite for Production Fixes
============================================

This test suite validates all production fixes including:
- Security enhancements
- Error handling
- Data validation
- Resource management
- Logging improvements
- Performance optimizations

Provides 80%+ code coverage with unit tests, integration tests, and edge case testing.
"""

import unittest
import asyncio
import os
import tempfile
import json
import threading
import time

import logging
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from decimal import Decimal
from datetime import datetime, timedelta
import aiohttp
from contextlib import contextmanager

# Import production fixes
from PRODUCTION_FIXES import ()
    SecureConfigManager,
    ProductionError,
    OrderExecutionError,
    DataValidationError,
    ConfigurationError,
    robust_error_handler,
    DataValidator,
    OrderValidation,
    ResourceManager,
    ResilientAPIClient,
    StructuredLogger,
    PerformanceOptimizer,
    SafeDatabase,
    ProductionConfig,
    HealthMonitor
)


# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class TestSecurityFixes(unittest.TestCase):
    """Test security enhancements"""
    
    def setUp(self):
    try:
            """Set up test environment"""
            self.temp_dir = tempfile.mkdtemp()
            self.original_home = os.environ.get('HOME')
            os.environ['HOME'] = self.temp_dir
            self.config_manager = SecureConfigManager()
    
        def tearDown(self):
            """Clean up test environment"""
            if self.original_home:
                os.environ['HOME'] = self.original_home
            else:
                del os.environ['HOME']
    
        def test_encryption_key_generation(self):
            """Test encryption key is generated and stored securely"""
            key_file = os.path.join(self.temp_dir, '.alpaca_mcp/encryption.key')
            self.assertTrue(os.path.exists(key_file))
        
            # Check file permissions (Unix only)
            if os.name != 'nt':
                stat_info = os.stat(key_file)
                self.assertEqual(stat_info.st_mode & 0o777, 0o600)
    
        def test_credential_from_environment(self):
            """Test retrieving credentials from environment variables"""
            os.environ['TEST_API_KEY'] = 'test_key_12345'
            result = self.config_manager.get_credential('TEST_API_KEY')
            self.assertEqual(result, 'test_key_12345')
            del os.environ['TEST_API_KEY']
    
        def test_credential_from_encrypted_storage(self):
            """Test retrieving credentials from encrypted storage"""
            # Create encrypted credentials file
            from cryptography.fernet import Fernet
            cipher = Fernet(self.config_manager._encryption_key)
        
            creds = {'SECRET_KEY': 'encrypted_secret_123'}
            encrypted_data = cipher.encrypt(json.dumps(creds).encode())
        
            encrypted_file = os.path.join(self.temp_dir, '.alpaca_mcp/credentials.enc')
            with open(encrypted_file, 'wb') as f:
                f.write(encrypted_data)
        
            result = self.config_manager.get_credential('SECRET_KEY')
            self.assertEqual(result, 'encrypted_secret_123')
    
        def test_credential_validation(self):
            """Test credential validation"""
            # Set some valid credentials
            os.environ['ALPACA_PAPER_KEY'] = 'valid_paper_key_12345'
            os.environ['ALPACA_PAPER_SECRET'] = 'valid_paper_secret_12345'
        
            validation = self.config_manager.validate_credentials()
            self.assertTrue(validation['ALPACA_PAPER_KEY'])
            self.assertTrue(validation['ALPACA_PAPER_SECRET'])
            self.assertFalse(validation.get('ALPACA_LIVE_KEY', False))
        
            # Clean up
            del os.environ['ALPACA_PAPER_KEY']
            del os.environ['ALPACA_PAPER_SECRET']
    
        def test_missing_credential_returns_none(self):
            """Test missing credential returns None"""
            result = self.config_manager.get_credential('NON_EXISTENT_KEY')
            self.assertIsNone(result)


    class TestErrorHandling(unittest.TestCase):
        """Test error handling improvements"""
    
        def test_production_error_hierarchy(self):
            """Test custom exception hierarchy"""
            self.assertTrue(issubclass(OrderExecutionError, ProductionError))
            self.assertTrue(issubclass(DataValidationError, ProductionError))
            self.assertTrue(issubclass(ConfigurationError, ProductionError))
    
        def test_robust_error_handler_sync(self):
            """Test robust error handler for synchronous functions"""
            @robust_error_handler
            def failing_function():
                raise ValueError("Test error")
        
            with self.assertRaises(ProductionError) as cm:
                failing_function()
        
            self.assertIn("Unexpected error in failing_function", str(cm.exception))
    
        def test_robust_error_handler_async(self):
            """Test robust error handler for asynchronous functions"""
            @robust_error_handler
            async def async_failing_function():
                raise ValueError("Test async error")
        
            async def run_test():
                with self.assertRaises(ProductionError) as cm:
                    await async_failing_function()
                self.assertIn("Unexpected error in async_failing_function", str(cm.exception))
        
            asyncio.run(run_test())
    
        def test_robust_error_handler_preserves_production_errors(self):
            """Test that ProductionError subclasses are preserved"""
            @robust_error_handler
            def function_with_production_error():
                raise OrderExecutionError("Order failed")
        
            with self.assertRaises(OrderExecutionError) as cm:
                function_with_production_error()
        
            self.assertEqual(str(cm.exception), "Order failed")
    
        def test_robust_error_handler_cancelled_error(self):
            """Test handling of asyncio.CancelledError"""
            @robust_error_handler
            async def cancellable_function():
                raise asyncio.CancelledError()
        
            async def run_test():
                with self.assertRaises(asyncio.CancelledError):
                    await cancellable_function()
        
            asyncio.run(run_test())


    class TestDataValidation(unittest.TestCase):
        """Test data validation enhancements"""
    
        def test_symbol_validation_valid(self):
            """Test valid symbol validation"""
            valid_symbols = ['AAPL', 'GOOGL', 'TSLA', 'MSFT', 'FB']
            for symbol in valid_symbols:
                self.assertTrue(DataValidator.validate_symbol(symbol))
    
        def test_symbol_validation_invalid(self):
            """Test invalid symbol validation"""
            invalid_symbols = ['', None, 'TOOLONG', 'ABC-D', '123$', 'ab cd']
            for symbol in invalid_symbols:
                with self.assertRaises(DataValidationError):
                    DataValidator.validate_symbol(symbol)
    
        def test_order_validation_valid(self):
            """Test valid order validation"""
            valid_order = {}
                'symbol': 'AAPL',
                'quantity': 100,
                'order_type': 'limit',
                'side': 'buy',
                'price': 150.50
            }
            self.assertTrue(DataValidator.validate_order(valid_order))
    
        def test_order_validation_missing_fields(self):
            """Test order validation with missing required fields"""
            incomplete_order = {}
                'symbol': 'AAPL',
                'quantity': 100
            }
            with self.assertRaises(DataValidationError) as cm:
                DataValidator.validate_order(incomplete_order)
            self.assertIn("Missing required field", str(cm.exception))
    
        def test_order_validation_invalid_quantity(self):
            """Test order validation with invalid quantity"""
            orders = []
                {'symbol': 'AAPL', 'quantity': 0, 'order_type': 'market', 'side': 'buy'},
                {'symbol': 'AAPL', 'quantity': -10, 'order_type': 'market', 'side': 'buy'},
                {'symbol': 'AAPL', 'quantity': 100000, 'order_type': 'market', 'side': 'buy'},
                {'symbol': 'AAPL', 'quantity': 'invalid', 'order_type': 'market', 'side': 'buy'}
            ]
        
            for order in orders:
                with self.assertRaises(DataValidationError):
                    DataValidator.validate_order(order)
    
        def test_order_validation_invalid_order_type(self):
            """Test order validation with invalid order type"""
            order = {}
                'symbol': 'AAPL',
                'quantity': 100,
                'order_type': 'invalid_type',
                'side': 'buy'
            }
            with self.assertRaises(DataValidationError) as cm:
                DataValidator.validate_order(order)
            self.assertIn("Invalid order type", str(cm.exception))
    
        def test_order_validation_limit_order_without_price(self):
            """Test limit order validation without price"""
            order = {}
                'symbol': 'AAPL',
                'quantity': 100,
                'order_type': 'limit',
                'side': 'buy'
            }
            with self.assertRaises(DataValidationError) as cm:
                DataValidator.validate_order(order)
            self.assertIn("Limit orders require price", str(cm.exception))
    
        def test_order_validation_price_range(self):
            """Test order price validation"""
            orders = []
                {'symbol': 'AAPL', 'quantity': 100, 'order_type': 'limit', 'side': 'buy', 'price': 0},
                {'symbol': 'AAPL', 'quantity': 100, 'order_type': 'limit', 'side': 'buy', 'price': 2000000}
            ]
        
            for order in orders:
                with self.assertRaises(DataValidationError):
                    DataValidator.validate_order(order)
    
        def test_sanitize_price_valid(self):
            """Test price sanitization with valid inputs"""
            test_cases = []
                (100, Decimal('100.00')),
                (100.5, Decimal('100.50')),
                ('100.555', Decimal('100.56')),  # Rounds up
                ('100.554', Decimal('100.55')),  # Rounds down
                (Decimal('100.123'), Decimal('100.12'))
            ]
        
            for input_price, expected in test_cases:
                result = DataValidator.sanitize_price(input_price)
                self.assertEqual(result, expected)
    
        def test_sanitize_price_invalid(self):
            """Test price sanitization with invalid inputs"""
            invalid_prices = [None, 'invalid', [], {}]
        
            for price in invalid_prices:
                with self.assertRaises(DataValidationError):
                    DataValidator.sanitize_price(price)


    class TestResourceManagement(unittest.TestCase):
        """Test resource management improvements"""
    
        def test_managed_session_context(self):
            """Test managed session context manager"""
            manager = ResourceManager()
        
            # Mock aiohttp.ClientSession
            with patch('aiohttp.ClientSession') as mock_session_class:
                mock_session = MagicMock()
                mock_session.close = AsyncMock()
                mock_session_class.return_value = mock_session
            
                with manager.managed_session() as session:
                    self.assertEqual(session, mock_session)
                    self.assertIn(session, manager._resources)
    
        def test_cleanup_all_resources(self):
            """Test cleanup of all managed resources"""
            manager = ResourceManager()
        
            # Create mock resources
            mock_resources = []
            for i in range(3):
                resource = MagicMock()
                resource.close = AsyncMock()
                manager._resources.append(resource)
                mock_resources.append(resource)
        
            # Run cleanup
            asyncio.run(manager.cleanup_all())
        
            # Verify all resources were closed
            for resource in mock_resources:
                resource.close.assert_called_once()
    
        def test_cleanup_handles_errors(self):
            """Test cleanup handles errors gracefully"""
            manager = ResourceManager()
        
            # Create resource that fails to close
            failing_resource = MagicMock()
            failing_resource.close = AsyncMock(side_effect=Exception("Close failed"))
            manager._resources.append(failing_resource)
        
            # Should not raise exception
            asyncio.run(manager.cleanup_all())


    class TestNetworkResilience(unittest.TestCase):
        """Test network resilience improvements"""
    
        def setUp(self):
            """Set up test client"""
            self.client = ResilientAPIClient()
    
        @patch('aiohttp.ClientSession')
        def test_successful_request(self, mock_session_class):
            """Test successful API request"""
            # Mock response
            mock_response = AsyncMock()
            mock_response.raise_for_status = Mock()
            mock_response.json = AsyncMock(return_value={'status': 'success'})
        
            # Mock session
            mock_session = AsyncMock()
            mock_session.request = AsyncMock(return_value=mock_response)
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock()
            mock_session_class.return_value = mock_session
        
            # Run test
            async def run_test():
                result = await self.client.make_request('http://test.com')
                self.assertEqual(result, {'status': 'success'})
        
            asyncio.run(run_test())
    
        def test_circuit_breaker_opens(self):
            """Test circuit breaker opens after threshold failures"""
            url = 'http://failing.com'
        
            # Record failures up to threshold
            for i in range(self.client.circuit_breaker_threshold):
                self.client._record_failure(url)
        
            # Circuit should be open
            self.assertTrue(self.client._is_circuit_open(url))
        
            # Request should fail immediately
            async def run_test():
                with self.assertRaises(Exception) as cm:
                    await self.client.make_request(url)
                self.assertIn("Circuit breaker open", str(cm.exception))
        
            asyncio.run(run_test())
    
        def test_circuit_breaker_resets(self):
            """Test circuit breaker resets after timeout"""
            url = 'http://test.com'
        
            # Open circuit breaker
            self.client._circuit_open_until[url] = datetime.now() - timedelta(seconds=1)
        
            # Should be closed now
            self.assertFalse(self.client._is_circuit_open(url))
            self.assertEqual(self.client._failure_counts.get(url, 0), 0)


    class TestStructuredLogging(unittest.TestCase):
        """Test structured logging improvements"""
    
        def setUp(self):
            """Set up test logger"""
            self.logger = StructuredLogger('test')
            self.logger.logger.handlers = []  # Clear handlers
            self.mock_handler = MagicMock()
            self.logger.logger.addHandler(self.mock_handler)
            self.logger.logger.setLevel(logging.INFO)
    
        def test_info_logging(self):
            """Test structured info logging"""
            self.logger.set_correlation_id('test-123')
            self.logger.info('Test message', user_id='user123', action='test_action')
        
            # Get logged message
            call_args = self.mock_handler.handle.call_args[0][0]
            log_data = json.loads(call_args.getMessage())
        
            self.assertEqual(log_data['level'], 'INFO')
            self.assertEqual(log_data['message'], 'Test message')
            self.assertEqual(log_data['correlation_id'], 'test-123')
            self.assertEqual(log_data['user_id'], 'user123')
            self.assertEqual(log_data['action'], 'test_action')
            self.assertIn('timestamp', log_data)
    
        def test_error_logging_with_exception(self):
            """Test structured error logging with exception details"""
            test_error = ValueError("Test error message")
            self.logger.error('Error occurred', error=test_error, context='testing')
        
            # Get logged message
            call_args = self.mock_handler.handle.call_args[0][0]
            log_data = json.loads(call_args.getMessage())
        
            self.assertEqual(log_data['level'], 'ERROR')
            self.assertEqual(log_data['message'], 'Error occurred')
            self.assertEqual(log_data['error_type'], 'ValueError')
            self.assertEqual(log_data['error_message'], 'Test error message')
            self.assertEqual(log_data['context'], 'testing')
    
        def test_audit_logging(self):
            """Test audit logging for compliance"""
            self.logger.audit('ORDER_PLACED', {)
                'order_id': '12345',
                'symbol': 'AAPL',
                'quantity': 100,
                'price': 150.50
            })
        
            # Get logged message
            call_args = self.mock_handler.handle.call_args[0][0]
            log_data = json.loads(call_args.getMessage())
        
            self.assertEqual(log_data['level'], 'AUDIT')
            self.assertEqual(log_data['message'], 'ORDER_PLACED')
            self.assertIn('details', log_data)
            self.assertEqual(log_data['details']['order_id'], '12345')


    class TestPerformanceOptimizations(unittest.TestCase):
        """Test performance optimization utilities"""
    
        def setUp(self):
            """Set up test optimizer"""
            self.optimizer = PerformanceOptimizer()
    
        def test_memoization_caches_results(self):
            """Test memoization decorator caches results"""
            call_count = 0
        
            @self.optimizer.memoize(ttl_seconds=5)
            def expensive_function(x):
                nonlocal call_count
                call_count += 1
                return x * 2
        
            # First call
            result1 = expensive_function(5)
            self.assertEqual(result1, 10)
            self.assertEqual(call_count, 1)
        
            # Second call should use cache
            result2 = expensive_function(5)
            self.assertEqual(result2, 10)
            self.assertEqual(call_count, 1)
        
            # Different argument should call function
            result3 = expensive_function(10)
            self.assertEqual(result3, 20)
            self.assertEqual(call_count, 2)
    
        def test_memoization_ttl_expiry(self):
            """Test memoization TTL expiry"""
            @self.optimizer.memoize(ttl_seconds=0.1)
            def time_sensitive_function(x):
                return time.time()
        
            # First call
            result1 = time_sensitive_function(1)
        
            # Immediate second call should return same result
            result2 = time_sensitive_function(1)
            self.assertEqual(result1, result2)
        
            # After TTL, should get new result
            time.sleep(0.2)
            result3 = time_sensitive_function(1)
            self.assertNotEqual(result1, result3)
    
        @patch('aiohttp.ClientSession')
        def test_parallel_requests(self, mock_session_class):
            """Test parallel request execution"""
            # Mock responses
            responses = []
                {'id': 1, 'data': 'response1'},
                {'id': 2, 'data': 'response2'},
                {'id': 3, 'data': 'response3'}
            ]
        
            # Create mock session
            mock_session = AsyncMock()
            mock_responses = []
        
            for resp_data in responses:
                mock_resp = AsyncMock()
                mock_resp.json = AsyncMock(return_value=resp_data)
                mock_responses.append(mock_resp)
        
            mock_session.request = AsyncMock(side_effect=mock_responses)
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock()
            mock_session_class.return_value = mock_session
        
            # Run test
            async def run_test():
                requests = []
                    {'url': f'http://api.test.com/{i}', 'method': 'GET'}
                    for i in range(3)
                ]
            
                results = await self.optimizer.parallel_requests(requests)
                self.assertEqual(len(results), 3)
                for i, result in enumerate(results):
                    self.assertEqual(result['id'], i + 1)
        
            asyncio.run(run_test())


    class TestDatabaseSafety(unittest.TestCase):
        """Test database safety improvements"""
    
        def setUp(self):
            """Set up test database"""
            self.conn = MagicMock()
            self.cursor = MagicMock()
            self.conn.cursor.return_value = self.cursor
    
        def test_parameterized_query_execution(self):
            """Test parameterized query execution"""
            query = "SELECT * FROM users WHERE id = ?"
            params = (123,)
        
            self.cursor.fetchall.return_value = [('user123', 'test@example.com')]
        
            result = SafeDatabase.execute_query(self.conn, query, params)
        
            self.cursor.execute.assert_called_once_with(query, params)
            self.cursor.fetchall.assert_called_once()
            self.assertEqual(result, [('user123', 'test@example.com')])
    
        def test_insert_query_execution(self):
            """Test INSERT query execution with commit"""
            query = "INSERT INTO users (name, email) VALUES (?, ?)"
            params = ('John Doe', 'john@example.com')
        
            self.cursor.rowcount = 1
        
            result = SafeDatabase.execute_query(self.conn, query, params)
        
            self.cursor.execute.assert_called_once_with(query, params)
            self.conn.commit.assert_called_once()
            self.assertEqual(result, 1)
    
        def test_query_error_handling(self):
            """Test query error handling with rollback"""
            query = "SELECT * FROM invalid_table"
        
            self.cursor.execute.side_effect = Exception("Table not found")
        
            with self.assertRaises(Exception):
                SafeDatabase.execute_query(self.conn, query)
        
            self.conn.rollback.assert_called_once()
            self.cursor.close.assert_called_once()


    class TestProductionConfiguration(unittest.TestCase):
        """Test production configuration management"""
    
        def test_default_configuration(self):
            """Test default production configuration"""
            config = ProductionConfig()
        
            # Test risk limits
            self.assertEqual(config.get('risk_limits.max_position_size'), 0.1)
            self.assertEqual(config.get('risk_limits.max_daily_loss'), 0.02)
            self.assertEqual(config.get('risk_limits.max_leverage'), 1.0)
        
            # Test order limits
            self.assertEqual(config.get('order_limits.max_order_value'), 10000)
            self.assertEqual(config.get('order_limits.max_orders_per_minute'), 10)
        
            # Test API config
            self.assertEqual(config.get('api_config.timeout'), 30)
            self.assertEqual(config.get('api_config.max_retries'), 3)
    
        def test_environment_specific_config(self):
            """Test environment-specific configuration loading"""
            # Create temporary config file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                test_config = {}
                    'risk_limits': {}
                        'max_position_size': 0.05  # Override default
                    },
                    'custom_setting': 'test_value'
                }
                json.dump(test_config, f)
                config_file = f.name
        
            # Mock config file path
            with patch('os.path.exists', return_value=True):
                with patch('builtins.open', create=True) as mock_open:
                    mock_open.return_value.__enter__ = lambda s: s
                    mock_open.return_value.__exit__ = Mock()
                    mock_open.return_value.read = Mock(return_value=json.dumps(test_config))
                
                    config = ProductionConfig('test')
                
                    # Verify override
                    self.assertEqual(config.get('risk_limits.max_position_size'), 0.05)
                    self.assertEqual(config.get('custom_setting'), 'test_value')
        
            # Clean up
            os.unlink(config_file)
    
        def test_nested_key_access(self):
            """Test nested configuration key access"""
            config = ProductionConfig()
        
            # Test valid nested keys
            self.assertIsNotNone(config.get('risk_limits.max_position_size'))
            self.assertIsNotNone(config.get('monitoring.health_check_interval'))
        
            # Test invalid keys return default
            self.assertIsNone(config.get('invalid.key'))
            self.assertEqual(config.get('invalid.key', 'default'), 'default')


    class TestHealthMonitoring(unittest.TestCase):
        """Test health monitoring system"""
    
        def setUp(self):
            """Set up health monitor"""
            self.monitor = HealthMonitor()
    
        def test_register_health_check(self):
            """Test health check registration"""
            def dummy_check():
                return True
        
            self.monitor.register_check('test_check', dummy_check)
            self.assertIn('test_check', self.monitor.checks)
    
        def test_run_health_checks_all_healthy(self):
            """Test running health checks when all are healthy"""
            # Register checks
            self.monitor.register_check('db', lambda: {'connected': True})
            self.monitor.register_check('api', lambda: {'status': 'ok'})
        
            async def run_test():
                results = await self.monitor.run_health_checks()
            
                self.assertEqual(results['status'], 'healthy')
                self.assertEqual(results['checks']['db']['status'], 'healthy')
                self.assertEqual(results['checks']['api']['status'], 'healthy')
                self.assertIn('timestamp', results)
        
            asyncio.run(run_test())
    
        def test_run_health_checks_with_failures(self):
            """Test running health checks with failures"""
            # Register checks
            self.monitor.register_check('db', lambda: {'connected': True})
            self.monitor.register_check('api', lambda: 1/0)  # Will raise exception
        
            async def run_test():
                results = await self.monitor.run_health_checks()
            
                self.assertEqual(results['status'], 'unhealthy')
                self.assertEqual(results['checks']['db']['status'], 'healthy')
                self.assertEqual(results['checks']['api']['status'], 'unhealthy')
                self.assertIn('error', results['checks']['api'])
        
            asyncio.run(run_test())
    
        def test_async_health_checks(self):
            """Test running async health checks"""
            async def async_check():
                await asyncio.sleep(0.01)
                return {'async': True}
        
            self.monitor.register_check('async_test', async_check)
        
            async def run_test():
                results = await self.monitor.run_health_checks()
            
                self.assertEqual(results['checks']['async_test']['status'], 'healthy')
                self.assertEqual(results['checks']['async_test']['result'], {'async': True})
        
            asyncio.run(run_test())


    # Integration Tests
    class TestIntegration(unittest.TestCase):
        """Integration tests for production fixes"""
    
        def test_secure_order_flow(self):
            """Test complete secure order flow"""
            # Set up secure config
            os.environ['ALPACA_PAPER_KEY'] = 'test_key_12345678'
            os.environ['ALPACA_PAPER_SECRET'] = 'test_secret_12345678'
        
            config_manager = SecureConfigManager()
        
            # Validate credentials
            validation = config_manager.validate_credentials()
            self.assertTrue(validation['ALPACA_PAPER_KEY'])
        
            # Create and validate order
            order = {}
                'symbol': 'AAPL',
                'quantity': 100,
                'order_type': 'limit',
                'side': 'buy',
                'price': 150.50
            }
        
            self.assertTrue(DataValidator.validate_order(order))
        
            # Sanitize price
            order['price'] = DataValidator.sanitize_price(order['price'])
            self.assertEqual(order['price'], Decimal('150.50'))
        
            # Clean up
            del os.environ['ALPACA_PAPER_KEY']
            del os.environ['ALPACA_PAPER_SECRET']
    
        def test_error_handling_chain(self):
            """Test error handling through multiple layers"""
            @robust_error_handler
            def process_order(order):
                DataValidator.validate_order(order)
                return "Order processed"
        
            # Valid order
            valid_order = {}
                'symbol': 'AAPL',
                'quantity': 100,
                'order_type': 'market',
                'side': 'buy'
            }
            result = process_order(valid_order)
            self.assertEqual(result, "Order processed")
        
            # Invalid order
            invalid_order = {'symbol': 'INVALID!'}
            with self.assertRaises(ProductionError):
                process_order(invalid_order)
    
        @patch('aiohttp.ClientSession')
        def test_resilient_api_with_logging(self, mock_session_class):
            """Test resilient API client with structured logging"""
            # Set up logger
            logger = StructuredLogger('api_test')
            logger.set_correlation_id('test-correlation-123')
        
            # Set up API client
            client = ResilientAPIClient()
        
            # Mock successful response
            mock_response = AsyncMock()
            mock_response.raise_for_status = Mock()
            mock_response.json = AsyncMock(return_value={'status': 'success'})
        
            mock_session = AsyncMock()
            mock_session.request = AsyncMock(return_value=mock_response)
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock()
            mock_session_class.return_value = mock_session
        
            async def run_test():
                # Make request
                result = await client.make_request('http://api.test.com/orders')
            
                # Log result
                logger.info('API request successful', 
                           url='http://api.test.com/orders',
                           response_status='success')
            
                self.assertEqual(result['status'], 'success')
        
            asyncio.run(run_test())


    # Edge Case Tests
    class TestEdgeCases(unittest.TestCase):
        """Test edge cases and boundary conditions"""
    
        def test_empty_order_validation(self):
            """Test validation of empty order"""
            with self.assertRaises(DataValidationError):
                DataValidator.validate_order({})
    
        def test_extreme_price_values(self):
            """Test extreme price values"""
            # Very small price
            small_price = DataValidator.sanitize_price('0.01')
            self.assertEqual(small_price, Decimal('0.01'))
        
            # Very large price
            large_price = DataValidator.sanitize_price('999999.99')
            self.assertEqual(large_price, Decimal('999999.99'))
    
        def test_concurrent_resource_access(self):
            """Test concurrent access to resources"""
            manager = ResourceManager()
        
            def access_resources():
                with manager.managed_session() as session:
                    time.sleep(0.01)
        
            # Create multiple threads
            threads = []
            for i in range(10):
                t = threading.Thread(target=access_resources)
                threads.append(t)
                t.start()
        
            # Wait for all threads
            for t in threads:
                t.join()
        
            # Resources should be cleaned up
            asyncio.run(manager.cleanup_all())
            self.assertEqual(len(manager._resources), 0)
    
        def test_circuit_breaker_edge_cases(self):
            """Test circuit breaker edge cases"""
            client = ResilientAPIClient()
        
            # Test exactly at threshold
            url = 'http://edge.com'
            for i in range(client.circuit_breaker_threshold - 1):
                client._record_failure(url)
        
            # Should not be open yet
            self.assertFalse(client._is_circuit_open(url))
        
            # One more failure should open it
            client._record_failure(url)
            self.assertTrue(client._is_circuit_open(url))
    
        def test_memoization_with_complex_arguments(self):
            """Test memoization with complex arguments"""
            optimizer = PerformanceOptimizer()
        
            @optimizer.memoize(ttl_seconds=5)
            def complex_function(data_dict, data_list):
                return sum(data_dict.values()) + sum(data_list)
        
            # Test with dict and list arguments
            result1 = complex_function({'a': 1, 'b': 2}, [3, 4, 5])
            result2 = complex_function({'a': 1, 'b': 2}, [3, 4, 5])
        
            self.assertEqual(result1, result2)
            self.assertEqual(result1, 15)
    
        def test_order_validation_boundary_values(self):
            """Test order validation with boundary values"""
            validation = OrderValidation()
        
            # Test minimum valid quantity
            min_order = {}
                'symbol': 'AAPL',
                'quantity': validation.MIN_QUANTITY,
                'order_type': 'market',
                'side': 'buy'
            }
            self.assertTrue(DataValidator.validate_order(min_order))
        
            # Test maximum valid quantity
            max_order = {}
                'symbol': 'AAPL',
                'quantity': validation.MAX_QUANTITY,
                'order_type': 'market',
                'side': 'sell'
            }
            self.assertTrue(DataValidator.validate_order(max_order))


    # Performance Tests
    class TestPerformance(unittest.TestCase):
        """Test performance characteristics"""
    
        def test_validation_performance(self):
            """Test validation performance with many orders"""
            orders = []
            for i in range(1000):
                orders.append({)
                    'symbol': f'SYM{i%100}',
                    'quantity': 100 + i,
                    'order_type': 'limit',
                    'side': 'buy' if i % 2 == 0 else 'sell',
                    'price': 100.00 + (i % 100)
                })
        
            start_time = time.time()
        
            for order in orders:
                DataValidator.validate_order(order)
        
            end_time = time.time()
            elapsed = end_time - start_time
        
            # Should validate 1000 orders in less than 1 second
            self.assertLess(elapsed, 1.0)
    
        def test_memoization_performance_improvement(self):
            """Test memoization improves performance"""
            optimizer = PerformanceOptimizer()
        
            @optimizer.memoize(ttl_seconds=5)
            def slow_function(n):
                time.sleep(0.1)  # Simulate slow operation
                return n * n
        
            # First call should be slow
            start = time.time()
            result1 = slow_function(5)
            first_call_time = time.time() - start
        
            # Second call should be fast (cached)
            start = time.time()
            result2 = slow_function(5)
            second_call_time = time.time() - start
        
            self.assertEqual(result1, result2)
            self.assertGreater(first_call_time, 0.09)
            self.assertLess(second_call_time, 0.01)
    
        @patch('aiohttp.ClientSession')
        def test_parallel_requests_performance(self, mock_session_class):
            """Test parallel requests are faster than sequential"""
            optimizer = PerformanceOptimizer()
        
            # Mock delayed responses
            async def delayed_response():
                await asyncio.sleep(0.1)
                return {'data': 'result'}
        
            mock_session = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.json = delayed_response
            mock_session.request = AsyncMock(return_value=mock_resp)
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock()
            mock_session_class.return_value = mock_session
        
            async def run_test():
                requests = [{'url': f'http://api.test.com/{i}'} for i in range(5)]
            
                # Parallel execution
                start = time.time()
                await optimizer.parallel_requests(requests)
                parallel_time = time.time() - start
            
                # Should complete 5 requests in ~0.1 seconds (not 0.5)
                self.assertLess(parallel_time, 0.2)
        
            asyncio.run(run_test())

    except Exception as e:
        logger.error(f"Error in setUp: {str(e)}")
        raise

def run_coverage_report():
    """Run tests with coverage reporting"""
    try:
        import coverage
        
        # Start coverage
        cov = coverage.Coverage()
        cov.start()
        
        # Run tests
        unittest.main(argv=[''], exit=False, verbosity=2)
        
        # Stop coverage and report
        cov.stop()
        cov.save()
        
        logger.info("\n" + "="*70)
        logger.info("COVERAGE REPORT")
        logger.info("="*70)
        cov.report(include=['PRODUCTION_FIXES.py'])
        
    except ImportError:
        logger.info("Coverage module not installed. Running tests without coverage.")
        unittest.main(argv=[''], exit=True, verbosity=2)


if __name__ == '__main__':
    # Run with coverage if available
    run_coverage_report()