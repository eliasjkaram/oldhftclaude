#!/usr/bin/env python3
"""
PRODUCTION MINIO ML TRADING SYSTEM
==================================
Full production system with MinIO integration, ML predictions, and real trading
"""

import os
import sys
import asyncio
import logging
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

# Core imports
import numpy as np
import pandas as pd
from io import BytesIO

# MinIO
try:
    from minio import Minio
    from minio.error import S3Error
    MINIO_AVAILABLE = True
except ImportError:
    MINIO_AVAILABLE = False
    print("Warning: MinIO not installed. Install with: pip install minio")

# ML/DL imports
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("Warning: PyTorch not installed. Install with: pip install torch")

try:
    from sklearn.preprocessing import StandardScaler, MinMaxScaler
    from sklearn.model_selection import train_test_split
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.metrics import mean_squared_error, mean_absolute_error
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("Warning: Scikit-learn not installed. Install with: pip install scikit-learn")

# Technical indicators
try:
    import ta
    TA_AVAILABLE = True
except ImportError:
    TA_AVAILABLE = False
    print("Warning: TA-Lib not installed. Install with: pip install ta")

# Alpaca
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame

# Fallback imports
try:
    from scipy.stats import norm
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False
    print("Warning: SciPy not installed. Install with: pip install scipy")
    # Simple normal CDF approximation
    def norm_cdf(x):
        return 0.5 * (1 + np.sign(x) * np.sqrt(1 - np.exp(-2 * x**2 / np.pi)))
    def norm_pdf(x):
        return np.exp(-x**2/2) / np.sqrt(2*np.pi)
    class norm:
        cdf = staticmethod(norm_cdf)
        pdf = staticmethod(norm_pdf)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

class ProductionMinIOMLTradingSystem:
    def __init__(self):
        # API credentials
        self.alpaca_api_key = 'PKEP9PIBDKOSUGHHY44Z'
        self.alpaca_secret_key = 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ'
        
        # Initialize Alpaca clients
        self.trading_client = TradingClient(self.alpaca_api_key, self.alpaca_secret_key, paper=True)
        self.data_client = StockHistoricalDataClient(self.alpaca_api_key, self.alpaca_secret_key)
        
        # MinIO setup
        self.minio_client = None
        if MINIO_AVAILABLE:
            try:
                self.minio_client = Minio()
                    "uschristmas.us:9000",
                    access_key="minioadmin",
                    secret_key="minioadmin",
                    secure=False
                )
                logger.info("✅ MinIO connected successfully")
            except Exception as e:
                logger.error(f"MinIO connection failed: {e}")
        
        # Trading universe
        self.symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 
                       'JPM', 'SPY', 'QQQ', 'IWM', 'AMD', 'NFLX', 'BA', 'DIS']
        
        # Model storage
        self.models = {}
        self.scalers = {}
        
        # Trading state
        self.active_positions = {}
        self.pending_orders = {}
        self.trade_history = []
        
        # Performance metrics
        self.total_trades = 0
        self.winning_trades = 0
        self.total_pnl = 0
        
        logger.info("🚀 Production MinIO ML Trading System Initialized")
        self._check_dependencies()
        
    def _check_dependencies(self):
        """Check and report on available dependencies"""
        deps = {}
            'MinIO': MINIO_AVAILABLE,
            'PyTorch': TORCH_AVAILABLE,
            'Scikit-learn': SKLEARN_AVAILABLE,
            'Technical Analysis': TA_AVAILABLE,
            'SciPy': SCIPY_AVAILABLE
        }
        
        logger.info("📦 Dependency Status:")
        for dep, available in deps.items():
            status = "✅" if available else "❌"
            logger.info(f"  {status} {dep}")
    
    def get_historical_data(self, symbol: str, days: int = 365) -> pd.DataFrame:
        """Get historical data from MinIO or Alpaca"""
        try:
            # Try MinIO first
            if self.minio_client:
                df = self._get_data_from_minio(symbol, days)
                if not df.empty:
                    return df
            
            # Fallback to Alpaca
            return self._get_data_from_alpaca(symbol, days)
            
        except Exception as e:
            logger.error(f"Error getting historical data: {e}")
            return pd.DataFrame()
    
    def _get_data_from_minio(self, symbol: str, days: int) -> pd.DataFrame:
        """Fetch data from MinIO buckets"""
        if not self.minio_client:
            return pd.DataFrame()
            
        try:
            # List available buckets
            buckets = [b.name for b in self.minio_client.list_buckets()]
            logger.info(f"Available MinIO buckets: {buckets}")
            
            # Try different bucket/object patterns
            for bucket in ['stockdb', 'stock-data', 'options-data', 'market-data']:
                if bucket not in buckets:
                    continue
                    
                try:
                    # List objects in bucket
                    objects = self.minio_client.list_objects(bucket, prefix=symbol)
                    
                    for obj in objects:
                        if symbol in obj.object_name:
                            # Get object
                            response = self.minio_client.get_object(bucket, obj.object_name)
                            data = response.read()
                            response.close()
                            response.release_conn()
                            
                            # Parse based on file type
                            if obj.object_name.endswith('.parquet'):
                                df = pd.read_parquet(BytesIO(data))
                            elif obj.object_name.endswith('.csv'):
                                df = pd.read_csv(BytesIO(data))
                            else:
                                continue
                            
                            if not df.empty:
                                logger.info(f"✅ Found {symbol} data in MinIO: {bucket}/{obj.object_name}")
                                return df
                                
                except Exception as e:
                    continue
                    
        except Exception as e:
            logger.error(f"MinIO error: {e}")
            
        return pd.DataFrame()
    
    def _get_data_from_alpaca(self, symbol: str, days: int) -> pd.DataFrame:
        """Get data from Alpaca API"""
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            request = StockBarsRequest()
                symbol_or_symbols=symbol,
                timeframe=TimeFrame.Day,
                start=start_date,
                end=end_date
            )
            
            bars = self.data_client.get_stock_bars(request)
            df = bars.df.reset_index()
            
            if not df.empty:
                df.columns = ['timestamp', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'trade_count', 'vwap']
                df.set_index('timestamp', inplace=True)
                logger.info(f"✅ Retrieved {len(df)} days of data from Alpaca for {symbol}")
                
            return df
            
        except Exception as e:
            logger.error(f"Alpaca data error: {e}")
            return pd.DataFrame()
    
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Engineer features for ML models"""
        if df.empty:
            return df
            
        try:
            # Basic features
            df['returns'] = df['close'].pct_change()
            df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_open_ratio'] = df['close'] / df['open']
            
            # Volume features
            df['volume_sma'] = df['volume'].rolling(20).mean()
            df['volume_ratio'] = df['volume'] / df['volume_sma']
            
            if TA_AVAILABLE:
                # Technical indicators
                df['sma_5'] = ta.trend.sma_indicator(df['close'], window=5)
                df['sma_20'] = ta.trend.sma_indicator(df['close'], window=20)
                df['ema_12'] = ta.trend.ema_indicator(df['close'], window=12)
                
                # RSI
                df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
                
                # MACD
                macd = ta.trend.MACD(df['close'])
                df['macd'] = macd.macd()
                df['macd_signal'] = macd.macd_signal()
                
                # Bollinger Bands
                bb = ta.volatility.BollingerBands(df['close'], window=20)
                df['bb_upper'] = bb.bollinger_hband()
                df['bb_lower'] = bb.bollinger_lband()
                df['bb_width'] = df['bb_upper'] - df['bb_lower']
                
                # ATR
                df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close']).average_true_range()
            else:
                # Simple alternatives if TA not available
                df['sma_5'] = df['close'].rolling(5).mean()
                df['sma_20'] = df['close'].rolling(20).mean()
                df['rsi'] = 50  # Neutral RSI
                
            # Volatility
            df['volatility'] = df['returns'].rolling(20).std() * np.sqrt(252)
            
            # Forward fill and drop NaN
            df.fillna(method='ffill', inplace=True)
            df.dropna(inplace=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Feature engineering error: {e}")
            return df
    
    def build_simple_ml_model(self, X_train: np.ndarray, y_train: np.ndarray) -> Any:
        """Build a simple ML model that works without heavy dependencies"""
        try:
            if SKLEARN_AVAILABLE:
                # Use Random Forest if available
                model = RandomForestRegressor(n_estimators=50, max_depth=10, random_state=42)
                model.fit(X_train, y_train)
                return model
            else:
                # Simple linear regression fallback
                logger.info("Using simple linear regression (no sklearn)")
                # Calculate simple linear regression manually
                X_mean = np.mean(X_train, axis=0)
                y_mean = np.mean(y_train)
                
                # Simple model that predicts based on mean
                class SimpleModel:
                    def __init__(self, x_mean, y_mean):
                        self.x_mean = x_mean
                        self.y_mean = y_mean
                    
                    def predict(self, X):
                        # Simple prediction based on deviation from mean
                        return np.full(len(X), self.y_mean)
                
                return SimpleModel(X_mean, y_mean)
                
        except Exception as e:
            logger.error(f"Model building error: {e}")
            return None
    
    async def train_models(self, symbol: str):
        """Train ML models for price prediction"""
        logger.info(f"🔧 Training models for {symbol}...")
        
        # Get historical data
        df = self.get_historical_data(symbol, days=730)  # 2 years
        
        if df.empty or len(df) < 100:
            logger.error(f"Insufficient data for {symbol}")
            return False
        
        # Engineer features
        df = self.engineer_features(df)
        
        # Prepare data for ML
        feature_cols = ['returns', 'volume_ratio', 'rsi', 'volatility']
        available_features = [col for col in feature_cols if col in df.columns]
        
        if len(available_features) < 2:
            logger.error("Insufficient features available")
            return False
        
        # Create target (next day return)
        df['target'] = df['close'].shift(-1) / df['close'] - 1
        df.dropna(inplace=True)
        
        # Prepare training data
        X = df[available_features].values
        y = df['target'].values
        
        # Split data
        split_idx = int(0.8 * len(X))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Scale features
        if SKLEARN_AVAILABLE:
            scaler = MinMaxScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            self.scalers[symbol] = scaler
        else:
            # Simple normalization
            X_min = X_train.min(axis=0)
            X_max = X_train.max(axis=0)
            X_train_scaled = (X_train - X_min) / (X_max - X_min + 1e-8)
            X_test_scaled = (X_test - X_min) / (X_max - X_min + 1e-8)
        
        # Train model
        model = self.build_simple_ml_model(X_train_scaled, y_train)
        
        if model:
            self.models[symbol] = model
            
            # Evaluate
            predictions = model.predict(X_test_scaled)
            mae = np.mean(np.abs(predictions - y_test))
            
            logger.info(f"✅ Model trained for {symbol}")
            logger.info(f"   MAE: {mae:.4f}")
            logger.info(f"   Features used: {available_features}")
            
            return True
        
        return False
    
    def predict_price(self, symbol: str, days_ahead: int = 5) -> Dict[str, Any]:
        """Predict future prices"""
        try:
            # Get recent data
            df = self.get_historical_data(symbol, days=60)
            
            if df.empty:
                return {}
            
            # Engineer features
            df = self.engineer_features(df)
            
            # Get model
            if symbol not in self.models:
                logger.warning(f"No model available for {symbol}")
                return {}
            
            model = self.models[symbol]
            
            # Prepare features
            feature_cols = ['returns', 'volume_ratio', 'rsi', 'volatility']
            available_features = [col for col in feature_cols if col in df.columns]
            
            # Get latest features
            latest_features = df[available_features].iloc[-1:].values
            
            # Scale features
            if symbol in self.scalers:
                latest_features_scaled = self.scalers[symbol].transform(latest_features)
            else:
                latest_features_scaled = latest_features
            
            # Predict
            predicted_return = model.predict(latest_features_scaled)[0]
            current_price = df['close'].iloc[-1]
            predicted_price = current_price * (1 + predicted_return)
            
            # Simple multi-day forecast
            predictions = []
            price = current_price
            for i in range(days_ahead):
                price = price * (1 + predicted_return * (0.9 ** i))  # Decay factor
                predictions.append(price)
            
            return {}
                'symbol': symbol,
                'current_price': current_price,
                'predictions': predictions,
                'expected_return': predicted_return,
                'confidence': 0.7  # Fixed confidence for simple model
            }
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {}
    
    def calculate_option_price(self, S: float, K: float, T: float, r: float = 0.05, 
                             sigma: float = 0.3, option_type: str = 'call') -> Dict[str, float]:
        """Calculate option price using Black-Scholes"""
        try:
            # Black-Scholes formula
            d1 = (np.log(S/K) + (r + sigma**2/2)*T) / (sigma*np.sqrt(T))
            d2 = d1 - sigma*np.sqrt(T)
            
            if option_type == 'call':
                price = S*norm.cdf(d1) - K*np.exp(-r*T)*norm.cdf(d2)
                delta = norm.cdf(d1)
            else:
                price = K*np.exp(-r*T)*norm.cdf(-d2) - S*norm.cdf(-d1)
                delta = -norm.cdf(-d1)
            
            # Greeks
            gamma = norm.pdf(d1)/(S*sigma*np.sqrt(T))
            vega = S*norm.pdf(d1)*np.sqrt(T)/100
            theta = -(S*norm.pdf(d1)*sigma)/(2*np.sqrt(T))/365
            
            return {}
                'price': price,
                'delta': delta,
                'gamma': gamma,
                'vega': vega,
                'theta': theta,
                'iv': sigma
            }
            
        except Exception as e:
            logger.error(f"Option pricing error: {e}")
            return {'price': 0, 'delta': 0, 'gamma': 0, 'vega': 0, 'theta': 0, 'iv': 0}
    
    async def analyze_opportunities(self) -> List[Dict]:
        """Analyze market for trading opportunities"""
        opportunities = []
        
        # Get current market data
        try:
            request = StockLatestQuoteRequest(symbol_or_symbols=self.symbols)
            quotes = self.data_client.get_stock_latest_quote(request)
            
            for symbol, quote in quotes.items():
                current_price = float(quote.ask_price) if quote.ask_price else float(quote.bid_price)
                
                # Get prediction
                prediction = self.predict_price(symbol, days_ahead=5)
                
                if prediction and prediction['expected_return'] > 0.01:  # 1% threshold
                    # Stock opportunity
                    opportunities.append({)
                        'type': 'STOCK',
                        'symbol': symbol,
                        'action': 'BUY',
                        'current_price': current_price,
                        'predicted_price': prediction['predictions'][0],
                        'expected_return': prediction['expected_return'],
                        'confidence': prediction['confidence'],
                        'strategy': 'ml_momentum'
                    })
                    
                    # Option opportunity (call)
                    option = self.calculate_option_price()
                        S=current_price,
                        K=current_price * 1.02,  # 2% OTM
                        T=30/365,  # 30 days
                        sigma=0.25
                    )
                    
                    opportunities.append({)
                        'type': 'OPTION',
                        'symbol': symbol,
                        'action': 'BUY_CALL',
                        'strike': current_price * 1.02,
                        'expiry_days': 30,
                        'option_price': option['price'],
                        'delta': option['delta'],
                        'confidence': prediction['confidence'] * 0.8,
                        'strategy': 'ml_directional'
                    })
                    
                    # Spread opportunity (bull call spread)
                    if prediction['expected_return'] > 0.02:
                        opportunities.append({)
                            'type': 'SPREAD',
                            'symbol': symbol,
                            'strategy': 'bull_call_spread',
                            'long_strike': current_price,
                            'short_strike': current_price * 1.05,
                            'expiry_days': 30,
                            'confidence': prediction['confidence'] * 0.9
                        })
                        
        except Exception as e:
            logger.error(f"Error analyzing opportunities: {e}")
            
        return opportunities
    
    async def execute_trade(self, opportunity: Dict) -> bool:
        """Execute a trade based on opportunity"""
        try:
            symbol = opportunity['symbol']
            
            if opportunity['type'] == 'STOCK':
                # Calculate position size
                account = self.trading_client.get_account()
                buying_power = float(account.buying_power)
                position_size = min(buying_power * 0.05, 10000)  # 5% or $10k max
                
                quantity = int(position_size / opportunity['current_price'])
                
                if quantity > 0:
                    order_data = MarketOrderRequest()
                        symbol=symbol,
                        qty=quantity,
                        side=OrderSide.BUY,
                        time_in_force=TimeInForce.DAY
                    )
                    
                    order = self.trading_client.submit_order(order_data)
                    
                    logger.info(f"✅ STOCK ORDER: Buy {quantity} {symbol} @ market")
                    logger.info(f"   Expected return: {opportunity['expected_return']:.2%}")
                    logger.info(f"   Order ID: {order.id}")
                    
                    self.total_trades += 1
                    return True
                    
            elif opportunity['type'] == 'OPTION':
                # Log option trade (would execute if options API available)
                logger.info(f"📊 OPTION SIGNAL: Buy {symbol} Call")
                logger.info(f"   Strike: ${opportunity['strike']:.2f}")
                logger.info(f"   Premium: ${opportunity['option_price']:.2f}")
                logger.info(f"   Delta: {opportunity['delta']:.3f}")
                
            elif opportunity['type'] == 'SPREAD':
                # Log spread trade
                logger.info(f"🎯 SPREAD SIGNAL: {opportunity['strategy']} on {symbol}")
                logger.info(f"   Strikes: ${opportunity['long_strike']:.2f} / ${opportunity['short_strike']:.2f}")
                
            return True
            
        except Exception as e:
            logger.error(f"Trade execution error: {e}")
            return False
    
    async def run_trading_cycle(self):
        """Run one complete trading cycle"""
        logger.info("\n" + "="*60)
        logger.info("🔄 Starting Trading Cycle")
        
        # Update account info
        try:
            account = self.trading_client.get_account()
            logger.info(f"💰 Account Balance: ${float(account.portfolio_value):,.2f}")
            logger.info(f"💵 Buying Power: ${float(account.buying_power):,.2f}")
        except:
            pass
        
        # Analyze opportunities
        opportunities = await self.analyze_opportunities()
        logger.info(f"🔍 Found {len(opportunities)} opportunities")
        
        # Sort by confidence and expected return
        opportunities.sort(key=lambda x: x.get('confidence', 0) * x.get('expected_return', 0), reverse=True)
        
        # Execute top opportunities
        executed = 0
        for opp in opportunities[:5]:  # Top 5
            if await self.execute_trade(opp):
                executed += 1
                await asyncio.sleep(1)  # Rate limiting
        
        logger.info(f"✅ Executed {executed} trades")
        logger.info("="*60)
    
    async def run(self):
        """Main production loop"""
        logger.info("🚀 Starting Production MinIO ML Trading System")
        
        # Train models for all symbols
        logger.info("\n📚 Training ML models...")
        for symbol in self.symbols[:5]:  # Train on first 5 for speed
            await self.train_models(symbol)
            await asyncio.sleep(0.5)
        
        logger.info("\n🎯 Starting live trading...")
        
        while True:
            try:
                # Check market hours
                clock = self.trading_client.get_clock()
                if not clock.is_open:
                    logger.info("Market closed. Waiting...")
                    await asyncio.sleep(60)
                    continue
                
                # Run trading cycle
                await self.run_trading_cycle()
                
                # Wait before next cycle
                await asyncio.sleep(30)  # 30 seconds between cycles
                
            except KeyboardInterrupt:
                logger.info("\n👋 Shutting down...")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                await asyncio.sleep(60)

async def main():
    system = ProductionMinIOMLTradingSystem()
    await system.run()

if __name__ == "__main__":
    # Install dependencies message
    print("\n" + "="*60)
    print("PRODUCTION MINIO ML TRADING SYSTEM")
    print("="*60)
    print("\nRequired dependencies:")
    print("pip install minio pandas numpy scikit-learn scipy ta")
    print("\nOptional for better performance:")
    print("pip install torch tensorflow")
    print("="*60 + "\n")
    
    # Run system
    asyncio.run(main())