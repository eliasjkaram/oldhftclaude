#!/usr/bin/env python3
"""
MinIO Web Browser Interface Scraper
Scrapes the MinIO browser interface to discover available datasets
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from datetime import datetime
from urllib.parse import urljoin, urlparse
import time
from typing import Dict, List, Optional, Tuple
import logging

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MinIOWebScraper:
    def __init__(self, base_url: str = "https://uschristmas.us/browser/stockdb"):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({)
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.inventory = {}
            'buckets': [],
            'total_files': 0,
            'total_size': 0,
            'file_types': {},
            'datasets': []
        }
    
    def parse_file_size(self, size_str: str) -> int:
        """Convert human-readable file size to bytes"""
        units = {}
            'B': 1,
            'KB': 1024,
            'MB': 1024**2,
            'GB': 1024**3,
            'TB': 1024**4
        }
        
        size_str = size_str.strip().upper()
        for unit, multiplier in units.items():
            if unit in size_str:
                try:
                    number = float(size_str.replace(unit, '').strip())
                    return int(number * multiplier)
                except:
                    return 0
        return 0
    
    def parse_date(self, date_str: str) -> Optional[datetime]:
        """Parse various date formats from the interface"""
        date_formats = []
            '%Y-%m-%d %H:%M:%S',
            '%Y-%m-%d',
            '%m/%d/%Y %I:%M %p',
            '%d-%b-%Y %H:%M',
            '%Y-%m-%dT%H:%M:%S.%fZ'
        ]
        
        for fmt in date_formats:
            try:
                return datetime.strptime(date_str.strip(), fmt)
            except:
                continue
        return None
    
    def extract_file_type(self, filename: str) -> str:
        """Extract file type from filename"""
        if '.' in filename:
            return filename.split('.')[-1].lower()
        return 'unknown'
    
    def scrape_page(self, url: str) -> Tuple[BeautifulSoup, int]:
        """Scrape a page and return BeautifulSoup object"""
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            return soup, response.status_code
        except requests.exceptions.RequestException as e:
            logger.error(f"Error scraping {url}: {e}")
            return None, 0
    
    def discover_api_endpoints(self, base_url: str) -> List[str]:
        """Discover potential API endpoints for MinIO Console"""
        potential_endpoints = []
            f"{base_url}/api/v1/buckets",
            f"{base_url}/api/v1/buckets/stockdb/objects",
            f"{base_url}/api/v1/buckets/stockdb/objects/list",
            f"{base_url}/minio/admin/v3/list-buckets",
            f"{base_url}/minio/v2/buckets",
            f"{base_url.replace('/browser', '')}/api/v1/buckets",
            f"{base_url.replace('/browser/stockdb', '')}/api/v1/buckets",
            f"{base_url.replace('/browser/stockdb', '')}/api/v1/buckets/stockdb/objects"
        ]
        
        # Extract base domain for API discovery
        from urllib.parse import urlparse
        parsed = urlparse(base_url)
        base_domain = f"{parsed.scheme}://{parsed.netloc}"
        
        potential_endpoints.extend([)
            f"{base_domain}/api/v1/buckets",
            f"{base_domain}/api/v1/buckets/stockdb/objects",
            f"{base_domain}/minio/admin/v3/list-buckets"
        ])
        
        return potential_endpoints
    
    def try_api_endpoints(self, endpoints: List[str]) -> Dict:
        """Try various API endpoints to get data"""
        api_data = {}
        
        for endpoint in endpoints:
            try:
                logger.info(f"Trying API endpoint: {endpoint}")
                response = self.session.get(endpoint, timeout=10)
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        api_data[endpoint] = data
                        logger.info(f"Successfully got data from: {endpoint}")
                    except:
                        # Not JSON, try XML
                        api_data[endpoint] = response.text
                elif response.status_code == 401:
                    logger.warning(f"Authentication required for: {endpoint}")
                    api_data[endpoint] = {"error": "authentication_required"}
                elif response.status_code == 403:
                    logger.warning(f"Access denied for: {endpoint}")
                    api_data[endpoint] = {"error": "access_denied"}
                else:
                    logger.debug(f"Endpoint {endpoint} returned status: {response.status_code}")
                    
            except Exception as e:
                logger.debug(f"Error accessing {endpoint}: {e}")
                continue
        
        return api_data
    
    def extract_minio_data(self, soup: BeautifulSoup) -> Dict:
        """Extract data from MinIO browser interface"""
        data = {}
            'files': [],
            'folders': [],
            'breadcrumb': []
        }
        
        # Try to find file listings in various possible formats
        # Method 1: Table-based listings
        tables = soup.find_all('table')
        for table in tables:
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all(['td', 'th'])
                if len(cells) >= 2:  # At least name and size
                    file_info = self.parse_table_row(cells)
                    if file_info:
                        data['files'].append(file_info)
        
        # Method 2: List-based listings
        file_lists = soup.find_all(['ul', 'ol'], class_=re.compile(r'file|list|browser'))
        for file_list in file_lists:
            items = file_list.find_all('li')
            for item in items:
                file_info = self.parse_list_item(item)
                if file_info:
                    data['files'].append(file_info)
        
        # Method 3: Div-based listings
        file_divs = soup.find_all('div', class_=re.compile(r'file|object|item'))
        for div in file_divs:
            file_info = self.parse_div_item(div)
            if file_info:
                data['files'].append(file_info)
        
        # Extract breadcrumb/path
        breadcrumb = soup.find(['nav', 'div'], class_=re.compile(r'breadcrumb|path'))
        if breadcrumb:
            data['breadcrumb'] = [item.text.strip() for item in breadcrumb.find_all(['a', 'span'])]
        
        # Look for any JavaScript data
        scripts = soup.find_all('script')
        for script in scripts:
            if script.string:
                js_data = self.extract_js_data(script.string)
                if js_data:
                    data.update(js_data)
        
        return data
    
    def parse_table_row(self, cells: List) -> Optional[Dict]:
        """Parse a table row into file information"""
        if len(cells) < 2:
            return None
        
        file_info = {}
        
        # Extract name (usually first cell)
        name_cell = cells[0]
        name_link = name_cell.find('a')
        if name_link:
            file_info['name'] = name_link.text.strip()
            file_info['url'] = name_link.get('href', '')
        else:
            file_info['name'] = name_cell.text.strip()
        
        # Skip header rows
        if file_info['name'].lower() in ['name', 'filename', 'object']:
            return None
        
        # Extract size (usually second cell)
        if len(cells) > 1:
            size_text = cells[1].text.strip()
            file_info['size'] = self.parse_file_size(size_text)
            file_info['size_human'] = size_text
        
        # Extract date (usually third cell)
        if len(cells) > 2:
            date_text = cells[2].text.strip()
            date_obj = self.parse_date(date_text)
            if date_obj:
                file_info['modified'] = date_obj.isoformat()
                file_info['modified_human'] = date_text
        
        # Extract type
        file_info['type'] = self.extract_file_type(file_info['name'])
        
        return file_info if file_info.get('name') else None
    
    def parse_list_item(self, item) -> Optional[Dict]:
        """Parse a list item into file information"""
        file_info = {}
        
        # Extract link
        link = item.find('a')
        if link:
            file_info['name'] = link.text.strip()
            file_info['url'] = link.get('href', '')
        else:
            file_info['name'] = item.text.strip()
        
        # Look for size and date in spans
        spans = item.find_all('span')
        for span in spans:
            text = span.text.strip()
            if any(unit in text.upper() for unit in ['B', 'KB', 'MB', 'GB']):
                file_info['size'] = self.parse_file_size(text)
                file_info['size_human'] = text
            else:
                date_obj = self.parse_date(text)
                if date_obj:
                    file_info['modified'] = date_obj.isoformat()
                    file_info['modified_human'] = text
        
        file_info['type'] = self.extract_file_type(file_info.get('name', ''))
        
        return file_info if file_info.get('name') else None
    
    def parse_div_item(self, div) -> Optional[Dict]:
        """Parse a div element into file information"""
        file_info = {}
        
        # Extract name
        name_elem = div.find(['a', 'span'], class_=re.compile(r'name|title'))
        if name_elem:
            file_info['name'] = name_elem.text.strip()
            if name_elem.name == 'a':
                file_info['url'] = name_elem.get('href', '')
        
        # Extract size
        size_elem = div.find(['span', 'div'], class_=re.compile(r'size'))
        if size_elem:
            size_text = size_elem.text.strip()
            file_info['size'] = self.parse_file_size(size_text)
            file_info['size_human'] = size_text
        
        # Extract date
        date_elem = div.find(['span', 'div'], class_=re.compile(r'date|time|modified'))
        if date_elem:
            date_text = date_elem.text.strip()
            date_obj = self.parse_date(date_text)
            if date_obj:
                file_info['modified'] = date_obj.isoformat()
                file_info['modified_human'] = date_text
        
        file_info['type'] = self.extract_file_type(file_info.get('name', ''))
        
        return file_info if file_info.get('name') else None
    
    def extract_js_data(self, script_content: str) -> Optional[Dict]:
        """Extract data from JavaScript content"""
        data = {}
        
        # Look for JSON data
        json_patterns = []
            r'window\.__INITIAL_STATE__\s*=\s*({.*?});',
            r'var\s+data\s*=\s*({.*?});',
            r'const\s+files\s*=\s*(\[.*?\]);'
        ]
        
        for pattern in json_patterns:
            match = re.search(pattern, script_content, re.DOTALL)
            if match:
                try:
                    json_data = json.loads(match.group(1))
                    data['js_data'] = json_data
                    break
                except:
                    continue
        
        return data if data else None
    
    def parse_api_data(self, api_data: Dict) -> List[Dict]:
        """Parse API response data into file information"""
        all_files = []
        
        for endpoint, data in api_data.items():
            if isinstance(data, dict) and data.get('error'):
                continue
                
            try:
                # Handle different API response formats
                if isinstance(data, dict):
                    # MinIO list-objects response (with 'objects' key)
                    if 'objects' in data:
                        for obj in data['objects']:
                            file_info = {}
                                'name': obj.get('name', 'unknown'),
                                'size': obj.get('size', 0),
                                'size_human': self.format_bytes(obj.get('size', 0)),
                                'modified': obj.get('last_modified', obj.get('lastModified')),
                                'etag': obj.get('etag', ''),
                                'type': self.extract_file_type(obj.get('name', '')),
                                'source': endpoint
                            }
                            all_files.append(file_info)
                    
                    # MinIO list-objects response (with 'contents' key)
                    elif 'contents' in data:
                        for obj in data['contents']:
                            file_info = {}
                                'name': obj.get('key', obj.get('name', 'unknown')),
                                'size': obj.get('size', 0),
                                'size_human': self.format_bytes(obj.get('size', 0)),
                                'modified': obj.get('lastModified', obj.get('last_modified')),
                                'etag': obj.get('etag', ''),
                                'type': self.extract_file_type(obj.get('key', obj.get('name', ''))),
                                'source': endpoint
                            }
                            all_files.append(file_info)
                    
                    # MinIO buckets response
                    elif 'buckets' in data:
                        for bucket in data['buckets']:
                            file_info = {}
                                'name': bucket.get('name', 'unknown'),
                                'type': 'bucket',
                                'created': bucket.get('creationDate', bucket.get('created')),
                                'source': endpoint
                            }
                            all_files.append(file_info)
                    
                    # Generic object list
                    elif isinstance(data, list):
                        for item in data:
                            if isinstance(item, dict):
                                file_info = {}
                                    'name': item.get('name', item.get('key', 'unknown')),
                                    'size': item.get('size', 0),
                                    'size_human': self.format_bytes(item.get('size', 0)),
                                    'modified': item.get('modified', item.get('lastModified')),
                                    'type': self.extract_file_type(item.get('name', item.get('key', ''))),
                                    'source': endpoint
                                }
                                all_files.append(file_info)
                
                elif isinstance(data, str):
                    # Try to parse XML response
                    try:
                        from xml.etree import ElementTree as ET
                        root = ET.fromstring(data)
                        
                        # Parse S3/MinIO ListBucketResult
                        if root.tag.endswith('ListBucketResult'):
                            for content in root.findall('.//{*}Contents'):
                                key = content.find('{*}Key')
                                size = content.find('{*}Size')
                                modified = content.find('{*}LastModified')
                                
                                file_info = {}
                                    'name': key.text if key is not None else 'unknown',
                                    'size': int(size.text) if size is not None else 0,
                                    'size_human': self.format_bytes(int(size.text)) if size is not None else '0 B',
                                    'modified': modified.text if modified is not None else None,
                                    'type': self.extract_file_type(key.text if key is not None else ''),
                                    'source': endpoint
                                }
                                all_files.append(file_info)
                    except Exception as xml_error:
                        logger.debug(f"Failed to parse XML from {endpoint}: {xml_error}")
                        
            except Exception as e:
                logger.error(f"Error parsing data from {endpoint}: {e}")
                continue
        
        return all_files
    
    def check_authentication(self, soup: BeautifulSoup) -> bool:
        """Check if authentication is required"""
        # Look for login forms or authentication messages
        login_indicators = []
            soup.find('form', {'id': re.compile(r'login|signin')}),
            soup.find('input', {'type': 'password'}),
            soup.find(text=re.compile(r'login|sign in|authenticate', re.I))
        ]
        
        return any(login_indicators)
    
    def navigate_folders(self, base_url: str, max_depth: int = 3) -> List[Dict]:
        """Navigate through folders to discover all files"""
        all_files = []
        visited = set()
        to_visit = [(base_url, 0)]
        
        while to_visit:
            url, depth = to_visit.pop(0)
            
            if url in visited or depth > max_depth:
                continue
            
            visited.add(url)
            logger.info(f"Scraping: {url} (depth: {depth})")
            
            soup, status = self.scrape_page(url)
            if not soup:
                continue
            
            # Check for authentication
            if self.check_authentication(soup):
                logger.warning(f"Authentication required for {url}")
                self.inventory['requires_auth'] = True
                continue
            
            # Extract data
            data = self.extract_minio_data(soup)
            
            # Process files
            for file_info in data.get('files', []):
                file_info['depth'] = depth
                file_info['parent_url'] = url
                all_files.append(file_info)
                
                # Update inventory stats
                self.inventory['total_files'] += 1
                if file_info.get('size'):
                    self.inventory['total_size'] += file_info['size']
                
                file_type = file_info.get('type', 'unknown')
                self.inventory['file_types'][file_type] = self.inventory['file_types'].get(file_type, 0) + 1
                
                # If it's a folder, add to visit queue
                if file_info.get('url') and file_info['name'].endswith('/'):
                    folder_url = urljoin(url, file_info['url'])
                    to_visit.append((folder_url, depth + 1))
            
            # Small delay to be respectful
            time.sleep(0.5)
        
        return all_files
    
    def identify_datasets(self, files: List[Dict]) -> List[Dict]:
        """Identify and group files into datasets"""
        datasets = {}
        
        for file in files:
            # Extract dataset name from path or filename
            name = file.get('name', '')
            parent = file.get('parent_url', '')
            
            # Common dataset patterns
            dataset_patterns = []
                r'(\w+)_\d{4}',  # name_year
                r'(\w+)_v\d+',   # name_version
                r'(\w+)\.csv',   # simple csv
                r'(\w+)\.parquet',  # parquet files
                r'(\w+)\.json'   # json files
            ]
            
            dataset_name = None
            for pattern in dataset_patterns:
                match = re.match(pattern, name)
                if match:
                    dataset_name = match.group(1)
                    break
            
            if not dataset_name:
                dataset_name = name.split('.')[0]
            
            if dataset_name not in datasets:
                datasets[dataset_name] = {}
                    'name': dataset_name,
                    'files': [],
                    'total_size': 0,
                    'file_types': {},
                    'date_range': {'min': None, 'max': None}
                }
            
            datasets[dataset_name]['files'].append(file)
            datasets[dataset_name]['total_size'] += file.get('size', 0)
            
            file_type = file.get('type', 'unknown')
            datasets[dataset_name]['file_types'][file_type] = datasets[dataset_name]['file_types'].get(file_type, 0) + 1
            
            # Update date range
            if file.get('modified'):
                if not datasets[dataset_name]['date_range']['min'] or file['modified'] < datasets[dataset_name]['date_range']['min']:
                    datasets[dataset_name]['date_range']['min'] = file['modified']
                if not datasets[dataset_name]['date_range']['max'] or file['modified'] > datasets[dataset_name]['date_range']['max']:
                    datasets[dataset_name]['date_range']['max'] = file['modified']
        
        return list(datasets.values())
    
    def scrape_minio(self) -> Dict:
        """Main method to scrape MinIO browser"""
        logger.info(f"Starting MinIO scrape of {self.base_url}")
        
        all_files = []
        
        # First, try the traditional HTML scraping approach
        html_files = self.navigate_folders(self.base_url)
        if html_files:
            all_files.extend(html_files)
            logger.info(f"Found {len(html_files)} files via HTML scraping")
        
        # Then, try API endpoints for modern MinIO Console
        endpoints = self.discover_api_endpoints(self.base_url)
        api_data = self.try_api_endpoints(endpoints)
        
        api_files = []
        if api_data:
            api_files = self.parse_api_data(api_data)
            if api_files:
                all_files.extend(api_files)
                logger.info(f"Found {len(api_files)} files via API endpoints")
        
        # Update inventory with all discovered files
        for file_info in all_files:
            if file_info.get('size'):
                self.inventory['total_size'] += file_info['size']
            
            file_type = file_info.get('type', 'unknown')
            self.inventory['file_types'][file_type] = self.inventory['file_types'].get(file_type, 0) + 1
        
        self.inventory['total_files'] = len(all_files)
        
        # Identify datasets
        datasets = self.identify_datasets(all_files)
        self.inventory['datasets'] = datasets
        
        # Store raw API data for debugging
        self.inventory['api_discovery'] = {}
            'attempted_endpoints': endpoints,
            'successful_endpoints': [ep for ep, data in api_data.items() if not (isinstance(data, dict) and data.get('error'))],
            'api_responses': api_data
        }
        
        # Generate summary
        self.inventory['summary'] = {}
            'total_files': self.inventory['total_files'],
            'total_size_bytes': self.inventory['total_size'],
            'total_size_human': self.format_bytes(self.inventory['total_size']),
            'unique_file_types': len(self.inventory['file_types']),
            'total_datasets': len(datasets),
            'scrape_timestamp': datetime.now().isoformat(),
            'discovery_methods': {}
                'html_scraping': len(html_files) if html_files else 0,
                'api_endpoints': len(api_files)
            }
        }
        
        return self.inventory
    
    def format_bytes(self, bytes: int) -> str:
        """Format bytes to human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes < 1024.0:
                return f"{bytes:.2f} {unit}"
            bytes /= 1024.0
        return f"{bytes:.2f} PB"
    
    def save_inventory(self, filename: str = "minio_inventory.json"):
        """Save inventory to JSON file"""
        with open(filename, 'w') as f:
            json.dump(self.inventory, f, indent=2)
        logger.info(f"Inventory saved to {filename}")
    
    def print_summary(self):
        """Print a summary of the inventory"""
        print("\n" + "="*60)
        print("MinIO Data Inventory Summary")
        print("="*60)
        
        summary = self.inventory.get('summary', {})
        print(f"Total Files: {summary.get('total_files', 0)}")
        print(f"Total Size: {summary.get('total_size_human', '0 B')}")
        print(f"File Types: {summary.get('unique_file_types', 0)}")
        print(f"Datasets: {summary.get('total_datasets', 0)}")
        
        if self.inventory.get('requires_auth'):
            print("\n⚠️  Authentication required for some resources")
        
        print("\nFile Types Distribution:")
        for file_type, count in sorted(self.inventory['file_types'].items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"  {file_type}: {count}")
        
        print("\nTop Datasets by Size:")
        datasets_by_size = sorted(self.inventory['datasets'], key=lambda x: x['total_size'], reverse=True)[:10]
        for dataset in datasets_by_size:
            print(f"  {dataset['name']}: {self.format_bytes(dataset['total_size'])} ({len(dataset['files'])} files)")
        
        print("="*60)


def main():
    """Main function to run the scraper"""
    # Initialize scraper
    scraper = MinIOWebScraper()
    
    try:
        # Scrape MinIO
        inventory = scraper.scrape_minio()
        
        # Save inventory
        scraper.save_inventory()
        
        # Print summary
        scraper.print_summary()
        
        # Also save a detailed report
        with open("minio_detailed_report.txt", "w") as f:
            f.write("MinIO Data Inventory Detailed Report\n")
            f.write("="*60 + "\n\n")
            
            f.write(f"Scrape Date: {inventory['summary']['scrape_timestamp']}\n")
            f.write(f"Base URL: {scraper.base_url}\n\n")
            
            f.write("SUMMARY\n")
            f.write("-"*30 + "\n")
            f.write(f"Total Files: {inventory['summary']['total_files']}\n")
            f.write(f"Total Size: {inventory['summary']['total_size_human']}\n")
            f.write(f"File Types: {inventory['summary']['unique_file_types']}\n")
            f.write(f"Datasets: {inventory['summary']['total_datasets']}\n\n")
            
            f.write("FILE TYPES\n")
            f.write("-"*30 + "\n")
            for file_type, count in sorted(inventory['file_types'].items()):
                f.write(f"{file_type}: {count}\n")
            
            f.write("\nDATASETS\n")
            f.write("-"*30 + "\n")
            for dataset in sorted(inventory['datasets'], key=lambda x: x['name']):
                f.write(f"\nDataset: {dataset['name']}\n")
                f.write(f"  Files: {len(dataset['files'])}\n")
                f.write(f"  Size: {scraper.format_bytes(dataset['total_size'])}\n")
                f.write(f"  Types: {', '.join(dataset['file_types'].keys())}\n")
                if dataset['date_range']['min']:
                    f.write(f"  Date Range: {dataset['date_range']['min']} to {dataset['date_range']['max']}\n")
        
        logger.info("Detailed report saved to minio_detailed_report.txt")
        
    except Exception as e:
        logger.error(f"Error during scraping: {e}")
        raise


if __name__ == "__main__":
    main()