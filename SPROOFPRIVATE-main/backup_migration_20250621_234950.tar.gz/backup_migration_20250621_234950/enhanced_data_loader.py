#!/usr/bin/env python3
"""
Enhanced Data Loader for Comprehensive Backtest System
Integrates MinIO historical data and Alpaca API data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import os
from typing import Optional, Dict, Any
import yfinance as yf
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# MinIO imports
try:
    from minio import Minio
    from minio.error import S3Error
    import pyarrow.parquet as pq
    import pyarrow as pa
    MINIO_AVAILABLE = True
except ImportError:
    MINIO_AVAILABLE = False

# Try new Alpaca SDK first, then fall back to old one
try:
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame
    ALPACA_NEW_SDK = True
    ALPACA_AVAILABLE = True
except ImportError:
    ALPACA_NEW_SDK = False
    try:
        import alpaca_trade_api as tradeapi
        ALPACA_AVAILABLE = True
    except ImportError:
        ALPACA_AVAILABLE = False

logger = logging.getLogger(__name__)

class EnhancedDataLoader:
    """Loads data from multiple sources with fallback"""
    
    def __init__(self):
        # MinIO configuration
        self.minio_client = None
        if MINIO_AVAILABLE:
            try:
                # Get MinIO credentials from environment
                # Use default HTTPS port (443) for uschristmas.us
                endpoint = 'uschristmas.us'
                
                self.minio_client = Minio(
                    endpoint,
                    access_key=os.getenv('MINIO_ACCESS_KEY', 'AKSTOCKDB2024'),
                    secret_key=os.getenv('MINIO_SECRET_KEY', 'StockDB-Secret-Access-Key-2024-Secure!'),
                    secure=True
                )
                logger.info(f"MinIO client initialized with {endpoint}")
            except Exception as e:
                logger.warning(f"MinIO initialization failed: {e}")
                
        # Alpaca configuration  
        self.alpaca_client = None
        self.alpaca_api = None
        if ALPACA_AVAILABLE:
            api_key = os.getenv('ALPACA_API_KEY') or os.getenv('ALPACA_PAPER_API_KEY')
            api_secret = os.getenv('ALPACA_SECRET_KEY') or os.getenv('ALPACA_PAPER_API_SECRET')
            base_url = os.getenv('ALPACA_BASE_URL') or os.getenv('ALPACA_PAPER_BASE_URL')
            
            if api_key and api_secret:
                try:
                    if ALPACA_NEW_SDK:
                        self.alpaca_client = StockHistoricalDataClient(api_key, api_secret)
                        logger.info(f"Alpaca client initialized (new SDK) with key: {api_key[:10]}...")
                    else:
                        self.alpaca_api = tradeapi.REST(api_key, api_secret, base_url)
                        logger.info(f"Alpaca client initialized (old SDK) with key: {api_key[:10]}...")
                except Exception as e:
                    logger.warning(f"Alpaca initialization failed: {e}")
    
    def get_historical_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Get historical data with multiple source fallback"""
        
        # Try MinIO first if available (we know it has TLT data)
        if self.minio_client:
            df = self._get_minio_data(symbol, start_date, end_date)
            if not df.empty:
                logger.info(f"Loaded {symbol} data from MinIO")
                return df
        
        # Try Alpaca API as second option
        df = self._get_alpaca_data(symbol, start_date, end_date)
        if not df.empty:
            logger.info(f"Loaded {symbol} data from Alpaca")
            return df
            
        # Try yfinance
        df = self._get_yfinance_data(symbol, start_date, end_date)
        if not df.empty:
            logger.info(f"Loaded {symbol} data from yfinance")
            return df
            
        # Generate synthetic data as last resort
        logger.warning(f"No real data available for {symbol}, using synthetic")
        return self._generate_synthetic_data(symbol, start_date, end_date)
    
    def _get_minio_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Load data from MinIO storage"""
        if not self.minio_client:
            return pd.DataFrame()
            
        try:
            bucket_name = "stockdb"
            
            # TLT data is in stocks-2010-2025/TLT.csv
            csv_path = f"stocks-2010-2025/{symbol}.csv"
            
            # Check if the file exists
            try:
                stat = self.minio_client.stat_object(bucket_name, csv_path)
                logger.info(f"Found {symbol} data in MinIO: {csv_path} ({stat.size} bytes)")
                
                # Download and read CSV file
                response = self.minio_client.get_object(bucket_name, csv_path)
                df = pd.read_csv(response)
                response.close()
                
                # Parse date column - MinIO uses 'trade_date'
                date_col = None
                for col in ['Date', 'date', 'trade_date', 'timestamp']:
                    if col in df.columns:
                        date_col = col
                        break
                
                if date_col:
                    df[date_col] = pd.to_datetime(df[date_col])
                    df = df.set_index(date_col)
                    
                    # Filter by date range
                    df = df[(df.index >= start_date) & (df.index <= end_date)]
                    
                    # Standardize column names
                    column_mapping = {
                        'open': 'Open', 'Open': 'Open',
                        'high': 'High', 'High': 'High',
                        'low': 'Low', 'Low': 'Low',
                        'close': 'Close', 'Close': 'Close',
                        'volume': 'Volume', 'Volume': 'Volume'
                    }
                    df.rename(columns=column_mapping, inplace=True)
                    
                    # Ensure we have the required columns
                    required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
                    if all(col in df.columns for col in required_cols):
                        # Filter out rows with zero or invalid prices
                        price_cols = ['Open', 'High', 'Low', 'Close']
                        valid_mask = (df[price_cols] > 0).all(axis=1)
                        df_clean = df[valid_mask]
                        
                        if len(df_clean) < len(df):
                            logger.info(f"Filtered out {len(df) - len(df_clean)} rows with invalid prices")
                        
                        return df_clean[required_cols]
                    else:
                        logger.warning(f"Missing required columns in MinIO data. Found: {list(df.columns)}")
                        
            except S3Error as e:
                if e.code != 'NoSuchKey':
                    logger.debug(f"MinIO error for {symbol}: {e}")
                    
            # Try other possible locations
            prefixes = [f"stocks/{symbol}/", f"{symbol}/", f"data/{symbol}/"]
            
            for prefix in prefixes:
                objects = list(self.minio_client.list_objects(bucket_name, prefix=prefix, recursive=True))
                
                if objects:
                    logger.info(f"Found {len(objects)} objects for {symbol} in {prefix}")
                    # Process CSV or parquet files
                    for obj in objects:
                        if obj.object_name.endswith(('.csv', '.parquet')):
                            # Process first matching file
                            data = self.minio_client.get_object(bucket_name, obj.object_name)
                            
                            if obj.object_name.endswith('.csv'):
                                df = pd.read_csv(data)
                            else:
                                df = pd.read_parquet(data)
                            
                            data.close()
                            
                            # Process and return data
                            date_col = None
                            for col in ['Date', 'date', 'trade_date', 'timestamp']:
                                if col in df.columns:
                                    date_col = col
                                    break
                            
                            if date_col:
                                df[date_col] = pd.to_datetime(df[date_col])
                                df = df.set_index(date_col)
                                df = df[(df.index >= start_date) & (df.index <= end_date)]
                                
                                # Standardize columns and return
                                column_mapping = {
                                    'open': 'Open', 'Open': 'Open',
                                    'high': 'High', 'High': 'High',
                                    'low': 'Low', 'Low': 'Low',
                                    'close': 'Close', 'Close': 'Close',
                                    'volume': 'Volume', 'Volume': 'Volume'
                                }
                                df.rename(columns=column_mapping, inplace=True)
                                
                                required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
                                if all(col in df.columns for col in required_cols):
                                    # Filter out rows with zero or invalid prices
                                    price_cols = ['Open', 'High', 'Low', 'Close']
                                    valid_mask = (df[price_cols] > 0).all(axis=1)
                                    df_clean = df[valid_mask]
                                    
                                    if len(df_clean) < len(df):
                                        logger.info(f"Filtered out {len(df) - len(df_clean)} rows with invalid prices")
                                    
                                    return df_clean[required_cols]
                            break
                
        except Exception as e:
            logger.debug(f"MinIO data fetch failed for {symbol}: {e}")
            
        return pd.DataFrame()
    
    def _get_alpaca_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Load data from Alpaca API"""
        if not self.alpaca_client and not self.alpaca_api:
            return pd.DataFrame()
            
        try:
            if ALPACA_NEW_SDK and self.alpaca_client:
                # New SDK method
                request = StockBarsRequest(
                    symbol_or_symbols=symbol,
                    start=start_date,
                    end=end_date,
                    timeframe=TimeFrame.Day
                )
                
                bars = self.alpaca_client.get_stock_bars(request)
                
                if symbol in bars.df.index.get_level_values('symbol'):
                    df = bars.df.loc[symbol]
                    
                    # Standardize column names
                    column_mapping = {
                        'open': 'Open',
                        'high': 'High',
                        'low': 'Low', 
                        'close': 'Close',
                        'volume': 'Volume'
                    }
                    df.rename(columns=column_mapping, inplace=True)
                    
                    return df[['Open', 'High', 'Low', 'Close', 'Volume']]
            
            elif self.alpaca_api:
                # Old SDK method
                bars = self.alpaca_api.get_bars(
                    symbol,
                    '1Day',
                    start=start_date.isoformat(),
                    end=end_date.isoformat(),
                    limit=1000,
                    adjustment='raw'
                ).df
                
                if not bars.empty:
                    # Standardize column names
                    column_mapping = {
                        'open': 'Open',
                        'high': 'High',
                        'low': 'Low', 
                        'close': 'Close',
                        'volume': 'Volume'
                    }
                    bars.rename(columns=column_mapping, inplace=True)
                    
                    return bars[['Open', 'High', 'Low', 'Close', 'Volume']]
                
        except Exception as e:
            logger.debug(f"Alpaca data fetch failed for {symbol}: {e}")
            
        return pd.DataFrame()
    
    def _get_yfinance_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Load data from yfinance"""
        try:
            ticker = yf.Ticker(symbol)
            df = ticker.history(start=start_date, end=end_date, interval='1d')
            
            if not df.empty:
                return df[['Open', 'High', 'Low', 'Close', 'Volume']]
                
        except Exception as e:
            logger.debug(f"yfinance data fetch failed for {symbol}: {e}")
            
        return pd.DataFrame()
    
    def _generate_synthetic_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Generate synthetic data when real data unavailable"""
        days = (end_date - start_date).days
        dates = pd.date_range(start=start_date, end=end_date, freq='B')  # Business days
        
        # Realistic price simulation
        base_price = 100
        if symbol == 'TLT':
            base_price = 120  # Bond ETF typical price
            volatility = 0.12  # Lower volatility for bonds
        else:
            volatility = 0.25  # Stock volatility
            
        returns = np.random.normal(0.0001, volatility/np.sqrt(252), len(dates))
        prices = base_price * np.exp(np.cumsum(returns))
        
        df = pd.DataFrame({
            'Open': prices * np.random.uniform(0.99, 1.01, len(dates)),
            'High': prices * np.random.uniform(1.0, 1.02, len(dates)),
            'Low': prices * np.random.uniform(0.98, 1.0, len(dates)),
            'Close': prices,
            'Volume': np.random.lognormal(15, 1, len(dates)).astype(int)
        }, index=dates)
        
        return df