#!/usr/bin/env python3
"""
Execute Trades - Fixed Version
==============================
Executes paper trades with proper error handling
"""

import os
import asyncio
import logging
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Get credentials
API_KEY = os.getenv('ALPACA_API_KEY') or os.getenv('ALPACA_PAPER_API_KEY')
SECRET_KEY = os.getenv('ALPACA_SECRET_KEY') or os.getenv('ALPACA_PAPER_API_SECRET')

async def execute_trades():
    """Execute paper trades with Alpaca API."""
    try:
        from alpaca.trading.client import TradingClient
        from alpaca.trading.requests import MarketOrderRequest
        from alpaca.trading.enums import OrderSide, TimeInForce
        
        # Create trading client
        trading_client = TradingClient(API_KEY, SECRET_KEY, paper=True)
        
        # Get account info
        account = trading_client.get_account()
        logger.info(f"\n📊 Account Status:")
        logger.info(f"   Equity: ${float(account.equity):,.2f}")
        logger.info(f"   Cash: ${float(account.cash):,.2f}")
        logger.info(f"   Positions: {len(trading_client.get_all_positions())}")
        
        # Execute a small test trade
        logger.info(f"\n📈 Executing test trade...")
        
        try:
            order_request = MarketOrderRequest()
                symbol="SPY",
                qty=1,
                side=OrderSide.BUY,
                time_in_force=TimeInForce.DAY
            )
            
            order = trading_client.submit_order(order_request)
            logger.info(f"   ✅ BUY 1 SPY - Order submitted")
            logger.info(f"   Order ID: {str(order.id)}")
            logger.info(f"   Status: {order.status}")
            
        except Exception as e:
            logger.error(f"   ❌ Trade failed: {e}")
        
        # Get all orders
        logger.info(f"\n📋 Recent Orders:")
        orders = trading_client.get_orders()
        for i, order in enumerate(orders[:5]):
            logger.info(f"   {i+1}. {order.symbol} - {order.qty} shares - {order.status}")
        
        # Get positions
        positions = trading_client.get_all_positions()
        if positions:
            logger.info(f"\n📊 Top 5 Positions:")
            for i, pos in enumerate(positions[:5]):
                value = float(pos.qty) * float(pos.current_price or pos.avg_entry_price)
                logger.info(f"   {i+1}. {pos.symbol}: {pos.qty} shares = ${value:,.2f}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return False

async def main():
    """Main execution."""
    print(""")
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║                        TRADE EXECUTION - FIXED                         ║
    ╚═══════════════════════════════════════════════════════════════════════╝
    """)
    
    if not API_KEY or not SECRET_KEY:
        logger.error("❌ No API credentials found!")
        return
    
    await execute_trades()
    
    logger.info("\n✅ Trade execution complete!")

if __name__ == "__main__":
    asyncio.run(main())