
#!/usr/bin/env python3
"""
Real-time dashboard for Premium Harvesting Bot
Provides web interface for monitoring positions and performance
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import json
import threading
import time
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify
import pandas as pd
import plotly.graph_objs as go
import plotly.utils
from collections import defaultdict

from universal_market_data import get_current_market_data, validate_price


app = Flask(__name__)

# Shared data with bot
bot_data = {}
    'positions': {},
    'risk_metrics': {},
    'performance': defaultdict(float),
    'trade_history': [],
    'market_data': {}
}

@app.route('/')
def index():
    """Main dashboard page"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Premium Harvest Bot Dashboard</title>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
            .container { max-width: 1400px; margin: 0 auto; }
            .card { background: white; border-radius: 8px; padding: 20px; margin: 10px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .metric { display: inline-block; margin: 10px 20px; }
            .metric-value { font-size: 24px; font-weight: bold; color: #2c3e50; }
            .metric-label { font-size: 12px; color: #7f8c8d; }
            .position-table { width: 100%; border-collapse: collapse; }
            .position-table th, .position-table td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
            .profit { color: #27ae60; }
            .loss { color: #e74c3c; }
            h2 { color: #2c3e50; }
            .status-active { color: #27ae60; }
            .status-stopped { color: #e74c3c; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Premium Harvest Bot Dashboard</h1>
            
            <div class="card">
                <h2>Portfolio Metrics</h2>
                <div id="metrics"></div>
            </div>
            
            <div class="card">
                <h2>Active Positions</h2>
                <table class="position-table" id="positions">
                    <thead>
                        <tr>
                            <th>Symbol</th>
                            <th>Strike</th>
                            <th>Expiry</th>
                            <th>Contracts</th>
                            <th>Entry Premium</th>
                            <th>Current Premium</th>
                            <th>P&L</th>
                            <th>P&L %</th>
                            <th>Delta</th>
                            <th>Theta</th>
                        </tr>
                    </thead>
                    <tbody id="positions-body"></tbody>
                </table>
            </div>
            
            <div class="card">
                <h2>Performance Chart</h2>
                <div id="performance-chart"></div>
            </div>
            
            <div class="card">
                <h2>Greeks Exposure</h2>
                <div id="greeks-chart"></div>
            </div>
        </div>
        
        <script>
            function updateDashboard() {}
                $.get('/api/data', function(data) {)
                    // Update metrics
                    let metricsHtml = '';
                    for (let key in data.metrics) {}
                        metricsHtml += `
                            <div class="metric">
                                <div class="metric-label">${key.replace(/_/g, ' ').toUpperCase()}</div>
                                <div class="metric-value">${data.metrics[key]}</div>
                            </div>
                        `;
                    }
                    $('#metrics').html(metricsHtml);
                    
                    // Update positions
                    let positionsHtml = '';
                    for (let id in data.positions) {}
                        let pos = data.positions[id];
                        let pnlClass = pos.pnl >= 0 ? 'loss' : 'profit';
                        positionsHtml += `
                            <tr>
                                <td>${pos.symbol}</td>
                                <td>$${pos.strike}</td>
                                <td>${pos.expiry}</td>
                                <td>${pos.contracts}</td>
                                <td>$${pos.sold_premium.toFixed(2)}</td>
                                <td>$${pos.current_premium.toFixed(2)}</td>
                                <td class="${pnlClass}">$${pos.pnl.toFixed(2)}</td>
                                <td class="${pnlClass}">${pos.pnl_percentage.toFixed(1)}%</td>
                                <td>${pos.delta.toFixed(3)}</td>
                                <td>$${pos.theta.toFixed(2)}</td>
                            </tr>
                        `;
                    }
                    $('#positions-body').html(positionsHtml || '<tr><td colspan="10">No active positions</td></tr>');
                    
                    // Update performance chart
                    if (data.performance_data) {}
                        Plotly.newPlot('performance-chart', data.performance_data.data, data.performance_data.layout);
                    }
                    
                    // Update Greeks chart
                    if (data.greeks_data) {}
                        Plotly.newPlot('greeks-chart', data.greeks_data.data, data.greeks_data.layout);
                    }
                });
            }
            
            // Update every 5 seconds
            setInterval(updateDashboard, 5000);
            updateDashboard();
        </script>
    </body>
    </html>
    '''

@app.route('/api/data')
def api_data():
    """API endpoint for dashboard data"""
    # Calculate metrics
    metrics = {}
        'total_positions': len(bot_data['positions']),
        'total_pnl': f"${sum(p.get('pnl', 0) for p in bot_data['positions'].values():.2f}",
        'theta_income': f"${bot_data['risk_metrics'].get('theta_income', 0):.2f}/day",
        'delta_exposure': f"${bot_data['risk_metrics'].get('delta_exposure', 0):.2f}",
        'win_rate': calculate_win_rate(),
        'avg_profit': calculate_avg_profit()
    }
    
    # Prepare position data
    positions = {}
    for id, pos in bot_data['positions'].items():
        positions[id] = {}
            'symbol': pos.get('symbol'),
            'strike': pos.get('strike'),
            'expiry': pos.get('expiry'),
            'contracts': pos.get('contracts'),
            'sold_premium': pos.get('sold_premium', 0),
            'current_premium': pos.get('current_premium', 0),
            'pnl': pos.get('pnl', 0),
            'pnl_percentage': pos.get('pnl_percentage', 0),
            'delta': pos.get('greeks', {}).get('delta', 0),
            'theta': pos.get('greeks', {}).get('theta', 0) * pos.get('contracts', 0) * 100
        }
    
    # Performance chart data
    performance_data = create_performance_chart()
    
    # Greeks chart data
    greeks_data = create_greeks_chart()
    
    return jsonify({)
        'metrics': metrics,
        'positions': positions,
        'performance_data': performance_data,
        'greeks_data': greeks_data
    })

def calculate_win_rate():
    """Calculate win rate from trade history"""
    if not bot_data['trade_history']:
        return "N/A"
    
    wins = sum(1 for trade in bot_data['trade_history'] if trade.get('pnl', 0) > 0)
    total = len(bot_data['trade_history'])
    
    return f"{(wins/total)*100:.1f}%" if total > 0 else "N/A"

def calculate_avg_profit():
    """Calculate average profit per trade"""
    if not bot_data['trade_history']:
        return "N/A"
        
    total_pnl = sum(trade.get('pnl', 0) for trade in bot_data['trade_history'])
    avg = total_pnl / len(bot_data['trade_history'])
    
    return f"${avg:.2f}"

def create_performance_chart():
    """Create performance over time chart"""
    # Mock data for demonstration
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    cumulative_pnl = [sum(bot_data['performance'].values()] * 30)
    
    # Add some variation
    for i in range(1, 30):
        cumulative_pnl[i] = cumulative_pnl[i-1] + (i * 10)
    
    trace = go.Scatter()
        x=dates,
        y=cumulative_pnl,
        mode='lines',
        name='Cumulative P&L',
        line=dict(color='#27ae60', width=2)
    )
    
    layout = go.Layout()
        title='Cumulative Performance',
        xaxis=dict(title='Date'),
        yaxis=dict(title='P&L ($)'),
        height=400
    )
    
    return {'data': [trace], 'layout': layout}

def create_greeks_chart():
    """Create Greeks exposure chart"""
    greeks = bot_data['risk_metrics']
    
    categories = ['Delta', 'Gamma', 'Theta', 'Vega']
    values = []
        greeks.get('delta_exposure', 0),
        greeks.get('gamma_exposure', 0),
        greeks.get('theta_income', 0),
        greeks.get('vega_exposure', 0)
    ]
    
    trace = go.Bar()
        x=categories,
        y=values,
        marker=dict(color=['#3498db', '#e74c3c', '#27ae60', '#f39c12'])
    )
    
    layout = go.Layout()
        title='Greeks Exposure',
        xaxis=dict(title='Greek'),
        yaxis=dict(title='Exposure ($)'),
        height=300
    )
    
    return {'data': [trace], 'layout': layout}

def run_dashboard():
    """Run the dashboard in a separate thread"""
    app.run(host='0.0.0.0', port=5000, debug=False)

if __name__ == '__main__':
    # Start dashboard
    dashboard_thread = threading.Thread(target=run_dashboard)
    dashboard_thread.daemon = True
    dashboard_thread.start()
    
    print("Dashboard running at http://localhost:5000")
    
    # Keep running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Dashboard stopped")