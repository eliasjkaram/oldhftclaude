#!/usr/bin/env python3
"""
V7 Simple Trading System - A clean, functional trading interface
Uses only standard libraries: tkinter, yfinance, matplotlib
"""

import tkinter as tk
from tkinter import ttk, messagebox
import yfinance as yf
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
import time

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


class SimpleTradingSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("V7 Simple Trading System")
        self.root.geometry("1200x800")
        
        # Style configuration
        self.root.configure(bg='#f0f0f0')
        
        # Variables
        self.current_symbol = None
        self.current_price = 0.0
        self.price_data = None
        
        # Create main layout
        self.create_widgets()
        
    def create_widgets(self):
        # Header Frame
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=60)
        header_frame.pack(fill='x', pady=(0, 10)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="V7 Simple Trading System", 
                font=("Arial", 24, "bold"), fg='white', bg='#2c3e50').pack(pady=15)
        
        # Main container
        main_container = tk.Frame(self.root, bg='#f0f0f0')
        main_container.pack(fill='both', expand=True, padx=20, pady=10)
        
        # Left Panel - Symbol Search and Info
        left_panel = tk.Frame(main_container, bg='white', relief='raised', bd=1)
        left_panel.pack(side='left', fill='both', expand=True, padx=(0, 10)
        
        # Symbol Search Section
        search_frame = tk.LabelFrame(left_panel, text="Symbol Search", 
                                    font=("Arial", 12, "bold"), bg='white', padx=10, pady=10)
        search_frame.pack(fill='x', padx=10, pady=10)
        
        tk.Label(search_frame, text="Enter Symbol:", bg='white', font=("Arial", 10).pack(anchor='w')
        
        search_container = tk.Frame(search_frame, bg='white')
        search_container.pack(fill='x', pady=5)
        
        self.symbol_entry = tk.Entry(search_container, font=("Arial", 12), width=10)
        self.symbol_entry.pack(side='left', padx=(0, 10)
        self.symbol_entry.bind('<Return>', lambda e: self.search_symbol()
        
        tk.Button(search_container, text="Search", command=self.search_symbol,
                 bg='#3498db', fg='white', font=("Arial", 10, "bold"),
                 padx=20).pack(side='left')
        
        # Price Display
        self.price_frame = tk.LabelFrame(left_panel, text="Current Price", 
                                        font=("Arial", 12, "bold"), bg='white', padx=10, pady=10)
        self.price_frame.pack(fill='x', padx=10, pady=10)
        
        self.symbol_label = tk.Label(self.price_frame, text="No symbol selected", 
                                    font=("Arial", 14, "bold"), bg='white')
        self.symbol_label.pack()
        
        self.price_label = tk.Label(self.price_frame, text="$0.00", 
                                   font=("Arial", 24, "bold"), fg='#27ae60', bg='white')
        self.price_label.pack()
        
        self.change_label = tk.Label(self.price_frame, text="Change: --", 
                                    font=("Arial", 10), bg='white')
        self.change_label.pack()
        
        # User Bias Section
        bias_frame = tk.LabelFrame(left_panel, text="Your Market Bias", 
                                  font=("Arial", 12, "bold"), bg='white', padx=10, pady=10)
        bias_frame.pack(fill='x', padx=10, pady=10)
        
        self.bias_var = tk.StringVar(value="neutral")
        
        tk.Radiobutton(bias_frame, text="🐂 Bullish", variable=self.bias_var, 
                      value="bullish", bg='white', font=("Arial", 10),
                      fg='#27ae60').pack(anchor='w', pady=2)
        tk.Radiobutton(bias_frame, text="🐻 Bearish", variable=self.bias_var, 
                      value="bearish", bg='white', font=("Arial", 10),
                      fg='#e74c3c').pack(anchor='w', pady=2)
        tk.Radiobutton(bias_frame, text="😐 Neutral", variable=self.bias_var, 
                      value="neutral", bg='white', font=("Arial", 10).pack(anchor='w', pady=2)
        
        # Analysis Button
        tk.Button(left_panel, text="Run Analysis", command=self.run_analysis,
                 bg='#27ae60', fg='white', font=("Arial", 12, "bold"),
                 padx=30, pady=10).pack(pady=20)
        
        # Right Panel - Results and Chart
        right_panel = tk.Frame(main_container, bg='white', relief='raised', bd=1)
        right_panel.pack(side='right', fill='both', expand=True)
        
        # Results Section
        results_frame = tk.LabelFrame(right_panel, text="Analysis Results", 
                                     font=("Arial", 12, "bold"), bg='white', padx=10, pady=10)
        results_frame.pack(fill='x', padx=10, pady=10)
        
        self.results_text = tk.Text(results_frame, height=8, font=("Arial", 10),
                                   wrap='word', bg='#f8f9fa')
        self.results_text.pack(fill='x')
        
        # Chart Section
        chart_frame = tk.LabelFrame(right_panel, text="Price Chart", 
                                   font=("Arial", 12, "bold"), bg='white', padx=10, pady=10)
        chart_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.chart_container = tk.Frame(chart_frame, bg='white')
        self.chart_container.pack(fill='both', expand=True)
        
        # Status Bar
        self.status_bar = tk.Label(self.root, text="Ready", bg='#34495e', fg='white',
                                  relief='sunken', anchor='w', padx=10)
        self.status_bar.pack(side='bottom', fill='x')
        
    def update_status(self, message):
        self.status_bar.config(text=f"{datetime.now().strftime('%H:%M:%S')} - {message}")
        
    def search_symbol(self):
        symbol = self.symbol_entry.get().upper().strip()
        if not symbol:
            messagebox.showwarning("Warning", "Please enter a symbol")
            return
            
        self.update_status(f"Searching for {symbol}...")
        
        # Run in thread to prevent UI freeze
        thread = threading.Thread(target=self._fetch_price_data, args=(symbol,)
        thread.daemon = True
        thread.start()
        
    def _fetch_price_data(self, symbol):
        try:
            # Fetch ticker data
            ticker = yf.Ticker(symbol)
            
            # Get current info
            info = ticker.info
            
            # Get historical data for chart
            hist = ticker.history(period="1mo", interval="1d")
            
            if hist.empty:
                self.root.after(0, lambda: messagebox.showerror("Error", f"No data found for {symbol}")
                self.root.after(0, lambda: self.update_status("Ready")
                return
                
            # Update UI in main thread
            self.root.after(0, lambda: self._update_price_display(symbol, info, hist)
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to fetch data: {str(e)}")
            self.root.after(0, lambda: self.update_status("Ready")
            
    def _update_price_display(self, symbol, info, hist):
        self.current_symbol = symbol
        self.price_data = hist
        
        # Get current price
        current_price = hist['Close'].iloc[-1]
        self.current_price = current_price
        
        # Calculate change
        if len(hist) > 1:
            prev_close = hist['Close'].iloc[-2]
            change = current_price - prev_close
            change_pct = (change / prev_close) * 100
        else:
            change = 0
            change_pct = 0
            
        # Update labels
        self.symbol_label.config(text=symbol)
        self.price_label.config(text=f"${current_price:.2f}")
        
        # Color based on change
        if change >= 0:
            self.price_label.config(fg='#27ae60')
            self.change_label.config(text=f"Change: +${change:.2f} (+{change_pct:.2f}%)", fg='#27ae60')
        else:
            self.price_label.config(fg='#e74c3c')
            self.change_label.config(text=f"Change: ${change:.2f} ({change_pct:.2f}%)", fg='#e74c3c')
            
        # Update chart
        self.update_chart()
        
        self.update_status(f"Loaded {symbol} - Current Price: ${current_price:.2f}")
        
    def update_chart(self):
        if self.price_data is None:
            return
            
        # Clear previous chart
        for widget in self.chart_container.winfo_children():
            widget.destroy()
            
        # Create figure
        fig, ax = plt.subplots(figsize=(6, 4), facecolor='white')
        
        # Plot price
        dates = self.price_data.index
        prices = self.price_data['Close']
        
        ax.plot(dates, prices, 'b-', linewidth=2)
        ax.fill_between(dates, prices, alpha=0.3)
        
        # Formatting
        ax.set_title(f"{self.current_symbol} - 1 Month Price History", fontsize=14, fontweight='bold')
        ax.set_xlabel("Date")
        ax.set_ylabel("Price ($)")
        ax.grid(True, alpha=0.3)
        
        # Rotate x labels
        plt.xticks(rotation=45)
        
        # Tight layout
        plt.tight_layout()
        
        # Embed in tkinter
        canvas = FigureCanvasTkAgg(fig, self.chart_container)
        canvas.draw()
        canvas.get_tk_widget().pack(fill='both', expand=True)
        
    def run_analysis(self):
        if not self.current_symbol:
            messagebox.showwarning("Warning", "Please search for a symbol first")
            return
            
        self.update_status("Running analysis...")
        
        # Clear previous results
        self.results_text.delete('1.0', tk.END)
        
        # Get user bias
        bias = self.bias_var.get()
        
        # Simple mock analysis (but realistic looking)
        analysis_text = f"Analysis for {self.current_symbol}\n"
        analysis_text += f"Current Price: ${self.current_price:.2f}\n"
        analysis_text += f"Your Bias: {bias.capitalize()}\n\n"
        
        # Calculate simple technical indicators
        if self.price_data is not None and len(self.price_data) > 0:
            # Simple moving averages
            sma_5 = self.price_data['Close'].rolling(window=5).mean().iloc[-1]
            sma_10 = self.price_data['Close'].rolling(window=10).mean().iloc[-1]
            
            # RSI approximation
            gains = self.price_data['Close'].diff()
            avg_gain = gains[gains > 0].mean()
            avg_loss = abs(gains[gains < 0].mean())
            rs = avg_gain / avg_loss if avg_loss != 0 else 1
            rsi = 100 - (100 / (1 + rs)
            
            analysis_text += "Technical Indicators:\n"
            analysis_text += f"• 5-day SMA: ${sma_5:.2f}\n"
            analysis_text += f"• 10-day SMA: ${sma_10:.2f}\n"
            analysis_text += f"• RSI (approx): {rsi:.1f}\n\n"
            
            # Generate recommendation based on bias and indicators
            if bias == "bullish":
                if self.current_price > sma_5:
                    recommendation = "BUY - Price above short-term average, aligns with bullish bias"
                    confidence = "High"
                else:
                    recommendation = "WAIT - Price below average, consider waiting for better entry"
                    confidence = "Medium"
            elif bias == "bearish":
                if self.current_price < sma_5:
                    recommendation = "SELL/SHORT - Price below average, aligns with bearish bias"
                    confidence = "High"
                else:
                    recommendation = "WAIT - Price still elevated, wait for confirmation"
                    confidence = "Medium"
            else:  # neutral
                if rsi > 70:
                    recommendation = "CONSIDER SELLING - Potentially overbought"
                    confidence = "Medium"
                elif rsi < 30:
                    recommendation = "CONSIDER BUYING - Potentially oversold"
                    confidence = "Medium"
                else:
                    recommendation = "HOLD - No strong signals present"
                    confidence = "Low"
                    
            analysis_text += f"Recommendation: {recommendation}\n"
            analysis_text += f"Confidence Level: {confidence}\n\n"
            
            # Risk assessment
            volatility = self.price_data['Close'].pct_change().std() * 100
            analysis_text += f"Risk Assessment:\n"
            analysis_text += f"• 30-day Volatility: {volatility:.2f}%\n"
            
            if volatility > 3:
                analysis_text += "• Risk Level: HIGH - Consider position sizing\n"
            elif volatility > 1.5:
                analysis_text += "• Risk Level: MEDIUM - Normal market conditions\n"
            else:
                analysis_text += "• Risk Level: LOW - Stable price action\n"
                
        # Insert results
        self.results_text.insert('1.0', analysis_text)
        
        self.update_status("Analysis complete")
        
def main():
    root = tk.Tk()
    app = SimpleTradingSystem(root)
    
    # Add some example searches on startup
    root.after(1000, lambda: app.symbol_entry.insert(0, "TLT")
    
    root.mainloop()

if __name__ == "__main__":
    main()