#!/usr/bin/env python3
"""
Model Performance Evaluation Suite
==================================
Comprehensive evaluation suite for model performance analysis across multiple dimensions.
Provides statistical rigor, visualization, and production monitoring capabilities.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import json
import logging
from pathlib import Path
import warnings
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import asyncio
from abc import ABC, abstractmethod

# Statistical libraries
from scipy import stats
from scipy.stats import ks_2samp, mannwhitneyu, wilcoxon, shapiro
from statsmodels.stats.power import TTestPower
from statsmodels.tsa.stattools import adfuller, acf, pacf
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm

# ML libraries
from sklearn.metrics import ()
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
    mean_squared_error, mean_absolute_error, r2_score
)
from sklearn.model_selection import cross_val_score
import shap

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import matplotlib.backends.backend_pdf as pdf_backend

# Local imports (assuming these exist)
from unified_logging import get_logger
from unified_error_handling import retry, ErrorCategory, ErrorSeverity

logger = get_logger(__name__)

# Suppress warnings for clean output
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=RuntimeWarning)


@dataclass
class PerformanceMetrics:
    """Container for all performance metrics"""
    # Trading metrics
    total_return: float = 0.0
    annualized_return: float = 0.0
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    max_drawdown: float = 0.0
    max_drawdown_duration: int = 0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    
    # Risk metrics
    var_95: float = 0.0
    cvar_95: float = 0.0
    var_99: float = 0.0
    cvar_99: float = 0.0
    tail_ratio: float = 0.0
    downside_deviation: float = 0.0
    
    # ML metrics
    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1_score: Optional[float] = None
    auc_roc: Optional[float] = None
    mse: Optional[float] = None
    mae: Optional[float] = None
    r2: Optional[float] = None
    
    # Options metrics
    delta_mae: Optional[float] = None
    gamma_mae: Optional[float] = None
    vega_mae: Optional[float] = None
    theta_mae: Optional[float] = None
    iv_rmse: Optional[float] = None
    
    # Execution metrics
    avg_slippage: float = 0.0
    total_slippage: float = 0.0
    market_impact: float = 0.0
    implementation_shortfall: float = 0.0
    
    # Statistical metrics
    confidence_intervals: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    p_values: Dict[str, float] = field(default_factory=dict)
    effect_sizes: Dict[str, float] = field(default_factory=dict)


@dataclass
class ModelPrediction:
    """Single model prediction with metadata"""
    timestamp: datetime
    model_id: str
    features: Dict[str, float]
    prediction: float
    actual: Optional[float] = None
    confidence: Optional[float] = None
    execution_price: Optional[float] = None
    position_size: Optional[float] = None
    pnl: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class MetricsCalculator:
    """Calculate various performance metrics"""
    
    @staticmethod
    def calculate_trading_metrics(returns: pd.Series, 
                                benchmark_returns: Optional[pd.Series] = None,
                                risk_free_rate: float = 0.02) -> Dict[str, float]:
        """Calculate trading performance metrics"""
        if len(returns) == 0:
            return {}
        
        # Annualization factor
        periods_per_year = 252 if len(returns) > 100 else 12
        
        # Basic returns
        total_return = (1 + returns).prod() - 1
        annualized_return = (1 + total_return) ** (periods_per_year / len(returns)) - 1
        
        # Volatility
        volatility = returns.std() * np.sqrt(periods_per_year)
        downside_returns = returns[returns < 0]
        downside_vol = downside_returns.std() * np.sqrt(periods_per_year) if len(downside_returns) > 0 else 0
        
        # Risk-adjusted returns
        sharpe = (annualized_return - risk_free_rate) / volatility if volatility > 0 else 0
        sortino = (annualized_return - risk_free_rate) / downside_vol if downside_vol > 0 else 0
        
        # Drawdown analysis
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_dd = drawdown.min()
        
        # Drawdown duration
        dd_start = None
        max_duration = 0
        current_duration = 0
        
        for i, dd in enumerate(drawdown):
            if dd < 0:
                if dd_start is None:
                    dd_start = i
                current_duration = i - dd_start
            else:
                if current_duration > max_duration:
                    max_duration = current_duration
                dd_start = None
                current_duration = 0
        
        # Calmar ratio
        calmar = annualized_return / abs(max_dd) if max_dd != 0 else 0
        
        # Win/loss statistics
        wins = returns[returns > 0]
        losses = returns[returns < 0]
        win_rate = len(wins) / len(returns) if len(returns) > 0 else 0
        
        avg_win = wins.mean() if len(wins) > 0 else 0
        avg_loss = losses.mean() if len(losses) > 0 else 0
        
        # Profit factor
        total_wins = wins.sum() if len(wins) > 0 else 0
        total_losses = abs(losses.sum()) if len(losses) > 0 else 0
        profit_factor = total_wins / total_losses if total_losses > 0 else np.inf
        
        # Information ratio (if benchmark provided)
        info_ratio = 0
        if benchmark_returns is not None and len(benchmark_returns) == len(returns):
            excess_returns = returns - benchmark_returns
            tracking_error = excess_returns.std() * np.sqrt(periods_per_year)
            info_ratio = excess_returns.mean() * periods_per_year / tracking_error if tracking_error > 0 else 0
        
        return {}
            'total_return': total_return,
            'annualized_return': annualized_return,
            'volatility': volatility,
            'sharpe_ratio': sharpe,
            'sortino_ratio': sortino,
            'calmar_ratio': calmar,
            'max_drawdown': max_dd,
            'max_drawdown_duration': max_duration,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'downside_deviation': downside_vol,
            'information_ratio': info_ratio
        }
    
    @staticmethod
    def calculate_risk_metrics(returns: pd.Series, 
                             confidence_levels: List[float] = [0.95, 0.99]) -> Dict[str, float]:
        """Calculate risk metrics"""
        if len(returns) == 0:
            return {}
        
        metrics = {}
        
        for level in confidence_levels:
            # VaR
            var = np.percentile(returns, (1 - level) * 100)
            metrics[f'var_{int(level*100)}'] = var
            
            # CVaR (Expected Shortfall)
            cvar = returns[returns <= var].mean()
            metrics[f'cvar_{int(level*100)}'] = cvar
        
        # Tail ratio
        right_tail = np.percentile(returns, 95)
        left_tail = abs(np.percentile(returns, 5))
        metrics['tail_ratio'] = right_tail / left_tail if left_tail > 0 else np.inf
        
        # Higher moments
        metrics['skewness'] = stats.skew(returns)
        metrics['kurtosis'] = stats.kurtosis(returns)
        
        # Maximum daily loss
        metrics['worst_day'] = returns.min()
        metrics['best_day'] = returns.max()
        
        return metrics
    
    @staticmethod
    def calculate_ml_metrics(y_true: np.ndarray, 
                           y_pred: np.ndarray,
                           task_type: str = 'regression',
                           y_prob: Optional[np.ndarray] = None) -> Dict[str, float]:
        """Calculate ML performance metrics"""
        metrics = {}
        
        if task_type == 'regression':
            metrics['mse'] = mean_squared_error(y_true, y_pred)
            metrics['rmse'] = np.sqrt(metrics['mse'])
            metrics['mae'] = mean_absolute_error(y_true, y_pred)
            metrics['r2'] = r2_score(y_true, y_pred)
            metrics['mape'] = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
            
        elif task_type == 'classification':
            metrics['accuracy'] = accuracy_score(y_true, y_pred)
            metrics['precision'] = precision_score(y_true, y_pred, average='weighted')
            metrics['recall'] = recall_score(y_true, y_pred, average='weighted')
            metrics['f1_score'] = f1_score(y_true, y_pred, average='weighted')
            
            if y_prob is not None:
                if len(np.unique(y_true)) == 2:
                    metrics['auc_roc'] = roc_auc_score(y_true, y_prob[:, 1])
                else:
                    metrics['auc_roc'] = roc_auc_score(y_true, y_prob, multi_class='ovr')
        
        return metrics
    
    @staticmethod
    def calculate_options_metrics(predictions: pd.DataFrame, 
                                actuals: pd.DataFrame) -> Dict[str, float]:
        """Calculate options-specific metrics"""
        metrics = {}
        
        # Greeks accuracy
        for greek in ['delta', 'gamma', 'vega', 'theta', 'rho']:
            if greek in predictions.columns and greek in actuals.columns:
                mae = mean_absolute_error(actuals[greek], predictions[greek])
                metrics[f'{greek}_mae'] = mae
                
                # Relative error
                mask = actuals[greek] != 0
                if mask.any():
                    rel_error = np.mean(np.abs())
                        (actuals[greek][mask] - predictions[greek][mask]) / actuals[greek][mask]
                    ))
                    metrics[f'{greek}_relative_error'] = rel_error
        
        # IV metrics
        if 'implied_volatility' in predictions.columns and 'implied_volatility' in actuals.columns:
            metrics['iv_rmse'] = np.sqrt(mean_squared_error())
                actuals['implied_volatility'], 
                predictions['implied_volatility']
            ))
            metrics['iv_mae'] = mean_absolute_error()
                actuals['implied_volatility'], 
                predictions['implied_volatility']
            )
        
        # Option price accuracy
        if 'option_price' in predictions.columns and 'option_price' in actuals.columns:
            metrics['price_rmse'] = np.sqrt(mean_squared_error())
                actuals['option_price'], 
                predictions['option_price']
            ))
            metrics['price_mae'] = mean_absolute_error()
                actuals['option_price'], 
                predictions['option_price']
            )
        
        return metrics
    
    @staticmethod
    def calculate_execution_metrics(executions: pd.DataFrame) -> Dict[str, float]:
        """Calculate execution quality metrics"""
        metrics = {}
        
        if 'slippage' in executions.columns:
            metrics['avg_slippage'] = executions['slippage'].mean()
            metrics['total_slippage'] = executions['slippage'].sum()
            metrics['slippage_std'] = executions['slippage'].std()
        
        if 'market_impact' in executions.columns:
            metrics['avg_market_impact'] = executions['market_impact'].mean()
            metrics['total_market_impact'] = executions['market_impact'].sum()
        
        if 'implementation_shortfall' in executions.columns:
            metrics['avg_implementation_shortfall'] = executions['implementation_shortfall'].mean()
            metrics['total_implementation_shortfall'] = executions['implementation_shortfall'].sum()
        
        # Fill rate
        if 'filled_quantity' in executions.columns and 'requested_quantity' in executions.columns:
            metrics['fill_rate'] = ()
                executions['filled_quantity'].sum() / 
                executions['requested_quantity'].sum()
            )
        
        return metrics


class StatisticalAnalyzer:
    """Statistical analysis for model evaluation"""
    
    @staticmethod
    def calculate_confidence_intervals(data: np.ndarray, 
                                     confidence: float = 0.95,
                                     method: str = 'bootstrap') -> Tuple[float, float]:
        """Calculate confidence intervals"""
        if method == 'bootstrap':
            # Bootstrap confidence intervals
            n_bootstrap = 10000
            bootstrap_samples = []
            
            for _ in range(n_bootstrap):
                sample = np.random.choice(data, size=len(data), replace=True)
                bootstrap_samples.append(np.mean(sample))
            
            alpha = 1 - confidence
            lower = np.percentile(bootstrap_samples, alpha/2 * 100)
            upper = np.percentile(bootstrap_samples, (1 - alpha/2) * 100)
            
        elif method == 'normal':
            # Normal approximation
            mean = np.mean(data)
            std_error = stats.sem(data)
            margin = std_error * stats.t.ppf((1 + confidence) / 2, len(data) - 1)
            lower = mean - margin
            upper = mean + margin
            
        else:
            raise ValueError(f"Unknown method: {method}")
        
        return lower, upper
    
    @staticmethod
    def test_statistical_significance(sample1: np.ndarray, 
                                    sample2: np.ndarray,
                                    test_type: str = 'auto') -> Dict[str, float]:
        """Test statistical significance between two samples"""
        results = {}
        
        # Normality test
        _, p1_normal = shapiro(sample1) if len(sample1) > 3 else (None, 0)
        _, p2_normal = shapiro(sample2) if len(sample2) > 3 else (None, 0)
        
        is_normal = p1_normal > 0.05 and p2_normal > 0.05
        
        if test_type == 'auto':
            test_type = 'parametric' if is_normal else 'non-parametric'
        
        if test_type == 'parametric':
            # T-test
            t_stat, p_value = stats.ttest_ind(sample1, sample2)
            results['test_name'] = 't-test'
            results['statistic'] = t_stat
            results['p_value'] = p_value
            
            # Effect size (Cohen's d)
            pooled_std = np.sqrt(())
                (len(sample1) - 1) * np.var(sample1, ddof=1) + 
                (len(sample2) - 1) * np.var(sample2, ddof=1)
            ) / (len(sample1) + len(sample2) - 2))
            
            effect_size = (np.mean(sample1) - np.mean(sample2)) / pooled_std if pooled_std > 0 else 0
            results['effect_size'] = effect_size
            
        else:
            # Mann-Whitney U test
            u_stat, p_value = mannwhitneyu(sample1, sample2, alternative='two-sided')
            results['test_name'] = 'mann-whitney'
            results['statistic'] = u_stat
            results['p_value'] = p_value
            
            # Effect size (rank-biserial correlation)
            n1, n2 = len(sample1), len(sample2)
            effect_size = 1 - (2 * u_stat) / (n1 * n2)
            results['effect_size'] = effect_size
        
        # Power analysis
        if test_type == 'parametric':
            power_analysis = TTestPower()
            results['statistical_power'] = power_analysis.solve_power()
                effect_size=abs(effect_size),
                nobs1=len(sample1),
                ratio=len(sample2)/len(sample1),
                alpha=0.05
            )
        
        return results
    
    @staticmethod
    def analyze_time_series(series: pd.Series) -> Dict[str, Any]:
        """Analyze time series properties"""
        results = {}
        
        # Stationarity test (Augmented Dickey-Fuller)
        adf_result = adfuller(series.dropna())
        results['adf_statistic'] = adf_result[0]
        results['adf_pvalue'] = adf_result[1]
        results['is_stationary'] = adf_result[1] < 0.05
        
        # Autocorrelation
        acf_values = acf(series.dropna(), nlags=20)
        pacf_values = pacf(series.dropna(), nlags=20)
        
        # Find significant lags
        significant_lags = []
        confidence_interval = 1.96 / np.sqrt(len(series))
        
        for i, val in enumerate(acf_values[1:], 1):
            if abs(val) > confidence_interval:
                significant_lags.append(i)
        
        results['significant_lags'] = significant_lags
        results['has_autocorrelation'] = len(significant_lags) > 0
        
        # Seasonality detection (simplified)
        if len(series) > 100:
            # Use FFT for frequency analysis
            fft = np.fft.fft(series.dropna())
            frequencies = np.fft.fftfreq(len(series))
            
            # Find dominant frequencies
            power = np.abs(fft) ** 2
            dominant_freq_idx = np.argmax(power[1:len(power)//2]) + 1
            dominant_period = 1 / frequencies[dominant_freq_idx] if frequencies[dominant_freq_idx] != 0 else 0
            
            results['dominant_period'] = abs(dominant_period)
            results['has_seasonality'] = dominant_period > 1 and dominant_period < len(series) / 2
        
        return results


class ModelComparator:
    """Compare multiple models"""
    
    def __init__(self):
        self.comparison_results = {}
        
    def compare_models(self, 
                      model_results: Dict[str, pd.DataFrame],
                      metrics_to_compare: List[str] = None) -> pd.DataFrame:
        """Compare multiple models on various metrics"""
        
        if metrics_to_compare is None:
            metrics_to_compare = []
                'sharpe_ratio', 'total_return', 'max_drawdown',
                'win_rate', 'accuracy', 'f1_score'
            ]
        
        comparison_df = pd.DataFrame(index=model_results.keys(), columns=metrics_to_compare)
        
        calculator = MetricsCalculator()
        
        for model_name, results in model_results.items():
            # Calculate returns if not present
            if 'returns' in results.columns:
                returns = results['returns']
            elif 'pnl' in results.columns:
                returns = results['pnl'].pct_change().dropna()
            else:
                continue
            
            # Trading metrics
            trading_metrics = calculator.calculate_trading_metrics(returns)
            
            for metric in metrics_to_compare:
                if metric in trading_metrics:
                    comparison_df.loc[model_name, metric] = trading_metrics[metric]
        
        return comparison_df
    
    def calculate_dominance(self, 
                          comparison_df: pd.DataFrame,
                          higher_is_better: Dict[str, bool] = None) -> Dict[str, Any]:
        """Calculate Pareto dominance between models"""
        
        if higher_is_better is None:
            higher_is_better = {}
                'sharpe_ratio': True,
                'total_return': True,
                'max_drawdown': False,
                'win_rate': True,
                'accuracy': True,
                'f1_score': True
            }
        
        models = comparison_df.index.tolist()
        dominance_matrix = pd.DataFrame(False, index=models, columns=models)
        
        for i, model1 in enumerate(models):
            for j, model2 in enumerate(models):
                if i == j:
                    continue
                
                # Check if model1 dominates model2
                dominates = True
                at_least_one_better = False
                
                for metric in comparison_df.columns:
                    val1 = comparison_df.loc[model1, metric]
                    val2 = comparison_df.loc[model2, metric]
                    
                    if pd.isna(val1) or pd.isna(val2):
                        dominates = False
                        break
                    
                    if higher_is_better.get(metric, True):
                        if val1 < val2:
                            dominates = False
                            break
                        elif val1 > val2:
                            at_least_one_better = True
                    else:
                        if val1 > val2:
                            dominates = False
                            break
                        elif val1 < val2:
                            at_least_one_better = True
                
                if dominates and at_least_one_better:
                    dominance_matrix.loc[model1, model2] = True
        
        # Find Pareto optimal models
        pareto_optimal = []
        for model in models:
            if not dominance_matrix[model].any():
                pareto_optimal.append(model)
        
        return {}
            'dominance_matrix': dominance_matrix,
            'pareto_optimal': pareto_optimal,
            'dominated_models': [m for m in models if m not in pareto_optimal]
        }


class TemporalAnalyzer:
    """Analyze model performance over time"""
    
    @staticmethod
    def calculate_rolling_metrics(predictions: pd.DataFrame,
                                window: int = 252,
                                step: int = 1) -> pd.DataFrame:
        """Calculate rolling performance metrics"""
        
        calculator = MetricsCalculator()
        rolling_metrics = []
        
        for i in range(window, len(predictions), step):
            window_data = predictions.iloc[i-window:i]
            
            if 'returns' in window_data.columns:
                returns = window_data['returns']
                metrics = calculator.calculate_trading_metrics(returns)
                metrics['end_date'] = window_data.index[-1]
                rolling_metrics.append(metrics)
        
        return pd.DataFrame(rolling_metrics)
    
    @staticmethod
    def detect_regime_changes(returns: pd.Series,
                            method: str = 'hmm',
                            n_regimes: int = 2) -> Dict[str, Any]:
        """Detect regime changes in returns"""
        
        if method == 'hmm':
            # Hidden Markov Model for regime detection
            model = sm.tsa.MarkovRegression()
                returns.dropna(),
                k_regimes=n_regimes,
                switching_variance=True
            )
            
            try:
                results = model.fit()
                
                return {}
                    'regimes': results.smoothed_marginal_probabilities,
                    'regime_means': [results.params[f'regime{i}'] for i in range(n_regimes)],
                    'regime_volatilities': [np.sqrt(results.params[f'sigma2_regime{i}']) 
                                          for i in range(n_regimes)],
                    'transition_matrix': results.regime_transition
                }
            except:
                logger.warning("HMM fitting failed, using simple volatility regimes")
        
        # Fallback: Simple volatility-based regimes
        vol = returns.rolling(window=20).std()
        vol_percentiles = vol.quantile([0.33, 0.67])
        
        regimes = pd.Series(index=returns.index)
        regimes[vol <= vol_percentiles[0.33]] = 0  # Low volatility
        regimes[(vol > vol_percentiles[0.33]) & (vol <= vol_percentiles[0.67])] = 1  # Medium
        regimes[vol > vol_percentiles[0.67]] = 2  # High volatility
        
        return {}
            'regimes': regimes,
            'regime_names': ['Low Vol', 'Medium Vol', 'High Vol']
        }
    
    @staticmethod
    def analyze_performance_decay(metrics_over_time: pd.DataFrame,
                                metric_name: str = 'sharpe_ratio') -> Dict[str, float]:
        """Analyze performance decay over time"""
        
        if metric_name not in metrics_over_time.columns:
            return {}
        
        values = metrics_over_time[metric_name].values
        time_index = np.arange(len(values))
        
        # Fit exponential decay
        def exp_decay(t, a, b, c):
            return a * np.exp(-b * t) + c
        
        try:
            from scipy.optimize import curve_fit
            popt, _ = curve_fit(exp_decay, time_index, values, maxfev=5000)
            
            half_life = np.log(2) / popt[1] if popt[1] > 0 else np.inf
            
            return {}
                'decay_rate': popt[1],
                'half_life': half_life,
                'asymptotic_value': popt[2],
                'initial_value': popt[0] + popt[2]
            }
        except:
            # Linear decay fallback
            slope, intercept = np.polyfit(time_index, values, 1)
            
            return {}
                'decay_rate': -slope,
                'linear_slope': slope,
                'projected_zero': -intercept / slope if slope != 0 else np.inf
            }


class FeatureAnalyzer:
    """Analyze feature importance and behavior"""
    
    def __init__(self, model=None):
        self.model = model
        self.shap_explainer = None
        
    def calculate_feature_importance(self, 
                                   X: pd.DataFrame,
                                   y: pd.Series,
                                   method: str = 'permutation') -> pd.DataFrame:
        """Calculate feature importance"""
        
        if method == 'shap' and self.model is not None:
            # SHAP values
            if self.shap_explainer is None:
                self.shap_explainer = shap.Explainer(self.model, X)
            
            shap_values = self.shap_explainer(X)
            
            importance_df = pd.DataFrame({)
                'feature': X.columns,
                'importance': np.abs(shap_values.values).mean(axis=0),
                'std': np.abs(shap_values.values).std(axis=0)
            })
            
        elif method == 'permutation':
            # Permutation importance
            from sklearn.inspection import permutation_importance
            
            if self.model is None:
                # Use a default model
                from sklearn.ensemble import RandomForestRegressor
                self.model = RandomForestRegressor(n_estimators=100, random_state=42)
                self.model.fit(X, y)
            
            result = permutation_importance(self.model, X, y, n_repeats=10)
            
            importance_df = pd.DataFrame({)
                'feature': X.columns,
                'importance': result.importances_mean,
                'std': result.importances_std
            })
            
        else:
            # Model-based importance (if available)
            if hasattr(self.model, 'feature_importances_'):
                importance_df = pd.DataFrame({)
                    'feature': X.columns,
                    'importance': self.model.feature_importances_
                })
            else:
                raise ValueError(f"Method {method} not available")
        
        return importance_df.sort_values('importance', ascending=False)
    
    def analyze_feature_stability(self,
                                feature_importance_history: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """Analyze feature importance stability over time"""
        
        all_features = set()
        for df in feature_importance_history.values():
            all_features.update(df['feature'].values)
        
        stability_results = []
        
        for feature in all_features:
            importances = []
            dates = []
            
            for date, df in feature_importance_history.items():
                if feature in df['feature'].values:
                    imp = df[df['feature'] == feature]['importance'].iloc[0]
                    importances.append(imp)
                    dates.append(date)
            
            if len(importances) > 1:
                stability_results.append({)
                    'feature': feature,
                    'mean_importance': np.mean(importances),
                    'std_importance': np.std(importances),
                    'cv_importance': np.std(importances) / np.mean(importances) if np.mean(importances) > 0 else np.inf,
                    'trend': np.polyfit(range(len(importances)), importances, 1)[0] if len(importances) > 2 else 0,
                    'n_periods': len(importances)
                })
        
        return pd.DataFrame(stability_results).sort_values('cv_importance')


class ErrorAnalyzer:
    """Analyze prediction errors"""
    
    @staticmethod
    def analyze_error_distribution(errors: np.ndarray) -> Dict[str, Any]:
        """Analyze error distribution"""
        
        results = {}
            'mean': np.mean(errors),
            'median': np.median(errors),
            'std': np.std(errors),
            'skew': stats.skew(errors),
            'kurtosis': stats.kurtosis(errors),
            'percentiles': {}
                '1%': np.percentile(errors, 1),
                '5%': np.percentile(errors, 5),
                '25%': np.percentile(errors, 25),
                '75%': np.percentile(errors, 75),
                '95%': np.percentile(errors, 95),
                '99%': np.percentile(errors, 99)
            }
        }
        
        # Normality test
        if len(errors) > 3:
            _, p_value = shapiro(errors)
            results['is_normal'] = p_value > 0.05
            results['normality_pvalue'] = p_value
        
        # Bias detection
        t_stat, p_value = stats.ttest_1samp(errors, 0)
        results['has_bias'] = p_value < 0.05
        results['bias_pvalue'] = p_value
        results['bias_direction'] = 'positive' if np.mean(errors) > 0 else 'negative'
        
        return results
    
    @staticmethod
    def cluster_errors(errors_df: pd.DataFrame,
                      features: List[str],
                      n_clusters: int = 5) -> Dict[str, Any]:
        """Cluster errors to find patterns"""
        
        from sklearn.cluster import KMeans
        from sklearn.preprocessing import StandardScaler
        
        # Prepare data
        X = errors_df[features].fillna(0)
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Cluster
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        clusters = kmeans.fit_predict(X_scaled)
        
        # Analyze clusters
        errors_df['cluster'] = clusters
        cluster_stats = []
        
        for i in range(n_clusters):
            cluster_data = errors_df[errors_df['cluster'] == i]
            
            stats = {}
                'cluster': i,
                'size': len(cluster_data),
                'mean_error': cluster_data['error'].mean(),
                'std_error': cluster_data['error'].std(),
                'worst_error': cluster_data['error'].abs().max()
            }
            
            # Feature means for this cluster
            for feature in features:
                stats[f'{feature}_mean'] = cluster_data[feature].mean()
            
            cluster_stats.append(stats)
        
        return {}
            'cluster_assignments': clusters,
            'cluster_stats': pd.DataFrame(cluster_stats),
            'cluster_centers': scaler.inverse_transform(kmeans.cluster_centers_)
        }


class VisualizationEngine:
    """Create comprehensive visualizations"""
    
    def __init__(self, style: str = 'seaborn'):
        plt.style.use(style)
        self.colors = px.colors.qualitative.Plotly
        
    def create_performance_tearsheet(self, 
                                   performance_data: Dict[str, Any],
                                   save_path: Optional[str] = None) -> go.Figure:
        """Create comprehensive performance tearsheet"""
        
        fig = make_subplots()
            rows=3, cols=2,
            subplot_titles=()
                'Cumulative Returns', 'Rolling Sharpe Ratio',
                'Drawdown', 'Monthly Returns Heatmap',
                'Return Distribution', 'Risk Metrics'
            ),
            vertical_spacing=0.1,
            horizontal_spacing=0.1
        )
        
        # 1. Cumulative returns
        if 'cumulative_returns' in performance_data:
            fig.add_trace()
                go.Scatter()
                    x=performance_data['dates'],
                    y=performance_data['cumulative_returns'],
                    mode='lines',
                    name='Strategy',
                    line=dict(color=self.colors[0])
                ),
                row=1, col=1
            )
            
            if 'benchmark_returns' in performance_data:
                fig.add_trace()
                    go.Scatter()
                        x=performance_data['dates'],
                        y=performance_data['benchmark_returns'],
                        mode='lines',
                        name='Benchmark',
                        line=dict(color=self.colors[1], dash='dash')
                    ),
                    row=1, col=1
                )
        
        # 2. Rolling Sharpe
        if 'rolling_sharpe' in performance_data:
            fig.add_trace()
                go.Scatter()
                    x=performance_data['dates'],
                    y=performance_data['rolling_sharpe'],
                    mode='lines',
                    name='Sharpe Ratio',
                    line=dict(color=self.colors[2])
                ),
                row=1, col=2
            )
            
            # Add zero line
            fig.add_hline(y=0, line_dash="dash", line_color="gray", row=1, col=2)
        
        # 3. Drawdown
        if 'drawdown' in performance_data:
            fig.add_trace()
                go.Scatter()
                    x=performance_data['dates'],
                    y=performance_data['drawdown'] * 100,
                    mode='lines',
                    fill='tozeroy',
                    name='Drawdown',
                    line=dict(color=self.colors[3])
                ),
                row=2, col=1
            )
        
        # 4. Monthly returns heatmap
        if 'monthly_returns' in performance_data:
            monthly_data = performance_data['monthly_returns']
            
            fig.add_trace()
                go.Heatmap()
                    z=monthly_data.values,
                    x=monthly_data.columns,
                    y=monthly_data.index,
                    colorscale='RdYlGn',
                    zmid=0,
                    text=monthly_data.values.round(2),
                    texttemplate='%{text}%',
                    showscale=False
                ),
                row=2, col=2
            )
        
        # 5. Return distribution
        if 'returns' in performance_data:
            returns = performance_data['returns']
            
            fig.add_trace()
                go.Histogram()
                    x=returns,
                    nbinsx=50,
                    name='Returns',
                    marker_color=self.colors[4],
                    opacity=0.7
                ),
                row=3, col=1
            )
            
            # Add normal distribution overlay
            x_range = np.linspace(returns.min(), returns.max(), 100)
            normal_dist = stats.norm.pdf(x_range, returns.mean(), returns.std())
            
            fig.add_trace()
                go.Scatter()
                    x=x_range,
                    y=normal_dist * len(returns) * (returns.max() - returns.min()) / 50,
                    mode='lines',
                    name='Normal',
                    line=dict(color='red', dash='dash')
                ),
                row=3, col=1
            )
        
        # 6. Risk metrics radar
        if 'risk_metrics' in performance_data:
            metrics = performance_data['risk_metrics']
            
            fig.add_trace()
                go.Scatterpolar()
                    r=list(metrics.values()),
                    theta=list(metrics.keys()),
                    fill='toself',
                    name='Risk Profile'
                ),
                row=3, col=2
            )
        
        # Update layout
        fig.update_layout()
            title='Model Performance Tearsheet',
            showlegend=True,
            height=1200,
            width=1600
        )
        
        if save_path:
            fig.write_html(save_path)
            
        return fig
    
    def create_model_comparison_chart(self,
                                    comparison_data: pd.DataFrame,
                                    metrics: List[str],
                                    save_path: Optional[str] = None) -> go.Figure:
        """Create model comparison visualization"""
        
        fig = go.Figure()
        
        # Normalize metrics for radar chart
        normalized_data = comparison_data[metrics].copy()
        for col in metrics:
            max_val = normalized_data[col].max()
            if max_val > 0:
                normalized_data[col] = normalized_data[col] / max_val
        
        # Add trace for each model
        for i, model in enumerate(comparison_data.index):
            fig.add_trace()
                go.Scatterpolar()
                    r=normalized_data.loc[model].values,
                    theta=metrics,
                    fill='toself',
                    name=model,
                    line=dict(color=self.colors[i % len(self.colors)])
                )
            )
        
        fig.update_layout()
            title='Model Comparison Radar Chart',
            polar=dict()
                radialaxis=dict()
                    visible=True,
                    range=[0, 1]
                )
            ),
            showlegend=True,
            height=600,
            width=800
        )
        
        if save_path:
            fig.write_html(save_path)
            
        return fig
    
    def create_feature_importance_plot(self,
                                     feature_importance: pd.DataFrame,
                                     top_n: int = 20,
                                     save_path: Optional[str] = None) -> go.Figure:
        """Create feature importance visualization"""
        
        # Get top features
        top_features = feature_importance.nlargest(top_n, 'importance')
        
        fig = go.Figure()
        
        fig.add_trace()
            go.Bar()
                x=top_features['importance'],
                y=top_features['feature'],
                orientation='h',
                marker_color=self.colors[0],
                error_x=dict()
                    type='data',
                    array=top_features.get('std', 0),
                    visible=True
                ) if 'std' in top_features.columns else None
            )
        )
        
        fig.update_layout()
            title=f'Top {top_n} Feature Importances',
            xaxis_title='Importance',
            yaxis_title='Feature',
            height=max(400, top_n * 30),
            width=800,
            yaxis=dict(autorange="reversed")
        )
        
        if save_path:
            fig.write_html(save_path)
            
        return fig
    
    def create_error_analysis_dashboard(self,
                                      error_data: Dict[str, Any],
                                      save_path: Optional[str] = None) -> go.Figure:
        """Create error analysis dashboard"""
        
        fig = make_subplots()
            rows=2, cols=2,
            subplot_titles=()
                'Error Distribution', 'Errors Over Time',
                'Error vs Predicted', 'Error Heatmap by Features'
            )
        )
        
        # 1. Error distribution
        if 'errors' in error_data:
            errors = error_data['errors']
            
            fig.add_trace()
                go.Histogram()
                    x=errors,
                    nbinsx=50,
                    name='Errors',
                    marker_color=self.colors[0]
                ),
                row=1, col=1
            )
        
        # 2. Errors over time
        if 'error_timeline' in error_data:
            timeline = error_data['error_timeline']
            
            fig.add_trace()
                go.Scatter()
                    x=timeline['date'],
                    y=timeline['error'],
                    mode='markers',
                    marker=dict()
                        size=5,
                        color=timeline['error'].abs(),
                        colorscale='Viridis',
                        showscale=True
                    ),
                    name='Errors'
                ),
                row=1, col=2
            )
        
        # 3. Error vs Predicted
        if 'predictions' in error_data and 'errors' in error_data:
            fig.add_trace()
                go.Scatter()
                    x=error_data['predictions'],
                    y=error_data['errors'],
                    mode='markers',
                    marker=dict()
                        size=5,
                        color=self.colors[2],
                        opacity=0.6
                    ),
                    name='Error vs Predicted'
                ),
                row=2, col=1
            )
            
            # Add zero line
            fig.add_hline(y=0, line_dash="dash", line_color="gray", row=2, col=1)
        
        # 4. Error heatmap
        if 'error_heatmap' in error_data:
            heatmap_data = error_data['error_heatmap']
            
            fig.add_trace()
                go.Heatmap()
                    z=heatmap_data['values'],
                    x=heatmap_data['x_labels'],
                    y=heatmap_data['y_labels'],
                    colorscale='RdBu',
                    zmid=0
                ),
                row=2, col=2
            )
        
        fig.update_layout()
            title='Error Analysis Dashboard',
            showlegend=True,
            height=800,
            width=1200
        )
        
        if save_path:
            fig.write_html(save_path)
            
        return fig


class ModelPerformanceEvaluator:
    """Main class for comprehensive model evaluation"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.calculator = MetricsCalculator()
        self.stat_analyzer = StatisticalAnalyzer()
        self.comparator = ModelComparator()
        self.temporal_analyzer = TemporalAnalyzer()
        self.feature_analyzer = FeatureAnalyzer()
        self.error_analyzer = ErrorAnalyzer()
        self.viz_engine = VisualizationEngine()
        
        # Storage for results
        self.evaluation_results = {}
        self.model_registry = {}
        
    @handle_errors("model_evaluation", ErrorCategory.BUSINESS, ErrorSeverity.MEDIUM)
    def evaluate_model(self,
                      model_id: str,
                      predictions: pd.DataFrame,
                      actuals: pd.DataFrame,
                      model_type: str = 'trading',
                      additional_data: Optional[Dict[str, Any]] = None) -> PerformanceMetrics:
        """Comprehensive model evaluation"""
        
        logger.info(f"Evaluating model: {model_id}")
        
        # Initialize metrics
        metrics = PerformanceMetrics()
        
        # Calculate returns if needed
        if 'returns' not in predictions.columns:
            if 'pnl' in predictions.columns:
                predictions['returns'] = predictions['pnl'].pct_change().fillna(0)
            elif 'position' in predictions.columns and 'price_change' in actuals.columns:
                predictions['returns'] = predictions['position'].shift(1) * actuals['price_change']
        
        # Trading metrics
        if 'returns' in predictions.columns:
            trading_metrics = self.calculator.calculate_trading_metrics(predictions['returns'])
            for key, value in trading_metrics.items():
                if hasattr(metrics, key):
                    setattr(metrics, key, value)
        
        # Risk metrics
        if 'returns' in predictions.columns:
            risk_metrics = self.calculator.calculate_risk_metrics(predictions['returns'])
            for key, value in risk_metrics.items():
                if hasattr(metrics, key):
                    setattr(metrics, key, value)
        
        # ML metrics
        if model_type in ['ml', 'classification', 'regression']:
            task_type = 'classification' if model_type == 'classification' else 'regression'
            
            if 'y_true' in actuals.columns and 'y_pred' in predictions.columns:
                ml_metrics = self.calculator.calculate_ml_metrics()
                    actuals['y_true'].values,
                    predictions['y_pred'].values,
                    task_type=task_type,
                    y_prob=predictions.get('y_prob', None)
                )
                
                for key, value in ml_metrics.items():
                    if hasattr(metrics, key):
                        setattr(metrics, key, value)
        
        # Options metrics
        if model_type == 'options':
            options_metrics = self.calculator.calculate_options_metrics(predictions, actuals)
            for key, value in options_metrics.items():
                if hasattr(metrics, key):
                    setattr(metrics, key, value)
        
        # Execution metrics
        if 'executions' in additional_data:
            exec_metrics = self.calculator.calculate_execution_metrics(additional_data['executions'])
            for key, value in exec_metrics.items():
                if hasattr(metrics, key):
                    setattr(metrics, key, value)
        
        # Calculate confidence intervals
        if 'returns' in predictions.columns:
            returns_array = predictions['returns'].values
            
            # Sharpe ratio confidence interval
            sharpe_ci = self.stat_analyzer.calculate_confidence_intervals()
                returns_array / returns_array.std() if returns_array.std() > 0 else returns_array
            )
            metrics.confidence_intervals['sharpe_ratio'] = sharpe_ci
            
            # Return confidence interval
            return_ci = self.stat_analyzer.calculate_confidence_intervals(returns_array)
            metrics.confidence_intervals['daily_return'] = return_ci
        
        # Store results
        self.evaluation_results[model_id] = {}
            'metrics': metrics,
            'predictions': predictions,
            'actuals': actuals,
            'timestamp': datetime.now()
        }
        
        return metrics
    
    def compare_models(self,
                      model_ids: List[str],
                      comparison_metrics: Optional[List[str]] = None) -> Dict[str, Any]:
        """Compare multiple models"""
        
        # Gather model results
        model_results = {}
        for model_id in model_ids:
            if model_id in self.evaluation_results:
                model_results[model_id] = self.evaluation_results[model_id]['predictions']
        
        # Compare models
        comparison_df = self.comparator.compare_models(model_results, comparison_metrics)
        
        # Statistical significance testing
        significance_results = {}
        
        if len(model_ids) == 2 and all(mid in self.evaluation_results for mid in model_ids):
            # Pairwise comparison
            returns1 = self.evaluation_results[model_ids[0]]['predictions']['returns'].values
            returns2 = self.evaluation_results[model_ids[1]]['predictions']['returns'].values
            
            significance_results = self.stat_analyzer.test_statistical_significance()
                returns1, returns2
            )
        
        # Dominance analysis
        dominance_results = self.comparator.calculate_dominance(comparison_df)
        
        return {}
            'comparison_table': comparison_df,
            'statistical_significance': significance_results,
            'dominance_analysis': dominance_results,
            'best_model': comparison_df.index[comparison_df['sharpe_ratio'].argmax()]
            if 'sharpe_ratio' in comparison_df.columns else None
        }
    
    def analyze_temporal_performance(self,
                                   model_id: str,
                                   window: int = 252,
                                   step: int = 21) -> Dict[str, Any]:
        """Analyze model performance over time"""
        
        if model_id not in self.evaluation_results:
            raise ValueError(f"Model {model_id} not found in evaluation results")
        
        predictions = self.evaluation_results[model_id]['predictions']
        
        # Rolling metrics
        rolling_metrics = self.temporal_analyzer.calculate_rolling_metrics()
            predictions, window, step
        )
        
        # Regime analysis
        if 'returns' in predictions.columns:
            regime_results = self.temporal_analyzer.detect_regime_changes()
                predictions['returns']
            )
        else:
            regime_results = {}
        
        # Performance decay
        if len(rolling_metrics) > 10:
            decay_analysis = self.temporal_analyzer.analyze_performance_decay()
                rolling_metrics, 'sharpe_ratio'
            )
        else:
            decay_analysis = {}
        
        return {}
            'rolling_metrics': rolling_metrics,
            'regime_analysis': regime_results,
            'performance_decay': decay_analysis
        }
    
    def analyze_features(self,
                       model_id: str,
                       feature_data: pd.DataFrame,
                       target: pd.Series,
                       model_object: Optional[Any] = None) -> Dict[str, Any]:
        """Analyze feature importance and behavior"""
        
        if model_object:
            self.feature_analyzer.model = model_object
        
        # Feature importance
        importance_df = self.feature_analyzer.calculate_feature_importance()
            feature_data, target, method='permutation'
        )
        
        # Feature stability (if historical importance available)
        stability_df = None
        if hasattr(self, 'feature_importance_history'):
            stability_df = self.feature_analyzer.analyze_feature_stability()
                self.feature_importance_history
            )
        
        return {}
            'feature_importance': importance_df,
            'feature_stability': stability_df,
            'top_features': importance_df.head(10)['feature'].tolist()
        }
    
    def analyze_errors(self,
                     model_id: str,
                     feature_data: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """Analyze prediction errors"""
        
        if model_id not in self.evaluation_results:
            raise ValueError(f"Model {model_id} not found in evaluation results")
        
        predictions = self.evaluation_results[model_id]['predictions']
        actuals = self.evaluation_results[model_id]['actuals']
        
        # Calculate errors
        if 'y_pred' in predictions.columns and 'y_true' in actuals.columns:
            errors = actuals['y_true'] - predictions['y_pred']
        elif 'returns' in predictions.columns and 'returns' in actuals.columns:
            errors = actuals['returns'] - predictions['returns']
        else:
            return {}
        
        # Error distribution analysis
        error_dist = self.error_analyzer.analyze_error_distribution(errors.values)
        
        # Error clustering
        cluster_results = None
        if feature_data is not None and len(feature_data.columns) > 0:
            errors_df = pd.DataFrame({)
                'error': errors,
                **feature_data
            })
            
            # Select numeric features only
            numeric_features = feature_data.select_dtypes(include=[np.number]).columns.tolist()
            
            if numeric_features:
                cluster_results = self.error_analyzer.cluster_errors()
                    errors_df, numeric_features, n_clusters=5
                )
        
        return {}
            'error_distribution': error_dist,
            'error_clustering': cluster_results,
            'mean_absolute_error': np.mean(np.abs(errors)),
            'root_mean_squared_error': np.sqrt(np.mean(errors**2))
        }
    
    def generate_report(self,
                       model_id: str,
                       output_path: str,
                       include_sections: Optional[List[str]] = None) -> str:
        """Generate comprehensive evaluation report"""
        
        if include_sections is None:
            include_sections = []
                'summary', 'performance', 'risk', 'temporal',
                'features', 'errors', 'visualizations'
            ]
        
        logger.info(f"Generating report for model: {model_id}")
        
        # Create PDF
        pdf_path = output_path.replace('.html', '.pdf')
        pdf = pdf_backend.PdfPages(pdf_path)
        
        # Title page
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.text(0.5, 0.7, f'Model Performance Report', 
                ha='center', va='center', fontsize=24, weight='bold')
        ax.text(0.5, 0.6, f'Model ID: {model_id}', 
                ha='center', va='center', fontsize=16)
        ax.text(0.5, 0.5, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', 
                ha='center', va='center', fontsize=12)
        ax.axis('off')
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
        
        # Performance section
        if 'performance' in include_sections and model_id in self.evaluation_results:
            metrics = self.evaluation_results[model_id]['metrics']
            
            # Metrics table
            fig, ax = plt.subplots(figsize=(8.5, 11))
            ax.axis('tight')
            ax.axis('off')
            
            # Create metrics table
            table_data = []
            for attr in ['sharpe_ratio', 'total_return', 'max_drawdown', 'win_rate']:
                if hasattr(metrics, attr):
                    value = getattr(metrics, attr)
                    table_data.append([attr.replace('_', ' ').title(), f"{value:.4f}"])
            
            table = ax.table(cellText=table_data, 
                           colLabels=['Metric', 'Value'],
                           cellLoc='left',
                           loc='center')
            table.auto_set_font_size(False)
            table.set_fontsize(12)
            
            ax.set_title('Performance Metrics', fontsize=16, weight='bold', pad=20)
            pdf.savefig(fig, bbox_inches='tight')
            plt.close(fig)
        
        # Visualizations
        if 'visualizations' in include_sections:
            # Performance tearsheet
            perf_data = {}
                'returns': self.evaluation_results[model_id]['predictions'].get('returns', pd.Series()),
                'dates': self.evaluation_results[model_id]['predictions'].index
            }
            
            if len(perf_data['returns']) > 0:
                perf_data['cumulative_returns'] = (1 + perf_data['returns']).cumprod()
                perf_data['drawdown'] = self._calculate_drawdown(perf_data['cumulative_returns'])
                perf_data['rolling_sharpe'] = ()
                    perf_data['returns'].rolling(252).mean() / 
                    perf_data['returns'].rolling(252).std() * np.sqrt(252)
                )
            
                # Create matplotlib version of tearsheet
                fig, axes = plt.subplots(2, 2, figsize=(12, 10))
                
                # Cumulative returns
                axes[0, 0].plot(perf_data['dates'], perf_data['cumulative_returns'])
                axes[0, 0].set_title('Cumulative Returns')
                axes[0, 0].grid(True, alpha=0.3)
                
                # Drawdown
                axes[0, 1].fill_between(perf_data['dates'], 0, perf_data['drawdown'] * 100, alpha=0.3)
                axes[0, 1].set_title('Drawdown %')
                axes[0, 1].grid(True, alpha=0.3)
                
                # Returns distribution
                axes[1, 0].hist(perf_data['returns'], bins=50, alpha=0.7)
                axes[1, 0].set_title('Returns Distribution')
                axes[1, 0].grid(True, alpha=0.3)
                
                # Rolling Sharpe
                axes[1, 1].plot(perf_data['dates'], perf_data['rolling_sharpe'])
                axes[1, 1].axhline(y=0, color='r', linestyle='--', alpha=0.5)
                axes[1, 1].set_title('Rolling Sharpe Ratio (252 days)')
                axes[1, 1].grid(True, alpha=0.3)
                
                plt.tight_layout()
                pdf.savefig(fig, bbox_inches='tight')
                plt.close(fig)
        
        # Close PDF
        pdf.close()
        
        # Also create HTML version with interactive plots
        html_content = self._generate_html_report(model_id, include_sections)
        
        with open(output_path, 'w') as f:
            f.write(html_content)
        
        logger.info(f"Report generated: {output_path} and {pdf_path}")
        
        return output_path
    
    def _calculate_drawdown(self, cumulative_returns: pd.Series) -> pd.Series:
        """Calculate drawdown series"""
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        return drawdown
    
    def _generate_html_report(self, model_id: str, sections: List[str]) -> str:
        """Generate HTML report with interactive visualizations"""
        
        html_parts = ["""]
        <!DOCTYPE html>
        <html>
        <head>
            <title>Model Performance Report</title>
            <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                h1 { color: #333; }
                h2 { color: #666; margin-top: 30px; }
                .metric { display: inline-block; margin: 10px 20px; }
                .metric-value { font-size: 24px; font-weight: bold; }
                .metric-label { font-size: 14px; color: #666; }
                table { border-collapse: collapse; width: 100%; margin: 20px 0; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
            </style>
        </head>
        <body>
        """]
        
        # Title
        html_parts.append(f""")
        <h1>Model Performance Report</h1>
        <p><strong>Model ID:</strong> {model_id}</p>
        <p><strong>Generated:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M")}</p>
        """)
        
        # Summary metrics
        if 'summary' in sections and model_id in self.evaluation_results:
            metrics = self.evaluation_results[model_id]['metrics']
            
            html_parts.append("<h2>Summary Metrics</h2>")
            html_parts.append('<div class="metrics-container">')
            
            key_metrics = []
                ('Sharpe Ratio', metrics.sharpe_ratio, '.3f'),
                ('Total Return', metrics.total_return * 100, '.2f', '%'),
                ('Max Drawdown', metrics.max_drawdown * 100, '.2f', '%'),
                ('Win Rate', metrics.win_rate * 100, '.1f', '%')
            ]
            
            for label, value, fmt, *suffix in key_metrics:
                suffix_str = suffix[0] if suffix else ''
                html_parts.append(f''')
                <div class="metric">
                    <div class="metric-value">{value:{fmt}}{suffix_str}</div>
                    <div class="metric-label">{label}</div>
                </div>
                ''')
            
            html_parts.append('</div>')
        
        # Performance visualization
        if 'visualizations' in sections:
            html_parts.append("<h2>Performance Visualizations</h2>")
            
            # Create performance data
            perf_data = self._prepare_performance_data(model_id)
            
            # Generate Plotly chart
            fig = self.viz_engine.create_performance_tearsheet(perf_data)
            
            # Convert to HTML
            html_parts.append(fig.to_html(full_html=False, include_plotlyjs=False))
        
        # Close HTML
        html_parts.append(""")
        </body>
        </html>
        """)
        
        return '\n'.join(html_parts)
    
    def _prepare_performance_data(self, model_id: str) -> Dict[str, Any]:
        """Prepare performance data for visualization"""
        
        if model_id not in self.evaluation_results:
            return {}
        
        predictions = self.evaluation_results[model_id]['predictions']
        
        # Basic performance data
        perf_data = {}
            'dates': predictions.index,
            'returns': predictions.get('returns', pd.Series())
        }
        
        if len(perf_data['returns']) > 0:
            # Cumulative returns
            perf_data['cumulative_returns'] = (1 + perf_data['returns']).cumprod()
            
            # Drawdown
            perf_data['drawdown'] = self._calculate_drawdown(perf_data['cumulative_returns'])
            
            # Rolling Sharpe
            perf_data['rolling_sharpe'] = ()
                perf_data['returns'].rolling(252).mean() / 
                perf_data['returns'].rolling(252).std() * np.sqrt(252)
            )
            
            # Monthly returns for heatmap
            monthly_returns = perf_data['returns'].resample('M').apply()
                lambda x: (1 + x).prod() - 1
            )
            
            if len(monthly_returns) > 0:
                monthly_pivot = pd.pivot_table()
                    pd.DataFrame({)
                        'returns': monthly_returns.values,
                        'year': monthly_returns.index.year,
                        'month': monthly_returns.index.month
                    }),
                    values='returns',
                    index='year',
                    columns='month'
                ) * 100  # Convert to percentage
                
                perf_data['monthly_returns'] = monthly_pivot
            
            # Risk metrics for radar chart
            metrics = self.evaluation_results[model_id]['metrics']
            perf_data['risk_metrics'] = {}
                'Sharpe': min(metrics.sharpe_ratio, 3),  # Cap for visualization
                'Sortino': min(metrics.sortino_ratio, 3),
                'Calmar': min(metrics.calmar_ratio, 3),
                'Win Rate': metrics.win_rate,
                'Profit Factor': min(metrics.profit_factor, 3)
            }
        
        return perf_data


class RealtimeMonitor:
    """Monitor model performance in real-time"""
    
    def __init__(self, evaluator: ModelPerformanceEvaluator):
        self.evaluator = evaluator
        self.monitoring_tasks = {}
        self.alert_handlers = []
        self.metrics_buffer = defaultdict(list)
        self.alert_thresholds = {}
            'sharpe_drop': 0.5,
            'max_drawdown': 0.2,
            'accuracy_drop': 0.1,
            'consecutive_losses': 5
        }
        
    async def start_monitoring(self, 
                             model_id: str,
                             update_interval: int = 60) -> None:
        """Start real-time monitoring for a model"""
        
        async def monitor_loop():
            consecutive_losses = 0
            baseline_metrics = None
            
            while model_id in self.monitoring_tasks:
                try:
                    # Get latest predictions and actuals
                    latest_data = await self._get_latest_data(model_id)
                    
                    if latest_data:
                        # Evaluate recent performance
                        metrics = self.evaluator.evaluate_model()
                            f"{model_id}_realtime",
                            latest_data['predictions'],
                            latest_data['actuals']
                        )
                        
                        # Store metrics
                        self.metrics_buffer[model_id].append({)
                            'timestamp': datetime.now(),
                            'metrics': metrics
                        })
                        
                        # Set baseline if first run
                        if baseline_metrics is None:
                            baseline_metrics = metrics
                        
                        # Check alerts
                        alerts = self._check_alerts(model_id, metrics, baseline_metrics)
                        
                        if alerts:
                            await self._trigger_alerts(model_id, alerts)
                        
                        # Track consecutive losses
                        if metrics.win_rate < 0.5:
                            consecutive_losses += 1
                        else:
                            consecutive_losses = 0
                    
                    await asyncio.sleep(update_interval)
                    
                except Exception as e:
                    logger.error(f"Error monitoring model {model_id}: {e}")
                    await asyncio.sleep(update_interval)
        
        # Start monitoring task
        task = asyncio.create_task(monitor_loop())
        self.monitoring_tasks[model_id] = task
        
        logger.info(f"Started monitoring for model: {model_id}")
    
    async def stop_monitoring(self, model_id: str) -> None:
        """Stop monitoring a model"""
        
        if model_id in self.monitoring_tasks:
            self.monitoring_tasks[model_id].cancel()
            del self.monitoring_tasks[model_id]
            logger.info(f"Stopped monitoring for model: {model_id}")
    
    def add_alert_handler(self, handler: Callable) -> None:
        """Add alert handler"""
        self.alert_handlers.append(handler)
    
    async def _get_latest_data(self, model_id: str) -> Optional[Dict[str, pd.DataFrame]]:
        """Get latest prediction and actual data"""
        # This would connect to your real-time data source
        # For now, returning None as placeholder
        return None
    
    def _check_alerts(self, 
                     model_id: str,
                     current_metrics: PerformanceMetrics,
                     baseline_metrics: PerformanceMetrics) -> List[Dict[str, Any]]:
        """Check for alert conditions"""
        
        alerts = []
        
        # Sharpe ratio drop
        if baseline_metrics.sharpe_ratio > 0:
            sharpe_drop = (baseline_metrics.sharpe_ratio - current_metrics.sharpe_ratio) / baseline_metrics.sharpe_ratio
            if sharpe_drop > self.alert_thresholds['sharpe_drop']:
                alerts.append({)
                    'type': 'performance_degradation',
                    'metric': 'sharpe_ratio',
                    'severity': 'high',
                    'message': f'Sharpe ratio dropped by {sharpe_drop:.1%}',
                    'current_value': current_metrics.sharpe_ratio,
                    'baseline_value': baseline_metrics.sharpe_ratio
                })
        
        # Max drawdown breach
        if abs(current_metrics.max_drawdown) > self.alert_thresholds['max_drawdown']:
            alerts.append({)
                'type': 'risk_breach',
                'metric': 'max_drawdown',
                'severity': 'critical',
                'message': f'Max drawdown exceeded threshold: {current_metrics.max_drawdown:.1%}',
                'current_value': current_metrics.max_drawdown,
                'threshold': self.alert_thresholds['max_drawdown']
            })
        
        # Accuracy drop (for ML models)
        if current_metrics.accuracy is not None and baseline_metrics.accuracy is not None:
            accuracy_drop = baseline_metrics.accuracy - current_metrics.accuracy
            if accuracy_drop > self.alert_thresholds['accuracy_drop']:
                alerts.append({)
                    'type': 'model_degradation',
                    'metric': 'accuracy',
                    'severity': 'medium',
                    'message': f'Model accuracy dropped by {accuracy_drop:.1%}',
                    'current_value': current_metrics.accuracy,
                    'baseline_value': baseline_metrics.accuracy
                })
        
        return alerts
    
    async def _trigger_alerts(self, model_id: str, alerts: List[Dict[str, Any]]) -> None:
        """Trigger alert handlers"""
        
        for handler in self.alert_handlers:
            for alert in alerts:
                try:
                    await handler(model_id, alert)
                except Exception as e:
                    logger.error(f"Error in alert handler: {e}")


# Integration function for MASTER_PRODUCTION_INTEGRATION.py
def integrate_model_performance_evaluation(master_system) -> Dict[str, Any]:
    """
    Integrate model performance evaluation suite with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from model_performance_evaluation import integrate_model_performance_evaluation
    evaluation_system = integrate_model_performance_evaluation(self)
    """
    
    # Create evaluator instance
    config = {}
        'confidence_level': 0.95,
        'rolling_window': 252,
        'min_sample_size': 30
    }
    
    evaluator = ModelPerformanceEvaluator(config)
    
    # Create real-time monitor
    monitor = RealtimeMonitor(evaluator)
    
    # Integration functions
    def evaluate_model(model_id: str, 
                      predictions_df: pd.DataFrame,
                      actuals_df: pd.DataFrame,
                      model_type: str = 'trading',
                      **kwargs) -> PerformanceMetrics:
        """Evaluate a model's performance"""
        return evaluator.evaluate_model()
            model_id, predictions_df, actuals_df, model_type, kwargs
        )
    
    def compare_models(model_ids: List[str], 
                      metrics: Optional[List[str]] = None) -> Dict[str, Any]:
        """Compare multiple models"""
        return evaluator.compare_models(model_ids, metrics)
    
    def analyze_feature_importance(model_id: str,
                                 feature_data: pd.DataFrame,
                                 target: pd.Series,
                                 model_obj: Optional[Any] = None) -> Dict[str, Any]:
        """Analyze feature importance"""
        return evaluator.analyze_features(model_id, feature_data, target, model_obj)
    
    def generate_performance_report(model_id: str,
                                  output_path: str,
                                  sections: Optional[List[str]] = None) -> str:
        """Generate comprehensive performance report"""
        return evaluator.generate_report(model_id, output_path, sections)
    
    async def start_monitoring(model_id: str, interval: int = 60) -> None:
        """Start real-time monitoring"""
        await monitor.start_monitoring(model_id, interval)
    
    async def stop_monitoring(model_id: str) -> None:
        """Stop real-time monitoring"""
        await monitor.stop_monitoring(model_id)
    
    def add_performance_alert(handler: Callable) -> None:
        """Add alert handler for performance issues"""
        monitor.add_alert_handler(handler)
    
    # Bind methods to master system
    master_system.evaluate_model = evaluate_model
    master_system.compare_models = compare_models
    master_system.analyze_feature_importance = analyze_feature_importance
    master_system.generate_performance_report = generate_performance_report
    master_system.start_model_monitoring = start_monitoring
    master_system.stop_model_monitoring = stop_monitoring
    master_system.add_performance_alert = add_performance_alert
    
    # Store references
    master_system.model_evaluator = evaluator
    master_system.performance_monitor = monitor
    
    logger.info("Model performance evaluation suite integrated successfully")
    
    return {}
        'evaluator': evaluator,
        'monitor': monitor,
        'evaluate_model': evaluate_model,
        'compare_models': compare_models,
        'analyze_feature_importance': analyze_feature_importance,
        'generate_performance_report': generate_performance_report,
        'start_monitoring': start_monitoring,
        'stop_monitoring': stop_monitoring,
        'add_performance_alert': add_performance_alert
    }


if __name__ == "__main__":
    # Example usage
    import asyncio
    
    # Create evaluator
    evaluator = ModelPerformanceEvaluator()
    
    # Generate sample data
    np.random.seed(42)
    n_days = 1000
    
    # Simulate returns
    returns = np.random.normal(0.0005, 0.02, n_days)
    cumulative = (1 + returns).cumprod()
    
    # Create predictions DataFrame
    predictions_df = pd.DataFrame({)
        'returns': returns,
        'cumulative': cumulative,
        'signal': np.random.choice([-1, 0, 1], n_days),
        'position': np.random.uniform(-1, 1, n_days)
    }, index=pd.date_range('2020-01-01', periods=n_days, freq='D'))
    
    # Create actuals DataFrame
    actuals_df = pd.DataFrame({)
        'returns': returns + np.random.normal(0, 0.001, n_days),
        'price': 100 * cumulative
    }, index=predictions_df.index)
    
    # Evaluate model
    print("Evaluating model performance...")
    metrics = evaluator.evaluate_model()
        'test_model',
        predictions_df,
        actuals_df,
        model_type='trading'
    )
    
    print(f"\nPerformance Metrics:")
    print(f"Sharpe Ratio: {metrics.sharpe_ratio:.3f}")
    print(f"Total Return: {metrics.total_return:.2%}")
    print(f"Max Drawdown: {metrics.max_drawdown:.2%}")
    print(f"Win Rate: {metrics.win_rate:.2%}")
    
    # Generate report
    print("\nGenerating performance report...")
    report_path = evaluator.generate_report()
        'test_model',
        'performance_report.html'
    )
    print(f"Report saved to: {report_path}")
    
    # Temporal analysis
    print("\nAnalyzing temporal performance...")
    temporal_results = evaluator.analyze_temporal_performance('test_model')
    
    if 'performance_decay' in temporal_results:
        decay = temporal_results['performance_decay']
        print(f"Performance decay rate: {decay.get('decay_rate', 0):.4f}")
    
    # Error analysis
    print("\nAnalyzing errors...")
    error_results = evaluator.analyze_errors('test_model')
    
    if 'error_distribution' in error_results:
        error_dist = error_results['error_distribution']
        print(f"Mean error: {error_dist['mean']:.4f}")
        print(f"Error std: {error_dist['std']:.4f}")
        print(f"Has bias: {error_dist['has_bias']}")
    
    print("\nEvaluation complete!")