#!/usr/bin/env python3
"""
FINAL REAL TRADING SYSTEM - NO FAKE IMPLEMENTATIONS
====================================================

Uses existing real implementations from the codebase:
✅ Real Alpaca API integration (real_alpaca_config.py)
✅ Real market data fetcher (real_market_data_fetcher.py) 
✅ Real portfolio tracking (no synthetic data)
✅ Real technical indicators (using pandas/numpy)
✅ Real order execution via Alpaca
✅ Real AI analysis (when OpenRouter available)

This integrates all the real components that already exist.
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import numpy as np
import pandas as pd

# Import existing real implementations
from real_alpaca_config import setup_alpaca_environment, get_alpaca_config
from real_market_data_fetcher import RealMarketDataFetcher
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce
import requests
from comprehensive_data_validation import ComprehensiveValidator, ValidationLimits, SecurityValidator

from universal_market_data import get_current_market_data, validate_price



class RealTechnicalAnalysis:
    """Real technical analysis using pandas/numpy - no fake calculations"""
    
    @staticmethod
    def calculate_rsi(prices: pd.Series, period: int = 14) -> float:
        """Calculate real RSI using actual formula"""
        if len(prices) < period + 1:
            return 50.0
            
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return float(rsi.iloc[-1])
    
    @staticmethod
    def calculate_macd(prices: pd.Series) -> Dict[str, float]:
        """Calculate real MACD using actual formula"""
        if len(prices) < 26:
            return {'macd': 0.0, 'signal': 0.0, 'histogram': 0.0}
            
        exp1 = prices.ewm(span=12).mean()
        exp2 = prices.ewm(span=26).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9).mean()
        histogram = macd - signal
        
        return {}
            'macd': float(macd.iloc[-1]),
            'signal': float(signal.iloc[-1]),
            'histogram': float(histogram.iloc[-1])
        }
    
    @staticmethod
    def calculate_bollinger_bands(prices: pd.Series, period: int = 20) -> Dict[str, float]:
        """Calculate real Bollinger Bands"""
        if len(prices) < period:
            return {'upper': 0.0, 'middle': 0.0, 'lower': 0.0}
            
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper = sma + (std * 2)
        lower = sma - (std * 2)
        
        return {}
            'upper': float(upper.iloc[-1]),
            'middle': float(sma.iloc[-1]),
            'lower': float(lower.iloc[-1])
        }
    
    @staticmethod
    def calculate_moving_averages(prices: pd.Series) -> Dict[str, float]:
        """Calculate real moving averages"""
        if len(prices) < 50:
            return {'sma_20': 0.0, 'sma_50': 0.0, 'ema_12': 0.0}
            
        sma_20 = prices.rolling(window=20).mean().iloc[-1] if len(prices) >= 20 else 0
        sma_50 = prices.rolling(window=50).mean().iloc[-1] if len(prices) >= 50 else 0
        ema_12 = prices.ewm(span=12).mean().iloc[-1] if len(prices) >= 12 else 0
        
        return {}
            'sma_20': float(sma_20),
            'sma_50': float(sma_50),
            'ema_12': float(ema_12)
        }

class RealAIAnalysis:
    """Real AI analysis with OpenRouter API"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv('OPENROUTER_API_KEY')
        self.logger = logging.getLogger(__name__)
        
    def analyze_symbol(self, symbol: str, market_data: Dict, technical_data: Dict) -> Dict:
        """Real AI analysis of symbol"""
        try:
            # Prepare market context
            context = f"""
            Symbol: {symbol}
            Current Price: ${market_data.get('price', 0):.2f}
            Volume: {market_data.get('volume', 0):,}
            
            Technical Indicators:
            RSI: {technical_data.get('rsi', 50):.1f}
            MACD: {technical_data.get('macd', {}).get('macd', 0):.3f}
            20-day SMA: ${technical_data.get('moving_averages', {}).get('sma_20', 0):.2f}
            
            Provide a clear BUY/SELL/HOLD recommendation with confidence (0-1).
            """
            
            headers = {}
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {}
                "model": "deepseek/deepseek-r1",
                "messages": []
                    {"role": "system", "content": "You are a professional trading analyst. Provide specific, actionable recommendations."},
                    {"role": "user", "content": context}
                ],
                "max_tokens": 300
            }
            
            response = requests.post()
                "https://openrouter.ai/api/v1/chat/completions",
                json=payload,
                headers=headers,
                timeout=15
            )
            
            if response.status_code == 200:
                ai_response = response.json()
                content = ai_response['choices'][0]['message']['content']
                
                # Parse response
                recommendation = "HOLD"
                confidence = 0.5
                
                content_upper = content.upper()
                if "BUY" in content_upper:
                    recommendation = "BUY"
                    confidence = 0.7
                elif "SELL" in content_upper:
                    recommendation = "SELL"
                    confidence = 0.7
                
                return {}
                    'recommendation': recommendation,
                    'confidence': confidence,
                    'reasoning': content[:150],
                    'source': 'ai'
                }
            else:
                return self._technical_fallback(technical_data)
                
        except Exception as e:
            self.logger.warning(f"AI analysis failed: {e}")
            return self._technical_fallback(technical_data)
    
    def _technical_fallback(self, technical_data: Dict) -> Dict:
        """Technical analysis fallback"""
        rsi = technical_data.get('rsi', 50)
        macd_data = technical_data.get('macd', {})
        macd = macd_data.get('macd', 0)
        signal = macd_data.get('signal', 0)
        
        # Simple technical rules
        if rsi < 30 and macd > signal:
            return {'recommendation': 'BUY', 'confidence': 0.6, 'reasoning': 'Oversold RSI + MACD bullish', 'source': 'technical'}
        elif rsi > 70 and macd < signal:
            return {'recommendation': 'SELL', 'confidence': 0.6, 'reasoning': 'Overbought RSI + MACD bearish', 'source': 'technical'}
        else:
            return {'recommendation': 'HOLD', 'confidence': 0.5, 'reasoning': 'Mixed signals', 'source': 'technical'}

class RealPortfolioTracker:
    """Real portfolio tracking with Alpaca - no fake P&L"""
    
    def __init__(self, trading_client: TradingClient):
        self.trading_client = trading_client
        self.logger = logging.getLogger(__name__)
        
    def get_real_portfolio_status(self) -> Dict:
        """Get actual portfolio status from Alpaca"""
        try:
            account = self.trading_client.get_account()
            positions = self.trading_client.get_all_positions()
            
            # Calculate real metrics
            total_equity = float(account.equity)
            buying_power = float(account.buying_power)
            day_trade_count = int(account.daytrade_buying_power) if account.daytrade_buying_power else 0
            unrealized_pnl = float(account.unrealized_pl) if account.unrealized_pl else 0.0
            
            position_data = []
            for pos in positions:
                position_data.append({)
                    'symbol': pos.symbol,
                    'quantity': float(pos.qty),
                    'market_value': float(pos.market_value) if pos.market_value else 0.0,
                    'unrealized_pnl': float(pos.unrealized_pl) if pos.unrealized_pl else 0.0,
                    'unrealized_pnl_percent': float(pos.unrealized_plpc) if pos.unrealized_plpc else 0.0,
                    'current_price': float(pos.current_price) if pos.current_price else 0.0,
                    'avg_entry_price': float(pos.avg_entry_price) if pos.avg_entry_price else 0.0
                })
            
            return {}
                'total_equity': total_equity,
                'buying_power': buying_power,
                'day_trade_count': day_trade_count,
                'unrealized_pnl': unrealized_pnl,
                'positions_count': len(positions),
                'positions': position_data,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error getting portfolio status: {e}")
            return {}
                'total_equity': 0.0,
                'buying_power': 0.0,
                'day_trade_count': 0,
                'unrealized_pnl': 0.0,
                'positions_count': 0,
                'positions': [],
                'error': str(e)
            }

class RealOrderExecutor:
    """Real order execution through Alpaca"""
    
    def __init__(self, trading_client: TradingClient):
        self.trading_client = trading_client
        self.logger = logging.getLogger(__name__)
        
    def execute_order(self, symbol: str, side: str, quantity: float, dry_run: bool = True) -> Dict:
        """Execute real order (or simulate if dry_run=True)"""
        try:
# Comprehensive input validation
            validator = ComprehensiveValidator()
            
            # Validate symbol
            if 'symbol' in locals():
                symbol_result = validator.validate_trading_request({'request_type': 'get_quote', 'symbol': symbol}, 'system')
                if not symbol_result['valid']:
                    raise ValueError(f"Symbol validation failed: {symbol_result['errors']}")
                symbol = symbol_result['sanitized_data']['symbol']
            
            # Validate quantity
            if 'quantity' in locals():
                limits = ValidationLimits()
                if not (limits.MIN_QUANTITY <= float(quantity) <= limits.MAX_QUANTITY):
                    raise ValueError(f"Quantity {quantity} out of valid range")
            
            # Validate price
            if 'price' in locals() or 'limit_price' in locals():
                price_to_check = locals().get('price', locals().get('limit_price'))
                if price_to_check is not None:
                    limits = ValidationLimits()
                    if not (limits.MIN_PRICE <= float(price_to_check) <= limits.MAX_PRICE):
                        raise ValueError(f"Price {price_to_check} out of valid range")
    def execute_order(self, symbol: str, side: str, quantity: float, dry_run: bool = True) -> Dict:
                self.logger.info(f"DRY RUN: Would execute {side} {quantity} shares of {symbol}")
                return {}
                    'status': 'simulated',
                    'symbol': symbol,
                    'side': side,
                    'quantity': quantity,
                    'message': 'Order simulated successfully'
                }
            
            # Real order execution
            order_side = OrderSide.BUY if side.upper() == "BUY" else OrderSide.SELL
            
            order_request = MarketOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=order_side,
                time_in_force=TimeInForce.DAY
            )
            
            order = self.trading_client.submit_order(order_request)
            
            return {}
                'status': 'submitted',
                'order_id': order.id,
                'symbol': order.symbol,
                'side': order.side.value,
                'quantity': float(order.qty),
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Order execution failed: {e}")
            return {}
                'status': 'error',
                'symbol': symbol,
                'side': side,
                'quantity': quantity,
                'error': str(e)
            }

class FinalRealTradingSystem:
    """Complete real trading system using existing implementations"""
    
    def __init__(self, mode: str = 'paper'):
        self.mode = mode
        self.logger = self._setup_logging()
        
        # Initialize real components
        try:
            self.config = setup_alpaca_environment(mode)
            self.data_fetcher = RealMarketDataFetcher(mode)
            
            self.trading_client = TradingClient()
                api_key=self.config['api_key'],
                secret_key=self.config['secret_key'],
                paper=self.config['paper_trading']
            )
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
            
            self.portfolio_tracker = RealPortfolioTracker(self.trading_client)
            self.order_executor = RealOrderExecutor(self.trading_client)
            self.ai_analyzer = RealAIAnalysis()
            
            self.logger.info(f"✅ Real trading system initialized in {mode} mode")
            
        except Exception as e:
            self.logger.error(f"System initialization failed: {e}")
            raise
    
    def _setup_logging(self):
        """Setup logging"""
        logging.basicConfig()
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[]
                logging.FileHandler('real_trading_system.log'),
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)
    
    async def analyze_symbol(self, symbol: str) -> Dict:
        """Complete real analysis of a symbol"""
        self.logger.info(f"🔍 Analyzing {symbol}")
        
        # 1. Get real market data
        quote = await self.data_fetcher.get_live_quote(symbol)
        historical = await self.data_fetcher.get_historical_data(symbol, '3mo')
        
        if historical.empty:
            return {'error': f'No data available for {symbol}'}
        
        # 2. Calculate real technical indicators
        close_prices = historical['Close']
        
        technical_analysis = {}
            'rsi': RealTechnicalAnalysis.calculate_rsi(close_prices),
            'macd': RealTechnicalAnalysis.calculate_macd(close_prices),
            'bollinger_bands': RealTechnicalAnalysis.calculate_bollinger_bands(close_prices),
            'moving_averages': RealTechnicalAnalysis.calculate_moving_averages(close_prices)
        }
        
        # 3. Get real AI analysis
        ai_analysis = self.ai_analyzer.analyze_symbol(symbol, quote, technical_analysis)
        
        # 4. Calculate trend analysis
        recent_prices = close_prices.tail(10)
        price_change = (recent_prices.iloc[-1] - recent_prices.iloc[0]) / recent_prices.iloc[0]
        
        trend_analysis = {}
            'trend_direction': 'UP' if price_change > 0.02 else 'DOWN' if price_change < -0.02 else 'SIDEWAYS',
            'price_change_10d': price_change,
            'volatility': close_prices.tail(20).std() / close_prices.tail(20).mean(),
            'volume_trend': 'HIGH' if quote.get('volume', 0) > historical['Volume'].tail(20).mean() * 1.5 else 'NORMAL'
        }
        
        return {}
            'symbol': symbol,
            'market_data': quote,
            'technical_analysis': technical_analysis,
            'ai_analysis': ai_analysis,
            'trend_analysis': trend_analysis,
            'timestamp': datetime.now().isoformat()
        }
    
    async def get_portfolio_status(self) -> Dict:
        """Get real portfolio status"""
        return self.portfolio_tracker.get_real_portfolio_status()
    
    async def run_full_analysis(self, symbols: List[str]) -> Dict:
        """Run complete analysis on multiple symbols"""
        self.logger.info(f"🚀 Running REAL analysis on {len(symbols)} symbols")
        
        # Get portfolio status
        portfolio = await self.get_portfolio_status()
        
        # Analyze each symbol
        symbol_analyses = {}
        for symbol in symbols:
            try:
                analysis = await self.analyze_symbol(symbol)
                symbol_analyses[symbol] = analysis
                
                # Add trading signal
                ai_rec = analysis.get('ai_analysis', {}).get('recommendation', 'HOLD')
                confidence = analysis.get('ai_analysis', {}).get('confidence', 0.5)
                
                # Generate trading signal based on multiple factors
                rsi = analysis.get('technical_analysis', {}).get('rsi', 50)
                macd_histogram = analysis.get('technical_analysis', {}).get('macd', {}).get('histogram', 0)
                
                trading_signal = self._generate_trading_signal(ai_rec, confidence, rsi, macd_histogram)
                analysis['trading_signal'] = trading_signal
                
            except Exception as e:
                self.logger.error(f"Analysis failed for {symbol}: {e}")
                symbol_analyses[symbol] = {'error': str(e)}
        
        return {}
            'portfolio': portfolio,
            'symbol_analyses': symbol_analyses,
            'analysis_timestamp': datetime.now().isoformat(),
            'symbols_analyzed': len(symbol_analyses)
        }
    
    def _generate_trading_signal(self, ai_rec: str, confidence: float, rsi: float, macd_histogram: float) -> Dict:
        """Generate trading signal based on multiple factors"""
        score = 0
        reasons = []
        
        # AI recommendation weight
        if ai_rec == 'BUY':
            score += confidence * 2
            reasons.append(f"AI recommends BUY (confidence: {confidence:.1%})")
        elif ai_rec == 'SELL':
            score -= confidence * 2
            reasons.append(f"AI recommends SELL (confidence: {confidence:.1%})")
        
        # RSI weight
        if rsi < 30:
            score += 1
            reasons.append("RSI oversold (<30)")
        elif rsi > 70:
            score -= 1
            reasons.append("RSI overbought (>70)")
        
        # MACD weight
        if macd_histogram > 0:
            score += 0.5
            reasons.append("MACD bullish")
        elif macd_histogram < 0:
            score -= 0.5
            reasons.append("MACD bearish")
        
        # Generate final signal
        if score > 1:
            signal = 'STRONG_BUY'
        elif score > 0.5:
            signal = 'BUY'
        elif score < -1:
            signal = 'STRONG_SELL'
        elif score < -0.5:
            signal = 'SELL'
        else:
            signal = 'HOLD'
        
        return {}
            'signal': signal,
            'score': score,
            'reasons': reasons,
            'strength': abs(score)
        }
    
    def display_results(self, results: Dict):
        """Display analysis results"""
        print("\n" + "="*80)
        print("🎯 FINAL REAL TRADING SYSTEM ANALYSIS")
        print("="*80)
        
        # Portfolio section
        portfolio = results.get('portfolio', {})
        print(f"\n💰 PORTFOLIO STATUS ({self.mode.upper()}):")
        print(f"   Total Equity: ${portfolio.get('total_equity', 0):,.2f}")
        print(f"   Buying Power: ${portfolio.get('buying_power', 0):,.2f}")
        print(f"   Unrealized P&L: ${portfolio.get('unrealized_pnl', 0):,.2f}")
        print(f"   Positions: {portfolio.get('positions_count', 0)}")
        
        if portfolio.get('positions'):
            print("\n   Current Positions:")
            for pos in portfolio['positions'][:5]:  # Show first 5
                pnl_pct = pos.get('unrealized_pnl_percent', 0) * 100
                print(f"     {pos['symbol']}: {pos['quantity']:.0f} shares @ ${pos['current_price']:.2f} ({pnl_pct:+.1f}%)")
        
        # Symbol analyses
        symbol_analyses = results.get('symbol_analyses', {})
        print(f"\n📊 SYMBOL ANALYSIS ({len(symbol_analyses)} symbols):")
        
        for symbol, analysis in symbol_analyses.items():
            if 'error' in analysis:
                print(f"\n❌ {symbol}: {analysis['error']}")
                continue
                
            market_data = analysis.get('market_data', {})
            technical = analysis.get('technical_analysis', {})
            ai_analysis = analysis.get('ai_analysis', {})
            signal = analysis.get('trading_signal', {})
            
            print(f"\n📈 {symbol}:")
            print(f"   Price: ${market_data.get('price', 0):.2f} | Volume: {market_data.get('volume', 0):,}")
            print(f"   RSI: {technical.get('rsi', 0):.1f} | MACD: {technical.get('macd', {}).get('macd', 0):.3f}")
            print(f"   AI: {ai_analysis.get('recommendation', 'N/A')} ({ai_analysis.get('confidence', 0):.0%}) | Source: {ai_analysis.get('source', 'N/A')}")
            print(f"   🎯 Signal: {signal.get('signal', 'HOLD')} (Strength: {signal.get('strength', 0):.1f})")
            
            if signal.get('reasons'):
                print(f"   Reasons: {', '.join(signal['reasons'][:2])}")
        
        print(f"\n✅ Analysis completed at {results.get('analysis_timestamp', 'N/A')}")
        print("🔥 ALL DATA IS REAL - No synthetic/mock implementations!")

async def main():
    """Main function"""
    print("🚀 FINAL REAL TRADING SYSTEM")
    print("="*50)
    print("✅ Real Alpaca API integration")
    print("✅ Real market data (Alpaca + YFinance)")
    print("✅ Real portfolio tracking")
    print("✅ Real technical analysis")
    print("✅ Real AI analysis (OpenRouter)")
    print("✅ Real order execution capability")
    print("="*50)
    
    # Initialize system
    system = FinalRealTradingSystem(mode='paper')
    
    # Test symbols
    test_symbols = ['AAPL', 'TSLA', 'SPY', 'NVDA']
    
    # Run analysis
    results = await system.run_full_analysis(test_symbols)
    
    # Display results
    system.display_results(results)
    
    return results

if __name__ == "__main__":
    results = asyncio.run(main())