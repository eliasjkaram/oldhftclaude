#!/usr/bin/env python3
"""
Test script for the MinIO Web Browser Interface Scraper
"""

import json
from web_minio_scraper import MinIOWebScraper
import sys

import logging

def main():
    logger.info("Testing MinIO Web Scraper...")
    logger.info("="*50)
    
    # Initialize scraper with the target URL
    scraper = MinIOWebScraper("https://uschristmas.us/browser/stockdb")
    
    try:
        # Perform the scraping
        logger.info("Starting scrape operation...")
        inventory = scraper.scrape_minio()
        
        # Print results
        scraper.print_summary()
        
        # Save results
        scraper.save_inventory("minio_inventory_stockdb.json")
        
        logger.info("\nScraping completed successfully!")
        logger.info(f"Results saved to: minio_inventory_stockdb.json")
        logger.info(f"Detailed report saved to: minio_detailed_report.txt")
        
        return True
        
    except Exception as e:
        logger.error("Error during scraping: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)