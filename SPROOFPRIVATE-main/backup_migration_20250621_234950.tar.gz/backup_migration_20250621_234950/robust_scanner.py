
#!/usr/bin/env python3
"""
Robust Options Scanner - Memory efficient, error resistant, iterative processing
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import gc
import time
import json
import random
import logging
from datetime import datetime
from typing import Dict, List
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from real_options_bot import RealOptionsBot

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler(f'robust_scan_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RobustOptionsScanner:
    """Memory-efficient, error-resistant options scanner"""
    
    def __init__(self):
        self.bot = None
        self.processed_symbols = set()
        self.failed_symbols = set()
        self.total_opportunities = 0
        self.session_results = {}
            'credit_spreads': [],
            'debit_spreads': [],
            'iron_condors': [],
            'straddles': [],
            'strangles': [],
            'butterflies': [],
            'arbitrage': []
        }
        self.start_time = datetime.now()
        
        # All available symbols (expanded list)
        self.all_symbols = []
            # Major ETFs
            'SPY', 'QQQ', 'IWM', 'XLF', 'XLE', 'XLK', 'XLV', 'XLI', 'XLP', 'XLY',
            'GDX', 'EEM', 'TLT', 'VXX', 'UVXY', 'SQQQ', 'TQQQ', 'SPXS', 'SPXL',
            # FAANG+
            'AAPL', 'MSFT', 'GOOGL', 'GOOG', 'AMZN', 'META', 'TSLA', 'NVDA', 'NFLX',
            # Mega caps
            'BRK.B', 'JPM', 'V', 'JNJ', 'WMT', 'PG', 'MA', 'UNH', 'HD', 'DIS',
            # High volume tech
            'AMD', 'INTC', 'CRM', 'ORCL', 'ADBE', 'CSCO', 'IBM', 'QCOM', 'TXN',
            # Finance
            'BAC', 'WFC', 'GS', 'MS', 'C', 'AXP', 'BLK', 'SCHW',
            # Popular stocks
            'PLTR', 'BB', 'AMC', 'GME', 'COIN', 'RIVN', 'LCID', 'F', 'UBER', 'LYFT',
            # Additional
            'KO', 'PEP', 'MCD', 'NKE', 'SBUX', 'COST', 'LOW', 'TGT', 'CVX', 'XOM'
        ]
        
        # Randomize processing order
        random.shuffle(self.all_symbols)
        logger.info(f"🎯 Initialized scanner with {len(self.all_symbols)} symbols in random order")
    
    def initialize_bot(self):
        """Initialize bot with error handling"""
        try:
            self.bot = RealOptionsBot()
            logger.info("✅ Bot initialized successfully")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to initialize bot: {e}")
            return False
    
    def calculate_advanced_metrics(self, opportunity):
        """Fast metrics calculation with error handling"""
        try:
            metrics = {}
            
            # Basic metrics
            metrics['net_premium'] = getattr(opportunity, 'net_premium', 0)
            metrics['max_profit'] = getattr(opportunity, 'max_profit', 0)
            metrics['max_loss'] = getattr(opportunity, 'max_loss', 0)
            metrics['probability_profit'] = getattr(opportunity, 'probability_profit', 0)
            
            # Safe calculations
            if metrics['max_loss'] > 0:
                metrics['profit_loss_ratio'] = metrics['max_profit'] / metrics['max_loss']
                metrics['risk_reward_ratio'] = metrics['max_loss'] / metrics['max_profit'] if metrics['max_profit'] > 0 else float('inf')
            else:
                metrics['profit_loss_ratio'] = float('inf')
                metrics['risk_reward_ratio'] = 0
            
            # Expected values
            prob_win = metrics['probability_profit']
            prob_lose = 1 - prob_win
            metrics['expected_profit'] = (prob_win * metrics['max_profit']) - (prob_lose * metrics['max_loss'])
            
            capital_req = max(abs(metrics['net_premium']), metrics['max_loss'])
            metrics['expected_return'] = metrics['expected_profit'] / capital_req if capital_req > 0 else 0
            
            # Kelly fraction (simplified)
            if metrics['max_loss'] > 0 and prob_win > 0 and metrics['max_profit'] > 0:
                b = metrics['max_profit'] / metrics['max_loss']
                kelly_fraction = (b * prob_win - prob_lose) / b
                metrics['kelly_fraction'] = max(0, min(0.25, kelly_fraction)
            else:
                metrics['kelly_fraction'] = 0
            
            # Opportunity score
            metrics['opportunity_score'] = ()
                metrics['expected_return'] * 0.4 +
                metrics['probability_profit'] * 0.3 +
                (1 / max(metrics['risk_reward_ratio'], 0.1) * 0.2 +)
                min(metrics['profit_loss_ratio'], 5) * 0.1
            )
            
            return metrics
            
        except Exception as e:
            logger.debug(f"Metrics calculation error: {e}")
            return {'opportunity_score': 0, 'expected_profit': 0, 'probability_profit': 0}
    
    def process_single_symbol(self, symbol: str) -> Dict:
        """Process a single symbol with comprehensive error handling"""
        symbol_start = time.time()
        results = {}
            'symbol': symbol,
            'status': 'failed',
            'opportunities': 0,
            'spreads': {},
            'error': None,
            'processing_time': 0,
            'current_price': 0
        }
        
        try:
            logger.info(f"🔍 Processing {symbol}...")
            
            # Get current price with timeout
            from alpaca.data.requests import StockLatestQuoteRequest
            quote_request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            quote = self.bot.stock_data_client.get_stock_latest_quote(quote_request)
            
            if symbol not in quote:
                results['error'] = 'No quote data'
                return results
                
            current_price = float(quote[symbol].ask_price)
            results['current_price'] = current_price
            
            logger.info(f"   📊 {symbol}: ${current_price:.2f}")
            
            # Get options chain with limited retries
            options_chain = None
            for attempt in range(2):
                try:
                    options_chain = self.bot.get_options_chain(symbol)
                    break
                except Exception as e:
                    if attempt == 0:
                        time.sleep(1)  # Brief retry delay
                        continue
                    else:
                        raise e
            
            if not options_chain:
                results['error'] = 'No options data'
                return results
            
            logger.info(f"   ✅ Found {len(options_chain)} contracts")
            
            # Analyze spreads with memory management
            try:
                spreads = self.bot.find_all_spreads(options_chain, current_price, symbol)
                
                # Count and log opportunities
                total_symbol_opps = sum(len(opps) for opps in spreads.values()
                results['opportunities'] = total_symbol_opps
                results['spreads'] = spreads
                results['status'] = 'success'
                
                # Log summary for this symbol
                if total_symbol_opps > 0:
                    logger.info(f"   🎯 {symbol}: {total_symbol_opps} opportunities found")
                    for strategy_type, opps in spreads.items():
                        if opps:
                            logger.info(f"      {strategy_type}: {len(opps)}")
                else:
                    logger.info(f"   ⚪ {symbol}: No qualifying opportunities")
                
                # Add best opportunities to session results (limit memory)
                for strategy_type, opportunities in spreads.items():
                    if opportunities:
                        # Sort by score and take top 2 per strategy per symbol
                        scored_opps = []
                        for opp in opportunities:
                            metrics = self.calculate_advanced_metrics(opp)
                            scored_opps.append((opp, metrics)
                        
                        scored_opps.sort(key=lambda x: x[1]['opportunity_score'], reverse=True)
                        
                        # Add top 2 to session results
                        for opp, metrics in scored_opps[:2]:
                            opp_data = {}
                                'symbol': symbol,
                                'strategy': opp.strategy_name,
                                'net_premium': metrics.get('net_premium', 0),
                                'max_profit': metrics.get('max_profit', 0),
                                'max_loss': metrics.get('max_loss', 0),
                                'probability_profit': metrics.get('probability_profit', 0),
                                'expected_profit': metrics.get('expected_profit', 0),
                                'opportunity_score': metrics.get('opportunity_score', 0),
                                'kelly_fraction': metrics.get('kelly_fraction', 0),
                                'timestamp': datetime.now().isoformat()
                            }
                            self.session_results[strategy_type].append(opp_data)
                
            except Exception as e:
                results['error'] = f'Spread analysis failed: {str(e)}'
                logger.warning(f"   ⚠️ {symbol}: Spread analysis error - {e}")
                return results
            
            # Clear memory
            del options_chain
            del spreads
            gc.collect()
            
        except Exception as e:
            results['error'] = str(e)
            logger.error(f"   ❌ {symbol}: {e}")
            
        finally:
            results['processing_time'] = time.time() - symbol_start
            
        return results
    
    def save_session_results(self):
        """Save accumulated results to file"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'session_results_{timestamp}.json'
            
            # Create summary
            summary = {}
                'session_info': {}
                    'start_time': self.start_time.isoformat(),
                    'end_time': datetime.now().isoformat(),
                    'total_symbols_processed': len(self.processed_symbols),
                    'total_symbols_failed': len(self.failed_symbols),
                    'total_opportunities': sum(len(opps) for opps in self.session_results.values(),
                    'processed_symbols': list(self.processed_symbols),
                    'failed_symbols': list(self.failed_symbols)
                },
                'opportunities_by_strategy': {}
            }
            
            # Add top opportunities by strategy
            for strategy_type, opportunities in self.session_results.items():
                if opportunities:
                    # Sort by score
                    sorted_opps = sorted(opportunities, key=lambda x: x['opportunity_score'], reverse=True)
                    summary['opportunities_by_strategy'][strategy_type] = sorted_opps[:10]  # Top 10 per strategy
            
            with open(filename, 'w') as f:
                json.dump(summary, f, indent=2, default=str)
                
            logger.info(f"💾 Session results saved to {filename}")
            
        except Exception as e:
            logger.error(f"Failed to save session results: {e}")
    
    def display_session_summary(self):
        """Display comprehensive session summary"""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        
        logger.info(f"\n{'='*80}")
        logger.info(f"📊 SESSION SUMMARY")
        logger.info(f"{'='*80}")
        logger.info(f"⏱️  Total Runtime: {elapsed/60:.1f} minutes")
        logger.info(f"✅ Symbols Processed: {len(self.processed_symbols)}")
        logger.info(f"❌ Symbols Failed: {len(self.failed_symbols)}")
        logger.info(f"🎯 Total Opportunities: {sum(len(opps) for opps in self.session_results.values()}")
        
        logger.info(f"\n📈 OPPORTUNITIES BY STRATEGY:")
        for strategy_type, opportunities in self.session_results.items():
            if opportunities:
                count = len(opportunities)
                avg_score = sum(opp['opportunity_score'] for opp in opportunities) / count
                avg_expected = sum(opp['expected_profit'] for opp in opportunities) / count
                logger.info(f"   {strategy_type.upper():20}: {count:3} | Avg Score: {avg_score:.2f} | Avg Expected: ${avg_expected:6.2f}")
        
        # Top 5 overall opportunities
        all_opps = []
        for strategy_type, opportunities in self.session_results.items():
            for opp in opportunities:
                all_opps.append(opp)
        
        if all_opps:
            all_opps.sort(key=lambda x: x['opportunity_score'], reverse=True)
            
            logger.info(f"\n🏆 TOP 5 OPPORTUNITIES:")
            for i, opp in enumerate(all_opps[:5], 1):
                logger.info(f"   #{i}. {opp['strategy']} - {opp['symbol']}")
                logger.info(f"       Score: {opp['opportunity_score']:.2f} | Expected: ${opp['expected_profit']:.2f} | Win%: {opp['probability_profit']:.1%}")
        
        logger.info(f"{'='*80}")
    
    def run_iterative_scan(self, max_symbols: int = None, save_interval: int = 10):
        """Run iterative scan with memory management"""
        logger.info(f"🚀 STARTING ROBUST ITERATIVE OPTIONS SCANNER")
        logger.info(f"📋 Processing {len(self.all_symbols)} symbols in random order")
        
        if not self.initialize_bot():
            return
        
        symbols_to_process = self.all_symbols[:max_symbols] if max_symbols else self.all_symbols
        
        for i, symbol in enumerate(symbols_to_process, 1):
            try:
                logger.info(f"\n📍 Progress: {i}/{len(symbols_to_process)} ({i/len(symbols_to_process)*100:.1f}%)")
                
                # Process symbol
                result = self.process_single_symbol(symbol)
                
                if result['status'] == 'success':
                    self.processed_symbols.add(symbol)
                    self.total_opportunities += result['opportunities']
                else:
                    self.failed_symbols.add(symbol)
                
                # Periodic saves and memory management
                if i % save_interval == 0:
                    logger.info(f"💾 Saving progress... ({len(self.processed_symbols)} processed)")
                    self.save_session_results()
                    gc.collect()  # Force garbage collection
                
                # Brief pause to avoid rate limiting
                time.sleep(0.5)
                
            except KeyboardInterrupt:
                logger.info(f"\n⏹️  Scan interrupted by user")
                break
            except Exception as e:
                logger.error(f"Unexpected error processing {symbol}: {e}")
                self.failed_symbols.add(symbol)
                continue
        
        # Final summary and save
        self.display_session_summary()
        self.save_session_results()
        
        logger.info(f"\n✅ SCAN COMPLETE!")
        logger.info(f"📊 Processed {len(self.processed_symbols)} symbols")
        logger.info(f"🎯 Found {sum(len(opps) for opps in self.session_results.values()} total opportunities")

def main():
    """Main execution"""
    scanner = RobustOptionsScanner()
    
    # Run with options
    try:
        # Process all symbols (or limit for testing)
        scanner.run_iterative_scan(max_symbols=None, save_interval=5)
    except Exception as e:
        logger.error(f"Scanner failed: {e}")

if __name__ == "__main__":
    main()