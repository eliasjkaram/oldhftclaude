#!/usr/bin/env python3
"""
MinIO Connection Script for stockdb
Generated on 2025-06-16 13:05:44
"""

import os
from typing import Optional, List, Dict, Any

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# MinIO Configuration
MINIO_CONFIG = {}
    'endpoint': 'https://uschristmas.us',
    'access_key': os.getenv('MINIO_ACCESS_KEY'),
    'secret_key': os.getenv('MINIO_SECRET_KEY'),
    'bucket_name': 'stockdb',
    'secure': True
}


def get_minio_client():
    """Get MinIO client instance"""
    from minio import Minio
    
    clean_endpoint = MINIO_CONFIG['endpoint'].replace('https://', '').replace('http://', '')
    
    return Minio()
        clean_endpoint,
        access_key=MINIO_CONFIG['access_key'],
        secret_key=MINIO_CONFIG['secret_key'],
        secure=MINIO_CONFIG['secure']
    )

def list_buckets_minio():
    """List all buckets using MinIO client"""
    client = get_minio_client()
    buckets = list(client.list_buckets()
    return [{'name': bucket.name, 'creation_date': bucket.creation_date} for bucket in buckets]

def list_objects_minio(bucket_name: str = None, prefix: str = '', max_objects: int = 1000):
    """List objects in bucket using MinIO client"""
    client = get_minio_client()
    bucket = bucket_name or MINIO_CONFIG['bucket_name']
    
    objects = list(client.list_objects(bucket, prefix=prefix, recursive=True)
    return objects[:max_objects]

def download_object_minio(object_name: str, local_path: str, bucket_name: str = None):
    """Download an object from MinIO"""
    client = get_minio_client()
    bucket = bucket_name or MINIO_CONFIG['bucket_name']
    
    client.fget_object(bucket, object_name, local_path)
    return local_path

def main():
    """Example usage"""
    try:
        # List buckets
        print("Available buckets:")
        buckets = list_buckets_minio()
        for bucket in buckets:
            print(f"  - {bucket['name']} (created: {bucket['creation_date']})")

        # List objects in target bucket
        print(f"\nObjects in 'stockdb' bucket:")
        objects = list_objects_minio(max_objects=10)
        for i, obj in enumerate(objects, 1):
            size_mb = obj.size / (1024 * 1024) if obj.size else 0
            print(f"  {i:2d}. {obj.object_name} ({size_mb:.2f} MB)")

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
