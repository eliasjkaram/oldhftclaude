#!/usr/bin/env python3
"""Test GPU cluster component startup"""

import asyncio
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_gpu_cluster():
    try:
        # Try to import the GPU cluster module
        from gpu_cluster_deployment_system import GPUClusterDeploymentSystem
        
        logger.info("GPU cluster module imported successfully")
        
        # Try to create an instance
        gpu_system = GPUClusterDeploymentSystem()
        logger.info("GPU cluster instance created successfully")
        
        # Check if it has a start method
        if hasattr(gpu_system, 'start'):
            logger.info("GPU cluster has start method")
        
        return True
        
    except Exception as e:
        logger.error(f"GPU cluster test failed: {e}")
        return False

if __name__ == "__main__":
    asyncio.run(test_gpu_cluster())