from typing import Dict, List, Optional, Tuple
import sys
import os

#!/usr/bin/env python3
"""
Options Backtesting Integration
===============================

Demonstrates how to integrate the MinIO options processor with the
comprehensive backtesting system for testing various options strategies.

Supports:
- Options arbitrage strategies
- LEAPS trading
- Wheel strategy
- Calendar spreads
- Iron condors
- Butterfly spreads
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import sqlite3

# Import the options processor and backtesting system
from minio_options_processor import MinIOOptionsProcessor, OptionContract
from comprehensive_backtest_system import BacktestConfig, BacktestEngine

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)



# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

@dataclass
class OptionsStrategy:
    """Base class for options strategies"""
    name: str
    capital_required: float
    max_positions: int
    risk_per_trade: float
    
    def evaluate(self, contracts: List[OptionContract], market_data: pd.DataFrame) -> Dict:
    try:
            """Evaluate strategy and return signals - base implementation
        
            This base implementation provides a simple volatility-based signal.
            Subclasses should override for specific strategies.
            """
            signals = []
        
            # Base implementation: Look for high implied volatility
            for contract in contracts:
                if hasattr(contract, 'implied_volatility') and contract.implied_volatility:
                    # Signal if IV is high (above 30%)
                    if contract.implied_volatility > 0.30:
                        signals.append({)
                            'contract': contract,
                            'action': 'SELL',  # Sell high IV
                            'reason': f'High IV: {contract.implied_volatility:.1%}',
                            'confidence': min(0.7, contract.implied_volatility),
                            'size': 1
                        })
                    # Signal if IV is low (below 15%)
                    elif contract.implied_volatility < 0.15:
                        signals.append({)
                            'contract': contract,
                            'action': 'BUY',  # Buy low IV
                            'reason': f'Low IV: {contract.implied_volatility:.1%}',
                            'confidence': 0.6,
                            'size': 1
                        })
        
            return {}
                'signals': signals[:self.max_positions],  # Limit to max positions
                'evaluated': len(contracts),
                'signaled': len(signals)
            }


    class ArbitrageStrategy(OptionsStrategy):
        """Options arbitrage strategy"""
    
        def __init__(self):
            super().__init__()
                name="Options Arbitrage",
                capital_required=50000,
                max_positions=10,
                risk_per_trade=1000
            )
        
        def evaluate(self, contracts: List[OptionContract], market_data: pd.DataFrame) -> Dict:
            """Find and execute arbitrage opportunities"""
            signals = []
        
            # Group contracts by underlying and expiration
            grouped = {}
            for contract in contracts:
                key = (contract.underlying, contract.expiration)
                if key not in grouped:
                    grouped[key] = []
                grouped[key].append(contract)
            
            # Check each group for arbitrage
            for (underlying, expiration), group in grouped.items():
                # Need both calls and puts at same strike
                calls = [c for c in group if c.option_type == 'call']
                puts = [c for c in group if c.option_type == 'put']
            
                for call in calls:
                    for put in puts:
                        if call.strike == put.strike:
                            # Check put-call parity
                            signal = self._check_put_call_parity(call, put, market_data)
                            if signal:
                                signals.append(signal)
                            
            return {'signals': signals, 'strategy': self.name}
        
        def _check_put_call_parity(self, call: OptionContract, put: OptionContract, 
                                  market_data: pd.DataFrame) -> Optional[Dict]:
            """Check put-call parity for arbitrage"""
            # Get current stock price
            if call.underlying in market_data.columns:
                stock_price = market_data[call.underlying].iloc[-1]
            else:
                stock_price = call.strike  # Fallback
            
            # Put-call parity: C - P = S - K * exp(-r*T)
            r = 0.05  # Risk-free rate
            T = call.years_to_expiration
        
            theoretical_diff = stock_price - call.strike * np.exp(-r * T)
            actual_diff = call.mid_price - put.mid_price
        
            deviation = actual_diff - theoretical_diff
        
            # Check if deviation is significant
            if abs(deviation) > 0.50:  # $0.50 threshold
                return {}
                    'type': 'arbitrage',
                    'underlying': call.underlying,
                    'strike': call.strike,
                    'expiration': call.expiration,
                    'deviation': deviation,
                    'action': 'conversion' if deviation > 0 else 'reversal',
                    'expected_profit': abs(deviation) * 0.8  # Account for costs
                }
            
            return None


    class LEAPSStrategy(OptionsStrategy):
        """LEAPS trading strategy"""
    
        def __init__(self):
            super().__init__()
                name="LEAPS Trading",
                capital_required=100000,
                max_positions=20,
                risk_per_trade=5000
            )
        
        def evaluate(self, contracts: List[OptionContract], market_data: pd.DataFrame) -> Dict:
            """Evaluate LEAPS for trading opportunities"""
            signals = []
        
            # Filter LEAPS only
            leaps = [c for c in contracts if c.is_leap]
        
            for contract in leaps:
                # Look for undervalued LEAPS with high IV
                if contract.implied_volatility > 0.3 and contract.volume > 100:
                    # Calculate theoretical value
                    signal = self._evaluate_leap(contract, market_data)
                    if signal:
                        signals.append(signal)
                    
            return {'signals': signals, 'strategy': self.name}
        
        def _evaluate_leap(self, contract: OptionContract, market_data: pd.DataFrame) -> Optional[Dict]:
            """Evaluate individual LEAP contract"""
            # Simple criteria: Look for deep OTM LEAPS with high potential
            if contract.moneyness == 'OTM':
                # Calculate potential return
                potential_return = (contract.strike - contract.mid_price) / contract.mid_price
            
                if potential_return > 2.0:  # 200% potential return
                    return {}
                        'type': 'leap_buy',
                        'contract': contract.symbol,
                        'underlying': contract.underlying,
                        'strike': contract.strike,
                        'expiration': contract.expiration,
                        'potential_return': potential_return,
                        'risk_score': 1 / contract.implied_volatility
                    }
                
            return None


    class WheelStrategy(OptionsStrategy):
        """Options wheel strategy"""
    
        def __init__(self):
            super().__init__()
                name="Wheel Strategy",
                capital_required=25000,
                max_positions=5,
                risk_per_trade=5000
            )
            self.positions = {}  # Track current positions
        
        def evaluate(self, contracts: List[OptionContract], market_data: pd.DataFrame) -> Dict:
            """Run the wheel strategy"""
            signals = []
        
            # Group by underlying
            by_underlying = {}
            for contract in contracts:
                if contract.underlying not in by_underlying:
                    by_underlying[contract.underlying] = []
                by_underlying[contract.underlying].append(contract)
            
            for underlying, contracts_list in by_underlying.items():
                # Check if we have a position
                if underlying not in self.positions:
                    # Look for put to sell
                    signal = self._find_put_to_sell(underlying, contracts_list, market_data)
                else:
                    # We own stock, look for call to sell
                    signal = self._find_call_to_sell(underlying, contracts_list, market_data)
                
                if signal:
                    signals.append(signal)
                
            return {'signals': signals, 'strategy': self.name}
        
        def _find_put_to_sell(self, underlying: str, contracts: List[OptionContract], 
                             market_data: pd.DataFrame) -> Optional[Dict]:
            """Find optimal put to sell"""
            # Filter for OTM puts with 30-45 DTE
            puts = [c for c in contracts]
                    if c.option_type == 'put' 
                    and c.moneyness == 'OTM'
                    and 30 <= c.days_to_expiration <= 45]
        
            if not puts:
                return None
            
            # Find put with best premium
            best_put = max(puts, key=lambda x: x.bid)
        
            if best_put.bid > 0.50:  # Minimum premium threshold
                return {}
                    'type': 'sell_put',
                    'contract': best_put.symbol,
                    'underlying': underlying,
                    'strike': best_put.strike,
                    'premium': best_put.bid,
                    'expiration': best_put.expiration
                }
            
            return None
        
        def _find_call_to_sell(self, underlying: str, contracts: List[OptionContract], 
                              market_data: pd.DataFrame) -> Optional[Dict]:
            """Find optimal call to sell against stock position"""
            # Filter for OTM calls with 30-45 DTE
            calls = [c for c in contracts]
                     if c.option_type == 'call' 
                     and c.moneyness == 'OTM'
                     and 30 <= c.days_to_expiration <= 45]
        
            if not calls:
                return None
            
            # Find call with best premium
            best_call = max(calls, key=lambda x: x.bid)
        
            if best_call.bid > 0.50:  # Minimum premium threshold
                return {}
                    'type': 'sell_call',
                    'contract': best_call.symbol,
                    'underlying': underlying,
                    'strike': best_call.strike,
                    'premium': best_call.bid,
                    'expiration': best_call.expiration
                }
            
            return None


    class OptionsBacktestEngine:
        """Enhanced backtest engine with options support"""
    
        def __init__(self, options_processor: MinIOOptionsProcessor):
            self.options_processor = options_processor
            self.strategies = {}
            self.results = {}
        
        def add_strategy(self, strategy: OptionsStrategy):
            """Add a strategy to backtest"""
            self.strategies[strategy.name] = strategy
            logger.info(f"Added strategy: {strategy.name}")
        
        def run_backtest(self, 
                        start_date: datetime,
                        end_date: datetime,
                        symbols: List[str],
                        initial_capital: float = 100000) -> Dict:
            """Run backtest for all strategies"""
            logger.info(f"Starting backtest from {start_date} to {end_date}")
        
            results = {}
        
            for strategy_name, strategy in self.strategies.items():
                logger.info(f"Backtesting {strategy_name}...")
            
                # Run strategy backtest
                strategy_results = self._backtest_strategy()
                    strategy, start_date, end_date, symbols, initial_capital
                )
            
                results[strategy_name] = strategy_results
            
            self.results = results
            return results
        
        def _backtest_strategy(self, 
                              strategy: OptionsStrategy,
                              start_date: datetime,
                              end_date: datetime,
                              symbols: List[str],
                              initial_capital: float) -> Dict:
            """Backtest individual strategy"""
            # Initialize portfolio
            portfolio = {}
                'cash': initial_capital,
                'positions': {},
                'history': [],
                'equity_curve': [initial_capital]
            }
        
            # Download options data
            raw_data = self.options_processor.download_options_data()
                symbols=symbols,
                start_date=start_date,
                end_date=end_date,
                include_leaps=True
            )
        
            # Process data
            contracts = self.options_processor.process_options_data(raw_data)
        
            # Simulate trading days
            current_date = start_date
            while current_date <= end_date:
                # Filter contracts for current date
                current_contracts = []
                    c for c in contracts 
                    if c.expiration > current_date
                ]
            
                # Get market data (simplified - would use real data in practice)
                market_data = pd.DataFrame({)
                    symbol: self.get_price_distribution(100, 10, 1) 
                    for symbol in symbols
                })
            
                # Evaluate strategy
                signals = strategy.evaluate(current_contracts, market_data)
            
                # Execute trades
                for signal in signals.get('signals', []):
                    self._execute_trade(portfolio, signal, current_date)
                
                # Update portfolio value
                portfolio_value = self._calculate_portfolio_value(portfolio, current_contracts)
                portfolio['equity_curve'].append(portfolio_value)
            
                # Move to next day
                current_date += timedelta(days=1)
            
            # Calculate metrics
            equity_curve = np.array(portfolio['equity_curve'])
            returns = np.diff(equity_curve) / equity_curve[:-1]
        
            metrics = {}
                'total_return': (equity_curve[-1] - initial_capital) / initial_capital,
                'sharpe_ratio': np.sqrt(252) * returns.mean() / returns.std() if returns.std() > 0 else 0,
                'max_drawdown': self._calculate_max_drawdown(equity_curve),
                'win_rate': self._calculate_win_rate(portfolio['history']),
                'total_trades': len(portfolio['history']),
                'final_value': equity_curve[-1]
            }
        
            return {}
                'metrics': metrics,
                'equity_curve': equity_curve.tolist(),
                'trades': portfolio['history']
            }
        
        def _execute_trade(self, portfolio: Dict, signal: Dict, date: datetime):
            """Execute a trade signal"""
            # Simplified trade execution
            trade = {}
                'date': date,
                'type': signal['type'],
                'symbol': signal.get('contract', signal.get('underlying'),
                'quantity': 1,
                'price': signal.get('premium', 0),
                'pnl': 0
            }
        
            # Update cash
            if 'sell' in signal['type']:
                portfolio['cash'] += signal.get('premium', 0) * 100  # Options multiplier
            else:
                portfolio['cash'] -= signal.get('premium', 0) * 100
            
            portfolio['history'].append(trade)
        
        def _calculate_portfolio_value(self, portfolio: Dict, contracts: List[OptionContract]) -> float:
            """Calculate total portfolio value"""
            # Simplified - just return cash for now
            # In practice, would mark positions to market
            return portfolio['cash']
        
        def _calculate_max_drawdown(self, equity_curve: np.ndarray) -> float:
            """Calculate maximum drawdown"""
            peak = np.maximum.accumulate(equity_curve)
            drawdown = (peak - equity_curve) / peak
            return np.max(drawdown)
        
        def _calculate_win_rate(self, trades: List[Dict]) -> float:
            """Calculate win rate from trades"""
            if not trades:
                return 0.0
            
            wins = sum(1 for t in trades if t.get('pnl', 0) > 0)
            return wins / len(trades)
        
        def generate_report(self, output_path: str = "options_backtest_report.html"):
            """Generate backtest report"""
            html_content = f"""
            <html>
            <head>
                <title>Options Backtest Report</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; }}
                    .strategy {{ border: 1px solid #ddd; padding: 15px; margin: 15px 0; }}
                    table {{ border-collapse: collapse; width: 100%; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #4CAF50; color: white; }}
                    .metric {{ font-weight: bold; color: #2196F3; }}
                </style>
            </head>
            <body>
                <h1>Options Strategy Backtest Report</h1>
                <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            """
        
            for strategy_name, results in self.results.items():
                metrics = results['metrics']
                html_content += f"""
                <div class="strategy">
                    <h2>{strategy_name}</h2>
                    <table>
                        <tr><td>Total Return</td><td class="metric">{metrics['total_return']:.2%}</td></tr>
                        <tr><td>Sharpe Ratio</td><td class="metric">{metrics['sharpe_ratio']:.2f}</td></tr>
                        <tr><td>Max Drawdown</td><td class="metric">{metrics['max_drawdown']:.2%}</td></tr>
                        <tr><td>Win Rate</td><td class="metric">{metrics['win_rate']:.2%}</td></tr>
                        <tr><td>Total Trades</td><td class="metric">{metrics['total_trades']}</td></tr>
                        <tr><td>Final Value</td><td class="metric">${metrics['final_value']:,.2f}</td></tr>
                    </table>
                </div>
                """
            
            html_content += """
            </body>
            </html>
            """
        
            with open(output_path, 'w') as f:
                f.write(html_content)
            
            logger.info(f"Report generated: {output_path}")

    except Exception as e:
        logger.error(f"Error in evaluate: {str(e)}")
        raise

def main():
    try:
        """Main function to demonstrate integration"""
        logger.info("Starting Options Backtesting Integration Demo...")
    
        # Initialize options processor
        processor = MinIOOptionsProcessor()
    
        # Initialize backtest engine
        backtest_engine = OptionsBacktestEngine(processor)
    
        # Add strategies
        backtest_engine.add_strategy(ArbitrageStrategy()
        backtest_engine.add_strategy(LEAPSStrategy()
        backtest_engine.add_strategy(WheelStrategy()
    
        # Define backtest parameters
        symbols = ['AAPL', 'MSFT', 'GOOGL']
        end_date = datetime.now()
        start_date = end_date - timedelta(days=180)  # 6 months
    
        # Run backtest
        logger.info("Running backtest...")
        results = backtest_engine.run_backtest()
            start_date=start_date,
            end_date=end_date,
            symbols=symbols,
            initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000"))
        )
    
        # Generate report
        backtest_engine.generate_report("options_backtest_results.html")
    
        # Print summary
        logger.info("\nBacktest Summary:")
        for strategy_name, result in results.items():
            metrics = result['metrics']
            logger.info(f"\n{strategy_name}:")
            logger.info(f"  Total Return: {metrics['total_return']:.2%}")
            logger.info(f"  Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            logger.info(f"  Max Drawdown: {metrics['max_drawdown']:.2%}")
            logger.info(f"  Total Trades: {metrics['total_trades']}")
        
        logger.info("\nBacktest complete!")


    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise
    main()