#!/usr/bin/env python3
"""
MinIO Connection Test Script with Custom Credentials
Tests connection to uschristmas.us MinIO server with provided credentials
"""

import os
import sys
import json
import traceback
from datetime import datetime
from typing import Dict, List, Any

try:
    from minio import Minio
    from minio.error import S3Error
    minio_available = True
except ImportError:
    minio_available = False

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    boto3_available = True
except ImportError:
    boto3_available = False

try:
    import pandas as pd
    pandas_available = True
except ImportError:
    pandas_available = False

# Custom MinIO Configuration
MINIO_CONFIG = {}
    'endpoint': 'https://uschristmas.us',
    'access_key': os.getenv('MINIO_ACCESS_KEY'),
    'secret_key': os.getenv('MINIO_SECRET_KEY'),
    'bucket_name': 'stockdb',
    'secure': True
}

class MinIOConnectionTester:
    """Test MinIO connection with various methods and configurations"""
    
    def __init__(self):
        self.endpoint = MINIO_CONFIG['endpoint']
        self.access_key = MINIO_CONFIG['access_key']
        self.secret_key = MINIO_CONFIG['secret_key']
        self.bucket_name = MINIO_CONFIG['bucket_name']
        self.secure = MINIO_CONFIG['secure']
        
        # Clean endpoint for MinIO client
        self.clean_endpoint = self.endpoint.replace('https://', '').replace('http://', '')
        
        print(f"MinIO Connection Tester")
        print(f"======================")
        print(f"Endpoint: {self.endpoint}")
        print(f"Clean endpoint: {self.clean_endpoint}")
        print(f"Access Key: {self.access_key}")
        print(f"Secret Key: {'*' * len(self.secret_key)}")
        print(f"Bucket: {self.bucket_name}")
        print(f"Secure: {self.secure}")
        print()
    
    def check_dependencies(self) -> Dict[str, bool]:
        """Check if required dependencies are available"""
        deps = {}
            'minio': minio_available,
            'boto3': boto3_available,
            'pandas': pandas_available
        }
        
        print("Dependency Check:")
        print("-" * 20)
        for dep, available in deps.items():
            status = "✓ Available" if available else "✗ Missing"
            print(f"{dep:10}: {status}")
        
        return deps
    
    def test_minio_client(self) -> bool:
        """Test connection using MinIO Python client"""
        if not minio_available:
            print("\nMinIO client not available - install with: pip install minio")
            return False
        
        print(f"\nTesting MinIO Client Connection")
        print(f"=" * 40)
        
        try:
            # Create MinIO client
            client = Minio()
                self.clean_endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=self.secure
            )
            
            print(f"✓ MinIO client created successfully")
            
            # Test by listing buckets
            print(f"Attempting to list buckets...")
            buckets = list(client.list_buckets())
            print(f"✓ Successfully connected to MinIO server!")
            print(f"  Found {len(buckets)} buckets:")
            
            for bucket in buckets:
                print(f"    - {bucket.name} (created: {bucket.creation_date})")
            
            # Check if our target bucket exists
            bucket_exists = client.bucket_exists(self.bucket_name)
            print(f"\nTarget bucket '{self.bucket_name}' exists: {bucket_exists}")
            
            if bucket_exists:
                print(f"\nExploring bucket '{self.bucket_name}'...")
                self._explore_bucket_minio(client)
            
            return True
            
        except S3Error as e:
            print(f"✗ MinIO S3Error: {e}")
            print(f"  Error code: {e.code}")
            print(f"  Error message: {e.message}")
            return False
        except Exception as e:
            print(f"✗ MinIO client error: {type(e).__name__}: {e}")
            traceback.print_exc()
            return False
    
    def test_boto3_client(self) -> bool:
        """Test connection using boto3"""
        if not boto3_available:
            print("\nboto3 not available - install with: pip install boto3")
            return False
        
        print(f"\nTesting boto3 Connection")
        print(f"=" * 40)
        
        try:
            # Create boto3 S3 client
            s3_client = boto3.client()
                's3',
                endpoint_url=self.endpoint,
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                verify=False  # Disable SSL verification for testing
            )
            
            print(f"✓ boto3 client created successfully")
            
            # Test by listing buckets
            print(f"Attempting to list buckets...")
            response = s3_client.list_buckets()
            buckets = response.get('Buckets', [])
            
            print(f"✓ Successfully connected via boto3!")
            print(f"  Found {len(buckets)} buckets:")
            
            for bucket in buckets:
                print(f"    - {bucket['Name']} (created: {bucket['CreationDate']})")
            
            # Check if our target bucket exists
            try:
                s3_client.head_bucket(Bucket=self.bucket_name)
                print(f"\nTarget bucket '{self.bucket_name}' exists and is accessible")
                
                print(f"\nExploring bucket '{self.bucket_name}'...")
                self._explore_bucket_boto3(s3_client)
                
            except ClientError as e:
                if e.response['Error']['Code'] == '404':
                    print(f"\nTarget bucket '{self.bucket_name}' does not exist")
                else:
                    print(f"Error accessing bucket: {e}")
            
            return True
            
        except ClientError as e:
            print(f"✗ boto3 ClientError: {e}")
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            print(f"  Error code: {error_code}")
            return False
        except Exception as e:
            print(f"✗ boto3 error: {type(e).__name__}: {e}")
            traceback.print_exc()
            return False
    
    def _explore_bucket_minio(self, client: Minio, max_objects: int = 20):
        """Explore bucket contents using MinIO client"""
        try:
            objects = list(client.list_objects(self.bucket_name, recursive=True))
            print(f"  Total objects in bucket: {len(objects)}")
            
            if objects:
                print(f"\nFirst {min(max_objects, len(objects))} objects:")
                for i, obj in enumerate(objects[:max_objects]):
                    size_mb = obj.size / (1024 * 1024) if obj.size else 0
                    print(f"    {i+1:2d}. {obj.object_name}")
                    print(f"        Size: {size_mb:.2f} MB")
                    print(f"        Modified: {obj.last_modified}")
                
                # Analyze file types
                self._analyze_file_types([obj.object_name for obj in objects])
                
                # Look for interesting directories/patterns
                self._analyze_directory_structure([obj.object_name for obj in objects])
                
        except Exception as e:
            print(f"  Error exploring bucket: {e}")
    
    def _explore_bucket_boto3(self, client, max_objects: int = 20):
        """Explore bucket contents using boto3"""
        try:
            paginator = client.get_paginator('list_objects_v2')
            objects = []
            
            for page in paginator.paginate(Bucket=self.bucket_name):
                if 'Contents' in page:
                    objects.extend(page['Contents'])
            
            print(f"  Total objects in bucket: {len(objects)}")
            
            if objects:
                print(f"\nFirst {min(max_objects, len(objects))} objects:")
                for i, obj in enumerate(objects[:max_objects]):
                    size_mb = obj['Size'] / (1024 * 1024) if obj['Size'] else 0
                    print(f"    {i+1:2d}. {obj['Key']}")
                    print(f"        Size: {size_mb:.2f} MB")
                    print(f"        Modified: {obj['LastModified']}")
                
                # Analyze file types
                self._analyze_file_types([obj['Key'] for obj in objects])
                
                # Look for interesting directories/patterns
                self._analyze_directory_structure([obj['Key'] for obj in objects])
                
        except Exception as e:
            print(f"  Error exploring bucket: {e}")
    
    def _analyze_file_types(self, object_names: List[str]):
        """Analyze file types in the bucket"""
        extensions = {}
        for name in object_names:
            if '.' in name:
                ext = name.split('.')[-1].lower()
                extensions[ext] = extensions.get(ext, 0) + 1
        
        if extensions:
            print(f"\nFile types found:")
            sorted_exts = sorted(extensions.items(), key=lambda x: x[1], reverse=True)
            for ext, count in sorted_exts[:10]:  # Top 10 file types
                print(f"    .{ext}: {count} files")
    
    def _analyze_directory_structure(self, object_names: List[str]):
        """Analyze directory structure"""
        directories = {}
        for name in object_names:
            if '/' in name:
                # Get top-level directory
                top_dir = name.split('/')[0]
                directories[top_dir] = directories.get(top_dir, 0) + 1
        
        if directories:
            print(f"\nTop-level directories:")
            sorted_dirs = sorted(directories.items(), key=lambda x: x[1], reverse=True)
            for dir_name, count in sorted_dirs[:10]:  # Top 10 directories
                print(f"    {dir_name}/: {count} files")
    
    def generate_connection_script(self, successful_methods: List[str]):
        """Generate a connection script based on successful methods"""
        if not successful_methods:
            return None
        
        script_content = f'''#!/usr/bin/env python3
"""
MinIO Connection Script for stockdb
Generated on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""

import os
from typing import Optional, List, Dict, Any

# MinIO Configuration
MINIO_CONFIG = {{}}
    'endpoint': '{self.endpoint}',
    'access_key': '{self.access_key}',
    'secret_key': '{self.secret_key}',
    'bucket_name': '{self.bucket_name}',
    'secure': {self.secure}
}}

'''
        
        if 'minio' in successful_methods:
            script_content += '''
def get_minio_client():
    """Get MinIO client instance"""
    from minio import Minio
    
    clean_endpoint = MINIO_CONFIG['endpoint'].replace('https://', '').replace('http://', '')
    
    return Minio()
        clean_endpoint,
        access_key=MINIO_CONFIG['access_key'],
        secret_key=MINIO_CONFIG['secret_key'],
        secure=MINIO_CONFIG['secure']
    )

def list_buckets_minio():
    """List all buckets using MinIO client"""
    client = get_minio_client()
    buckets = list(client.list_buckets())
    return [{'name': bucket.name, 'creation_date': bucket.creation_date} for bucket in buckets]

def list_objects_minio(bucket_name: str = None, prefix: str = '', max_objects: int = 1000):
    """List objects in bucket using MinIO client"""
    client = get_minio_client()
    bucket = bucket_name or MINIO_CONFIG['bucket_name']
    
    objects = list(client.list_objects(bucket, prefix=prefix, recursive=True))
    return objects[:max_objects]

def download_object_minio(object_name: str, local_path: str, bucket_name: str = None):
    """Download an object from MinIO"""
    client = get_minio_client()
    bucket = bucket_name or MINIO_CONFIG['bucket_name']
    
    client.fget_object(bucket, object_name, local_path)
    return local_path
'''
        
        if 'boto3' in successful_methods:
            script_content += '''
def get_boto3_client():
    """Get boto3 S3 client instance"""
    import boto3
    
    return boto3.client()
        's3',
        endpoint_url=MINIO_CONFIG['endpoint'],
        aws_access_key_id=MINIO_CONFIG['access_key'],
        aws_secret_access_key=MINIO_CONFIG['secret_key'],
        verify=False
    )

def list_buckets_boto3():
    """List all buckets using boto3"""
    client = get_boto3_client()
    response = client.list_buckets()
    return response.get('Buckets', [])

def list_objects_boto3(bucket_name: str = None, prefix: str = '', max_objects: int = 1000):
    """List objects in bucket using boto3"""
    client = get_boto3_client()
    bucket = bucket_name or MINIO_CONFIG['bucket_name']
    
    paginator = client.get_paginator('list_objects_v2')
    objects = []
    
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        if 'Contents' in page:
            objects.extend(page['Contents'])
            if len(objects) >= max_objects:
                break
    
    return objects[:max_objects]

def download_object_boto3(object_name: str, local_path: str, bucket_name: str = None):
    """Download an object using boto3"""
    client = get_boto3_client()
    bucket = bucket_name or MINIO_CONFIG['bucket_name']
    
    client.download_file(bucket, object_name, local_path)
    return local_path
'''
        
        script_content += '''
def main():
    """Example usage"""
    try:
        # List buckets
        print("Available buckets:")
'''
        
        if 'minio' in successful_methods:
            script_content += '''        buckets = list_buckets_minio()
        for bucket in buckets:
            print(f"  - {bucket['name']} (created: {bucket['creation_date']})")
'''
        elif 'boto3' in successful_methods:
            script_content += '''        buckets = list_buckets_boto3()
        for bucket in buckets:
            print(f"  - {bucket['Name']} (created: {bucket['CreationDate']})")
'''
        
        script_content += f'''
        # List objects in target bucket
        print(f"\\nObjects in '{MINIO_CONFIG['bucket_name']}' bucket:")
'''
        
        if 'minio' in successful_methods:
            script_content += '''        objects = list_objects_minio(max_objects=10)
        for i, obj in enumerate(objects, 1):
            size_mb = obj.size / (1024 * 1024) if obj.size else 0
            print(f"  {i:2d}. {obj.object_name} ({size_mb:.2f} MB)")
'''
        elif 'boto3' in successful_methods:
            script_content += '''        objects = list_objects_boto3(max_objects=10)
        for i, obj in enumerate(objects, 1):
            size_mb = obj['Size'] / (1024 * 1024) if obj['Size'] else 0
            print(f"  {i:2d}. {obj['Key']} ({size_mb:.2f} MB)")
'''
        
        script_content += '''
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
'''
        
        return script_content
    
    def run_tests(self):
        """Run all connection tests"""
        print(f"\nStarting MinIO Connection Tests")
        print(f"=" * 50)
        
        # Check dependencies
        deps = self.check_dependencies()
        
        successful_methods = []
        
        # Test MinIO client
        if deps['minio']:
            if self.test_minio_client():
                successful_methods.append('minio')
        
        # Test boto3
        if deps['boto3']:
            if self.test_boto3_client():
                successful_methods.append('boto3')
        
        # Results summary
        print(f"\n" + "=" * 50)
        print(f"TEST RESULTS SUMMARY")
        print(f"=" * 50)
        
        if successful_methods:
            print(f"✓ Successfully connected using: {', '.join(successful_methods)}")
            
            # Generate connection script
            script_content = self.generate_connection_script(successful_methods)
            if script_content:
                script_path = '/home/harry/alpaca-mcp/minio_stockdb_connection.py'
                with open(script_path, 'w') as f:
                    f.write(script_content)
                print(f"✓ Generated connection script: {script_path}")
            
        else:
            print(f"✗ No successful connections")
            print(f"\nTroubleshooting suggestions:")
            print(f"1. Verify the MinIO server is running and accessible")
            print(f"2. Check firewall/network connectivity to {self.endpoint}")
            print(f"3. Verify credentials are correct")
            print(f"4. Try different endpoint formats (with/without https://)")
        
        return successful_methods

def main():
    """Main function"""
    tester = MinIOConnectionTester()
    successful_methods = tester.run_tests()
    
    if successful_methods:
        print(f"\n" + "=" * 50)
        print(f"INSTALLATION REQUIREMENTS")
        print(f"=" * 50)
        
        required_packages = []
        if 'minio' in successful_methods:
            required_packages.append("minio")
        if 'boto3' in successful_methods:
            required_packages.append("boto3")
        
        if required_packages:
            print(f"To use MinIO in your scripts, install:")
            print(f"pip install {' '.join(required_packages)}")

if __name__ == "__main__":
    main()