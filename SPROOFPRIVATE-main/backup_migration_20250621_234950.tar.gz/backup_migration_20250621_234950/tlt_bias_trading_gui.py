#!/usr/bin/env python3
"""
TLT Bias Trading GUI
====================
GUI application for analyzing user beliefs about TLT and recommending
appropriate option strategies with comprehensive metrics
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta
import asyncio
from threading import Thread
import json

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


from adaptive_bias_strategy_optimizer import AdaptiveBiasStrategyOptimizer
from user_bias_integration_system import UserBiasIntegrationSystem
from bias_options_strategy_mapper import BiasOptionsStrategyMapper, BlackScholesCalculator

from universal_market_data import get_current_market_data, validate_price


class TLTTradingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("TLT Trading Strategy Analyzer - Bias Integration System")
        self.root.geometry("1400x900")
        
        # Initialize systems
        self.bias_system = UserBiasIntegrationSystem(enabled=True)
        self.strategy_optimizer = AdaptiveBiasStrategyOptimizer()
        self.options_mapper = BiasOptionsStrategyMapper()
        self.bs_calculator = BlackScholesCalculator()
        
        # Market data cache
        self.tlt_data = None
        self.current_price = None
        self.current_iv = None
        
        # Create GUI
        self._create_widgets()
        
        # Load initial data
        self.root.after(100, self._load_tlt_data)
        
    def _create_widgets(self):
        """Create all GUI widgets"""
        
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S)
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(2, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="TLT Trading Strategy Analyzer", 
                               font=('Arial', 18, 'bold')
        title_label.grid(row=0, column=0, columnspan=3, pady=10)
        
        # User Input Section
        input_frame = ttk.LabelFrame(main_frame, text="Your Market View", padding="10")
        input_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        # Bias input
        ttk.Label(input_frame, text="Your belief about TLT:").grid(row=0, column=0, sticky=tk.W)
        self.bias_text = scrolledtext.ScrolledText(input_frame, height=3, width=80)
        self.bias_text.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)
        self.bias_text.insert('1.0', "I believe TLT is going up in about 1 year, over 1 year we might see trend up or it stay in the range we have seen in the last 60 days")
        
        # Quick bias buttons
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=2, column=0, columnspan=3, pady=5)
        
        ttk.Button(button_frame, text="Strongly Bullish", 
                  command=lambda: self._set_bias("TLT will strongly rally over the next year").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Moderately Bullish", 
                  command=lambda: self._set_bias("TLT should trend up moderately over the next year").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Range Bound", 
                  command=lambda: self._set_bias("TLT will stay in current range for the year").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Bearish", 
                  command=lambda: self._set_bias("TLT looks overvalued and will decline").pack(side=tk.LEFT, padx=5)
        
        # Analyze button
        ttk.Button(input_frame, text="Analyze & Get Recommendations", 
                  command=self._analyze_bias, style='Accent.TButton').grid(row=3, column=0, columnspan=3, pady=10)
        
        # Market Data Section
        data_frame = ttk.LabelFrame(main_frame, text="TLT Market Data", padding="10")
        data_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 5)
        
        self.data_text = scrolledtext.ScrolledText(data_frame, height=15, width=40)
        self.data_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S)
        
        # Strategy Recommendations Section
        rec_frame = ttk.LabelFrame(main_frame, text="Recommended Strategies", padding="10")
        rec_frame.grid(row=2, column=1, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(5, 0)
        
        # Create treeview for strategies
        columns = ('Strategy', 'Direction', 'Max Profit', 'Max Loss', 'Breakeven', 'Prob. Profit', 'Score')
        self.strategy_tree = ttk.Treeview(rec_frame, columns=columns, show='tree headings', height=8)
        
        # Configure columns
        self.strategy_tree.column('#0', width=0, stretch=False)
        self.strategy_tree.column('Strategy', width=200)
        self.strategy_tree.column('Direction', width=100)
        self.strategy_tree.column('Max Profit', width=100)
        self.strategy_tree.column('Max Loss', width=100)
        self.strategy_tree.column('Breakeven', width=100)
        self.strategy_tree.column('Prob. Profit', width=100)
        self.strategy_tree.column('Score', width=80)
        
        # Headings
        for col in columns:
            self.strategy_tree.heading(col, text=col)
            
        self.strategy_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(rec_frame, orient=tk.VERTICAL, command=self.strategy_tree.yview)
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S)
        self.strategy_tree.configure(yscrollcommand=scrollbar.set)
        
        # Strategy details
        details_frame = ttk.LabelFrame(main_frame, text="Strategy Details", padding="10")
        details_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        self.details_text = scrolledtext.ScrolledText(details_frame, height=10, width=120)
        self.details_text.grid(row=0, column=0, sticky=(tk.W, tk.E)
        
        # Bind selection event
        self.strategy_tree.bind('<<TreeviewSelect>>', self._on_strategy_select)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready - Loading TLT data...")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(10, 0)
        
    def _set_bias(self, text):
        """Set predefined bias text"""
        self.bias_text.delete('1.0', tk.END)
        self.bias_text.insert('1.0', text)
        
    def _load_tlt_data(self):
        """Load TLT market data"""
        self.status_var.set("Loading TLT market data...")
        
        def load():
            try:
                # Download TLT data
                tlt = yf.Ticker("TLT")
                self.tlt_data = tlt.history(period="1y")
                
                # Get current price
                self.current_price = self.tlt_data['Close'].iloc[-1]
                
                # Calculate IV (simplified - using historical volatility as proxy)
                returns = self.tlt_data['Close'].pct_change().dropna()
                self.current_iv = returns.rolling(30).std().iloc[-1] * np.sqrt(252)
                
                # Get additional info
                info = tlt.info
                
                # Update GUI
                self.root.after(0, self._update_market_data, info)
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to load TLT data: {str(e)}")
                
        Thread(target=load, daemon=True).start()
        
    def _update_market_data(self, info):
        """Update market data display"""
        self.data_text.delete('1.0', tk.END)
        
        # Format market data
        data_text = f"""TLT - iShares 20+ Year Treasury Bond ETF

Current Price: ${self.current_price:.2f}
Implied Volatility: {self.current_iv*100:.1f}%
52-Week High: ${info.get('fiftyTwoWeekHigh', 'N/A')}
52-Week Low: ${info.get('fiftyTwoWeekLow', 'N/A')}
Average Volume: {info.get('averageVolume', 'N/A'):,}

Recent Performance:
1-Day Change: {self._calculate_return(1):.2f}%
5-Day Change: {self._calculate_return(5):.2f}%
1-Month Change: {self._calculate_return(22):.2f}%
3-Month Change: {self._calculate_return(66):.2f}%
1-Year Change: {self._calculate_return(252):.2f}%

Technical Indicators:
20-Day SMA: ${self.tlt_data['Close'].rolling(20).mean().iloc[-1]:.2f}
50-Day SMA: ${self.tlt_data['Close'].rolling(50).mean().iloc[-1]:.2f}
RSI (14): {self._calculate_rsi():.1f}

Last 60-Day Range:
High: ${self.tlt_data['Close'].tail(60).max():.2f}
Low: ${self.tlt_data['Close'].tail(60).min():.2f}
Current Position: {((self.current_price - self.tlt_data['Close'].tail(60).min() /))
                   (self.tlt_data['Close'].tail(60).max() - self.tlt_data['Close'].tail(60).min() * 100):.1f}%
"""
        
        self.data_text.insert('1.0', data_text)
        self.status_var.set("TLT data loaded successfully")
        
    def _calculate_return(self, days):
        """Calculate return over specified days"""
        if len(self.tlt_data) < days:
            return 0
        return ((self.current_price / self.tlt_data['Close'].iloc[-days-1]) - 1) * 100
        
    def _calculate_rsi(self, period=14):
        """Calculate RSI"""
        delta = self.tlt_data['Close'].diff()
        gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
        rs = gain / loss
        return 100 - (100 / (1 + rs).iloc[-1]
        
    def _analyze_bias(self):
        """Analyze user bias and generate recommendations"""
        self.status_var.set("Analyzing your market view...")
        
        # Get user input
        user_input = self.bias_text.get('1.0', 'end-1c')
        
        if not user_input.strip():
            messagebox.showwarning("Input Required", "Please enter your market view")
            return
            
        # Parse bias
        self.bias_system.add_user_bias(user_input)
        
        # For TLT, we'll analyze directly
        user_bias = self._parse_tlt_bias(user_input)
        
        # Generate recommendations
        self._generate_recommendations(user_bias)
        
    def _parse_tlt_bias(self, user_input):
        """Parse TLT-specific bias from user input"""
        
        # Simplified parsing for TLT
        user_input_lower = user_input.lower()
        
        # Determine direction
        if any(word in user_input_lower for word in ['going up', 'rally', 'bullish', 'increase', 'rise']):
            direction = 'bullish'
        elif any(word in user_input_lower for word in ['going down', 'decline', 'bearish', 'fall', 'drop']):
            direction = 'bearish'
        else:
            direction = 'neutral'
            
        # Determine time horizon
        if '1 year' in user_input_lower or 'one year' in user_input_lower:
            time_horizon = 365
        elif 'month' in user_input_lower:
            time_horizon = 30
        elif 'week' in user_input_lower:
            time_horizon = 7
        else:
            time_horizon = 180  # Default 6 months
            
        # Determine confidence
        if any(word in user_input_lower for word in ['strongly', 'definitely', 'certainly']):
            confidence = 0.8
        elif any(word in user_input_lower for word in ['might', 'maybe', 'possibly']):
            confidence = 0.5
        else:
            confidence = 0.65
            
        # Check for range-bound view
        if 'range' in user_input_lower or 'stay in' in user_input_lower:
            direction = 'neutral'
            
        return {}
            'symbol': 'TLT',
            'direction': direction,
            'confidence': confidence,
            'time_horizon': time_horizon,
            'raw_input': user_input
        }
        
    def _generate_recommendations(self, user_bias):
        """Generate strategy recommendations"""
        
        # Clear previous recommendations
        for item in self.strategy_tree.get_children():
            self.strategy_tree.delete(item)
            
        self.details_text.delete('1.0', tk.END)
        
        # Get machine bias
        machine_bias = self.strategy_optimizer._calculate_machine_bias('TLT', self.tlt_data)
        
        # Detect market regime
        market_regime = self.strategy_optimizer._detect_market_regime(self.tlt_data)
        
        # Generate strategies
        strategies = self._get_tlt_strategies(user_bias, machine_bias, market_regime)
        
        # Display strategies
        for i, strategy in enumerate(strategies):
            values = ()
                strategy['name'],
                strategy['direction'],
                f"${strategy['max_profit']:,.0f}",
                f"${strategy['max_loss']:,.0f}",
                f"${strategy['breakeven']:.2f}",
                f"{strategy['probability']:.1f}%",
                f"{strategy['score']:.2f}"
            )
            
            item = self.strategy_tree.insert('', 'end', values=values)
            
            # Store full strategy data
            self.strategy_tree.set(item, '#0', json.dumps(strategy)
            
        self.status_var.set(f"Generated {len(strategies)} strategy recommendations")
        
        # Auto-select first strategy
        if strategies:
            first_item = self.strategy_tree.get_children()[0]
            self.strategy_tree.selection_set(first_item)
            self.strategy_tree.focus(first_item)
            
    def _get_tlt_strategies(self, user_bias, machine_bias, market_regime):
        """Generate TLT-specific strategies"""
        
        strategies = []
        
        # 1. Long-term bullish with range possibility
        if user_bias['direction'] == 'bullish' and user_bias['time_horizon'] > 180:
            
            # LEAPS Call Options
            strategies.append({)
                'name': 'LEAPS Call Options',
                'direction': 'Bullish',
                'strikes': {'call': self.current_price * 1.05},
                'expiration': '1 Year',
                'max_profit': 'Unlimited',
                'max_loss': 800,  # Premium estimate
                'breakeven': self.current_price * 1.05 + 8,
                'probability': 45,
                'score': 0.75,
                'details': 'Buy 1-year call options slightly OTM. Best for strong directional moves.',
                'legs': [{'action': 'BUY', 'type': 'CALL', 'strike': self.current_price * 1.05, 'expiry': '1Y'}]
            })
            
            # Bull Call Spread (LEAPS)
            strategies.append({)
                'name': 'Bull Call Spread (LEAPS)',
                'direction': 'Bullish',
                'strikes': {'long_call': self.current_price, 'short_call': self.current_price * 1.10},
                'expiration': '1 Year',
                'max_profit': (self.current_price * 0.10 - 3) * 100,
                'max_loss': 300,
                'breakeven': self.current_price + 3,
                'probability': 55,
                'score': 0.80,
                'details': 'Buy ATM call, sell 10% OTM call. Limited risk, limited reward.',
                'legs': []
                    {'action': 'BUY', 'type': 'CALL', 'strike': self.current_price, 'expiry': '1Y'},
                    {'action': 'SELL', 'type': 'CALL', 'strike': self.current_price * 1.10, 'expiry': '1Y'}
                ]
            })
            
            # Calendar Spread (for range-bound scenario)
            strategies.append({)
                'name': 'Calendar Call Spread',
                'direction': 'Neutral-Bullish',
                'strikes': {'strike': self.current_price * 1.02},
                'expiration': 'Mixed',
                'max_profit': 400,
                'max_loss': 200,
                'breakeven': self.current_price * 0.98,
                'probability': 65,
                'score': 0.85,
                'details': 'Sell near-term call, buy long-term call. Profits from time decay if range-bound.',
                'legs': []
                    {'action': 'SELL', 'type': 'CALL', 'strike': self.current_price * 1.02, 'expiry': '45D'},
                    {'action': 'BUY', 'type': 'CALL', 'strike': self.current_price * 1.02, 'expiry': '1Y'}
                ]
            })
            
            # Diagonal Bull Spread
            strategies.append({)
                'name': 'Diagonal Bull Spread',
                'direction': 'Bullish',
                'strikes': {'short': self.current_price * 1.03, 'long': self.current_price},
                'expiration': 'Mixed',
                'max_profit': 500,
                'max_loss': 300,
                'breakeven': self.current_price + 3,
                'probability': 60,
                'score': 0.82,
                'details': 'Buy long-term ATM call, sell short-term OTM call. Captures time decay + directional move.',
                'legs': []
                    {'action': 'BUY', 'type': 'CALL', 'strike': self.current_price, 'expiry': '1Y'},
                    {'action': 'SELL', 'type': 'CALL', 'strike': self.current_price * 1.03, 'expiry': '45D'}
                ]
            })
            
        # 2. If machine disagrees (exploitation opportunity)
        if user_bias['direction'] != machine_bias['direction']:
            
            # Iron Condor (exploit uncertainty)
            strategies.append({)
                'name': 'Iron Condor (Skewed)',
                'direction': 'Neutral',
                'strikes': {}
                    'put_short': self.current_price * 0.97,
                    'put_long': self.current_price * 0.94,
                    'call_short': self.current_price * 1.02,
                    'call_long': self.current_price * 1.05
                },
                'expiration': '45 Days',
                'max_profit': 180,
                'max_loss': 120,
                'breakeven': f"{self.current_price * 0.97:.2f} - {self.current_price * 1.02:.2f}",
                'probability': 70,
                'score': 0.88,
                'details': 'Skewed toward your bullish bias. Profits if TLT stays within range.',
                'legs': []
                    {'action': 'SELL', 'type': 'PUT', 'strike': self.current_price * 0.97, 'expiry': '45D'},
                    {'action': 'BUY', 'type': 'PUT', 'strike': self.current_price * 0.94, 'expiry': '45D'},
                    {'action': 'SELL', 'type': 'CALL', 'strike': self.current_price * 1.02, 'expiry': '45D'},
                    {'action': 'BUY', 'type': 'CALL', 'strike': self.current_price * 1.05, 'expiry': '45D'}
                ]
            })
            
        # 3. Conservative strategies for range-bound view
        strategies.append({)
            'name': 'Covered Call (Synthetic)',
            'direction': 'Neutral-Bullish',
            'strikes': {'call': self.current_price * 1.05},
            'expiration': 'Monthly',
            'max_profit': 250,
            'max_loss': 'Stock decline',
            'breakeven': self.current_price - 2.5,
            'probability': 75,
            'score': 0.70,
            'details': 'Own TLT shares (or synthetic long), sell monthly calls. Income generation strategy.',
            'legs': []
                {'action': 'OWN', 'type': 'SHARES', 'quantity': 100},
                {'action': 'SELL', 'type': 'CALL', 'strike': self.current_price * 1.05, 'expiry': '30D'}
            ]
        })
        
        # 4. Based on current IV
        if self.current_iv > 0.20:  # High IV
            strategies.append({)
                'name': 'Short Strangle',
                'direction': 'Neutral',
                'strikes': {'put': self.current_price * 0.95, 'call': self.current_price * 1.05},
                'expiration': '45 Days',
                'max_profit': 350,
                'max_loss': 'Unlimited',
                'breakeven': f"{self.current_price * 0.95 - 3.5:.2f} - {self.current_price * 1.05 + 3.5:.2f}",
                'probability': 68,
                'score': 0.72,
                'details': 'Sell OTM put and call. High IV makes this attractive. Requires margin.',
                'legs': []
                    {'action': 'SELL', 'type': 'PUT', 'strike': self.current_price * 0.95, 'expiry': '45D'},
                    {'action': 'SELL', 'type': 'CALL', 'strike': self.current_price * 1.05, 'expiry': '45D'}
                ]
            })
            
        # Calculate Black-Scholes metrics for each strategy
        for strategy in strategies:
            self._add_greeks_to_strategy(strategy)
            
        # Sort by score
        strategies.sort(key=lambda x: x['score'], reverse=True)
        
        return strategies[:7]  # Return top 7 strategies
        
    def _add_greeks_to_strategy(self, strategy):
        """Add Greeks calculations to strategy"""
        
        T = 45/365  # Default 45 days
        if '1Y' in str(strategy.get('expiration', ''):
            T = 365/365
        elif '30D' in str(strategy.get('expiration', ''):
            T = 30/365
            
        r = 0.05  # Risk-free rate
        
        # Calculate aggregate Greeks for the strategy
        total_delta = 0
        total_gamma = 0
        total_theta = 0
        total_vega = 0
        
        for leg in strategy.get('legs', []):
            if leg['type'] in ['CALL', 'PUT']:
                strike = leg.get('strike', self.current_price)
                
                greeks = self.bs_calculator.calculate_greeks()
                    self.current_price, strike, r, self.current_iv, T, leg['type'].lower()
                )
                
                # Adjust sign based on action
                sign = 1 if leg['action'] == 'BUY' else -1
                
                total_delta += sign * greeks.delta
                total_gamma += sign * greeks.gamma
                total_theta += sign * greeks.theta
                total_vega += sign * greeks.vega
                
        strategy['greeks'] = {}
            'delta': round(total_delta, 3),
            'gamma': round(total_gamma, 3),
            'theta': round(total_theta, 2),
            'vega': round(total_vega, 2)
        }
        
    def _on_strategy_select(self, event):
        """Handle strategy selection"""
        selection = self.strategy_tree.selection()
        
        if not selection:
            return
            
        # Get strategy data
        item = selection[0]
        strategy_json = self.strategy_tree.set(item, '#0')
        
        try:
            strategy = json.loads(strategy_json)
        except:
            return
            
        # Display details
        self.details_text.delete('1.0', tk.END)
        
        details = f"""Strategy: {strategy['name']}
{'='*80}

Description: {strategy.get('details', 'N/A')}

Trade Structure:
"""
        
        for i, leg in enumerate(strategy.get('legs', []), 1):
            details += f"\n  Leg {i}: {leg['action']} {leg.get('quantity', 1)} {leg['type']} "
            if 'strike' in leg:
                details += f"@ ${leg['strike']:.2f} "
            if 'expiry' in leg:
                details += f"({leg['expiry']})"
                
        details += f"""

Risk/Reward Profile:
  Maximum Profit: ${strategy['max_profit']:,} {'(Unlimited)' if strategy['max_profit'] == 'Unlimited' else ''}
  Maximum Loss: ${strategy['max_loss']:,} {'(Unlimited)' if strategy['max_loss'] == 'Unlimited' else ''}
  Breakeven: {strategy['breakeven']}
  Probability of Profit: {strategy['probability']}%

Greeks (per contract):
  Delta: {strategy.get('greeks', {}).get('delta', 'N/A')}
  Gamma: {strategy.get('greeks', {}).get('gamma', 'N/A')}
  Theta: {strategy.get('greeks', {}).get('theta', 'N/A')} ($/day)
  Vega: {strategy.get('greeks', {}).get('vega', 'N/A')} ($/1% IV)

Market Context:
  User View: {self._get_user_view()}
  Machine View: {self._get_machine_view()}
  Strategy Score: {strategy['score']:.2f}

Implementation Notes:
- Monitor TLT price action around ${self.current_price:.2f}
- Current IV: {self.current_iv*100:.1f}% (historical average: ~15-20%)
- Consider rolling positions as expiration approaches
- Adjust position size based on account risk tolerance
"""
        
        self.details_text.insert('1.0', details)
        
    def _get_user_view(self):
        """Get summarized user view"""
        user_input = self.bias_text.get('1.0', 'end-1c')
        if 'going up' in user_input.lower():
            return "Bullish (1-year horizon)"
        elif 'range' in user_input.lower():
            return "Range-bound to slightly bullish"
        else:
            return "Neutral"
            
    def _get_machine_view(self):
        """Get machine view based on technicals"""
        rsi = self._calculate_rsi()
        sma20 = self.tlt_data['Close'].rolling(20).mean().iloc[-1]
        
        if self.current_price > sma20 and rsi > 50:
            return "Bullish (technical indicators positive)"
        elif self.current_price < sma20 and rsi < 50:
            return "Bearish (technical indicators negative)"
        else:
            return "Neutral (mixed signals)"


def main():
    """Run the TLT Trading GUI"""
    root = tk.Tk()
    
    # Style configuration
    style = ttk.Style()
    style.theme_use('clam')
    
    # Configure colors
    style.configure('Accent.TButton', foreground='white', background='#0078D4')
    
    app = TLTTradingGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()