
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Ultimate Unified Trading Bot - Lite Version
===========================================
A simplified version that focuses on core functionality without all imports
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import os
import sys
import json
import time
import logging
import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import sqlite3
from alpaca.trading.client import TradingClient
from dotenv import load_dotenv

from universal_market_data import get_current_market_data, validate_price


# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment
load_dotenv()

class UltimateUnifiedBotLite:
    """Simplified version of the Ultimate Unified Bot"""
    
    def __init__(self, mode='paper'):
        self.mode = mode
        logger.info(f"🚀 Initializing Ultimate Bot Lite ({mode} mode)...")
        
        # Initialize Alpaca
        self.setup_alpaca()
        
        # Trading parameters
        self.watchlist = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA']
        self.max_positions = 5
        self.position_size_pct = 0.02  # 2% per position
        self.stop_loss_pct = 0.01      # 1% stop loss
        self.take_profit_pct = 0.03    # 3% take profit
        
        # Track positions
        self.active_positions = {}
        self.performance_metrics = {}
            'total_trades': 0,
            'winning_trades': 0,
            'total_pnl': 0.0
        }
        
        # Initialize database
        self.setup_database()
        
        logger.info("✅ Bot initialized successfully!")
    
    def setup_alpaca(self):
        """Setup Alpaca connection"""
        if self.mode == 'paper':
            self.trading_client = TradingClient(os.getenv('ALPACA_PAPER_API_KEY')
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret), os.getenv('ALPACA_PAPER_API_SECRET'), paper=True)
        else:
            raise ValueError("Only paper mode supported in lite version")
        
        # Test connection
        account = self.trading_client.get_account()
        logger.info(f"✅ Connected to Alpaca - Portfolio: ${float(account.portfolio_value):,.2f}")
    
    def setup_database(self):
        """Setup trades database"""
        self.conn = sqlite3.connect('ultimate_bot_lite.db')
        cursor = self.conn.cursor()
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS trades ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                action TEXT,
                quantity INTEGER,
                price REAL,
                strategy TEXT,
                pnl REAL,
                status TEXT
            )
        ''')
        
        self.conn.commit()
    
    def get_market_data(self, symbol: str) -> Dict:
        """Get current market data for symbol"""
        try:
            # Get latest quote
            quote = self.data_client.get_stock_latest_quote(symbol)
            
            # Get daily bars for analysis
            bars = self.data_client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe='1Day', limit=50)).df
            
            if len(bars) < 20:
                return None
            
            # Calculate indicators
            bars['sma20'] = bars['close'].rolling(20).mean()
            bars['sma50'] = bars['close'].rolling(50).mean() if len(bars) >= 50 else bars['sma20']
            bars['rsi'] = self.calculate_rsi(bars['close'])
            
            return {}
                'symbol': symbol,
                'current_price': (quote.bid_price + quote.ask_price) / 2,
                'bid': quote.bid_price,
                'ask': quote.ask_price,
                'spread': quote.ask_price - quote.bid_price,
                'bars': bars,
                'sma20': bars['sma20'].iloc[-1],
                'sma50': bars['sma50'].iloc[-1],
                'rsi': bars['rsi'].iloc[-1],
                'volume': bars['volume'].iloc[-1]
            }
        except Exception as e:
            logger.error(f"Error getting data for {symbol}: {e}")
            return None
    
    def calculate_rsi(self, prices, period=14):
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def analyze_opportunity(self, market_data: Dict) -> Optional[Dict]:
        """Analyze trading opportunity"""
        if not market_data:
            return None
        
        symbol = market_data['symbol']
        price = market_data['current_price']
        sma20 = market_data['sma20']
        sma50 = market_data['sma50']
        rsi = market_data['rsi']
        
        # Simple strategy rules
        signal = None
        confidence = 0.0
        
        # Trend following
        if price > sma20 > sma50 and rsi < 70:
            signal = 'BUY'
            confidence = 0.7
            strategy = 'trend_following'
        
        # Mean reversion
        elif price < sma20 * 0.98 and rsi < 30:
            signal = 'BUY'
            confidence = 0.65
            strategy = 'mean_reversion'
        
        # Overbought
        elif price < sma20 and rsi > 70:
            signal = 'SELL'
            confidence = 0.6
            strategy = 'overbought'
        
        if signal and confidence > 0.6:
            return {}
                'symbol': symbol,
                'signal': signal,
                'price': price,
                'confidence': confidence,
                'strategy': strategy,
                'stop_loss': price * (1 - self.stop_loss_pct),
                'take_profit': price * (1 + self.take_profit_pct)
            }
        
        return None
    
    def calculate_position_size(self, price: float) -> int:
        """Calculate position size"""
        account = self.trading_client.get_account()
        portfolio_value = float(account.portfolio_value)
        position_value = portfolio_value * self.position_size_pct
        shares = int(position_value / price)
        return max(1, shares)
    
    def execute_trade(self, opportunity: Dict):
        """Execute trade"""
        symbol = opportunity['symbol']
        
        # Check if already have position
        if symbol in self.active_positions:
            logger.info(f"Already have position in {symbol}")
            return
        
        # Check position limit
        positions = self.trading_client.get_all_positions()
        if len(positions) >= self.max_positions:
            logger.info("Max positions reached")
            return
        
        # Calculate quantity
        quantity = self.calculate_position_size(opportunity['price'])
        
        try:
            # Place order
            order = self.trading_client.submit_order(order_data=LimitOrderRequest(symbol=symbol, qty=quantity, side='buy', time_in_force='day',
                limit_price=opportunity['price'] * 1.001  # Small buffer
            )
            
            logger.info(f"✅ Order placed: BUY {quantity} {symbol} @ ${opportunity['price']:.2f}")
            
            # Track position
            self.active_positions[symbol] = {}
                'order_id': order.id,
                'entry_price': opportunity['price'],
                'stop_loss': opportunity['stop_loss'],
                'take_profit': opportunity['take_profit'],
                'strategy': opportunity['strategy'],
                'entry_time': datetime.now()
            }
            
            # Record trade
            self.record_trade(symbol, 'BUY', quantity, opportunity['price'], 
                            opportunity['strategy'], 'PENDING')
            
            # Set stop loss order
            self.set_stop_loss(symbol, quantity, opportunity['stop_loss'])
            
        except Exception as e:
            logger.error(f"Failed to execute trade: {e}")
    
    def set_stop_loss(self, symbol: str, quantity: int, stop_price: float):
        """Set stop loss order"""
        try:
            self.trading_client.submit_order(order_data=MarketOrderRequest(symbol=symbol, qty=quantity, side='sell', time_in_force='gtc',
                stop_price=stop_price
            )
            logger.info(f"Stop loss set for {symbol} at ${stop_price:.2f}")
        except Exception as e:
            logger.error(f"Failed to set stop loss: {e}")
    
    def monitor_positions(self):
        """Monitor and manage positions"""
        positions = self.trading_client.get_all_positions()
        
        for position in positions:
            symbol = position.symbol
            current_price = float(position.current_price)
            entry_price = float(position.avg_entry_price)
            unrealized_pnl_pct = float(position.unrealized_plpc)
            
            # Take profit check
            if unrealized_pnl_pct >= self.take_profit_pct:
                logger.info(f"🎯 Take profit triggered for {symbol}: {unrealized_pnl_pct:.2%}")
                self.close_position(position)
            
            # Trailing stop
            elif unrealized_pnl_pct > 0.01:  # 1% profit
                if symbol in self.active_positions:
                    new_stop = entry_price * 1.005  # Move stop to breakeven + 0.5%
                    self.update_stop_loss(symbol, position.qty, new_stop)
    
    def close_position(self, position):
        """Close a position"""
        try:
            order = self.trading_client.submit_order(order_data=MarketOrderRequest(symbol=position.symbol, qty=position.qty, side='sell', time_in_force='day'))
            )
            
            pnl = float(position.unrealized_pl)
            logger.info(f"✅ Closed {position.symbol} - P&L: ${pnl:.2f}")
            
            # Update metrics
            self.performance_metrics['total_trades'] += 1
            if pnl > 0:
                self.performance_metrics['winning_trades'] += 1
            self.performance_metrics['total_pnl'] += pnl
            
            # Record trade
            self.record_trade(position.symbol, 'SELL', position.qty, 
                            float(position.current_price), 'close', 'COMPLETED', pnl)
            
            # Remove from active positions
            if position.symbol in self.active_positions:
                del self.active_positions[position.symbol]
                
        except Exception as e:
            logger.error(f"Failed to close position: {e}")
    
    def update_stop_loss(self, symbol: str, quantity: int, new_stop: float):
        """Update stop loss"""
        # Cancel existing stop orders
        orders = self.trading_client.get_orders(status='open')
        for order in orders:
            if order.symbol == symbol and order.order_type == 'stop':
                self.trading_client.cancel_order_by_id(order.id)
        
        # Set new stop
        self.set_stop_loss(symbol, quantity, new_stop)
    
    def record_trade(self, symbol, action, quantity, price, strategy, status, pnl=None):
        """Record trade in database"""
        cursor = self.conn.cursor()
        cursor.execute(''')
            INSERT INTO trades (symbol, action, quantity, price, strategy, status, pnl)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (symbol, action, quantity, price, strategy, status, pnl))
        self.conn.commit()
    
    def display_status(self):
        """Display bot status"""
        account = self.trading_client.get_account()
        positions = self.trading_client.get_all_positions()
        
        win_rate = (self.performance_metrics['winning_trades'] /)
                   max(1, self.performance_metrics['total_trades'])) * 100
        
        print("\n" + "="*60)
        print(f"🤖 ULTIMATE BOT LITE STATUS - {datetime.now().strftime('%H:%M:%S')}")
        print("="*60)
        print(f"💰 Portfolio: ${float(account.portfolio_value):,.2f}")
        print(f"💵 Cash: ${float(account.cash):,.2f}")
        print(f"📊 Positions: {len(positions)}/{self.max_positions}")
        print(f"📈 Total P&L: ${self.performance_metrics['total_pnl']:.2f}")
        print(f"🎯 Win Rate: {win_rate:.1f}%")
        print(f"🔄 Total Trades: {self.performance_metrics['total_trades']}")
        
        if positions:
            print("\n📊 Active Positions:")
            for pos in positions:
                pnl = float(pos.unrealized_pl)
                pnl_pct = float(pos.unrealized_plpc) * 100
                print(f"  {pos.symbol}: {pos.qty} shares | P&L: ${pnl:.2f} ({pnl_pct:+.2f}%)")
        
        print("="*60)
    
    async def run(self):
        """Main bot loop"""
        logger.info("🚀 Starting Ultimate Bot Lite...")
        
        cycle = 0
        while True:
            try:
                cycle += 1
                
                # Check market hours
                clock = self.trading_client.get_clock()
                if not clock.is_open and self.mode == 'paper':
                    logger.info("Market closed - using paper trading mode")
                
                # Monitor existing positions
                self.monitor_positions()
                
                # Look for new opportunities
                for symbol in self.watchlist:
                    # Get market data
                    market_data = self.get_market_data(symbol)
                    
                    # Analyze opportunity
                    opportunity = self.analyze_opportunity(market_data)
                    
                    # Execute if valid
                    if opportunity:
                        logger.info(f"🎯 Opportunity: {opportunity['strategy']} {symbol} ")
                                  f"(confidence: {opportunity['confidence']:.2f})")
                        self.execute_trade(opportunity)
                
                # Display status every 5 cycles
                if cycle % 5 == 0:
                    self.display_status()
                
                # Wait before next cycle
                await asyncio.sleep(60)  # 1 minute
                
            except KeyboardInterrupt:
                logger.info("Shutdown requested...")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                await asyncio.sleep(60)
        
        logger.info("✅ Bot stopped")
        self.conn.close()

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Ultimate Bot Lite')
    parser.add_argument('--mode', default='paper', choices=['paper'],
                       help='Trading mode (only paper supported)')
    
    args = parser.parse_args()
    
    # Create and run bot
    bot = UltimateUnifiedBotLite(mode=args.mode)
    
    # Run the bot
    asyncio.run(bot.run())

if __name__ == "__main__":
    main()