#!/usr/bin/env python3
"""
V24 Complete 76+ Algorithms Backtest System with Unique Implementations
Each algorithm has its own distinct trading logic
"""

import pandas as pd
import numpy as np
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import json
from datetime import datetime
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, get_realistic_price

warnings.filterwarnings('ignore')

class CompleteAlgorithmSet:
    """All 76+ algorithms with unique implementations"""
    
    # === TECHNICAL INDICATORS (16 algorithms) ===
    
    def rsi_oversold(self, data):
        """RSI Oversold/Overbought - Buy < 30, Sell > 70"""
        delta = data['close'].diff()
        gain = (delta.where(delta > 0, 0).rolling(window=14).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=14).mean())
        rs = gain / loss.replace(0, 1e-10)
        rsi = 100 - (100 / (1 + rs)
        
        signals = pd.Series(0, index=data.index)
        signals[rsi < 30] = 1
        signals[rsi > 70] = -1
        return signals
    
    def macd_crossover(self, data):
        """MACD Crossover - Buy when MACD crosses above signal"""
        exp1 = data['close'].ewm(span=12, adjust=False).mean()
        exp2 = data['close'].ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        
        signals = pd.Series(0, index=data.index)
        signals[(macd > signal) & (macd.shift(1) <= signal.shift(1)] = 1)
        signals[(macd < signal) & (macd.shift(1) >= signal.shift(1)] = -1)
        return signals
    
    def bollinger_squeeze(self, data):
        """Bollinger Band Squeeze - Trade breakouts from squeeze"""
        middle = data['close'].rolling(window=20).mean()
        std = data['close'].rolling(window=20).std()
        upper = middle + (2 * std)
        lower = middle - (2 * std)
        
        # Detect squeeze (bands narrow)
        band_width = (upper - lower) / middle
        squeeze = band_width < band_width.rolling(50).mean() * 0.8
        
        signals = pd.Series(0, index=data.index)
        # Buy on breakout above upper after squeeze
        signals[squeeze & (data['close'] > upper)] = 1
        # Sell on breakdown below lower after squeeze
        signals[squeeze & (data['close'] < lower)] = -1
        return signals
    
    def ema_crossover(self, data):
        """EMA Crossover - 12/26 EMA crossover"""
        ema_short = data['close'].ewm(span=12, adjust=False).mean()
        ema_long = data['close'].ewm(span=26, adjust=False).mean()
        
        signals = pd.Series(0, index=data.index)
        signals[(ema_short > ema_long) & (ema_short.shift(1) <= ema_long.shift(1)] = 1)
        signals[(ema_short < ema_long) & (ema_short.shift(1) >= ema_long.shift(1)] = -1)
        return signals
    
    def stochastic_oscillator(self, data):
        """Stochastic Oscillator - Overbought/Oversold"""
        period = 14
        lowest_low = data['low'].rolling(window=period).min()
        highest_high = data['high'].rolling(window=period).max()
        k_percent = 100 * ((data['close'] - lowest_low) / (highest_high - lowest_low)
        d_percent = k_percent.rolling(window=3).mean()
        
        signals = pd.Series(0, index=data.index)
        # Buy when %K crosses above %D in oversold
        signals[(k_percent < 20) & (k_percent > d_percent) & (k_percent.shift(1) <= d_percent.shift(1)] = 1)
        # Sell when %K crosses below %D in overbought
        signals[(k_percent > 80) & (k_percent < d_percent) & (k_percent.shift(1) >= d_percent.shift(1)] = -1)
        return signals
    
    def williams_r(self, data):
        """Williams %R - Momentum indicator"""
        period = 14
        highest_high = data['high'].rolling(window=period).max()
        lowest_low = data['low'].rolling(window=period).min()
        wr = -100 * ((highest_high - data['close']) / (highest_high - lowest_low)
        
        signals = pd.Series(0, index=data.index)
        signals[wr < -80] = 1  # Oversold
        signals[wr > -20] = -1  # Overbought
        return signals
    
    def adx_trend(self, data):
        """ADX Trend Strength - Trade strong trends"""
        high_low = data['high'] - data['low']
        high_close = (data['high'] - data['close'].shift().abs()
        low_close = (data['low'] - data['close'].shift().abs()
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr = true_range.rolling(window=14).mean()
        
        # Directional movement
        up_move = data['high'] - data['high'].shift()
        down_move = data['low'].shift() - data['low']
        
        plus_dm = pd.Series(0.0, index=data.index)
        minus_dm = pd.Series(0.0, index=data.index)
        
        plus_dm[(up_move > down_move) & (up_move > 0)] = up_move
        minus_dm[(down_move > up_move) & (down_move > 0)] = down_move
        
        # ADX calculation (simplified)
        adx = (plus_dm.rolling(14).mean() - minus_dm.rolling(14).mean().abs() / atr)
        
        signals = pd.Series(0, index=data.index)
        # Buy strong uptrend
        signals[(adx > 0.25) & (data['close'] > data['close'].rolling(20).mean()] = 1)
        # Sell strong downtrend
        signals[(adx > 0.25) & (data['close'] < data['close'].rolling(20).mean()] = -1)
        return signals
    
    def parabolic_sar(self, data):
        """Parabolic SAR - Trend following with stops"""
        af = 0.02
        max_af = 0.2
        
        signals = pd.Series(0, index=data.index)
        sar = pd.Series(index=data.index, dtype=float)
        
        # Initialize
        sar.iloc[0] = data['low'].iloc[0]
        trend = 1  # 1 for uptrend, -1 for downtrend
        ep = data['high'].iloc[0]  # Extreme point
        
        for i in range(1, len(data):
            if trend == 1:
                sar.iloc[i] = sar.iloc[i-1] + af * (ep - sar.iloc[i-1])
                if data['low'].iloc[i] < sar.iloc[i]:
                    trend = -1
                    signals.iloc[i] = -1
                    sar.iloc[i] = ep
                    ep = data['low'].iloc[i]
                    af = 0.02
                else:
                    if data['high'].iloc[i] > ep:
                        ep = data['high'].iloc[i]
                        af = min(af + 0.02, max_af)
            else:
                sar.iloc[i] = sar.iloc[i-1] - af * (sar.iloc[i-1] - ep)
                if data['high'].iloc[i] > sar.iloc[i]:
                    trend = 1
                    signals.iloc[i] = 1
                    sar.iloc[i] = ep
                    ep = data['high'].iloc[i]
                    af = 0.02
                else:
                    if data['low'].iloc[i] < ep:
                        ep = data['low'].iloc[i]
                        af = min(af + 0.02, max_af)
        
        return signals
    
    def ichimoku_cloud(self, data):
        """Ichimoku Cloud - Multiple timeframe analysis"""
        # Tenkan-sen (Conversion Line)
        high_9 = data['high'].rolling(window=9).max()
        low_9 = data['low'].rolling(window=9).min()
        tenkan = (high_9 + low_9) / 2
        
        # Kijun-sen (Base Line)
        high_26 = data['high'].rolling(window=26).max()
        low_26 = data['low'].rolling(window=26).min()
        kijun = (high_26 + low_26) / 2
        
        # Senkou Span A (Leading Span A)
        senkou_a = ((tenkan + kijun) / 2).shift(26)
        
        # Senkou Span B (Leading Span B)
        high_52 = data['high'].rolling(window=52).max()
        low_52 = data['low'].rolling(window=52).min()
        senkou_b = ((high_52 + low_52) / 2).shift(26)
        
        signals = pd.Series(0, index=data.index)
        # Buy when price above cloud and tenkan crosses above kijun
        signals[(data['close'] > senkou_a) & (data['close'] > senkou_b) &]
                (tenkan > kijun) & (tenkan.shift(1) <= kijun.shift(1)] = 1)
        # Sell when price below cloud and tenkan crosses below kijun
        signals[(data['close'] < senkou_a) & (data['close'] < senkou_b) &]
                (tenkan < kijun) & (tenkan.shift(1) >= kijun.shift(1)] = -1)
        
        return signals
    
    def volume_breakout(self, data):
        """Volume Breakout - Trade on high volume moves"""
        avg_volume = data['volume'].rolling(window=20).mean()
        volume_ratio = data['volume'] / avg_volume
        price_change = data['close'].pct_change()
        
        signals = pd.Series(0, index=data.index)
        # Buy on high volume up move
        signals[(volume_ratio > 2) & (price_change > 0.02)] = 1
        # Sell on high volume down move
        signals[(volume_ratio > 2) & (price_change < -0.02)] = -1
        return signals
    
    def support_resistance(self, data):
        """Support/Resistance - Trade bounces and breakouts"""
        # Find local highs and lows
        window = 20
        resistance = data['high'].rolling(window).max()
        support = data['low'].rolling(window).min()
        
        signals = pd.Series(0, index=data.index)
        # Buy at support
        signals[(data['low'] <= support * 1.01) & (data['close'] > support)] = 1
        # Sell at resistance
        signals[(data['high'] >= resistance * 0.99) & (data['close'] < resistance)] = -1
        return signals
    
    def fibonacci_retracement(self, data):
        """Fibonacci Retracement - Trade key fib levels"""
        # Find recent swing high/low
        window = 50
        recent_high = data['high'].rolling(window).max()
        recent_low = data['low'].rolling(window).min()
        
        # Key Fibonacci levels
        diff = recent_high - recent_low
        fib_382 = recent_high - (0.382 * diff)
        fib_500 = recent_high - (0.500 * diff)
        fib_618 = recent_high - (0.618 * diff)
        
        signals = pd.Series(0, index=data.index)
        # Buy at fibonacci support levels
        signals[(data['low'] <= fib_618 * 1.01) & (data['close'] > fib_618)] = 1
        signals[(data['low'] <= fib_500 * 1.01) & (data['close'] > fib_500)] = 1
        # Sell at fibonacci resistance (0.382 retracement)
        signals[(data['high'] >= fib_382 * 0.99) & (data['close'] < fib_382)] = -1
        return signals
    
    def pivot_points(self, data):
        """Pivot Points - Intraday support/resistance"""
        # Calculate pivot points
        pivot = (data['high'].shift(1) + data['low'].shift(1) + data['close'].shift(1) / 3)
        r1 = 2 * pivot - data['low'].shift(1)
        s1 = 2 * pivot - data['high'].shift(1)
        r2 = pivot + (data['high'].shift(1) - data['low'].shift(1)
        s2 = pivot - (data['high'].shift(1) - data['low'].shift(1)
        
        signals = pd.Series(0, index=data.index)
        # Buy at support levels
        signals[(data['low'] <= s1) & (data['close'] > s1)] = 1
        signals[(data['low'] <= s2) & (data['close'] > s2)] = 1
        # Sell at resistance levels
        signals[(data['high'] >= r1) & (data['close'] < r1)] = -1
        signals[(data['high'] >= r2) & (data['close'] < r2)] = -1
        return signals
    
    def trend_following(self, data):
        """Trend Following - Simple trend system"""
        fast_ma = data['close'].rolling(window=20).mean()
        slow_ma = data['close'].rolling(window=50).mean()
        
        # Calculate trend strength
        trend = (fast_ma - slow_ma) / slow_ma
        
        signals = pd.Series(0, index=data.index)
        # Strong uptrend
        signals[(trend > 0.02) & (trend > trend.shift(1)] = 1)
        # Strong downtrend
        signals[(trend < -0.02) & (trend < trend.shift(1)] = -1)
        return signals
    
    def channel_breakout(self, data):
        """Channel Breakout - Donchian channel"""
        period = 20
        upper_channel = data['high'].rolling(window=period).max()
        lower_channel = data['low'].rolling(window=period).min()
        
        signals = pd.Series(0, index=data.index)
        # Buy on upper channel breakout
        signals[data['close'] > upper_channel.shift(1)] = 1
        # Sell on lower channel breakdown
        signals[data['close'] < lower_channel.shift(1)] = -1
        return signals
    
    def atr_trailing_stop(self, data):
        """ATR Trailing Stop - Dynamic stop loss"""
        high_low = data['high'] - data['low']
        high_close = (data['high'] - data['close'].shift().abs()
        low_close = (data['low'] - data['close'].shift().abs()
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr = true_range.rolling(window=14).mean()
        
        # Calculate trailing stops
        long_stop = data['close'] - (2 * atr)
        short_stop = data['close'] + (2 * atr)
        
        signals = pd.Series(0, index=data.index)
        # Track position
        position = 0
        for i in range(1, len(data):
            if position == 0:
                # Enter long if close > previous high
                if data['close'].iloc[i] > data['high'].iloc[i-1]:
                    signals.iloc[i] = 1
                    position = 1
                # Enter short if close < previous low
                elif data['close'].iloc[i] < data['low'].iloc[i-1]:
                    signals.iloc[i] = -1
                    position = -1
            elif position == 1:
                # Exit long if stop hit
                if data['low'].iloc[i] < long_stop.iloc[i-1]:
                    signals.iloc[i] = -1
                    position = 0
            elif position == -1:
                # Exit short if stop hit
                if data['high'].iloc[i] > short_stop.iloc[i-1]:
                    signals.iloc[i] = 1
                    position = 0
        
        return signals
    
    # === STATISTICAL ALGORITHMS (12 algorithms) ===
    
    def mean_reversion(self, data):
        """Mean Reversion - Trade extremes back to mean"""
        lookback = 20
        mean = data['close'].rolling(window=lookback).mean()
        std = data['close'].rolling(window=lookback).std()
        z_score = (data['close'] - mean) / std
        
        signals = pd.Series(0, index=data.index)
        signals[z_score < -2] = 1  # Buy when 2 std below mean
        signals[z_score > 2] = -1  # Sell when 2 std above mean
        return signals
    
    def momentum_alpha(self, data):
        """Momentum Alpha - Trade acceleration"""
        returns = data['close'].pct_change()
        momentum = returns.rolling(window=20).mean()
        acceleration = momentum - momentum.shift(5)
        
        signals = pd.Series(0, index=data.index)
        # Buy positive and accelerating momentum
        signals[(momentum > 0.001) & (acceleration > 0)] = 1
        # Sell negative and decelerating momentum
        signals[(momentum < -0.001) & (acceleration < 0)] = -1
        return signals
    
    def pairs_trading(self, data):
        """Pairs Trading - Statistical arbitrage"""
        # Simulate pairs trading using price vs moving average
        lookback = 60
        ma = data['close'].rolling(window=lookback).mean()
        spread = data['close'] - ma
        spread_mean = spread.rolling(window=30).mean()
        spread_std = spread.rolling(window=30).std()
        z_score = (spread - spread_mean) / spread_std
        
        signals = pd.Series(0, index=data.index)
        signals[z_score < -1.5] = 1  # Buy when spread too low
        signals[z_score > 1.5] = -1  # Sell when spread too high
        return signals
    
    def cointegration(self, data):
        """Cointegration - Long-term mean reversion"""
        # Use log prices for cointegration
        log_price = np.log(data['close'])
        trend = pd.Series(range(len(log_price), index=log_price.index)
        
        # Detrend the series
        detrended = log_price - (trend * 0.0001)  # Small trend adjustment
        mean = detrended.rolling(window=100).mean()
        
        signals = pd.Series(0, index=data.index)
        signals[detrended < mean - 0.05] = 1
        signals[detrended > mean + 0.05] = -1
        return signals
    
    def garch_volatility(self, data):
        """GARCH Volatility - Trade volatility patterns"""
        returns = data['close'].pct_change()
        
        # Simple GARCH approximation
        vol = returns.rolling(window=20).std()
        vol_mean = vol.rolling(window=60).mean()
        
        signals = pd.Series(0, index=data.index)
        # Buy when volatility is low (mean reverting)
        signals[(vol < vol_mean * 0.8) & (returns > 0)] = 1
        # Sell when volatility spikes
        signals[(vol > vol_mean * 1.5) & (returns < 0)] = -1
        return signals
    
    def kalman_filter(self, data):
        """Kalman Filter - Optimal state estimation"""
        # Simplified Kalman filter using adaptive moving average
        prices = data['close'].values
        filtered = pd.Series(index=data.index, dtype=float)
        
        # Initialize
        filtered.iloc[0] = prices[0]
        error = 1.0
        
        for i in range(1, len(prices):
            # Predict
            prediction = filtered.iloc[i-1]
            
            # Update
            gain = error / (error + 0.1)  # Kalman gain
            filtered.iloc[i] = prediction + gain * (prices[i] - prediction)
            error = (1 - gain) * error + 0.01  # Process noise
        
        signals = pd.Series(0, index=data.index)
        # Trade crossovers
        signals[(data['close'] > filtered) & (data['close'].shift(1) <= filtered.shift(1)] = 1)
        signals[(data['close'] < filtered) & (data['close'].shift(1) >= filtered.shift(1)] = -1)
        return signals
    
    def statistical_arbitrage(self, data):
        """Statistical Arbitrage - Multiple statistical edges"""
        # Combine multiple statistical measures
        returns = data['close'].pct_change()
        
        # Autocorrelation
        autocorr = returns.rolling(window=20).apply(lambda x: x.autocorr(lag=1)
        
        # Skewness
        skew = returns.rolling(window=20).skew()
        
        # Kurtosis
        kurt = returns.rolling(window=20).kurt()
        
        signals = pd.Series(0, index=data.index)
        # Buy negative autocorrelation with positive skew
        signals[(autocorr < -0.2) & (skew > 0.5)] = 1
        # Sell positive autocorrelation with negative skew
        signals[(autocorr > 0.2) & (skew < -0.5)] = -1
        return signals
    
    def factor_model(self, data):
        """Factor Model - Multi-factor approach"""
        # Simple multi-factor model
        value_factor = 1 / data['close']  # Inverse price as value proxy
        momentum_factor = data['close'].pct_change(20)  # 20-day momentum
        quality_factor = data['volume'] / data['volume'].rolling(50).mean()  # Volume consistency
        
        # Normalize factors
        value_z = (value_factor - value_factor.rolling(100).mean() / value_factor.rolling(100).std())
        momentum_z = (momentum_factor - momentum_factor.rolling(100).mean() / momentum_factor.rolling(100).std())
        quality_z = (quality_factor - quality_factor.rolling(100).mean() / quality_factor.rolling(100).std())
        
        # Composite score
        score = value_z + momentum_z - quality_z
        
        signals = pd.Series(0, index=data.index)
        signals[score > 1.5] = 1
        signals[score < -1.5] = -1
        return signals
    
    def pca_strategy(self, data):
        """PCA Strategy - Principal component analysis"""
        # Create multiple features
        features = pd.DataFrame({)
            'returns_5': data['close'].pct_change(5),
            'returns_10': data['close'].pct_change(10),
            'returns_20': data['close'].pct_change(20),
            'volume_ratio': data['volume'] / data['volume'].rolling(20).mean(),
            'range': (data['high'] - data['low']) / data['close']
        }, index=data.index)
        
        # Simple PCA approximation - combine features
        pc1 = features['returns_5'] * 0.4 + features['returns_10'] * 0.3 + features['returns_20'] * 0.3
        
        signals = pd.Series(0, index=data.index)
        signals[pc1 > pc1.rolling(50).mean() + pc1.rolling(50).std()] = 1
        signals[pc1 < pc1.rolling(50).mean() - pc1.rolling(50).std()] = -1
        return signals
    
    def regime_switching(self, data):
        """Regime Switching - Adapt to market regimes"""
        returns = data['close'].pct_change()
        vol = returns.rolling(window=20).std()
        
        # Define regimes
        low_vol_regime = vol < vol.rolling(100).quantile(0.3)
        high_vol_regime = vol > vol.rolling(100).quantile(0.7)
        
        # Different strategies for different regimes
        signals = pd.Series(0, index=data.index)
        
        # Low volatility - trend following
        trend = data['close'].rolling(20).mean()
        signals[low_vol_regime & (data['close'] > trend)] = 1
        signals[low_vol_regime & (data['close'] < trend)] = -1
        
        # High volatility - mean reversion
        z_score = (data['close'] - data['close'].rolling(10).mean() / data['close'].rolling(10).std())
        signals[high_vol_regime & (z_score < -1)] = 1
        signals[high_vol_regime & (z_score > 1)] = -1
        
        return signals
    
    def bayesian_inference(self, data):
        """Bayesian Inference - Probabilistic approach"""
        returns = data['close'].pct_change()
        
        # Prior: historical return distribution
        prior_mean = returns.rolling(100).mean()
        prior_std = returns.rolling(100).std()
        
        # Likelihood: recent returns
        recent_mean = returns.rolling(10).mean()
        
        # Posterior (simplified)
        weight = 0.2  # Weight on recent data
        posterior_mean = (1 - weight) * prior_mean + weight * recent_mean
        
        signals = pd.Series(0, index=data.index)
        # Buy when posterior suggests positive returns
        signals[posterior_mean > prior_std * 0.5] = 1
        # Sell when posterior suggests negative returns
        signals[posterior_mean < -prior_std * 0.5] = -1
        return signals
    
    def time_series_momentum(self, data):
        """Time Series Momentum - Cross-sectional momentum"""
        # Multiple lookback periods
        mom_1m = data['close'].pct_change(20)
        mom_3m = data['close'].pct_change(60)
        mom_6m = data['close'].pct_change(120)
        
        # Weighted momentum score
        momentum_score = mom_1m * 0.5 + mom_3m * 0.3 + mom_6m * 0.2
        
        signals = pd.Series(0, index=data.index)
        # Buy strong momentum
        signals[momentum_score > 0.1] = 1
        # Sell weak momentum
        signals[momentum_score < -0.1] = -1
        return signals
    
    # === MACHINE LEARNING ALGORITHMS (12 algorithms) ===
    
    def neural_network(self, data):
        """Neural Network - Multi-layer perceptron simulation"""
        # Input features
        rsi = self.calculate_rsi(data['close'])
        macd = data['close'].ewm(span=12).mean() - data['close'].ewm(span=26).mean()
        bb_width = (data['close'].rolling(20).mean() + 2*data['close'].rolling(20).std() - \)
                   (data['close'].rolling(20).mean() - 2*data['close'].rolling(20).std())
        volume_ratio = data['volume'] / data['volume'].rolling(20).mean()
        
        # Normalize inputs
        rsi_norm = (rsi - 50) / 50
        macd_norm = macd / data['close'].rolling(20).std()
        bb_norm = bb_width / data['close']
        vol_norm = (volume_ratio - 1) / 2
        
        # Hidden layer (tanh activation)
        hidden1 = np.tanh(rsi_norm * 0.3 + macd_norm * 0.3 + bb_norm * 0.2 + vol_norm * 0.2)
        hidden2 = np.tanh(rsi_norm * -0.2 + macd_norm * 0.4 + bb_norm * -0.1 + vol_norm * 0.3)
        
        # Output layer
        output = hidden1 * 0.6 + hidden2 * 0.4
        
        signals = pd.Series(0, index=data.index)
        signals[output > 0.3] = 1
        signals[output < -0.3] = -1
        return signals
    
    def random_forest(self, data):
        """Random Forest - Ensemble of decision trees"""
        # Multiple decision rules (trees)
        returns = data['close'].pct_change()
        
        # Tree 1: Momentum
        tree1 = pd.Series(0, index=data.index)
        tree1[(returns.rolling(5).mean() > 0) & (returns.rolling(20).mean() > 0)] = 1
        tree1[(returns.rolling(5).mean() < 0) & (returns.rolling(20).mean() < 0)] = -1
        
        # Tree 2: Mean reversion
        z_score = (data['close'] - data['close'].rolling(20).mean() / data['close'].rolling(20).std())
        tree2 = pd.Series(0, index=data.index)
        tree2[z_score < -1.5] = 1
        tree2[z_score > 1.5] = -1
        
        # Tree 3: Volume
        vol_ratio = data['volume'] / data['volume'].rolling(20).mean()
        tree3 = pd.Series(0, index=data.index)
        tree3[(vol_ratio > 1.5) & (returns > 0)] = 1
        tree3[(vol_ratio > 1.5) & (returns < 0)] = -1
        
        # Ensemble vote
        ensemble = (tree1 + tree2 + tree3) / 3
        
        signals = pd.Series(0, index=data.index)
        signals[ensemble > 0.5] = 1
        signals[ensemble < -0.5] = -1
        return signals
    
    def svm_classifier(self, data):
        """SVM Classifier - Support vector machine"""
        # Define support vectors (price levels)
        window = 50
        resistance = data['high'].rolling(window).max()
        support = data['low'].rolling(window).min()
        midpoint = (resistance + support) / 2
        
        # Distance from hyperplane
        distance = (data['close'] - midpoint) / (resistance - support)
        
        # Classify based on distance and momentum
        momentum = data['close'].pct_change(10)
        
        signals = pd.Series(0, index=data.index)
        # Buy when below midpoint with positive momentum
        signals[(distance < -0.2) & (momentum > 0)] = 1
        # Sell when above midpoint with negative momentum
        signals[(distance > 0.2) & (momentum < 0)] = -1
        return signals
    
    def xgboost(self, data):
        """XGBoost - Gradient boosting simulation"""
        # Feature engineering
        features = pd.DataFrame({)
            'rsi': self.calculate_rsi(data['close']),
            'returns_5': data['close'].pct_change(5),
            'returns_20': data['close'].pct_change(20),
            'volume_change': data['volume'].pct_change(),
            'high_low_ratio': (data['high'] - data['low']) / data['close'],
            'close_to_high': (data['close'] - data['low']) / (data['high'] - data['low'])
        }, index=data.index)
        
        # Gradient boosting approximation
        # Stage 1: RSI predictor
        stage1 = pd.Series(0, index=data.index)
        stage1[features['rsi'] < 30] = 0.3
        stage1[features['rsi'] > 70] = -0.3
        
        # Stage 2: Momentum predictor (boosting on residuals)
        stage2 = pd.Series(0, index=data.index)
        stage2[features['returns_5'] > 0.02] = 0.2
        stage2[features['returns_5'] < -0.02] = -0.2
        
        # Stage 3: Volume predictor
        stage3 = pd.Series(0, index=data.index)
        stage3[features['volume_change'] > 0.5] = 0.1
        stage3[features['volume_change'] < -0.5] = -0.1
        
        # Combined prediction
        prediction = stage1 + stage2 + stage3
        
        signals = pd.Series(0, index=data.index)
        signals[prediction > 0.3] = 1
        signals[prediction < -0.3] = -1
        return signals
    
    def lstm_prediction(self, data):
        """LSTM Prediction - Long short-term memory patterns"""
        # Simulate LSTM with multiple time dependencies
        close_prices = data['close']
        
        # Short-term memory (recent 5 days)
        short_memory = close_prices.rolling(5).mean()
        short_trend = (short_memory - short_memory.shift(5) / short_memory.shift(5)
        
        # Long-term memory (20 days)
        long_memory = close_prices.rolling(20).mean()
        long_trend = (long_memory - long_memory.shift(20) / long_memory.shift(20)
        
        # Forget gate (volatility filter)
        volatility = close_prices.pct_change().rolling(10).std()
        forget_factor = 1 / (1 + volatility * 10)  # High vol = forget more
        
        # Cell state
        cell_state = short_trend * forget_factor + long_trend * (1 - forget_factor)
        
        signals = pd.Series(0, index=data.index)
        signals[cell_state > 0.02] = 1
        signals[cell_state < -0.02] = -1
        return signals
    
    def reinforcement_learning(self, data):
        """Reinforcement Learning - Q-learning approximation"""
        # States based on price position
        sma = data['close'].rolling(20).mean()
        position = (data['close'] - sma) / sma
        
        # Define states
        states = pd.cut(position, bins=[-np.inf, -0.02, 0.02, np.inf], labels=['low', 'neutral', 'high'])
        
        # Action values (simplified Q-table)
        signals = pd.Series(0, index=data.index)
        
        # Rewards based on future returns
        future_returns = data['close'].pct_change().shift(-5)
        
        # Learn from past rewards
        for i in range(20, len(data)-5):
            current_state = states.iloc[i]
            
            if current_state == 'low':
                # Usually buy in low state
                if future_returns.iloc[i-5:i].mean() > 0:
                    signals.iloc[i] = 1
            elif current_state == 'high':
                # Usually sell in high state
                if future_returns.iloc[i-5:i].mean() < 0:
                    signals.iloc[i] = -1
        
        return signals
    
    def deep_q_network(self, data):
        """Deep Q-Network - DQN trading agent"""
        # State representation
        returns = data['close'].pct_change()
        
        # Features for state
        state_features = pd.DataFrame({)
            'price_norm': (data['close'] - data['close'].rolling(50).mean() / data['close'].rolling(50).std(),)
            'volume_norm': (data['volume'] - data['volume'].rolling(50).mean() / data['volume'].rolling(50).std(),)
            'rsi_norm': (self.calculate_rsi(data['close']) - 50) / 50,
            'returns_5': returns.rolling(5).mean(),
            'returns_20': returns.rolling(20).mean()
        }, index=data.index)
        
        # Deep network approximation
        layer1 = np.tanh(state_features['price_norm'] * 0.3 + state_features['rsi_norm'] * 0.4)
        layer2 = np.tanh(layer1 * 0.5 + state_features['returns_5'] * 100)
        
        # Q-values for actions
        q_buy = layer2 + state_features['returns_20'] * 50
        q_sell = -layer2 - state_features['returns_20'] * 50
        q_hold = pd.Series(0, index=data.index)
        
        signals = pd.Series(0, index=data.index)
        # Choose action with highest Q-value
        for i in range(len(data):
            if q_buy.iloc[i] > q_sell.iloc[i] and q_buy.iloc[i] > q_hold.iloc[i]:
                signals.iloc[i] = 1
            elif q_sell.iloc[i] > q_buy.iloc[i] and q_sell.iloc[i] > q_hold.iloc[i]:
                signals.iloc[i] = -1
        
        return signals
    
    def genetic_algorithm(self, data):
        """Genetic Algorithm - Evolving trading rules"""
        # Define genes (trading rules)
        returns = data['close'].pct_change()
        
        # Gene pool
        gene1 = data['close'] > data['close'].rolling(10).mean()  # MA crossover
        gene2 = self.calculate_rsi(data['close']) < 40  # RSI oversold
        gene3 = data['volume'] > data['volume'].rolling(20).mean() * 1.5  # Volume spike
        gene4 = returns.rolling(5).mean() > 0  # Short momentum
        gene5 = (data['high'] - data['low']) / data['close'] > 0.02  # High volatility
        
        # Fitness based on historical performance (simplified)
        fitness1 = returns.shift(-1).where(gene1).sum()
        fitness2 = returns.shift(-1).where(gene2).sum()
        fitness3 = returns.shift(-1).where(gene3).sum()
        
        # Select best genes
        best_genes = []
        if fitness1 > 0: best_genes.append(gene1)
        if fitness2 > 0: best_genes.append(gene2)
        if fitness3 > 0: best_genes.append(gene3)
        
        signals = pd.Series(0, index=data.index)
        
        # Crossover - combine best genes
        if len(best_genes) >= 2:
            combined = sum(best_genes) >= 2  # At least 2 genes must be true
            signals[combined] = 1
        
        # Mutation - opposite signals
        mutation = gene4 & gene5
        signals[mutation] = -1
        
        return signals
    
    def ensemble_learning(self, data):
        """Ensemble Learning - Combine multiple models"""
        # Get predictions from multiple models
        rsi_signal = self.rsi_oversold(data)
        macd_signal = self.macd_crossover(data)
        mean_rev_signal = self.mean_reversion(data)
        
        # Weighted ensemble
        ensemble_score = (rsi_signal * 0.3 + macd_signal * 0.4 + mean_rev_signal * 0.3)
        
        # Meta-learner: adjust weights based on recent performance
        returns = data['close'].pct_change()
        
        # Track model performance
        rsi_perf = (returns * rsi_signal.shift(1).rolling(20).sum()
        macd_perf = (returns * macd_signal.shift(1).rolling(20).sum()
        mean_perf = (returns * mean_rev_signal.shift(1).rolling(20).sum()
        
        # Dynamic weighting
        total_perf = rsi_perf.abs() + macd_perf.abs() + mean_perf.abs()
        w1 = rsi_perf.abs() / total_perf
        w2 = macd_perf.abs() / total_perf
        w3 = mean_perf.abs() / total_perf
        
        # Apply dynamic weights
        dynamic_ensemble = rsi_signal * w1 + macd_signal * w2 + mean_rev_signal * w3
        
        signals = pd.Series(0, index=data.index)
        signals[dynamic_ensemble > 0.5] = 1
        signals[dynamic_ensemble < -0.5] = -1
        return signals
    
    def online_learning(self, data):
        """Online Learning - Adaptive learning"""
        returns = data['close'].pct_change()
        
        # Initialize weights
        w_momentum = 0.5
        w_mean_rev = 0.5
        learning_rate = 0.01
        
        signals = pd.Series(0, index=data.index)
        
        # Features
        momentum = returns.rolling(10).mean()
        mean_rev = (data['close'] - data['close'].rolling(20).mean() / data['close'].rolling(20).std())
        
        for i in range(20, len(data)-1):
            # Make prediction
            prediction = w_momentum * momentum.iloc[i] * 100 - w_mean_rev * mean_rev.iloc[i] * 0.5
            
            if prediction > 0.01:
                signals.iloc[i] = 1
            elif prediction < -0.01:
                signals.iloc[i] = -1
            
            # Update weights based on outcome
            actual_return = returns.iloc[i+1]
            error = actual_return - prediction
            
            # Gradient descent update
            w_momentum += learning_rate * error * momentum.iloc[i]
            w_mean_rev += learning_rate * error * (-mean_rev.iloc[i])
            
            # Constrain weights
            w_momentum = max(0, min(1, w_momentum)
            w_mean_rev = max(0, min(1, w_mean_rev)
        
        return signals
    
    def transfer_learning(self, data):
        """Transfer Learning - Apply learned patterns"""
        # Pre-trained patterns (from other markets/timeframes)
        
        # Pattern 1: V-shape recovery
        rolling_min = data['low'].rolling(10).min()
        v_shape = (data['low'] == rolling_min) & (data['close'] > data['open'])
        
        # Pattern 2: Breakout pattern
        resistance = data['high'].rolling(20).max()
        breakout = (data['close'] > resistance) & (data['volume'] > data['volume'].rolling(20).mean())
        
        # Pattern 3: Reversal pattern
        rsi = self.calculate_rsi(data['close'])
        reversal = ((rsi < 30) & (data['close'] > data['open']) | ((rsi > 70) & (data['close'] < data['open'])
        
        # Transfer weights (pre-learned importance)
        w1, w2, w3 = 0.4, 0.3, 0.3
        
        signals = pd.Series(0, index=data.index)
        signals[v_shape] = w1
        signals[breakout] += w2
        signals[reversal] -= w3
        
        # Threshold for signals
        signals[signals > 0.3] = 1
        signals[signals < -0.3] = -1
        signals[(signals != 1) & (signals != -1)] = 0
        
        return signals
    
    def autoencoder_anomaly(self, data):
        """Autoencoder Anomaly - Detect unusual patterns"""
        # Encode market features
        features = pd.DataFrame({)
            'returns': data['close'].pct_change(),
            'volume_ratio': data['volume'] / data['volume'].rolling(20).mean(),
            'high_low': (data['high'] - data['low']) / data['close'],
            'close_open': (data['close'] - data['open']) / data['open']
        }, index=data.index)
        
        # Normalize
        normalized = (features - features.rolling(50).mean() / features.rolling(50).std())
        
        # Encoding (compression)
        encoded = normalized['returns'] * 0.4 + normalized['volume_ratio'] * 0.3 + normalized['high_low'] * 0.3
        
        # Decoding (reconstruction)
        reconstructed_returns = encoded * 0.4
        reconstructed_volume = encoded * 0.3
        
        # Reconstruction error
        error = ((normalized['returns'] - reconstructed_returns)**2 +)
                (normalized['volume_ratio'] - reconstructed_volume)**2)
        
        # High error = anomaly
        anomaly_threshold = error.rolling(50).mean() + 2 * error.rolling(50).std()
        
        signals = pd.Series(0, index=data.index)
        # Trade on anomalies
        signals[(error > anomaly_threshold) & (features['returns'] > 0)] = 1
        signals[(error > anomaly_threshold) & (features['returns'] < 0)] = -1
        
        return signals
    
    # === OPTIONS ALGORITHMS (16 algorithms) ===
    
    def delta_neutral(self, data):
        """Delta Neutral - Hedged position"""
        # Simulate delta using price sensitivity
        price_change = data['close'].pct_change()
        volatility = price_change.rolling(20).std()
        
        # Delta approximation (option-like behavior)
        moneyness = (data['close'] - data['close'].rolling(50).mean() / data['close'])
        delta = 0.5 + moneyness * 2  # Simplified delta
        
        signals = pd.Series(0, index=data.index)
        # Adjust position when delta deviates from neutral
        signals[delta > 0.6] = -1  # Reduce exposure
        signals[delta < 0.4] = 1   # Increase exposure
        return signals
    
    def gamma_scalping(self, data):
        """Gamma Scalping - Trade gamma exposure"""
        # Gamma is rate of change of delta
        price = data['close']
        returns = price.pct_change()
        
        # Simulate gamma using acceleration of price
        price_velocity = returns
        price_acceleration = price_velocity.diff()
        
        # Gamma approximation
        gamma = price_acceleration.rolling(10).mean()
        
        signals = pd.Series(0, index=data.index)
        # Scalp when gamma is high
        signals[(gamma > gamma.rolling(50).std() & (returns > 0)] = -1  # Sell into strength)
        signals[(gamma < -gamma.rolling(50).std() & (returns < 0)] = 1  # Buy into weakness)
        return signals
    
    def theta_decay(self, data):
        """Theta Decay - Time decay strategies"""
        # Simulate time decay using volatility decay
        volatility = data['close'].pct_change().rolling(20).std()
        vol_ma = volatility.rolling(60).mean()
        
        # Theta increases as volatility decreases
        theta_proxy = (vol_ma - volatility) / vol_ma
        
        signals = pd.Series(0, index=data.index)
        # Sell when theta decay is high (low volatility)
        signals[theta_proxy > 0.2] = -1
        # Buy when expecting volatility expansion
        signals[volatility < volatility.rolling(100).quantile(0.1)] = 1
        return signals
    
    def vega_trading(self, data):
        """Vega Trading - Volatility exposure"""
        # Calculate implied volatility proxy
        high_low_range = (data['high'] - data['low']) / data['close']
        iv_proxy = high_low_range.rolling(20).mean()
        
        # Historical volatility
        hv = data['close'].pct_change().rolling(20).std()
        
        # Volatility premium
        vol_premium = iv_proxy - hv
        
        signals = pd.Series(0, index=data.index)
        # Buy volatility when cheap
        signals[vol_premium < -vol_premium.rolling(100).std()] = 1
        # Sell volatility when expensive
        signals[vol_premium > vol_premium.rolling(100).std()] = -1
        return signals
    
    def iron_condor(self, data):
        """Iron Condor - Range-bound strategy"""
        # Define expected range
        atr = self.calculate_atr(data)
        current_price = data['close']
        upper_bound = current_price + 2 * atr
        lower_bound = current_price - 2 * atr
        
        # Check if price is in profitable range
        sma = current_price.rolling(20).mean()
        in_range = (current_price < sma * 1.02) & (current_price > sma * 0.98)
        
        signals = pd.Series(0, index=data.index)
        # Enter when expecting range-bound movement
        volatility = current_price.pct_change().rolling(20).std()
        signals[in_range & (volatility < volatility.rolling(100).mean()] = 1)
        # Exit on breakout
        signals[(current_price > upper_bound) | (current_price < lower_bound)] = -1
        return signals
    
    def butterfly_spread(self, data):
        """Butterfly Spread - Low volatility bet"""
        # Target price (at the money)
        target = data['close'].rolling(20).mean()
        distance = abs(data['close'] - target) / target
        
        # Volatility assessment
        vol = data['close'].pct_change().rolling(20).std()
        low_vol = vol < vol.rolling(60).mean()
        
        signals = pd.Series(0, index=data.index)
        # Enter when near target with low vol
        signals[(distance < 0.01) & low_vol] = 1
        # Exit when moving away from target
        signals[distance > 0.03] = -1
        return signals
    
    def calendar_spread(self, data):
        """Calendar Spread - Time structure trade"""
        # Short-term vs long-term volatility
        short_vol = data['close'].pct_change().rolling(10).std()
        long_vol = data['close'].pct_change().rolling(30).std()
        
        # Term structure
        term_structure = short_vol - long_vol
        
        signals = pd.Series(0, index=data.index)
        # Buy when short-term vol low relative to long-term
        signals[term_structure < -term_structure.rolling(50).std()] = 1
        # Sell when short-term vol high
        signals[term_structure > term_structure.rolling(50).std()] = -1
        return signals
    
    def diagonal_spread(self, data):
        """Diagonal Spread - Combined directional and volatility"""
        # Directional component
        trend = data['close'].rolling(20).mean()
        direction = (data['close'] - trend) / trend
        
        # Volatility component
        vol = data['close'].pct_change().rolling(20).std()
        vol_trend = vol.rolling(20).mean()
        
        signals = pd.Series(0, index=data.index)
        # Bullish diagonal - uptrend with decreasing vol
        signals[(direction > 0.01) & (vol < vol_trend)] = 1
        # Bearish diagonal
        signals[(direction < -0.01) & (vol > vol_trend)] = -1
        return signals
    
    def straddle_strangle(self, data):
        """Straddle/Strangle - Volatility expansion"""
        # Current volatility
        current_vol = data['close'].pct_change().rolling(20).std()
        
        # Volatility percentile
        vol_percentile = current_vol.rolling(252).rank(pct=True)
        
        # Volume spike (potential catalyst)
        volume_spike = data['volume'] > data['volume'].rolling(20).mean() * 2
        
        signals = pd.Series(0, index=data.index)
        # Buy volatility when it's low with volume spike
        signals[(vol_percentile < 0.2) & volume_spike] = 1
        # Sell after volatility expansion
        signals[vol_percentile > 0.8] = -1
        return signals
    
    def covered_call(self, data):
        """Covered Call - Income generation"""
        # Identify range-bound periods
        returns = data['close'].pct_change()
        rolling_range = data['high'].rolling(20).max() - data['low'].rolling(20).min()
        narrow_range = rolling_range < rolling_range.rolling(100).mean()
        
        # Slightly bullish but not breaking out
        sma = data['close'].rolling(50).mean()
        mildly_bullish = (data['close'] > sma) & (data['close'] < sma * 1.05)
        
        signals = pd.Series(0, index=data.index)
        # Enter covered call position
        signals[narrow_range & mildly_bullish] = 1
        # Exit on breakout
        signals[data['close'] > data['high'].rolling(20).max()] = -1
        return signals
    
    def protective_put(self, data):
        """Protective Put - Downside protection"""
        # Detect potential tops
        rsi = self.calculate_rsi(data['close'])
        high_rsi = rsi > 70
        
        # Price at resistance
        resistance = data['high'].rolling(50).max()
        at_resistance = data['high'] > resistance * 0.98
        
        # Volume divergence
        price_high = data['close'] == data['close'].rolling(20).max()
        volume_low = data['volume'] < data['volume'].rolling(20).mean()
        
        signals = pd.Series(0, index=data.index)
        # Buy protection at potential tops
        signals[high_rsi & at_resistance] = 1
        signals[price_high & volume_low] = 1
        # Remove protection after correction
        signals[rsi < 40] = -1
        return signals
    
    def collar_strategy(self, data):
        """Collar Strategy - Limited risk/reward"""
        # Current position relative to range
        high_52w = data['high'].rolling(252).max()
        low_52w = data['low'].rolling(252).min()
        position_in_range = (data['close'] - low_52w) / (high_52w - low_52w)
        
        signals = pd.Series(0, index=data.index)
        # Collar when in middle of range
        signals[(position_in_range > 0.4) & (position_in_range < 0.6)] = 1
        # Adjust at extremes
        signals[(position_in_range > 0.8) | (position_in_range < 0.2)] = -1
        return signals
    
    def greeks_optimization(self, data):
        """Greeks Optimization - Balance all Greeks"""
        # Simplified Greeks
        delta = (data['close'] - data['close'].rolling(20).mean() / data['close'])
        gamma = delta.diff()
        theta = -data['close'].pct_change().rolling(20).std() / 20  # Daily decay
        vega = (data['high'] - data['low']) / data['close']
        
        # Optimize: minimize risk, maximize edge
        risk_score = abs(delta) + abs(gamma) * 10 + abs(vega) * 5
        edge_score = -theta * 100  # Theta income
        
        # Combined score
        greek_score = edge_score - risk_score
        
        signals = pd.Series(0, index=data.index)
        signals[greek_score > greek_score.rolling(50).mean() + greek_score.rolling(50).std()] = 1
        signals[greek_score < greek_score.rolling(50).mean() - greek_score.rolling(50).std()] = -1
        return signals
    
    def volatility_arbitrage(self, data):
        """Volatility Arbitrage - IV vs HV"""
        # Implied volatility proxy (using high-low range)
        iv_proxy = ((data['high'] - data['low']) / data['close']).rolling(20).mean() * np.sqrt(252)
        
        # Historical volatility
        hv = data['close'].pct_change().rolling(20).std() * np.sqrt(252)
        
        # Volatility spread
        vol_spread = iv_proxy - hv
        
        signals = pd.Series(0, index=data.index)
        # Buy when IV < HV (volatility cheap)
        signals[vol_spread < -vol_spread.rolling(100).std()] = 1
        # Sell when IV > HV (volatility expensive)
        signals[vol_spread > vol_spread.rolling(100).std()] = -1
        return signals
    
    def options_flow(self, data):
        """Options Flow - Follow smart money"""
        # Simulate options flow using volume and price action
        volume_surge = data['volume'] > data['volume'].rolling(20).mean() * 1.5
        
        # Bullish flow: volume surge with price up
        bullish_flow = volume_surge & (data['close'] > data['open'])
        
        # Bearish flow: volume surge with price down
        bearish_flow = volume_surge & (data['close'] < data['open'])
        
        # Accumulation/Distribution
        flow_score = pd.Series(0, index=data.index)
        flow_score[bullish_flow] = 1
        flow_score[bearish_flow] = -1
        flow_cumulative = flow_score.rolling(10).sum()
        
        signals = pd.Series(0, index=data.index)
        signals[flow_cumulative > 3] = 1
        signals[flow_cumulative < -3] = -1
        return signals
    
    def put_call_parity(self, data):
        """Put-Call Parity - Arbitrage opportunities"""
        # Synthetic positions
        stock_price = data['close']
        
        # Forward price approximation
        risk_free_rate = 0.02  # Assumed
        time_to_expiry = 30 / 365  # 30 days
        forward_price = stock_price * (1 + risk_free_rate * time_to_expiry)
        
        # Parity deviation
        synthetic_forward = stock_price  # Simplified
        parity_deviation = (forward_price - synthetic_forward) / stock_price
        
        signals = pd.Series(0, index=data.index)
        # Arbitrage when parity violated
        signals[parity_deviation > 0.01] = 1  # Buy synthetic
        signals[parity_deviation < -0.01] = -1  # Sell synthetic
        return signals
    
    # === HFT ALGORITHMS (12 algorithms) ===
    
    def market_making(self, data):
        """Market Making - Provide liquidity"""
        # Bid-ask spread proxy
        typical_spread = (data['high'] - data['low']) / data['close']
        current_spread = typical_spread.rolling(5).mean()
        average_spread = typical_spread.rolling(50).mean()
        
        # Volume profile
        volume_profile = data['volume'] / data['volume'].rolling(20).mean()
        
        signals = pd.Series(0, index=data.index)
        # Make market when spread is wide and volume normal
        signals[(current_spread > average_spread * 1.5) & (volume_profile > 0.8)] = 1
        # Stop when spread narrows
        signals[current_spread < average_spread * 0.8] = -1
        return signals
    
    def latency_arbitrage(self, data):
        """Latency Arbitrage - Speed advantage"""
        # Simulate price discrepancies
        fast_ma = data['close'].rolling(3).mean()
        slow_ma = data['close'].rolling(10).mean()
        
        # Price momentum
        momentum = data['close'].pct_change(3)
        
        # Latency signal (fast indicator divergence)
        divergence = (fast_ma - slow_ma) / slow_ma
        
        signals = pd.Series(0, index=data.index)
        # Arbitrage opportunities
        signals[(divergence > 0.001) & (momentum > 0)] = 1
        signals[(divergence < -0.001) & (momentum < 0)] = -1
        return signals
    
    def order_flow(self, data):
        """Order Flow - Analyze order patterns"""
        # Volume-weighted price
        vwap = (data['close'] * data['volume']).rolling(20).sum() / data['volume'].rolling(20).sum()
        
        # Order flow imbalance
        buy_pressure = ((data['close'] - data['low']) / (data['high'] - data['low']) * data['volume']
        sell_pressure = ((data['high'] - data['close']) / (data['high'] - data['low']) * data['volume']
        
        flow_imbalance = (buy_pressure - sell_pressure).rolling(10).sum()
        
        signals = pd.Series(0, index=data.index)
        # Follow order flow
        signals[flow_imbalance > flow_imbalance.rolling(50).std() * 2] = 1
        signals[flow_imbalance < -flow_imbalance.rolling(50).std() * 2] = -1
        return signals
    
    def microstructure(self, data):
        """Microstructure - Market mechanics"""
        # Tick-based analysis (using close prices)
        price_changes = data['close'].diff()
        
        # Tick direction
        upticks = (price_changes > 0).rolling(10).sum()
        downticks = (price_changes < 0).rolling(10).sum()
        tick_ratio = upticks / (downticks + 1)
        
        # Trade intensity
        trade_intensity = data['volume'] / data['volume'].rolling(50).mean()
        
        signals = pd.Series(0, index=data.index)
        # Trade on microstructure signals
        signals[(tick_ratio > 2) & (trade_intensity > 1.5)] = 1
        signals[(tick_ratio < 0.5) & (trade_intensity > 1.5)] = -1
        return signals
    
    def quote_stuffing_detection(self, data):
        """Quote Stuffing Detection - Detect manipulation"""
        # Abnormal volume patterns
        volume_zscore = (data['volume'] - data['volume'].rolling(50).mean() / data['volume'].rolling(50).std())
        
        # Price efficiency
        high_low_ratio = (data['high'] - data['low']) / data['close']
        efficiency = 1 / (1 + high_low_ratio)
        
        # Stuffing indicator
        stuffing_score = volume_zscore * (1 - efficiency)
        
        signals = pd.Series(0, index=data.index)
        # Trade against manipulation
        signals[stuffing_score > 2] = -1  # Fade the move
        signals[stuffing_score < -2] = 1   # Buy the dip
        return signals
    
    def iceberg_detection(self, data):
        """Iceberg Detection - Hidden orders"""
        # Persistent pressure without price movement
        volume_ma = data['volume'].rolling(20).mean()
        price_range = (data['high'] - data['low']) / data['close']
        
        # High volume, low price movement = potential iceberg
        iceberg_score = (data['volume'] / volume_ma) / (price_range + 0.001)
        
        # Cumulative pressure
        cum_pressure = iceberg_score.rolling(5).sum()
        
        signals = pd.Series(0, index=data.index)
        # Trade with detected icebergs
        signals[cum_pressure > cum_pressure.rolling(50).quantile(0.9)] = 1
        signals[cum_pressure < cum_pressure.rolling(50).quantile(0.1)] = -1
        return signals
    
    def dark_pool_liquidity(self, data):
        """Dark Pool Liquidity - Hidden liquidity"""
        # Detect dark pool activity
        # Large price gaps with normal volume = potential dark pool
        price_gap = abs(data['open'] - data['close'].shift(1) / data['close'].shift(1)
        normal_volume = (data['volume'] > data['volume'].rolling(20).mean() * 0.8) & \
                       (data['volume'] < data['volume'].rolling(20).mean() * 1.2)
        
        dark_pool_signal = (price_gap > 0.005) & normal_volume
        
        signals = pd.Series(0, index=data.index)
        # Follow dark pool direction
        signals[dark_pool_signal & (data['close'] > data['open'])] = 1
        signals[dark_pool_signal & (data['close'] < data['open'])] = -1
        return signals
    
    def co_location(self, data):
        """Co-location - Ultra-low latency"""
        # Fastest possible signals
        tick = data['close'].diff()
        
        # Immediate momentum
        instant_momentum = tick.rolling(2).sum()
        
        # Volume confirmation
        volume_spike = data['volume'] > data['volume'].shift(1) * 1.5
        
        signals = pd.Series(0, index=data.index)
        # Ultra-fast execution
        signals[(instant_momentum > 0) & volume_spike] = 1
        signals[(instant_momentum < 0) & volume_spike] = -1
        return signals
    
    def smart_order_routing(self, data):
        """Smart Order Routing - Optimal execution"""
        # Liquidity assessment
        liquidity_score = data['volume'] / data['volume'].rolling(20).mean()
        
        # Price impact estimation
        volatility = data['close'].pct_change().rolling(10).std()
        spread = (data['high'] - data['low']) / data['close']
        impact = volatility * spread
        
        # Optimal routing score
        routing_score = liquidity_score / (1 + impact * 10)
        
        signals = pd.Series(0, index=data.index)
        # Execute when conditions optimal
        signals[routing_score > routing_score.rolling(50).quantile(0.8)] = 1
        signals[routing_score < routing_score.rolling(50).quantile(0.2)] = -1
        return signals
    
    def liquidity_provision(self, data):
        """Liquidity Provision - Passive strategies"""
        # Market depth proxy
        volume_profile = data['volume'].rolling(10).mean()
        volatility = data['close'].pct_change().rolling(10).std()
        
        # Liquidity demand
        liquidity_demand = volatility * volume_profile
        
        # Provide liquidity when profitable
        spread = (data['high'] - data['low']) / data['close']
        profitability = spread - volatility * 2
        
        signals = pd.Series(0, index=data.index)
        signals[(profitability > 0) & (liquidity_demand > liquidity_demand.rolling(50).mean()] = 1)
        signals[profitability < -0.001] = -1
        return signals
    
    def rebate_capture(self, data):
        """Rebate Capture - Exchange incentives"""
        # High-frequency small trades
        micro_volatility = data['close'].pct_change().rolling(5).std()
        
        # Ideal conditions for rebate capture
        tight_range = micro_volatility < micro_volatility.rolling(100).quantile(0.3)
        high_volume = data['volume'] > data['volume'].rolling(20).mean()
        
        # Mean reversion in tight range
        micro_zscore = (data['close'] - data['close'].rolling(5).mean() / data['close'].rolling(5).std())
        
        signals = pd.Series(0, index=data.index)
        signals[tight_range & high_volume & (micro_zscore < -1)] = 1
        signals[tight_range & high_volume & (micro_zscore > 1)] = -1
        return signals
    
    def queue_position(self, data):
        """Queue Position - Order book priority"""
        # Early detection of momentum
        early_momentum = data['close'].pct_change(3)
        
        # Volume acceleration
        volume_accel = data['volume'].diff() / data['volume'].shift(1)
        
        # Queue priority score
        priority_score = early_momentum * 100 + volume_accel
        
        signals = pd.Series(0, index=data.index)
        # Get in queue early
        signals[priority_score > priority_score.rolling(20).std()] = 1
        signals[priority_score < -priority_score.rolling(20).std()] = -1
        return signals
    
    # === ADVANCED ALGORITHMS (16 algorithms) ===
    
    def quantum_algorithm(self, data):
        """Quantum Algorithm - Superposition of states"""
        # Multiple probability states
        states = []
        
        # State 1: Momentum
        momentum_state = data['close'].pct_change(10) > 0
        states.append(momentum_state.astype(float)
        
        # State 2: Mean reversion
        zscore = (data['close'] - data['close'].rolling(20).mean() / data['close'].rolling(20).std())
        reversion_state = zscore < -1
        states.append(reversion_state.astype(float)
        
        # State 3: Volatility
        vol = data['close'].pct_change().rolling(20).std()
        vol_state = vol < vol.rolling(50).mean()
        states.append(vol_state.astype(float)
        
        # Quantum superposition (weighted combination)
        superposition = sum(states) / len(states)
        
        # Collapse to definite state
        signals = pd.Series(0, index=data.index)
        signals[superposition > 0.66] = 1
        signals[superposition < 0.33] = -1
        return signals
    
    def fractal_analysis(self, data):
        """Fractal Analysis - Self-similar patterns"""
        # Calculate fractal dimension (simplified)
        returns = data['close'].pct_change()
        
        # Multi-scale analysis
        scales = [5, 10, 20, 40]
        fractal_dims = []
        
        for scale in scales:
            # Range over scale
            high_scale = data['high'].rolling(scale).max()
            low_scale = data['low'].rolling(scale).min()
            range_scale = high_scale - low_scale
            
            # Fractal dimension approximation
            fd = np.log(scale) / np.log(range_scale / data['close'] + 1)
            fractal_dims.append(fd)
        
        # Average fractal dimension
        avg_fd = sum(fractal_dims) / len(fractal_dims)
        
        signals = pd.Series(0, index=data.index)
        # Trade based on fractal patterns
        signals[avg_fd > avg_fd.rolling(50).mean() + avg_fd.rolling(50).std()] = 1
        signals[avg_fd < avg_fd.rolling(50).mean() - avg_fd.rolling(50).std()] = -1
        return signals
    
    def chaos_theory(self, data):
        """Chaos Theory - Butterfly effect"""
        # Lyapunov exponent approximation
        returns = data['close'].pct_change()
        
        # Sensitivity to initial conditions
        small_change = returns.rolling(5).std()
        large_change = returns.rolling(20).std()
        
        # Chaos indicator
        chaos = large_change / (small_change + 0.0001)
        
        # Phase space reconstruction
        phase1 = returns
        phase2 = returns.shift(5)
        phase3 = returns.shift(10)
        
        # Strange attractor detection
        attractor = (phase1 + phase2 + phase3).rolling(20).mean()
        
        signals = pd.Series(0, index=data.index)
        # Trade at edge of chaos
        signals[(chaos > 10) & (attractor > 0)] = 1
        signals[(chaos > 10) & (attractor < 0)] = -1
        return signals
    
    def wavelet_transform(self, data):
        """Wavelet Transform - Multi-resolution analysis"""
        close = data['close']
        
        # Simplified wavelet decomposition
        # Level 1: High frequency
        hf = close - close.rolling(2).mean()
        
        # Level 2: Medium frequency
        mf = close.rolling(2).mean() - close.rolling(8).mean()
        
        # Level 3: Low frequency
        lf = close.rolling(8).mean() - close.rolling(32).mean()
        
        # Reconstruct with emphasis on different frequencies
        reconstruction = hf * 0.2 + mf * 0.5 + lf * 0.3
        
        signals = pd.Series(0, index=data.index)
        # Trade reconstructed signal
        signals[reconstruction > reconstruction.rolling(20).std()] = 1
        signals[reconstruction < -reconstruction.rolling(20).std()] = -1
        return signals
    
    def hidden_markov(self, data):
        """Hidden Markov Model - Regime detection"""
        returns = data['close'].pct_change()
        vol = returns.rolling(20).std()
        
        # Define hidden states
        # State 1: Bull market (high returns, low vol)
        bull_score = returns.rolling(20).mean() / (vol + 0.0001)
        
        # State 2: Bear market (negative returns, high vol)
        bear_score = -returns.rolling(20).mean() * vol
        
        # State 3: Sideways (low returns, low vol)
        sideways_score = 1 / (abs(returns.rolling(20).mean() + vol + 0.0001))
        
        # Determine most likely state
        signals = pd.Series(0, index=data.index)
        
        for i in range(len(data):
            scores = [bull_score.iloc[i], bear_score.iloc[i], sideways_score.iloc[i]]
            state = np.argmax(scores)
            
            if state == 0:  # Bull
                signals.iloc[i] = 1
            elif state == 1:  # Bear
                signals.iloc[i] = -1
            # Sideways = 0
        
        return signals
    
    def particle_filter(self, data):
        """Particle Filter - Monte Carlo state estimation"""
        # Generate particles (possible price paths)
        current_price = data['close']
        returns = current_price.pct_change()
        
        # Particle parameters
        vol = returns.rolling(20).std()
        drift = returns.rolling(20).mean()
        
        # Predict future state (simplified)
        prediction = current_price * (1 + drift + vol * np.random.randn()
        
        # Weight particles by likelihood
        actual_move = current_price.diff()
        predicted_move = drift * current_price
        
        # Likelihood
        error = abs(actual_move - predicted_move)
        weight = 1 / (1 + error)
        
        # Resample based on weights
        confidence = weight.rolling(10).mean()
        
        signals = pd.Series(0, index=data.index)
        # Trade high confidence predictions
        signals[(confidence > confidence.rolling(50).quantile(0.8) & (drift > 0)] = 1)
        signals[(confidence > confidence.rolling(50).quantile(0.8) & (drift < 0)] = -1)
        return signals
    
    def spectral_analysis(self, data):
        """Spectral Analysis - Frequency domain"""
        # Fourier-like decomposition
        close = data['close']
        
        # Different frequency components
        cycles = []
        for period in [5, 10, 20, 40]:
            cycle = close.rolling(period).mean() - close.rolling(period*2).mean()
            cycles.append(cycle)
        
        # Dominant frequency
        power = [c.rolling(20).std() for c in cycles]
        dominant_idx = np.argmax(power)
        dominant_cycle = cycles[dominant_idx]
        
        signals = pd.Series(0, index=data.index)
        # Trade the dominant cycle
        signals[dominant_cycle > dominant_cycle.rolling(20).std()] = 1
        signals[dominant_cycle < -dominant_cycle.rolling(20).std()] = -1
        return signals
    
    def topological_data(self, data):
        """Topological Data Analysis - Shape of data"""
        # Persistence homology (simplified)
        high = data['high']
        low = data['low']
        close = data['close']
        
        # Topological features
        # Feature 1: Holes (gaps)
        gaps = (low - high.shift(1).fillna(0)
        gap_persistence = (gaps > 0).rolling(10).sum()
        
        # Feature 2: Connectivity
        connectivity = 1 / (1 + abs(close.pct_change().rolling(20).mean()))
        
        # Feature 3: Curvature
        curvature = close.diff().diff()
        
        # Topological score
        topo_score = gap_persistence * 0.3 + connectivity * 0.4 + curvature * 100 * 0.3
        
        signals = pd.Series(0, index=data.index)
        signals[topo_score > topo_score.rolling(50).quantile(0.8)] = 1
        signals[topo_score < topo_score.rolling(50).quantile(0.2)] = -1
        return signals
    
    def graph_network(self, data):
        """Graph Network - Network effects"""
        # Build correlation network
        returns = data['close'].pct_change()
        
        # Node features
        node_momentum = returns.rolling(20).mean()
        node_volatility = returns.rolling(20).std()
        node_volume = data['volume'] / data['volume'].rolling(20).mean()
        
        # Edge features (correlations)
        edge_strength = returns.rolling(20).apply(lambda x: x.autocorr(lag=1)
        
        # Graph signal
        centrality = node_momentum * edge_strength
        
        # Community detection (simplified)
        community = centrality.rolling(50).mean()
        
        signals = pd.Series(0, index=data.index)
        # Trade based on network position
        signals[centrality > community + community.rolling(50).std()] = 1
        signals[centrality < community - community.rolling(50).std()] = -1
        return signals
    
    def transformer_model(self, data):
        """Transformer Model - Attention mechanism"""
        # Self-attention on price series
        lookback = 20
        close = data['close']
        
        # Query, Key, Value (simplified)
        query = close.rolling(5).mean()
        key = close.rolling(10).mean()
        value = close.rolling(20).mean()
        
        # Attention scores
        attention = (query - key) / (key.rolling(20).std() + 0.0001)
        
        # Apply attention to values
        attended_value = value * (1 + attention)
        
        # Multi-head (different lookbacks)
        head2 = close.rolling(15).mean() * (1 + attention)
        
        # Combine heads
        output = attended_value * 0.6 + head2 * 0.4
        
        signals = pd.Series(0, index=data.index)
        # Generate signals from transformer output
        signals[close > output * 1.01] = 1
        signals[close < output * 0.99] = -1
        return signals
    
    def attention_mechanism(self, data):
        """Attention Mechanism - Focus on important features"""
        # Multiple features
        features = {}
            'price': data['close'],
            'volume': data['volume'] / data['volume'].rolling(20).mean(),
            'volatility': data['close'].pct_change().rolling(20).std(),
            'momentum': data['close'].pct_change(10)
        }
        
        # Attention weights (learned from performance)
        weights = {}
            'price': 0.3,
            'volume': 0.2,
            'volatility': 0.2,
            'momentum': 0.3
        }
        
        # Dynamic attention (based on recent performance)
        for feature in features:
            # Adjust weights based on feature importance
            feature_signal = features[feature].rolling(20).mean()
            feature_return = data['close'].pct_change().shift(-1)
            correlation = feature_signal.rolling(50).corr(feature_return)
            weights[feature] *= (1 + correlation)
        
        # Normalize weights
        total_weight = sum(weights.values()
        weights = {k: v/total_weight for k, v in weights.items()}
        
        # Apply attention
        attended_signal = sum(features[k] * weights[k] for k in features)
        
        signals = pd.Series(0, index=data.index)
        signals[attended_signal > attended_signal.rolling(50).quantile(0.8)] = 1
        signals[attended_signal < attended_signal.rolling(50).quantile(0.2)] = -1
        return signals
    
    def meta_learning(self, data):
        """Meta Learning - Learn to learn"""
        # Track performance of multiple strategies
        strategies = {}
            'momentum': data['close'].pct_change(10),
            'mean_rev': -(data['close'] - data['close'].rolling(20).mean() / data['close'].rolling(20).std(),)
            'trend': (data['close'] - data['close'].rolling(50).mean() / data['close'].rolling(50).mean())
        }
        
        # Meta features (strategy performance)
        returns = data['close'].pct_change()
        strategy_performance = {}
        
        for name, strategy in strategies.items():
            # Calculate recent performance
            strategy_returns = (strategy.shift(1) * returns).rolling(20).sum()
            strategy_performance[name] = strategy_returns
        
        # Meta strategy: choose best performing
        signals = pd.Series(0, index=data.index)
        
        for i in range(50, len(data):
            # Find best performing strategy
            best_strategy = max(strategy_performance.items(), 
                              key=lambda x: x[1].iloc[i] if not pd.isna(x[1].iloc[i]) else -np.inf)
            
            # Use best strategy signal
            if strategies[best_strategy[0]].iloc[i] > 0:
                signals.iloc[i] = 1
            elif strategies[best_strategy[0]].iloc[i] < 0:
                signals.iloc[i] = -1
        
        return signals
    
    def federated_learning(self, data):
        """Federated Learning - Distributed learning"""
        # Simulate multiple models trained on different data aspects
        
        # Model 1: Price patterns
        model1 = pd.Series(0, index=data.index)
        price_pattern = data['close'].rolling(10).mean() > data['close'].rolling(30).mean()
        model1[price_pattern] = 1
        model1[~price_pattern] = -1
        
        # Model 2: Volume patterns
        model2 = pd.Series(0, index=data.index)
        volume_surge = data['volume'] > data['volume'].rolling(20).mean() * 1.5
        model2[volume_surge & (data['close'] > data['open'])] = 1
        model2[volume_surge & (data['close'] < data['open'])] = -1
        
        # Model 3: Volatility patterns
        model3 = pd.Series(0, index=data.index)
        vol = data['close'].pct_change().rolling(20).std()
        low_vol = vol < vol.rolling(50).quantile(0.3)
        model3[low_vol] = 1  # Buy in low vol
        model3[~low_vol] = -1
        
        # Federated aggregation (weighted average)
        # Weights based on model confidence
        conf1 = abs(data['close'].rolling(10).mean() - data['close'].rolling(30).mean() / data['close'])
        conf2 = volume_surge.rolling(10).mean()
        conf3 = 1 / (1 + vol)
        
        # Normalize confidences
        total_conf = conf1 + conf2 + conf3
        w1 = conf1 / total_conf
        w2 = conf2 / total_conf
        w3 = conf3 / total_conf
        
        # Aggregate
        federated_signal = model1 * w1 + model2 * w2 + model3 * w3
        
        signals = pd.Series(0, index=data.index)
        signals[federated_signal > 0.3] = 1
        signals[federated_signal < -0.3] = -1
        return signals
    
    def adversarial_strategy(self, data):
        """Adversarial Strategy - Game theory approach"""
        # Assume market as adversary
        returns = data['close'].pct_change()
        
        # Detect adversarial patterns
        # Pattern 1: False breakouts
        breakout = data['close'] > data['high'].rolling(20).max().shift(1)
        failed_breakout = breakout & (returns.shift(-1) < 0)
        
        # Pattern 2: Stop hunting
        recent_low = data['low'].rolling(10).min()
        stop_hunt = (data['low'] < recent_low * 0.99) & (data['close'] > recent_low)
        
        # Pattern 3: Squeeze
        volatility = returns.rolling(20).std()
        squeeze = volatility < volatility.rolling(100).quantile(0.1)
        
        # Counter-strategy
        signals = pd.Series(0, index=data.index)
        
        # Fade false breakouts
        signals[failed_breakout.shift(1)] = -1
        
        # Buy stop hunts
        signals[stop_hunt] = 1
        
        # Prepare for squeeze breakout
        signals[squeeze & (volatility > volatility.shift(1)] = 1)
        
        return signals
    
    def multi_agent(self, data):
        """Multi-Agent System - Cooperative strategies"""
        # Multiple specialized agents
        
        # Agent 1: Trend follower
        agent1 = pd.Series(0, index=data.index)
        trend = data['close'].rolling(20).mean()
        agent1[data['close'] > trend] = 1
        agent1[data['close'] < trend] = -1
        
        # Agent 2: Volatility trader
        agent2 = pd.Series(0, index=data.index)
        vol = data['close'].pct_change().rolling(20).std()
        agent2[vol > vol.rolling(50).mean()] = -1  # Sell high vol
        agent2[vol < vol.rolling(50).mean()] = 1   # Buy low vol
        
        # Agent 3: Support/Resistance
        agent3 = pd.Series(0, index=data.index)
        support = data['low'].rolling(20).min()
        resistance = data['high'].rolling(20).max()
        agent3[data['close'] <= support * 1.01] = 1
        agent3[data['close'] >= resistance * 0.99] = -1
        
        # Communication between agents (simple voting)
        votes = agent1 + agent2 + agent3
        
        # Consensus mechanism
        signals = pd.Series(0, index=data.index)
        signals[votes >= 2] = 1   # Majority buy
        signals[votes <= -2] = -1  # Majority sell
        
        return signals
    
    def adaptive_strategy(self, data):
        """Adaptive Strategy - Self-modifying algorithm"""
        returns = data['close'].pct_change()
        
        # Initialize parameters
        lookback = 20
        threshold = 0.01
        
        # Performance tracking
        signals = pd.Series(0, index=data.index)
        
        for i in range(50, len(data):
            # Current parameters
            current_signal = 0
            
            # Measure recent performance
            if i > lookback + 50:
                recent_signals = signals.iloc[i-lookback-10:i-10]
                recent_returns = returns.iloc[i-lookback-9:i-9]
                performance = (recent_signals * recent_returns).sum()
                
                # Adapt parameters based on performance
                if performance < 0:
                    # Poor performance - adjust
                    lookback = min(50, lookback + 5)
                    threshold *= 1.1
                else:
                    # Good performance - fine tune
                    lookback = max(10, lookback - 1)
                    threshold *= 0.95
            
            # Generate signal with current parameters
            ma = data['close'].iloc[i-lookback:i].mean()
            if data['close'].iloc[i] > ma * (1 + threshold):
                current_signal = 1
            elif data['close'].iloc[i] < ma * (1 - threshold):
                current_signal = -1
            
            signals.iloc[i] = current_signal
        
        return signals
    
    # Helper method for RSI calculation
    def calculate_rsi(self, prices, period=14):
        """Calculate RSI indicator"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
        rs = gain / loss.replace(0, 1e-10)
        return 100 - (100 / (1 + rs)
    
    # Helper method for ATR calculation
    def calculate_atr(self, data, period=14):
        """Calculate Average True Range"""
        high_low = data['high'] - data['low']
        high_close = (data['high'] - data['close'].shift().abs()
        low_close = (data['low'] - data['close'].shift().abs()
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return true_range.rolling(window=period).mean()


class CompleteBacktester:
    """Backtester for all algorithms"""
    
    def __init__(self):
        with open('alpaca_config.json', 'r') as f:
            config = json.load(f)
        
        self.client = TradingClient()
            config.get('paper_api_key'),
            config.get('paper_secret_key'),
            config.get('paper_base_url')
        )
        
        self.algorithms = CompleteAlgorithmSet()
        self.results = {}
    
    def fetch_data(self, symbol, start_date, end_date):
        """Fetch daily data from Alpaca"""
        bars = self.client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=start_date,
            end=end_date,
            adjustment='raw'
        ).df
        
        if not bars.empty:
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in bars.columns:
                    bars[col] = bars[col].astype(float)
        
        return bars
    
    def get_all_algorithms(self):
        """Get all algorithm names"""
        algo_methods = []
            # Technical (16)
            'rsi_oversold', 'macd_crossover', 'bollinger_squeeze', 'ema_crossover',
            'stochastic_oscillator', 'williams_r', 'adx_trend', 'parabolic_sar',
            'ichimoku_cloud', 'volume_breakout', 'support_resistance', 'fibonacci_retracement',
            'pivot_points', 'trend_following', 'channel_breakout', 'atr_trailing_stop',
            
            # Statistical (12)
            'mean_reversion', 'momentum_alpha', 'pairs_trading', 'cointegration',
            'garch_volatility', 'kalman_filter', 'statistical_arbitrage', 'factor_model',
            'pca_strategy', 'regime_switching', 'bayesian_inference', 'time_series_momentum',
            
            # ML (12)
            'neural_network', 'random_forest', 'svm_classifier', 'xgboost',
            'lstm_prediction', 'reinforcement_learning', 'deep_q_network', 'genetic_algorithm',
            'ensemble_learning', 'online_learning', 'transfer_learning', 'autoencoder_anomaly',
            
            # Options (16)
            'delta_neutral', 'gamma_scalping', 'theta_decay', 'vega_trading',
            'iron_condor', 'butterfly_spread', 'calendar_spread', 'diagonal_spread',
            'straddle_strangle', 'covered_call', 'protective_put', 'collar_strategy',
            'greeks_optimization', 'volatility_arbitrage', 'options_flow', 'put_call_parity',
            
            # HFT (12)
            'market_making', 'latency_arbitrage', 'order_flow', 'microstructure',
            'quote_stuffing_detection', 'iceberg_detection', 'dark_pool_liquidity', 'co_location',
            'smart_order_routing', 'liquidity_provision', 'rebate_capture', 'queue_position',
            
            # Advanced (16)
            'quantum_algorithm', 'fractal_analysis', 'chaos_theory', 'wavelet_transform',
            'hidden_markov', 'particle_filter', 'spectral_analysis', 'topological_data',
            'graph_network', 'transformer_model', 'attention_mechanism', 'meta_learning',
            'federated_learning', 'adversarial_strategy', 'multi_agent', 'adaptive_strategy'
        ]
        
        categories = {}
            'Technical': algo_methods[:16],
            'Statistical': algo_methods[16:28],
            'ML': algo_methods[28:40],
            'Options': algo_methods[40:56],
            'HFT': algo_methods[56:68],
            'Advanced': algo_methods[68:84]
        }
        
        return algo_methods, categories
    
    def backtest_strategy(self, data, signals, initial_capital=100000):
        """Run backtest for a single strategy"""
        cash = initial_capital
        shares = 0
        trades = []
        
        for i in range(len(data):
            if i >= len(signals):
                break
                
            current_price = data['close'].iloc[i]
            signal = signals.iloc[i]
            
            if signal == 1 and shares == 0:  # Buy
                shares = int(cash * 0.95 / current_price)
                if shares > 0:
                    cash -= shares * current_price
                    trades.append({'action': 'BUY', 'price': current_price})
            
            elif signal == -1 and shares > 0:  # Sell
                cash += shares * current_price
                trades.append({'action': 'SELL', 'price': current_price})
                shares = 0
        
        # Close position
        if shares > 0:
            cash += shares * data['close'].iloc[-1]
            trades.append({'action': 'SELL', 'price': data['close'].iloc[-1]})
        
        total_return = (cash - initial_capital) / initial_capital
        
        # Calculate win rate
        wins = 0
        if len(trades) >= 2:
            for i in range(0, len(trades)-1, 2):
                if i+1 < len(trades) and trades[i]['action'] == 'BUY' and trades[i+1]['action'] == 'SELL':
                    if trades[i+1]['price'] > trades[i]['price']:
                        wins += 1
        
        win_rate = wins / (len(trades) // 2) if len(trades) >= 2 else 0
        
        return {}
            'return': total_return,
            'trades': len(trades),
            'win_rate': win_rate,
            'final_value': cash
        }
    
    def run_complete_backtest(self, symbols, start_date, end_date):
        """Run backtest for all 84 algorithms"""
        algo_methods, categories = self.get_all_algorithms()
        
        print(f"\n{'='*120}")
        print(f"🚀 V24 COMPLETE 84 ALGORITHMS BACKTEST - UNIQUE IMPLEMENTATIONS")
        print(f"{'='*120}")
        print(f"📅 Period: {start_date} to {end_date}")
        print(f"📊 Symbols: {', '.join(symbols)}")
        print(f"🤖 Total Algorithms: {len(algo_methods)}")
        print(f"📁 Categories: {', '.join(categories.keys()}")
        print(f"{'='*120}\n")
        
        all_results = []
        
        for symbol in symbols:
            print(f"\n{'='*80}")
            print(f"📊 Processing {symbol}...")
            print(f"{'='*80}")
            
            data = self.fetch_data(symbol, start_date, end_date)
            
            if data.empty:
                print(f"❌ No data available for {symbol}")
                continue
            
            print(f"✅ Fetched {len(data)} days, price range: ${data['close'].min():.2f}-${data['close'].max():.2f}\n")
            
            for category, algos in categories.items():
                print(f"📈 {category} Algorithms ({len(algos)}):")
                
                for algo_name in algos:
                    try:
                        # Get algorithm method
                        if hasattr(self.algorithms, algo_name):
                            algo_method = getattr(self.algorithms, algo_name)
                            signals = algo_method(data)
                            
                            # Run backtest
                            results = self.backtest_strategy(data, signals)
                            
                            if results['trades'] > 0:
                                print(f"  • {algo_name}: Return={results['return']:.2%}, ")
                                      f"Trades={results['trades']}, Win Rate={results['win_rate']:.1%}")
                                
                                all_results.append({)
                                    'symbol': symbol,
                                    'category': category,
                                    'algorithm': algo_name,
                                    'return': results['return'],
                                    'trades': results['trades'],
                                    'win_rate': results['win_rate']
                                })
                            else:
                                print(f"  • {algo_name}: No trades generated")
                        else:
                            print(f"  • {algo_name}: Method not found")
                    
                    except Exception as e:
                        print(f"  • {algo_name}: Error - {str(e)[:50]}...")
                
                print()  # Blank line between categories
        
        # Generate summary
        self.generate_summary(all_results)
        
        return all_results
    
    def generate_summary(self, results):
        """Generate comprehensive summary"""
        print(f"\n{'='*120}")
        print(f"📊 COMPREHENSIVE BACKTEST SUMMARY")
        print(f"{'='*120}")
        
        if not results:
            print("No results to summarize")
            return
        
        # Group by category
        category_results = {}
        for r in results:
            cat = r['category']
            if cat not in category_results:
                category_results[cat] = []
            category_results[cat].append(r)
        
        # Category performance
        print(f"\n🏆 PERFORMANCE BY CATEGORY:")
        print(f"{'Category':<20} {'Avg Return':<15} {'Best Return':<15} {'Total Trades':<15} {'Active Algos':<15}")
        print(f"{'-'*80}")
        
        category_stats = []
        for category, cat_results in category_results.items():
            returns = [r['return'] for r in cat_results]
            trades = sum(r['trades'] for r in cat_results)
            active = len(set(r['algorithm'] for r in cat_results)
            
            avg_return = np.mean(returns) if returns else 0
            best_return = max(returns) if returns else 0
            
            category_stats.append({)
                'category': category,
                'avg_return': avg_return,
                'best_return': best_return,
                'total_trades': trades,
                'active_algos': active
            })
        
        # Sort by average return
        category_stats.sort(key=lambda x: x['avg_return'], reverse=True)
        
        for stats in category_stats:
            print(f"{stats['category']:<20} {stats['avg_return']:>13.2%} ")
                  f"{stats['best_return']:>13.2%} {stats['total_trades']:>13} "
                  f"{stats['active_algos']:>13}")
        
        # Top algorithms
        print(f"\n🌟 TOP 20 ALGORITHMS:")
        print(f"{'Rank':<6} {'Algorithm':<30} {'Symbol':<10} {'Return':<12} {'Trades':<10} {'Win Rate':<10}")
        print(f"{'-'*90}")
        
        # Sort by return
        results.sort(key=lambda x: x['return'], reverse=True)
        
        for i, r in enumerate(results[:20], 1):
            print(f"{i:<6} {r['algorithm']:<30} {r['symbol']:<10} ")
                  f"{r['return']:>10.2%} {r['trades']:>8} {r['win_rate']:>8.1%}")
        
        # Algorithm diversity check
        unique_returns = {}
        for r in results:
            key = f"{r['return']:.4f}-{r['trades']}"
            if key not in unique_returns:
                unique_returns[key] = []
            unique_returns[key].append(r['algorithm'])
        
        # Find algorithms with identical results
        print(f"\n🔍 ALGORITHM UNIQUENESS CHECK:")
        identical_count = 0
        for key, algos in unique_returns.items():
            if len(algos) > 1:
                identical_count += 1
                if identical_count <= 5:  # Show first 5
                    ret, trades = key.split('-')
                    print(f"\nIdentical results (Return={float(ret):.2%}, Trades={trades}):")
                    for algo in algos[:5]:
                        print(f"  • {algo}")
        
        if identical_count == 0:
            print("✅ All algorithms produced unique results!")
        else:
            print(f"\n⚠️  Found {identical_count} groups of algorithms with identical results")
        
        # Overall statistics
        total_trades = sum(r['trades'] for r in results)
        active_algos = len(set(r['algorithm'] for r in results if r['trades'] > 0)
        
        print(f"\n📊 OVERALL STATISTICS:")
        print(f"  • Total Algorithms Tested: 84")
        print(f"  • Active Algorithms: {active_algos}")
        print(f"  • Total Trades Executed: {total_trades}")
        print(f"  • Average Trades per Algorithm: {total_trades / active_algos if active_algos > 0 else 0:.1f}")
        print(f"  • Unique Result Patterns: {len(unique_returns)}")
        
        print(f"\n✅ Complete backtest finished!")


def main():
    backtester = CompleteBacktester()
    
    # Test with major symbols
    symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'SPY']
    
    # Run for 2023
    results = backtester.run_complete_backtest(symbols, '2023-01-01', '2023-12-31')
    
    # Save results
    df = pd.DataFrame(results)
    df.to_csv('v24_backtest_results.csv', index=False)
    print(f"\n📁 Results saved to: v24_backtest_results.csv")


if __name__ == "__main__":
    main()