"""
CuPy stub for systems without CUDA
"""

import numpy as np

# Mock CuPy to use NumPy
array = np.array
zeros = np.zeros
ones = np.ones
empty = np.empty
arange = np.arange
linspace = np.linspace

# Math functions
sqrt = np.sqrt
exp = np.exp
log = np.log
sin = np.sin
cos = np.cos
tan = np.tan

# Array operations
sum = np.sum
mean = np.mean
std = np.std
var = np.var
dot = np.dot

# Mock CUDA functionality
class cuda:
    @staticmethod
    def Device(device_id=0):
        return None
    
    class Stream:
        def __init__(self):
            pass
        
        def __enter__(self):
            return self
        
        def __exit__(self, *args):
            pass

# Mock cupy specific functions
def asarray(x):
    return np.asarray(x)

def asnumpy(x):
    if hasattr(x, 'get'):
        return x.get()
    return np.asarray(x)

class ndarray(np.ndarray):
    def get(self):
        return np.asarray(self)
