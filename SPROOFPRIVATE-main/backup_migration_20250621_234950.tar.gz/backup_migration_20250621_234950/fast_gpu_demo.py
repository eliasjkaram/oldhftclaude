#!/usr/bin/env python3
"""
Fast GPU Demo for Options Pricing
Quick demonstration of GPU acceleration for ML training
"""

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from datetime import datetime
import time
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, get_realistic_price

warnings.filterwarnings('ignore')

class FastGPUDemo:
    """
    Fast GPU demonstration for options pricing ML
    """
    
    def __init__(self):
        # Check GPU availability
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"🔥 Device: {self.device}")
        if torch.cuda.is_available():
            print(f"   GPU: {torch.cuda.get_device_name()}")
            print(f"   Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    
    def create_synthetic_data(self, n_samples: int = 10000, n_features: int = 10) -> tuple:
        """Create synthetic options pricing data for GPU demo"""
        
        print(f"📊 Creating synthetic dataset: {n_samples:,} samples, {n_features} features")
        
        # Generate realistic synthetic features
        np.random.seed(42)
        
        # Stock features
        prices = [get_realistic_price(s) for s in symbols]  # Stock prices around $150
        stock_volumes = np.random.lognormal(15, 1, n_samples)  # Log-normal volume distribution
        
        # Options features
        put_call_ratios = np.random.gamma(2, 0.5, n_samples)  # Gamma distribution for P/C ratio
        call_volumes = np.random.exponential(50000, n_samples)
        put_volumes = call_volumes * put_call_ratios
        
        # Technical indicators
        rsi = np.random.beta(2, 2, n_samples) * 100  # RSI between 0-100
        volatility = np.random.gamma(2, 0.1, n_samples)  # Volatility
        
        # Additional features
        volume_ratio = stock_volumes / np.mean(stock_volumes)
        price_momentum = np.random.normal(0, 0.02, n_samples)
        options_activity = (call_volumes + put_volumes) / stock_volumes
        
        # Combine features
        X = np.column_stack([)
            stock_prices,
            stock_volumes,
            put_call_ratios,
            call_volumes,
            put_volumes,
            rsi,
            volatility,
            volume_ratio,
            price_momentum,
            options_activity
        ])
        
        # Create realistic targets
        # Next day stock price with some correlation to features
        noise = np.random.normal(0, 5, n_samples)
        next_stock_price = (stock_prices *)
                           (1 + price_momentum + volatility * np.random.normal(0, 0.1, n_samples) +)
                           noise)
        
        # Next day return
        stock_returns = (next_stock_price / stock_prices) - 1
        
        # Option price predictions (simplified Black-Scholes inspired)
        call_prices = np.maximum(stock_prices - 145, 0) + volatility * 10 + np.random.normal(0, 2, n_samples)
        put_prices = np.maximum(155 - stock_prices, 0) + volatility * 10 + np.random.normal(0, 2, n_samples)
        
        # Multiple targets
        y_stock_price = next_stock_price
        y_stock_return = stock_returns
        y_call_price = call_prices
        y_put_price = put_prices
        
        print(f"✅ Synthetic data created")
        print(f"   Stock price range: ${X[:, 0].min():.2f} - ${X[:, 0].max():.2f}")
        print(f"   P/C ratio range: {X[:, 2].min():.2f} - {X[:, 2].max():.2f}")
        
        return X, y_stock_price, y_stock_return, y_call_price, y_put_price
    
    def create_gpu_model(self, input_dim: int, output_dim: int = 1) -> nn.Module:
        """Create GPU-optimized neural network"""
        
        class OptionsPricingGPU(nn.Module):
            def __init__(self, input_dim, output_dim):
                super(OptionsPricingGPU, self).__init__()
                self.network = nn.Sequential()
                    nn.Linear(input_dim, 256),
                    nn.ReLU(),
                    nn.BatchNorm1d(256),
                    nn.Dropout(0.3),
                    
                    nn.Linear(256, 128),
                    nn.ReLU(),
                    nn.BatchNorm1d(128),
                    nn.Dropout(0.2),
                    
                    nn.Linear(128, 64),
                    nn.ReLU(),
                    nn.Dropout(0.1),
                    
                    nn.Linear(64, output_dim)
                )
            
            def forward(self, x):
                return self.network(x)
        
        return OptionsPricingGPU(input_dim, output_dim)
    
    def train_gpu_model(self, X: np.ndarray, y: np.ndarray, task_name: str, 
                       epochs: int = 200, batch_size: int = 1024) -> dict:
        """Train model with GPU acceleration"""
        
        print(f"\n🔥 Training {task_name} on GPU...")
        start_time = time.time()
        
        # Convert to tensors and move to GPU
        X_tensor = torch.FloatTensor(X).to(self.device)
        y_tensor = torch.FloatTensor(y.reshape(-1, 1).to(self.device)
        
        # Split data
        split_idx = int(0.8 * len(X)
        X_train, X_test = X_tensor[:split_idx], X_tensor[split_idx:]
        y_train, y_test = y_tensor[:split_idx], y_tensor[split_idx:]
        
        print(f"   Training samples: {len(X_train):,}")
        print(f"   Test samples: {len(X_test):,}")
        print(f"   Batch size: {batch_size}")
        print(f"   Epochs: {epochs}")
        
        # Create model and move to GPU
        model = self.create_gpu_model(X.shape[1])
        model = model.to(self.device)
        
        # Setup training
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-5)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=20, factor=0.5)
        
        # Training loop with GPU batching
        model.train()
        best_loss = float('inf')
        
        for epoch in range(epochs):
            epoch_loss = 0
            n_batches = 0
            
            # Mini-batch training
            for i in range(0, len(X_train), batch_size):
                batch_X = X_train[i:i+batch_size]
                batch_y = y_train[i:i+batch_size]
                
                optimizer.zero_grad()
                outputs = model(batch_X)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()
                
                epoch_loss += loss.item()
                n_batches += 1
            
            avg_loss = epoch_loss / n_batches
            scheduler.step(avg_loss)
            
            if avg_loss < best_loss:
                best_loss = avg_loss
            
            # Print progress
            if epoch % 50 == 0 or epoch == epochs - 1:
                print(f"     Epoch {epoch:3d}: Loss = {avg_loss:.6f}, LR = {optimizer.param_groups[0]['lr']:.2e}")
        
        # Evaluate
        model.eval()
        with torch.no_grad():
            train_pred = model(X_train)
            test_pred = model(X_test)
            
            train_loss = criterion(train_pred, y_train).item()
            test_loss = criterion(test_pred, y_test).item()
            
            # Calculate R²
            train_r2 = 1 - train_loss / torch.var(y_train).item()
            test_r2 = 1 - test_loss / torch.var(y_test).item()
        
        training_time = time.time() - start_time
        
        print(f"   ✅ Training complete: {training_time:.2f}s")
        print(f"   📊 Train R²: {train_r2:.4f}, Test R²: {test_r2:.4f}")
        print(f"   📊 Train MSE: {train_loss:.6f}, Test MSE: {test_loss:.6f}")
        
        return {}
            'model': model,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_loss': train_loss,
            'test_loss': test_loss,
            'training_time': training_time,
            'device': str(self.device)
        }
    
    def benchmark_gpu_vs_cpu(self, X: np.ndarray, y: np.ndarray) -> dict:
        """Benchmark GPU vs CPU training speed"""
        
        print(f"\n⚡ GPU vs CPU BENCHMARK")
        print("=" * 40)
        
        results = {}
        
        # GPU Training
        if torch.cuda.is_available():
            print(f"🔥 GPU Training...")
            self.device = torch.device('cuda')
            gpu_result = self.train_gpu_model(X, y, "GPU_Benchmark", epochs=100, batch_size=2048)
            results['gpu'] = gpu_result
        
        # CPU Training
        print(f"💻 CPU Training...")
        self.device = torch.device('cpu')
        cpu_result = self.train_gpu_model(X, y, "CPU_Benchmark", epochs=100, batch_size=2048)
        results['cpu'] = cpu_result
        
        # Compare
        if 'gpu' in results and 'cpu' in results:
            speedup = results['cpu']['training_time'] / results['gpu']['training_time']
            print(f"\n🏆 BENCHMARK RESULTS:")
            print(f"   GPU Time: {results['gpu']['training_time']:.2f}s")
            print(f"   CPU Time: {results['cpu']['training_time']:.2f}s")
            print(f"   🚀 GPU Speedup: {speedup:.1f}x faster")
            print(f"   GPU R²: {results['gpu']['test_r2']:.4f}")
            print(f"   CPU R²: {results['cpu']['test_r2']:.4f}")
        
        # Reset to GPU
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        return results
    
    def make_prediction(self, model: nn.Module, sample_features: np.ndarray) -> float:
        """Make prediction using trained GPU model"""
        
        model.eval()
        with torch.no_grad():
            features_tensor = torch.FloatTensor(sample_features.reshape(1, -1).to(self.device)
            prediction = model(features_tensor)
            return prediction.cpu().numpy()[0, 0]
    
    def run_gpu_demo(self) -> dict:
        """Run complete GPU demonstration"""
        
        print("🔥 FAST GPU OPTIONS PRICING DEMO")
        print("=" * 60)
        print(f"🎯 Goal: Demonstrate GPU acceleration for ML training")
        print(f"📊 Using synthetic data for fast execution")
        print(f"🚀 GPU: {torch.cuda.get_device_name() if torch.cuda.is_available() else 'Not available'}")
        print("=" * 60)
        
        # Create synthetic data
        X, y_stock_price, y_stock_return, y_call_price, y_put_price = self.create_synthetic_data()
            n_samples=50000, n_features=10
        )
        
        # Train multiple models
        models = {}
        
        # 1. Stock Price Prediction
        models['stock_price'] = self.train_gpu_model(X, y_stock_price, "Stock Price Prediction")
        
        # 2. Stock Return Prediction
        models['stock_return'] = self.train_gpu_model(X, y_stock_return, "Stock Return Prediction")
        
        # 3. Call Price Prediction
        models['call_price'] = self.train_gpu_model(X, y_call_price, "Call Price Prediction")
        
        # 4. Put Price Prediction
        models['put_price'] = self.train_gpu_model(X, y_put_price, "Put Price Prediction")
        
        # Benchmark GPU vs CPU
        benchmark = self.benchmark_gpu_vs_cpu(X[:10000], y_stock_price[:10000])  # Smaller dataset for benchmark
        
        # Test predictions
        print(f"\n🔮 TESTING PREDICTIONS")
        print("=" * 40)
        
        # Sample input (AAPL-like data)
        sample_input = np.array([)
            150.0,      # stock_price
            50000000,   # stock_volume  
            1.2,        # put_call_ratio
            80000,      # call_volume
            96000,      # put_volume
            55.0,       # rsi
            0.25,       # volatility
            1.1,        # volume_ratio
            0.01,       # price_momentum
            0.002       # options_activity
        ])
        
        print(f"📊 Sample input (AAPL-like):")
        print(f"   Stock price: ${sample_input[0]:.2f}")
        print(f"   Put/Call ratio: {sample_input[2]:.2f}")
        print(f"   Volatility: {sample_input[6]:.3f}")
        
        predictions = {}
        for model_name, model_result in models.items():
            pred_value = self.make_prediction(model_result['model'], sample_input)
            predictions[model_name] = pred_value
            
            print(f"   {model_name}: {pred_value:.4f}")
        
        # Calculate performance summary
        total_training_time = sum([m['training_time'] for m in models.values()])
        avg_r2 = np.mean([m['test_r2'] for m in models.values()])
        total_samples = len(X) * len(models)
        
        summary = {}
            'total_models_trained': len(models),
            'total_training_time': total_training_time,
            'average_r2_score': avg_r2,
            'total_samples_processed': total_samples,
            'samples_per_second': total_samples / total_training_time,
            'gpu_used': torch.cuda.is_available(),
            'device': str(self.device),
            'predictions': predictions
        }
        
        print(f"\n🏆 GPU DEMO SUMMARY")
        print("=" * 40)
        print(f"🤖 Models trained: {len(models)}")
        print(f"⏱️  Total time: {total_training_time:.2f}s")
        print(f"📊 Average R²: {avg_r2:.4f}")
        print(f"🚀 Speed: {summary['samples_per_second']:.0f} samples/sec")
        print(f"🔥 GPU acceleration: {'✅ Active' if torch.cuda.is_available() else '❌ Not available'}")
        
        # Save results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        results_file = f"gpu_demo_results_{timestamp}.json"
        
        import json
        with open(results_file, 'w') as f:
            json.dump({)
                'summary': summary,
                'benchmark': benchmark,
                'models_performance': {k: {}}
                    'test_r2': float(v['test_r2']),
                    'training_time': float(v['training_time'])
                } for k, v in models.items()}
            }, f, indent=2)
        
        print(f"📄 Results saved: {results_file}")
        
        return summary

def main():
    """Main GPU demo execution"""
    
    try:
        demo = FastGPUDemo()
        results = demo.run_gpu_demo()
        
        print(f"\n🎉 GPU DEMO COMPLETE!")
        print("=" * 50)
        print(f"✅ GPU-accelerated ML training working")
        print(f"✅ Multiple prediction models trained")
        print(f"✅ Ready for real options data")
        print(f"✅ Scalable to large datasets")
        
        if results['gpu_used']:
            print(f"\n🔥 GPU BENEFITS DEMONSTRATED:")
            print(f"• Parallel training on NVIDIA GPU")
            print(f"• Batch processing optimization")
            print(f"• Fast tensor operations")
            print(f"• Scalable to massive datasets")
        
        print(f"\n💡 NEXT STEPS:")
        print(f"• Install additional GPU libraries: pip install xgboost lightgbm cupy")
        print(f"• Scale to full 2021-2023 options dataset")
        print(f"• Deploy models for real-time trading")
        print(f"• Implement automated retraining")
        
    except Exception as e:
        print(f"💥 GPU demo failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()