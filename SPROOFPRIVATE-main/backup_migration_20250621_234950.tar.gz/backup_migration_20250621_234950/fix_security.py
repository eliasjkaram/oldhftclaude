#!/usr/bin/env python3
"""
Security Fix - Addresses Issue #4
- Removes hardcoded API keys from source files
- Moves credentials to environment variables
- Creates secure credential management system
"""

import os
import re
import sys
import json
import logging
from typing import Dict, List, Tuple, Optional
from pathlib import Path
import shutil
from datetime import datetime

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SecurityFixer:
    """Fixes security issues related to hardcoded credentials"""
    
    def __init__(self):
        self.project_root = '/home/harry/alpaca-mcp'
        self.backup_dir = os.path.join(self.project_root, 'backups', 'security_fix_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
        
        # Known API key patterns
        self.api_key_patterns = []
            # Alpaca keys
            (r"['\"]([A-Z0-9]{20})['\"]", "ALPACA_API_KEY"),
            (r"['\"]([A-Za-z0-9]{40,48})['\"]", "ALPACA_SECRET_KEY"),
            
            # Generic patterns
            (r"api_key\s*=\s*['\"]([^'\"]+)['\"]", "API_KEY"),
            (r"secret\s*=\s*['\"]([^'\"]+)['\"]", "SECRET_KEY"),
            (r"token\s*=\s*['\"]([^'\"]+)['\"]", "API_TOKEN")
        ]
        
        # Files with known hardcoded credentials
        self.files_with_credentials = []
            ('paper_trading_bot.py', 45, '<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_SECRET>'),
            ('arbitrage_scanner.py', 42, '<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_SECRET>'),
            ('market_data_collector.py', 42, '<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_SECRET>'),
            ('market_data_collector.py', 44, os.getenv('ALPACA_LIVE_API_KEY'), os.getenv('ALPACA_LIVE_API_SECRET'))
        ]
        
        # Create backup directory
        os.makedirs(self.backup_dir, exist_ok=True)
    
    def create_env_template(self):
        """Create .env.template file with required environment variables"""
        template_path = os.path.join(self.project_root, '.env.template')
        
        template_content = '''# Alpaca Trading API Credentials
# Paper Trading
ALPACA_PAPER_API_KEY=your_paper_api_key_here
ALPACA_PAPER_SECRET_KEY=your_paper_secret_key_here
ALPACA_PAPER_BASE_URL=https://paper-api.alpaca.markets

# Live Trading (use with caution!)
ALPACA_LIVE_API_KEY=your_live_api_key_here
ALPACA_LIVE_SECRET_KEY=your_live_secret_key_here
ALPACA_LIVE_BASE_URL=https://api.alpaca.markets

# Default to paper trading for safety
ALPACA_API_KEY=${ALPACA_PAPER_API_KEY}
ALPACA_SECRET_KEY=${ALPACA_PAPER_SECRET_KEY}
ALPACA_BASE_URL=${ALPACA_PAPER_BASE_URL}

# Other API Keys
POLYGON_API_KEY=your_polygon_key_here
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_key_here

# Database Configuration
DB_PATH=/home/harry/alpaca-mcp/data/trading.db

# Logging Configuration
LOG_LEVEL=INFO
LOG_PATH=/home/harry/alpaca-mcp/logs

# Trading Configuration
MAX_POSITIONS=10
POSITION_SIZE_PCT=0.1
STOP_LOSS_PCT=0.02
TAKE_PROFIT_PCT=0.05
MIN_CONFIDENCE=0.7

# Runtime Configuration
MAX_RUNTIME_MINUTES=360
MARKET_DATA_CYCLE_MINUTES=5
HEALTH_CHECK_INTERVAL_SECONDS=30
'''
        
        with open(template_path, 'w') as f:
            f.write(template_content)
        
        logger.info(f"Created .env.template at {template_path}")
        
        # Also create .gitignore if it doesn't exist
        gitignore_path = os.path.join(self.project_root, '.gitignore')
        if not os.path.exists(gitignore_path):
            with open(gitignore_path, 'w') as f:
                f.write('.env\n*.log\n__pycache__/\n*.pyc\n')
        else:
            # Ensure .env is in gitignore
            with open(gitignore_path, 'r') as f:
                content = f.read()
            
            if '.env' not in content:
                with open(gitignore_path, 'a') as f:
                    f.write('\n.env\n')
    
    def create_secure_config_module(self):
        """Create a secure configuration module"""
        config_path = os.path.join(self.project_root, 'secure_config.py')
        
        config_content = '''#!/usr/bin/env python3
"""
Secure Configuration Module
Loads credentials from environment variables
"""

import os
import logging
from typing import Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class SecureConfig:
    """Secure configuration management"""
    
    def __init__(self, use_paper: bool = True):
        self.use_paper = use_paper
        self._validate_environment()
    
    def _validate_environment(self):
        """Validate required environment variables are set"""
        required_vars = []
            'ALPACA_PAPER_API_KEY',
            'ALPACA_PAPER_SECRET_KEY'
        ]
        
        missing = []
        for var in required_vars:
            if not os.getenv(var):
                missing.append(var)
        
        if missing:
            logger.warning(f"Missing environment variables: {', '.join(missing)}")
            logger.warning("Please copy .env.template to .env and fill in your credentials")
    
    @property
    def alpaca_api_key(self) -> Optional[str]:
        """Get Alpaca API key"""
        if self.use_paper:
            return os.getenv('ALPACA_PAPER_API_KEY', os.getenv('ALPACA_API_KEY'))
        else:
            return os.getenv('ALPACA_LIVE_API_KEY', os.getenv('ALPACA_API_KEY'))
    
    @property
    def alpaca_secret_key(self) -> Optional[str]:
        """Get Alpaca secret key"""
        if self.use_paper:
            return os.getenv('ALPACA_PAPER_SECRET_KEY', os.getenv('ALPACA_SECRET_KEY'))
        else:
            return os.getenv('ALPACA_LIVE_SECRET_KEY', os.getenv('ALPACA_SECRET_KEY'))
    
    @property
    def alpaca_base_url(self) -> str:
        """Get Alpaca base URL"""
        if self.use_paper:
            return os.getenv('ALPACA_PAPER_BASE_URL', 'https://paper-api.alpaca.markets')
        else:
            return os.getenv('ALPACA_LIVE_BASE_URL', 'https://api.alpaca.markets')
    
    @property
    def polygon_api_key(self) -> Optional[str]:
        """Get Polygon API key"""
        return os.getenv('POLYGON_API_KEY')
    
    @property
    def alpha_vantage_api_key(self) -> Optional[str]:
        """Get Alpha Vantage API key"""
        return os.getenv('ALPHA_VANTAGE_API_KEY')
    
    def get_alpaca_client(self):
        """Get configured Alpaca client"""
        from alpaca.trading.client import TradingClient
        
        if not self.alpaca_api_key or not self.alpaca_secret_key:
            raise ValueError("Alpaca credentials not configured. Please set environment variables.")
        
        return TradingClient()
            self.alpaca_api_key,
            self.alpaca_secret_key,
            paper=self.use_paper,
            url_override=self.alpaca_base_url
        )
    
    def get_trading_config(self) -> dict:
        """Get trading configuration from environment"""
        return {}
            'max_positions': int(os.getenv('MAX_POSITIONS', '10')),
            'position_size_pct': float(os.getenv('POSITION_SIZE_PCT', '0.1')),
            'stop_loss_pct': float(os.getenv('STOP_LOSS_PCT', '0.02')),
            'take_profit_pct': float(os.getenv('TAKE_PROFIT_PCT', '0.05')),
            'min_confidence': float(os.getenv('MIN_CONFIDENCE', '0.7'))
        }

# Default instance for paper trading
config = SecureConfig(use_paper=True)

# Convenience functions
def get_alpaca_client(use_paper: bool = True):
    """Get Alpaca client with proper credentials"""
    cfg = SecureConfig(use_paper=use_paper)
    return cfg.get_alpaca_client()

def get_trading_config() -> dict:
    """Get trading configuration"""
    return config.get_trading_config()
'''
        
        with open(config_path, 'w') as f:
            f.write(config_content)
        
        logger.info(f"Created secure config module at {config_path}")
    
    def backup_file(self, filepath: str):
        """Backup a file before modifying it"""
        if os.path.exists(filepath):
            filename = os.path.basename(filepath)
            backup_path = os.path.join(self.backup_dir, filename)
            shutil.copy2(filepath, backup_path)
            logger.info(f"Backed up {filename} to {backup_path}")
    
    def fix_file_credentials(self, filepath: str) -> Tuple[bool, List[str]]:
        """Fix hardcoded credentials in a file"""
        file_path = os.path.join(self.project_root, filepath)
        
        if not os.path.exists(file_path):
            logger.warning(f"File not found: {file_path}")
            return False, [f"File not found: {filepath}"]
        
        # Backup the file first
        self.backup_file(file_path)
        
        with open(file_path, 'r') as f:
            content = f.read()
        
        original_content = content
        changes = []
        
        # Replace known hardcoded keys
        replacements = []
            # Alpaca paper keys
            ('<ALPACA_PAPER_KEY>', "os.getenv('ALPACA_PAPER_API_KEY')"),
            ('<ALPACA_PAPER_SECRET>', "os.getenv('ALPACA_PAPER_SECRET_KEY')"),
            
            # Alpaca live keys
            (os.getenv('ALPACA_LIVE_API_KEY'), "os.getenv('ALPACA_LIVE_API_KEY')"),
            (os.getenv('ALPACA_LIVE_API_SECRET'), "os.getenv('ALPACA_LIVE_SECRET_KEY')"),
        ]
        
        for old_key, new_value in replacements:
            if old_key in content:
                # Find the context around the key
                pattern = rf"['\"]({re.escape(old_key)})['\"]"
                content = re.sub(pattern, new_value, content)
                changes.append(f"Replaced hardcoded key '{old_key[:8]}...' with {new_value}")
        
        # Add import for os if needed and not already present
        if 'os.getenv' in content and 'import os' not in content:
            # Add import at the beginning after shebang and docstring
            lines = content.split('\n')
            import_added = False
            
            for i, line in enumerate(lines):
                # Skip shebang, empty lines, and docstrings
                if line.startswith('#!') or line.strip() == '' or line.strip().startswith('"""'):
                    continue
                
                # Add import before first real code line
                if not import_added and not line.startswith('import') and not line.startswith('from'):
                    lines.insert(i, 'import os')
                    import_added = True
                    changes.append("Added 'import os' for environment variables")
                    break
                
                # Or add after other imports
                if line.startswith('import') or line.startswith('from'):
                    # Find the last import
                    j = i
                    while j < len(lines) - 1 and (lines[j+1].startswith('import') or lines[j+1].startswith('from')):
                        j += 1
                    lines.insert(j + 1, 'import os')
                    import_added = True
                    changes.append("Added 'import os' for environment variables")
                    break
            
            content = '\n'.join(lines)
        
        # Fix TradingClient instantiation patterns
        trading_client_pattern = r"TradingClient\s*\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*,\s*paper\s*=\s*(True|False)\s*\)"
        
        def replace_trading_client(match):
            paper = match.group(3)
            return f"TradingClient(os.getenv('ALPACA_API_KEY'), os.getenv('ALPACA_SECRET_KEY'), paper={paper})"
        
        new_content = re.sub(trading_client_pattern, replace_trading_client, content)
        if new_content != content:
            content = new_content
            changes.append("Updated TradingClient instantiation to use environment variables")
        
        # Write the fixed content back
        if content != original_content:
            with open(file_path, 'w') as f:
                f.write(content)
            logger.info(f"Fixed {filepath}: {len(changes)} changes made")
            return True, changes
        else:
            logger.info(f"No changes needed for {filepath}")
            return False, []
    
    def create_migration_script(self):
        """Create a script to help users migrate their credentials"""
        script_path = os.path.join(self.project_root, 'migrate_credentials.py')
        
        script_content = '''#!/usr/bin/env python3
"""
Credential Migration Helper
Helps users securely migrate their API credentials to environment variables
"""

import os
import sys
from pathlib import Path

from universal_market_data import get_current_market_data, validate_price


def main():
    print("=== Alpaca MCP Credential Migration ===")
    print()
    
    env_path = Path('.env')
    template_path = Path('.env.template')
    
    if env_path.exists():
        print("✓ .env file already exists")
        response = input("Do you want to update it? (y/N): ").strip().lower()
        if response != 'y':
            print("Migration cancelled")
            return
    
    # Read template
    if not template_path.exists():
        print("✗ .env.template not found. Please run fix_security.py first")
        return 1
    
    print()
    print("Please enter your Alpaca credentials:")
    print("(Leave blank to skip)")
    print()
    
    # Collect credentials
    credentials = {}
    
    # Paper trading
    print("=== Paper Trading Credentials ===")
    credentials['ALPACA_PAPER_API_KEY'] = input("Paper API Key: ").strip()
    credentials['ALPACA_PAPER_SECRET_KEY'] = input("Paper Secret Key: ").strip()
    
    print()
    print("=== Live Trading Credentials (Optional) ===")
    credentials['ALPACA_LIVE_API_KEY'] = input("Live API Key: ").strip()
    credentials['ALPACA_LIVE_SECRET_KEY'] = input("Live Secret Key: ").strip()
    
    # Read template
    with open(template_path, 'r') as f:
        content = f.read()
    
    # Replace placeholders
    for key, value in credentials.items():
        if value:
            placeholder = f"your_{key.lower().replace('alpaca_', '').replace('_', '_')}_here"
            content = content.replace(placeholder, value)
    
    # Write .env file
    with open(env_path, 'w') as f:
        f.write(content)
    
    # Set permissions
    os.chmod(env_path, 0o600)  # Read/write for owner only
    
    print()
    print("✓ Credentials saved to .env")
    print("✓ File permissions set to 600 (owner read/write only)")
    print()
    print("IMPORTANT:")
    print("1. Never commit .env to version control")
    print("2. Keep your credentials secure")
    print("3. Use paper trading for testing")
    print()
    print("Migration complete!")

if __name__ == "__main__":
    sys.exit(main())
'''
        
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        os.chmod(script_path, 0o755)
        logger.info(f"Created migration script at {script_path}")
    
    def fix_all_files(self) -> Dict[str, List[str]]:
        """Fix all files with hardcoded credentials"""
        results = {}
        
        # Get all Python files
        python_files = []
        for root, dirs, files in os.walk(self.project_root):
            # Skip backup directories
            if 'backups' in root or '__pycache__' in root:
                continue
                
            for file in files:
                if file.endswith('.py'):
                    rel_path = os.path.relpath(os.path.join(root, file), self.project_root)
                    python_files.append(rel_path)
        
        logger.info(f"Scanning {len(python_files)} Python files for hardcoded credentials...")
        
        # Fix known files first
        for file_info in self.files_with_credentials:
            filepath = file_info[0]
            fixed, changes = self.fix_file_credentials(filepath)
            if fixed:
                results[filepath] = changes
        
        # Scan other files
        for filepath in python_files:
            if filepath not in [f[0] for f in self.files_with_credentials]:
                fixed, changes = self.fix_file_credentials(filepath)
                if fixed:
                    results[filepath] = changes
        
        return results

def main():
    """Main function to fix security issues"""
    fixer = SecurityFixer()
    
    logger.info("Starting security fix process...")
    
    # Step 1: Create secure configuration infrastructure
    logger.info("\nStep 1: Creating secure configuration files")
    fixer.create_env_template()
    fixer.create_secure_config_module()
    fixer.create_migration_script()
    
    # Step 2: Fix hardcoded credentials
    logger.info("\nStep 2: Fixing hardcoded credentials in source files")
    results = fixer.fix_all_files()
    
    # Summary
    logger.info("\n" + "="*60)
    logger.info("SECURITY FIX SUMMARY")
    logger.info("="*60)
    
    if results:
        logger.info(f"\nFixed {len(results)} files:")
        for filepath, changes in results.items():
            logger.info(f"\n{filepath}:")
            for change in changes:
                logger.info(f"  - {change}")
    else:
        logger.info("\nNo hardcoded credentials found!")
    
    logger.info(f"\nBackups saved to: {fixer.backup_dir}")
    
    # Instructions
    logger.info("\n" + "="*60)
    logger.info("NEXT STEPS")
    logger.info("="*60)
    logger.info("1. Run: python migrate_credentials.py")
    logger.info("2. Enter your API credentials when prompted")
    logger.info("3. Verify .env file was created with correct permissions")
    logger.info("4. Test the system with the fixed components")
    logger.info("\nIMPORTANT: Never commit .env to version control!")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())