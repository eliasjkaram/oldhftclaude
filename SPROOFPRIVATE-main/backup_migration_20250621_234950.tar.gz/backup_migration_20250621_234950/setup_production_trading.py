#!/usr/bin/env python3
"""
Setup Production Trading Environment
====================================
Ensures all components are ready for live trading.
"""

import os
import sys
import subprocess
from datetime import datetime

def setup_environment():
    """Setup trading environment"""
    print("🔧 Setting up production trading environment...")
    
    # Create necessary directories
    dirs = ['logs', 'data', 'models', 'reports', 'backups']
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    print("✅ Directories created")
    
    # Install critical dependencies
    print("\n📦 Installing critical dependencies...")
    critical_packages = []
        'alpaca-py',
        'yfinance',
        'pandas',
        'numpy',
        'python-dotenv'
    ]
    
    for package in critical_packages:
        subprocess.run([sys.executable, '-m', 'pip', 'install', package, '--quiet'])
    print("✅ Dependencies installed")
    
    # Create example .env if not exists
    if not os.path.exists('.env'):
        print("\n📝 Creating .env template...")
        with open('.env', 'w') as f:
            f.write("""# Alpaca API Credentials)
ALPACA_API_KEY=your_api_key_here
ALPACA_API_SECRET=your_api_secret_here
ALPACA_PAPER_TRADING=true  # Set to false for live trading

# OpenRouter API (for AI trading)
OPENROUTER_API_KEY=your_openrouter_key_here

# Risk Settings
MAX_POSITION_SIZE=10000  # Maximum $ per position
MAX_DAILY_LOSS=5000     # Maximum daily loss allowed
STOP_LOSS_PERCENT=5     # Stop loss percentage

# Trading Settings
ENABLE_OPTIONS=false    # Enable options trading
ENABLE_CRYPTO=false     # Enable crypto trading
ENABLE_AI_TRADING=true  # Enable AI-powered trading
""")
        print("✅ .env template created - PLEASE EDIT WITH YOUR CREDENTIALS")
        return False
    
    return True

def test_connections():
    """Test API connections"""
    print("\n🔌 Testing API connections...")
    
    try:
        # Test Alpaca connection
        from alpaca.trading.client import TradingClient
        api_key = os.getenv('ALPACA_API_KEY')
        api_secret = os.getenv('ALPACA_API_SECRET')
        
        if not api_key or api_key == 'your_api_key_here':
            print("❌ Alpaca API credentials not configured")
            return False
        
        paper = os.getenv('ALPACA_PAPER_TRADING', 'true').lower() == 'true'
        client = TradingClient(api_key, api_secret, paper=paper)
        account = client.get_account()
        
        print(f"✅ Alpaca connected - Account value: ${float(account.portfolio_value):,.2f}")
        print(f"   Trading mode: {'PAPER' if paper else 'LIVE'}")
        
        # Test market data
        from universal_market_data import get_current_market_data
        data = get_current_market_data(['AAPL'])
        print(f"✅ Market data working - AAPL: ${data['AAPL']['price']:.2f}")
        
        return True
        
    except Exception as e:
        print(f"❌ Connection test failed: {e}")
        return False

def show_trading_menu():
    """Show trading options menu"""
    print("\n" + "=" * 80)
    print("💰 ALPACA TRADING SYSTEM - READY TO MAKE MONEY!")
    print("=" * 80)
    print("\n🎯 TRADING OPTIONS:")
    print("\n1. 🚀 FULL PRODUCTION MODE")
    print("   • AI-powered trading with 5+ strategies")
    print("   • Real-time market analysis")
    print("   • Automated risk management")
    print("   • 24/7 operation")
    
    print("\n2. 📊 MONITORING ONLY")
    print("   • Watch market movements")
    print("   • No actual trades")
    print("   • Performance tracking")
    
    print("\n3. 🧪 BACKTEST MODE")
    print("   • Test strategies on historical data")
    print("   • No real money at risk")
    print("   • Performance analysis")
    
    print("\n4. 📈 SINGLE STRATEGY")
    print("   • Run one specific strategy")
    print("   • Lower risk approach")
    print("   • Good for beginners")

def main():
    print("=" * 80)
    print("🏦 ALPACA TRADING SYSTEM SETUP")
    print("=" * 80)
    print(f"Timestamp: {datetime.now()}")
    print("=" * 80)
    
    # Setup environment
    env_ready = setup_environment()
    
    if not env_ready:
        print("\n⚠️  Please configure your .env file with API credentials first!")
        print("\n📝 Steps:")
        print("1. Edit .env file with your Alpaca API credentials")
        print("2. Get API keys from: https://alpaca.markets/")
        print("3. Use paper trading keys for testing")
        print("4. Run this script again")
        return
    
    # Test connections
    if not test_connections():
        print("\n❌ Cannot proceed without valid API connections")
        return
    
    # Show options
    show_trading_menu()
    
    print("\n" + "=" * 80)
    print("✅ SYSTEM READY FOR TRADING!")
    print("=" * 80)
    
    print("\n🚀 TO START MAKING MONEY:")
    print("\n1. For FULL PRODUCTION trading (recommended):")
    print("   python launch_full_production_system.py")
    
    print("\n2. For SAFE TESTING with paper account:")
    print("   python fix_ai_discovery_system.py")
    
    print("\n3. For GUI interface:")
    print("   python ULTIMATE_PRODUCTION_TRADING_GUI.py")
    
    print("\n⚠️  RISK WARNING:")
    print("• Trading involves substantial risk of loss")
    print("• Past performance doesn't guarantee future results")
    print("• Start with paper trading to test strategies")
    print("• Never invest more than you can afford to lose")
    
    print("\n💡 TIPS FOR SUCCESS:")
    print("• Start with paper trading")
    print("• Monitor your positions closely")
    print("• Set stop losses")
    print("• Diversify your strategies")
    print("• Keep learning and adapting")
    
    print("\n🎯 Ready to start? Choose your path above!")

if __name__ == "__main__":
    main()