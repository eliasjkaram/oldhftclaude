
#!/usr/bin/env python3
"""
Data Source Configuration Manager
Allows easy switching between MinIO and other data sources
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import json
import os
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime

class DataSourceConfig:
    """Manages data source configurations for the trading system"""
    
    def __init__(self, config_file: str = "data_sources.json"):
        self.config_file = Path(config_file)
        self.configs = self._load_configs()
        self.active_source = self.configs.get('active', 'minio')
    
    def _load_configs(self) -> Dict:
        """Load configurations from file"""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                return json.load(f)
        else:
            # Create default configurations
            return self._create_default_configs()
    
    def _create_default_configs(self) -> Dict:
        """Create default data source configurations"""
        configs = {}
            'active': 'minio',
            'sources': {}
                'minio': {}
                    'type': 'minio',
                    'enabled': True,
                    'config': {}
                        'endpoint': 'uschristmas.us/minio',
                        'access_key': 'AKSTOCKDBUSER001',
                        'secret_key': 'StockDB-User-Secret-Key-Secure-2024!',
                        'bucket_name': 'stockdb',
                        'secure': True
                    },
                    'cache': {}
                        'cache_dir': str(Path.home() / 'alpaca-mcp' / 'minio_cache'),
                        'max_cache_age_hours': 24,
                        'max_cache_size_gb': 50
                    }
                },
                'alpaca': {}
                    'type': 'alpaca',
                    'enabled': False,
                    'config': {}
                        'api_key': os.getenv('ALPACA_API_KEY', ''),
                        'api_secret': os.getenv('ALPACA_API_SECRET', ''),
                        'base_url': 'https://paper-api.alpaca.markets',
                        'data_url': 'https://data.alpaca.markets'
                    }
                },
                'yahoo': {}
                    'type': 'yahoo',
                    'enabled': False,
                    'config': {}
                        'rate_limit': 2000,
                        'retry_count': 3
                    }
                },
                'simulated': {}
                    'type': 'simulated',
                    'enabled': True,
                    'config': {}
                        'seed': 42,
                        'volatility': 0.02,
                        'trend': 0.0001
                    }
                }
            },
            'fallback_order': ['minio', 'alpaca', 'yahoo', 'simulated'],
            'last_updated': datetime.now().isoformat()
        }
        
        # Save default configs
        self.save_configs(configs)
        return configs
    
    def save_configs(self, configs: Dict = None):
        """Save configurations to file"""
        if configs is None:
            configs = self.configs
        
        configs['last_updated'] = datetime.now().isoformat()
        
        with open(self.config_file, 'w') as f:
            json.dump(configs, f, indent=2)
    
    def get_active_config(self) -> Dict:
        """Get configuration for the active data source"""
        return self.configs['sources'].get(self.active_source, {})
    
    def set_active_source(self, source_name: str):
        """Set the active data source"""
        if source_name not in self.configs['sources']:
            raise ValueError(f"Unknown data source: {source_name}")
        
        self.active_source = source_name
        self.configs['active'] = source_name
        self.save_configs()
    
    def add_data_source(self, name: str, config: Dict):
        """Add a new data source configuration"""
        self.configs['sources'][name] = config
        self.save_configs()
    
    def update_data_source(self, name: str, config: Dict):
        """Update an existing data source configuration"""
        if name not in self.configs['sources']:
            raise ValueError(f"Data source {name} not found")
        
        self.configs['sources'][name].update(config)
        self.save_configs()
    
    def get_fallback_sources(self) -> list:
        """Get list of fallback sources in order"""
        return []
            source for source in self.configs['fallback_order']
            if self.configs['sources'].get(source, {}).get('enabled', False)
        ]
    
    def enable_source(self, name: str):
        """Enable a data source"""
        if name in self.configs['sources']:
            self.configs['sources'][name]['enabled'] = True
            self.save_configs()
    
    def disable_source(self, name: str):
        """Disable a data source"""
        if name in self.configs['sources']:
            self.configs['sources'][name]['enabled'] = False
            self.save_configs()
    
    def get_minio_config(self) -> Optional[Dict]:
        """Get MinIO specific configuration"""
        minio_config = self.configs['sources'].get('minio', {})
        if minio_config.get('enabled', False):
            return {}
                'minio_config': minio_config.get('config', {}),
                'cache_config': minio_config.get('cache', {})
            }
        return None
    
    def validate_config(self, source_name: str) -> bool:
        """Validate a data source configuration"""
        if source_name not in self.configs['sources']:
            return False
        
        config = self.configs['sources'][source_name]
        
        # Basic validation
        if not config.get('type'):
            return False
        
        # Source-specific validation
        if config['type'] == 'minio':
            required = ['endpoint', 'access_key', 'secret_key', 'bucket_name']
            return all(key in config.get('config', {}) for key in required)
        
        elif config['type'] == 'alpaca':
            required = ['api_key', 'api_secret']
            return all(config.get('config', {}).get(key) for key in required)
        
        return True
    
    def list_sources(self) -> Dict:
        """List all configured data sources"""
        sources = {}
        for name, config in self.configs['sources'].items():
            sources[name] = {}
                'type': config.get('type'),
                'enabled': config.get('enabled', False),
                'valid': self.validate_config(name),
                'is_active': name == self.active_source
            }
        return sources


def create_data_source_adapter(config_manager: DataSourceConfig):
    """Factory function to create appropriate data source adapter"""
    active_config = config_manager.get_active_config()
    source_type = active_config.get('type')
    
    if source_type == 'minio':
        from minio_data_integration import MinIODataIntegration
        minio_settings = config_manager.get_minio_config()
        if minio_settings:
            return MinIODataIntegration()
                **minio_settings['minio_config'],
                cache_dir=minio_settings['cache_config']['cache_dir']
            )
    
    elif source_type == 'alpaca':
        # Alpaca integration - use Alpaca data client
        from alpaca.data import StockHistoricalDataClient
        
        api_key = alpaca_settings.get('api_key')
        api_secret = alpaca_settings.get('api_secret')
        
        if not api_key or not api_secret:
            raise ValueError("Alpaca API credentials not provided")
            
        # Return Alpaca client configuration
        return {}
            'type': 'alpaca',
            'client': StockHistoricalDataClient(api_key, api_secret),
            'base_url': alpaca_settings.get('base_url', 'https://paper-api.alpaca.markets'),
            'data_feed': alpaca_settings.get('data_feed', 'iex')
        }
    
    elif source_type == 'yahoo':
        # Yahoo Finance integration using yfinance
        import yfinance as yf
        
        # Return yfinance configuration
        return {}
            'type': 'yahoo',
            'module': yf,
            'cache_dir': cache_config.get('cache_dir', 'data_cache'),
            'auto_adjust': True,  # Adjust for splits and dividends
            'prepost': True,     # Include pre/post market data
            'threads': True      # Use multithreading for batch downloads
        }
    
    elif source_type == 'simulated':
        # Return None to indicate simulated data should be used
        return None
    
    raise ValueError(f"Unknown data source type: {source_type}")


# CLI interface for managing data sources
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Data Source Configuration Manager')
    parser.add_argument('command', choices=['list', 'set', 'enable', 'disable', 'validate'],
                       help='Command to execute')
    parser.add_argument('--source', help='Data source name')
    parser.add_argument('--add-source', help='Add new data source (JSON config)')
    
    args = parser.parse_args()
    
    config_manager = DataSourceConfig()
    
    if args.command == 'list':
        sources = config_manager.list_sources()
        print("\nConfigured Data Sources:")
        print("-" * 50)
        for name, info in sources.items():
            status = "✓" if info['enabled'] else "✗"
            active = " (ACTIVE)" if info['is_active'] else ""
            valid = " [VALID]" if info['valid'] else " [INVALID]"
            print(f"{status} {name}: {info['type']}{valid}{active}")
        print(f"\nFallback order: {' -> '.join(config_manager.get_fallback_sources()}")
    
    elif args.command == 'set' and args.source:
        try:
            config_manager.set_active_source(args.source)
            print(f"Active data source set to: {args.source}")
        except ValueError as e:
            print(f"Error: {e}")
    
    elif args.command == 'enable' and args.source:
        config_manager.enable_source(args.source)
        print(f"Enabled data source: {args.source}")
    
    elif args.command == 'disable' and args.source:
        config_manager.disable_source(args.source)
        print(f"Disabled data source: {args.source}")
    
    elif args.command == 'validate' and args.source:
        if config_manager.validate_config(args.source):
            print(f"✓ Configuration for {args.source} is valid")
        else:
            print(f"✗ Configuration for {args.source} is invalid or incomplete")
    
    else:
        parser.print_help()