#!/usr/bin/env python3
"""
Integrated System Test Suite
============================
Comprehensive test to verify all components work together
"""

import sys
import time
import logging
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any
import pandas as pd

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class IntegratedSystemTester:
    """Test all integrated components"""
    
    def __init__(self):
        self.test_results = {}
            'timestamp': datetime.now().isoformat(),
            'tests_run': 0,
            'tests_passed': 0,
            'tests_failed': 0,
            'component_status': {},
            'errors': []
        }
        
    def test_alpaca_connection(self) -> bool:
        """Test Alpaca API connection"""
        logger.info("Testing Alpaca connection...")
        try:
            from alpaca_config import default_config
            from alpaca.trading.client import TradingClient
            
            # Test connection
            client = TradingClient(**default_config.get_trading_client_config())
            account = client.get_account()
            
            self.test_results['component_status']['alpaca'] = {}
                'status': 'connected',
                'mode': 'paper' if default_config.is_paper else 'live',
                'buying_power': float(account.buying_power),
                'account_status': account.status
            }
            
            logger.info(f"✅ Alpaca connected in {default_config.mode} mode")
            return True
            
        except Exception as e:
            logger.error(f"❌ Alpaca connection failed: {e}")
            self.test_results['errors'].append(f"Alpaca: {str(e)}")
            return False
    
    def test_minio_pipeline(self) -> bool:
        """Test MinIO data pipeline"""
        logger.info("Testing MinIO data pipeline...")
        try:
            from DATA_PIPELINE_MINIO import DataPipelineMinIO
            
            pipeline = DataPipelineMinIO()
            
            # Test data retrieval
            test_symbol = 'AAPL'
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
            
            if pipeline.minio_client:
                # Try to get some data
                data = pipeline.get_stock_data(test_symbol, start_date, end_date)
                
                self.test_results['component_status']['minio'] = {}
                    'status': 'connected',
                    'test_data_retrieved': data is not None and not data.empty if data is not None else False,
                    'records': len(data) if data is not None and not data.empty else 0
                }
                
                logger.info("✅ MinIO pipeline operational")
                return True
            else:
                self.test_results['component_status']['minio'] = {'status': 'not available'}
                logger.warning("⚠️  MinIO not available - using fallback")
                return True  # Not critical
                
        except Exception as e:
            logger.error(f"❌ MinIO pipeline test failed: {e}")
            self.test_results['errors'].append(f"MinIO: {str(e)}")
            return False
    
    def test_gpu_acceleration(self) -> bool:
        """Test GPU acceleration"""
        logger.info("Testing GPU acceleration...")
        try:
            import torch
            
            gpu_available = torch.cuda.is_available()
            
            if gpu_available:
                self.test_results['component_status']['gpu'] = {}
                    'status': 'available',
                    'device': torch.cuda.get_device_name(),
                    'cuda_version': torch.version.cuda,
                    'memory_gb': torch.cuda.get_device_properties(0).total_memory / 1e9
                }
                logger.info(f"✅ GPU acceleration available: {torch.cuda.get_device_name()}")
            else:
                self.test_results['component_status']['gpu'] = {'status': 'not available'}
                logger.info("ℹ️  GPU not available - using CPU")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ GPU test failed: {e}")
            self.test_results['errors'].append(f"GPU: {str(e)}")
            return False
    
    def test_ai_bots(self) -> bool:
        """Test AI bot functionality"""
        logger.info("Testing AI bots...")
        try:
            from ai_bots_interface import AIBotManager
            
            bot_manager = AIBotManager()
            
            # Get available bots
            bot_count = len(bot_manager.bot_configs)
            
            # Test opportunity generation
            opportunities = bot_manager.get_all_opportunities()
            
            self.test_results['component_status']['ai_bots'] = {}
                'status': 'operational',
                'total_bots': bot_count,
                'test_opportunities': len(opportunities),
                'bot_types': list(bot_manager.bot_configs.keys())[:5]  # First 5
            }
            
            logger.info(f"✅ AI bots operational: {bot_count} bots available")
            return True
            
        except Exception as e:
            logger.error(f"❌ AI bots test failed: {e}")
            self.test_results['errors'].append(f"AI Bots: {str(e)}")
            return False
    
    def test_master_integration(self) -> bool:
        """Test master production integration"""
        logger.info("Testing master integration...")
        try:
            from MASTER_PRODUCTION_INTEGRATION import MasterProductionIntegration
            
            # Create instance
            master = MasterProductionIntegration()
            
            # Get system status
            status = master.get_system_status()
            
            self.test_results['component_status']['master_integration'] = {}
                'status': status.get('overall_status', 'unknown'),
                'components': status.get('components', {}),
                'performance': status.get('performance', {})
            }
            
            logger.info("✅ Master integration operational")
            return True
            
        except Exception as e:
            logger.error(f"❌ Master integration test failed: {e}")
            self.test_results['errors'].append(f"Master Integration: {str(e)}")
            return False
    
    def test_trading_systems(self) -> bool:
        """Test trading system components"""
        logger.info("Testing trading systems...")
        try:
            from ROBUST_REAL_TRADING_SYSTEM import RobustRealTradingSystem
            from TRULY_REAL_SYSTEM import TrulyRealTradingSystem
            
            # Test robust system
            robust = RobustRealTradingSystem()
            
            # Test truly real system  
            truly_real = TrulyRealTradingSystem()
            
            self.test_results['component_status']['trading_systems'] = {}
                'robust_system': 'initialized',
                'truly_real_system': 'initialized',
                'status': 'operational'
            }
            
            logger.info("✅ Trading systems initialized")
            return True
            
        except Exception as e:
            logger.error(f"❌ Trading systems test failed: {e}")
            self.test_results['errors'].append(f"Trading Systems: {str(e)}")
            return False
    
    def test_ai_execution_bridge(self) -> bool:
        """Test AI bot execution integration"""
        logger.info("Testing AI execution bridge...")
        try:
            from ai_bot_execution_integration import AIBotExecutionBridge
            
            bridge = AIBotExecutionBridge()
            
            # Test validation
            test_opportunity = {}
                'symbol': 'AAPL',
                'action': 'buy',
                'confidence': 0.75,
                'bot_type': 'test_bot'
            }
            
            is_valid = bridge.validate_opportunity(test_opportunity)
            
            self.test_results['component_status']['ai_execution'] = {}
                'status': 'operational',
                'validation_test': 'passed' if is_valid else 'failed',
                'execution_ready': True
            }
            
            logger.info("✅ AI execution bridge operational")
            return True
            
        except Exception as e:
            logger.error(f"❌ AI execution test failed: {e}")
            self.test_results['errors'].append(f"AI Execution: {str(e)}")
            return False
    
    def run_all_tests(self):
        """Run all integration tests"""
        logger.info("="*60)
        logger.info("Starting Integrated System Tests")
        logger.info("="*60)
        
        tests = []
            ("Alpaca Connection", self.test_alpaca_connection),
            ("MinIO Pipeline", self.test_minio_pipeline),
            ("GPU Acceleration", self.test_gpu_acceleration),
            ("AI Bots", self.test_ai_bots),
            ("Master Integration", self.test_master_integration),
            ("Trading Systems", self.test_trading_systems),
            ("AI Execution Bridge", self.test_ai_execution_bridge)
        ]
        
        for test_name, test_func in tests:
            self.test_results['tests_run'] += 1
            try:
                if test_func():
                    self.test_results['tests_passed'] += 1
                else:
                    self.test_results['tests_failed'] += 1
            except Exception as e:
                self.test_results['tests_failed'] += 1
                self.test_results['errors'].append(f"{test_name}: {str(e)}")
                logger.error(f"Test {test_name} crashed: {e}")
            
            time.sleep(0.5)  # Small delay between tests
        
        # Generate report
        self.generate_report()
    
    def generate_report(self):
        """Generate test report"""
        logger.info("\n" + "="*60)
        logger.info("Integration Test Report")
        logger.info("="*60)
        
        # Summary
        total = self.test_results['tests_run']
        passed = self.test_results['tests_passed']
        failed = self.test_results['tests_failed']
        
        logger.info(f"Tests Run: {total}")
        logger.info(f"Tests Passed: {passed} ({passed/total*100:.1f}%)")
        logger.info(f"Tests Failed: {failed}")
        
        # Component Status
        logger.info("\nComponent Status:")
        for component, status in self.test_results['component_status'].items():
            logger.info(f"  {component}: {status.get('status', 'unknown')}")
        
        # Errors
        if self.test_results['errors']:
            logger.info("\nErrors Found:")
            for error in self.test_results['errors']:
                logger.info(f"  ❌ {error}")
        
        # Save report
        report_file = f"integration_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(self.test_results, f, indent=2)
        
        logger.info(f"\nDetailed report saved to: {report_file}")
        
        # Overall result
        if failed == 0:
            logger.info("\n✅ ALL TESTS PASSED - System is ready for use!")
        else:
            logger.info(f"\n⚠️  {failed} tests failed - Review errors above")
        
        return self.test_results


def main():
    """Run integration tests"""
    tester = IntegratedSystemTester()
    results = tester.run_all_tests()
    
    # Exit with appropriate code
    sys.exit(0 if results['tests_failed'] == 0 else 1)


if __name__ == "__main__":
    main()