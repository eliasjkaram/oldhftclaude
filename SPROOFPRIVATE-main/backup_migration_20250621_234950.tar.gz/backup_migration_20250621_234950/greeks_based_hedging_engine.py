"""
Greeks-Based Dynamic Hedging Engine

Production-ready dynamic hedging system that:
- Calculates option Greeks (Delta, Gamma, Vega, Theta, Rho)
- Implements dynamic delta hedging
- Performs gamma scalping
- Manages vega exposure
- Executes portfolio-level Greek neutralization
- Provides real-time hedge monitoring and rebalancing
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging
from datetime import datetime, timedelta
from scipy.stats import norm
from scipy.optimize import minimize, LinearConstraint
import asyncio
import json
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class OptionType(Enum):
    """Option type"""
    CALL = "call"
    PUT = "put"


class HedgeType(Enum):
    """Types of hedging strategies"""
    DELTA = "delta"
    GAMMA = "gamma"
    VEGA = "vega"
    THETA = "theta"
    RHO = "rho"
    FULL = "full"


@dataclass
class OptionContract:
    """Option contract specification"""
    symbol: str
    underlying: str
    strike: float
    expiry: datetime
    option_type: OptionType
    multiplier: float = 100
    exchange: str = "CBOE"


@dataclass
class Greeks:
    """Option Greeks"""
    delta: float
    gamma: float
    vega: float
    theta: float
    rho: float
    charm: float = 0.0  # Delta decay
    vanna: float = 0.0  # Delta/Vega cross
    volga: float = 0.0  # Vega convexity


@dataclass
class MarketData:
    """Market data snapshot"""
    underlying_price: float
    implied_volatility: float
    risk_free_rate: float
    dividend_yield: float
    timestamp: datetime


@dataclass
class Position:
    """Position in portfolio"""
    instrument: Union[str, OptionContract]
    quantity: float
    avg_price: float
    current_price: float
    pnl: float = 0.0
    greeks: Optional[Greeks] = None


@dataclass
class HedgeOrder:
    """Hedge order to be executed"""
    hedge_id: str
    hedge_type: HedgeType
    instrument: Union[str, OptionContract]
    quantity: float
    side: str  # 'buy' or 'sell'
    order_type: str  # 'market', 'limit'
    limit_price: Optional[float] = None
    urgency: str = "normal"  # 'urgent', 'normal', 'patient'
    reason: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


class BlackScholes:
    """Black-Scholes option pricing and Greeks calculation"""
    
    @staticmethod
    def price(S: float, K: float, T: float, r: float, sigma: float, 
              q: float, option_type: OptionType) -> float:
        """Calculate option price using Black-Scholes"""
        if T <= 0:
            return max(0, S - K) if option_type == OptionType.CALL else max(0, K - S)
            
        d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        if option_type == OptionType.CALL:
            price = S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        else:
            price = K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)
            
        return price
        
    @staticmethod
    def calculate_greeks(S: float, K: float, T: float, r: float, sigma: float,
                        q: float, option_type: OptionType) -> Greeks:
        """Calculate all Greeks"""
        if T <= 0:
            # At expiration
            if option_type == OptionType.CALL:
                delta = 1.0 if S > K else 0.0
            else:
                delta = -1.0 if S < K else 0.0
                
            return Greeks(delta=delta, gamma=0, vega=0, theta=0, rho=0)
            
        d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        # Delta
        if option_type == OptionType.CALL:
            delta = np.exp(-q * T) * norm.cdf(d1)
        else:
            delta = -np.exp(-q * T) * norm.cdf(-d1)
            
        # Gamma
        gamma = np.exp(-q * T) * norm.pdf(d1) / (S * sigma * np.sqrt(T))
        
        # Vega
        vega = S * np.exp(-q * T) * norm.pdf(d1) * np.sqrt(T) / 100
        
        # Theta
        term1 = -S * np.exp(-q * T) * norm.pdf(d1) * sigma / (2 * np.sqrt(T))
        if option_type == OptionType.CALL:
            term2 = -r * K * np.exp(-r * T) * norm.cdf(d2)
            term3 = q * S * np.exp(-q * T) * norm.cdf(d1)
        else:
            term2 = r * K * np.exp(-r * T) * norm.cdf(-d2)
            term3 = -q * S * np.exp(-q * T) * norm.cdf(-d1)
        theta = (term1 + term2 + term3) / 365
        
        # Rho
        if option_type == OptionType.CALL:
            rho = K * T * np.exp(-r * T) * norm.cdf(d2) / 100
        else:
            rho = -K * T * np.exp(-r * T) * norm.cdf(-d2) / 100
            
        # Second-order Greeks
        charm = -q * np.exp(-q * T) * norm.cdf(d1) + np.exp(-q * T) * norm.pdf(d1) * \
                (2 * (r - q) * T - d2 * sigma * np.sqrt(T)) / (2 * T * sigma * np.sqrt(T))
                
        vanna = -np.exp(-q * T) * norm.pdf(d1) * d2 / sigma
        
        volga = vega * d1 * d2 / sigma
        
        return Greeks()
            delta=delta,
            gamma=gamma,
            vega=vega,
            theta=theta,
            rho=rho,
            charm=charm,
            vanna=vanna,
            volga=volga
        )


class GreeksAggregator:
    """Aggregate Greeks across portfolio"""
    
    def __init__(self):
        self.positions: List[Position] = []
        self.aggregate_greeks = Greeks(0, 0, 0, 0, 0)
        
    def add_position(self, position: Position):
        """Add position to portfolio"""
        self.positions.append(position)
        self._update_aggregate_greeks()
        
    def remove_position(self, instrument: str):
        """Remove position from portfolio"""
        self.positions = [p for p in self.positions]
                         if self._get_instrument_id(p.instrument) != instrument]
        self._update_aggregate_greeks()
        
    def _get_instrument_id(self, instrument: Union[str, OptionContract]) -> str:
        """Get instrument identifier"""
        if isinstance(instrument, str):
            return instrument
        return f"{instrument.symbol}_{instrument.strike}_{instrument.expiry.strftime('%Y%m%d')}"
        
    def _update_aggregate_greeks(self):
        """Update aggregate Greeks"""
        total_delta = sum(p.greeks.delta * p.quantity for p in self.positions if p.greeks)
        total_gamma = sum(p.greeks.gamma * p.quantity for p in self.positions if p.greeks)
        total_vega = sum(p.greeks.vega * p.quantity for p in self.positions if p.greeks)
        total_theta = sum(p.greeks.theta * p.quantity for p in self.positions if p.greeks)
        total_rho = sum(p.greeks.rho * p.quantity for p in self.positions if p.greeks)
        
        self.aggregate_greeks = Greeks()
            delta=total_delta,
            gamma=total_gamma,
            vega=total_vega,
            theta=total_theta,
            rho=total_rho
        )
        
    def get_greek_exposures(self) -> Dict[str, float]:
        """Get all Greek exposures"""
        return {}
            'delta': self.aggregate_greeks.delta,
            'gamma': self.aggregate_greeks.gamma,
            'vega': self.aggregate_greeks.vega,
            'theta': self.aggregate_greeks.theta,
            'rho': self.aggregate_greeks.rho,
            'dollar_delta': self.calculate_dollar_delta(),
            'dollar_gamma': self.calculate_dollar_gamma()
        }
        
    def calculate_dollar_delta(self) -> float:
        """Calculate dollar delta exposure"""
        dollar_delta = 0
        for position in self.positions:
            if position.greeks and isinstance(position.instrument, OptionContract):
                underlying_price = position.current_price  # Simplified
                dollar_delta += position.greeks.delta * position.quantity * \
                               position.instrument.multiplier * underlying_price
        return dollar_delta
        
    def calculate_dollar_gamma(self) -> float:
        """Calculate dollar gamma exposure"""
        dollar_gamma = 0
        for position in self.positions:
            if position.greeks and isinstance(position.instrument, OptionContract):
                underlying_price = position.current_price  # Simplified
                dollar_gamma += position.greeks.gamma * position.quantity * \
                               position.instrument.multiplier * underlying_price**2 / 100
        return dollar_gamma


class HedgeCalculator:
    """Calculate required hedges"""
    
    def __init__(self, available_instruments: List[Union[str, OptionContract]]):
        self.available_instruments = available_instruments
        self.hedge_costs = {}  # Cache for hedge costs
        
    def calculate_delta_hedge(self, current_delta: float, 
                            target_delta: float = 0) -> List[HedgeOrder]:
        """Calculate delta hedge requirements"""
        delta_to_hedge = target_delta - current_delta
        
        if abs(delta_to_hedge) < 0.1:  # Threshold
            return []
            
        # Simple approach: hedge with underlying
        hedge_orders = []
        
        if delta_to_hedge > 0:
            # Need to buy underlying
            hedge_orders.append(HedgeOrder())
                hedge_id=f"delta_hedge_{datetime.now().timestamp()}",
                hedge_type=HedgeType.DELTA,
                instrument="UNDERLYING",
                quantity=delta_to_hedge,
                side="buy",
                order_type="market",
                reason=f"Delta hedge: current={current_delta:.2f}, target={target_delta:.2f}"
            ))
        else:
            # Need to sell underlying
            hedge_orders.append(HedgeOrder())
                hedge_id=f"delta_hedge_{datetime.now().timestamp()}",
                hedge_type=HedgeType.DELTA,
                instrument="UNDERLYING",
                quantity=abs(delta_to_hedge),
                side="sell",
                order_type="market",
                reason=f"Delta hedge: current={current_delta:.2f}, target={target_delta:.2f}"
            ))
            
        return hedge_orders
        
    def calculate_gamma_hedge(self, current_gamma: float,
                            target_gamma: float = 0,
                            available_options: List[Tuple[OptionContract, Greeks]] = None) -> List[HedgeOrder]:
        """Calculate gamma hedge using options"""
        if available_options is None:
            available_options = []
        gamma_to_hedge = target_gamma - current_gamma
        
        if abs(gamma_to_hedge) < 0.01:  # Threshold
            return []
            
        # Find best option to hedge gamma
        best_option = None
        best_quantity = 0
        min_vega_impact = float('inf')
        
        for option, greeks in available_options:
            if greeks.gamma != 0:
                quantity_needed = gamma_to_hedge / greeks.gamma
                vega_impact = abs(quantity_needed * greeks.vega)
                
                if vega_impact < min_vega_impact:
                    best_option = option
                    best_quantity = quantity_needed
                    min_vega_impact = vega_impact
                    
        if best_option:
            side = "buy" if best_quantity > 0 else "sell"
            return [HedgeOrder()
                hedge_id=f"gamma_hedge_{datetime.now().timestamp()}",
                hedge_type=HedgeType.GAMMA,
                instrument=best_option,
                quantity=abs(best_quantity),
                side=side,
                order_type="limit",
                reason=f"Gamma hedge: current={current_gamma:.4f}, target={target_gamma:.4f}"
            )]
            
        return []
        
    def calculate_vega_hedge(self, current_vega: float,
                           target_vega: float = 0,
                           available_options: List[Tuple[OptionContract, Greeks]] = None) -> List[HedgeOrder]:
        """Calculate vega hedge"""
        if available_options is None:
            available_options = []
        vega_to_hedge = target_vega - current_vega
        
        if abs(vega_to_hedge) < 1:  # Threshold
            return []
            
        # Find best option to hedge vega with minimal gamma impact
        best_option = None
        best_quantity = 0
        min_gamma_impact = float('inf')
        
        for option, greeks in available_options:
            if greeks.vega != 0:
                quantity_needed = vega_to_hedge / greeks.vega
                gamma_impact = abs(quantity_needed * greeks.gamma)
                
                if gamma_impact < min_gamma_impact:
                    best_option = option
                    best_quantity = quantity_needed
                    min_gamma_impact = gamma_impact
                    
        if best_option:
            side = "buy" if best_quantity > 0 else "sell"
            return [HedgeOrder()
                hedge_id=f"vega_hedge_{datetime.now().timestamp()}",
                hedge_type=HedgeType.VEGA,
                instrument=best_option,
                quantity=abs(best_quantity),
                side=side,
                order_type="limit",
                reason=f"Vega hedge: current={current_vega:.2f}, target={target_vega:.2f}"
            )]
            
        return []
        
    def calculate_portfolio_hedge(self, current_greeks: Greeks,
                                target_greeks: Greeks,
                                available_options: List[Tuple[OptionContract, Greeks]],
                                constraints: Dict[str, Any] = None) -> List[HedgeOrder]:
        """Calculate optimal portfolio hedge considering all Greeks"""
        n_options = len(available_options)
        
        if n_options == 0:
            return []
            
        # Setup optimization problem
        # Decision variables: quantities of each available option
        
        # Objective: minimize hedging cost
        def objective(quantities):
            cost = 0
            for i, (option, _) in enumerate(available_options):
                # Simplified cost model
                cost += abs(quantities[i]) * 0.01  # Transaction cost
            return cost
            
        # Constraints: match target Greeks
        def delta_constraint(quantities):
            total_delta = current_greeks.delta
            for i, (_, greeks) in enumerate(available_options):
                total_delta += quantities[i] * greeks.delta
            return abs(total_delta - target_greeks.delta)
            
        def gamma_constraint(quantities):
            total_gamma = current_greeks.gamma
            for i, (_, greeks) in enumerate(available_options):
                total_gamma += quantities[i] * greeks.gamma
            return abs(total_gamma - target_greeks.gamma)
            
        def vega_constraint(quantities):
            total_vega = current_greeks.vega
            for i, (_, greeks) in enumerate(available_options):
                total_vega += quantities[i] * greeks.vega
            return abs(total_vega - target_greeks.vega)
            
        # Initial guess
        x0 = np.zeros(n_options)
        
        # Bounds
        bounds = [(-1000, 1000) for _ in range(n_options)]
        
        # Optimize
        constraints = []
            {'type': 'eq', 'fun': delta_constraint},
            {'type': 'eq', 'fun': gamma_constraint},
            {'type': 'eq', 'fun': vega_constraint}
        ]
        
        result = minimize(objective, x0, method='SLSQP', 
                         bounds=bounds, constraints=constraints)
        
        hedge_orders = []
        if result.success:
            for i, quantity in enumerate(result.x):
                if abs(quantity) > 0.1:  # Threshold
                    option = available_options[i][0]
                    side = "buy" if quantity > 0 else "sell"
                    hedge_orders.append(HedgeOrder())
                        hedge_id=f"portfolio_hedge_{i}_{datetime.now().timestamp()}",
                        hedge_type=HedgeType.FULL,
                        instrument=option,
                        quantity=abs(quantity),
                        side=side,
                        order_type="limit",
                        reason="Portfolio Greek neutralization"
                    ))
                    
        return hedge_orders


class DynamicHedgingEngine:
    """Main dynamic hedging engine"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.aggregator = GreeksAggregator()
        self.hedge_calculator = HedgeCalculator([])
        self.active_hedges: List[HedgeOrder] = []
        self.hedge_history: List[Dict[str, Any]] = []
        self.market_data_cache: Dict[str, MarketData] = {}
        self.is_running = False
        
        # Hedging parameters
        self.delta_threshold = config.get('delta_threshold', 10)
        self.gamma_threshold = config.get('gamma_threshold', 1)
        self.vega_threshold = config.get('vega_threshold', 100)
        self.rebalance_interval = config.get('rebalance_interval', 300)  # seconds
        
    def update_position(self, position: Position):
        """Update position in portfolio"""
        # Calculate Greeks if option
        if isinstance(position.instrument, OptionContract):
            market_data = self.get_market_data(position.instrument.underlying)
            greeks = self.calculate_position_greeks(position, market_data)
            position.greeks = greeks
            
        self.aggregator.add_position(position)
        logger.info(f"Updated position: {position.instrument}")
        
    def calculate_position_greeks(self, position: Position, 
                                 market_data: MarketData) -> Greeks:
        """Calculate Greeks for a position"""
        if not isinstance(position.instrument, OptionContract):
            return Greeks(0, 0, 0, 0, 0)
            
        option = position.instrument
        time_to_expiry = (option.expiry - datetime.now()).days / 365.0
        
        greeks = BlackScholes.calculate_greeks()
            S=market_data.underlying_price,
            K=option.strike,
            T=time_to_expiry,
            r=market_data.risk_free_rate,
            sigma=market_data.implied_volatility,
            q=market_data.dividend_yield,
            option_type=option.option_type
        )
        
        return greeks
        
    def get_market_data(self, underlying: str) -> MarketData:
        """Get current market data"""
        # In production, this would fetch real market data
        if underlying not in self.market_data_cache:
            self.market_data_cache[underlying] = MarketData()
                underlying_price=100.0,
                implied_volatility=0.20,
                risk_free_rate=0.03,
                dividend_yield=0.02,
                timestamp=datetime.now()
            )
        return self.market_data_cache[underlying]
        
    def check_hedge_requirements(self) -> List[HedgeOrder]:
        """Check if hedging is required"""
        current_exposures = self.aggregator.get_greek_exposures()
        hedge_orders = []
        
        # Check delta
        if abs(current_exposures['delta']) > self.delta_threshold:
            delta_hedges = self.hedge_calculator.calculate_delta_hedge()
                current_exposures['delta'], target_delta=0
            )
            hedge_orders.extend(delta_hedges)
            
        # Check gamma
        if abs(current_exposures['gamma']) > self.gamma_threshold:
            # Get available options for hedging
            available_options = self._get_available_options()
            gamma_hedges = self.hedge_calculator.calculate_gamma_hedge()
                current_exposures['gamma'], target_gamma=0, 
                available_options=available_options
            )
            hedge_orders.extend(gamma_hedges)
            
        # Check vega
        if abs(current_exposures['vega']) > self.vega_threshold:
            available_options = self._get_available_options()
            vega_hedges = self.hedge_calculator.calculate_vega_hedge()
                current_exposures['vega'], target_vega=0,
                available_options=available_options
            )
            hedge_orders.extend(vega_hedges)
            
        return hedge_orders
        
    def _get_available_options(self) -> List[Tuple[OptionContract, Greeks]]:
        """Get available options for hedging"""
        # In production, this would fetch from market data
        available = []
        
        # Example: ATM options with different expiries
        underlying_price = 100
        expiries = [30, 60, 90]  # days
        
        for days in expiries:
            for option_type in [OptionType.CALL, OptionType.PUT]:
                option = OptionContract()
                    symbol=f"SPY_{days}D_{option_type.value}",
                    underlying="SPY",
                    strike=underlying_price,
                    expiry=datetime.now() + timedelta(days=days),
                    option_type=option_type
                )
                
                market_data = self.get_market_data("SPY")
                greeks = BlackScholes.calculate_greeks()
                    S=market_data.underlying_price,
                    K=option.strike,
                    T=days/365.0,
                    r=market_data.risk_free_rate,
                    sigma=market_data.implied_volatility,
                    q=market_data.dividend_yield,
                    option_type=option.option_type
                )
                
                available.append((option, greeks))
                
        return available
        
    async def execute_hedge(self, hedge_order: HedgeOrder) -> bool:
        """Execute hedge order"""
        logger.info(f"Executing hedge: {hedge_order.hedge_id} - ")
                   f"{hedge_order.side} {hedge_order.quantity} {hedge_order.instrument}")
        
        # In production, this would send order to execution system
        # Simulate execution
        await asyncio.sleep(0.1)
        
        # Record hedge
        self.active_hedges.append(hedge_order)
        self.hedge_history.append({)
            'hedge_order': hedge_order,
            'execution_time': datetime.now(),
            'status': 'executed'
        })
        
        return True
        
    async def run_hedging_loop(self):
        """Main hedging loop"""
        self.is_running = True
        
        while self.is_running:
            try:
                # Update market data
                self._update_market_data()
                
                # Recalculate Greeks
                self._recalculate_all_greeks()
                
                # Check hedge requirements
                hedge_orders = self.check_hedge_requirements()
                
                # Execute hedges
                for hedge_order in hedge_orders:
                    success = await self.execute_hedge(hedge_order)
                    if success:
                        logger.info(f"Hedge executed: {hedge_order.hedge_id}")
                    else:
                        logger.error(f"Hedge failed: {hedge_order.hedge_id}")
                        
                # Log current exposures
                exposures = self.aggregator.get_greek_exposures()
                logger.info(f"Current exposures: Delta={exposures['delta']:.2f}, ")
                          f"Gamma={exposures['gamma']:.4f}, "
                          f"Vega={exposures['vega']:.2f}")
                          
            except Exception as e:
                logger.error(f"Error in hedging loop: {e}")
                
            await asyncio.sleep(self.rebalance_interval)
            
    def _update_market_data(self):
        """Update market data for all underlyings"""
        # In production, fetch real market data
        for underlying in set(p.instrument.underlying for p in self.aggregator.positions)
                            if isinstance(p.instrument, OptionContract)):
            # Simulate market movement
            current_data = self.market_data_cache.get(underlying)
            if current_data:
                # Random walk
                price_change = np.random.normal(0, current_data.implied_volatility *)
                                              np.sqrt(self.rebalance_interval/252/86400))
                new_price = current_data.underlying_price * (1 + price_change)
                
                self.market_data_cache[underlying] = MarketData()
                    underlying_price=new_price,
                    implied_volatility=current_data.implied_volatility * 
                                     (1 + np.random.normal(0, 0.01)),
                    risk_free_rate=current_data.risk_free_rate,
                    dividend_yield=current_data.dividend_yield,
                    timestamp=datetime.now()
                )
                
    def _recalculate_all_greeks(self):
        """Recalculate Greeks for all positions"""
        for position in self.aggregator.positions:
            if isinstance(position.instrument, OptionContract):
                market_data = self.get_market_data(position.instrument.underlying)
                position.greeks = self.calculate_position_greeks(position, market_data)
                
        self.aggregator._update_aggregate_greeks()
        
    def generate_hedge_report(self) -> Dict[str, Any]:
        """Generate hedging report"""
        exposures = self.aggregator.get_greek_exposures()
        
        report = {}
            'timestamp': datetime.now().isoformat(),
            'exposures': exposures,
            'positions': len(self.aggregator.positions),
            'active_hedges': len(self.active_hedges),
            'hedge_history': len(self.hedge_history),
            'thresholds': {}
                'delta': self.delta_threshold,
                'gamma': self.gamma_threshold,
                'vega': self.vega_threshold
            },
            'recent_hedges': []
        }
        
        # Add recent hedges
        for hedge_record in self.hedge_history[-10:]:
            hedge = hedge_record['hedge_order']
            report['recent_hedges'].append({)
                'time': hedge_record['execution_time'].isoformat(),
                'type': hedge.hedge_type.value,
                'instrument': str(hedge.instrument),
                'quantity': hedge.quantity,
                'side': hedge.side,
                'reason': hedge.reason
            })
            
        return report
        
    def stop(self):
        """Stop hedging engine"""
        self.is_running = False
        logger.info("Hedging engine stopped")


class GreeksBasedHedgingSystem:
    """Complete Greeks-based hedging system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.engine = DynamicHedgingEngine(config)
        self.monitoring_task = None
        
    async def start(self):
        """Start hedging system"""
        logger.info("Starting Greeks-Based Hedging System")
        self.monitoring_task = asyncio.create_task(self.engine.run_hedging_loop())
        
    async def stop(self):
        """Stop hedging system"""
        logger.info("Stopping Greeks-Based Hedging System")
        self.engine.stop()
        if self.monitoring_task:
            self.monitoring_task.cancel()
            
    def add_option_position(self, option: OptionContract, quantity: float, 
                           avg_price: float):
        """Add option position"""
        position = Position()
            instrument=option,
            quantity=quantity,
            avg_price=avg_price,
            current_price=avg_price  # Will be updated
        )
        self.engine.update_position(position)
        
    def add_stock_position(self, symbol: str, quantity: float, avg_price: float):
        """Add stock position"""
        position = Position()
            instrument=symbol,
            quantity=quantity,
            avg_price=avg_price,
            current_price=avg_price,
            greeks=Greeks(delta=1.0 * quantity, gamma=0, vega=0, theta=0, rho=0)
        )
        self.engine.update_position(position)
        
    def get_current_exposures(self) -> Dict[str, float]:
        """Get current Greek exposures"""
        return self.engine.aggregator.get_greek_exposures()
        
    def get_hedge_report(self) -> Dict[str, Any]:
        """Get hedging report"""
        return self.engine.generate_hedge_report()


async def main():
    """Example usage of Greeks-based hedging system"""
    
    # Configuration
    config = {}
        'delta_threshold': 50,
        'gamma_threshold': 5,
        'vega_threshold': 200,
        'rebalance_interval': 10  # 10 seconds for demo
    }
    
    # Create system
    system = GreeksBasedHedgingSystem(config)
    
    # Add some option positions
    # Long call spread
    call_long = OptionContract()
        symbol="SPY_430C_20240315",
        underlying="SPY",
        strike=430,
        expiry=datetime(2024, 3, 15),
        option_type=OptionType.CALL
    )
    system.add_option_position(call_long, 10, 5.50)
    
    call_short = OptionContract()
        symbol="SPY_440C_20240315",
        underlying="SPY",
        strike=440,
        expiry=datetime(2024, 3, 15),
        option_type=OptionType.CALL
    )
    system.add_option_position(call_short, -10, 2.50)
    
    # Long put for protection
    put_long = OptionContract()
        symbol="SPY_420P_20240315",
        underlying="SPY",
        strike=420,
        expiry=datetime(2024, 3, 15),
        option_type=OptionType.PUT
    )
    system.add_option_position(put_long, 5, 3.00)
    
    # Start system
    await system.start()
    
    # Run for a while
    for i in range(6):
        await asyncio.sleep(10)
        
        # Print current exposures
        exposures = system.get_current_exposures()
        print(f"\nTime {i*10}s - Current Exposures:")
        for greek, value in exposures.items():
            print(f"  {greek}: {value:.2f}")
            
    # Get final report
    report = system.get_hedge_report()
    print("\nHedging Report:")
    print(json.dumps(report, indent=2, default=str))
    
    # Stop system
    await system.stop()


if __name__ == "__main__":
    asyncio.run(main())
class GreeksBasedHedgingEngine:
    """Stub implementation for GreeksBasedHedgingEngine"""
    def __init__(self, *args, **kwargs):
        self.config = kwargs
        print(f"Initialized {self.__class__.__name__}")
    
    def run(self):
        print(f"Running {self.__class__.__name__}")
        return True

__all__ = ["GreeksBasedHedgingEngine"]
