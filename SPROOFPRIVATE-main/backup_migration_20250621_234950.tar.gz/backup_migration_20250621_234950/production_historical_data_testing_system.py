
#!/usr/bin/env python3
# TODO: Consider using UnifiedDataAPI from data_api_fixer.py for robust data fetching
"""
Comprehensive Historical Data Testing System
==========================================

A sophisticated testing framework that:
1. Detects when markets are closed
2. Automatically switches to historical data mode
3. Uses data from yfinance, Alpaca, and MinIO
4. Randomly selects 5-day periods from 2022-2023
5. Integrates with all existing trading algorithms
6. Provides realistic market simulation
7. Tracks performance as if trading live

Author: AI Trading System Development Team
Version: 1.0 - Complete Historical Testing System
"""

# Alpaca imports
from typing import Dict, List, Optional, Tuple
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
import json
import time
import random
import logging
import asyncio
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
from pathlib import Path
import pandas as pd
import numpy as np
import threading
from queue import Queue
import warnings
warnings.filterwarnings('ignore')

# Import data sources
import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
try:
    ALPACA_AVAILABLE = True
except ImportError:
    ALPACA_AVAILABLE = False

# Import MinIO integration
from minio_data_integration import MinIODataIntegration

# Import existing systems
from historical_data_engine import HistoricalDataEngine
from robust_data_fetcher import RobustDataFetcher

from universal_market_data import get_current_market_data, validate_price


# =============================================================================
# CONFIGURATION
# =============================================================================

# Market hours (Eastern Time)
MARKET_OPEN_TIME = "09:30"
MARKET_CLOSE_TIME = "16:00"
MARKET_TIMEZONE = "US/Eastern"

# Historical data configuration
HISTORICAL_START_DATE = "2022-01-01"
HISTORICAL_END_DATE = "2023-12-31"
HISTORICAL_PERIOD_DAYS = 5  # 5-day testing periods

# Alpaca credentials
ALPACA_PAPER_API_KEY = os.getenv('ALPACA_PAPER_API_KEY', '<ALPACA_PAPER_KEY>')
ALPACA_PAPER_API_SECRET = os.getenv('ALPACA_PAPER_API_SECRET', '<ALPACA_PAPER_SECRET>')
ALPACA_PAPER_BASE_URL = 'https://paper-api.alpaca.markets'

# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================

logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('historical_testing_system.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# =============================================================================
# DATA STRUCTURES
# =============================================================================


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

@dataclass
class MarketStatus:
    """Market status information"""
    is_open: bool
    current_time: datetime
    next_open: Optional[datetime] = None
    next_close: Optional[datetime] = None
    status_message: str = ""
    
@dataclass
class HistoricalPeriod:
    """Historical period for testing"""
    start_date: datetime
    end_date: datetime
    symbols: List[str]
    period_id: str = ""
    
    def __post_init__(self):
        if not self.period_id:
            self.period_id = f"{self.start_date.strftime('%Y%m%d')}_{self.end_date.strftime('%Y%m%d')}"

@dataclass
class TestingSession:
    """Testing session information"""
    session_id: str
    mode: str  # 'live' or 'historical'
    start_time: datetime
    historical_period: Optional[HistoricalPeriod] = None
    data_source: str = "mixed"  # 'yfinance', 'alpaca', 'minio', 'mixed'
    performance_metrics: Dict[str, Any] = field(default_factory=dict)
    trades_executed: List[Dict] = field(default_factory=list)
    
@dataclass
class SimulatedOrder:
    """Simulated order for historical testing"""
    order_id: str
    symbol: str
    side: str  # 'buy' or 'sell'
    quantity: float
    order_type: str  # 'market' or 'limit'
    price: float
    timestamp: datetime
    status: str = "pending"  # 'pending', 'filled', 'cancelled'
    filled_price: Optional[float] = None
    filled_timestamp: Optional[datetime] = None

# =============================================================================
# MARKET STATUS DETECTOR
# =============================================================================

class MarketStatusDetector:
    """Detects market open/closed status and trading hours"""
    
    def __init__(self):
        self.logger = logging.getLogger(f"{__name__}.MarketStatusDetector")
        self.alpaca_client = None
        
        if ALPACA_AVAILABLE:
            try:
                self.alpaca_client = TradingClient(ALPACA_PAPER_API_KEY, ALPACA_PAPER_API_SECRET, paper=True)
                self.logger.info("✅ Alpaca client initialized for market status")
            except Exception as e:
                self.logger.error(f"❌ Failed to initialize Alpaca client: {e}")
                
    def get_market_status(self) -> MarketStatus:
        """Get current market status"""
        current_time = datetime.now(timezone.utc)
        
        # Try Alpaca first for accurate market hours
        if self.alpaca_client:
            try:
                clock = self.alpaca_client.get_clock()
                
                return MarketStatus()
                    is_open=clock.is_open,
                    current_time=current_time,
                    next_open=clock.next_open.replace(tzinfo=timezone.utc) if clock.next_open else None,
                    next_close=clock.next_close.replace(tzinfo=timezone.utc) if clock.next_close else None,
                    status_message=f"Market is {'open' if clock.is_open else 'closed'}"
                )
            except Exception as e:
                self.logger.warning(f"⚠️ Alpaca market status failed, using fallback: {e}")
        
        # Fallback: Simple time-based check
        return self._fallback_market_status()
        
    def _fallback_market_status(self) -> MarketStatus:
        """Fallback market status based on time"""
        import pytz
        
        et_tz = pytz.timezone(MARKET_TIMEZONE)
        current_et = datetime.now(et_tz)
        
        # Check if weekend
        if current_et.weekday() >= 5:  # Saturday = 5, Sunday = 6
            is_open = False
            status_message = "Market closed (weekend)"
            
            # Calculate next Monday open
            days_until_monday = 7 - current_et.weekday()
            next_open = current_et.replace(hour=9, minute=30, second=0, microsecond=0)
            next_open += timedelta(days=days_until_monday)
            next_close = None
        else:
            # Weekday - check time
            market_open = current_et.replace(hour=9, minute=30, second=0, microsecond=0)
            market_close = current_et.replace(hour=16, minute=0, second=0, microsecond=0)
            
            if current_et < market_open:
                is_open = False
                status_message = "Market closed (pre-market)"
                next_open = market_open
                next_close = market_close
            elif current_et > market_close:
                is_open = False
                status_message = "Market closed (after-hours)"
                
                # Next open is tomorrow
                next_open = market_open + timedelta(days=1)
                if next_open.weekday() >= 5:  # If tomorrow is weekend
                    days_until_monday = 7 - next_open.weekday() + 1
                    next_open += timedelta(days=days_until_monday)
                next_close = None
            else:
                is_open = True
                status_message = "Market open"
                next_open = None
                next_close = market_close
                
        return MarketStatus()
            is_open=is_open,
            current_time=datetime.now(timezone.utc),
            next_open=next_open.astimezone(timezone.utc) if next_open else None,
            next_close=next_close.astimezone(timezone.utc) if next_close else None,
            status_message=status_message
        )
        
    def is_market_open(self) -> bool:
        """Quick check if market is open"""
        return self.get_market_status().is_open

# =============================================================================
# HISTORICAL DATA MANAGER
# =============================================================================

class HistoricalDataManager:
    """Manages historical data from multiple sources"""
    
    def __init__(self):
        self.logger = logging.getLogger(f"{__name__}.HistoricalDataManager")
        
        # Initialize data sources
        self.yfinance_engine = HistoricalDataEngine(use_alpaca=False)  # YFinance only
        self.alpaca_engine = HistoricalDataEngine(use_alpaca=True) if ALPACA_AVAILABLE else None
        self.minio_integration = self._init_minio()
        
        # Cache for historical data
        self.data_cache = {}
        
        self.logger.info("🚀 Historical Data Manager initialized")
        
    def _init_minio(self) -> Optional[MinIODataIntegration]:
        """Initialize MinIO integration"""
        try:
            minio = MinIODataIntegration()
            self.logger.info("✅ MinIO integration initialized")
            return minio
        except Exception as e:
            self.logger.warning(f"⚠️ MinIO initialization failed: {e}")
            return None
            
    def get_random_historical_period(self, symbols: List[str]) -> HistoricalPeriod:
        """Get a random 5-day period from 2022-2023"""
        start_date = pd.to_datetime(HISTORICAL_START_DATE)
        end_date = pd.to_datetime(HISTORICAL_END_DATE)
        
        # Calculate total days
        total_days = (end_date - start_date).days
        
        # Random start within range (leave room for 5-day period)
        random_offset = random.randint(0, total_days - HISTORICAL_PERIOD_DAYS)
        period_start = start_date + timedelta(days=random_offset)
        
        # Skip weekends
        while period_start.weekday() >= 5:  # Saturday or Sunday
            period_start += timedelta(days=1)
            
        period_end = period_start + timedelta(days=HISTORICAL_PERIOD_DAYS - 1)
        
        # Ensure end is not weekend
        while period_end.weekday() >= 5:
            period_end += timedelta(days=1)
            
        return HistoricalPeriod()
            start_date=period_start,
            end_date=period_end,
            symbols=symbols
        )
        
    def fetch_historical_data(self, period: HistoricalPeriod, 
                            data_source: str = "mixed") -> Dict[str, pd.DataFrame]:
        """
        Fetch historical data for a period from specified source
        
        Args:
            period: Historical period to fetch
            data_source: 'yfinance', 'alpaca', 'minio', or 'mixed'
            
        Returns:
            Dictionary mapping symbols to DataFrames
        """
        self.logger.info(f"📊 Fetching data for {period.period_id} using {data_source}")
        
        cache_key = f"{period.period_id}_{data_source}"
        if cache_key in self.data_cache:
            return self.data_cache[cache_key]
            
        historical_data = {}
        
        if data_source == "mixed":
            # Use multiple sources with fallback
            sources = ['minio', 'alpaca', 'yfinance']
        else:
            sources = [data_source]
            
        for symbol in period.symbols:
            data_fetched = False
            
            for source in sources:
                try:
                    if source == "yfinance":
                        data = self._fetch_yfinance_data(symbol, period)
                    elif source == "alpaca" and self.alpaca_engine:
                        data = self._fetch_alpaca_data(symbol, period)
                    elif source == "minio" and self.minio_integration:
                        data = self._fetch_minio_data(symbol, period)
                    else:
                        continue
                        
                    if data is not None and not data.empty:
                        historical_data[symbol] = data
                        data_fetched = True
                        self.logger.debug(f"✅ Fetched {symbol} from {source}")
                        break
                        
                except Exception as e:
                    self.logger.debug(f"Failed to fetch {symbol} from {source}: {e}")
                    
            if not data_fetched:
                self.logger.warning(f"⚠️ Could not fetch data for {symbol}")
                
        # Cache the result
        self.data_cache[cache_key] = historical_data
        
        self.logger.info(f"📊 Fetched data for {len(historical_data)}/{len(period.symbols)} symbols")
        return historical_data
        
    def _fetch_yfinance_data(self, symbol: str, period: HistoricalPeriod) -> pd.DataFrame:
        """Fetch data from Yahoo Finance"""
        ticker = YFinanceWrapper().get_ticker(symbol)
        data = ticker.history()
            start=period.start_date,
            end=period.end_date + timedelta(days=1),
            interval="1m"  # 1-minute data for realistic simulation
        )
        
        if data.empty:
            # Fallback to daily data
            data = ticker.history()
                start=period.start_date,
                end=period.end_date + timedelta(days=1),
                interval="1d"
            )
            
        return self._standardize_data(data, symbol)
        
    def _fetch_alpaca_data(self, symbol: str, period: HistoricalPeriod) -> pd.DataFrame:
        """Fetch data from Alpaca"""
        if not self.alpaca_engine:
            return pd.DataFrame()
            
        # Use the alpaca engine's fetch method
        data = self.alpaca_engine._fetch_alpaca_data()
            symbol, 
            self._calculate_period_string(period)
        )
        
        if data is not None:
            # Filter to exact period
            data = data[]
                (data.index >= period.start_date) & 
                (data.index <= period.end_date)
            ]
            
        return data if data is not None else pd.DataFrame()
        
    def _fetch_minio_data(self, symbol: str, period: HistoricalPeriod) -> pd.DataFrame:
        """Fetch data from MinIO"""
        if not self.minio_integration:
            return pd.DataFrame()
            
        try:
            data = self.minio_integration.get_historical_data()
                symbol=symbol,
                start_date=period.start_date,
                end_date=period.end_date,
                interval='minute'  # Try minute data first
            )
            
            if data.empty:
                # Fallback to daily
                data = self.minio_integration.get_historical_data()
                    symbol=symbol,
                    start_date=period.start_date,
                    end_date=period.end_date,
                    interval='daily'
                )
                
            return data
            
        except Exception as e:
            self.logger.debug(f"MinIO fetch error for {symbol}: {e}")
            return pd.DataFrame()
            
    def _standardize_data(self, data: pd.DataFrame, symbol: str) -> pd.DataFrame:
        """Standardize data format across sources"""
        if data.empty:
            return data
            
        # Ensure lowercase column names
        data.columns = data.columns.str.lower()
        
        # Add symbol column if not present
        if 'symbol' not in data.columns:
            data['symbol'] = symbol
            
        # Calculate returns if not present
        if 'returns' not in data.columns and 'close' in data.columns:
            data['returns'] = data['close'].pct_change()
            
        return data
        
    def _calculate_period_string(self, period: HistoricalPeriod) -> str:
        """Calculate period string for data fetching"""
        days = (period.end_date - period.start_date).days
        
        if days <= 5:
            return "5d"
        elif days <= 30:
            return "1mo"
        elif days <= 90:
            return "3mo"
        else:
            return "1y"

# =============================================================================
# MARKET SIMULATOR
# =============================================================================

class HistoricalMarketSimulator:
    """Simulates market conditions using historical data"""
    
    def __init__(self, historical_data: Dict[str, pd.DataFrame]):
        self.logger = logging.getLogger(f"{__name__}.MarketSimulator")
        self.historical_data = historical_data
        self.current_timestamp = None
        self.current_prices = {}
        self.order_book = []
        self.filled_orders = []
        
        # Initialize simulation
        self._initialize_simulation()
        
    def _initialize_simulation(self):
        """Initialize the simulation with first timestamp"""
        # Find earliest common timestamp
        timestamps = []
        for symbol, data in self.historical_data.items():
            if not data.empty:
                timestamps.extend(data.index.tolist()
                
        if timestamps:
            timestamps = sorted(set(timestamps)
            self.available_timestamps = timestamps
            self.current_timestamp = timestamps[0]
            self.timestamp_index = 0
            self._update_current_prices()
            
            self.logger.info(f"📊 Initialized simulation with {len(timestamps)} timestamps")
        else:
            self.logger.error("❌ No data available for simulation")
            
    def _update_current_prices(self):
        """Update current prices for all symbols"""
        for symbol, data in self.historical_data.items():
            if self.current_timestamp in data.index:
                row = data.loc[self.current_timestamp]
                self.current_prices[symbol] = {}
                    'bid': row.get('low', row.get('close', 0),
                    'ask': row.get('high', row.get('close', 0),
                    'last': row.get('close', 0),
                    'volume': row.get('volume', 0)
                }
                
    def advance_time(self, steps: int = 1) -> bool:
        """
        Advance simulation time by specified steps
        
        Returns:
            True if successful, False if end of data
        """
        if self.timestamp_index + steps >= len(self.available_timestamps):
            return False
            
        self.timestamp_index += steps
        self.current_timestamp = self.available_timestamps[self.timestamp_index]
        self._update_current_prices()
        
        # Process pending orders
        self._process_pending_orders()
        
        return True
        
    def get_current_price(self, symbol: str) -> Dict[str, float]:
        """Get current price data for a symbol"""
        return self.current_prices.get(symbol, {)
            'bid': 0, 'ask': 0, 'last': 0, 'volume': 0
        })
        
    def place_order(self, order: SimulatedOrder) -> str:
        """Place a simulated order"""
        order.timestamp = self.current_timestamp
        self.order_book.append(order)
        
        # Immediate execution for market orders
        if order.order_type == "market":
            self._execute_order(order)
            
        return order.order_id
        
    def _execute_order(self, order: SimulatedOrder):
        """Execute a simulated order"""
        price_data = self.get_current_price(order.symbol)
        
        if order.side == "buy":
            order.filled_price = price_data['ask']
        else:
            order.filled_price = price_data['bid']
            
        order.status = "filled"
        order.filled_timestamp = self.current_timestamp
        
        self.filled_orders.append(order)
        self.order_book.remove(order)
        
        self.logger.debug(f"✅ Executed {order.side} order for {order.symbol} @ ${order.filled_price:.2f}")
        
    def _process_pending_orders(self):
        """Process pending limit orders"""
        for order in self.order_book[:]:  # Copy list to allow modification
            if order.order_type == "limit":
                price_data = self.get_current_price(order.symbol)
                
                if order.side == "buy" and price_data['ask'] <= order.price:
                    self._execute_order(order)
                elif order.side == "sell" and price_data['bid'] >= order.price:
                    self._execute_order(order)
                    
    def get_market_snapshot(self) -> Dict[str, Any]:
        """Get current market snapshot"""
        return {}
            'timestamp': self.current_timestamp,
            'prices': self.current_prices.copy(),
            'pending_orders': len(self.order_book),
            'filled_orders': len(self.filled_orders),
            'simulation_progress': self.timestamp_index / len(self.available_timestamps)
        }

# =============================================================================
# ALGORITHM ADAPTER
# =============================================================================

class TradingAlgorithmAdapter:
    """Adapts existing trading algorithms to work with historical data"""
    
    def __init__(self, simulator: HistoricalMarketSimulator):
        self.logger = logging.getLogger(f"{__name__}.AlgorithmAdapter")
        self.simulator = simulator
        self.wrapped_algorithms = {}
        self.performance_tracker = {}
        
    def wrap_algorithm(self, algorithm_name: str, algorithm_instance: Any):
        """Wrap a trading algorithm for historical testing"""
        
        # Create a wrapper that intercepts data calls
        class AlgorithmWrapper:
            def __init__(self, original_algo, sim):
                self.original = original_algo
                self.simulator = sim
                
                # Monkey-patch data fetching methods
                if hasattr(self.original, 'fetch_market_data'):
                    self.original._original_fetch = self.original.fetch_market_data
                    self.original.fetch_market_data = self._fetch_historical_data
                    
                if hasattr(self.original, 'place_order'):
                    self.original._original_place_order = self.original.place_order
                    self.original.place_order = self._place_simulated_order
                    
            def _fetch_historical_data(self, symbol):
                """Override to return historical data"""
                return self.simulator.get_current_price(symbol)
                
            def get_market_data(symbols):
                return get_current_market_data(symbols)
                """Override to place simulated orders"""
                order = SimulatedOrder()
                    order_id=f"SIM_{int(time.time() * 1000)}",
                    symbol=symbol,
                    side=side,
                    quantity=quantity,
                    order_type=order_type,
                    price=price or 0,
                    timestamp=self.simulator.current_timestamp
                )
                return self.simulator.place_order(order)
                
        wrapped = AlgorithmWrapper(algorithm_instance, self.simulator)
        self.wrapped_algorithms[algorithm_name] = wrapped
        
        self.logger.info(f"✅ Wrapped algorithm: {algorithm_name}")
        return wrapped

# =============================================================================
# PERFORMANCE TRACKER
# =============================================================================

class PerformanceTracker:
    """Tracks performance metrics for historical testing"""
    
    def __init__(self, initial_capital: float = 100000):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        self.positions = {}
        self.trade_history = []
        self.equity_curve = []
        self.metrics = {}
        
    def update_position(self, symbol: str, quantity: float, price: float, side: str):
        """Update position after a trade"""
        if side == "buy":
            if symbol not in self.positions:
                self.positions[symbol] = {'quantity': 0, 'avg_price': 0}
                
            # Update average price
            total_value = (self.positions[symbol]['quantity'] * self.positions[symbol]['avg_price'] +)
                          quantity * price)
            new_quantity = self.positions[symbol]['quantity'] + quantity
            
            self.positions[symbol]['quantity'] = new_quantity
            self.positions[symbol]['avg_price'] = total_value / new_quantity if new_quantity > 0 else 0
            
            self.current_capital -= quantity * price
            
        else:  # sell
            if symbol in self.positions and self.positions[symbol]['quantity'] >= quantity:
                # Calculate profit/loss
                cost_basis = self.positions[symbol]['avg_price'] * quantity
                sale_value = quantity * price
                profit = sale_value - cost_basis
                
                self.positions[symbol]['quantity'] -= quantity
                self.current_capital += sale_value
                
                # Record trade
                self.trade_history.append({)
                    'timestamp': datetime.now(),
                    'symbol': symbol,
                    'side': side,
                    'quantity': quantity,
                    'price': price,
                    'profit': profit
                })
                
    def update_equity(self, current_prices: Dict[str, Dict[str, float]]):
        """Update equity curve with current market prices"""
        total_value = self.current_capital
        
        for symbol, position in self.positions.items():
            if position['quantity'] > 0 and symbol in current_prices:
                market_value = position['quantity'] * current_prices[symbol]['last']
                total_value += market_value
                
        self.equity_curve.append({)
            'timestamp': datetime.now(),
            'equity': total_value,
            'cash': self.current_capital,
            'positions_value': total_value - self.current_capital
        })
        
    def calculate_metrics(self) -> Dict[str, float]:
        """Calculate performance metrics"""
        if not self.equity_curve:
            return {}
            
        equity_values = [e['equity'] for e in self.equity_curve]
        
        # Calculate returns
        returns = pd.Series(equity_values).pct_change().dropna()
        
        # Basic metrics
        total_return = (equity_values[-1] - self.initial_capital) / self.initial_capital
        
        # Risk metrics
        volatility = returns.std() * np.sqrt(252) if len(returns) > 1 else 0
        sharpe_ratio = (returns.mean() * 252) / volatility if volatility > 0 else 0
        
        # Drawdown
        equity_series = pd.Series(equity_values)
        rolling_max = equity_series.expanding().max()
        drawdown = (equity_series - rolling_max) / rolling_max
        max_drawdown = drawdown.min()
        
        # Win rate
        winning_trades = [t for t in self.trade_history if t.get('profit', 0) > 0]
        win_rate = len(winning_trades) / len(self.trade_history) if self.trade_history else 0
        
        self.metrics = {}
            'total_return': total_return,
            'volatility': volatility,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'total_trades': len(self.trade_history),
            'final_equity': equity_values[-1] if equity_values else self.initial_capital
        }
        
        return self.metrics

# =============================================================================
# MAIN TESTING SYSTEM
# =============================================================================

class HistoricalDataTestingSystem:
    """
    Main system that coordinates historical data testing
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.market_detector = MarketStatusDetector()
        self.data_manager = HistoricalDataManager()
        self.current_session = None
        self.simulator = None
        self.performance_tracker = None
        
        # Database for storing results
        self.db_path = 'historical_testing.db'
        self._init_database()
        
        # Algorithm registry
        self.registered_algorithms = {}
        
        # Default symbols for testing
        self.default_symbols = []
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 
            'TSLA', 'NVDA', 'JPM', 'BAC', 'SPY'
        ]
        
        self.logger.info("🚀 Historical Data Testing System initialized")
        
    def _init_database(self):
        """Initialize database for storing test results"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS testing_sessions ()
                session_id TEXT PRIMARY KEY,
                mode TEXT,
                start_time TIMESTAMP,
                end_time TIMESTAMP,
                data_source TEXT,
                period_start TIMESTAMP,
                period_end TIMESTAMP,
                symbols TEXT,
                performance_metrics TEXT,
                trades_count INTEGER,
                final_equity REAL
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS trade_history ()
                trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                timestamp TIMESTAMP,
                symbol TEXT,
                side TEXT,
                quantity REAL,
                price REAL,
                profit REAL,
                FOREIGN KEY (session_id) REFERENCES testing_sessions(session_id)
            )
        ''')
        
        conn.commit()
        conn.close()
        
    def register_algorithm(self, name: str, algorithm_class: Any, config: Dict = None):
        """Register a trading algorithm for testing"""
        self.registered_algorithms[name] = {}
            'class': algorithm_class,
            'config': config or {},
            'instance': None
        }
        self.logger.info(f"✅ Registered algorithm: {name}")
        
    def check_and_start_session(self) -> TestingSession:
        """Check market status and start appropriate session"""
        market_status = self.market_detector.get_market_status()
        
        self.logger.info(f"📊 Market Status: {market_status.status_message}")
        
        if market_status.is_open:
            # Market is open - could run live or historical
            session = self._start_live_session()
        else:
            # Market is closed - switch to historical
            self.logger.info("🕐 Market closed - switching to historical data mode")
            session = self._start_historical_session()
            
        self.current_session = session
        return session
        
    def _start_live_session(self) -> TestingSession:
        """Start a live trading session"""
        session_id = f"LIVE_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        session = TestingSession()
            session_id=session_id,
            mode='live',
            start_time=datetime.now(),
            data_source='live'
        )
        
        self.logger.info(f"🟢 Started LIVE session: {session_id}")
        return session
        
    def _start_historical_session(self) -> TestingSession:
        """Start a historical testing session"""
        session_id = f"HIST_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Get random historical period
        period = self.data_manager.get_random_historical_period(self.default_symbols)
        
        # Randomly select data source
        data_sources = ['mixed', 'yfinance', 'alpaca', 'minio']
        if not ALPACA_AVAILABLE:
            data_sources.remove('alpaca')
        if not self.data_manager.minio_integration:
            data_sources.remove('minio')
            
        data_source = random.choice(data_sources)
        
        session = TestingSession()
            session_id=session_id,
            mode='historical',
            start_time=datetime.now(),
            historical_period=period,
            data_source=data_source
        )
        
        self.logger.info(f"🔄 Started HISTORICAL session: {session_id}")
        self.logger.info(f"📅 Testing period: {period.start_date.date()} to {period.end_date.date()}")
        self.logger.info(f"📊 Data source: {data_source}")
        
        return session
        
    async def run_testing_session(self, duration_minutes: int = 60):
        """Run a complete testing session"""
        # Check and start session
        session = self.check_and_start_session()
        
        if session.mode == 'historical':
            await self._run_historical_session(session, duration_minutes)
        else:
            await self._run_live_session(session, duration_minutes)
            
        # Save session results
        self._save_session_results(session)
        
        return session
        
    async def _run_historical_session(self, session: TestingSession, duration_minutes: int):
        """Run historical testing session"""
        self.logger.info(f"🚀 Running historical session for {duration_minutes} minutes")
        
        # Fetch historical data
        historical_data = self.data_manager.fetch_historical_data()
            session.historical_period,
            session.data_source
        )
        
        if not historical_data:
            self.logger.error("❌ No historical data available")
            return
            
        # Initialize simulator
        self.simulator = HistoricalMarketSimulator(historical_data)
        
        # Initialize performance tracker
        self.performance_tracker = PerformanceTracker()
        
        # Initialize and wrap algorithms
        algorithm_adapter = TradingAlgorithmAdapter(self.simulator)
        
        for name, algo_info in self.registered_algorithms.items():
            try:
                # Create algorithm instance
                instance = algo_info['class'](algo_info['config'])
                algo_info['instance'] = instance
                
                # Wrap for historical testing
                algorithm_adapter.wrap_algorithm(name, instance)
                
            except Exception as e:
                self.logger.error(f"❌ Failed to initialize {name}: {e}")
                
        # Run simulation
        start_time = time.time()
        simulation_steps = 0
        
        while time.time() - start_time < duration_minutes * 60:
            # Advance simulation time
            if not self.simulator.advance_time():
                self.logger.info("📊 Reached end of historical data")
                break
                
            simulation_steps += 1
            
            # Get market snapshot
            snapshot = self.simulator.get_market_snapshot()
            
            # Run each algorithm
            for name, algo_info in self.registered_algorithms.items():
                if algo_info['instance']:
                    try:
                        # Call algorithm's main trading logic
                        if hasattr(algo_info['instance'], 'analyze_and_trade'):
                            await algo_info['instance'].analyze_and_trade()
                        elif hasattr(algo_info['instance'], 'run'):
                            algo_info['instance'].run()
                            
                    except Exception as e:
                        self.logger.error(f"❌ Algorithm {name} error: {e}")
                        
            # Update performance metrics
            self._update_performance_metrics()
            
            # Log progress periodically
            if simulation_steps % 100 == 0:
                progress = snapshot['simulation_progress'] * 100
                self.logger.info(f"📊 Simulation progress: {progress:.1f}%")
                
            # Small delay to prevent CPU overload
            await asyncio.sleep(0.01)
            
        # Calculate final metrics
        session.performance_metrics = self.performance_tracker.calculate_metrics()
        session.trades_executed = self.simulator.filled_orders
        
        self.logger.info(f"✅ Historical session completed: {simulation_steps} steps")
        self.logger.info(f"📊 Final metrics: {session.performance_metrics}")
        
    async def _run_live_session(self, session: TestingSession, duration_minutes: int):
        """Run live trading session (placeholder for integration)"""
        self.logger.info(f"🟢 Running live session for {duration_minutes} minutes")
        
        # This would integrate with existing live trading systems
        # For now, just wait
        await asyncio.sleep(duration_minutes * 60)
        
    def _update_performance_metrics(self):
        """Update performance metrics during simulation"""
        if not self.simulator or not self.performance_tracker:
            return
            
        # Process filled orders
        for order in self.simulator.filled_orders:
            if order.order_id not in self.performance_tracker.trade_history:
                self.performance_tracker.update_position()
                    order.symbol,
                    order.quantity,
                    order.filled_price,
                    order.side
                )
                
        # Update equity curve
        self.performance_tracker.update_equity(self.simulator.current_prices)
        
    def _save_session_results(self, session: TestingSession):
        """Save session results to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Save session
        cursor.execute(''')
            INSERT INTO testing_sessions ()
                session_id, mode, start_time, end_time, data_source,
                period_start, period_end, symbols, performance_metrics,
                trades_count, final_equity
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', ()
            session.session_id,
            session.mode,
            session.start_time,
            datetime.now(),
            session.data_source,
            session.historical_period.start_date if session.historical_period else None,
            session.historical_period.end_date if session.historical_period else None,
            json.dumps(session.historical_period.symbols if session.historical_period else []),
            json.dumps(session.performance_metrics),
            len(session.trades_executed),
            session.performance_metrics.get('final_equity', 100000)
        )
        
        # Save trades
        for trade in session.trades_executed:
            cursor.execute(''')
                INSERT INTO trade_history ()
                    session_id, timestamp, symbol, side, quantity, price, profit
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', ()
                session.session_id,
                trade.filled_timestamp,
                trade.symbol,
                trade.side,
                trade.quantity,
                trade.filled_price,
                0  # Profit calculation would be more complex
            )
            
        conn.commit()
        conn.close()
        
        self.logger.info(f"💾 Saved session results: {session.session_id}")
        
    def get_performance_summary(self, last_n_sessions: int = 10) -> pd.DataFrame:
        """Get performance summary of recent sessions"""
        conn = sqlite3.connect(self.db_path)
        
        query = '''
            SELECT session_id, mode, start_time, data_source, 
                   trades_count, final_equity, performance_metrics
            FROM testing_sessions
            ORDER BY start_time DESC
            LIMIT ?
        '''
        
        df = pd.read_sql_query(query, conn, params=(last_n_sessions,)
        conn.close()
        
        # Parse performance metrics
        if not df.empty:
            metrics_df = pd.json_normalize()
                df['performance_metrics'].apply(json.loads)
            )
            df = pd.concat([df, metrics_df], axis=1)
            
        return df

# =============================================================================
# INTEGRATION HELPERS
# =============================================================================

def integrate_with_existing_system(system_name: str, config: Dict = None):
    """
    Helper function to integrate with existing trading systems
    
    Example:
        from historical_data_testing_system import integrate_with_existing_system
        
        # In your existing system
        testing_system = integrate_with_existing_system('my_algo', config)
        
        # Register your algorithm
        testing_system.register_algorithm('my_algo', MyAlgorithmClass, config)
        
        # Run testing
        await testing_system.run_testing_session(duration_minutes=30)
    """
    testing_system = HistoricalDataTestingSystem()
    
    # Auto-detect and import common systems
    try:
        # Import existing systems dynamically
        if system_name == 'aggressive_trading':
            from aggressive_trading_system import AggressiveTradingSystem
            testing_system.register_algorithm('aggressive', AggressiveTradingSystem, config)
            
        elif system_name == 'comprehensive_trading':
            from comprehensive_trading_system import ComprehensiveTradingSystem
            testing_system.register_algorithm('comprehensive', ComprehensiveTradingSystem, config)
            
        elif system_name == 'gpu_autoencoder':
            from gpu_autoencoder_dsg_system import GPUAutoencoderDSGSystem
            testing_system.register_algorithm('gpu_dsg', GPUAutoencoderDSGSystem, config)
            
        # Add more systems as needed
            
    except ImportError as e:
        logger.warning(f"Could not import {system_name}: {e}")
        
    return testing_system

# =============================================================================
# DEMO AND TESTING
# =============================================================================

async def self.get_production_config()\n📊 Current Market Status: {market_status.status_message}")
    logger.info(f"⏰ Current Time: {market_status.current_time}")
    
    if market_status.next_open:
        logger.info(f"📅 Next Open: {market_status.next_open}")
    if market_status.next_close:
        logger.info(f"📅 Next Close: {market_status.next_close}")
        
    # Register a simple test algorithm
    class SimpleTestAlgorithm:
        def __init__(self, config):
            self.config = config
            self.trades_made = 0
            
        def analyze_and_trade(self):
            # Simple logic - buy if we have no position
            if self.trades_made < 5:
                self.place_order('AAPL', 'buy', 10, 'market')
                self.trades_made += 1
                
    testing_system.register_algorithm('simple_test', SimpleTestAlgorithm, {})
    
    # Run a short test session
    logger.info(f"\n🔄 Starting testing session...")
    session = await testing_system.run_testing_session(duration_minutes=1)
    
    logger.info(f"\n✅ Session completed: {session.session_id}")
    logger.info(f"📊 Mode: {session.mode}")
    logger.info(f"📊 Data Source: {session.data_source}")
    
    if session.historical_period:
        logger.info(f"📅 Period: {session.historical_period.start_date.date()} to {session.historical_period.end_date.date()}")
        
    if session.performance_metrics:
        logger.info(f"\n📈 Performance Metrics:")
        for metric, value in session.performance_metrics.items():
            if isinstance(value, float):
                logger.info(f"  {metric}: {value:.4f}")
            else:
                logger.info(f"  {metric}: {value}")
                
    # Show recent session summary
    logger.info(f"\n📊 Recent Sessions Summary:")
    summary_df = testing_system.get_performance_summary(5)
    if not summary_df.empty:
        logger.info(summary_df[['session_id', 'mode', 'trades_count', 'final_equity']].to_string()
        
    logger.info(f"\n✅ Demo completed successfully!")

# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    # Run the demo
    asyncio.run(demo_historical_testing()