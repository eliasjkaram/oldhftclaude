#!/usr/bin/env python3
"""
Continual Learning Pipeline with Experience Replay
==================================================
Advanced continual learning system for options trading models
"""
from unified_error_handling import handle_errors



import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, Dataset
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable, Union
from dataclasses import dataclass, field
from collections import deque, defaultdict
import random
import time
import pickle
import json
from datetime import datetime, timedelta
import threading
import queue
from abc import ABC, abstractmethod

from unified_logging import get_logger
from unified_error_handling import retry, ErrorCategory, ErrorSeverity
from unified_configuration import get_config
from drift_detection_monitoring import DriftDetectionMonitor, DriftMetrics
from options_data_pipeline import OptionContract, OptionMarketData

logger = get_logger(__name__)

@dataclass
class ReplayBufferSample:
    """Single sample in replay buffer"""
    features: torch.Tensor
    target: torch.Tensor
    importance_weight: float = 1.0
    timestamp: datetime = field(default_factory=datetime.now)
    task_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TrainingTask:
    """Definition of a training task"""
    task_id: str
    name: str
    data_loader: DataLoader
    validation_loader: Optional[DataLoader] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ModelCheckpoint:
    """Model checkpoint with metadata"""
    model_state: Dict[str, torch.Tensor]
    optimizer_state: Dict
    task_history: List[str]
    performance_metrics: Dict[str, float]
    timestamp: datetime
    training_samples: int
    
class ReplayBuffer:
    """Advanced replay buffer with importance sampling"""
    
    def __init__(self, max_size: int = 10000, prioritized: bool = True):
        self.max_size = max_size
        self.prioritized = prioritized
        self.buffer = deque(maxlen=max_size)
        self.priorities = deque(maxlen=max_size)
        self.task_counts = defaultdict(int)
        
        # Importance sampling parameters
        self.alpha = 0.6  # Prioritization exponent
        self.beta = 0.4   # Importance sampling exponent
        self.beta_increment = 0.001
        self.epsilon = 1e-6
        
    def add(self, sample: ReplayBufferSample, priority: Optional[float] = None):
        """Add sample to buffer with priority"""
        if priority is None:
            priority = max(self.priorities) if self.priorities else 1.0
        
        self.buffer.append(sample)
        self.priorities.append(priority)
        
        if sample.task_id:
            self.task_counts[sample.task_id] += 1
    
    def sample(self, batch_size: int, beta: Optional[float] = None) -> List[ReplayBufferSample]:
        """Sample from buffer with importance weighting"""
        if len(self.buffer) < batch_size:
            return list(self.buffer)
        
        if not self.prioritized:
            return random.sample(list(self.buffer), batch_size)
        
        # Calculate sampling probabilities
        priorities = np.array(self.priorities)
        probs = priorities ** self.alpha
        probs /= probs.sum()
        
        # Sample indices
        indices = np.random.choice(len(self.buffer), batch_size, p=probs)
        
        # Calculate importance weights
        if beta is None:
            beta = self.beta
            self.beta = min(1.0, self.beta + self.beta_increment)
        
        total = len(self.buffer)
        weights = (total * probs[indices]) ** (-beta)
        weights /= weights.max()
        
        # Create samples with importance weights
        samples = []
        for i, idx in enumerate(indices):
            sample = self.buffer[idx]
            sample.importance_weight = weights[i]
            samples.append(sample)
        
        return samples
    
    def update_priorities(self, indices: List[int], priorities: List[float]):
        """Update priorities for samples"""
        for idx, priority in zip(indices, priorities):
            if 0 <= idx < len(self.priorities):
                self.priorities[idx] = priority + self.epsilon
    
    def get_task_distribution(self) -> Dict[str, float]:
        """Get distribution of tasks in buffer"""
        total = len(self.buffer)
        if total == 0:
            return {}
        
        return {}
            task: count / total 
            for task, count in self.task_counts.items()
        }
    
    def save(self, filepath: str):
        """Save buffer to disk"""
        with open(filepath, 'wb') as f:
            pickle.dump({)
                'buffer': list(self.buffer),
                'priorities': list(self.priorities),
                'task_counts': dict(self.task_counts),
                'beta': self.beta
            }, f)
    
    def load(self, filepath: str):
        """Load buffer from disk"""
        with open(filepath, 'rb') as f:
            data = pickle.load(f)
            self.buffer = deque(data['buffer'], maxlen=self.max_size)
            self.priorities = deque(data['priorities'], maxlen=self.max_size)
            self.task_counts = defaultdict(int, data['task_counts'])
            self.beta = data.get('beta', 0.4)

class ContinualLearningStrategy(ABC):
    """Abstract base class for continual learning strategies"""
    
    @abstractmethod
    def before_training_step(self, model: nn.Module, loss: torch.Tensor, 
                           current_task: TrainingTask) -> torch.Tensor:
        """Modify loss before backpropagation"""
        pass
    
    @abstractmethod
    def after_training_task(self, model: nn.Module, task: TrainingTask):
        """Update strategy after completing a task"""
        pass
    
    @abstractmethod
    def get_strategy_params(self) -> Dict[str, Any]:
        """Get strategy parameters for saving"""
        pass

class ExperienceReplayStrategy(ContinualLearningStrategy):
    """Experience replay continual learning strategy"""
    
    def __init__(self, buffer_size: int = 10000, replay_batch_size: int = 32):
        self.replay_buffer = ReplayBuffer(max_size=buffer_size, prioritized=True)
        self.replay_batch_size = replay_batch_size
        
    def before_training_step(self, model: nn.Module, loss: torch.Tensor,
                           current_task: TrainingTask) -> torch.Tensor:
        """Add replay loss to current loss"""
        if len(self.replay_buffer.buffer) < self.replay_batch_size:
            return loss
        
        # Sample from replay buffer
        replay_samples = self.replay_buffer.sample(self.replay_batch_size)
        
        # Calculate replay loss
        replay_features = torch.stack([s.features for s in replay_samples])
        replay_targets = torch.stack([s.target for s in replay_samples])
        weights = torch.tensor([s.importance_weight for s in replay_samples])
        
        # Forward pass on replay data
        replay_predictions = model(replay_features)
        
        # Calculate weighted loss
        criterion = nn.MSELoss(reduction='none')
        replay_losses = criterion(replay_predictions, replay_targets)
        weighted_replay_loss = (replay_losses * weights.unsqueeze(1)).mean()
        
        # Combine with current loss
        combined_loss = loss + 0.5 * weighted_replay_loss  # Balance factor
        
        return combined_loss
    
    def after_training_task(self, model: nn.Module, task: TrainingTask):
        """Store samples from completed task"""
        # Sample important examples from task
        for batch in task.data_loader:
            features, targets = batch
            
            # Calculate importance scores (using loss as proxy)
            with torch.no_grad():
                predictions = model(features)
                losses = nn.MSELoss(reduction='none')(predictions, targets)
                importance_scores = losses.mean(dim=1)
            
            # Add to replay buffer with priorities
            for i in range(features.size(0)):
                sample = ReplayBufferSample()
                    features=features[i],
                    target=targets[i],
                    task_id=task.task_id,
                    metadata={'task_name': task.name}
                )
                priority = importance_scores[i].item()
                self.replay_buffer.add(sample, priority)
    
    def get_strategy_params(self) -> Dict[str, Any]:
        return {}
            'buffer_size': self.replay_buffer.max_size,
            'replay_batch_size': self.replay_batch_size,
            'task_distribution': self.replay_buffer.get_task_distribution()
        }

class EWCStrategy(ContinualLearningStrategy):
    """Elastic Weight Consolidation strategy"""
    
    def __init__(self, lambda_param: float = 5000.0):
        self.lambda_param = lambda_param
        self.fisher_dict = {}
        self.optimal_params_dict = {}
        self.task_count = 0
        
    def before_training_step(self, model: nn.Module, loss: torch.Tensor,
                           current_task: TrainingTask) -> torch.Tensor:
        """Add EWC penalty to loss"""
        if self.task_count == 0:
            return loss
        
        ewc_loss = 0
        for name, param in model.named_parameters():
            if name in self.fisher_dict:
                fisher = self.fisher_dict[name]
                optimal_param = self.optimal_params_dict[name]
                ewc_loss += (fisher * (param - optimal_param) ** 2).sum()
        
        total_loss = loss + (self.lambda_param / 2) * ewc_loss
        return total_loss
    
    def after_training_task(self, model: nn.Module, task: TrainingTask):
        """Calculate Fisher information matrix after task"""
        model.eval()
        
        # Initialize Fisher information
        fisher_dict = {}
        for name, param in model.named_parameters():
            fisher_dict[name] = torch.zeros_like(param)
        
        # Calculate Fisher information
        total_samples = 0
        for batch in task.data_loader:
            features, targets = batch
            model.zero_grad()
            
            predictions = model(features)
            loss = nn.MSELoss()(predictions, targets)
            loss.backward()
            
            for name, param in model.named_parameters():
                if param.grad is not None:
                    fisher_dict[name] += param.grad.data ** 2
            
            total_samples += features.size(0)
        
        # Average Fisher information
        for name in fisher_dict:
            fisher_dict[name] /= total_samples
            
            # Update running average of Fisher information
            if name in self.fisher_dict:
                self.fisher_dict[name] = 0.9 * self.fisher_dict[name] + 0.1 * fisher_dict[name]
            else:
                self.fisher_dict[name] = fisher_dict[name]
        
        # Store optimal parameters
        for name, param in model.named_parameters():
            self.optimal_params_dict[name] = param.data.clone()
        
        self.task_count += 1
        model.train()
    
    def get_strategy_params(self) -> Dict[str, Any]:
        return {}
            'lambda_param': self.lambda_param,
            'task_count': self.task_count,
            'num_fisher_params': len(self.fisher_dict)
        }

class ContinualLearningPipeline:
    """Main continual learning pipeline"""
    
    def __init__(self, config_manager=None, strategy: str = 'rehearsal'):
        self.config = config_manager or get_config()
        
        # Initialize strategy
        if strategy == 'rehearsal':
            buffer_size = self.config.get('ml.rehearsal_buffer_size', 10000)
            self.strategy = ExperienceReplayStrategy(buffer_size=buffer_size)
        elif strategy == 'ewc':
            lambda_param = self.config.get('ml.ewc_lambda', 5000)
            self.strategy = EWCStrategy(lambda_param=lambda_param)
        else:
            raise ValueError(f"Unknown strategy: {strategy}")
        
        # Model management
        self.current_model = None
        self.model_version = 0
        self.task_history = []
        
        # Training state
        self.is_training = False
        self.training_queue = queue.Queue()
        self.training_thread = None
        
        # Performance tracking
        self.performance_history = defaultdict(list)
        self.training_metrics = defaultdict(list)
        
        # Checkpoint management
        self.checkpoint_dir = self.config.get('ml.checkpoint_dir', './checkpoints')
        self.max_checkpoints = 5
        
        # Integration with drift monitor
        self.drift_monitor = None
        
    def set_model(self, model: nn.Module):
        """Set the current model"""
        self.current_model = model
        logger.info(f"Model set with {sum(p.numel() for p in model.parameters())} parameters")
    
    def create_training_task(self, 
                           data: pd.DataFrame,
                           target_col: str,
                           task_name: str,
                           validation_split: float = 0.2) -> TrainingTask:
        """Create a training task from data"""
        # Convert to tensors
        feature_cols = [col for col in data.columns if col != target_col]
        X = torch.tensor(data[feature_cols].values, dtype=torch.float32)
        y = torch.tensor(data[target_col].values, dtype=torch.float32).unsqueeze(1)
        
        # Split data
        n_samples = len(data)
        n_val = int(n_samples * validation_split)
        indices = torch.randperm(n_samples)
        
        train_idx = indices[n_val:]
        val_idx = indices[:n_val]
        
        # Create datasets
        train_dataset = TensorDataset(X[train_idx], y[train_idx])
        val_dataset = TensorDataset(X[val_idx], y[val_idx])
        
        # Create data loaders
        train_loader = DataLoader()
            train_dataset,
            batch_size=self.config.get('ml.batch_size', 32),
            shuffle=True
        )
        
        val_loader = DataLoader()
            val_dataset,
            batch_size=self.config.get('ml.batch_size', 32),
            shuffle=False
        )
        
        # Create task
        task = TrainingTask()
            task_id=f"task_{self.model_version}_{int(time.time())}",
            name=task_name,
            data_loader=train_loader,
            validation_loader=val_loader,
            metadata={}
                'n_samples': n_samples,
                'n_features': len(feature_cols),
                'feature_names': feature_cols
            }
        )
        
        return task
    
    @handle_errors("continual_learning", ErrorCategory.SYSTEM, ErrorSeverity.HIGH)
    def train_on_task(self, task: TrainingTask, epochs: int = 10) -> Dict[str, float]:
        """Train model on a single task with continual learning"""
        if self.current_model is None:
            raise ValueError("No model set")
        
        logger.info(f"Starting training on task: {task.name}")
        
        # Setup optimizer
        optimizer = optim.Adam()
            self.current_model.parameters(),
            lr=self.config.get('ml.learning_rate', 0.001)
        )
        
        # Training metrics
        metrics = {}
            'task_id': task.task_id,
            'task_name': task.name,
            'train_losses': [],
            'val_losses': [],
            'best_val_loss': float('inf')
        }
        
        # Training loop
        for epoch in range(epochs):
            # Training phase
            self.current_model.train()
            train_losses = []
            
            for batch_idx, (features, targets) in enumerate(task.data_loader):
                optimizer.zero_grad()
                
                # Forward pass
                predictions = self.current_model(features)
                base_loss = nn.MSELoss()(predictions, targets)
                
                # Apply continual learning strategy
                loss = self.strategy.before_training_step()
                    self.current_model, base_loss, task
                )
                
                # Backward pass
                loss.backward()
                optimizer.step()
                
                train_losses.append(loss.item())
            
            # Validation phase
            val_loss = self._validate(task.validation_loader)
            
            # Record metrics
            avg_train_loss = np.mean(train_losses)
            metrics['train_losses'].append(avg_train_loss)
            metrics['val_losses'].append(val_loss)
            
            # Track best model
            if val_loss < metrics['best_val_loss']:
                metrics['best_val_loss'] = val_loss
                self._save_checkpoint(task, metrics)
            
            logger.info(f"Epoch {epoch+1}/{epochs} - Train Loss: {avg_train_loss:.4f}, Val Loss: {val_loss:.4f}")
        
        # Post-task updates
        self.strategy.after_training_task(self.current_model, task)
        
        # Update task history
        self.task_history.append(task.task_id)
        self.model_version += 1
        
        # Store performance
        self.performance_history[task.name].append(metrics)
        
        return metrics
    
    def _validate(self, val_loader: Optional[DataLoader]) -> float:
        """Validate model"""
        if val_loader is None:
            return 0.0
        
        self.current_model.eval()
        val_losses = []
        
        with torch.no_grad():
            for features, targets in val_loader:
                predictions = self.current_model(features)
                loss = nn.MSELoss()(predictions, targets)
                val_losses.append(loss.item())
        
        return np.mean(val_losses)
    
    def continual_update(self, new_data: pd.DataFrame, task_name: str = "update"):
        """Perform continual learning update with new data"""
        # Create task
        task = self.create_training_task()
            new_data,
            target_col='option_price',  # Adjust based on your data
            task_name=task_name
        )
        
        # Train on task
        metrics = self.train_on_task(task, epochs=5)  # Fewer epochs for updates
        
        return metrics
    
    def adapt_to_drift(self, drift_results: List[DriftMetrics]):
        """Adapt model based on detected drift"""
        # Determine if retraining is needed
        critical_drifts = [d for d in drift_results if d.drift_severity in ['high', 'critical']]
        
        if not critical_drifts:
            logger.info("No critical drift detected - no adaptation needed")
            return
        
        logger.warning(f"Critical drift detected in {len(critical_drifts)} features - triggering adaptation")
        
        # Queue adaptation task
        self.training_queue.put({)
            'type': 'drift_adaptation',
            'drift_results': drift_results,
            'timestamp': datetime.now()
        })
    
    def _save_checkpoint(self, task: TrainingTask, metrics: Dict[str, Any]):
        """Save model checkpoint"""
        checkpoint = ModelCheckpoint()
            model_state=self.current_model.state_dict(),
            optimizer_state={},  # Could save optimizer state too
            task_history=self.task_history.copy(),
            performance_metrics=metrics,
            timestamp=datetime.now(),
            training_samples=len(task.data_loader.dataset)
        )
        
        # Save checkpoint
        checkpoint_path = f"{self.checkpoint_dir}/checkpoint_v{self.model_version}_{task.task_id}.pt"
        torch.save(checkpoint, checkpoint_path)
        
        logger.info(f"Checkpoint saved: {checkpoint_path}")
        
        # Clean old checkpoints
        self._clean_old_checkpoints()
    
    def _clean_old_checkpoints(self):
        """Remove old checkpoints keeping only recent ones"""
        import os
        import glob
        
        checkpoints = glob.glob(f"{self.checkpoint_dir}/checkpoint_*.pt")
        checkpoints.sort(key=os.path.getmtime, reverse=True)
        
        # Remove old checkpoints
        for checkpoint in checkpoints[self.max_checkpoints:]:
            os.remove(checkpoint)
            logger.info(f"Removed old checkpoint: {checkpoint}")
    
    def load_checkpoint(self, checkpoint_path: str):
        """Load model from checkpoint"""
        checkpoint = torch.load(checkpoint_path)
        
        if isinstance(checkpoint, ModelCheckpoint):
            self.current_model.load_state_dict(checkpoint.model_state)
            self.task_history = checkpoint.task_history
            self.model_version = len(self.task_history)
            
            logger.info(f"Loaded checkpoint with {self.model_version} tasks")
        else:
            # Legacy checkpoint format
            self.current_model.load_state_dict(checkpoint)
            logger.info("Loaded legacy checkpoint")
    
    def get_adaptation_summary(self) -> Dict[str, Any]:
        """Get summary of continual learning adaptation"""
        # Strategy info
        strategy_info = self.strategy.get_strategy_params()
        
        # Performance trends
        performance_trends = {}
        for task_name, history in self.performance_history.items():
            if history:
                latest = history[-1]
                performance_trends[task_name] = {}
                    'best_val_loss': latest['best_val_loss'],
                    'num_updates': len(history)
                }
        
        # Buffer statistics (if using replay)
        buffer_stats = {}
        if isinstance(self.strategy, ExperienceReplayStrategy):
            buffer_stats = {}
                'buffer_size': len(self.strategy.replay_buffer.buffer),
                'task_distribution': self.strategy.replay_buffer.get_task_distribution()
            }
        
        return {}
            'model_version': self.model_version,
            'tasks_completed': len(self.task_history),
            'strategy': type(self.strategy).__name__,
            'strategy_params': strategy_info,
            'performance_trends': performance_trends,
            'buffer_stats': buffer_stats
        }
    
    def start_automated_adaptation(self):
        """Start automated continual learning thread"""
        self.is_training = True
        self.training_thread = threading.Thread()
            target=self._automated_training_loop,
            daemon=True
        )
        self.training_thread.start()
        logger.info("Automated continual learning started")
    
    def stop_automated_adaptation(self):
        """Stop automated training"""
        self.is_training = False
        if self.training_thread:
            self.training_thread.join(timeout=10)
        logger.info("Automated continual learning stopped")
    
    def _automated_training_loop(self):
        """Background training loop"""
        while self.is_training:
            try:
                # Wait for training tasks
                task_info = self.training_queue.get(timeout=60)
                
                if task_info['type'] == 'drift_adaptation':
                    # Handle drift-triggered adaptation
                    logger.info("Processing drift-triggered adaptation")
                    # Implementation would fetch recent data and retrain
                    
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error in automated training: {e}")
                time.sleep(60)


# Integration function
def integrate_continual_learning(master_system):
    """
    Integrate continual learning pipeline with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from continual_learning_pipeline import integrate_continual_learning
    integrate_continual_learning(self)
    """
    
    # Create pipeline instance
    strategy = master_system.config_manager.get('ml.continual_strategy', 'rehearsal')
    master_system.continual_learning = ContinualLearningPipeline()
        master_system.config_manager,
        strategy=strategy
    )
    
    # Connect to drift monitor
    if hasattr(master_system, 'drift_monitor'):
        master_system.continual_learning.drift_monitor = master_system.drift_monitor
        
        # Register drift callback
        def on_drift_detected(drift_results):
            master_system.continual_learning.adapt_to_drift(drift_results)
        
        master_system.drift_monitor.register_drift_callback(on_drift_detected)
    
    # Add methods to master system
    def train_model_continually(self, model: nn.Module, training_data: pd.DataFrame):
        """Train model with continual learning"""
        self.continual_learning.set_model(model)
        task = self.continual_learning.create_training_task()
            training_data,
            target_col='option_price',
            task_name='initial_training'
        )
        return self.continual_learning.train_on_task(task)
    
    def update_model_incrementally(self, new_data: pd.DataFrame):
        """Incrementally update model with new data"""
        return self.continual_learning.continual_update(new_data)
    
    def get_continual_learning_status(self) -> Dict[str, Any]:
        """Get continual learning status"""
        return self.continual_learning.get_adaptation_summary()
    
    # Bind methods
    master_system.train_model_continually = train_model_continually.__get__(master_system)
    master_system.update_model_incrementally = update_model_incrementally.__get__(master_system)
    master_system.get_continual_learning_status = get_continual_learning_status.__get__(master_system)
    
    # Start automated adaptation
    master_system.continual_learning.start_automated_adaptation()
    
    logger.info("Continual learning pipeline integrated with master system")


if __name__ == "__main__":
    # Test continual learning pipeline
    import torch.nn as nn
    
    # Create simple model
    class SimpleOptionsModel(nn.Module):
        def __init__(self, input_dim: int, hidden_dim: int = 64):
            super().__init__()
            self.fc1 = nn.Linear(input_dim, hidden_dim)
            self.fc2 = nn.Linear(hidden_dim, hidden_dim)
            self.fc3 = nn.Linear(hidden_dim, 1)
            self.relu = nn.ReLU()
            self.dropout = nn.Dropout(0.2)
        
        def forward(self, x):
            x = self.relu(self.fc1(x))
            x = self.dropout(x)
            x = self.relu(self.fc2(x))
            x = self.dropout(x)
            x = self.fc3(x)
            return x
    
    # Create pipeline
    pipeline = ContinualLearningPipeline(strategy='rehearsal')
    
    # Create synthetic data
    n_samples = 1000
    n_features = 20
    
    # Task 1 data
    task1_data = pd.DataFrame()
        np.random.randn(n_samples, n_features),
        columns=[f'feature_{i}' for i in range(n_features)]
    )
    task1_data['option_price'] = np.random.randn(n_samples) + 10
    
    # Create and set model
    model = SimpleOptionsModel(n_features)
    pipeline.set_model(model)
    
    # Train on task 1
    print("Training on Task 1...")
    task1 = pipeline.create_training_task(task1_data, 'option_price', 'task_1')
    metrics1 = pipeline.train_on_task(task1, epochs=5)
    print(f"Task 1 best validation loss: {metrics1['best_val_loss']:.4f}")
    
    # Task 2 data (shifted distribution)
    task2_data = pd.DataFrame()
        np.random.randn(n_samples, n_features) + 0.5,
        columns=[f'feature_{i}' for i in range(n_features)]
    )
    task2_data['option_price'] = np.random.randn(n_samples) + 15
    
    # Train on task 2
    print("\nTraining on Task 2...")
    task2 = pipeline.create_training_task(task2_data, 'option_price', 'task_2')
    metrics2 = pipeline.train_on_task(task2, epochs=5)
    print(f"Task 2 best validation loss: {metrics2['best_val_loss']:.4f}")
    
    # Show adaptation summary
    summary = pipeline.get_adaptation_summary()
    print(f"\nAdaptation Summary: {json.dumps(summary, indent=2)}")