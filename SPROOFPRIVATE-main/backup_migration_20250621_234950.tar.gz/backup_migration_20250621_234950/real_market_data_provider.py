#!/usr/bin/env python3
"""
Real Market Data Provider
========================
Gets ACTUAL live market data from Alpaca API and YFinance.
NO SIMULATION - ONLY REAL DATA!
"""

import os
import numpy as np
from datetime import datetime
import logging
import asyncio
from typing import Dict, List, Optional, Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealMarketDataProvider:
    """Gets REAL market data from Alpaca and YFinance - NO SIMULATION"""
    
    def __init__(self):
        self.alpaca_client = None
        self.alpaca_data_client = None
        self.yfinance_available = False
        self._setup_data_sources()
        
    def _setup_data_sources(self):
        """Set up Alpaca and YFinance connections"""
        # Setup Alpaca
        try:
            from alpaca.data import StockHistoricalDataClient
            from alpaca.trading.client import TradingClient
            
            # Use provided Alpaca credentials
            api_key = os.environ.get('ALPACA_API_KEY', 'PKEP9PIBDKOSUGHHY44Z')
            secret_key = os.environ.get('ALPACA_SECRET_KEY', 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ')
            
            self.alpaca_data_client = StockHistoricalDataClient(api_key, secret_key)
            self.alpaca_client = TradingClient(api_key, secret_key, paper=True)
            
            # Test connection
            account = self.alpaca_client.get_account()
            logger.info(f"✅ Alpaca connected! Account: ${float(account.portfolio_value):,.2f}")
            
        except Exception as e:
            logger.error(f"Alpaca connection failed: {e}")
            self.alpaca_data_client = None
            
        # Setup YFinance
        try:
            import yfinance as yf
            self.yfinance_available = True
            # Test yfinance
            test = yf.Ticker("AAPL").info
            logger.info("✅ YFinance connected and working!")
        except Exception as e:
            logger.error(f"YFinance not available: {e}")
            self.yfinance_available = False
    
    def get_market_data(self, symbols: Optional[List[str]] = None) -> Dict[str, Any]:
        """Get REAL market data - NO SIMULATION"""
        if symbols is None:
            symbols = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 'META', 'NVDA', 'SPY', 'QQQ']
        
        market_data = {}
        
        # Try Alpaca first for REAL data
        if self.alpaca_data_client:
            try:
                from alpaca.data.requests import StockLatestQuoteRequest, StockLatestBarRequest
                
                # Get latest quotes
                quote_request = StockLatestQuoteRequest(symbol_or_symbols=symbols)
                quotes = self.alpaca_data_client.get_stock_latest_quote(quote_request)
                
                # Get latest bars for more data
                bar_request = StockLatestBarRequest(symbol_or_symbols=symbols)
                bars = self.alpaca_data_client.get_stock_latest_bar(bar_request)
                
                for symbol in symbols:
                    if symbol in quotes and symbol in bars:
                        quote = quotes[symbol]
                        bar = bars[symbol]
                        
                        # Use REAL data from Alpaca
                        market_data[symbol] = {}
                            'bid': float(quote.bid_price) if quote.bid_price else float(bar.close),
                            'ask': float(quote.ask_price) if quote.ask_price else float(bar.close),
                            'price': float(bar.close),
                            'open': float(bar.open),
                            'high': float(bar.high),
                            'low': float(bar.low),
                            'volume': int(bar.volume),
                            'spread': float(quote.ask_price - quote.bid_price) if quote.ask_price and quote.bid_price else 0.01,
                            'timestamp': bar.timestamp,
                            'source': 'alpaca_live'
                        }
                        logger.info(f"Alpaca: {symbol} = ${market_data[symbol]['price']:.2f}")
                
                if market_data:
                    logger.info(f"✅ Got REAL data for {len(market_data)} symbols from Alpaca")
                    return market_data
                    
            except Exception as e:
                logger.error(f"Alpaca data fetch error: {e}")
        
        # Fallback to YFinance for REAL data
        if self.yfinance_available:
            try:
                import yfinance as yf
                logger.info("Using YFinance for REAL market data...")
                
                for symbol in symbols:
                    try:
                        ticker = yf.Ticker(symbol)
                        
                        # Get real-time price
                        info = ticker.info
                        history = ticker.history(period="1d", interval="1m")
                        
                        if not history.empty:
                            latest = history.iloc[-1]
                            
                            # Use REAL data from YFinance
                            bid = info.get('bid', latest['Close'])
                            ask = info.get('ask', latest['Close'])
                            
                            if bid is None or ask is None or bid == 0:
                                # If no bid/ask, use close with small spread
                                bid = latest['Close'] * 0.9999
                                ask = latest['Close'] * 1.0001
                            
                            market_data[symbol] = {}
                                'bid': float(bid),
                                'ask': float(ask),
                                'price': float(latest['Close']),
                                'open': float(latest['Open']),
                                'high': float(latest['High']),
                                'low': float(latest['Low']),
                                'volume': int(latest['Volume']),
                                'spread': float(ask - bid),
                                'timestamp': history.index[-1],
                                'source': 'yfinance_live'
                            }
                            logger.info(f"YFinance: {symbol} = ${market_data[symbol]['price']:.2f}")
                            
                    except Exception as e:
                        logger.error(f"YFinance error for {symbol}: {e}")
                        continue
                
                if market_data:
                    logger.info(f"✅ Got REAL data for {len(market_data)} symbols from YFinance")
                    return market_data
                    
            except Exception as e:
                logger.error(f"YFinance error: {e}")
        
        # If all else fails, return empty - NO FAKE DATA
        logger.error("❌ Could not get real market data from any source!")
        return {}
    
    def get_real_time_quote(self, symbol: str) -> Dict[str, float]:
        """Get real-time quote for a single symbol"""
        data = self.get_market_data([symbol])
        if symbol in data:
            return data[symbol]
        return {}
    
    def get_historical_data(self, symbol: str, period: str = "1mo") -> Any:
        """Get historical data from Alpaca or YFinance"""
        try:
            if self.alpaca_data_client:
                from alpaca.data.requests import StockBarsRequest
                from alpaca.data.timeframe import TimeFrame
                from datetime import datetime, timedelta
                
                # Calculate time range
                end = datetime.now()
                if period == "1d":
                    start = end - timedelta(days=1)
                    timeframe = TimeFrame.Minute
                elif period == "1wk":
                    start = end - timedelta(weeks=1)
                    timeframe = TimeFrame.Hour
                elif period == "1mo":
                    start = end - timedelta(days=30)
                    timeframe = TimeFrame.Day
                else:
                    start = end - timedelta(days=365)
                    timeframe = TimeFrame.Day
                
                request = StockBarsRequest()
                    symbol_or_symbols=symbol,
                    start=start,
                    end=end,
                    timeframe=timeframe
                )
                
                bars = self.alpaca_data_client.get_stock_bars(request)
                return bars.df
                
            elif self.yfinance_available:
                import yfinance as yf
                ticker = yf.Ticker(symbol)
                return ticker.history(period=period)
                
        except Exception as e:
            logger.error(f"Historical data error: {e}")
            return None

# Global instance
real_market_data = RealMarketDataProvider()

def get_real_market_data(symbols: Optional[List[str]] = None) -> Dict[str, Any]:
    """Get REAL market data - NO SIMULATION"""
    return real_market_data.get_market_data(symbols)

def get_real_quote(symbol: str) -> Dict[str, float]:
    """Get real-time quote for a symbol"""
    return real_market_data.get_real_time_quote(symbol)

# Test the connection
if __name__ == "__main__":
    print("Testing REAL market data connections...")
    print("=" * 80)
    
    # Test with common symbols
    test_symbols = ['AAPL', 'GOOGL', 'AMZN', 'TSLA', 'SPY']
    data = get_real_market_data(test_symbols)
    
    if data:
        print("\n✅ REAL MARKET DATA:")
        print("-" * 40)
        for symbol, info in data.items():
            print(f"{symbol}: ${info['price']:.2f} (Source: {info['source']})")
            print(f"  Bid: ${info['bid']:.2f} | Ask: ${info['ask']:.2f} | Spread: ${info['spread']:.2f}")
            print(f"  Volume: {info['volume']:,}")
            print()
    else:
        print("❌ Failed to get real market data!")