
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Enhanced Trading Prediction AI
Combines multiple advanced prediction models with ensemble methods
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler, RobustScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import ta
import time
import warnings
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
warnings.filterwarnings('ignore')

class TransformerPredictor(nn.Module):
    """Advanced Transformer model for price prediction"""
    
    def __init__(self, input_size=20, d_model=128, nhead=8, num_layers=6, seq_len=60):
        super(TransformerPredictor, self).__init__()
        self.d_model = d_model
        self.seq_len = seq_len
        
        # Input projection
        self.input_projection = nn.Linear(input_size, d_model)
        
        # Positional encoding
        self.pos_encoding = self._create_positional_encoding(seq_len, d_model)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer()
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=512,
            dropout=0.2,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # Output layers
        self.output_layers = nn.Sequential()
            nn.LayerNorm(d_model),
            nn.Linear(d_model, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 3)  # price, volatility, trend
        )
        
    def _create_positional_encoding(self, seq_len, d_model):
        pe = torch.zeros(seq_len, d_model)
        position = torch.arange(0, seq_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * -(np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe.unsqueeze(0)
    
    def forward(self, x):
        # Input projection and positional encoding
        x = self.input_projection(x)
        x = x + self.pos_encoding[:, :x.size(1), :].to(x.device)
        
        # Transformer encoding
        transformer_out = self.transformer(x)
        
        # Global average pooling
        pooled = transformer_out.mean(dim=1)
        
        # Output prediction
        return self.output_layers(pooled)

class AdvancedLSTM(nn.Module):
    """Enhanced LSTM with residual connections and attention"""
    
    def __init__(self, input_size=20, hidden_size=256, num_layers=4):
        super(AdvancedLSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # Multi-scale LSTM layers
        self.lstm1 = nn.LSTM(input_size, hidden_size, 2, batch_first=True, dropout=0.2)
        self.lstm2 = nn.LSTM(hidden_size, hidden_size//2, 2, batch_first=True, dropout=0.2)
        
        # Self-attention
        self.attention = nn.MultiheadAttention(hidden_size//2, num_heads=8, batch_first=True)
        
        # Residual connections
        self.residual_projection = nn.Linear(input_size, hidden_size//2)
        
        # Output layers
        self.output_layers = nn.Sequential()
            nn.LayerNorm(hidden_size//2),
            nn.Linear(hidden_size//2, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 3)
        )
        
    def forward(self, x):
        # Multi-scale LSTM processing
        lstm1_out, _ = self.lstm1(x)
        lstm2_out, _ = self.lstm2(lstm1_out)
        
        # Self-attention
        attn_out, _ = self.attention(lstm2_out, lstm2_out, lstm2_out)
        
        # Residual connection
        residual = self.residual_projection(x[:, -1, :])  # Use last timestep
        combined = attn_out[:, -1, :] + residual
        
        return self.output_layers(combined)

class EnhancedPredictionAI:
    """Advanced prediction system with ensemble methods"""
    
    def __init__(self, symbols=['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'NVDA']):
        self.symbols = symbols
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.models = {}
        self.scalers = {}
        self.feature_scalers = {}
        self.sequence_length = 60
        
        print(f"🧠 Enhanced Trading Prediction AI")
        print(f"Device: {self.device}")
        if torch.cuda.is_available():
            print(f"GPU: {torch.cuda.get_device_name(0)}")
            print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
    
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Advanced feature engineering with technical indicators"""
        
        # Basic price features
        df['returns'] = df['Close'].pct_change()
df["log_returns"] = np.log(df["Close"] / df["Close"].shift(1))
        df['volatility'] = df['returns'].rolling(20).std()
        
        # Technical indicators using ta library
        df['sma_5'] = ta.trend.sma_indicator(df['Close'], window=5)
        df['sma_20'] = ta.trend.sma_indicator(df['Close'], window=20)
        df['sma_50'] = ta.trend.sma_indicator(df['Close'], window=50)
        df['ema_12'] = ta.trend.ema_indicator(df['Close'], window=12)
        df['ema_26'] = ta.trend.ema_indicator(df['Close'], window=26)
        
        # MACD
        df['macd'] = ta.trend.macd_diff(df['Close'])
        df['macd_signal'] = ta.trend.macd_signal(df['Close'])
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # RSI
        df['rsi'] = ta.momentum.rsi(df['Close'], window=14)
        
        # Bollinger Bands
        bb_indicator = ta.volatility.BollingerBands(df['Close'])
        df['bb_upper'] = bb_indicator.bollinger_hband()
        df['bb_middle'] = bb_indicator.bollinger_mavg()
        df['bb_lower'] = bb_indicator.bollinger_lband()
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
        df['bb_position'] = (df['Close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
        
        # Volume indicators
        df['volume_sma'] = df['Volume'].rolling(20).mean()
        df['volume_ratio'] = df['Volume'] / df['volume_sma']
        
        # Price position indicators
        df['price_position_5'] = df['Close'] / df['sma_5']
        df['price_position_20'] = df['Close'] / df['sma_20']
        df['price_position_50'] = df['Close'] / df['sma_50']
        
        # Momentum indicators
        df['momentum_5'] = df['Close'] / df['Close'].shift(5)
        df['momentum_10'] = df['Close'] / df['Close'].shift(10)
        df['momentum_20'] = df['Close'] / df['Close'].shift(20)
        
        # Support/Resistance levels
        df['high_20'] = df['High'].rolling(20).max()
        df['low_20'] = df['Low'].rolling(20).min()
        df['price_range'] = (df['Close'] - df['low_20']) / (df['high_20'] - df['low_20'])
        
        return df
    
    def fetch_enhanced_data(self, symbol: str, period: str = "6mo") -> pd.DataFrame:
        """Fetch and enhance market data with features"""
        print(f"  📈 Fetching enhanced data for {symbol}...")
        
        try:
            ticker = YFinanceWrapper().get_ticker(symbol)
            df = ticker.history(period=period, interval="1h")
            
            if df.empty:
                raise ValueError(f"No data for {symbol}")
            
            # Engineer features
            df = self.engineer_features(df)
            
            # Drop NaN values
            df = df.dropna()
            
            if len(df) < self.sequence_length + 50:
                raise ValueError(f"Insufficient data for {symbol}")
            
            print(f"    ✅ {len(df)} enhanced records for {symbol}")
            return df
            
        except Exception as e:
            print(f"    ❌ Error fetching {symbol}: {e}")
            return pd.DataFrame()
    
    def prepare_sequences(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare sequences for training with enhanced features"""
        
        # Select feature columns
        feature_columns = []
            'Open', 'High', 'Low', 'Close', 'Volume',
            'returns', 'volatility', 'sma_5', 'sma_20', 'ema_12', 'ema_26',
            'macd', 'macd_signal', 'rsi', 'bb_width', 'bb_position',
            'volume_ratio', 'price_position_5', 'price_position_20',
            'momentum_5', 'momentum_10', 'price_range'
        ]
        
        # Remove any missing columns
        available_columns = [col for col in feature_columns if col in df.columns]
        features = df[available_columns].values
        
        # Scale features
        scaler = RobustScaler()
        features_scaled = scaler.fit_transform(features)
        
        # Create sequences
        X, y = [], []
for i in range(self.sequence_length, len(features_scaled)):
            X.append(features_scaled[i-self.sequence_length:i])
            
            # Multi-target: next price, volatility, trend
            next_close = df['Close'].iloc[i]
            current_close = df['Close'].iloc[i-1]
            price_change = (next_close - current_close) / current_close
            
            next_vol = df['volatility'].iloc[i] if not pd.isna(df['volatility'].iloc[i]) else 0
            trend = 1 if price_change > 0.001 else (-1 if price_change < -0.001 else 0)
            
            y.append([price_change, next_vol, trend])
        
        return np.array(X), np.array(y), scaler
    
    def create_ensemble_models(self, input_size: int) -> Dict:
        """Create ensemble of different model types"""
        
        models = {}
            'transformer': TransformerPredictor()
                input_size=input_size,
                d_model=128,
                nhead=8,
                num_layers=4,
                seq_len=self.sequence_length
            ).to(self.device),
            
            'lstm': AdvancedLSTM()
                input_size=input_size,
                hidden_size=256,
                num_layers=3
            ).to(self.device),
            
            'lstm_small': AdvancedLSTM()
                input_size=input_size,
                hidden_size=128,
                num_layers=2
            ).to(self.device)
        }
        
        return models
    
    def train_ensemble(self, symbol: str, epochs: int = 100):
        """Train ensemble of models for a symbol"""
        print(f"\n🎯 Training ensemble for {symbol}")
        
        # Fetch and prepare data
        df = self.fetch_enhanced_data(symbol)
        if df.empty:
            return False
        
        X, y, scaler = self.prepare_sequences(df)
        self.scalers[symbol] = scaler
        
        # Split data
        split_idx = int(len(X) * 0.8)
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Convert to tensors
        X_train = torch.FloatTensor(X_train).to(self.device)
        y_train = torch.FloatTensor(y_train).to(self.device)
        X_test = torch.FloatTensor(X_test).to(self.device)
        y_test = torch.FloatTensor(y_test).to(self.device)
        
        # Create ensemble models
        models = self.create_ensemble_models(X_train.shape[-1])
        self.models[symbol] = {}
        
        # Train each model in ensemble
        for model_name, model in models.items():
            print(f"  📚 Training {model_name}...")
            
            optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)
            scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=10)
            criterion = nn.MSELoss()
            
            best_loss = float('inf')
            patience = 15
            patience_counter = 0
            
            for epoch in range(epochs):
                model.train()
                optimizer.zero_grad()
                
                # Forward pass
                outputs = model(X_train)
                loss = criterion(outputs, y_train)
                
                # Backward pass
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                scheduler.step()
                
                # Validation
                if epoch % 10 == 0:
                    model.eval()
                    with torch.no_grad():
                        val_outputs = model(X_test)
                        val_loss = criterion(val_outputs, y_test).item()
                    
                    if val_loss < best_loss:
                        best_loss = val_loss
                        patience_counter = 0
                        # Save best model
                        self.models[symbol][model_name] = {}
                            'model': model.state_dict(),
                            'loss': val_loss
                        }
                    else:
                        patience_counter += 1
                    
                    if patience_counter >= patience:
                        print(f"    Early stopping at epoch {epoch}")
                        break
            
            print(f"    ✅ {model_name} trained - Best loss: {best_loss:.6f}")
        
        return True
    
    def predict_ensemble(self, symbol: str, lookback_days: int = 5) -> Dict:
        """Make ensemble predictions for a symbol"""
        if symbol not in self.models or symbol not in self.scalers:
            print(f"❌ No trained models for {symbol}")
            return {}
        
        # Fetch recent data
        df = self.fetch_enhanced_data(symbol, period="5d")
        if df.empty or len(df) < self.sequence_length:
            return {}
        
        # Prepare features
        feature_columns = []
            'Open', 'High', 'Low', 'Close', 'Volume',
            'returns', 'volatility', 'sma_5', 'sma_20', 'ema_12', 'ema_26',
            'macd', 'macd_signal', 'rsi', 'bb_width', 'bb_position',
            'volume_ratio', 'price_position_5', 'price_position_20',
            'momentum_5', 'momentum_10', 'price_range'
        ]
        
        available_columns = [col for col in feature_columns if col in df.columns]
        features = df[available_columns].values
        
        # Scale features
        features_scaled = self.scalers[symbol].transform(features)
        
        # Get last sequence
        last_sequence = features_scaled[-self.sequence_length:].reshape(1, self.sequence_length, -1)
        last_sequence = torch.FloatTensor(last_sequence).to(self.device)
        
        # Make predictions with ensemble
        predictions = {}
        ensemble_preds = []
        
        for model_name, model_data in self.models[symbol].items():
            # Recreate model
            input_size = last_sequence.shape[-1]
            if model_name == 'transformer':
                model = TransformerPredictor(input_size=input_size).to(self.device)
            else:
                hidden_size = 256 if 'small' not in model_name else 128
                num_layers = 3 if 'small' not in model_name else 2
                model = AdvancedLSTM(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers).to(self.device)
            
            model.load_state_dict(model_data['model'])
            model.eval()
            
            with torch.no_grad():
                pred = model(last_sequence).cpu().numpy()[0]
                predictions[model_name] = {}
                    'price_change': pred[0],
                    'volatility': pred[1],
                    'trend': pred[2],
                    'confidence': 1.0 / (1.0 + model_data['loss'])
                }
                ensemble_preds.append(pred)
        
        # Ensemble average weighted by confidence
        weights = [predictions[name]['confidence'] for name in predictions.keys()]
        weights = np.array(weights) / sum(weights)
        
        ensemble_pred = np.average(ensemble_preds, axis=0, weights=weights)
        
        # Current price for prediction
        current_price = df['Close'].iloc[-1]
        predicted_price = current_price * (1 + ensemble_pred[0])
        
        return {}
            'symbol': symbol,
            'current_price': current_price,
            'predicted_price': predicted_price,
            'price_change_pct': ensemble_pred[0] * 100,
            'predicted_volatility': ensemble_pred[1],
            'trend_signal': ensemble_pred[2],
            'confidence': np.mean(weights),
            'individual_predictions': predictions,
            'timestamp': datetime.now().isoformat()
        }
    
    def train_all_symbols(self, epochs: int = 100):
        """Train ensemble models for all symbols"""
        print(f"\n🚀 Training enhanced prediction models for {len(self.symbols)} symbols")
        
        for symbol in self.symbols:
            try:
                self.train_ensemble(symbol, epochs)
                time.sleep(1)  # Rate limiting
            except Exception as e:
                print(f"❌ Error training {symbol}: {e}")
    
    def predict_all_symbols(self) -> Dict:
        """Generate predictions for all symbols"""
        print(f"\n🔮 Generating ensemble predictions for all symbols")
        
        predictions = {}
        for symbol in self.symbols:
            try:
                pred = self.predict_ensemble(symbol)
                if pred:
                    predictions[symbol] = pred
                    print(f"  ✅ {symbol}: {pred['predicted_price']:.2f} ({pred['price_change_pct']:+.2f}%)")
            except Exception as e:
                print(f"  ❌ Error predicting {symbol}: {e}")
        
        return predictions
    
    def run_enhanced_prediction_system(self):
        """Run the complete enhanced prediction system"""
        print("🧠 Starting Enhanced Trading Prediction AI System")
        print("=" * 60)
        
        # Train models
        self.train_all_symbols(epochs=80)
        
        print("\n" + "=" * 60)
        print("🔮 ENHANCED PREDICTION RESULTS")
        print("=" * 60)
        
        # Generate predictions
        predictions = self.predict_all_symbols()
        
        # Summary
        if predictions:
            print(f"\n📊 PREDICTION SUMMARY")
            print("-" * 40)
            for symbol, pred in predictions.items():
                direction = "📈" if pred['price_change_pct'] > 0 else "📉"
                confidence = pred['confidence']
                print(f"{direction} {symbol}: ${pred['predicted_price']:.2f} ({pred['price_change_pct']:+.2f}%) - Confidence: {confidence:.3f}")
        
        return predictions

if __name__ == "__main__":
    # Initialize and run enhanced prediction system
    ai = EnhancedPredictionAI()
    predictions = ai.run_enhanced_prediction_system()