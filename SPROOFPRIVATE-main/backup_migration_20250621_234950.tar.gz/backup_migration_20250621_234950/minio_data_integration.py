#!/usr/bin/env python3
"""
MinIO Data Integration for Trading System
========================================
Intelligent data wrangling and integration with trading algorithms
"""

import os
import subprocess
import json
import zipfile
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging
from io import StringIO
import glob
from pathlib import Path
from dotenv import load_dotenv

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, validate_price



# Load environment variables
load_dotenv()

class MinIODataWrangler:
    """Intelligent data wrangling for MinIO historical market data"""
    
    def __init__(self):
        self.mc_path = "./mc"
        self.endpoint = os.getenv('MINIO_ENDPOINT')
        self.access_key = os.getenv('MINIO_ACCESS_KEY')
        self.secret_key = os.getenv('MINIO_SECRET_KEY')
        self.bucket = os.getenv('MINIO_BUCKET', 'stockdb')
        self.alias = "uschristmas"
        
        self.cache_dir = "./minio_cache"
        self.processed_dir = "./processed_data"
        
        # Create directories
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(self.processed_dir, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
    def configure_mc_client(self):
        """Configure MinIO client with credentials from .env"""
        cmd = f'{self.mc_path} alias set {self.alias} {self.endpoint} {self.access_key} "{self.secret_key}"'
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        if result.returncode == 0:
            self.logger.info("MinIO client configured successfully")
        else:
            self.logger.error(f"Failed to configure MinIO client: {result.stderr}")
            
    def list_available_data(self) -> Dict[str, List[str]]:
        """List all available data in MinIO"""
        available_data = {}
            'years': [],
            'categories': [],
            'samples': []
        }
        
        # List main bucket
        cmd = f"{self.mc_path} ls {self.alias}/{self.bucket}/"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        for line in result.stdout.splitlines():
            if ".zip" in line:
                year = line.split()[-1].replace(".zip", "")
                available_data['years'].append(year)
            elif line.endswith("/"):
                category = line.split()[-1].replace("/", "")
                available_data['categories'].append(category)
                
        return available_data
    
    def download_and_extract_year(self, year: int) -> str:
        """Download and extract year data intelligently"""
        zip_filename = f"{year}.zip"
        zip_path = os.path.join(self.cache_dir, zip_filename)
        extract_dir = os.path.join(self.cache_dir, str(year)
        
        # Check if already extracted
        if os.path.exists(extract_dir) and os.listdir(extract_dir):
            self.logger.info(f"Year {year} data already extracted")
            return extract_dir
            
        # Download if not cached
        if not os.path.exists(zip_path):
            self.logger.info(f"Downloading {year} data from MinIO...")
            cmd = f"{self.mc_path} cp {self.alias}/{self.bucket}/{zip_filename} {zip_path}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"Failed to download {year} data: {result.stderr}")
                
        # Extract data
        self.logger.info(f"Extracting {year} data...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
            
        self.logger.info(f"Successfully extracted {year} data to {extract_dir}")
        return extract_dir
    
    def identify_data_format(self, file_path: str) -> Dict[str, any]:
        """Intelligently identify the format of a data file"""
        file_info = {}
            'format': None,
            'delimiter': None,
            'has_header': True,
            'columns': [],
            'date_column': None,
            'price_columns': []
        }
        
        # Read first few lines
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [f.readline() for _ in range(10)]
            
        # Detect delimiter
        delimiters = [',', '\t', '|', ';']
        delimiter_counts = {}
        
        for delimiter in delimiters:
            counts = [line.count(delimiter) for line in lines if line]
            if counts and all(c == counts[0] for c in counts):
                delimiter_counts[delimiter] = counts[0]
                
        if delimiter_counts:
            file_info['delimiter'] = max(delimiter_counts, key=delimiter_counts.get)
            
        # Try to parse and identify columns
        try:
            if file_info['delimiter']:
                # Try with header
                df = pd.read_csv(StringIO(''.join(lines), delimiter=file_info['delimiter'], nrows=5)
                columns = df.columns.tolist()
                
                # Identify date columns
                date_patterns = ['date', 'time', 'datetime', 'timestamp']
                for col in columns:
                    if any(pattern in col.lower() for pattern in date_patterns):
                        file_info['date_column'] = col
                        break
                        
                # Identify price columns
                price_patterns = ['price', 'close', 'open', 'high', 'low', 'bid', 'ask']
                for col in columns:
                    if any(pattern in col.lower() for pattern in price_patterns):
                        file_info['price_columns'].append(col)
                        
                file_info['columns'] = columns
                file_info['format'] = 'csv'
                
        except Exception as e:
            self.logger.warning(f"Could not parse file {file_path}: {e}")
            
        return file_info
    
    def process_market_data_file(self, file_path: str) -> Optional[pd.DataFrame]:
        """Process a single market data file intelligently"""
        try:
            # Identify format
            file_info = self.identify_data_format(file_path)
            
            if not file_info['delimiter']:
                self.logger.warning(f"Could not determine format for {file_path}")
                return None
                
            # Read the file
            df = pd.read_csv(file_path, delimiter=file_info['delimiter'])
            
            # Standardize column names
            column_mapping = {}
                'Date': 'date',
                'Open': 'open',
                'High': 'high',
                'Low': 'low',
                'Close': 'close',
                'Volume': 'volume',
                'Adj Close': 'adj_close'
            }
            
            # Apply mapping for common variations
            for col in df.columns:
                for standard, variations in []
                    ('date', ['Date', 'DATE', 'date', 'DateTime', 'timestamp']),
                    ('open', ['Open', 'OPEN', 'open', 'opening_price']),
                    ('high', ['High', 'HIGH', 'high', 'high_price']),
                    ('low', ['Low', 'LOW', 'low', 'low_price']),
                    ('close', ['Close', 'CLOSE', 'close', 'closing_price']),
                    ('volume', ['Volume', 'VOLUME', 'volume', 'vol'])
                ]:
                    if col in variations:
                        df = df.rename(columns={col: standard})
                        break
                        
            # Parse dates
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date'], errors='coerce')
                df = df.dropna(subset=['date'])
                df = df.sort_values('date')
                
            # Add technical indicators
            if all(col in df.columns for col in ['close', 'high', 'low']):
                # Simple Moving Averages
                df['sma_20'] = df['close'].rolling(window=20).mean()
                df['sma_50'] = df['close'].rolling(window=50).mean()
                
                # RSI
                delta = df['close'].diff()
                gain = (delta.where(delta > 0, 0).rolling(window=14).mean())
                loss = (-delta.where(delta < 0, 0).rolling(window=14).mean())
                rs = gain / loss
                df['rsi'] = 100 - (100 / (1 + rs)
                
                # Volatility
                df['volatility'] = df['close'].pct_change().rolling(window=20).std() * np.sqrt(252)
                
            return df
            
        except Exception as e:
            self.logger.error(f"Error processing {file_path}: {e}")
            return None
    
    def process_year_data(self, year: int) -> Dict[str, pd.DataFrame]:
        """Process all data for a specific year"""
        self.logger.info(f"Processing data for year {year}")
        
        # Download and extract
        data_dir = self.download_and_extract_year(year)
        
        # Find all data files
        processed_data = {}
        
        # Common patterns for stock data files
        patterns = ['*.csv', '*.txt', '*.dat']
        
        for pattern in patterns:
            files = glob.glob(os.path.join(data_dir, '**', pattern), recursive=True)
            
            for file_path in files:
                # Extract symbol from filename
                filename = os.path.basename(file_path)
                symbol = filename.split('.')[0].upper()
                
                # Skip if already processed
                if symbol in processed_data:
                    continue
                    
                # Process the file
                df = self.process_market_data_file(file_path)
                
                if df is not None and len(df) > 0:
                    processed_data[symbol] = df
                    self.logger.info(f"Processed {symbol}: {len(df)} rows")
                    
        self.logger.info(f"Processed {len(processed_data)} symbols for year {year}")
        return processed_data
    
    def create_training_dataset(self, years: List[int], symbols: Optional[List[str]] = None) -> pd.DataFrame:
        """Create a comprehensive training dataset for ML models"""
        all_data = []
        
        for year in years:
            self.logger.info(f"Loading data for {year}")
            year_data = self.process_year_data(year)
            
            for symbol, df in year_data.items():
                if symbols and symbol not in symbols:
                    continue
                    
                if 'date' in df.columns:
                    df['symbol'] = symbol
                    df['year'] = year
                    all_data.append(df)
                    
        if all_data:
            # Combine all data
            combined_df = pd.concat(all_data, ignore_index=True)
            
            # Sort by date
            combined_df = combined_df.sort_values(['date', 'symbol'])
            
            # Add additional features
            combined_df['returns'] = combined_df.groupby('symbol')['close'].pct_change()
            combined_df['log_returns'] = np.log(combined_df['close'] / combined_df.groupby('symbol')['close'].shift(1)
            
            # Save processed data
            output_path = os.path.join(self.processed_dir, f"training_data_{min(years)}_{max(years)}.parquet")
            combined_df.to_parquet(output_path)
            self.logger.info(f"Saved training dataset to {output_path}")
            
            return combined_df
        else:
            self.logger.warning("No data found to create training dataset")
            return pd.DataFrame()
    
    def get_backtest_data(self, symbol: str, start_year: int, end_year: int) -> pd.DataFrame:
        """Get cleaned data for backtesting a specific symbol"""
        all_data = []
        
        for year in range(start_year, end_year + 1):
            year_data = self.process_year_data(year)
            
            if symbol in year_data:
                all_data.append(year_data[symbol])
                
        if all_data:
            combined_df = pd.concat(all_data, ignore_index=True)
            combined_df = combined_df.sort_values('date')
            combined_df = combined_df.drop_duplicates(subset=['date'])
            return combined_df
        else:
            return pd.DataFrame()


class TradingAlgorithmEnhancer:
    """Enhance trading algorithms with MinIO historical data"""
    
    def __init__(self):
        self.data_wrangler = MinIODataWrangler()
        self.logger = logging.getLogger(__name__)
        
    def enhance_portfolio_optimization(self, symbols: List[str], lookback_years: int = 5):
        """Enhance portfolio optimization with historical data"""
        self.logger.info("Enhancing portfolio optimization with historical data")
        
        # Get current year
        current_year = datetime.now().year
        start_year = max(2002, current_year - lookback_years)  # MinIO data starts from 2002
        
        # Create training dataset
        training_data = self.data_wrangler.create_training_dataset()
            years=list(range(start_year, min(2010, current_year)),  # MinIO data up to 2009)
            symbols=symbols
        )
        
        if training_data.empty:
            self.logger.warning("No historical data available for enhancement")
            return None
            
        # Calculate historical metrics for each symbol
        metrics = {}
        
        for symbol in symbols:
            symbol_data = training_data[training_data['symbol'] == symbol]
            
            if len(symbol_data) > 252:  # At least 1 year of data
                metrics[symbol] = {}
                    'historical_return': symbol_data['returns'].mean() * 252,
                    'historical_volatility': symbol_data['returns'].std() * np.sqrt(252),
                    'historical_sharpe': (symbol_data['returns'].mean() * 252) / (symbol_data['returns'].std() * np.sqrt(252),)
                    'max_drawdown': self._calculate_max_drawdown(symbol_data['close']),
                    'skewness': symbol_data['returns'].skew(),
                    'kurtosis': symbol_data['returns'].kurtosis()
}
                
        return metrics
    
    def _calculate_max_drawdown(self, prices: pd.Series) -> float:
        """Calculate maximum drawdown"""
        cumulative = (1 + prices.pct_change().cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        return drawdown.min()
    
    def enhance_risk_management(self, portfolio: Dict[str, float]):
        """Enhance risk management with crisis period analysis"""
        self.logger.info("Analyzing crisis periods for enhanced risk management")
        
        # Focus on 2008 financial crisis
        crisis_data = self.data_wrangler.process_year_data(2008)
        
        crisis_metrics = {}
        
        for symbol, weight in portfolio.items():
            if symbol in crisis_data:
                df = crisis_data[symbol]
                
                # Find worst period
                df['cumulative_return'] = (1 + df['returns']).cumprod()
                worst_drawdown = self._calculate_max_drawdown(df['close'])
                
                # Calculate stress metrics
                crisis_metrics[symbol] = {}
                    'crisis_max_drawdown': worst_drawdown,
                    'crisis_volatility': df['returns'].std() * np.sqrt(252),
                    'crisis_var_95': df['returns'].quantile(0.05) * np.sqrt(252),
                    'recovery_time': self._calculate_recovery_time(df)
                }
                
        return crisis_metrics
    
    def _calculate_recovery_time(self, df: pd.DataFrame) -> int:
        """Calculate recovery time from drawdown"""
        if 'close' not in df.columns:
            return 0
            
        prices = df['close'].values
        peak_idx = np.argmax(prices)
        
        if peak_idx < len(prices) - 1:
            # Find recovery
            peak_price = prices[peak_idx]
            for i in range(peak_idx + 1, len(prices):
                if prices[i] >= peak_price:
                    return i - peak_idx
                    
        return len(prices) - peak_idx
    
    def create_ml_features(self, symbol: str, years: List[int]) -> pd.DataFrame:
        """Create ML features from historical data"""
        self.logger.info(f"Creating ML features for {symbol}")
        
        all_features = []
        
        for year in years:
            year_data = self.data_wrangler.process_year_data(year)
            
            if symbol in year_data:
                df = year_data[symbol].copy()
                
                # Price-based features
                df['returns'] = df['close'].pct_change()
                df['log_returns'] = np.log(df['close'] / df['close'].shift(1)
                df['high_low_spread'] = (df['high'] - df['low']) / df['close']
                df['close_open_spread'] = (df['close'] - df['open']) / df['open']
                
                # Volume features
                df['volume_sma'] = df['volume'].rolling(20).mean()
                df['volume_ratio'] = df['volume'] / df['volume_sma']
                
                # Volatility features
                df['volatility_20'] = df['returns'].rolling(20).std()
                df['volatility_60'] = df['returns'].rolling(60).std()
                
                # Momentum features
                df['momentum_5'] = df['close'] / df['close'].shift(5) - 1
                df['momentum_20'] = df['close'] / df['close'].shift(20) - 1
                
                # Market microstructure
                df['bid_ask_spread'] = df['high_low_spread'].rolling(5).mean()
                
                all_features.append(df)
                
        if all_features:
            return pd.concat(all_features, ignore_index=True)
        else:
            return pd.DataFrame()


def demo_intelligent_integration():
    """Demonstrate intelligent MinIO data integration"""
    print("🧠 Intelligent MinIO Data Integration Demo")
    print("=" * 60)
    
    # Initialize components
    wrangler = MinIODataWrangler()
    enhancer = TradingAlgorithmEnhancer()
    
    # Configure MinIO client
    wrangler.configure_mc_client()
    
    # List available data
    print("\n📊 Available Data in MinIO:")
    available = wrangler.list_available_data()
    print(f"Years: {', '.join(available['years'])}")
    print(f"Categories: {', '.join(available['categories'])}")
    
    # Example 1: Enhance portfolio optimization
    print("\n1️⃣ Enhancing Portfolio Optimization")
    print("-" * 40)
    
    symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN']
    historical_metrics = enhancer.enhance_portfolio_optimization(symbols, lookback_years=5)
    
    if historical_metrics:
        for symbol, metrics in historical_metrics.items():
            print(f"\n{symbol}:")
            print(f"  Historical Return: {metrics['historical_return']:.2%}")
            print(f"  Historical Volatility: {metrics['historical_volatility']:.2%}")
            print(f"  Historical Sharpe: {metrics['historical_sharpe']:.2f}")
            
    # Example 2: Crisis analysis
    print("\n2️⃣ Crisis Period Risk Analysis")
    print("-" * 40)
    
    portfolio = {'SPY': 0.4, 'QQQ': 0.3, 'IWM': 0.3}
    crisis_metrics = enhancer.enhance_risk_management(portfolio)
    
    if crisis_metrics:
        for symbol, metrics in crisis_metrics.items():
            print(f"\n{symbol} (2008 Crisis):")
            print(f"  Max Drawdown: {metrics['crisis_max_drawdown']:.2%}")
            print(f"  Crisis VaR 95%: {metrics['crisis_var_95']:.2%}")
            
    # Example 3: ML feature creation
    print("\n3️⃣ Creating ML Training Features")
    print("-" * 40)
    
    # This would create features for a specific symbol
    print("Feature engineering process configured for:")
    print("  • Price-based features")
    print("  • Volume features")
    print("  • Technical indicators")
    print("  • Market microstructure")
    print("  • Volatility measures")
    
    print("\n✅ MinIO integration ready for algorithm enhancement!")
    
    return wrangler, enhancer


if __name__ == "__main__":
    # Run demonstration
    wrangler, enhancer = demo_intelligent_integration()
    
    # Save configuration
    config = {}
        "minio_integration": {}
            "status": "configured",
            "data_years": [2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009],
            "features": {}
                "portfolio_optimization": "historical metrics integration",
                "risk_management": "crisis period analysis",
                "ml_training": "comprehensive feature engineering",
                "backtesting": "multi-year data support"
            }
        }
    }
    
    with open("minio_integration_config.json", "w") as f:
        json.dump(config, f, indent=2)
        
    print("\n💾 Configuration saved successfully!")