#!/usr/bin/env python3
"""
V18 COMPREHENSIVE BACKTESTING SYSTEM
====================================
Tests all 76+ optimized algorithms with:
- Real market data simulation
- Performance comparison
- Optimization recommendations
- Portfolio allocation suggestions
"""

import sys
import os
import asyncio
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import logging
from datetime import datetime, timedelta
import json
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

# Import our optimized algorithms
from v18_optimized_algorithms import EnhancedTradingAlgorithms, MarketRegime

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class ComprehensiveBacktestSystem:
    """Comprehensive backtesting for all optimized algorithms"""
    
    def __init__(self):
        self.algo_system = EnhancedTradingAlgorithms(use_gpu=True)
        self.results = {}
        self.market_data = {}
        
    def generate_realistic_market_data(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Generate realistic market data with various market conditions"""
        
        dates = pd.date_range(start=start_date, end=end_date, freq='1H')
        n_periods = len(dates)
        
        # Create different market regimes
        regime_changes = np.random.choice(range(100, n_periods-100), size=5, replace=False)
        regime_changes = sorted(regime_changes)
        regime_changes = [0] + list(regime_changes) + [n_periods]
        
        # Initialize price series
        prices = np.zeros(n_periods)
        volumes = np.zeros(n_periods)
        
        # Starting price
        current_price = 100
        
        # Generate data for each regime
        for i in range(len(regime_changes) - 1):
            start_idx = regime_changes[i]
            end_idx = regime_changes[i + 1]
            regime_length = end_idx - start_idx
            
            # Choose regime type
            regime_type = np.self.select_symbol(['trending_up', 'trending_down', 'volatile', 'calm', 'ranging'])
            
            if regime_type == 'trending_up':
                # Uptrend with momentum
                trend = np.linspace(0, 0.2, regime_length)
                noise = self.get_price_distribution(0, 0.005, regime_length)
                returns = trend / regime_length + noise
                
            elif regime_type == 'trending_down':
                # Downtrend
                trend = np.linspace(0, -0.15, regime_length)
                noise = self.get_price_distribution(0, 0.005, regime_length)
                returns = trend / regime_length + noise
                
            elif regime_type == 'volatile':
                # High volatility
                returns = self.get_price_distribution(0, 0.02, regime_length)
                
            elif regime_type == 'calm':
                # Low volatility
                returns = self.get_price_distribution(0.0001, 0.003, regime_length)
                
            else:  # ranging
                # Mean reverting
                returns = self.get_price_distribution(0, 0.008, regime_length)
                # Add mean reversion
                for j in range(1, len(returns):
                    if abs(np.sum(returns[:j]) > 0.05:
                        returns[j] -= np.sum(returns[:j]) * 0.1
            
            # Calculate prices
            for j in range(regime_length):
                prices[start_idx + j] = current_price * (1 + returns[j])
                current_price = prices[start_idx + j]
            
            # Generate volume based on volatility
            base_volume = 5000000
            volatility_mult = 1 + abs(returns).mean() * 50
            volumes[start_idx:end_idx] = np.random.lognormal()
                np.log(base_volume * volatility_mult), 0.5, regime_length
            )
        
        # Create OHLC data
        data = pd.DataFrame(index=dates)
        data['close'] = prices
        
        # Generate OHLC from close
        data['open'] = data['close'].shift(1).fillna(data['close'].iloc[0])
        data['high'] = data[['open', 'close']].max(axis=1) * (1 + self.get_uniform_prices(0, 0.005, n_periods)
        data['low'] = data[['open', 'close']].min(axis=1) * (1 - self.get_uniform_prices(0, 0.005, n_periods)
        data['volume'] = volumes.astype(int)
        
        # Add some market events (gaps, spikes)
        n_events = np.self.get_volume_data(5, 15)
        event_indices = np.random.choice(range(100, n_periods-100), size=n_events, replace=False)
        
        for idx in event_indices:
            event_type = np.self.select_symbol(['gap_up', 'gap_down', 'spike_volume'])
            
            if event_type == 'gap_up':
                data.loc[data.index[idx:idx+5], 'close'] *= 1.03
                data.loc[data.index[idx:idx+5], 'high'] *= 1.035
                
            elif event_type == 'gap_down':
                data.loc[data.index[idx:idx+5], 'close'] *= 0.97
                data.loc[data.index[idx:idx+5], 'low'] *= 0.965
                
            else:  # spike_volume
                data.loc[data.index[idx:idx+3], 'volume'] *= 5
        
        return data
    
    async def backtest_all_algorithms(self, symbols: list, start_date: str, end_date: str):
        """Backtest all algorithms on multiple symbols"""
        
        logger.info("\n" + "="*80)
        logger.info("🚀 V18 COMPREHENSIVE ALGORITHM BACKTESTING")
        logger.info("="*80)
        logger.info(f"📅 Period: {start_date} to {end_date}")
        logger.info(f"📊 Symbols: {', '.join(symbols)}")
        logger.info(f"🤖 Algorithms: {len(self.algo_system.algorithm_configs)}")
        logger.info(f"🖥️  GPU: {'Enabled' if self.algo_system.use_gpu else 'Disabled'}")
        logger.info("="*80 + "\n")
        
        all_results = {}
        
        # Test each symbol
        for symbol in symbols:
            logger.info(f"\n📈 Testing {symbol}...")
            
            # Generate market data
            data = self.generate_realistic_market_data(symbol, start_date, end_date)
            self.market_data[symbol] = data
            
            symbol_results = {}
            
            # Test each algorithm
            for i, (algo_name, config) in enumerate(self.algo_system.algorithm_configs.items():
                if (i + 1) % 10 == 0:
                    logger.info(f"   Progress: {i + 1}/{len(self.algo_system.algorithm_configs)} algorithms tested")
                
                try:
                    # Run backtest
                    result = await self.algo_system.backtest_algorithm(algo_name, data)
                    
                    # Store results
                    symbol_results[algo_name] = {}
                        'total_return': result.get('total_return', 0),
                        'sharpe_ratio': result.get('sharpe_ratio', 0),
                        'max_drawdown': result.get('max_drawdown', 0),
                        'win_rate': result.get('win_rate', 0),
                        'total_trades': result.get('total_trades', 0),
                        'category': config.category,
                        'risk_multiplier': config.risk_multiplier,
                        'ml_enhanced': config.use_ml,
                        'gpu_accelerated': config.gpu_accelerated
                    }
                    
                except Exception as e:
                    logger.error("   ⚠️  Error testing {algo_name}: {str(e)}")
                    symbol_results[algo_name] = {}
                        'total_return': 0,
                        'sharpe_ratio': 0,
                        'max_drawdown': -1,
                        'win_rate': 0,
                        'total_trades': 0,
                        'category': config.category,
                        'error': str(e)
                    }
            
            all_results[symbol] = symbol_results
        
        self.results = all_results
        return all_results
    
    def analyze_results(self):
        """Comprehensive analysis of backtest results"""
        
        logger.info("\n" + "="*80)
        logger.info("📊 BACKTEST ANALYSIS")
        logger.info("="*80)
        
        # Aggregate results across all symbols
        algorithm_performance = {}
        
        for symbol, symbol_results in self.results.items():
            for algo, metrics in symbol_results.items():
                if algo not in algorithm_performance:
                    algorithm_performance[algo] = {}
                        'returns': [],
                        'sharpes': [],
                        'drawdowns': [],
                        'win_rates': [],
                        'trades': [],
                        'category': metrics.get('category', 'Unknown')
                    }
                
                algorithm_performance[algo]['returns'].append(metrics['total_return'])
                algorithm_performance[algo]['sharpes'].append(metrics['sharpe_ratio'])
                algorithm_performance[algo]['drawdowns'].append(metrics['max_drawdown'])
                algorithm_performance[algo]['win_rates'].append(metrics['win_rate'])
                algorithm_performance[algo]['trades'].append(metrics['total_trades'])
        
        # Calculate average metrics
        for algo, perf in algorithm_performance.items():
            perf['avg_return'] = np.mean(perf['returns'])
            perf['avg_sharpe'] = np.mean(perf['sharpes'])
            perf['avg_drawdown'] = np.mean(perf['drawdowns'])
            perf['avg_win_rate'] = np.mean(perf['win_rates'])
            perf['total_trades'] = sum(perf['trades'])
            perf['consistency'] = 1 / (1 + np.std(perf['returns'])
        
        # Sort by performance
        sorted_algos = sorted(algorithm_performance.items(), 
                            key=lambda x: x[1]['avg_return'], 
                            reverse=True)
        
        # Print top performers
        logger.info("\n🏆 TOP 20 ALGORITHMS BY RETURN:")
        logger.info(f"{'Rank':<5} {'Algorithm':<30} {'Avg Return':<12} {'Sharpe':<8} {'Win Rate':<10} {'Consistency':<12}")
        logger.info("-" * 85)
        
        for i, (algo, perf) in enumerate(sorted_algos[:20], 1):
            print(f"{i:<5} {algo:<30} {perf['avg_return']:>10.2%} {perf['avg_sharpe']:>8.2f} ")
                  f"{perf['avg_win_rate']:>8.1%} {perf['consistency']:>10.3f}")
        
        # Category analysis
        category_performance = {}
        for algo, perf in algorithm_performance.items():
            category = perf['category']
            if category not in category_performance:
                category_performance[category] = []
            category_performance[category].append(perf['avg_return'])
        
        logger.info("\n📈 PERFORMANCE BY CATEGORY:")
        logger.info(f"{'Category':<20} {'Avg Return':<12} {'Best':<12} {'Worst':<12} {'Count':<8}")
        logger.info("-" * 60)
        
        for category, returns in sorted(category_performance.items(), 
                                      key=lambda x: np.mean(x[1]), 
                                      reverse=True):
            logger.info(f"{category:<20} {np.mean(returns):>10.2%} {max(returns):>10.2%} ")
                  f"{min(returns):>10.2%} {len(returns):>6}")
        
        # Risk-adjusted performance
        logger.info("\n⚖️  TOP 10 RISK-ADJUSTED PERFORMERS (Sharpe Ratio):")
        sorted_by_sharpe = sorted(algorithm_performance.items(), 
                                key=lambda x: x[1]['avg_sharpe'], 
                                reverse=True)
        
        for i, (algo, perf) in enumerate(sorted_by_sharpe[:10], 1):
            print(f"{i:2d}. {algo:<30} Sharpe: {perf['avg_sharpe']:>6.2f} ")
                  f"Return: {perf['avg_return']:>8.2%} DD: {perf['avg_drawdown']:>7.2%}")
        
        # ML vs Non-ML comparison
        ml_algos = []
        non_ml_algos = []
        
        for algo, config in self.algo_system.algorithm_configs.items():
            if algo in algorithm_performance:
                if config.use_ml:
                    ml_algos.append(algorithm_performance[algo]['avg_return'])
                else:
                    non_ml_algos.append(algorithm_performance[algo]['avg_return'])
        
        logger.info(f"\n🤖 ML-ENHANCED VS TRADITIONAL:")
        logger.info(f"ML Algorithms: Avg Return = {np.mean(ml_algos):.2%}, Count = {len(ml_algos)}")
        logger.info(f"Traditional: Avg Return = {np.mean(non_ml_algos):.2%}, Count = {len(non_ml_algos)}")
        
        return algorithm_performance
    
    def generate_visualizations(self):
        """Generate comprehensive visualization of results"""
        
        logger.info("\n📈 Generating visualizations...")
        
        # Prepare data
        algorithm_performance = self.analyze_results()
        
        # Create figure with subplots
        fig = plt.figure(figsize=(20, 16)
        gs = fig.add_gridspec(4, 3, hspace=0.3, wspace=0.3)
        
        # 1. Top algorithms bar chart
        ax1 = fig.add_subplot(gs[0, :2])
        top_20 = sorted(algorithm_performance.items(), 
                       key=lambda x: x[1]['avg_return'], 
                       reverse=True)[:20]
        
        names = [item[0][:20] for item in top_20]
        returns = [item[1]['avg_return'] * 100 for item in top_20]
        colors = ['green' if r > 0 else 'red' for r in returns]
        
        bars = ax1.bar(range(len(names), returns, color=colors, alpha=0.7)
        ax1.set_xticks(range(len(names))
        ax1.set_xticklabels(names, rotation=45, ha='right')
        ax1.set_ylabel('Average Return (%)')
        ax1.set_title('Top 20 Algorithms by Return', fontsize=14, fontweight='bold')
        ax1.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        ax1.grid(True, alpha=0.3)
        
        # Add value labels
        for bar, ret in zip(bars, returns):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + (0.5 if height > 0 else -1),
                    f'{ret:.1f}%', ha='center', va='bottom' if height > 0 else 'top', fontsize=8)
        
        # 2. Category performance boxplot
        ax2 = fig.add_subplot(gs[0, 2])
        category_data = []
        category_labels = []
        
        for category in ['Technical', 'Statistical', 'ML', 'Options', 'HFT', 'Advanced']:
            cat_returns = [perf['avg_return'] * 100 for algo, perf in algorithm_performance.items()]
                          if perf['category'] == category]
            if cat_returns:
                category_data.append(cat_returns)
                category_labels.append(category)
        
        box_plot = ax2.boxplot(category_data, labels=category_labels, patch_artist=True)
        for patch in box_plot['boxes']:
            patch.set_facecolor('skyblue')
        ax2.set_ylabel('Return (%)')
        ax2.set_title('Performance by Category', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        ax2.axhline(y=0, color='red', linestyle='--', alpha=0.5)
        
        # 3. Risk-Return scatter
        ax3 = fig.add_subplot(gs[1, :])
        
        returns = []
        risks = []
        names = []
        categories = []
        
        for algo, perf in algorithm_performance.items():
            if perf['avg_return'] != 0 and perf['avg_drawdown'] != -1:
                returns.append(perf['avg_return'] * 100)
                risks.append(abs(perf['avg_drawdown']) * 100)
                names.append(algo)
                categories.append(perf['category'])
        
        # Color by category
        category_colors = {}
            'Technical': 'blue',
            'Statistical': 'green',
            'ML': 'red',
            'Options': 'orange',
            'HFT': 'purple',
            'Advanced': 'brown'
        }
        
        colors = [category_colors.get(cat, 'gray') for cat in categories]
        
        scatter = ax3.scatter(risks, returns, c=colors, alpha=0.6, s=50)
        
        # Add labels for top performers
        top_indices = np.argsort(returns)[-10:]
        for idx in top_indices:
            ax3.annotate(names[idx][:15], (risks[idx], returns[idx]), 
                        xytext=(5, 5), textcoords='offset points', fontsize=8)
        
        ax3.set_xlabel('Max Drawdown (%)')
        ax3.set_ylabel('Average Return (%)')
        ax3.set_title('Risk-Return Profile of All Algorithms', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        ax3.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        
        # Add legend
        legend_elements = [plt.Line2D([0], [0], marker='o', color='w', 
                                    markerfacecolor=color, markersize=8, label=cat)
                         for cat, color in category_colors.items()]
        ax3.legend(handles=legend_elements, loc='upper right')
        
        # 4. Sharpe ratio distribution
        ax4 = fig.add_subplot(gs[2, 0])
        sharpes = [perf['avg_sharpe'] for perf in algorithm_performance.values()]
                  if perf['avg_sharpe'] != 0]
        
        ax4.hist(sharpes, bins=30, color='green', alpha=0.7, edgecolor='black')
        ax4.axvline(x=np.mean(sharpes), color='red', linestyle='--', 
                   label=f'Mean: {np.mean(sharpes):.2f}')
        ax4.set_xlabel('Sharpe Ratio')
        ax4.set_ylabel('Frequency')
        ax4.set_title('Sharpe Ratio Distribution', fontsize=14, fontweight='bold')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        # 5. Win rate distribution
        ax5 = fig.add_subplot(gs[2, 1])
        win_rates = [perf['avg_win_rate'] * 100 for perf in algorithm_performance.values()]
        
        ax5.hist(win_rates, bins=30, color='orange', alpha=0.7, edgecolor='black')
        ax5.axvline(x=50, color='red', linestyle='--', label='50% (Breakeven)')
        ax5.axvline(x=np.mean(win_rates), color='blue', linestyle='--', 
                   label=f'Mean: {np.mean(win_rates):.1f}%')
        ax5.set_xlabel('Win Rate (%)')
        ax5.set_ylabel('Frequency')
        ax5.set_title('Win Rate Distribution', fontsize=14, fontweight='bold')
        ax5.legend()
        ax5.grid(True, alpha=0.3)
        
        # 6. ML vs Non-ML performance
        ax6 = fig.add_subplot(gs[2, 2])
        
        ml_returns = []
        non_ml_returns = []
        
        for algo, config in self.algo_system.algorithm_configs.items():
            if algo in algorithm_performance:
                if config.use_ml:
                    ml_returns.append(algorithm_performance[algo]['avg_return'] * 100)
                else:
                    non_ml_returns.append(algorithm_performance[algo]['avg_return'] * 100)
        
        data_to_plot = [ml_returns, non_ml_returns]
        labels = ['ML-Enhanced', 'Traditional']
        
        violin_plot = ax6.violinplot(data_to_plot, positions=[1, 2], showmeans=True)
        ax6.set_xticks([1, 2])
        ax6.set_xticklabels(labels)
        ax6.set_ylabel('Return (%)')
        ax6.set_title('ML vs Traditional Algorithms', fontsize=14, fontweight='bold')
        ax6.grid(True, alpha=0.3)
        ax6.axhline(y=0, color='red', linestyle='--', alpha=0.5)
        
        # 7. Consistency heatmap
        ax7 = fig.add_subplot(gs[3, :])
        
        # Create consistency matrix
        top_30 = sorted(algorithm_performance.items(), 
                       key=lambda x: x[1]['avg_return'], 
                       reverse=True)[:30]
        
        consistency_matrix = []
        algo_names = []
        
        for algo, perf in top_30:
            row = []
            for symbol in self.results.keys():
                if algo in self.results[symbol]:
                    row.append(self.results[symbol][algo]['total_return'] * 100)
                else:
                    row.append(0)
            consistency_matrix.append(row)
            algo_names.append(algo[:20])
        
        # Create heatmap
        im = ax7.imshow(consistency_matrix, aspect='auto', cmap='RdYlGn')
        ax7.set_yticks(range(len(algo_names))
        ax7.set_yticklabels(algo_names)
        ax7.set_xticks(range(len(self.results))
        ax7.set_xticklabels(list(self.results.keys())
        ax7.set_xlabel('Symbol')
        ax7.set_ylabel('Algorithm')
        ax7.set_title('Algorithm Performance Consistency Across Symbols', fontsize=14, fontweight='bold')
        
        # Add colorbar
        cbar = plt.colorbar(im, ax=ax7)
        cbar.set_label('Return (%)', rotation=270, labelpad=20)
        
        plt.suptitle('V18 Comprehensive Algorithm Backtest Results', fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.savefig('v18_backtest_results.png', dpi=300, bbox_inches='tight')
        logger.info("✅ Saved: v18_backtest_results.png")
        
        return algorithm_performance
    
    def generate_recommendations(self, algorithm_performance):
        """Generate portfolio allocation recommendations"""
        
        logger.info("\n" + "="*80)
        logger.info("💡 PORTFOLIO ALLOCATION RECOMMENDATIONS")
        logger.info("="*80)
        
        # Filter algorithms by performance criteria
        qualified_algos = {}
        
        for algo, perf in algorithm_performance.items():
            if (perf['avg_return'] > 0.1 and  # At least 10% return)
                perf['avg_sharpe'] > 1.0 and   # Sharpe > 1
                perf['avg_drawdown'] > -0.3 and  # Max DD < 30%
                perf['avg_win_rate'] > 0.45):    # Win rate > 45%
                
                qualified_algos[algo] = perf
        
        logger.info(f"\n✅ {len(qualified_algos)} algorithms meet quality criteria")
        
        # Create diversified portfolio
        portfolio = {}
        
        # Group by category
        by_category = {}
        for algo, perf in qualified_algos.items():
            cat = perf['category']
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append((algo, perf)
        
        # Allocate by category (max 2 per category)
        total_allocation = 0
        max_per_category = 2
        
        for category, algos in by_category.items():
            # Sort by Sharpe ratio
            sorted_algos = sorted(algos, key=lambda x: x[1]['avg_sharpe'], reverse=True)
            
            for i, (algo, perf) in enumerate(sorted_algos[:max_per_category]):
                # Calculate allocation based on Sharpe ratio
                base_allocation = perf['avg_sharpe'] / 20  # 5% per 1.0 Sharpe
                
                # Adjust for consistency
                allocation = base_allocation * perf['consistency']
                
                # Cap at 15% per algorithm
                allocation = min(allocation, 0.15)
                
                portfolio[algo] = {}
                    'allocation': allocation,
                    'category': category,
                    'expected_return': perf['avg_return'],
                    'sharpe': perf['avg_sharpe'],
                    'max_drawdown': perf['avg_drawdown']
                }
                
                total_allocation += allocation
        
        # Normalize to 100%
        if total_allocation > 0:
            for algo in portfolio:
                portfolio[algo]['allocation'] /= total_allocation
        
        # Print recommendations
        logger.info("\n📊 RECOMMENDED PORTFOLIO ALLOCATION:")
        logger.info(f"{'Algorithm':<30} {'Allocation':<12} {'Category':<15} {'Exp. Return':<12} {'Sharpe':<8}")
        logger.info("-" * 85)
        
        sorted_portfolio = sorted(portfolio.items(), 
                                key=lambda x: x[1]['allocation'], 
                                reverse=True)
        
        portfolio_return = 0
        
        for algo, details in sorted_portfolio:
            print(f"{algo:<30} {details['allocation']:>10.1%} {details['category']:<15} ")
                  f"{details['expected_return']:>10.2%} {details['sharpe']:>6.2f}")
            portfolio_return += details['allocation'] * details['expected_return']
        
        logger.info("-" * 85)
        logger.info(f"{'TOTAL':<30} {'100.0%':>10} {'':15} {portfolio_return:>10.2%}")
        
        # Risk analysis
        logger.info("\n⚠️  PORTFOLIO RISK ANALYSIS:")
        
        # Category concentration
        category_allocation = {}
        for algo, details in portfolio.items():
            cat = details['category']
            if cat not in category_allocation:
                category_allocation[cat] = 0
            category_allocation[cat] += details['allocation']
        
        logger.info("\nCategory Diversification:")
        for cat, alloc in sorted(category_allocation.items(), 
                                key=lambda x: x[1], 
                                reverse=True):
            logger.info(f"  {cat}: {alloc:.1%}")
        
        # Calculate portfolio metrics
        weighted_sharpe = sum(d['allocation'] * d['sharpe'] for d in portfolio.values()
        max_drawdown = max(d['max_drawdown'] for d in portfolio.values()
        
        logger.info(f"\nPortfolio Metrics:")
        logger.info(f"  Expected Annual Return: {portfolio_return:.2%}")
        logger.info(f"  Weighted Sharpe Ratio: {weighted_sharpe:.2f}")
        logger.info(f"  Worst-Case Drawdown: {max_drawdown:.2%}")
        
        # Save recommendations
        recommendations = {}
            'timestamp': datetime.now().isoformat(),
            'portfolio': {algo: {k: float(v) if isinstance(v, (int, float, np.float64) else v)
                               for k, v in details.items()} 
                        for algo, details in portfolio.items()},
            'metrics': {}
                'expected_return': float(portfolio_return),
                'weighted_sharpe': float(weighted_sharpe),
                'max_drawdown': float(max_drawdown),
                'n_algorithms': len(portfolio)
            },
            'category_allocation': {cat: float(alloc) for cat, alloc in category_allocation.items()}
        }
        
        with open('v18_portfolio_recommendations.json', 'w') as f:
            json.dump(recommendations, f, indent=2)
        
        logger.info("\n✅ Recommendations saved to: v18_portfolio_recommendations.json")
        
        return portfolio

async def run_comprehensive_backtest():
    """Run comprehensive backtest of all optimized algorithms"""
    
    # Initialize backtest system
    backtest_system = ComprehensiveBacktestSystem()
    
    # Test on multiple symbols representing different market types
    symbols = []
        'AAPL',   # Large cap tech
        'SPY',    # Market index
        'GLD',    # Commodity
        'IWM',    # Small cap
        'TLT',    # Bonds
        'VIX',    # Volatility
        'ARKK',   # Growth/Innovation
        'XLE'     # Energy sector
    ]
    
    # Run backtest
    results = await backtest_system.backtest_all_algorithms()
        symbols=symbols,
        start_date='2024-01-01',
        end_date='2024-12-31'
    )
    
    # Generate visualizations
    algorithm_performance = backtest_system.generate_visualizations()
    
    # Generate recommendations
    portfolio = backtest_system.generate_recommendations(algorithm_performance)
    
    logger.info("\n" + "="*80)
    logger.info("✅ V18 COMPREHENSIVE BACKTESTING COMPLETE!")
    logger.info("="*80)

if __name__ == "__main__":
    asyncio.run(run_comprehensive_backtest()