
#!/usr/bin/env python3
"""
Syntax test for enhanced options bot
Tests basic functionality without external dependencies
"""

# Alpaca imports

import os
import logging
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import sys
import ast

def test_syntax():
    """Test if the enhanced options bot has valid Python syntax"""
    try:
        with open('enhanced_options_bot.py', 'r') as f:
            source = f.read()
        
        # Parse the AST to check for syntax errors
        tree = ast.parse(source)
        logger.info("✅ Syntax check passed")
        
        # Count key components
        classes = sum(1 for node in ast.walk(tree) if isinstance(node, ast.ClassDef))
        functions = sum(1 for node in ast.walk(tree) if isinstance(node, ast.FunctionDef))
        
        logger.info(f"📊 Found {classes} classes and {functions} functions")
        
        # Check for key methods
        method_names = [node.name for node in ast.walk(tree)]
                       if isinstance(node, ast.FunctionDef)]
        
        key_methods = []
            'find_premium_selling_opportunities',
            'find_spread_opportunities', 
            'find_directional_plays',
            'calculate_black_scholes_greeks',
            'execute_spread_trade',
            'should_trade'
        ]
        
        for method in key_methods:
            if method in method_names:
                logger.info(f"✅ {method} - Found")
            else:
                logger.info(f"❌ {method} - Missing")
                
        logger.info("\n🎯 Key Features Added:")
        logger.info("• Iron Condor and Butterfly spread strategies")
        logger.info("• Black-Scholes Greeks calculations")
        logger.info("• Enhanced risk management")
        logger.info("• Multi-strategy portfolio allocation")
        logger.info("• Directional options trading")
        logger.info("• Advanced position management")
        
        return True
        
    except SyntaxError as e:
        logger.info(f"❌ Syntax error: {e}")
        return False
    except Exception as e:
        logger.error("❌ Error: {e}")
        return False

if __name__ == "__main__":
    success = test_syntax()
    sys.exit(0 if success else 1)