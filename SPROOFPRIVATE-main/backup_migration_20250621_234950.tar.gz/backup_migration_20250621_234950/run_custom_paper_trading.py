
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Run Custom Paper Trading - Immediate execution demo
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import logging
from datetime import datetime, timedelta
import numpy as np

from custom_paper_trading_system import ()

from universal_market_data import get_current_market_data, get_realistic_price
    CustomPaperTradingAccount, Order, OrderSide, OrderType, AssetType
)

logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def run_trading_demo():
    """Run a comprehensive trading demo"""
    # Create custom paper account
    account = CustomPaperTradingAccount(initial_balance=100000)
    
    logger.info("🏦 CUSTOM PAPER TRADING SYSTEM DEMO")
    logger.info("=" * 60)
    
    # Initial status
    summary = account.get_portfolio_summary()
    logger.info(f"💰 Starting Balance: ${summary['cash_balance']:,.2f}")
    
    # 1. Stock trades
    logger.info("\n📈 EXECUTING STOCK TRADES")
    stock_orders = []
        ("AAPL", 100, 199.50, OrderSide.BUY),
        ("MSFT", 50, 449.80, OrderSide.BUY),
        ("TSLA", 30, 324.50, OrderSide.BUY)
    ]
    
    for symbol, qty, price, side in stock_orders:
        order = Order()
            order_id="",
            symbol=symbol,
            asset_type=AssetType.STOCK,
            side=side,
            order_type=OrderType.MARKET,
            quantity=qty
        )
        
        order_id = account.submit_order(order)
        if order_id:
            account.execute_order(order_id, fill_price=price)
            
    # 2. Options trades
    logger.info("\n📊 EXECUTING OPTIONS TRADES")
    
    # Buy calls
    call_order = Order()
        order_id="",
        symbol="AAPL250620C00200000",
        asset_type=AssetType.OPTION,
        side=OrderSide.BUY_TO_OPEN,
        order_type=OrderType.LIMIT,
        quantity=10,  # 10 contracts
        limit_price=2.50,
        option_details={}
            'underlying': 'AAPL',
            'strike': 200,
            'expiry': '2025-06-20',
            'type': 'call'
        }
    )
    
    order_id = account.submit_order(call_order)
    if order_id:
        account.execute_order(order_id)
        
    # Sell puts (cash-secured)
    put_order = Order()
        order_id="",
        symbol="MSFT250620P00440000",
        asset_type=AssetType.OPTION,
        side=OrderSide.SELL_TO_OPEN,
        order_type=OrderType.LIMIT,
        quantity=5,
        limit_price=3.20,
        option_details={}
            'underlying': 'MSFT',
            'strike': 440,
            'expiry': '2025-06-20',
            'type': 'put'
        }
    )
    
    order_id = account.submit_order(put_order)
    if order_id:
        account.execute_order(order_id)
        
    # 3. Spread trades
    logger.info("\n🦅 EXECUTING SPREAD TRADES")
    
    # Iron Condor on SPY
    iron_condor = Order()
        order_id="",
        symbol="SPY_IRON_CONDOR_590_595_615_620",
        asset_type=AssetType.SPREAD,
        side=OrderSide.SELL_TO_OPEN,
        order_type=OrderType.LIMIT,
        quantity=5,
        limit_price=2.00,  # Net credit
        spread_legs=[]
            {'symbol': 'SPY250620P00590000', 'side': 'buy', 'quantity': 5},
            {'symbol': 'SPY250620P00595000', 'side': 'sell', 'quantity': 5},
            {'symbol': 'SPY250620C00615000', 'side': 'sell', 'quantity': 5},
            {'symbol': 'SPY250620C00620000', 'side': 'buy', 'quantity': 5}
        ]
    )
    
    order_id = account.submit_order(iron_condor)
    if order_id:
        account.execute_order(order_id)
        
    # Butterfly Spread on QQQ
    butterfly = Order()
        order_id="",
        symbol="QQQ_BUTTERFLY_480_490_500",
        asset_type=AssetType.SPREAD,
        side=OrderSide.BUY_TO_OPEN,
        order_type=OrderType.LIMIT,
        quantity=10,
        limit_price=1.50,  # Net debit
        spread_legs=[]
            {'symbol': 'QQQ250620C00480000', 'side': 'buy', 'quantity': 10},
            {'symbol': 'QQQ250620C00490000', 'side': 'sell', 'quantity': 20},
            {'symbol': 'QQQ250620C00500000', 'side': 'buy', 'quantity': 10}
        ]
    )
    
    order_id = account.submit_order(butterfly)
    if order_id:
        account.execute_order(order_id)
        
    # Calendar Spread on TSLA
    calendar = Order()
        order_id="",
        symbol="TSLA_CALENDAR_325",
        asset_type=AssetType.SPREAD,
        side=OrderSide.BUY_TO_OPEN,
        order_type=OrderType.LIMIT,
        quantity=3,
        limit_price=4.00,  # Net debit
        spread_legs=[]
            {'symbol': 'TSLA250620C00325000', 'side': 'sell', 'quantity': 3},  # Front month
            {'symbol': 'TSLA250718C00325000', 'side': 'buy', 'quantity': 3}   # Back month
        ]
    )
    
    order_id = account.submit_order(calendar)
    if order_id:
        account.execute_order(order_id)
        
    # 4. Update market prices (simulate market movement)
    logger.info("\n📊 SIMULATING MARKET MOVEMENT")
    
    # Stocks move up
    market_updates = {}
        'AAPL': 202.00,  # +$2.50
        'MSFT': 453.00,  # +$3.20
        'TSLA': 330.00,  # +$5.50
        'AAPL250620C00200000': 3.50,  # Call gains value
        'MSFT250620P00440000': 2.00,  # Put loses value (good for seller)
        'SPY_IRON_CONDOR_590_595_615_620': 1.50,  # Profitable decay
        'QQQ_BUTTERFLY_480_490_500': 2.80,  # Butterfly profits
        'TSLA_CALENDAR_325': 4.50  # Calendar spread gains
    }
    
    account.update_market_prices(market_updates)
    
    # 5. Close some positions
    logger.info("\n💰 CLOSING PROFITABLE POSITIONS")
    
    # Close half of AAPL stock
    close_order = Order()
        order_id="",
        symbol="AAPL",
        asset_type=AssetType.STOCK,
        side=OrderSide.SELL,
        order_type=OrderType.MARKET,
        quantity=50
    )
    
    order_id = account.submit_order(close_order)
    if order_id:
        account.execute_order(order_id, fill_price=202.00)
        
    # Close call options for profit
    close_calls = Order()
        order_id="",
        symbol="AAPL250620C00200000",
        asset_type=AssetType.OPTION,
        side=OrderSide.SELL_TO_CLOSE,
        order_type=OrderType.LIMIT,
        quantity=10,
        limit_price=3.50
    )
    
    order_id = account.submit_order(close_calls)
    if order_id:
        account.execute_order(order_id)
        
    # 6. Display final results
    logger.info("\n" + "=" * 60)
    logger.info("📊 FINAL PORTFOLIO SUMMARY")
    logger.info("=" * 60)
    
    final_summary = account.get_portfolio_summary()
    
    logger.info(f"💰 Total Portfolio Value: ${final_summary['total_value']:,.2f}")
    logger.info(f"💵 Cash Balance: ${final_summary['cash_balance']:,.2f}")
    logger.info(f"📈 Positions Value: ${final_summary['positions_value']:,.2f}")
    logger.info(f"💹 Total Realized P&L: ${final_summary['total_realized_pnl']:,.2f}")
    logger.info(f"📊 Total Unrealized P&L: ${final_summary['total_unrealized_pnl']:,.2f}")
    logger.info(f"🎯 Total P&L: ${final_summary['total_pnl']:,.2f}")
    logger.info(f"📈 Return: {final_summary['return_pct']:.2f}%")
    logger.info(f"✅ Win Rate: {final_summary['win_rate']:.1f}%")
    logger.info(f"💰 Total Commission: ${final_summary['total_commission']:.2f}")
    
    logger.info("\n📊 CURRENT POSITIONS:")
    for symbol, position in final_summary['positions'].items():
        logger.info(f"   {symbol}:")
        logger.info(f"      Quantity: {position['quantity']}")
        logger.info(f"      Entry: ${position['entry_price']:.2f}")
        logger.info(f"      Current: ${position['current_price']:.2f}")
        logger.info(f"      P&L: ${position['unrealized_pnl']:.2f}")
        
    # 7. Show trade history
    logger.info("\n📜 TRADE HISTORY:")
    for i, trade in enumerate(account.trades[-10:], 1):  # Last 10 trades
        logger.info(f"   {i}. {trade.side.value} {trade.quantity} {trade.symbol} @ ${trade.price:.2f}")
        
    # Save final snapshot
    account.save_account_snapshot()
    
    logger.info("\n✅ Custom paper trading demo completed successfully!")
    
    # Show database location
    logger.info(f"📁 Trading data saved to: {account.db_path}")


if __name__ == "__main__":
    asyncio.run(run_trading_demo()