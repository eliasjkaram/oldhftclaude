
#!/usr/bin/env python3
"""
Advanced Analytics and Visualization for Enhanced GUI
3D visualizations, interactive charts, heatmaps, and real-time analytics
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.animation as animation
from matplotlib.patches import Rectangle
import seaborn as sns
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk
import logging
from typing import Dict, List, Tuple, Optional
from collections import deque
import threading
import queue

# 3D plotting
try:
    from mpl_toolkits.mplot3d import Axes3D
    THREEJS_AVAILABLE = True
except ImportError:
    THREEJS_AVAILABLE = False

# Advanced plotting
try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    import plotly.offline as pyo
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False

logger = logging.getLogger(__name__)

class RealTimeAnalytics:
    """Real-time analytics engine for live data processing"""
    
    def __init__(self):
        self.metrics_history = deque(maxlen=10000)
        self.performance_cache = {}
        self.analytics_active = False
        
        # Real-time calculations
        self.rolling_windows = {}
            'short': 60,    # 1 minute
            'medium': 300,  # 5 minutes
            'long': 3600    # 1 hour
        }
        
        # Analytics queue for async processing
        self.analytics_queue = queue.Queue()
        self.analytics_thread = None
        
    def start_analytics(self):
        """Start real-time analytics processing"""
        self.analytics_active = True
        self.analytics_thread = threading.Thread(target=self._analytics_loop, daemon=True)
        self.analytics_thread.start()
        
    def stop_analytics(self):
        """Stop analytics processing"""
        self.analytics_active = False
        
    def _analytics_loop(self):
        """Main analytics processing loop"""
        while self.analytics_active:
            try:
                # Process queued data
                while not self.analytics_queue.empty():
                    data_point = self.analytics_queue.get_nowait()
                    self._process_data_point(data_point)
                    
                # Calculate rolling metrics
                if len(self.metrics_history) > 10:
                    self._calculate_rolling_metrics()
                    
                # Sleep briefly
                threading.Event().wait(0.1)
                
            except Exception as e:
                logger.error(f"Analytics loop error: {e}")
                threading.Event().wait(1)
                
    def add_data_point(self, data: Dict):
        """Add new data point for processing"""
        data['timestamp'] = datetime.now()
        self.analytics_queue.put(data)
        
    def _process_data_point(self, data: Dict):
        """Process individual data point"""
        self.metrics_history.append(data)
        
        # Update performance cache
        self._update_performance_cache(data)
        
    def _update_performance_cache(self, data: Dict):
        """Update performance metrics cache"""
        try:
            # Processing speed metrics
            if 'processing_time' in data:
                self.performance_cache['avg_processing_time'] = np.mean([)
                    d.get('processing_time', 0) for d in list(self.metrics_history)[-100:]
                ])
                
            # Success rate metrics
            if 'trade_success' in data:
                recent_trades = []
                    d.get('trade_success', False) for d in list(self.metrics_history)[-50:]
                    if 'trade_success' in d
                ]
                if recent_trades:
                    self.performance_cache['success_rate'] = np.mean(recent_trades)
                    
            # P&L metrics
            if 'pnl' in data:
                self.performance_cache['total_pnl'] = sum([)
                    d.get('pnl', 0) for d in self.metrics_history
                ])
                
        except Exception as e:
            logger.error(f"Performance cache update failed: {e}")
            
    def _calculate_rolling_metrics(self):
        """Calculate rolling window metrics"""
        try:
            current_time = datetime.now()
            
            for window_name, seconds in self.rolling_windows.items():
                cutoff_time = current_time - timedelta(seconds=seconds)
                
                # Filter data for this window
                window_data = []
                    d for d in self.metrics_history 
                    if d.get('timestamp', current_time) > cutoff_time
                ]
                
                if len(window_data) > 0:
                    # Calculate metrics for this window
                    window_metrics = self._calculate_window_metrics(window_data)
                    self.performance_cache[f'{window_name}_window'] = window_metrics
                    
        except Exception as e:
            logger.error(f"Rolling metrics calculation failed: {e}")
            
    def _calculate_window_metrics(self, window_data: List[Dict]) -> Dict:
        """Calculate metrics for a time window"""
        metrics = {}
        
        try:
            # Opportunity metrics
            opportunities = [d.get('opportunities_found', 0) for d in window_data]
            if opportunities:
                metrics['avg_opportunities'] = np.mean(opportunities)
                metrics['max_opportunities'] = np.max(opportunities)
                
            # Performance metrics
            processing_times = [d.get('processing_time', 0) for d in window_data if 'processing_time' in d]
            if processing_times:
                metrics['avg_processing_time'] = np.mean(processing_times)
                metrics['processing_speed'] = len(window_data) / len(processing_times) if processing_times else 0
                
            # Trade metrics
            trades = [d for d in window_data if 'trade_success' in d]
            if trades:
                metrics['trade_count'] = len(trades)
                metrics['success_rate'] = np.mean([t['trade_success'] for t in trades])
                
        except Exception as e:
            logger.error(f"Window metrics calculation failed: {e}")
            
        return metrics
        
    def get_real_time_metrics(self) -> Dict:
        """Get current real-time metrics"""
        return self.performance_cache.copy()
        
    def get_trend_analysis(self) -> Dict:
        """Get trend analysis of recent performance"""
        try:
            if len(self.metrics_history) < 20:
                return {}
                
            recent_data = list(self.metrics_history)[-50:]
            
            # Extract time series data
            timestamps = [d.get('timestamp', datetime.now() for d in recent_data]
            
            # Performance trends
            trends = {}
            
            # Processing time trend
            processing_times = [d.get('processing_time', 0) for d in recent_data if 'processing_time' in d]
            if len(processing_times) > 5:
                x = np.arange(len(processing_times)
                z = np.polyfit(x, processing_times, 1)
                trends['processing_time_trend'] = z[0]  # Slope
                
            # Success rate trend
            successes = [d.get('trade_success', False) for d in recent_data if 'trade_success' in d]
            if len(successes) > 5:
                # Moving success rate
                window_size = min(10, len(successes) // 2)
                success_rates = []
                for i in range(window_size, len(successes):
                    window_success = np.mean(successes[i-window_size:i])
                    success_rates.append(window_success)
                    
                if len(success_rates) > 3:
                    x = np.arange(len(success_rates)
                    z = np.polyfit(x, success_rates, 1)
                    trends['success_rate_trend'] = z[0]
                    
            return trends
            
        except Exception as e:
            logger.error(f"Trend analysis failed: {e}")
            return {}

class AdvancedVisualization:
    """Advanced visualization components for the GUI"""
    
    def __init__(self):
        self.color_schemes = {}
            'dark': {}
                'bg': '#1a1a1a',
                'surface': '#2d2d2d',
                'primary': '#0078d4',
                'success': '#00ff88',
                'warning': '#ffaa00',
                'danger': '#ff4444',
                'text': '#ffffff'
            },
            'matrix': {}
                'bg': '#000000',
                'surface': '#001100',
                'primary': '#00ff00',
                'success': '#00ff88',
                'warning': '#ffff00',
                'danger': '#ff0000',
                'text': '#00ff00'
            }
        }
        
        self.current_theme = 'dark'
        
    def create_3d_performance_surface(self, parent, data: Dict) -> FigureCanvasTkAgg:
        """Create 3D performance surface visualization"""
        fig = Figure(figsize=(10, 8), facecolor=self.color_schemes[self.current_theme]['bg'])
        
        if THREEJS_AVAILABLE:
            ax = fig.add_subplot(111, projection='3d')
            ax.set_facecolor(self.color_schemes[self.current_theme]['surface'])
            
            try:
                # Generate sample 3D data for demonstration
                x = np.linspace(0.1, 0.4, 20)  # Delta range
                y = np.linspace(7, 45, 20)     # DTE range
                X, Y = np.meshgrid(x, y)
                
                # Simulate performance surface (higher is better)
                Z = np.sin(X * 10) * np.cos(Y / 10) * np.exp(-((X - 0.25)**2 + (Y - 25)**2) / 100)
                Z = (Z - Z.min() / (Z.max() - Z.min()  # Normalize))
                
                # Create surface plot
                surface = ax.plot_surface(X, Y, Z, cmap='RdYlGn', alpha=0.8, 
                                        linewidth=0, antialiased=True)
                
                # Add contour lines
                ax.contour(X, Y, Z, zdir='z', offset=Z.min(), cmap='RdYlGn', alpha=0.5)
                
                # Styling
                ax.set_xlabel('Delta', color=self.color_schemes[self.current_theme]['text'])
                ax.set_ylabel('DTE (Days)', color=self.color_schemes[self.current_theme]['text'])
                ax.set_zlabel('Performance Score', color=self.color_schemes[self.current_theme]['text'])
                ax.set_title('Strategy Performance Surface', 
                           color=self.color_schemes[self.current_theme]['text'], fontsize=14)
                
                # Color bar
                fig.colorbar(surface, ax=ax, shrink=0.5, aspect=5)
                
                # Style axes
                ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
                ax.grid(True, alpha=0.3)
                
            except Exception as e:
                logger.error(f"3D surface creation failed: {e}")
                # Fallback to 2D plot
                ax.remove()
                ax = fig.add_subplot(111)
                ax.text(0.5, 0.5, '3D Visualization\nNot Available', 
                       transform=ax.transAxes, ha='center', va='center',
                       color=self.color_schemes[self.current_theme]['text'])
        else:
            ax = fig.add_subplot(111)
            ax.text(0.5, 0.5, '3D Visualization\nRequires mpl_toolkits', 
                   transform=ax.transAxes, ha='center', va='center',
                   color=self.color_schemes[self.current_theme]['text'])
            
        canvas = FigureCanvasTkAgg(fig, parent)
        return canvas
        
    def create_heat_map(self, parent, data: Dict) -> FigureCanvasTkAgg:
        """Create performance heatmap"""
        fig = Figure(figsize=(12, 8), facecolor=self.color_schemes[self.current_theme]['bg'])
        ax = fig.add_subplot(111)
        ax.set_facecolor(self.color_schemes[self.current_theme]['surface'])
        
        try:
            # Generate sample correlation matrix
            symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'GOOGL', 'AMD', 'NVDA', 'TSLA']
            n_symbols = len(symbols)
            
            # Simulate correlation data
            np.random.seed(42)
            correlation_matrix = np.random.randn(n_symbols, n_symbols)
            correlation_matrix = np.corrcoef(correlation_matrix)
            
            # Create heatmap
            im = ax.imshow(correlation_matrix, cmap='RdBu_r', aspect='auto', 
                          vmin=-1, vmax=1, interpolation='nearest')
            
            # Add text annotations
            for i in range(n_symbols):
                for j in range(n_symbols):
                    text = ax.text(j, i, f'{correlation_matrix[i, j]:.2f}',
                                 ha="center", va="center", 
                                 color="white" if abs(correlation_matrix[i, j]) > 0.5 else "black",
                                 fontsize=8)
                                 
            # Styling
            ax.set_xticks(range(n_symbols)
            ax.set_yticks(range(n_symbols)
            ax.set_xticklabels(symbols, rotation=45)
            ax.set_yticklabels(symbols)
            ax.set_title('Symbol Correlation Heatmap', 
                        color=self.color_schemes[self.current_theme]['text'], fontsize=14)
            
            # Color bar
            cbar = fig.colorbar(im, ax=ax)
            cbar.ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            
            # Style
            ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            
        except Exception as e:
            logger.error(f"Heatmap creation failed: {e}")
            ax.text(0.5, 0.5, 'Heatmap\nGeneration Failed', 
                   transform=ax.transAxes, ha='center', va='center',
                   color=self.color_schemes[self.current_theme]['text'])
            
        canvas = FigureCanvasTkAgg(fig, parent)
        return canvas
        
    def create_real_time_stream(self, parent) -> Tuple[FigureCanvasTkAgg, animation.FuncAnimation]:
        """Create real-time streaming chart"""
        fig = Figure(figsize=(12, 6), facecolor=self.color_schemes[self.current_theme]['bg'])
        ax = fig.add_subplot(111)
        ax.set_facecolor(self.color_schemes[self.current_theme]['surface'])
        
        # Data storage for animation
        self.stream_data = {}
            'times': deque(maxlen=100),
            'portfolio_values': deque(maxlen=100),
            'processing_speeds': deque(maxlen=100),
            'opportunity_scores': deque(maxlen=100)
        }
        
        # Initialize with some data
        base_time = datetime.now()
        for i in range(50):
            self.stream_data['times'].append(base_time + timedelta(seconds=i)
            self.stream_data['portfolio_values'].append(100000 + np.random.normal(0, 500)
            self.stream_data['processing_speeds'].append(120000 + np.random.normal(0, 5000)
            self.stream_data['opportunity_scores'].append(0.7 + np.random.normal(0, 0.1)
            
        # Create initial plots
        self.portfolio_line, = ax.plot([], [], color=self.color_schemes[self.current_theme]['success'], 
                                      linewidth=2, label='Portfolio Value')
        
        # Twin axes for different scales
        ax2 = ax.twinx()
        ax3 = ax.twinx()
        ax3.spines['right'].set_position(('outward', 60)
        
        self.speed_line, = ax2.plot([], [], color=self.color_schemes[self.current_theme]['primary'], 
                                   linewidth=2, label='Processing Speed')
        self.score_line, = ax3.plot([], [], color=self.color_schemes[self.current_theme]['warning'], 
                                   linewidth=2, label='Opportunity Score')
        
        # Styling
        ax.set_title('Real-time Performance Stream', 
                    color=self.color_schemes[self.current_theme]['text'], fontsize=14)
        ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
        ax2.tick_params(colors=self.color_schemes[self.current_theme]['text'])
        ax3.tick_params(colors=self.color_schemes[self.current_theme]['text'])
        
        ax.grid(True, alpha=0.3)
        
        # Labels
        ax.set_ylabel('Portfolio Value ($)', color=self.color_schemes[self.current_theme]['text'])
        ax2.set_ylabel('Processing Speed (ops/sec)', color=self.color_schemes[self.current_theme]['text'])
        ax3.set_ylabel('Opportunity Score', color=self.color_schemes[self.current_theme]['text'])
        
        def animate(frame):
            """Animation function"""
            try:
                # Add new data point
                current_time = datetime.now()
                self.stream_data['times'].append(current_time)
                
                # Simulate real-time data
                last_portfolio = self.stream_data['portfolio_values'][-1] if self.stream_data['portfolio_values'] else 100000
                new_portfolio = last_portfolio + np.random.normal(0, 100)
                self.stream_data['portfolio_values'].append(new_portfolio)
                
                new_speed = 120000 + np.random.normal(0, 3000)
                self.stream_data['processing_speeds'].append(max(0, new_speed)
                
                new_score = 0.7 + np.random.normal(0, 0.05)
                self.stream_data['opportunity_scores'].append(np.clip(new_score, 0, 1)
                
                # Update plots
                times = list(self.stream_data['times'])
                portfolio_values = list(self.stream_data['portfolio_values'])
                processing_speeds = list(self.stream_data['processing_speeds'])
                opportunity_scores = list(self.stream_data['opportunity_scores'])
                
                self.portfolio_line.set_data(times, portfolio_values)
                self.speed_line.set_data(times, processing_speeds)
                self.score_line.set_data(times, opportunity_scores)
                
                # Auto-scale axes
                if len(times) > 1:
                    ax.set_xlim(times[0], times[-1])
                    ax.set_ylim(min(portfolio_values) * 0.999, max(portfolio_values) * 1.001)
                    ax2.set_ylim(min(processing_speeds) * 0.95, max(processing_speeds) * 1.05)
                    ax3.set_ylim(0, 1)
                    
                # Format x-axis
                ax.tick_params(axis='x', rotation=45)
                
            except Exception as e:
                logger.error(f"Animation frame failed: {e}")
                
            return self.portfolio_line, self.speed_line, self.score_line
            
        # Create animation
        anim = animation.FuncAnimation(fig, animate, interval=1000, blit=False, cache_frame_data=False)
        
        canvas = FigureCanvasTkAgg(fig, parent)
        return canvas, anim
        
    def create_options_flow_diagram(self, parent, options_data: List[Dict]) -> FigureCanvasTkAgg:
        """Create options flow diagram"""
        fig = Figure(figsize=(14, 10), facecolor=self.color_schemes[self.current_theme]['bg'])
        ax = fig.add_subplot(111)
        ax.set_facecolor(self.color_schemes[self.current_theme]['surface'])
        
        try:
            # Simulate options flow data
            symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'GOOGL']
            option_types = ['PUT', 'CALL']
            
            # Create flow diagram
            y_positions = {}
            y_offset = 0
            
            for symbol in symbols:
                y_positions[symbol] = {}
                for opt_type in option_types:
                    y_positions[symbol][opt_type] = y_offset
                    y_offset += 1
                    
            # Draw flow connections
            for i, symbol in enumerate(symbols):
                for j, opt_type in enumerate(option_types):
                    y_pos = y_positions[symbol][opt_type]
                    
                    # Volume representation (width of bars)
                    volume = np.random.randint(100, 1000)
                    width = volume / 1000 * 3  # Scale to reasonable width
                    
                    # Color based on option type
                    color = self.color_schemes[self.current_theme]['success'] if opt_type == 'PUT' else self.color_schemes[self.current_theme]['primary']
                    
                    # Draw bar
                    rect = Rectangle((0, y_pos - width/2), 5, width, 
                                   facecolor=color, alpha=0.7, edgecolor='white')
                    ax.add_patch(rect)
                    
                    # Add text
                    ax.text(2.5, y_pos, f'{symbol} {opt_type}\nVol: {volume}', 
                           ha='center', va='center', fontsize=9,
                           color=self.color_schemes[self.current_theme]['text'])
                           
            # Styling
            ax.set_xlim(-1, 6)
            ax.set_ylim(-0.5, len(symbols) * len(option_types) - 0.5)
            ax.set_title('Options Flow Analysis', 
                        color=self.color_schemes[self.current_theme]['text'], fontsize=16)
            
            # Remove ticks
            ax.set_xticks([])
            ax.set_yticks([])
            
            # Add legend
            put_patch = Rectangle((0, 0), 1, 1, facecolor=self.color_schemes[self.current_theme]['success'], alpha=0.7)
            call_patch = Rectangle((0, 0), 1, 1, facecolor=self.color_schemes[self.current_theme]['primary'], alpha=0.7)
            ax.legend([put_patch, call_patch], ['PUT Options', 'CALL Options'], 
                     loc='upper right', facecolor=self.color_schemes[self.current_theme]['surface'])
            
        except Exception as e:
            logger.error(f"Options flow diagram failed: {e}")
            ax.text(0.5, 0.5, 'Options Flow\nDiagram Failed', 
                   transform=ax.transAxes, ha='center', va='center',
                   color=self.color_schemes[self.current_theme]['text'])
            
        canvas = FigureCanvasTkAgg(fig, parent)
        return canvas
        
    def create_risk_analytics_dashboard(self, parent) -> FigureCanvasTkAgg:
        """Create comprehensive risk analytics dashboard"""
        fig = Figure(figsize=(16, 12), facecolor=self.color_schemes[self.current_theme]['bg'])
        
        # Create subplots
        gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
        
        # Portfolio distribution (pie chart)
        ax1 = fig.add_subplot(gs[0, 0])
        self._create_portfolio_distribution(ax1)
        
        # Risk metrics over time
        ax2 = fig.add_subplot(gs[0, 1:])
        self._create_risk_timeline(ax2)
        
        # Volatility surface
        ax3 = fig.add_subplot(gs[1, :])
        self._create_volatility_surface(ax3)
        
        # Greeks analysis
        ax4 = fig.add_subplot(gs[2, 0])
        self._create_greeks_analysis(ax4)
        
        # Correlation matrix
        ax5 = fig.add_subplot(gs[2, 1])
        self._create_mini_correlation_matrix(ax5)
        
        # Risk indicators
        ax6 = fig.add_subplot(gs[2, 2])
        self._create_risk_indicators(ax6)
        
        canvas = FigureCanvasTkAgg(fig, parent)
        return canvas
        
    def _create_portfolio_distribution(self, ax):
        """Create portfolio distribution pie chart"""
        try:
            labels = ['Wheel Positions', 'Premium Trades', 'Cash', 'Margin']
            sizes = [45, 30, 20, 5]
            colors = [self.color_schemes[self.current_theme]['success'],
                     self.color_schemes[self.current_theme]['primary'],
                     self.color_schemes[self.current_theme]['warning'],
                     self.color_schemes[self.current_theme]['danger']]
            
            wedges, texts, autotexts = ax.pie(sizes, labels=labels, colors=colors, 
                                            autopct='%1.1f%%', startangle=90)
            
            ax.set_title('Portfolio Distribution', 
                        color=self.color_schemes[self.current_theme]['text'])
            
            # Style text
            for text in texts + autotexts:
                text.set_color(self.color_schemes[self.current_theme]['text'])
                
        except Exception as e:
            logger.error(f"Portfolio distribution failed: {e}")
            
    def _create_risk_timeline(self, ax):
        """Create risk metrics timeline"""
        try:
            # Generate sample risk data
            dates = pd.date_range('2024-01-01', periods=30, freq='D')
            var_95 = np.random.uniform(-0.02, -0.05, 30)
            max_dd = np.cumsum(np.random.uniform(-0.001, 0.0005, 30)
            volatility = np.random.uniform(0.15, 0.35, 30)
            
            ax.plot(dates, var_95, color=self.color_schemes[self.current_theme]['danger'], 
                   label='VaR 95%', linewidth=2)
            ax.plot(dates, max_dd, color=self.color_schemes[self.current_theme]['warning'], 
                   label='Max Drawdown', linewidth=2)
            
            ax2 = ax.twinx()
            ax2.plot(dates, volatility, color=self.color_schemes[self.current_theme]['primary'], 
                    label='Volatility', linewidth=2, linestyle='--')
            
            ax.set_title('Risk Metrics Timeline', 
                        color=self.color_schemes[self.current_theme]['text'])
            ax.legend(loc='upper left')
            ax2.legend(loc='upper right')
            
            # Style
            ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            ax2.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            ax.grid(True, alpha=0.3)
            
        except Exception as e:
            logger.error(f"Risk timeline failed: {e}")
            
    def _create_volatility_surface(self, ax):
        """Create implied volatility surface"""
        try:
            # Generate sample IV surface data
            strikes = np.linspace(0.8, 1.2, 20)  # Moneyness
            expiries = np.linspace(0.1, 1.0, 15)   # Time to expiry
            X, Y = np.meshgrid(strikes, expiries)
            
            # Simulate IV surface (typical smile/skew pattern)
            Z = 0.25 + 0.1 * (X - 1.0)**2 + 0.05 * np.exp(-Y * 2)
            
            # Create contour plot
            contour = ax.contourf(X, Y, Z, levels=20, cmap='RdYlGn_r')
            ax.contour(X, Y, Z, levels=20, colors='black', alpha=0.4, linewidths=0.5)
            
            ax.set_xlabel('Moneyness (S/K)', color=self.color_schemes[self.current_theme]['text'])
            ax.set_ylabel('Time to Expiry (Years)', color=self.color_schemes[self.current_theme]['text'])
            ax.set_title('Implied Volatility Surface', 
                        color=self.color_schemes[self.current_theme]['text'])
            
            # Color bar
            cbar = plt.colorbar(contour, ax=ax)
            cbar.set_label('Implied Volatility', color=self.color_schemes[self.current_theme]['text'])
            cbar.ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            
            ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            
        except Exception as e:
            logger.error(f"Volatility surface failed: {e}")
            
    def _create_greeks_analysis(self, ax):
        """Create Greeks analysis chart"""
        try:
            greeks = ['Delta', 'Gamma', 'Theta', 'Vega']
            values = [0.25, 0.15, -0.08, 0.12]
            colors = [self.color_schemes[self.current_theme]['primary'],
                     self.color_schemes[self.current_theme]['success'],
                     self.color_schemes[self.current_theme]['danger'],
                     self.color_schemes[self.current_theme]['warning']]
            
            bars = ax.bar(greeks, values, color=colors, alpha=0.8)
            ax.set_title('Portfolio Greeks', color=self.color_schemes[self.current_theme]['text'])
            ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            ax.grid(True, alpha=0.3)
            
            # Add value labels
            for bar, value in zip(bars, values):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                       f'{value:.3f}', ha='center', va='bottom',
                       color=self.color_schemes[self.current_theme]['text'])
                       
        except Exception as e:
            logger.error(f"Greeks analysis failed: {e}")
            
    def _create_mini_correlation_matrix(self, ax):
        """Create mini correlation matrix"""
        try:
            assets = ['SPY', 'QQQ', 'VXX', 'TLT']
            corr_data = np.random.randn(len(assets), len(assets)
            corr_matrix = np.corrcoef(corr_data)
            
            im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-1, vmax=1)
            
            ax.set_xticks(range(len(assets))
            ax.set_yticks(range(len(assets))
            ax.set_xticklabels(assets)
            ax.set_yticklabels(assets)
            ax.set_title('Asset Correlations', color=self.color_schemes[self.current_theme]['text'])
            
            ax.tick_params(colors=self.color_schemes[self.current_theme]['text'])
            
        except Exception as e:
            logger.error(f"Mini correlation matrix failed: {e}")
            
    def _create_risk_indicators(self, ax):
        """Create risk indicator gauges"""
        try:
            # Simple risk level indicator
            risk_level = 0.35  # 35% risk level
            
            # Create gauge-like visualization
            theta = np.linspace(0, np.pi, 100)
            r = 1
            
            # Background arc
            ax.plot(r * np.cos(theta), r * np.sin(theta), 
                   color=self.color_schemes[self.current_theme]['text'], alpha=0.3, linewidth=10)
            
            # Risk level arc
            risk_theta = theta[:int(risk_level * 100)]
            ax.plot(r * np.cos(risk_theta), r * np.sin(risk_theta), 
                   color=self.color_schemes[self.current_theme]['warning'], linewidth=10)
            
            # Needle
            needle_angle = risk_level * np.pi
            ax.arrow(0, 0, 0.8 * np.cos(needle_angle), 0.8 * np.sin(needle_angle),
                    head_width=0.1, head_length=0.1, fc=self.color_schemes[self.current_theme]['danger'])
            
            ax.set_xlim(-1.2, 1.2)
            ax.set_ylim(-0.2, 1.2)
            ax.set_aspect('equal')
            ax.axis('off')
            ax.set_title('Risk Level', color=self.color_schemes[self.current_theme]['text'])
            
            # Add text
            ax.text(0, -0.3, f'{risk_level:.1%}', ha='center', va='center',
                   fontsize=16, color=self.color_schemes[self.current_theme]['text'])
                   
        except Exception as e:
            logger.error(f"Risk indicators failed: {e}")

class InteractiveAnalytics:
    """Interactive analytics components"""
    
    def __init__(self):
        self.analytics_engine = RealTimeAnalytics()
        self.visualization = AdvancedVisualization()
        
    def create_interactive_dashboard(self, parent):
        """Create interactive analytics dashboard"""
        # Create notebook for different analytics views
        analytics_notebook = ttk.Notebook(parent)
        analytics_notebook.pack(fill=tk.BOTH, expand=True)
        
        # Performance Analytics
        perf_frame = ttk.Frame(analytics_notebook)
        analytics_notebook.add(perf_frame, text="📈 Performance")
        
        perf_canvas = self.visualization.create_3d_performance_surface(perf_frame, {})
        perf_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Risk Analytics
        risk_frame = ttk.Frame(analytics_notebook)
        analytics_notebook.add(risk_frame, text="⚠️ Risk")
        
        risk_canvas = self.visualization.create_risk_analytics_dashboard(risk_frame)
        risk_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Market Flow
        flow_frame = ttk.Frame(analytics_notebook)
        analytics_notebook.add(flow_frame, text="🌊 Flow")
        
        flow_canvas = self.visualization.create_options_flow_diagram(flow_frame, [])
        flow_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Real-time Stream
        stream_frame = ttk.Frame(analytics_notebook)
        analytics_notebook.add(stream_frame, text="📡 Live")
        
        stream_canvas, stream_anim = self.visualization.create_real_time_stream(stream_frame)
        stream_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Store animation reference to prevent garbage collection
        self.stream_animation = stream_anim
        
        return analytics_notebook

# Example usage
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Advanced Analytics Demo")
    root.geometry("1200x800")
    root.configure(bg='#1a1a1a')
    
    interactive = InteractiveAnalytics()
    dashboard = interactive.create_interactive_dashboard(root)
    
    root.mainloop()