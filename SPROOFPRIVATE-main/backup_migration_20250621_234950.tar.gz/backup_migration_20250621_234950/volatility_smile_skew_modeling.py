from error_handler import ErrorCategory
#!/usr/bin/env python3
"""
Volatility Smile and Skew Modeling System

Production-ready system for modeling and analyzing volatility smiles, skews, and term structures
across option chains with real-time calibration and trading signal generation.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import asyncio
from collections import defaultdict
import json
import logging
from scipy import stats, optimize, interpolate
from scipy.stats import norm
from scipy.optimize import minimize, differential_evolution
from scipy.interpolate import UnivariateSpline, RBFInterpolator
import warnings
warnings.filterwarnings('ignore')

# Internal imports
from unified_logging import get_logger
from unified_error_handling import retry, ErrorCategory, ErrorSeverity, handle_errors
from monitoring_alerting import MetricsCollector
from greeks_calculator import GreeksCalculator

logger = get_logger(__name__)


class VolatilityModelType(Enum):
    """Types of volatility models"""
    SABR = "sabr"                    # Stochastic Alpha Beta Rho
    SVI = "svi"                      # Stochastic Volatility Inspired
    HESTON = "heston"                # Heston stochastic vol
    POLYNOMIAL = "polynomial"        # Polynomial fitting
    SPLINE = "spline"               # Cubic spline interpolation
    RBF = "rbf"                     # Radial basis function
    PARAMETRIC = "parametric"       # Custom parametric model
    NEURAL_NETWORK = "neural_network" # NN-based surface


class SkewMetric(Enum):
    """Skew measurement metrics"""
    RISK_REVERSAL = "risk_reversal"    # 25D RR
    BUTTERFLY = "butterfly"            # 25D BF
    SKEW_SLOPE = "skew_slope"         # dIV/dK
    SKEW_CURVATURE = "skew_curvature" # d²IV/dK²
    PUT_CALL_RATIO = "put_call_ratio" # P/C IV ratio
    ATM_SKEW = "atm_skew"            # Skew at ATM


class CalibrationMethod(Enum):
    """Calibration methods for volatility models"""
    LEAST_SQUARES = "least_squares"
    MAXIMUM_LIKELIHOOD = "maximum_likelihood"
    WEIGHTED_LEAST_SQUARES = "weighted_least_squares"
    ROBUST = "robust"
    BAYESIAN = "bayesian"


@dataclass
class VolatilitySurface:
    """Volatility surface representation"""
    underlying: str
    as_of_date: datetime
    spot_price: float
    
    # Surface data
    strikes: np.ndarray
    expiries: np.ndarray
    implied_vols: np.ndarray  # 2D array [expiry, strike]
    
    # Market data
    forward_prices: Dict[float, float] = field(default_factory=dict)
    discount_factors: Dict[float, float] = field(default_factory=dict)
    dividend_yield: float = 0.0
    risk_free_rate: float = 0.05
    
    # Model parameters
    model_type: VolatilityModelType = VolatilityModelType.SVI
    model_params: Dict[str, Any] = field(default_factory=dict)
    
    # Calibration info
    calibration_error: float = 0.0
    calibration_time: float = 0.0
    last_calibration: Optional[datetime] = None
    
    # Surface metrics
    atm_vol: float = 0.0
    skew_metrics: Dict[str, float] = field(default_factory=dict)
    term_structure: Dict[float, float] = field(default_factory=dict)
    
    # Quality metrics
    arbitrage_free: bool = True
    calendar_arbitrage: List[Tuple[float, float]] = field(default_factory=list)
    butterfly_arbitrage: List[Tuple[float, float, float]] = field(default_factory=list)


@dataclass
class SmileParameters:
    """Parameters for a single smile (fixed expiry)"""
    expiry: float  # Time to expiry in years
    forward: float
    atm_vol: float
    
    # SVI parameters
    svi_a: float = 0.0      # Level
    svi_b: float = 0.0      # Angle  
    svi_rho: float = 0.0    # Rotation
    svi_m: float = 0.0      # Translation
    svi_sigma: float = 0.0  # Width
    
    # SABR parameters
    sabr_alpha: float = 0.0  # Vol of vol
    sabr_beta: float = 0.5   # CEV exponent
    sabr_rho: float = 0.0    # Correlation
    sabr_nu: float = 0.0     # Vol of vol
    
    # Polynomial coefficients
    poly_coeffs: List[float] = field(default_factory=list)
    
    # Fit quality
    rmse: float = 0.0
    max_error: float = 0.0


@dataclass
class SkewTradingSignal:
    """Trading signal based on volatility skew analysis"""
    signal_id: str
    timestamp: datetime
    underlying: str
    
    # Signal details
    signal_type: str  # 'skew_steepening', 'smile_flattening', etc.
    strength: float   # -1 to 1
    confidence: float # 0 to 1
    
    # Skew metrics
    current_skew: float
    historical_mean: float
    z_score: float
    percentile: float
    
    # Trade recommendation
    recommended_trades: List[Dict[str, Any]] = field(default_factory=list)
    expected_edge: float = 0.0
    risk_reward_ratio: float = 0.0
    
    # Time horizon
    holding_period_days: int = 1
    expiry_target: Optional[datetime] = None


@dataclass
class VolatilityRegime:
    """Volatility regime characteristics"""
    regime_id: str
    regime_type: str  # 'low_vol', 'high_vol', 'stressed', 'normal'
    
    # Regime parameters
    avg_atm_vol: float
    avg_skew: float
    avg_term_structure_slope: float
    
    # Historical statistics
    frequency: float  # Percentage of time in this regime
    avg_duration_days: float
    transition_probabilities: Dict[str, float] = field(default_factory=dict)
    
    # Typical smile shape
    typical_smile_params: Optional[SmileParameters] = None


class VolatilitySmileSkewModeling:
    """Advanced volatility smile and skew modeling system"""
    
    def __init__(self,
                 default_model: VolatilityModelType = VolatilityModelType.SVI,
                 calibration_method: CalibrationMethod = CalibrationMethod.WEIGHTED_LEAST_SQUARES):
        
        self.default_model = default_model
        self.calibration_method = calibration_method
        self.metrics_collector = MetricsCollector()
        self.greeks_calculator = GreeksCalculator()
        
        # Model cache
        self.surfaces: Dict[str, VolatilitySurface] = {}
        self.smile_params: Dict[Tuple[str, float], SmileParameters] = {}
        
        # Historical data
        self.historical_surfaces: Dict[str, List[VolatilitySurface]] = defaultdict(list)
        self.skew_history: Dict[str, pd.DataFrame] = {}
        
        # Regime detection
        self.volatility_regimes: Dict[str, VolatilityRegime] = {}
        self.current_regime: Optional[str] = None
        
        # Model parameters
        self.min_strikes = 5
        self.max_calibration_iter = 1000
        self.calibration_tolerance = 1e-6
        
        # Trading parameters
        self.skew_zscore_threshold = 2.0
        self.min_edge_threshold = 0.005  # 50 bps
        self.max_vega_exposure = 10000
        
        logger.info(f"Volatility Smile/Skew Modeling initialized with {default_model.value} model")
    
    @retry("fit_surface", 'calculation', ErrorSeverity.HIGH)
    async def fit_volatility_surface(self,
                                   option_chain: pd.DataFrame,
                                   underlying: str,
                                   spot_price: float,
                                   as_of_date: Optional[datetime] = None) -> VolatilitySurface:
        """Fit a volatility surface to option chain data"""
        
        as_of_date = as_of_date or datetime.now()
        
        # Prepare data
        strikes, expiries, ivs = self._prepare_surface_data(option_chain)
        
        # Create surface object
        surface = VolatilitySurface()
            underlying=underlying,
            as_of_date=as_of_date,
            spot_price=spot_price,
            strikes=strikes,
            expiries=expiries,
            implied_vols=ivs,
            model_type=self.default_model
        )
        
        # Calculate forwards and discount factors
        surface.forward_prices = self._calculate_forwards(option_chain, spot_price)
        surface.discount_factors = self._calculate_discount_factors(expiries)
        
        # Fit the surface
        start_time = datetime.now()
        
        if self.default_model == VolatilityModelType.SVI:
            await self._fit_svi_surface(surface)
        elif self.default_model == VolatilityModelType.SABR:
            await self._fit_sabr_surface(surface)
        elif self.default_model == VolatilityModelType.SPLINE:
            await self._fit_spline_surface(surface)
        elif self.default_model == VolatilityModelType.POLYNOMIAL:
            await self._fit_polynomial_surface(surface)
        else:
            raise ValueError(f"Unsupported model type: {self.default_model}")
        
        surface.calibration_time = (datetime.now() - start_time).total_seconds()
        surface.last_calibration = datetime.now()
        
        # Calculate surface metrics
        await self._calculate_surface_metrics(surface)
        
        # Check arbitrage conditions
        surface.arbitrage_free = await self._check_arbitrage_conditions(surface)
        
        # Store surface
        self.surfaces[underlying] = surface
        self.historical_surfaces[underlying].append(surface)
        
        # Emit metrics
        self.metrics_collector.record('volatility_surface.fitted', 1, {)
            'underlying': underlying,
            'model': self.default_model.value,
            'calibration_error': surface.calibration_error
        })
        
        logger.info(f"Fitted {self.default_model.value} surface for {underlying} ")
                   f"with error {surface.calibration_error:.4f}")
        
        return surface
    
    def _prepare_surface_data(self, option_chain: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Prepare and clean option chain data for surface fitting"""
        
        # Filter valid options
        valid_options = option_chain[]
            (option_chain['implied_volatility'] > 0.01) &  # IV > 1%
            (option_chain['implied_volatility'] < 5.0) &   # IV < 500%
            (option_chain['bid'] > 0) &
            (option_chain['ask'] > 0) &
            (option_chain['volume'] > 0)
        ].copy()
        
        # Group by expiry
        expiry_groups = valid_options.groupby('expiry')
        
        strikes_list = []
        expiries_list = []
        ivs_list = []
        
        for expiry, group in expiry_groups:
            if len(group) >= self.min_strikes:
                # Sort by strike
                group = group.sort_values('strike')
                
                # Use mid IV
                group['mid_iv'] = (group['bid_iv'] + group['ask_iv']) / 2
                
                # Calculate time to expiry
                tte = (expiry - datetime.now()).days / 365.25
                
                strikes_list.append(group['strike'].values)
                expiries_list.append(np.full(len(group), tte))
                ivs_list.append(group['mid_iv'].values)
        
        # Convert to arrays
        strikes = np.concatenate(strikes_list)
        expiries = np.concatenate(expiries_list)
        ivs = np.concatenate(ivs_list)
        
        return strikes, expiries, ivs
    
    async def _fit_svi_surface(self, surface: VolatilitySurface):
        """Fit SVI (Stochastic Volatility Inspired) model to surface"""
        
        # Fit smile for each expiry
        unique_expiries = np.unique(surface.expiries)
        
        for expiry in unique_expiries:
            mask = surface.expiries == expiry
            strikes = surface.strikes[mask]
            ivs = surface.implied_vols[mask]
            
            # Get forward price
            forward = surface.forward_prices.get(expiry, surface.spot_price)
            
            # Fit SVI smile
            smile_params = await self._fit_svi_smile(strikes, ivs, forward, expiry)
            self.smile_params[(surface.underlying, expiry)] = smile_params
        
        # Store parameters in surface
        surface.model_params['smiles'] = self.smile_params
        
        # Calculate overall calibration error
        errors = []
        for i, (strike, expiry, actual_iv) in enumerate(zip(surface.strikes, surface.expiries, surface.implied_vols)):
            fitted_iv = self._evaluate_svi(strike, expiry, surface)
            errors.append((fitted_iv - actual_iv) ** 2)
        
        surface.calibration_error = np.sqrt(np.mean(errors))
    
    async def _fit_svi_smile(self, strikes: np.ndarray, ivs: np.ndarray, 
                           forward: float, expiry: float) -> SmileParameters:
        """Fit SVI model to a single smile"""
        
        # Convert to log-moneyness
        log_moneyness = np.log(strikes / forward)
        total_variance = ivs ** 2 * expiry
        
        # SVI parameterization: w(k) = a + b*(rho*(k-m) + sqrt((k-m)^2 + sigma^2))
        def svi_variance(k, a, b, rho, m, sigma):
            return a + b * (rho * (k - m) + np.sqrt((k - m) ** 2 + sigma ** 2))
        
        # Objective function
        def objective(params):
            a, b, rho, m, sigma = params
            
            # Constraints built into objective
            if b < 0 or sigma < 0 or abs(rho) > 1:
                return 1e10
            
            # No calendar arbitrage: a + b*sigma*sqrt(1-rho^2) >= 0
            if a + b * sigma * np.sqrt(1 - rho ** 2) < 0:
                return 1e10
            
            fitted_variance = svi_variance(log_moneyness, a, b, rho, m, sigma)
            
            # Weighted by vega
            weights = np.exp(-0.5 * log_moneyness ** 2)  # Approximate vega weights
            
            if self.calibration_method == CalibrationMethod.WEIGHTED_LEAST_SQUARES:
                errors = weights * (fitted_variance - total_variance) ** 2
            else:
                errors = (fitted_variance - total_variance) ** 2
            
            return np.sum(errors)
        
        # Initial guess
        atm_idx = np.argmin(np.abs(log_moneyness))
        atm_var = total_variance[atm_idx]
        
        x0 = []
            atm_var * 0.9,          # a
            atm_var * 0.1,          # b  
            -0.1,                   # rho
            0.0,                    # m
            0.1                     # sigma
        ]
        
        # Optimize
        result = differential_evolution()
            objective,
            bounds=[]
                (0, atm_var * 2),       # a
                (0, atm_var),           # b
                (-0.999, 0.999),        # rho
                (-0.5, 0.5),            # m
                (0.01, 1.0)             # sigma
            ],
            seed=42,
            maxiter=self.max_calibration_iter
        )
        
        # Create smile parameters
        a, b, rho, m, sigma = result.x
        
        smile = SmileParameters()
            expiry=expiry,
            forward=forward,
            atm_vol=np.sqrt(atm_var / expiry),
            svi_a=a,
            svi_b=b,
            svi_rho=rho,
            svi_m=m,
            svi_sigma=sigma,
            rmse=np.sqrt(result.fun / len(strikes))
        )
        
        return smile
    
    def _evaluate_svi(self, strike: float, expiry: float, surface: VolatilitySurface) -> float:
        """Evaluate SVI model at given strike and expiry"""
        
        # Find closest calibrated expiry
        calibrated_expiries = [exp for (und, exp) in self.smile_params.keys()]
                              if und == surface.underlying]
        
        if not calibrated_expiries:
            return 0.2  # Default volatility
        
        closest_expiry = min(calibrated_expiries, key=lambda x: abs(x - expiry))
        smile = self.smile_params[(surface.underlying, closest_expiry)]
        
        # Get forward
        forward = surface.forward_prices.get(expiry, surface.spot_price)
        
        # Calculate log-moneyness
        k = np.log(strike / forward)
        
        # SVI variance
        w = smile.svi_a + smile.svi_b * ()
            smile.svi_rho * (k - smile.svi_m) + 
            np.sqrt((k - smile.svi_m) ** 2 + smile.svi_sigma ** 2)
        )
        
        # Convert to IV
        total_variance = max(w, 1e-6)  # Ensure positive
        iv = np.sqrt(total_variance / expiry)
        
        return iv
    
    async def _fit_sabr_surface(self, surface: VolatilitySurface):
        """Fit SABR model to surface"""
        
        unique_expiries = np.unique(surface.expiries)
        
        for expiry in unique_expiries:
            mask = surface.expiries == expiry
            strikes = surface.strikes[mask]
            ivs = surface.implied_vols[mask]
            
            forward = surface.forward_prices.get(expiry, surface.spot_price)
            
            # Fit SABR smile
            smile_params = await self._fit_sabr_smile(strikes, ivs, forward, expiry)
            self.smile_params[(surface.underlying, expiry)] = smile_params
        
        # Calculate calibration error
        errors = []
        for i, (strike, expiry, actual_iv) in enumerate(zip(surface.strikes, surface.expiries, surface.implied_vols)):
            fitted_iv = self._evaluate_sabr(strike, expiry, surface)
            errors.append((fitted_iv - actual_iv) ** 2)
        
        surface.calibration_error = np.sqrt(np.mean(errors))
    
    async def _fit_sabr_smile(self, strikes: np.ndarray, ivs: np.ndarray,
                            forward: float, expiry: float) -> SmileParameters:
        """Fit SABR model to a single smile"""
        
        # SABR implied volatility approximation (Hagan et al.)
        def sabr_iv(K, F, T, alpha, beta, rho, nu):
            if K == F:
                # ATM formula
                return alpha * (1 + (2 - 3 * rho ** 2) * nu ** 2 * T / 24) / (F ** (1 - beta))
            
            z = nu / alpha * (F * K) ** ((1 - beta) / 2) * np.log(F / K)
            x = np.log((np.sqrt(1 - 2 * rho * z + z ** 2) + z - rho) / (1 - rho))
            
            A = alpha / ((F * K) ** ((1 - beta) / 2) *)
                        (1 + (1 - beta) ** 2 / 24 * np.log(F / K) ** 2 +)
                         (1 - beta) ** 4 / 1920 * np.log(F / K) ** 4))
            
            B = 1 + ((1 - beta) ** 2 / 24 * alpha ** 2 / (F * K) ** (1 - beta) +)
                    1 / 4 * rho * beta * nu * alpha / (F * K) ** ((1 - beta) / 2) +
                    (2 - 3 * rho ** 2) / 24 * nu ** 2) * T
            
            return A * z / x * B
        
        # Objective function
        def objective(params):
            alpha, beta, rho, nu = params
            
            # Parameter constraints
            if alpha <= 0 or beta < 0 or beta > 1 or abs(rho) > 1 or nu <= 0:
                return 1e10
            
            errors = 0
            for K, market_iv in zip(strikes, ivs):
                try:
                    model_iv = sabr_iv(K, forward, expiry, alpha, beta, rho, nu)
                    errors += (model_iv - market_iv) ** 2
                except:
                    return 1e10
            
            return errors
        
        # Initial guess
        atm_idx = np.argmin(np.abs(strikes - forward))
        atm_vol = ivs[atm_idx]
        
        x0 = [atm_vol, 0.5, 0.0, 0.3]
        
        # Optimize
        result = minimize()
            objective,
            x0,
            method='L-BFGS-B',
            bounds=[]
                (0.001, 1.0),    # alpha
                (0.0, 1.0),      # beta
                (-0.999, 0.999), # rho
                (0.001, 2.0)     # nu
            ]
        )
        
        alpha, beta, rho, nu = result.x
        
        smile = SmileParameters()
            expiry=expiry,
            forward=forward,
            atm_vol=atm_vol,
            sabr_alpha=alpha,
            sabr_beta=beta,
            sabr_rho=rho,
            sabr_nu=nu,
            rmse=np.sqrt(result.fun / len(strikes))
        )
        
        return smile
    
    def _evaluate_sabr(self, strike: float, expiry: float, surface: VolatilitySurface) -> float:
        """Evaluate SABR model at given strike and expiry"""
        
        # Find closest calibrated expiry
        calibrated_expiries = [exp for (und, exp) in self.smile_params.keys()]
                              if und == surface.underlying]
        
        if not calibrated_expiries:
            return 0.2
        
        closest_expiry = min(calibrated_expiries, key=lambda x: abs(x - expiry))
        smile = self.smile_params[(surface.underlying, closest_expiry)]
        
        forward = surface.forward_prices.get(expiry, surface.spot_price)
        
        # SABR formula
        alpha = smile.sabr_alpha
        beta = smile.sabr_beta
        rho = smile.sabr_rho
        nu = smile.sabr_nu
        
        if strike == forward:
            return alpha * (1 + (2 - 3 * rho ** 2) * nu ** 2 * expiry / 24) / (forward ** (1 - beta))
        
        z = nu / alpha * (forward * strike) ** ((1 - beta) / 2) * np.log(forward / strike)
        x = np.log((np.sqrt(1 - 2 * rho * z + z ** 2) + z - rho) / (1 - rho))
        
        A = alpha / ((forward * strike) ** ((1 - beta) / 2) *)
                    (1 + (1 - beta) ** 2 / 24 * np.log(forward / strike) ** 2 +)
                     (1 - beta) ** 4 / 1920 * np.log(forward / strike) ** 4))
        
        B = 1 + ((1 - beta) ** 2 / 24 * alpha ** 2 / (forward * strike) ** (1 - beta) +)
                1 / 4 * rho * beta * nu * alpha / (forward * strike) ** ((1 - beta) / 2) +
                (2 - 3 * rho ** 2) / 24 * nu ** 2) * expiry
        
        return A * z / x * B
    
    async def _fit_spline_surface(self, surface: VolatilitySurface):
        """Fit spline interpolation to surface"""
        
        # Create 2D spline interpolation
        from scipy.interpolate import bisplrep, bisplev
        
        # Create mesh
        unique_strikes = np.unique(surface.strikes)
        unique_expiries = np.unique(surface.expiries)
        
        # Create grid
        strike_grid, expiry_grid = np.meshgrid(unique_strikes, unique_expiries)
        iv_grid = np.zeros_like(strike_grid)
        
        # Fill grid with IVs
        for i, expiry in enumerate(unique_expiries):
            for j, strike in enumerate(unique_strikes):
                mask = (surface.expiries == expiry) & (surface.strikes == strike)
                if mask.any():
                    iv_grid[i, j] = surface.implied_vols[mask][0]
                else:
                    # Interpolate
                    expiry_mask = surface.expiries == expiry
                    if expiry_mask.any():
                        expiry_strikes = surface.strikes[expiry_mask]
                        expiry_ivs = surface.implied_vols[expiry_mask]
                        if len(expiry_strikes) >= 2:
                            interp = interp1d(expiry_strikes, expiry_ivs, 
                                            kind='linear', fill_value='extrapolate')
                            iv_grid[i, j] = interp(strike)
                        else:
                            iv_grid[i, j] = 0.2  # Default
                    else:
                        iv_grid[i, j] = 0.2
        
        # Fit spline
        tck = bisplrep(strike_grid.ravel(), expiry_grid.ravel(), 
                      iv_grid.ravel(), s=0.01)
        
        surface.model_params['spline_tck'] = tck
        
        # Calculate error
        errors = []
        for strike, expiry, actual_iv in zip(surface.strikes, surface.expiries, surface.implied_vols):
            fitted_iv = bisplev(strike, expiry, tck)
            errors.append((fitted_iv - actual_iv) ** 2)
        
        surface.calibration_error = np.sqrt(np.mean(errors))
    
    async def _fit_polynomial_surface(self, surface: VolatilitySurface):
        """Fit polynomial model to surface"""
        
        # Fit polynomial for each expiry
        unique_expiries = np.unique(surface.expiries)
        
        for expiry in unique_expiries:
            mask = surface.expiries == expiry
            strikes = surface.strikes[mask]
            ivs = surface.implied_vols[mask]
            
            forward = surface.forward_prices.get(expiry, surface.spot_price)
            
            # Convert to moneyness
            moneyness = strikes / forward
            
            # Fit polynomial (degree 3)
            coeffs = np.polyfit(moneyness, ivs, deg=3)
            
            smile = SmileParameters()
                expiry=expiry,
                forward=forward,
                atm_vol=np.polyval(coeffs, 1.0),
                poly_coeffs=coeffs.tolist()
            )
            
            self.smile_params[(surface.underlying, expiry)] = smile
        
        # Calculate error
        errors = []
        for strike, expiry, actual_iv in zip(surface.strikes, surface.expiries, surface.implied_vols):
            fitted_iv = self._evaluate_polynomial(strike, expiry, surface)
            errors.append((fitted_iv - actual_iv) ** 2)
        
        surface.calibration_error = np.sqrt(np.mean(errors))
    
    def _evaluate_polynomial(self, strike: float, expiry: float, surface: VolatilitySurface) -> float:
        """Evaluate polynomial model"""
        
        calibrated_expiries = [exp for (und, exp) in self.smile_params.keys()]
                              if und == surface.underlying]
        
        if not calibrated_expiries:
            return 0.2
        
        closest_expiry = min(calibrated_expiries, key=lambda x: abs(x - expiry))
        smile = self.smile_params[(surface.underlying, closest_expiry)]
        
        forward = surface.forward_prices.get(expiry, surface.spot_price)
        moneyness = strike / forward
        
        return np.polyval(smile.poly_coeffs, moneyness)
    
    def _calculate_forwards(self, option_chain: pd.DataFrame, spot: float) -> Dict[float, float]:
        """Calculate forward prices from put-call parity"""
        
        forwards = {}
        
        # Group by expiry
        for expiry, group in option_chain.groupby('expiry'):
            # Find matching calls and puts
            calls = group[group['option_type'] == 'call']
            puts = group[group['option_type'] == 'put']
            
            # Find pairs at same strike
            for strike in group['strike'].unique():
                call_data = calls[calls['strike'] == strike]
                put_data = puts[puts['strike'] == strike]
                
                if not call_data.empty and not put_data.empty:
                    # Put-call parity: C - P = S - K*exp(-rT)
                    call_price = (call_data['bid'].iloc[0] + call_data['ask'].iloc[0]) / 2
                    put_price = (put_data['bid'].iloc[0] + put_data['ask'].iloc[0]) / 2
                    
                    tte = (expiry - datetime.now()).days / 365.25
                    discount = np.exp(-0.05 * tte)  # Assume 5% risk-free rate
                    
                    implied_forward = strike * discount + call_price - put_price
                    
                    if expiry not in forwards:
                        forwards[tte] = implied_forward
                    else:
                        # Average multiple estimates
                        forwards[tte] = (forwards[tte] + implied_forward) / 2
        
        # Fill missing forwards with spot * exp(rT)
        unique_expiries = option_chain['expiry'].unique()
        for expiry in unique_expiries:
            tte = (expiry - datetime.now()).days / 365.25
            if tte not in forwards:
                forwards[tte] = spot * np.exp(0.05 * tte)
        
        return forwards
    
    def _calculate_discount_factors(self, expiries: np.ndarray) -> Dict[float, float]:
        """Calculate discount factors for each expiry"""
        
        discount_factors = {}
        unique_expiries = np.unique(expiries)
        
        for expiry in unique_expiries:
            discount_factors[expiry] = np.exp(-0.05 * expiry)  # 5% risk-free rate
        
        return discount_factors
    
    async def _calculate_surface_metrics(self, surface: VolatilitySurface):
        """Calculate various surface metrics"""
        
        # ATM volatility term structure
        for expiry in np.unique(surface.expiries):
            mask = surface.expiries == expiry
            expiry_strikes = surface.strikes[mask]
            expiry_ivs = surface.implied_vols[mask]
            
            # Find ATM
            forward = surface.forward_prices.get(expiry, surface.spot_price)
            atm_idx = np.argmin(np.abs(expiry_strikes - forward))
            
            surface.term_structure[expiry] = expiry_ivs[atm_idx]
        
        # Calculate skew metrics
        await self._calculate_skew_metrics(surface)
        
        # Overall ATM vol (shortest expiry)
        shortest_expiry = min(surface.term_structure.keys())
        surface.atm_vol = surface.term_structure[shortest_expiry]
    
    async def _calculate_skew_metrics(self, surface: VolatilitySurface):
        """Calculate various skew metrics"""
        
        # Focus on front month
        unique_expiries = np.unique(surface.expiries)
        if len(unique_expiries) == 0:
            return
        
        front_expiry = min(unique_expiries)
        mask = surface.expiries == front_expiry
        
        strikes = surface.strikes[mask]
        ivs = surface.implied_vols[mask]
        
        forward = surface.forward_prices.get(front_expiry, surface.spot_price)
        
        # 25-delta risk reversal
        delta_25_put_strike = forward * np.exp(-norm.ppf(0.25) * surface.atm_vol * np.sqrt(front_expiry))
        delta_25_call_strike = forward * np.exp(norm.ppf(0.75) * surface.atm_vol * np.sqrt(front_expiry))
        
        # Interpolate IVs
        iv_interp = interp1d(strikes, ivs, kind='cubic', fill_value='extrapolate')
        
        try:
            iv_25_put = iv_interp(delta_25_put_strike)
            iv_25_call = iv_interp(delta_25_call_strike)
            surface.skew_metrics[SkewMetric.RISK_REVERSAL.value] = iv_25_put - iv_25_call
        except:
            surface.skew_metrics[SkewMetric.RISK_REVERSAL.value] = 0
        
        # Skew slope at ATM
        if len(strikes) >= 3:
            # Numerical derivative
            h = 0.01 * forward
            try:
                iv_plus = iv_interp(forward + h)
                iv_minus = iv_interp(forward - h)
                surface.skew_metrics[SkewMetric.SKEW_SLOPE.value] = (iv_plus - iv_minus) / (2 * h)
            except:
                surface.skew_metrics[SkewMetric.SKEW_SLOPE.value] = 0
        
        # Put/Call IV ratio
        put_ivs = ivs[strikes < forward]
        call_ivs = ivs[strikes > forward]
        
        if len(put_ivs) > 0 and len(call_ivs) > 0:
            surface.skew_metrics[SkewMetric.PUT_CALL_RATIO.value] = np.mean(put_ivs) / np.mean(call_ivs)
        else:
            surface.skew_metrics[SkewMetric.PUT_CALL_RATIO.value] = 1.0
    
    async def _check_arbitrage_conditions(self, surface: VolatilitySurface) -> bool:
        """Check for arbitrage violations in the surface"""
        
        arbitrage_free = True
        
        # Check calendar arbitrage
        unique_strikes = np.unique(surface.strikes)
        
        for strike in unique_strikes:
            strike_mask = surface.strikes == strike
            strike_expiries = surface.expiries[strike_mask]
            strike_ivs = surface.implied_vols[strike_mask]
            
            # Sort by expiry
            sort_idx = np.argsort(strike_expiries)
            sorted_expiries = strike_expiries[sort_idx]
            sorted_ivs = strike_ivs[sort_idx]
            
            # Check if total variance is increasing
            total_variances = sorted_ivs ** 2 * sorted_expiries
            
            for i in range(1, len(total_variances)):
                if total_variances[i] < total_variances[i-1]:
                    surface.calendar_arbitrage.append((sorted_expiries[i-1], sorted_expiries[i]))
                    arbitrage_free = False
        
        # Check butterfly arbitrage
        unique_expiries = np.unique(surface.expiries)
        
        for expiry in unique_expiries:
            expiry_mask = surface.expiries == expiry
            expiry_strikes = surface.strikes[expiry_mask]
            expiry_ivs = surface.implied_vols[expiry_mask]
            
            # Sort by strike
            sort_idx = np.argsort(expiry_strikes)
            sorted_strikes = expiry_strikes[sort_idx]
            sorted_ivs = expiry_ivs[sort_idx]
            
            # Check convexity
            for i in range(1, len(sorted_strikes) - 1):
                k1, k2, k3 = sorted_strikes[i-1:i+2]
                iv1, iv2, iv3 = sorted_ivs[i-1:i+2]
                
                # Linear interpolation
                lambda_weight = (k2 - k1) / (k3 - k1)
                iv_linear = (1 - lambda_weight) * iv1 + lambda_weight * iv3
                
                if iv2 > iv_linear:
                    surface.butterfly_arbitrage.append((k1, k2, k3))
                    arbitrage_free = False
        
        return arbitrage_free
    
    @retry("analyze_skew", 'calculation', ErrorSeverity.MEDIUM)
    async def analyze_skew_trading_signals(self,
                                         underlying: str,
                                         lookback_days: int = 30) -> List[SkewTradingSignal]:
        """Analyze skew for trading opportunities"""
        
        if underlying not in self.surfaces:
            logger.warning(f"No surface found for {underlying}")
            return []
        
        current_surface = self.surfaces[underlying]
        signals = []
        
        # Get historical skew data
        historical_surfaces = self.historical_surfaces.get(underlying, [])
        if len(historical_surfaces) < lookback_days:
            logger.info(f"Insufficient history for {underlying}")
            return []
        
        # Extract skew metrics history
        skew_history = []
        for surface in historical_surfaces[-lookback_days:]:
            if SkewMetric.RISK_REVERSAL.value in surface.skew_metrics:
                skew_history.append({)
                    'date': surface.as_of_date,
                    'risk_reversal': surface.skew_metrics[SkewMetric.RISK_REVERSAL.value],
                    'skew_slope': surface.skew_metrics.get(SkewMetric.SKEW_SLOPE.value, 0),
                    'put_call_ratio': surface.skew_metrics.get(SkewMetric.PUT_CALL_RATIO.value, 1)
                })
        
        if not skew_history:
            return []
        
        skew_df = pd.DataFrame(skew_history)
        
        # Calculate statistics
        current_rr = current_surface.skew_metrics.get(SkewMetric.RISK_REVERSAL.value, 0)
        mean_rr = skew_df['risk_reversal'].mean()
        std_rr = skew_df['risk_reversal'].std()
        
        if std_rr > 0:
            z_score = (current_rr - mean_rr) / std_rr
            percentile = stats.percentileofscore(skew_df['risk_reversal'], current_rr)
            
            # Check for extreme skew
            if abs(z_score) > self.skew_zscore_threshold:
                signal_type = 'skew_extreme_high' if z_score > 0 else 'skew_extreme_low'
                
                # Generate trade recommendations
                trades = await self._generate_skew_trades(underlying, current_surface, signal_type)
                
                if trades:
                    signal = SkewTradingSignal()
                        signal_id=f"SKEW_{underlying}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                        timestamp=datetime.now(),
                        underlying=underlying,
                        signal_type=signal_type,
                        strength=min(abs(z_score) / 3, 1.0),  # Normalize to [-1, 1]
                        confidence=min(0.5 + abs(z_score) * 0.1, 0.9),
                        current_skew=current_rr,
                        historical_mean=mean_rr,
                        z_score=z_score,
                        percentile=percentile,
                        recommended_trades=trades,
                        expected_edge=self._calculate_expected_edge(trades),
                        risk_reward_ratio=self._calculate_risk_reward(trades),
                        holding_period_days=5
                    )
                    
                    signals.append(signal)
        
        return signals
    
    async def _generate_skew_trades(self, 
                                  underlying: str,
                                  surface: VolatilitySurface,
                                  signal_type: str) -> List[Dict[str, Any]]:
        """Generate specific trades based on skew signal"""
        
        trades = []
        
        # Get front month expiry
        unique_expiries = np.unique(surface.expiries)
        if len(unique_expiries) == 0:
            return trades
        
        front_expiry = min(unique_expiries)
        forward = surface.forward_prices.get(front_expiry, surface.spot_price)
        
        if signal_type == 'skew_extreme_high':
            # High skew = puts expensive relative to calls
            # Trade: Sell put spread, buy call spread
            
            # Put spread (sell)
            put_short_strike = forward * 0.95  # 5% OTM
            put_long_strike = forward * 0.90   # 10% OTM
            
            trades.append({)
                'action': 'sell',
                'instrument': 'put_spread',
                'strikes': [put_short_strike, put_long_strike],
                'expiry': front_expiry,
                'quantity': 10,
                'expected_premium': self._estimate_spread_price()
                    surface, put_short_strike, put_long_strike, front_expiry, 'put'
                )
            })
            
            # Call spread (buy)
            call_long_strike = forward * 1.05   # 5% OTM
            call_short_strike = forward * 1.10  # 10% OTM
            
            trades.append({)
                'action': 'buy',
                'instrument': 'call_spread',
                'strikes': [call_long_strike, call_short_strike],
                'expiry': front_expiry,
                'quantity': 10,
                'expected_cost': self._estimate_spread_price()
                    surface, call_long_strike, call_short_strike, front_expiry, 'call'
                )
            })
        
        elif signal_type == 'skew_extreme_low':
            # Low skew = calls expensive relative to puts
            # Trade: Buy put spread, sell call spread
            
            # Put spread (buy)
            put_long_strike = forward * 0.95
            put_short_strike = forward * 0.90
            
            trades.append({)
                'action': 'buy',
                'instrument': 'put_spread',
                'strikes': [put_long_strike, put_short_strike],
                'expiry': front_expiry,
                'quantity': 10,
                'expected_cost': self._estimate_spread_price()
                    surface, put_long_strike, put_short_strike, front_expiry, 'put'
                )
            })
            
            # Call spread (sell)
            call_short_strike = forward * 1.05
            call_long_strike = forward * 1.10
            
            trades.append({)
                'action': 'sell',
                'instrument': 'call_spread',
                'strikes': [call_short_strike, call_long_strike],
                'expiry': front_expiry,
                'quantity': 10,
                'expected_premium': self._estimate_spread_price()
                    surface, call_short_strike, call_long_strike, front_expiry, 'call'
                )
            })
        
        return trades
    
    def _estimate_spread_price(self,
                             surface: VolatilitySurface,
                             strike1: float,
                             strike2: float,
                             expiry: float,
                             option_type: str) -> float:
        """Estimate spread price using Black-Scholes"""
        
        # Get IVs
        if surface.model_type == VolatilityModelType.SVI:
            iv1 = self._evaluate_svi(strike1, expiry, surface)
            iv2 = self._evaluate_svi(strike2, expiry, surface)
        elif surface.model_type == VolatilityModelType.SABR:
            iv1 = self._evaluate_sabr(strike1, expiry, surface)
            iv2 = self._evaluate_sabr(strike2, expiry, surface)
        else:
            iv1 = iv2 = 0.2
        
        # Calculate option prices
        spot = surface.spot_price
        r = surface.risk_free_rate
        
        if option_type == 'call':
            price1 = self._black_scholes(spot, strike1, r, iv1, expiry, 'call')
            price2 = self._black_scholes(spot, strike2, r, iv2, expiry, 'call')
        else:
            price1 = self._black_scholes(spot, strike1, r, iv1, expiry, 'put')
            price2 = self._black_scholes(spot, strike2, r, iv2, expiry, 'put')
        
        return abs(price1 - price2)
    
    def _black_scholes(self, S: float, K: float, r: float, sigma: float, T: float, option_type: str) -> float:
        """Black-Scholes option pricing"""
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        if option_type == 'call':
            return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        else:
            return K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
    
    def _calculate_expected_edge(self, trades: List[Dict[str, Any]]) -> float:
        """Calculate expected edge from trades"""
        
        total_edge = 0
        
        for trade in trades:
            if trade['action'] == 'sell':
                total_edge += trade.get('expected_premium', 0)
            else:
                total_edge -= trade.get('expected_cost', 0)
        
        return total_edge
    
    def _calculate_risk_reward(self, trades: List[Dict[str, Any]]) -> float:
        """Calculate risk/reward ratio"""
        
        max_profit = 0
        max_loss = 0
        
        for trade in trades:
            if trade['instrument'].endswith('spread'):
                spread_width = abs(trade['strikes'][1] - trade['strikes'][0])
                quantity = trade['quantity']
                
                if trade['action'] == 'sell':
                    max_profit += trade.get('expected_premium', 0) * quantity
                    max_loss += (spread_width - trade.get('expected_premium', 0)) * quantity
                else:
                    max_profit += (spread_width - trade.get('expected_cost', 0)) * quantity
                    max_loss += trade.get('expected_cost', 0) * quantity
        
        return max_profit / max_loss if max_loss > 0 else float('inf')
    
    @retry("detect_regime", 'calculation', ErrorSeverity.MEDIUM)
    async def detect_volatility_regime(self, underlying: str) -> Optional[str]:
        """Detect current volatility regime"""
        
        if underlying not in self.surfaces:
            return None
        
        current_surface = self.surfaces[underlying]
        
        # Extract regime features
        atm_vol = current_surface.atm_vol
        skew = current_surface.skew_metrics.get(SkewMetric.RISK_REVERSAL.value, 0)
        term_structure_slope = self._calculate_term_structure_slope(current_surface)
        
        # Simple regime classification
        if atm_vol < 0.15:
            if abs(skew) < 0.02:
                regime = 'low_vol_balanced'
            else:
                regime = 'low_vol_skewed'
        elif atm_vol < 0.30:
            if abs(skew) < 0.05:
                regime = 'normal_vol_balanced'
            else:
                regime = 'normal_vol_skewed'
        else:
            if term_structure_slope > 0:
                regime = 'high_vol_backwardation'
            else:
                regime = 'high_vol_contango'
        
        self.current_regime = regime
        
        # Emit metric
        self.metrics_collector.record('volatility_regime.detected', 1, {)
            'underlying': underlying,
            'regime': regime,
            'atm_vol': atm_vol
        })
        
        return regime
    
    def _calculate_term_structure_slope(self, surface: VolatilitySurface) -> float:
        """Calculate slope of ATM volatility term structure"""
        
        if len(surface.term_structure) < 2:
            return 0
        
        # Sort by expiry
        sorted_terms = sorted(surface.term_structure.items())
        
        # Simple linear regression
        expiries = np.array([t[0] for t in sorted_terms])
        vols = np.array([t[1] for t in sorted_terms])
        
        # Calculate slope
        if len(expiries) >= 2:
            slope, _ = np.polyfit(expiries, vols, 1)
            return slope
        
        return 0
    
    def get_surface_summary(self, underlying: str) -> Dict[str, Any]:
        """Get summary of current volatility surface"""
        
        if underlying not in self.surfaces:
            return {}
        
        surface = self.surfaces[underlying]
        
        return {}
            'underlying': underlying,
            'as_of_date': surface.as_of_date.isoformat(),
            'spot_price': surface.spot_price,
            'atm_vol': surface.atm_vol,
            'model_type': surface.model_type.value,
            'calibration_error': surface.calibration_error,
            'arbitrage_free': surface.arbitrage_free,
            'skew_metrics': surface.skew_metrics,
            'term_structure': {str(k): v for k, v in surface.term_structure.items()},
            'current_regime': self.current_regime
        }
    
    def interpolate_volatility(self,
                             underlying: str,
                             strike: float,
                             expiry: float) -> Optional[float]:
        """Interpolate volatility for any strike/expiry"""
        
        if underlying not in self.surfaces:
            return None
        
        surface = self.surfaces[underlying]
        
        if surface.model_type == VolatilityModelType.SVI:
            return self._evaluate_svi(strike, expiry, surface)
        elif surface.model_type == VolatilityModelType.SABR:
            return self._evaluate_sabr(strike, expiry, surface)
        elif surface.model_type == VolatilityModelType.POLYNOMIAL:
            return self._evaluate_polynomial(strike, expiry, surface)
        elif surface.model_type == VolatilityModelType.SPLINE:
            # Use spline interpolation
            from scipy.interpolate import bisplev
            tck = surface.model_params.get('spline_tck')
            if tck:
                return bisplev(strike, expiry, tck)
        
        return None


# Integration function
def integrate_volatility_modeling(master_system):
    """
    Integrate volatility smile/skew modeling with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from volatility_smile_skew_modeling import integrate_volatility_modeling
    integrate_volatility_modeling(self)
    """
    
    # Create volatility modeling system
    master_system.vol_model = VolatilitySmileSkewModeling()
        default_model=VolatilityModelType.SVI,
        calibration_method=CalibrationMethod.WEIGHTED_LEAST_SQUARES
    )
    
    # Add methods
    async def fit_volatility_surface(self, option_chain: pd.DataFrame,
                                   underlying: str, spot_price: float) -> Dict[str, Any]:
        """Fit volatility surface to option chain"""
        surface = await self.vol_model.fit_volatility_surface()
            option_chain, underlying, spot_price
        )
        return self.vol_model.get_surface_summary(underlying)
    
    async def get_skew_signals(self, underlying: str) -> List[Dict[str, Any]]:
        """Get skew-based trading signals"""
        signals = await self.vol_model.analyze_skew_trading_signals(underlying)
        
        return [{]
            'signal_id': s.signal_id,
            'signal_type': s.signal_type,
            'strength': s.strength,
            'confidence': s.confidence,
            'z_score': s.z_score,
            'trades': s.recommended_trades,
            'expected_edge': s.expected_edge
        } for s in signals]
    
    def get_implied_volatility(self, underlying: str, strike: float, expiry: float) -> float:
        """Get interpolated implied volatility"""
        return self.vol_model.interpolate_volatility(underlying, strike, expiry) or 0.2
    
    async def detect_vol_regime(self, underlying: str) -> str:
        """Detect current volatility regime"""
        return await self.vol_model.detect_volatility_regime(underlying) or 'unknown'
    
    # Bind methods
    master_system.fit_volatility_surface = fit_volatility_surface.__get__(master_system)
    master_system.get_skew_signals = get_skew_signals.__get__(master_system)
    master_system.get_implied_volatility = get_implied_volatility.__get__(master_system)
    master_system.detect_vol_regime = detect_vol_regime.__get__(master_system)
    
    logger.info("Volatility smile/skew modeling integrated with master system")


if __name__ == "__main__":
    # Test volatility modeling
    import asyncio
    
    async def test_volatility_modeling():
        # Create modeling system
        vol_model = VolatilitySmileSkewModeling()
        
        # Create sample option chain
        np.random.seed(42)
        
        spot = 100
        expiries = [7, 14, 30, 60, 90]  # Days to expiry
        strikes = np.linspace(80, 120, 21)  # 80 to 120 in steps
        
        option_data = []
        
        for expiry_days in expiries:
            expiry_date = datetime.now() + timedelta(days=expiry_days)
            tte = expiry_days / 365.25
            
            for strike in strikes:
                # Generate realistic IV with smile
                moneyness = np.log(strike / spot)
                base_iv = 0.20 + 0.05 * tte  # Term structure
                
                # Add smile effect
                smile = 0.1 * moneyness ** 2 - 0.05 * moneyness
                iv = base_iv + smile + np.random.normal(0, 0.01)
                
                # Create call and put
                for option_type in ['call', 'put']:
                    option_data.append({)
                        'symbol': f"TEST_{strike}_{expiry_days}{option_type[0].upper()}",
                        'underlying': 'TEST',
                        'strike': strike,
                        'expiry': expiry_date,
                        'option_type': option_type,
                        'bid': 1.0,  # Simplified
                        'ask': 1.1,
                        'volume': 100,
                        'implied_volatility': max(iv, 0.05),
                        'bid_iv': max(iv - 0.005, 0.05),
                        'ask_iv': max(iv + 0.005, 0.05)
                    })
        
        option_chain = pd.DataFrame(option_data)
        
        print("Volatility Smile/Skew Modeling Test")
        print("=" * 60)
        
        # Fit surface
        print("\nFitting volatility surface...")
        surface = await vol_model.fit_volatility_surface()
            option_chain,
            underlying='TEST',
            spot_price=spot
        )
        
        print(f"\nSurface fitted with {surface.model_type.value} model")
        print(f"Calibration error: {surface.calibration_error:.4f}")
        print(f"Calibration time: {surface.calibration_time:.2f}s")
        print(f"Arbitrage free: {surface.arbitrage_free}")
        
        # Show term structure
        print("\n\nATM Volatility Term Structure:")
        print("-" * 40)
        for expiry, vol in sorted(surface.term_structure.items()):
            print(f"T = {expiry:.3f}: {vol:.1%}")
        
        # Show skew metrics
        print("\n\nSkew Metrics:")
        print("-" * 40)
        for metric, value in surface.skew_metrics.items():
            print(f"{metric}: {value:.4f}")
        
        # Test interpolation
        print("\n\nVolatility Interpolation Test:")
        print("-" * 40)
        
        test_strikes = [90, 95, 100, 105, 110]
        test_expiry = 30 / 365.25
        
        print(f"Expiry: {test_expiry:.3f} years")
        for strike in test_strikes:
            iv = vol_model.interpolate_volatility('TEST', strike, test_expiry)
            print(f"Strike {strike}: IV = {iv:.1%}")
        
        # Generate multiple surfaces for history
        print("\n\nGenerating historical surfaces...")
        
        for i in range(30):
            # Shift spot price
            new_spot = spot * (1 + np.random.normal(0, 0.01))
            
            # Regenerate option chain with some variation
            shifted_chain = option_chain.copy()
            shifted_chain['implied_volatility'] *= (1 + np.random.normal(0, 0.02))
            shifted_chain['bid_iv'] = shifted_chain['implied_volatility'] - 0.005
            shifted_chain['ask_iv'] = shifted_chain['implied_volatility'] + 0.005
            
            await vol_model.fit_volatility_surface()
                shifted_chain,
                underlying='TEST',
                spot_price=new_spot,
                as_of_date=datetime.now() - timedelta(days=30-i)
            )
        
        # Analyze skew signals
        print("\n\nAnalyzing skew trading signals...")
        signals = await vol_model.analyze_skew_trading_signals('TEST')
        
        print(f"\nFound {len(signals)} trading signals")
        
        for signal in signals:
            print(f"\n{signal.signal_type}:")
            print(f"  Strength: {signal.strength:.2f}")
            print(f"  Confidence: {signal.confidence:.2%}")
            print(f"  Z-score: {signal.z_score:.2f}")
            print(f"  Current skew: {signal.current_skew:.4f}")
            print(f"  Historical mean: {signal.historical_mean:.4f}")
            print(f"  Expected edge: ${signal.expected_edge:.2f}")
            print(f"  Risk/Reward: {signal.risk_reward_ratio:.2f}")
            
            print(f"  Recommended trades:")
            for trade in signal.recommended_trades:
                print(f"    - {trade['action']} {trade['instrument']} @ {trade['strikes']}")
        
        # Detect regime
        print("\n\nDetecting volatility regime...")
        regime = await vol_model.detect_volatility_regime('TEST')
        print(f"Current regime: {regime}")
        
        # Get surface summary
        summary = vol_model.get_surface_summary('TEST')
        print("\n\nSurface Summary:")
        print(json.dumps(summary, indent=2, default=str))
        
        print("\n\nVolatility modeling test completed!")
    
    # Run test
    asyncio.run(test_volatility_modeling())