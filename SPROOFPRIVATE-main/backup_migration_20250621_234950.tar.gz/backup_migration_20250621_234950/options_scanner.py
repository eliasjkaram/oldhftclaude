
#!/usr/bin/env python3
# TODO: Consider using UnifiedDataAPI from data_api_fixer.py for robust data fetching
"""
Options Scanner
Scans for profitable options trading opportunities
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
import sqlite3
import json
import sys
import os
from typing import Dict, List, Tuple, Optional

sys.path.append('/home/harry/alpaca-mcp')

from robust_data_fetcher import RobustDataFetcher
from cross_platform_validator import CrossPlatformValidator

logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/options_scanner.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class OptionsScanner:
    """Scans for options trading opportunities"""
    
    def __init__(self):
        self.data_fetcher = RobustDataFetcher({})
        self.validator = CrossPlatformValidator()
        
        # Options symbols to scan
        self.symbols = []
            'SPY', 'QQQ', 'AAPL', 'MSFT', 'NVDA', 'TSLA', 'AMD', 
            'META', 'GOOGL', 'AMZN', 'JPM', 'BAC', 'XLF', 'XLE', 
            'GLD', 'SLV', 'IWM', 'VXX', 'TLT', 'ARKK'
        ]
        
        self.init_database()
        
    def init_database(self):
        """Initialize options database"""
        self.db = sqlite3.connect('/home/harry/alpaca-mcp/options_scanner.db')
        cursor = self.db.cursor()
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS options_opportunities ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                strategy TEXT,
                strike_prices TEXT,
                expiration DATE,
                premium_collected REAL,
                max_profit REAL,
                max_loss REAL,
                breakeven TEXT,
                probability_profit REAL,
                iv_rank REAL,
                expected_value REAL,
                validation_score REAL
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS options_flow ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                option_type TEXT,
                strike REAL,
                expiration DATE,
                volume INTEGER,
                open_interest INTEGER,
                bid_ask_spread REAL,
                implied_volatility REAL,
                delta REAL,
                gamma REAL,
                unusual_activity BOOLEAN
            )
        ''')
        
        self.db.commit()
        
    async def scan_cycle(self):
        """Run one options scanning cycle"""
        logger.info("Starting options scan...")
        
        opportunities = []
        
        for symbol in self.symbols:
            try:
                # Validate data first
                validation = await self.validator.validate_all(symbol)
                if not validation['overall_valid']:
                    logger.warning(f"Skipping {symbol} - validation failed")
                    continue
                    
                # Get options chain
                ticker = YFinanceWrapper().get_ticker(symbol)
                
                # Get available expiration dates
                expirations = ticker.options
                if not expirations:
                    continue
                    
                # Scan nearest 3 expirations
                for exp_date in expirations[:3]:
                    opt_chain = ticker.option_chain(exp_date)
                    
                    # Analyze options strategies
                    opportunities.extend()
                        await self.analyze_strategies(symbol, exp_date, opt_chain, validation)
                    )
                    
                    # Track unusual options activity
                    await self.track_options_flow(symbol, exp_date, opt_chain)
                    
            except Exception as e:
                logger.error(f"Error scanning {symbol}: {e}", exc_info=True)
                
        # Log opportunities
        for opp in sorted(opportunities, key=lambda x: x['expected_value'], reverse=True)[:10]:
            self.log_opportunity(opp)
            
        logger.info(f"Options scan complete: {len(opportunities)} opportunities found")
        
    async def analyze_strategies(self, symbol, expiration, opt_chain, validation):
        """Analyze various options strategies"""
        opportunities = []
        
        # Get current price
        current_price = validation['validations']['price']['mean']
        if current_price <= 0:
            return opportunities
            
        # Calculate IV rank
        iv_rank = self.calculate_iv_rank(opt_chain)
        
        # 1. Covered Call / Cash Secured Put (Wheel Strategy)
        wheel_opp = self.analyze_wheel_strategy(symbol, expiration, opt_chain, current_price, iv_rank)
        if wheel_opp:
            opportunities.append(wheel_opp)
            
        # 2. Iron Condor
        condor_opp = self.analyze_iron_condor(symbol, expiration, opt_chain, current_price, iv_rank)
        if condor_opp:
            opportunities.append(condor_opp)
            
        # 3. Vertical Spreads
        spread_opps = self.analyze_vertical_spreads(symbol, expiration, opt_chain, current_price, iv_rank)
        opportunities.extend(spread_opps)
        
        # 4. Straddle/Strangle
        if iv_rank > 50:  # High IV
            volatility_opp = self.analyze_volatility_plays(symbol, expiration, opt_chain, current_price, iv_rank)
            if volatility_opp:
                opportunities.append(volatility_opp)
                
        # Add validation score to all opportunities
        for opp in opportunities:
            opp['validation_score'] = validation['confidence_score']
            
        return opportunities
        
    def analyze_wheel_strategy(self, symbol, expiration, opt_chain, current_price, iv_rank):
        """Analyze wheel strategy (CSP/CC)"""
        try:
            # Find OTM put for CSP
            otm_puts = opt_chain.puts[opt_chain.puts['strike'] < current_price * 0.95]
            if otm_puts.empty:
                return None
                
            # Select put with delta around -0.3
            target_strike = current_price * 0.93
            put = otm_puts.iloc[(otm_puts['strike'] - target_strike).abs().argsort()[:1]]
            
            if put.empty:
                return None
                
            put_data = put.iloc[0]
            
            # Calculate metrics
            premium = put_data['bid']
            strike = put_data['strike']
            
            if premium <= 0:
                return None
                
            # Days to expiration
            exp_date = datetime.strptime(expiration, '%Y-%m-%d')
            dte = (exp_date - datetime.now()).days
            
            # Annualized return
            cost_basis = strike * 100  # 100 shares
            monthly_return = (premium * 100) / cost_basis
            annual_return = monthly_return * (365 / max(dte, 1))
            
            # Probability of profit (simplified)
            pop = 1 - abs(put_data.get('delta', 0.3))
            
            return {}
                'symbol': symbol,
                'strategy': 'wheel_csp',
                'strike_prices': [strike],
                'expiration': expiration,
                'premium_collected': premium * 100,
                'max_profit': premium * 100,
                'max_loss': (strike - premium) * 100,
                'breakeven': [strike - premium],
                'probability_profit': pop,
                'iv_rank': iv_rank,
                'expected_value': (premium * 100 * pop) - ((strike - current_price) * 100 * (1 - pop) if strike > current_price else 0),
                'annual_return_pct': annual_return * 100
            }
            
        except Exception as e:
            logger.error(f"Wheel analysis error: {e}", exc_info=True)
            return None
            
    def analyze_iron_condor(self, symbol, expiration, opt_chain, current_price, iv_rank):
        """Analyze iron condor strategy"""
        try:
            if iv_rank < 30:  # Need decent IV for condors
                return None
                
            # Find strikes
            put_short_strike = current_price * 0.90
            put_long_strike = current_price * 0.85
            call_short_strike = current_price * 1.10
            call_long_strike = current_price * 1.15
            
            # Get options
            puts = opt_chain.puts
            calls = opt_chain.calls
            
            # Find closest strikes
            put_short = self.find_closest_option(puts, put_short_strike)
            put_long = self.find_closest_option(puts, put_long_strike)
            call_short = self.find_closest_option(calls, call_short_strike)
            call_long = self.find_closest_option(calls, call_long_strike)
            
            if not all([put_short, put_long, call_short, call_long]):
                return None
                
            # Calculate credit
            credit = (put_short['bid'] - put_long['ask'] +)
                     call_short['bid'] - call_long['ask'])
                     
            if credit <= 0:
                return None
                
            # Max loss is width of strikes minus credit
            width = min(put_short_strike - put_long_strike, 
                       call_long_strike - call_short_strike)
            max_loss = (width - credit) * 100
            max_profit = credit * 100
            
            # Probability of profit (between short strikes)
            pop = 0.68  # Rough estimate for 1 SD iron condor
            
            return {}
                'symbol': symbol,
                'strategy': 'iron_condor',
                'strike_prices': [put_long_strike, put_short_strike, 
                                call_short_strike, call_long_strike],
                'expiration': expiration,
                'premium_collected': max_profit,
                'max_profit': max_profit,
                'max_loss': max_loss,
                'breakeven': [put_short_strike - credit, call_short_strike + credit],
                'probability_profit': pop,
                'iv_rank': iv_rank,
                'expected_value': (max_profit * pop) - (max_loss * (1 - pop) * 0.5)
            }
            
        except Exception as e:
            logger.error(f"Iron condor analysis error: {e}", exc_info=True)
            return None
            
    def analyze_vertical_spreads(self, symbol, expiration, opt_chain, current_price, iv_rank):
        """Analyze bull/bear spreads"""
        opportunities = []
        
        try:
            # Bull call spread
            call_long_strike = current_price * 1.02
            call_short_strike = current_price * 1.05
            
            calls = opt_chain.calls
            call_long = self.find_closest_option(calls, call_long_strike)
            call_short = self.find_closest_option(calls, call_short_strike)
            
            if call_long and call_short:
                debit = call_long['ask'] - call_short['bid']
                if debit > 0:
                    max_profit = (call_short_strike - call_long_strike - debit) * 100
                    max_loss = debit * 100
                    
                    if max_profit > 0:
                        opportunities.append({)
                            'symbol': symbol,
                            'strategy': 'bull_call_spread',
                            'strike_prices': [call_long_strike, call_short_strike],
                            'expiration': expiration,
                            'premium_collected': -max_loss,  # Debit
                            'max_profit': max_profit,
                            'max_loss': max_loss,
                            'breakeven': [call_long_strike + debit],
                            'probability_profit': 0.45,  # Rough estimate
                            'iv_rank': iv_rank,
                            'expected_value': (max_profit * 0.45) - (max_loss * 0.55)
                        })
                        
        except Exception as e:
            logger.error(f"Vertical spread analysis error: {e}", exc_info=True)
            
        return opportunities
        
    def analyze_volatility_plays(self, symbol, expiration, opt_chain, current_price, iv_rank):
        """Analyze straddle/strangle for high IV"""
        try:
            # ATM straddle
            atm_strike = self.find_closest_strike(opt_chain.calls, current_price)
            
            call = self.find_closest_option(opt_chain.calls, atm_strike)
            put = self.find_closest_option(opt_chain.puts, atm_strike)
            
            if not call or not put:
                return None
                
            # Short straddle (selling volatility)
            credit = call['bid'] + put['bid']
            
            if credit <= 0:
                return None
                
            # Calculate expected move
            expected_move = credit  # Simplified
            
            return {}
                'symbol': symbol,
                'strategy': 'short_straddle',
                'strike_prices': [atm_strike],
                'expiration': expiration,
                'premium_collected': credit * 100,
                'max_profit': credit * 100,
                'max_loss': -10000,  # Undefined
                'breakeven': [atm_strike - credit, atm_strike + credit],
                'probability_profit': 0.5,  # Rough estimate
                'iv_rank': iv_rank,
                'expected_value': credit * 100 * 0.3  # Conservative
            }
            
        except Exception as e:
            logger.error(f"Volatility play analysis error: {e}", exc_info=True)
            return None
            
    def find_closest_option(self, options_df, target_strike):
        """Find option closest to target strike"""
        try:
            if options_df.empty:
                return None
                
            idx = (options_df['strike'] - target_strike).abs().argsort()[:1]
            if len(idx) > 0:
                return options_df.iloc[idx[0]].to_dict()
            return None
        except Exception:
            return None
            
    def find_closest_strike(self, options_df, target_price):
        """Find strike closest to target price"""
        try:
            if options_df.empty:
                return target_price
                
            strikes = options_df['strike'].unique()
            idx = np.abs(strikes - target_price).argmin()
            return strikes[idx]
        except Exception:
            return target_price
            
    def calculate_iv_rank(self, opt_chain):
        """Calculate IV rank (simplified)"""
        try:
            # Get ATM implied volatilities
            calls_iv = opt_chain.calls['impliedVolatility'].dropna()
            puts_iv = opt_chain.puts['impliedVolatility'].dropna()
            
            if calls_iv.empty and puts_iv.empty:
                return 50  # Default
                
            current_iv = pd.concat([calls_iv, puts_iv]).mean()
            
            # Without historical data, estimate based on current levels
            # This is simplified - in production, use historical IV data
            if current_iv < 0.2:
                return 20
            elif current_iv < 0.3:
                return 40
            elif current_iv < 0.4:
                return 60
            elif current_iv < 0.5:
                return 80
            else:
                return 90
                
        except Exception:
            return 50
            
    async def track_options_flow(self, symbol, expiration, opt_chain):
        """Track unusual options activity"""
        try:
            # Combine calls and puts
            all_options = []
            
            for opt_type, df in [('call', opt_chain.calls), ('put', opt_chain.puts)]:
                for _, opt in df.iterrows():
                    volume = opt.get('volume', 0)
                    oi = opt.get('openInterest', 0)
                    
                    # Check for unusual activity
                    unusual = False
                    if oi > 0 and volume > oi * 2:  # Volume > 2x OI]
                        unusual = True
                    elif volume > 1000 and oi < 100:  # High volume, low OI
                        unusual = True
                        
                    if volume > 100 or unusual:  # Track significant activity
                        all_options.append({)
                            'symbol': symbol,
                            'option_type': opt_type,
                            'strike': opt['strike'],
                            'expiration': expiration,
                            'volume': volume,
                            'open_interest': oi,
                            'bid_ask_spread': opt['ask'] - opt['bid'] if opt['bid'] > 0 else None,
                            'implied_volatility': opt.get('impliedVolatility'),
                            'delta': opt.get('delta'),
                            'gamma': opt.get('gamma'),
                            'unusual_activity': unusual
                        })
                        
            # Log options flow
            for opt_data in all_options:
                self.log_options_flow(opt_data)
                
        except Exception as e:
            logger.error(f"Options flow tracking error: {e}", exc_info=True)
            
    def log_opportunity(self, opportunity):
        """Log opportunity to database"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO options_opportunities
            (symbol, strategy, strike_prices, expiration, premium_collected,
             max_profit, max_loss, breakeven, probability_profit, iv_rank,
             expected_value, validation_score)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', ()
            opportunity['symbol'],
            opportunity['strategy'],
            json.dumps(opportunity['strike_prices']),
            opportunity['expiration'],
            opportunity['premium_collected'],
            opportunity['max_profit'],
            opportunity['max_loss'],
            json.dumps(opportunity['breakeven']),
            opportunity['probability_profit'],
            opportunity['iv_rank'],
            opportunity['expected_value'],
            opportunity.get('validation_score', 1.0)
        ))
        self.db.commit()
        
    def log_options_flow(self, flow_data):
        """Log options flow to database"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO options_flow
            (symbol, option_type, strike, expiration, volume, open_interest,
             bid_ask_spread, implied_volatility, delta, gamma, unusual_activity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', ()
            flow_data['symbol'],
            flow_data['option_type'],
            flow_data['strike'],
            flow_data['expiration'],
            flow_data['volume'],
            flow_data['open_interest'],
            flow_data['bid_ask_spread'],
            flow_data['implied_volatility'],
            flow_data['delta'],
            flow_data['gamma'],
            flow_data['unusual_activity']
        ))
        self.db.commit()

async def main():
    """Main scanning loop"""
    scanner = OptionsScanner()
    
    while True:
        try:
            await scanner.scan_cycle()
            await asyncio.sleep(900)  # Run every 15 minutes
            
        except Exception as e:
            logger.error(f"Scanner error: {e}", exc_info=True)
            await asyncio.sleep(900)

if __name__ == "__main__":
    os.makedirs('/home/harry/alpaca-mcp/logs', exist_ok=True)
    asyncio.run(main())