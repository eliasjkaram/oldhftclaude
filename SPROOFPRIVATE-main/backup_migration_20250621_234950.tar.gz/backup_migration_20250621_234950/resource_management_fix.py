#!/usr/bin/env python3
"""
Resource Management Fix Implementation
====================================

Comprehensive resource management using the ResourceManager from PRODUCTION_FIXES.py
to fix unclosed connections and memory leaks across the entire codebase.
"""

import asyncio
import aiohttp
import sqlite3
import logging
import weakref
import atexit
from typing import Dict, List, Optional, Any, Set, AsyncContextManager, ContextManager
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timedelta
import threading
from queue import Queue, Empty
import psutil
import gc

# Import the ResourceManager from PRODUCTION_FIXES
try:
    from PRODUCTION_FIXES import ResourceManager as BaseResourceManager
except ImportError:
    # Fallback implementation if PRODUCTION_FIXES is not available
    class BaseResourceManager:
        def __init__(self):
            self._resources = []
            self._lock = threading.Lock()

# Enhanced Resource Manager with comprehensive tracking
class EnhancedResourceManager(BaseResourceManager):
    """Enhanced resource manager with automatic cleanup and leak detection"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        """Singleton pattern for global resource management"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, '_initialized'):
            super().__init__()
            self._initialized = True
            self._aiohttp_sessions: Set[aiohttp.ClientSession] = weakref.WeakSet()
            self._db_connections: Set[sqlite3.Connection] = weakref.WeakSet()
            self._connection_pools: Dict[str, 'ConnectionPool'] = {}
            self._tasks: Set[asyncio.Task] = weakref.WeakSet()
            self._cleanup_scheduled = False
            self.logger = logging.getLogger(__name__)
            
            # Register cleanup handlers
            atexit.register(self._emergency_cleanup)
            
            # Start monitoring
            self._start_monitoring()
    
    def _start_monitoring(self):
        """Start resource monitoring in background"""
        def monitor():
            asyncio.set_event_loop(asyncio.new_event_loop())
            loop = asyncio.get_event_loop()
            loop.run_until_complete(self._monitor_resources())
        
        monitor_thread = threading.Thread(target=monitor, daemon=True)
        monitor_thread.start()
    
    async def _monitor_resources(self):
        """Monitor resources and cleanup leaked ones"""
        while True:
            try:
                await asyncio.sleep(60)  # Check every minute
                await self._check_for_leaks()
            except Exception as e:
                self.logger.error(f"Resource monitoring error: {e}")
    
    async def _check_for_leaks(self):
        """Check for and cleanup leaked resources"""
        # Check aiohttp sessions
        leaked_sessions = []
        for session in list(self._aiohttp_sessions):
            if session.closed:
                continue
            # Check if session is still in use
            if hasattr(session, '_last_used'):
                if datetime.now() - session._last_used > timedelta(minutes=5):
                    leaked_sessions.append(session)
        
        # Cleanup leaked sessions
        for session in leaked_sessions:
            self.logger.warning(f"Cleaning up leaked aiohttp session: {session}")
            try:
                await session.close()
            except Exception:
                pass
        
        # Log resource status
        self.logger.info(f"Resource status - Sessions: {len(self._aiohttp_sessions)}, ")
                        f"DB Connections: {len(self._db_connections)}, "
                        f"Tasks: {len(self._tasks)}")
    
    @asynccontextmanager
    async def aiohttp_session(self, **kwargs) -> AsyncContextManager[aiohttp.ClientSession]:
        """Managed aiohttp session with automatic cleanup"""
        session = None
        try:
            # Create session with timeout defaults
            timeout = aiohttp.ClientTimeout()
                total=kwargs.pop('timeout', 30),
                connect=kwargs.pop('connect_timeout', 10),
                sock_read=kwargs.pop('read_timeout', 10)
            )
            
            # Create connector with connection pooling
            connector = aiohttp.TCPConnector()
                limit=kwargs.pop('limit', 100),
                limit_per_host=kwargs.pop('limit_per_host', 30),
                ttl_dns_cache=kwargs.pop('ttl_dns_cache', 300)
            )
            
            session = aiohttp.ClientSession()
                timeout=timeout,
                connector=connector,
                **kwargs
            )
            
            # Track session
            session._last_used = datetime.now()
            self._aiohttp_sessions.add(session)
            
            yield session
            
        finally:
            if session and not session.closed:
                await session.close()
                # Wait for connector to close
                await asyncio.sleep(0.1)
    
    @contextmanager
    def database_connection(self, db_path: str, **kwargs) -> ContextManager[sqlite3.Connection]:
        """Managed database connection with automatic cleanup"""
        conn = None
        try:
            # Get or create connection pool for this database
            pool = self.get_connection_pool(db_path)
            conn = pool.get_connection()
            yield conn
        finally:
            if conn:
                pool.return_connection(conn)
    
    def get_connection_pool(self, db_path: str) -> 'ConnectionPool':
        """Get or create connection pool for database"""
        if db_path not in self._connection_pools:
            with self._lock:
                if db_path not in self._connection_pools:
                    self._connection_pools[db_path] = ConnectionPool(db_path)
        return self._connection_pools[db_path]
    
    async def create_task(self, coro, name: Optional[str] = None) -> asyncio.Task:
        """Create and track async task"""
        task = asyncio.create_task(coro)
        if name:
            task.set_name(name)
        self._tasks.add(task)
        return task
    
    async def cleanup_all(self):
        """Clean up all managed resources"""
        self.logger.info("Starting comprehensive resource cleanup...")
        
        # Cancel all tasks
        tasks_to_cancel = list(self._tasks)
        for task in tasks_to_cancel:
            if not task.done():
                task.cancel()
        
        # Wait for tasks to complete
        if tasks_to_cancel:
            await asyncio.gather(*tasks_to_cancel, return_exceptions=True)
        
        # Close all aiohttp sessions
        sessions_to_close = list(self._aiohttp_sessions)
        close_tasks = []
        for session in sessions_to_close:
            if not session.closed:
                close_tasks.append(session.close())
        
        if close_tasks:
            await asyncio.gather(*close_tasks, return_exceptions=True)
        
        # Close all database connections
        with self._lock:
            for pool in self._connection_pools.values():
                pool.close_all()
        
        # Call parent cleanup
        await super().cleanup_all()
        
        self.logger.info("Resource cleanup completed")
    
    def _emergency_cleanup(self):
        """Emergency synchronous cleanup on exit"""
        try:
            # Close database connections
            for pool in self._connection_pools.values():
                pool.close_all()
            
            # Force garbage collection
            gc.collect()
        except Exception:
            pass

class ConnectionPool:
    """Database connection pool with proper resource management"""
    
    def __init__(self, db_path: str, max_connections: int = 10):
        self.db_path = db_path
        self.max_connections = max_connections
        self._pool: Queue[sqlite3.Connection] = Queue(maxsize=max_connections)
        self._all_connections: List[sqlite3.Connection] = []
        self._lock = threading.Lock()
        self.logger = logging.getLogger(__name__)
        
        # Pre-create minimum connections
        for _ in range(min(3, max_connections)):
            conn = self._create_connection()
            self._pool.put(conn)
    
    def _create_connection(self) -> sqlite3.Connection:
        """Create new database connection with optimizations"""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        
        # Apply optimizations
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-64000")  # 64MB
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA mmap_size=268435456")  # 256MB
        
        self._all_connections.append(conn)
        return conn
    
    def get_connection(self) -> sqlite3.Connection:
        """Get connection from pool"""
        try:
            # Try to get from pool
            conn = self._pool.get_nowait()
            # Verify connection is still alive
            try:
                conn.execute("SELECT 1")
            except:
                conn.close()
                conn = self._create_connection()
            return conn
        except Empty:
            # Create new connection if under limit
            with self._lock:
                if len(self._all_connections) < self.max_connections:
                    return self._create_connection()
                else:
                    # Wait for connection
                    return self._pool.get(timeout=30)
    
    def return_connection(self, conn: sqlite3.Connection):
        """Return connection to pool"""
        try:
            # Verify connection is still good
            conn.execute("SELECT 1")
            self._pool.put(conn)
        except:
            # Connection is bad, close it
            try:
                conn.close()
            except Exception:
                pass
            # Remove from all connections
            with self._lock:
                if conn in self._all_connections:
                    self._all_connections.remove(conn)
    
    def close_all(self):
        """Close all connections"""
        with self._lock:
            # Close pooled connections
            while not self._pool.empty():
                try:
                    conn = self._pool.get_nowait()
                    conn.close()
                except Exception:
                    pass
            
            # Close all connections
            for conn in self._all_connections:
                try:
                    conn.close()
                except Exception:
                    pass
            
            self._all_connections.clear()

# Resource Management Decorators
def with_aiohttp_session(func):
    """Decorator to provide managed aiohttp session"""
    async def wrapper(*args, **kwargs):
        resource_manager = EnhancedResourceManager()
        async with resource_manager.aiohttp_session() as session:
            # Inject session as first argument if function expects it
            import inspect
            sig = inspect.signature(func)
            if 'session' in sig.parameters:
                return await func(session=session, *args, **kwargs)
            else:
                return await func(*args, **kwargs)
    return wrapper

def with_db_connection(db_name: str):
    """Decorator to provide managed database connection"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            resource_manager = EnhancedResourceManager()
            db_path = f"data/{db_name}.db"
            with resource_manager.database_connection(db_path) as conn:
                # Inject connection
                import inspect
                sig = inspect.signature(func)
                if 'conn' in sig.parameters:
                    return func(conn=conn, *args, **kwargs)
                else:
                    return func(*args, **kwargs)
        return wrapper
    return decorator

# Utility functions for resource cleanup
async def cleanup_abandoned_resources():
    """Cleanup any abandoned resources system-wide"""
    logger = logging.getLogger(__name__)
    logger.info("Starting abandoned resource cleanup...")
    
    # Find and close abandoned aiohttp sessions
    for obj in gc.get_objects():
        if isinstance(obj, aiohttp.ClientSession) and not obj.closed:
            logger.warning(f"Found abandoned aiohttp session: {obj}")
            try:
                await obj.close()
            except Exception:
                pass
    
    # Force garbage collection
    gc.collect()
    
    # Check memory usage
    process = psutil.Process()
    memory_info = process.memory_info()
    logger.info(f"Memory usage after cleanup - RSS: {memory_info.rss / 1024 / 1024:.2f} MB, ")
                f"VMS: {memory_info.vms / 1024 / 1024:.2f} MB")

# Global resource manager instance
_resource_manager = None

def get_resource_manager() -> EnhancedResourceManager:
    """Get global resource manager instance"""
    global _resource_manager
    if _resource_manager is None:
        _resource_manager = EnhancedResourceManager()
    return _resource_manager

# Cleanup function to be called on shutdown
async def shutdown_cleanup():
    """Comprehensive shutdown cleanup"""
    resource_manager = get_resource_manager()
    await resource_manager.cleanup_all()
    await cleanup_abandoned_resources()

if __name__ == "__main__":
    # Test the resource management
    async def test_resource_management():
        logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        
        resource_manager = get_resource_manager()
        
        # Test aiohttp session management
        logger.info("Testing aiohttp session management...")
        async with resource_manager.aiohttp_session() as session:
            async with session.get("https://api.github.com") as response:
                data = await response.json()
                logger.info(f"Got response: {response.status}")
        
        # Test database connection management
        logger.info("Testing database connection management...")
        with resource_manager.database_connection("test.db") as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS test (id INTEGER PRIMARY KEY, value TEXT)")
            conn.execute("INSERT INTO test (value) VALUES (?)", ("test_value",))
            conn.commit()
            
            cursor = conn.execute("SELECT COUNT(*) FROM test")
            count = cursor.fetchone()[0]
            logger.info(f"Database has {count} records")
        
        # Test task management
        logger.info("Testing task management...")
        async def sample_task(n):
            await asyncio.sleep(1)
            return n * 2
        
        tasks = []
        for i in range(5):
            task = await resource_manager.create_task(sample_task(i), name=f"task_{i}")
            tasks.append(task)
        
        results = await asyncio.gather(*tasks)
        logger.info(f"Task results: {results}")
        
        # Test cleanup
        logger.info("Testing cleanup...")
        await resource_manager.cleanup_all()
        
        logger.info("All tests completed successfully!")
    
    # Run tests
    asyncio.run(test_resource_management())