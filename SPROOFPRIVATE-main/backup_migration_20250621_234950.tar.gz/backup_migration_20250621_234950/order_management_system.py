#!/usr/bin/env python3
"""
Order Management System (OMS)
============================
Comprehensive order lifecycle management with advanced execution algorithms,
real-time monitoring, and smart order routing.
"""
class TradingError(Exception): pass  # Define locally



import asyncio
import uuid
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Union, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
import numpy as np
import pandas as pd
from collections import defaultdict, deque
import logging
import json
from concurrent.futures import ThreadPoolExecutor
import heapq
from decimal import Decimal, ROUND_DOWN

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import ()
    MarketOrderRequest, LimitOrderRequest, StopOrderRequest,
    StopLimitOrderRequest, TrailingStopOrderRequest,
    GetOrdersRequest, ReplaceOrderRequest
)
from alpaca.trading.enums import ()
    OrderSide, TimeInForce, OrderType, OrderStatus,
    OrderClass, QueryOrderStatus
)
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockLatestQuoteRequest

# Internal imports
from alpaca_config import AlpacaConfig
from unified_logging import get_logger
from unified_error_handling import ()
    handle_errors, ErrorCategory, ErrorSeverity,
    TradingError, ValidationError
)

logger = get_logger(__name__)


class OrderPriority(Enum):
    """Order execution priority levels"""
    URGENT = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BATCH = 5


class ExecutionAlgorithm(Enum):
    """Execution algorithm types"""
    AGGRESSIVE = "aggressive"  # Market orders, immediate execution
    PASSIVE = "passive"        # Limit orders at favorable prices
    TWAP = "twap"             # Time-weighted average price
    VWAP = "vwap"             # Volume-weighted average price
    ICEBERG = "iceberg"       # Hide large order size
    ADAPTIVE = "adaptive"     # Adjust based on market conditions
    POV = "pov"               # Percentage of volume
    DARK = "dark"             # Dark pool preference


class OrderState(Enum):
    """Detailed order states"""
    PENDING_VALIDATION = auto()
    VALIDATED = auto()
    PENDING_SUBMISSION = auto()
    SUBMITTED = auto()
    PENDING_FILL = auto()
    PARTIALLY_FILLED = auto()
    FILLED = auto()
    PENDING_CANCEL = auto()
    CANCELLED = auto()
    REJECTED = auto()
    EXPIRED = auto()
    FAILED = auto()


@dataclass
class OrderConstraints:
    """Order execution constraints"""
    max_participation_rate: float = 0.10  # Max 10% of volume
    max_spread_cross: float = 0.02        # Max 2% spread to cross
    min_fill_size: int = 100              # Minimum execution size
    max_slippage: float = 0.005           # Max 0.5% slippage
    max_market_impact: float = 0.001      # Max 0.1% impact
    time_limit: Optional[timedelta] = None
    price_limit: Optional[float] = None
    dark_pool_eligible: bool = True
    allow_odd_lots: bool = True


@dataclass
class ExecutionMetrics:
    """Order execution performance metrics"""
    arrival_price: float = 0.0
    execution_price: float = 0.0
    vwap_price: float = 0.0
    slippage: float = 0.0
    market_impact: float = 0.0
    fill_rate: float = 0.0
    execution_time: float = 0.0
    total_cost: float = 0.0
    implementation_shortfall: float = 0.0


@dataclass
class OrderRecord:
    """Comprehensive order record"""
    # Identifiers
    internal_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    broker_id: Optional[str] = None
    parent_id: Optional[str] = None
    strategy_id: Optional[str] = None
    
    # Order details
    symbol: str = ""
    side: OrderSide = OrderSide.BUY
    quantity: int = 0
    filled_quantity: int = 0
    remaining_quantity: int = 0
    
    # Pricing
    order_type: OrderType = OrderType.LIMIT
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    average_fill_price: float = 0.0
    
    # Timing
    created_at: datetime = field(default_factory=datetime.now)
    submitted_at: Optional[datetime] = None
    filled_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    
    # State
    state: OrderState = OrderState.PENDING_VALIDATION
    time_in_force: TimeInForce = TimeInForce.DAY
    
    # Execution
    algorithm: ExecutionAlgorithm = ExecutionAlgorithm.ADAPTIVE
    priority: OrderPriority = OrderPriority.NORMAL
    constraints: OrderConstraints = field(default_factory=OrderConstraints)
    
    # Tracking
    fills: List[Dict[str, Any]] = field(default_factory=list)
    modifications: List[Dict[str, Any]] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    # Performance
    metrics: ExecutionMetrics = field(default_factory=ExecutionMetrics)
    
    # Metadata
    tags: Dict[str, Any] = field(default_factory=dict)
    notes: str = ""


class OrderManagementSystem:
    """Advanced Order Management System"""
    
    def __init__(self, config: AlpacaConfig):
        self.config = config
        self.trading_client = TradingClient(**config.get_trading_client_config())
        self.data_client = StockHistoricalDataClient()
            config.api_key,
            config.secret_key
        )
        
        # Order storage
        self.orders: Dict[str, OrderRecord] = {}
        self.active_orders: Dict[str, OrderRecord] = {}
        self.order_history: List[OrderRecord] = []
        
        # Execution queues by priority
        self.execution_queues: Dict[OrderPriority, asyncio.Queue] = {}
            priority: asyncio.Queue() for priority in OrderPriority
        }
        
        # Market data cache
        self.market_data_cache: Dict[str, Dict[str, Any]] = {}
        self.quote_cache: Dict[str, Any] = {}
        
        # Execution algorithms
        self.execution_algorithms = {}
            ExecutionAlgorithm.AGGRESSIVE: self._execute_aggressive,
            ExecutionAlgorithm.PASSIVE: self._execute_passive,
            ExecutionAlgorithm.TWAP: self._execute_twap,
            ExecutionAlgorithm.VWAP: self._execute_vwap,
            ExecutionAlgorithm.ICEBERG: self._execute_iceberg,
            ExecutionAlgorithm.ADAPTIVE: self._execute_adaptive,
            ExecutionAlgorithm.POV: self._execute_pov
        }
        
        # Performance tracking
        self.execution_stats = defaultdict(lambda: {)
            'total_orders': 0,
            'filled_orders': 0,
            'cancelled_orders': 0,
            'rejected_orders': 0,
            'total_volume': 0,
            'total_value': 0.0,
            'avg_slippage': 0.0,
            'avg_fill_time': 0.0
        })
        
        # Configuration
        self.max_order_rate = 100  # Orders per second
        self.rate_limiter = asyncio.Semaphore(self.max_order_rate)
        
        # Background tasks
        self.executor = ThreadPoolExecutor(max_workers=20)
        self._running = False
        self._tasks = []
        
        logger.info(f"Order Management System initialized in {config.mode} mode")
    
    async def start(self):
        """Start the OMS background tasks"""
        self._running = True
        
        # Start execution workers for each priority
        for priority in OrderPriority:
            for i in range(self._get_worker_count(priority)):
                task = asyncio.create_task()
                    self._execution_worker(priority)
                )
                self._tasks.append(task)
        
        # Start monitoring tasks
        self._tasks.extend([)
            asyncio.create_task(self._monitor_orders()),
            asyncio.create_task(self._update_market_data()),
            asyncio.create_task(self._calculate_metrics()),
            asyncio.create_task(self._cleanup_orders())
        ])
        
        logger.info("OMS started with {} workers".format(len(self._tasks)))
    
    async def stop(self):
        """Stop the OMS"""
        self._running = False
        
        # Cancel all tasks
        for task in self._tasks:
            task.cancel()
        
        # Wait for tasks to complete
        await asyncio.gather(*self._tasks, return_exceptions=True)
        
        # Shutdown executor
        self.executor.shutdown(wait=True)
        
        logger.info("OMS stopped")
    
    def _get_worker_count(self, priority: OrderPriority) -> int:
        """Get number of workers for each priority level"""
        return {}
            OrderPriority.URGENT: 5,
            OrderPriority.HIGH: 3,
            OrderPriority.NORMAL: 2,
            OrderPriority.LOW: 1,
            OrderPriority.BATCH: 1
        }.get(priority, 1)
    
    @handle_errors("create_order", ErrorCategory.TRADING, ErrorSeverity.HIGH)
    async def create_order()
        self,
        symbol: str,
        side: Union[str, OrderSide],
        quantity: int,
        order_type: Union[str, OrderType] = OrderType.LIMIT,
        limit_price: Optional[float] = None,
        stop_price: Optional[float] = None,
        time_in_force: TimeInForce = TimeInForce.DAY,
        algorithm: ExecutionAlgorithm = ExecutionAlgorithm.ADAPTIVE,
        priority: OrderPriority = OrderPriority.NORMAL,
        constraints: Optional[OrderConstraints] = None,
        **kwargs
    ) -> OrderRecord:
        """Create a new order"""
        
        # Convert string types if needed
        if isinstance(side, str):
            side = OrderSide[side.upper()]
        if isinstance(order_type, str):
            order_type = OrderType[order_type.upper()]
        
        # Create order record
        order = OrderRecord()
            symbol=symbol,
            side=side,
            quantity=quantity,
            remaining_quantity=quantity,
            order_type=order_type,
            limit_price=limit_price,
            stop_price=stop_price,
            time_in_force=time_in_force,
            algorithm=algorithm,
            priority=priority,
            constraints=constraints or OrderConstraints(),
            tags=kwargs.get('tags', {}),
            strategy_id=kwargs.get('strategy_id'),
            parent_id=kwargs.get('parent_id')
        )
        
        # Store order
        self.orders[order.internal_id] = order
        self.active_orders[order.internal_id] = order
        
        # Validate order
        await self._validate_order(order)
        
        if order.state == OrderState.VALIDATED:
            # Queue for execution
            await self.execution_queues[priority].put(order)
            logger.info(f"Order created: {order.internal_id} - ")
                       f"{side.value} {quantity} {symbol}")
        else:
            logger.warning(f"Order validation failed: {order.internal_id}")
        
        return order
    
    async def _validate_order(self, order: OrderRecord) -> bool:
        """Validate order before submission"""
        try:
            # Check symbol
            if not order.symbol or len(order.symbol) > 5:
                order.errors.append("Invalid symbol")
                order.state = OrderState.REJECTED
                return False
            
            # Check quantity
            if order.quantity <= 0:
                order.errors.append("Invalid quantity")
                order.state = OrderState.REJECTED
                return False
            
            # Check prices
            if order.order_type == OrderType.LIMIT and not order.limit_price:
                order.errors.append("Limit price required for limit orders")
                order.state = OrderState.REJECTED
                return False
            
            if order.order_type in [OrderType.STOP, OrderType.STOP_LIMIT] and not order.stop_price:
                order.errors.append("Stop price required for stop orders")
                order.state = OrderState.REJECTED
                return False
            
            # Risk checks
            account = self.trading_client.get_account()
            order_value = order.quantity * (order.limit_price or await self._get_last_price(order.symbol))
            
            if order_value > float(account.buying_power):
                order.errors.append("Insufficient buying power")
                order.state = OrderState.REJECTED
                return False
            
            # Position limits
            positions = self.trading_client.get_all_positions()
            symbol_positions = [p for p in positions if p.symbol == order.symbol]
            
            if symbol_positions:
                current_position = float(symbol_positions[0].qty)
                if order.side == OrderSide.BUY:
                    new_position = current_position + order.quantity
                else:
                    new_position = current_position - order.quantity
                
                # Check position limits
                max_position = 10000  # Example limit
                if abs(new_position) > max_position:
                    order.errors.append(f"Position limit exceeded: {max_position}")
                    order.state = OrderState.REJECTED
                    return False
            
            order.state = OrderState.VALIDATED
            return True
            
        except Exception as e:
            logger.error(f"Order validation error: {e}")
            order.errors.append(str(e))
            order.state = OrderState.REJECTED
            return False
    
    async def _get_last_price(self, symbol: str) -> float:
        """Get last traded price for symbol"""
        try:
            # Check cache first
            if symbol in self.quote_cache:
                cache_time = self.quote_cache[symbol].get('timestamp')
                if cache_time and (datetime.now() - cache_time).seconds < 1:
                    return self.quote_cache[symbol]['price']
            
            # Fetch latest quote
            request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            quotes = self.data_client.get_stock_latest_quote(request)
            
            if symbol in quotes:
                quote = quotes[symbol]
                price = (quote.bid_price + quote.ask_price) / 2
                
                # Update cache
                self.quote_cache[symbol] = {}
                    'price': price,
                    'bid': quote.bid_price,
                    'ask': quote.ask_price,
                    'timestamp': datetime.now()
                }
                
                return price
            
            return 0.0
            
        except Exception as e:
            logger.error(f"Error getting last price for {symbol}: {e}")
            return 0.0
    
    async def _execution_worker(self, priority: OrderPriority):
        """Worker to process orders from queue"""
        queue = self.execution_queues[priority]
        
        while self._running:
            try:
                # Get order from queue with timeout
                order = await asyncio.wait_for()
                    queue.get(),
                    timeout=1.0
                )
                
                # Rate limiting
                async with self.rate_limiter:
                    # Execute order
                    await self._execute_order(order)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Execution worker error: {e}")
    
    async def _execute_order(self, order: OrderRecord):
        """Execute order using specified algorithm"""
        try:
            order.state = OrderState.PENDING_SUBMISSION
            
            # Get execution algorithm
            algorithm_func = self.execution_algorithms.get()
                order.algorithm,
                self._execute_adaptive
            )
            
            # Record arrival price
            order.metrics.arrival_price = await self._get_last_price(order.symbol)
            
            # Execute order
            await algorithm_func(order)
            
        except Exception as e:
            logger.error(f"Order execution error: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_aggressive(self, order: OrderRecord):
        """Aggressive execution - market orders"""
        try:
            # Create market order
            request = MarketOrderRequest()
                symbol=order.symbol,
                qty=order.quantity,
                side=order.side,
                time_in_force=order.time_in_force
            )
            
            # Submit order
            response = self.trading_client.submit_order(request)
            
            # Update order record
            order.broker_id = response.id
            order.submitted_at = datetime.now()
            order.state = OrderState.SUBMITTED
            
            logger.info(f"Aggressive order submitted: {order.broker_id}")
            
        except Exception as e:
            logger.error(f"Aggressive execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_passive(self, order: OrderRecord):
        """Passive execution - limit orders at favorable prices"""
        try:
            # Get current quote
            quote = await self._get_quote(order.symbol)
            
            # Set passive price
            if order.side == OrderSide.BUY:
                # Buy at bid or better
                limit_price = min()
                    order.limit_price or float('inf'),
                    quote['bid']
                )
            else:
                # Sell at ask or better
                limit_price = max()
                    order.limit_price or 0,
                    quote['ask']
                )
            
            # Create limit order
            request = LimitOrderRequest()
                symbol=order.symbol,
                qty=order.quantity,
                side=order.side,
                time_in_force=order.time_in_force,
                limit_price=limit_price
            )
            
            # Submit order
            response = self.trading_client.submit_order(request)
            
            # Update order record
            order.broker_id = response.id
            order.limit_price = limit_price
            order.submitted_at = datetime.now()
            order.state = OrderState.SUBMITTED
            
            logger.info(f"Passive order submitted: {order.broker_id} @ {limit_price}")
            
        except Exception as e:
            logger.error(f"Passive execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_twap(self, order: OrderRecord):
        """Time-Weighted Average Price execution"""
        try:
            # Calculate slice parameters
            total_duration = order.constraints.time_limit or timedelta(minutes=30)
            num_slices = max(10, min(100, order.quantity // 100))
            slice_size = order.quantity // num_slices
            slice_interval = total_duration.total_seconds() / num_slices
            
            remaining_quantity = order.quantity
            order.state = OrderState.PENDING_FILL
            
            # Execute slices
            for i in range(num_slices):
                if not self._running or order.state == OrderState.CANCELLED:
                    break
                
                # Calculate this slice size
                if i == num_slices - 1:
                    # Last slice gets remaining quantity
                    current_slice = remaining_quantity
                else:
                    current_slice = min(slice_size, remaining_quantity)
                
                if current_slice <= 0:
                    break
                
                # Create slice order
                slice_request = MarketOrderRequest()
                    symbol=order.symbol,
                    qty=current_slice,
                    side=order.side,
                    time_in_force=TimeInForce.IOC  # Immediate or cancel
                )
                
                try:
                    # Submit slice
                    response = self.trading_client.submit_order(slice_request)
                    
                    # Track fill
                    order.fills.append({)
                        'order_id': response.id,
                        'quantity': current_slice,
                        'timestamp': datetime.now(),
                        'slice_number': i + 1
                    })
                    
                    remaining_quantity -= current_slice
                    order.remaining_quantity = remaining_quantity
                    
                    logger.debug(f"TWAP slice {i+1}/{num_slices} executed: ")
                               f"{current_slice} shares")
                    
                except Exception as e:
                    logger.error(f"TWAP slice execution failed: {e}")
                
                # Wait for next slice
                if i < num_slices - 1:
                    await asyncio.sleep(slice_interval)
            
            # Update final state
            order.filled_quantity = order.quantity - remaining_quantity
            if order.filled_quantity == order.quantity:
                order.state = OrderState.FILLED
                order.filled_at = datetime.now()
            elif order.filled_quantity > 0:
                order.state = OrderState.PARTIALLY_FILLED
            
        except Exception as e:
            logger.error(f"TWAP execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_vwap(self, order: OrderRecord):
        """Volume-Weighted Average Price execution"""
        try:
            # Get historical volume pattern
            volume_profile = await self._get_volume_profile(order.symbol)
            
            # Calculate slice parameters based on volume
            total_duration = order.constraints.time_limit or timedelta(minutes=30)
            time_buckets = self._create_time_buckets(total_duration, 30)  # 30 buckets
            
            remaining_quantity = order.quantity
            order.state = OrderState.PENDING_FILL
            
            for i, (start_time, end_time, volume_pct) in enumerate(time_buckets):
                if not self._running or order.state == OrderState.CANCELLED:
                    break
                
                # Calculate quantity for this time bucket
                bucket_quantity = int(order.quantity * volume_pct)
                bucket_quantity = min(bucket_quantity, remaining_quantity)
                
                if bucket_quantity <= 0:
                    continue
                
                # Wait until bucket start time
                wait_time = (start_time - datetime.now()).total_seconds()
                if wait_time > 0:
                    await asyncio.sleep(wait_time)
                
                # Create order for this bucket
                bucket_request = LimitOrderRequest()
                    symbol=order.symbol,
                    qty=bucket_quantity,
                    side=order.side,
                    time_in_force=TimeInForce.IOC,
                    limit_price=await self._get_aggressive_price()
                        order.symbol, order.side
                    )
                )
                
                try:
                    # Submit order
                    response = self.trading_client.submit_order(bucket_request)
                    
                    # Track fill
                    order.fills.append({)
                        'order_id': response.id,
                        'quantity': bucket_quantity,
                        'timestamp': datetime.now(),
                        'bucket': i + 1,
                        'target_volume_pct': volume_pct
                    })
                    
                    remaining_quantity -= bucket_quantity
                    order.remaining_quantity = remaining_quantity
                    
                except Exception as e:
                    logger.error(f"VWAP bucket execution failed: {e}")
            
            # Update final state
            order.filled_quantity = order.quantity - remaining_quantity
            if order.filled_quantity == order.quantity:
                order.state = OrderState.FILLED
                order.filled_at = datetime.now()
            elif order.filled_quantity > 0:
                order.state = OrderState.PARTIALLY_FILLED
            
        except Exception as e:
            logger.error(f"VWAP execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_iceberg(self, order: OrderRecord):
        """Iceberg order execution - show only small portions"""
        try:
            # Iceberg parameters
            display_quantity = min()
                order.constraints.min_fill_size,
                order.quantity // 10  # Show max 10% at a time
            )
            
            remaining_quantity = order.quantity
            order.state = OrderState.PENDING_FILL
            
            while remaining_quantity > 0 and self._running:
                if order.state == OrderState.CANCELLED:
                    break
                
                # Calculate current display size
                current_display = min(display_quantity, remaining_quantity)
                
                # Create visible order
                iceberg_request = LimitOrderRequest()
                    symbol=order.symbol,
                    qty=current_display,
                    side=order.side,
                    time_in_force=TimeInForce.GTC,
                    limit_price=order.limit_price or await self._get_passive_price()
                        order.symbol, order.side
                    )
                )
                
                try:
                    # Submit visible portion
                    response = self.trading_client.submit_order(iceberg_request)
                    current_order_id = response.id
                    
                    # Wait for fill or timeout
                    filled = await self._wait_for_fill()
                        current_order_id,
                        timeout=60  # 1 minute timeout per slice
                    )
                    
                    if filled:
                        # Track fill
                        order.fills.append({)
                            'order_id': current_order_id,
                            'quantity': current_display,
                            'timestamp': datetime.now(),
                            'iceberg_slice': len(order.fills) + 1
                        })
                        
                        remaining_quantity -= current_display
                        order.remaining_quantity = remaining_quantity
                        order.filled_quantity += current_display
                    else:
                        # Cancel unfilled portion and adjust price
                        self.trading_client.cancel_order_by_id(current_order_id)
                        
                        # Adjust price to be more aggressive
                        if order.side == OrderSide.BUY:
                            order.limit_price = (order.limit_price or 0) * 1.001
                        else:
                            order.limit_price = (order.limit_price or float('inf')) * 0.999
                    
                except Exception as e:
                    logger.error(f"Iceberg slice execution failed: {e}")
                
                # Small delay between slices
                await asyncio.sleep(1)
            
            # Update final state
            if order.filled_quantity == order.quantity:
                order.state = OrderState.FILLED
                order.filled_at = datetime.now()
            elif order.filled_quantity > 0:
                order.state = OrderState.PARTIALLY_FILLED
            
        except Exception as e:
            logger.error(f"Iceberg execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_adaptive(self, order: OrderRecord):
        """Adaptive execution based on market conditions"""
        try:
            # Analyze market conditions
            market_conditions = await self._analyze_market_conditions(order.symbol)
            
            # Choose execution strategy based on conditions
            if market_conditions['volatility'] > 0.02:  # High volatility
                # Use TWAP to reduce market impact
                await self._execute_twap(order)
            elif market_conditions['spread'] > 0.001:  # Wide spread
                # Use passive execution
                await self._execute_passive(order)
            elif order.quantity > market_conditions['avg_volume'] * 0.01:  # Large order
                # Use iceberg to hide size
                await self._execute_iceberg(order)
            else:
                # Normal conditions - use limit order
                await self._execute_standard_limit(order)
            
        except Exception as e:
            logger.error(f"Adaptive execution failed: {e}")
            # Fallback to aggressive execution
            await self._execute_aggressive(order)
    
    async def _execute_pov(self, order: OrderRecord):
        """Percentage of Volume execution"""
        try:
            # POV parameters
            target_pov = order.constraints.max_participation_rate
            check_interval = 10  # seconds
            
            remaining_quantity = order.quantity
            order.state = OrderState.PENDING_FILL
            start_time = datetime.now()
            
            while remaining_quantity > 0 and self._running:
                if order.state == OrderState.CANCELLED:
                    break
                
                # Get recent volume
                recent_volume = await self._get_recent_volume()
                    order.symbol,
                    seconds=check_interval
                )
                
                # Calculate quantity to execute
                target_quantity = int(recent_volume * target_pov)
                execute_quantity = min(target_quantity, remaining_quantity)
                
                if execute_quantity > 0:
                    # Create order
                    pov_request = MarketOrderRequest()
                        symbol=order.symbol,
                        qty=execute_quantity,
                        side=order.side,
                        time_in_force=TimeInForce.IOC
                    )
                    
                    try:
                        # Submit order
                        response = self.trading_client.submit_order(pov_request)
                        
                        # Track fill
                        order.fills.append({)
                            'order_id': response.id,
                            'quantity': execute_quantity,
                            'timestamp': datetime.now(),
                            'market_volume': recent_volume,
                            'pov': target_pov
                        })
                        
                        remaining_quantity -= execute_quantity
                        order.remaining_quantity = remaining_quantity
                        order.filled_quantity += execute_quantity
                        
                    except Exception as e:
                        logger.error(f"POV slice execution failed: {e}")
                
                # Wait before next check
                await asyncio.sleep(check_interval)
                
                # Check time limit
                if order.constraints.time_limit:
                    if datetime.now() - start_time > order.constraints.time_limit:
                        logger.warning(f"POV execution time limit reached")
                        break
            
            # Update final state
            if order.filled_quantity == order.quantity:
                order.state = OrderState.FILLED
                order.filled_at = datetime.now()
            elif order.filled_quantity > 0:
                order.state = OrderState.PARTIALLY_FILLED
            
        except Exception as e:
            logger.error(f"POV execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _execute_standard_limit(self, order: OrderRecord):
        """Standard limit order execution"""
        try:
            # Set limit price if not specified
            if not order.limit_price:
                order.limit_price = await self._get_passive_price()
                    order.symbol, order.side
                )
            
            # Create limit order
            request = LimitOrderRequest()
                symbol=order.symbol,
                qty=order.quantity,
                side=order.side,
                time_in_force=order.time_in_force,
                limit_price=order.limit_price
            )
            
            # Submit order
            response = self.trading_client.submit_order(request)
            
            # Update order record
            order.broker_id = response.id
            order.submitted_at = datetime.now()
            order.state = OrderState.SUBMITTED
            
            logger.info(f"Limit order submitted: {order.broker_id} @ {order.limit_price}")
            
        except Exception as e:
            logger.error(f"Standard limit execution failed: {e}")
            order.state = OrderState.FAILED
            order.errors.append(str(e))
    
    async def _get_quote(self, symbol: str) -> Dict[str, float]:
        """Get current quote for symbol"""
        quote = self.quote_cache.get(symbol, {})
        
        # Check if cache is fresh
        if quote.get('timestamp'):
            age = (datetime.now() - quote['timestamp']).seconds
            if age < 1:  # 1 second cache
                return quote
        
        # Fetch fresh quote
        try:
            request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            quotes = self.data_client.get_stock_latest_quote(request)
            
            if symbol in quotes:
                q = quotes[symbol]
                quote = {}
                    'bid': q.bid_price,
                    'ask': q.ask_price,
                    'bid_size': q.bid_size,
                    'ask_size': q.ask_size,
                    'timestamp': datetime.now()
                }
                self.quote_cache[symbol] = quote
                return quote
        except Exception as e:
            logger.error(f"Error fetching quote: {e}")
        
        return {'bid': 0, 'ask': 0, 'timestamp': datetime.now()}
    
    async def _get_passive_price(self, symbol: str, side: OrderSide) -> float:
        """Get passive price (join the queue)"""
        quote = await self._get_quote(symbol)
        
        if side == OrderSide.BUY:
            return quote['bid']
        else:
            return quote['ask']
    
    async def _get_aggressive_price(self, symbol: str, side: OrderSide) -> float:
        """Get aggressive price (cross the spread)"""
        quote = await self._get_quote(symbol)
        
        if side == OrderSide.BUY:
            # Pay the ask
            return quote['ask'] * 1.001  # Add small buffer
        else:
            # Hit the bid
            return quote['bid'] * 0.999  # Subtract small buffer
    
    async def _wait_for_fill(self, order_id: str, timeout: int = 60) -> bool:
        """Wait for order to be filled"""
        start_time = datetime.now()
        
        while (datetime.now() - start_time).seconds < timeout:
            try:
                # Get order status
                order = self.trading_client.get_order_by_id(order_id)
                
                if order.status in [OrderStatus.FILLED, OrderStatus.PARTIALLY_FILLED]:
                    return True
                elif order.status in [OrderStatus.CANCELLED, OrderStatus.REJECTED]:
                    return False
                
            except Exception as e:
                logger.error(f"Error checking order status: {e}")
            
            await asyncio.sleep(0.5)
        
        return False
    
    async def _analyze_market_conditions(self, symbol: str) -> Dict[str, float]:
        """Analyze current market conditions"""
        try:
            quote = await self._get_quote(symbol)
            
            # Calculate spread
            spread = (quote['ask'] - quote['bid']) / quote['bid'] if quote['bid'] > 0 else 0
            
            # Get recent trades for volatility
            # This is simplified - in production would use more sophisticated measures
            volatility = 0.01  # Default 1% volatility
            
            # Get average volume
            avg_volume = 1000000  # Default 1M shares
            
            return {}
                'spread': spread,
                'volatility': volatility,
                'avg_volume': avg_volume,
                'bid_size': quote.get('bid_size', 0),
                'ask_size': quote.get('ask_size', 0)
            }
            
        except Exception as e:
            logger.error(f"Error analyzing market conditions: {e}")
            return {}
                'spread': 0.001,
                'volatility': 0.01,
                'avg_volume': 1000000
            }
    
    async def _get_volume_profile(self, symbol: str) -> List[float]:
        """Get intraday volume profile"""
        # Simplified - returns typical U-shaped volume profile
        # In production, would use historical data
        
        # U-shaped profile (high at open/close, low midday)
        profile = []
            0.08, 0.07, 0.06, 0.05, 0.04, 0.04,  # Morning
            0.03, 0.03, 0.03, 0.03, 0.03, 0.03,  # Midday
            0.04, 0.04, 0.05, 0.06, 0.07, 0.08   # Afternoon
        ]
        
        # Normalize
        total = sum(profile)
        return [v / total for v in profile]
    
    def _create_time_buckets()
        self,
        duration: timedelta,
        num_buckets: int
    ) -> List[Tuple[datetime, datetime, float]]:
        """Create time buckets with volume weights"""
        volume_profile = asyncio.run(self._get_volume_profile(""))
        
        start_time = datetime.now()
        bucket_duration = duration.total_seconds() / num_buckets
        
        buckets = []
        for i in range(num_buckets):
            bucket_start = start_time + timedelta(seconds=i * bucket_duration)
            bucket_end = bucket_start + timedelta(seconds=bucket_duration)
            
            # Map to volume profile
            profile_index = min()
                int(i * len(volume_profile) / num_buckets),
                len(volume_profile) - 1
            )
            volume_weight = volume_profile[profile_index]
            
            buckets.append((bucket_start, bucket_end, volume_weight))
        
        return buckets
    
    async def _get_recent_volume(self, symbol: str, seconds: int = 60) -> int:
        """Get volume traded in recent seconds"""
        # Simplified - in production would track actual volume
        # Returns estimated volume based on average daily volume
        avg_daily_volume = 10000000  # 10M shares
        trading_seconds = 6.5 * 3600  # 6.5 hours
        
        return int(avg_daily_volume * seconds / trading_seconds)
    
    async def _monitor_orders(self):
        """Monitor active orders and update states"""
        while self._running:
            try:
                # Get all active orders from broker
                broker_orders = self.trading_client.get_orders()
                    status=QueryOrderStatus.OPEN
                )
                
                # Update local order states
                for broker_order in broker_orders:
                    # Find matching local order
                    local_order = None
                    for order in self.active_orders.values():
                        if order.broker_id == broker_order.id:
                            local_order = order
                            break
                    
                    if local_order:
                        # Update state
                        self._update_order_state(local_order, broker_order)
                
                # Check for expired orders
                for order in list(self.active_orders.values()):
                    if order.expires_at and datetime.now() > order.expires_at:
                        await self.cancel_order(order.internal_id)
                
                await asyncio.sleep(1)  # Check every second
                
            except Exception as e:
                logger.error(f"Order monitoring error: {e}")
                await asyncio.sleep(5)
    
    def _update_order_state(self, local_order: OrderRecord, broker_order):
        """Update local order state from broker order"""
        # Map broker status to local state
        status_map = {}
            OrderStatus.NEW: OrderState.SUBMITTED,
            OrderStatus.PARTIALLY_FILLED: OrderState.PARTIALLY_FILLED,
            OrderStatus.FILLED: OrderState.FILLED,
            OrderStatus.DONE_FOR_DAY: OrderState.EXPIRED,
            OrderStatus.CANCELED: OrderState.CANCELLED,
            OrderStatus.EXPIRED: OrderState.EXPIRED,
            OrderStatus.REPLACED: OrderState.SUBMITTED,
            OrderStatus.PENDING_CANCEL: OrderState.PENDING_CANCEL,
            OrderStatus.PENDING_REPLACE: OrderState.SUBMITTED,
            OrderStatus.ACCEPTED: OrderState.SUBMITTED,
            OrderStatus.PENDING_NEW: OrderState.PENDING_SUBMISSION,
            OrderStatus.ACCEPTED_FOR_BIDDING: OrderState.SUBMITTED,
            OrderStatus.STOPPED: OrderState.SUBMITTED,
            OrderStatus.REJECTED: OrderState.REJECTED,
            OrderStatus.SUSPENDED: OrderState.SUBMITTED,
            OrderStatus.CALCULATED: OrderState.SUBMITTED
        }
        
        new_state = status_map.get(broker_order.status, OrderState.SUBMITTED)
        
        if new_state != local_order.state:
            local_order.state = new_state
            logger.info(f"Order {local_order.internal_id} state updated to {new_state}")
        
        # Update quantities
        local_order.filled_quantity = int(broker_order.filled_qty or 0)
        local_order.remaining_quantity = local_order.quantity - local_order.filled_quantity
        
        # Update average price
        if broker_order.filled_avg_price:
            local_order.average_fill_price = float(broker_order.filled_avg_price)
        
        # Update timestamps
        if broker_order.filled_at and local_order.state == OrderState.FILLED:
            local_order.filled_at = broker_order.filled_at
        
        # Remove from active if terminal state
        if new_state in [OrderState.FILLED, OrderState.CANCELLED,
                        OrderState.REJECTED, OrderState.EXPIRED]:
            if local_order.internal_id in self.active_orders:
                del self.active_orders[local_order.internal_id]
                self.order_history.append(local_order)
    
    async def _update_market_data(self):
        """Update market data cache"""
        while self._running:
            try:
                # Get symbols from active orders
                symbols = list(set())
                    order.symbol for order in self.active_orders.values()
                ))
                
                if symbols:
                    # Batch update quotes
                    request = StockLatestQuoteRequest(symbol_or_symbols=symbols)
                    quotes = self.data_client.get_stock_latest_quote(request)
                    
                    # Update cache
                    for symbol, quote in quotes.items():
                        self.quote_cache[symbol] = {}
                            'bid': quote.bid_price,
                            'ask': quote.ask_price,
                            'bid_size': quote.bid_size,
                            'ask_size': quote.ask_size,
                            'timestamp': datetime.now()
                        }
                
                await asyncio.sleep(0.5)  # Update every 500ms
                
            except Exception as e:
                logger.error(f"Market data update error: {e}")
                await asyncio.sleep(5)
    
    async def _calculate_metrics(self):
        """Calculate execution metrics"""
        while self._running:
            try:
                for order in self.order_history[-100:]:  # Last 100 orders
                    if order.state == OrderState.FILLED and not order.metrics.execution_price:
                        # Calculate metrics
                        order.metrics.execution_price = order.average_fill_price
                        
                        # Slippage
                        if order.metrics.arrival_price > 0:
                            if order.side == OrderSide.BUY:
                                order.metrics.slippage = ()
                                    order.metrics.execution_price - order.metrics.arrival_price
                                ) / order.metrics.arrival_price
                            else:
                                order.metrics.slippage = ()
                                    order.metrics.arrival_price - order.metrics.execution_price
                                ) / order.metrics.arrival_price
                        
                        # Execution time
                        if order.submitted_at and order.filled_at:
                            order.metrics.execution_time = ()
                                order.filled_at - order.submitted_at
                            ).total_seconds()
                        
                        # Fill rate
                        order.metrics.fill_rate = order.filled_quantity / order.quantity
                
                await asyncio.sleep(10)  # Calculate every 10 seconds
                
            except Exception as e:
                logger.error(f"Metrics calculation error: {e}")
                await asyncio.sleep(30)
    
    async def _cleanup_orders(self):
        """Clean up old orders and maintain history"""
        while self._running:
            try:
                # Keep only recent history (last 1000 orders)
                if len(self.order_history) > 1000:
                    self.order_history = self.order_history[-1000:]
                
                # Clean up old cache entries
                cutoff_time = datetime.now() - timedelta(minutes=5)
                
                # Clean quote cache
                for symbol in list(self.quote_cache.keys()):
                    if self.quote_cache[symbol].get('timestamp', datetime.min) < cutoff_time:
                        del self.quote_cache[symbol]
                
                # Archive old orders
                archive_cutoff = datetime.now() - timedelta(days=1)
                orders_to_archive = []
                    order for order in self.order_history
                    if order.created_at < archive_cutoff
                ]
                
                if orders_to_archive:
                    # In production, would save to database
                    logger.info(f"Archiving {len(orders_to_archive)} old orders")
                    self.order_history = []
                        order for order in self.order_history
                        if order.created_at >= archive_cutoff
                    ]
                
                await asyncio.sleep(300)  # Clean up every 5 minutes
                
            except Exception as e:
                logger.error(f"Cleanup error: {e}")
                await asyncio.sleep(600)
    
    async def cancel_order(self, order_id: str) -> bool:
        """Cancel an order"""
        try:
            order = self.orders.get(order_id)
            if not order:
                logger.error(f"Order not found: {order_id}")
                return False
            
            if order.state in [OrderState.FILLED, OrderState.CANCELLED]:
                logger.warning(f"Cannot cancel order in state: {order.state}")
                return False
            
            order.state = OrderState.PENDING_CANCEL
            
            # Cancel with broker
            if order.broker_id:
                self.trading_client.cancel_order_by_id(order.broker_id)
            
            order.state = OrderState.CANCELLED
            order.cancelled_at = datetime.now()
            
            # Remove from active orders
            if order_id in self.active_orders:
                del self.active_orders[order_id]
                self.order_history.append(order)
            
            logger.info(f"Order cancelled: {order_id}")
            return True
            
        except Exception as e:
            logger.error(f"Order cancellation failed: {e}")
            return False
    
    async def modify_order()
        self,
        order_id: str,
        quantity: Optional[int] = None,
        limit_price: Optional[float] = None,
        stop_price: Optional[float] = None
    ) -> bool:
        """Modify an existing order"""
        try:
            order = self.active_orders.get(order_id)
            if not order:
                logger.error(f"Active order not found: {order_id}")
                return False
            
            if not order.broker_id:
                logger.error(f"No broker ID for order: {order_id}")
                return False
            
            # Create replace request
            replace_request = ReplaceOrderRequest()
                qty=quantity or order.quantity,
                limit_price=limit_price or order.limit_price,
                stop_price=stop_price or order.stop_price
            )
            
            # Submit modification
            self.trading_client.replace_order_by_id()
                order.broker_id,
                replace_request
            )
            
            # Update local record
            if quantity:
                order.quantity = quantity
                order.remaining_quantity = quantity - order.filled_quantity
            if limit_price:
                order.limit_price = limit_price
            if stop_price:
                order.stop_price = stop_price
            
            # Track modification
            order.modifications.append({)
                'timestamp': datetime.now(),
                'quantity': quantity,
                'limit_price': limit_price,
                'stop_price': stop_price
            })
            
            logger.info(f"Order modified: {order_id}")
            return True
            
        except Exception as e:
            logger.error(f"Order modification failed: {e}")
            return False
    
    def get_order(self, order_id: str) -> Optional[OrderRecord]:
        """Get order by ID"""
        return self.orders.get(order_id)
    
    def get_active_orders(self, symbol: Optional[str] = None) -> List[OrderRecord]:
        """Get active orders, optionally filtered by symbol"""
        orders = list(self.active_orders.values())
        
        if symbol:
            orders = [o for o in orders if o.symbol == symbol]
        
        return orders
    
    def get_order_history()
        self,
        symbol: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[OrderRecord]:
        """Get historical orders with optional filters"""
        orders = self.order_history.copy()
        
        if symbol:
            orders = [o for o in orders if o.symbol == symbol]
        
        if start_date:
            orders = [o for o in orders if o.created_at >= start_date]
        
        if end_date:
            orders = [o for o in orders if o.created_at <= end_date]
        
        return orders
    
    def get_execution_statistics(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Get execution statistics"""
        if symbol:
            orders = [o for o in self.order_history if o.symbol == symbol]
        else:
            orders = self.order_history
        
        if not orders:
            return {}
        
        filled_orders = [o for o in orders if o.state == OrderState.FILLED]
        
        stats = {}
            'total_orders': len(orders),
            'filled_orders': len(filled_orders),
            'fill_rate': len(filled_orders) / len(orders) if orders else 0,
            'avg_execution_time': np.mean([)
                o.metrics.execution_time for o in filled_orders
                if o.metrics.execution_time > 0
            ]) if filled_orders else 0,
            'avg_slippage': np.mean([)
                o.metrics.slippage for o in filled_orders
                if o.metrics.slippage != 0
            ]) if filled_orders else 0,
            'total_volume': sum(o.filled_quantity for o in filled_orders),
            'total_value': sum()
                o.filled_quantity * o.average_fill_price
                for o in filled_orders
            )
        }
        
        # Breakdown by algorithm
        stats['by_algorithm'] = {}
        for algo in ExecutionAlgorithm:
            algo_orders = [o for o in filled_orders if o.algorithm == algo]
            if algo_orders:
                stats['by_algorithm'][algo.value] = {}
                    'count': len(algo_orders),
                    'avg_slippage': np.mean([)
                        o.metrics.slippage for o in algo_orders
                        if o.metrics.slippage != 0
                    ])
                }
        
        return stats
    
    async def get_market_impact()
        self,
        symbol: str,
        side: OrderSide,
        quantity: int
    ) -> float:
        """Estimate market impact for an order"""
        try:
            # Get current market data
            quote = await self._get_quote(symbol)
            spread = quote['ask'] - quote['bid']
            
            # Simple linear impact model
            # Impact = spread/2 + lambda * quantity / ADV
            # where lambda is market impact coefficient
            
            avg_daily_volume = 10000000  # Simplified
            lambda_coefficient = 0.1  # 10 bps per 1% of ADV
            
            participation_rate = quantity / avg_daily_volume
            
            # Base impact is half spread
            base_impact = spread / 2
            
            # Additional impact based on size
            size_impact = lambda_coefficient * participation_rate * quote['bid']
            
            total_impact = base_impact + size_impact
            
            # Convert to percentage
            impact_pct = total_impact / quote['bid']
            
            return impact_pct
            
        except Exception as e:
            logger.error(f"Market impact calculation error: {e}")
            return 0.001  # Default 10 bps


# Example usage
if __name__ == "__main__":
    import asyncio
    
    async def test_oms():
        # Initialize OMS
        config = AlpacaConfig('paper')
        oms = OrderManagementSystem(config)
        
        # Start OMS
        await oms.start()
        
        try:
            # Create a TWAP order
            order = await oms.create_order()
                symbol="AAPL",
                side=OrderSide.BUY,
                quantity=1000,
                algorithm=ExecutionAlgorithm.TWAP,
                priority=OrderPriority.NORMAL,
                constraints=OrderConstraints()
                    time_limit=timedelta(minutes=30),
                    max_participation_rate=0.05
                ),
                tags={'strategy': 'momentum', 'signal_strength': 0.85}
            )
            
            print(f"Order created: {order.internal_id}")
            
            # Wait a bit
            await asyncio.sleep(60)
            
            # Get order status
            updated_order = oms.get_order(order.internal_id)
            print(f"Order state: {updated_order.state}")
            print(f"Filled: {updated_order.filled_quantity}/{updated_order.quantity}")
            
            # Get statistics
            stats = oms.get_execution_statistics()
            print(f"Execution stats: {stats}")
            
        finally:
            # Stop OMS
            await oms.stop()
    
    # Run test
    asyncio.run(test_oms())