"""
Production-Ready Hybrid LSTM-MLP Architecture for Financial Markets
Combines sequential modeling (LSTM) with static feature processing (MLP)
Supports multi-task learning, attention mechanisms, and production deployment
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass
from collections import OrderedDict
import json
import time
from datetime import datetime
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
import pickle
import hashlib
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class HybridModelConfig:
    """Configuration for Hybrid LSTM-MLP Model"""
    # Temporal branch (LSTM)
    lstm_input_size: int = 64
    lstm_hidden_size: int = 256
    lstm_num_layers: int = 3
    lstm_dropout: float = 0.2
    use_bidirectional: bool = True
    
    # Static branch (MLP)
    mlp_input_size: int = 128
    mlp_hidden_sizes: List[int] = None
    mlp_dropout: float = 0.3
    mlp_activation: str = 'gelu'
    
    # Attention mechanisms
    attention_heads: int = 8
    attention_dim: int = 256
    use_cross_attention: bool = True
    use_hierarchical_attention: bool = True
    
    # Fusion mechanism
    fusion_method: str = 'gated'  # 'gated', 'attention', 'concat'
    fusion_dim: int = 512
    
    # Output configuration
    num_tasks: int = 3  # price, volatility, signals
    output_dims: Dict[str, int] = None
    
    # Training configuration
    lstm_lr: float = 1e-4
    mlp_lr: float = 5e-4
    fusion_lr: float = 2e-4
    weight_decay: float = 1e-5
    gradient_clip: float = 1.0
    
    # Production features
    enable_uncertainty: bool = True
    enable_interpretability: bool = True
    enable_online_learning: bool = True
    model_version: str = "1.0.0"
    
    def __post_init__(self):
        if self.mlp_hidden_sizes is None:
            self.mlp_hidden_sizes = [512, 256, 128]
        if self.output_dims is None:
            self.output_dims = {}
                'price': 1,
                'volatility': 1,
                'signals': 3,
                'greeks': 5
            }


class MultiHeadSelfAttention(nn.Module):
    """Multi-Head Self-Attention mechanism"""
    
    def __init__(self, input_dim: int, num_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.input_dim = input_dim
        self.num_heads = num_heads
        self.head_dim = input_dim // num_heads
        
        assert input_dim % num_heads == 0, "input_dim must be divisible by num_heads"
        
        self.query = nn.Linear(input_dim, input_dim)
        self.key = nn.Linear(input_dim, input_dim)
        self.value = nn.Linear(input_dim, input_dim)
        self.out = nn.Linear(input_dim, input_dim)
        
        self.dropout = nn.Dropout(dropout)
        self.scale = self.head_dim ** -0.5
        
    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        batch_size, seq_len, _ = x.shape
        
        # Linear transformations and split into heads
        Q = self.query(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        K = self.key(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        V = self.value(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Attention scores
        scores = torch.matmul(Q, K.transpose(-2, -1)) * self.scale
        
        if mask is not None:
            scores = scores.masked_fill(mask.unsqueeze(1).unsqueeze(1) == 0, -1e9)
        
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        
        # Apply attention to values
        context = torch.matmul(attn_weights, V)
        context = context.transpose(1, 2).contiguous().view(batch_size, seq_len, self.input_dim)
        
        output = self.out(context)
        
        return output, attn_weights


class CrossAttention(nn.Module):
    """Cross-attention between temporal and static features"""
    
    def __init__(self, temporal_dim: int, static_dim: int, hidden_dim: int, num_heads: int = 8):
        super().__init__()
        self.temporal_dim = temporal_dim
        self.static_dim = static_dim
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        
        self.temporal_proj = nn.Linear(temporal_dim, hidden_dim)
        self.static_proj = nn.Linear(static_dim, hidden_dim)
        
        self.attention = MultiHeadSelfAttention(hidden_dim, num_heads)
        self.norm = nn.LayerNorm(hidden_dim)
        
    def forward(self, temporal_features: torch.Tensor, static_features: torch.Tensor) -> torch.Tensor:
        # Project features to same dimension
        temporal_proj = self.temporal_proj(temporal_features)
        static_proj = self.static_proj(static_features)
        
        # Expand static features to match temporal sequence length
        batch_size, seq_len, _ = temporal_proj.shape
        static_proj = static_proj.unsqueeze(1).expand(-1, seq_len, -1)
        
        # Concatenate and apply attention
        combined = torch.cat([temporal_proj, static_proj], dim=1)
        attended, weights = self.attention(combined)
        
        # Residual connection and normalization
        output = self.norm(attended + combined)
        
        return output[:, :seq_len, :], weights


class GatedFusion(nn.Module):
    """Gated fusion mechanism for combining LSTM and MLP branches"""
    
    def __init__(self, lstm_dim: int, mlp_dim: int, output_dim: int):
        super().__init__()
        self.lstm_gate = nn.Sequential()
            nn.Linear(lstm_dim + mlp_dim, output_dim),
            nn.Sigmoid()
        )
        self.mlp_gate = nn.Sequential()
            nn.Linear(lstm_dim + mlp_dim, output_dim),
            nn.Sigmoid()
        )
        self.fusion_layer = nn.Linear(lstm_dim + mlp_dim, output_dim)
        self.norm = nn.LayerNorm(output_dim)
        
    def forward(self, lstm_features: torch.Tensor, mlp_features: torch.Tensor) -> torch.Tensor:
        # Expand MLP features if needed
        if lstm_features.dim() == 3 and mlp_features.dim() == 2:
            mlp_features = mlp_features.unsqueeze(1).expand(-1, lstm_features.size(1), -1)
        
        combined = torch.cat([lstm_features, mlp_features], dim=-1)
        
        # Compute gates
        lstm_gate = self.lstm_gate(combined)
        mlp_gate = self.mlp_gate(combined)
        
        # Normalize gates
        gate_sum = lstm_gate + mlp_gate + 1e-8
        lstm_gate = lstm_gate / gate_sum
        mlp_gate = mlp_gate / gate_sum
        
        # Apply gated fusion
        if lstm_features.dim() == 3:
            lstm_contrib = lstm_gate * lstm_features
            mlp_contrib = mlp_gate * mlp_features[:, :, :lstm_features.size(-1)]
        else:
            lstm_contrib = lstm_gate * lstm_features
            mlp_contrib = mlp_gate * mlp_features[:, :lstm_features.size(-1)]
        
        # Final fusion
        fused = self.fusion_layer(combined)
        output = self.norm(fused + lstm_contrib + mlp_contrib)
        
        return output


class TemporalEncoder(nn.Module):
    """LSTM-based temporal encoder with attention"""
    
    def __init__(self, config: HybridModelConfig):
        super().__init__()
        self.config = config
        
        # Multi-layer LSTM
        self.lstm = nn.LSTM()
            input_size=config.lstm_input_size,
            hidden_size=config.lstm_hidden_size,
            num_layers=config.lstm_num_layers,
            dropout=config.lstm_dropout if config.lstm_num_layers > 1 else 0,
            batch_first=True,
            bidirectional=config.use_bidirectional
        )
        
        lstm_output_size = config.lstm_hidden_size * (2 if config.use_bidirectional else 1)
        
        # Attention layers
        self.attention = MultiHeadSelfAttention()
            lstm_output_size,
            config.attention_heads,
            config.lstm_dropout
        )
        
        # Hierarchical attention if enabled
        if config.use_hierarchical_attention:
            self.feature_attention = nn.Sequential()
                nn.Linear(config.lstm_input_size, config.attention_dim),
                nn.Tanh(),
                nn.Linear(config.attention_dim, 1)
            )
            self.temporal_attention = nn.Sequential()
                nn.Linear(lstm_output_size, config.attention_dim),
                nn.Tanh(),
                nn.Linear(config.attention_dim, 1)
            )
        
        # Output projection
        self.output_proj = nn.Linear(lstm_output_size, config.attention_dim)
        self.norm = nn.LayerNorm(config.attention_dim)
        self.dropout = nn.Dropout(config.lstm_dropout)
        
    def forward(self, x: torch.Tensor, lengths: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        batch_size, seq_len, num_features = x.shape
        
        # Feature-level attention
        if self.config.use_hierarchical_attention:
            feature_weights = self.feature_attention(x)
            feature_weights = F.softmax(feature_weights, dim=-1)
            x = x * feature_weights
        
        # Pack sequences if lengths provided
        if lengths is not None:
            x = nn.utils.rnn.pack_padded_sequence(x, lengths, batch_first=True, enforce_sorted=False)
        
        # LSTM encoding
        lstm_out, (hidden, cell) = self.lstm(x)
        
        # Unpack sequences
        if lengths is not None:
            lstm_out, _ = nn.utils.rnn.pad_packed_sequence(lstm_out, batch_first=True)
        
        # Self-attention
        attended, attn_weights = self.attention(lstm_out)
        lstm_out = self.dropout(attended + lstm_out)
        
        # Temporal attention
        if self.config.use_hierarchical_attention:
            temporal_weights = self.temporal_attention(lstm_out)
            temporal_weights = F.softmax(temporal_weights, dim=1)
            # Weighted average over time
            aggregated = torch.sum(lstm_out * temporal_weights, dim=1)
        else:
            # Use last hidden state
            if self.config.use_bidirectional:
                hidden = hidden.view(self.config.lstm_num_layers, 2, batch_size, self.config.lstm_hidden_size)
                hidden = torch.cat([hidden[-1, 0], hidden[-1, 1]], dim=-1)
            else:
                hidden = hidden[-1]
            aggregated = hidden
        
        # Project to common dimension
        output = self.output_proj(aggregated)
        output = self.norm(output)
        
        return {}
            'features': output,
            'sequence': lstm_out,
            'attention_weights': attn_weights,
            'temporal_weights': temporal_weights if self.config.use_hierarchical_attention else None
        }


class StaticEncoder(nn.Module):
    """MLP-based static feature encoder with residual connections"""
    
    def __init__(self, config: HybridModelConfig):
        super().__init__()
        self.config = config
        
        # Build MLP layers with residual connections
        layers = []
        input_size = config.mlp_input_size
        
        for i, hidden_size in enumerate(config.mlp_hidden_sizes):
            layers.append(self._make_residual_block(input_size, hidden_size, config.mlp_dropout))
            input_size = hidden_size
        
        self.mlp = nn.Sequential(*layers)
        
        # Feature selection attention
        self.feature_selection = nn.Sequential()
            nn.Linear(config.mlp_input_size, config.mlp_input_size),
            nn.Sigmoid()
        )
        
        # Output projection
        self.output_proj = nn.Linear(input_size, config.attention_dim)
        self.norm = nn.LayerNorm(config.attention_dim)
        
    def _make_residual_block(self, input_size: int, output_size: int, dropout: float) -> nn.Module:
        """Create a residual block for the MLP"""
        return ResidualBlock(input_size, output_size, dropout, self.config.mlp_activation)
    
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        # Adaptive feature selection
        feature_gates = self.feature_selection(x)
        x = x * feature_gates
        
        # MLP encoding
        mlp_features = self.mlp(x)
        
        # Project to common dimension
        output = self.output_proj(mlp_features)
        output = self.norm(output)
        
        return {}
            'features': output,
            'feature_gates': feature_gates,
            'intermediate': mlp_features
        }


class ResidualBlock(nn.Module):
    """Residual block for deep MLP"""
    
    def __init__(self, input_size: int, output_size: int, dropout: float, activation: str):
        super().__init__()
        self.linear1 = nn.Linear(input_size, output_size)
        self.linear2 = nn.Linear(output_size, output_size)
        self.norm1 = nn.LayerNorm(output_size)
        self.norm2 = nn.LayerNorm(output_size)
        self.dropout = nn.Dropout(dropout)
        
        # Activation function
        if activation == 'gelu':
            self.activation = nn.GELU()
        elif activation == 'relu':
            self.activation = nn.ReLU()
        elif activation == 'silu':
            self.activation = nn.SiLU()
        else:
            self.activation = nn.ReLU()
        
        # Skip connection
        self.skip = nn.Linear(input_size, output_size) if input_size != output_size else nn.Identity()
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.skip(x)
        
        x = self.linear1(x)
        x = self.norm1(x)
        x = self.activation(x)
        x = self.dropout(x)
        
        x = self.linear2(x)
        x = self.norm2(x)
        
        x = x + residual
        x = self.activation(x)
        
        return x


class MultiTaskHead(nn.Module):
    """Multi-task output head with uncertainty estimation"""
    
    def __init__(self, input_dim: int, output_dims: Dict[str, int], enable_uncertainty: bool = True):
        super().__init__()
        self.output_dims = output_dims
        self.enable_uncertainty = enable_uncertainty
        
        # Task-specific heads
        self.task_heads = nn.ModuleDict()
        self.uncertainty_heads = nn.ModuleDict()
        
        for task, dim in output_dims.items():
            self.task_heads[task] = nn.Sequential()
                nn.Linear(input_dim, input_dim // 2),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(input_dim // 2, dim)
            )
            
            if enable_uncertainty:
                self.uncertainty_heads[task] = nn.Sequential()
                    nn.Linear(input_dim, input_dim // 2),
                    nn.ReLU(),
                    nn.Dropout(0.1),
                    nn.Linear(input_dim // 2, dim),
                    nn.Softplus()  # Ensure positive uncertainty
                )
        
        # Task importance weights (learnable)
        self.task_weights = nn.Parameter(torch.ones(len(output_dims)))
        
    def forward(self, x: torch.Tensor) -> Dict[str, Dict[str, torch.Tensor]]:
        outputs = {}
        
        for i, (task, head) in enumerate(self.task_heads.items()):
            prediction = head(x)
            outputs[task] = {'prediction': prediction}
            
            if self.enable_uncertainty:
                uncertainty = self.uncertainty_heads[task](x)
                outputs[task]['uncertainty'] = uncertainty
            
            # Add task weight
            outputs[task]['weight'] = F.softmax(self.task_weights, dim=0)[i]
        
        return outputs


class HybridLSTMMLPModel(nn.Module):
    """Production-ready Hybrid LSTM-MLP Model"""
    
    def __init__(self, config: HybridModelConfig):
        super().__init__()
        self.config = config
        
        # Encoders
        self.temporal_encoder = TemporalEncoder(config)
        self.static_encoder = StaticEncoder(config)
        
        # Cross-attention if enabled
        if config.use_cross_attention:
            self.cross_attention = CrossAttention()
                config.attention_dim,
                config.attention_dim,
                config.fusion_dim,
                config.attention_heads
            )
        
        # Fusion mechanism
        if config.fusion_method == 'gated':
            self.fusion = GatedFusion()
                config.attention_dim,
                config.attention_dim,
                config.fusion_dim
            )
        elif config.fusion_method == 'attention':
            self.fusion = MultiHeadSelfAttention()
                config.attention_dim * 2,
                config.attention_heads
            )
            self.fusion_proj = nn.Linear(config.attention_dim * 2, config.fusion_dim)
        else:  # concat
            self.fusion = nn.Linear(config.attention_dim * 2, config.fusion_dim)
        
        # Multi-task output heads
        self.output_head = MultiTaskHead()
            config.fusion_dim,
            config.output_dims,
            config.enable_uncertainty
        )
        
        # Ensemble heads for individual branches
        self.temporal_head = MultiTaskHead()
            config.attention_dim,
            config.output_dims,
            config.enable_uncertainty
        )
        self.static_head = MultiTaskHead()
            config.attention_dim,
            config.output_dims,
            config.enable_uncertainty
        )
        
        # Dynamic weight allocation
        self.branch_weights = nn.Parameter(torch.tensor([0.5, 0.5]))
        
        # Initialize weights
        self._initialize_weights()
        
    def _initialize_weights(self):
        """Initialize model weights"""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.LSTM):
                for name, param in module.named_parameters():
                    if 'weight' in name:
                        nn.init.xavier_uniform_(param)
                    elif 'bias' in name:
                        nn.init.zeros_(param)
    
    def forward()
        self,
        temporal_data: torch.Tensor,
        static_data: torch.Tensor,
        lengths: Optional[torch.Tensor] = None,
        return_intermediates: bool = False
    ) -> Dict[str, Any]:
        """
        Forward pass through the hybrid model
        
        Args:
            temporal_data: Temporal features [batch, seq_len, features]
            static_data: Static features [batch, features]
            lengths: Sequence lengths for padding
            return_intermediates: Return intermediate representations
        
        Returns:
            Dictionary with predictions, uncertainties, and optional intermediates
        """
        # Encode temporal features
        temporal_output = self.temporal_encoder(temporal_data, lengths)
        temporal_features = temporal_output['features']
        
        # Encode static features
        static_output = self.static_encoder(static_data)
        static_features = static_output['features']
        
        # Cross-attention between modalities
        if self.config.use_cross_attention:
            attended_features, cross_attn_weights = self.cross_attention()
                temporal_output['sequence'],
                static_features
            )
            # Use attended features for temporal branch
            temporal_features = attended_features.mean(dim=1)  # Average over sequence
        else:
            cross_attn_weights = None
        
        # Fusion
        if self.config.fusion_method == 'gated':
            fused_features = self.fusion(temporal_features, static_features)
        elif self.config.fusion_method == 'attention':
            combined = torch.cat([temporal_features, static_features], dim=-1)
            attended, _ = self.fusion(combined.unsqueeze(1))
            fused_features = self.fusion_proj(attended.squeeze(1))
        else:
            combined = torch.cat([temporal_features, static_features], dim=-1)
            fused_features = self.fusion(combined)
        
        # Get predictions from all heads
        fusion_outputs = self.output_head(fused_features)
        temporal_outputs = self.temporal_head(temporal_features)
        static_outputs = self.static_head(static_features)
        
        # Compute branch weights
        branch_weights = F.softmax(self.branch_weights, dim=0)
        
        # Ensemble predictions
        final_outputs = {}
        for task in self.config.output_dims:
            # Weighted ensemble
            ensemble_pred = ()
                branch_weights[0] * temporal_outputs[task]['prediction'] +
                branch_weights[1] * static_outputs[task]['prediction']
            )
            
            final_outputs[task] = {}
                'prediction': fusion_outputs[task]['prediction'],
                'ensemble_prediction': ensemble_pred,
                'temporal_prediction': temporal_outputs[task]['prediction'],
                'static_prediction': static_outputs[task]['prediction'],
                'task_weight': fusion_outputs[task]['weight']
            }
            
            # Uncertainty estimation
            if self.config.enable_uncertainty:
                # Combine uncertainties
                ensemble_uncertainty = torch.sqrt()
                    branch_weights[0]**2 * temporal_outputs[task]['uncertainty']**2 +
                    branch_weights[1]**2 * static_outputs[task]['uncertainty']**2
                )
                
                final_outputs[task]['uncertainty'] = fusion_outputs[task]['uncertainty']
                final_outputs[task]['ensemble_uncertainty'] = ensemble_uncertainty
        
        # Add metadata
        results = {}
            'predictions': final_outputs,
            'branch_weights': branch_weights,
            'metadata': {}
                'model_version': self.config.model_version,
                'timestamp': datetime.now().isoformat()
            }
        }
        
        # Add intermediates if requested
        if return_intermediates:
            results['intermediates'] = {}
                'temporal_features': temporal_features,
                'static_features': static_features,
                'fused_features': fused_features,
                'attention_weights': temporal_output['attention_weights'],
                'cross_attention_weights': cross_attn_weights,
                'feature_gates': static_output['feature_gates']
            }
        
        return results
    
    def get_feature_importance(self, temporal_data: torch.Tensor, static_data: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Get feature importance scores"""
        with torch.no_grad():
            # Get feature gates from static encoder
            static_output = self.static_encoder(static_data)
            static_importance = static_output['feature_gates'].mean(dim=0)
            
            # Get attention weights from temporal encoder
            temporal_output = self.temporal_encoder(temporal_data)
            if self.config.use_hierarchical_attention:
                temporal_importance = temporal_output['temporal_weights'].mean(dim=0).squeeze()
            else:
                temporal_importance = temporal_output['attention_weights'].mean(dim=(0, 1))
            
            return {}
                'static_features': static_importance,
                'temporal_features': temporal_importance
            }


class OnlineLearningModule:
    """Online learning capabilities for the hybrid model"""
    
    def __init__(self, model: HybridLSTMMLPModel, config: HybridModelConfig):
        self.model = model
        self.config = config
        
        # Separate optimizers for different components
        self.optimizers = {}
            'temporal': torch.optim.AdamW()
                model.temporal_encoder.parameters(),
                lr=config.lstm_lr,
                weight_decay=config.weight_decay
            ),
            'static': torch.optim.AdamW()
                model.static_encoder.parameters(),
                lr=config.mlp_lr,
                weight_decay=config.weight_decay
            ),
            'fusion': torch.optim.AdamW()
                list(model.fusion.parameters()) + list(model.output_head.parameters()),
                lr=config.fusion_lr,
                weight_decay=config.weight_decay
            )
        }
        
        # Learning rate schedulers
        self.schedulers = {}
            name: torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(opt, T_0=10, T_mult=2)
            for name, opt in self.optimizers.items()
        }
        
        # Buffer for experience replay
        self.experience_buffer = queue.Queue(maxsize=10000)
        
        # Statistics tracking
        self.update_stats = {}
            'total_updates': 0,
            'temporal_updates': 0,
            'static_updates': 0,
            'fusion_updates': 0
        }
    
    def update(self, batch: Dict[str, torch.Tensor], importance_weight: float = 1.0) -> Dict[str, float]:
        """Perform online update"""
        self.model.train()
        
        # Forward pass
        outputs = self.model()
            batch['temporal_data'],
            batch['static_data'],
            batch.get('lengths')
        )
        
        # Compute losses for each task
        losses = {}
        total_loss = 0
        
        for task, targets in batch['targets'].items():
            if task in outputs['predictions']:
                pred = outputs['predictions'][task]['prediction']
                
                # Task-specific loss
                if task in ['price', 'volatility']:
                    task_loss = F.mse_loss(pred, targets)
                elif task == 'signals':
                    task_loss = F.cross_entropy(pred, targets.long())
                else:  # Greeks
                    task_loss = F.l1_loss(pred, targets)
                
                # Weight by task importance and sample importance
                task_weight = outputs['predictions'][task]['task_weight']
                weighted_loss = task_loss * task_weight * importance_weight
                
                losses[f'{task}_loss'] = task_loss.item()
                total_loss += weighted_loss
        
        # Backward pass with gradient clipping
        total_loss.backward()
        
        # Clip gradients
        for optimizer in self.optimizers.values():
            torch.nn.utils.clip_grad_norm_()
                [p for group in optimizer.param_groups for p in group['params']],
                self.config.gradient_clip
            )
        
        # Update different components based on gradients
        grad_norms = self._compute_grad_norms()
        
        # Selective updates based on gradient magnitudes
        for component, optimizer in self.optimizers.items():
            if grad_norms[component] > 1e-6:  # Only update if gradients are significant
                optimizer.step()
                self.schedulers[component].step()
                self.update_stats[f'{component}_updates'] += 1
            optimizer.zero_grad()
        
        self.update_stats['total_updates'] += 1
        
        # Add to experience buffer
        if self.experience_buffer.full():
            self.experience_buffer.get()
        self.experience_buffer.put({)
            'batch': batch,
            'loss': total_loss.item(),
            'timestamp': time.time()
        })
        
        losses['total_loss'] = total_loss.item()
        return losses
    
    def _compute_grad_norms(self) -> Dict[str, float]:
        """Compute gradient norms for different components"""
        norms = {}
        
        components = {}
            'temporal': self.model.temporal_encoder,
            'static': self.model.static_encoder,
            'fusion': self.model.fusion
        }
        
        for name, module in components.items():
            total_norm = 0
            for p in module.parameters():
                if p.grad is not None:
                    total_norm += p.grad.data.norm(2).item() ** 2
            norms[name] = total_norm ** 0.5
        
        return norms


class ProductionInferenceEngine:
    """High-performance inference engine for production deployment"""
    
    def __init__(self, model: HybridLSTMMLPModel, config: HybridModelConfig):
        self.model = model
        self.config = config
        
        # Model versioning
        self.model_version = config.model_version
        self.model_hash = self._compute_model_hash()
        
        # Performance monitoring
        self.inference_times = []
        self.batch_sizes = []
        
        # Thread pool for parallel processing
        self.thread_pool = ThreadPoolExecutor(max_workers=4)
        
        # Feature normalization stats
        self.feature_stats = {}
            'temporal_mean': None,
            'temporal_std': None,
            'static_mean': None,
            'static_std': None
        }
        
        # Cache for recent predictions
        self.prediction_cache = OrderedDict()
        self.cache_size = 1000
        
    def _compute_model_hash(self) -> str:
        """Compute hash of model parameters for versioning"""
        param_data = []
        for param in self.model.parameters():
            param_data.append(param.data.cpu().numpy().tobytes())
        return hashlib.sha256(b''.join(param_data)).hexdigest()[:8]
    
    @torch.no_grad()
    def predict()
        self,
        temporal_data: np.ndarray,
        static_data: np.ndarray,
        return_uncertainty: bool = True,
        return_intermediates: bool = False
    ) -> Dict[str, Any]:
        """Production-ready prediction interface"""
        start_time = time.time()
        
        # Input validation
        temporal_data = self._validate_temporal_input(temporal_data)
        static_data = self._validate_static_input(static_data)
        
        # Check cache
        cache_key = self._compute_cache_key(temporal_data, static_data)
        if cache_key in self.prediction_cache:
            logger.info("Returning cached prediction")
            return self.prediction_cache[cache_key]
        
        # Convert to tensors
        temporal_tensor = torch.FloatTensor(temporal_data)
        static_tensor = torch.FloatTensor(static_data)
        
        # Add batch dimension if needed
        if temporal_tensor.dim() == 2:
            temporal_tensor = temporal_tensor.unsqueeze(0)
        if static_tensor.dim() == 1:
            static_tensor = static_tensor.unsqueeze(0)
        
        # Normalize features
        temporal_tensor = self._normalize_temporal(temporal_tensor)
        static_tensor = self._normalize_static(static_tensor)
        
        # Model inference
        self.model.eval()
        outputs = self.model()
            temporal_tensor,
            static_tensor,
            return_intermediates=return_intermediates
        )
        
        # Post-process outputs
        results = self._post_process_outputs(outputs, return_uncertainty)
        
        # Performance monitoring
        inference_time = time.time() - start_time
        self.inference_times.append(inference_time)
        self.batch_sizes.append(temporal_tensor.size(0))
        
        # Update cache
        self.prediction_cache[cache_key] = results
        if len(self.prediction_cache) > self.cache_size:
            self.prediction_cache.popitem(last=False)
        
        # Add metadata
        results['metadata'].update({)
            'inference_time_ms': inference_time * 1000,
            'model_hash': self.model_hash,
            'cache_hit': False
        })
        
        return results
    
    async def predict_async()
        self,
        temporal_data: np.ndarray,
        static_data: np.ndarray,
        **kwargs
    ) -> Dict[str, Any]:
        """Asynchronous prediction for high-frequency trading"""
        import asyncio
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor()
            None,
            self.predict,
            temporal_data,
            static_data,
            kwargs.get('return_uncertainty', True),
            kwargs.get('return_intermediates', False)
        )
    
    def predict_batch()
        self,
        temporal_batch: List[np.ndarray],
        static_batch: List[np.ndarray],
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Batch prediction with parallel processing"""
        # Process in parallel
        futures = []
        for temporal, static in zip(temporal_batch, static_batch):
            future = self.thread_pool.submit(self.predict, temporal, static, **kwargs)
            futures.append(future)
        
        # Collect results
        results = [future.result() for future in futures]
        return results
    
    def _validate_temporal_input(self, data: np.ndarray) -> np.ndarray:
        """Validate temporal input data"""
        if not isinstance(data, np.ndarray):
            data = np.array(data)
        
        if data.ndim not in [2, 3]:
            raise ValueError(f"Temporal data must be 2D or 3D, got {data.ndim}D")
        
        expected_features = self.config.lstm_input_size
        if data.shape[-1] != expected_features:
            raise ValueError(f"Expected {expected_features} temporal features, got {data.shape[-1]}")
        
        # Handle missing values
        if np.isnan(data).any():
            logger.warning("NaN values detected in temporal data, imputing with forward fill")
            data = self._impute_temporal(data)
        
        return data
    
    def _validate_static_input(self, data: np.ndarray) -> np.ndarray:
        """Validate static input data"""
        if not isinstance(data, np.ndarray):
            data = np.array(data)
        
        if data.ndim not in [1, 2]:
            raise ValueError(f"Static data must be 1D or 2D, got {data.ndim}D")
        
        expected_features = self.config.mlp_input_size
        if data.shape[-1] != expected_features:
            raise ValueError(f"Expected {expected_features} static features, got {data.shape[-1]}")
        
        # Handle missing values
        if np.isnan(data).any():
            logger.warning("NaN values detected in static data, imputing with mean")
            data = self._impute_static(data)
        
        return data
    
    def _impute_temporal(self, data: np.ndarray) -> np.ndarray:
        """Impute missing values in temporal data"""
        if data.ndim == 2:
            # Forward fill then backward fill
            df = pd.DataFrame(data)
            df = df.fillna(method='ffill').fillna(method='bfill')
            return df.values
        else:
            # Process each sample
            result = []
            for sample in data:
                df = pd.DataFrame(sample)
                df = df.fillna(method='ffill').fillna(method='bfill')
                result.append(df.values)
            return np.array(result)
    
    def _impute_static(self, data: np.ndarray) -> np.ndarray:
        """Impute missing values in static data"""
        if self.feature_stats['static_mean'] is not None:
            # Use stored statistics
            mask = np.isnan(data)
            data[mask] = np.take(self.feature_stats['static_mean'], np.where(mask)[1])
        else:
            # Use column means
            if data.ndim == 1:
                data = np.nan_to_num(data, nan=0.0)
            else:
                col_means = np.nanmean(data, axis=0)
                for i in range(data.shape[1]):
                    data[np.isnan(data[:, i]), i] = col_means[i]
        return data
    
    def _normalize_temporal(self, data: torch.Tensor) -> torch.Tensor:
        """Normalize temporal features"""
        if self.feature_stats['temporal_mean'] is not None:
            mean = torch.tensor(self.feature_stats['temporal_mean'])
            std = torch.tensor(self.feature_stats['temporal_std'])
            data = (data - mean) / (std + 1e-8)
        return data
    
    def _normalize_static(self, data: torch.Tensor) -> torch.Tensor:
        """Normalize static features"""
        if self.feature_stats['static_mean'] is not None:
            mean = torch.tensor(self.feature_stats['static_mean'])
            std = torch.tensor(self.feature_stats['static_std'])
            data = (data - mean) / (std + 1e-8)
        return data
    
    def _post_process_outputs(self, outputs: Dict[str, Any], return_uncertainty: bool) -> Dict[str, Any]:
        """Post-process model outputs"""
        results = {}
            'predictions': {},
            'metadata': outputs['metadata']
        }
        
        for task, task_outputs in outputs['predictions'].items():
            task_results = {}
                'value': task_outputs['prediction'].cpu().numpy(),
                'ensemble': task_outputs['ensemble_prediction'].cpu().numpy()
            }
            
            if return_uncertainty and 'uncertainty' in task_outputs:
                task_results['uncertainty'] = task_outputs['uncertainty'].cpu().numpy()
                task_results['ensemble_uncertainty'] = task_outputs['ensemble_uncertainty'].cpu().numpy()
            
            results['predictions'][task] = task_results
        
        # Add branch weights
        results['branch_weights'] = {}
            'temporal': outputs['branch_weights'][0].item(),
            'static': outputs['branch_weights'][1].item()
        }
        
        return results
    
    def _compute_cache_key(self, temporal_data: np.ndarray, static_data: np.ndarray) -> str:
        """Compute cache key for predictions"""
        # Use hash of input data
        temporal_hash = hashlib.md5(temporal_data.tobytes()).hexdigest()[:8]
        static_hash = hashlib.md5(static_data.tobytes()).hexdigest()[:8]
        return f"{temporal_hash}_{static_hash}"
    
    def update_feature_stats(self, temporal_data: np.ndarray, static_data: np.ndarray):
        """Update feature normalization statistics"""
        # Temporal stats
        if temporal_data.ndim == 3:
            self.feature_stats['temporal_mean'] = temporal_data.mean(axis=(0, 1))
            self.feature_stats['temporal_std'] = temporal_data.std(axis=(0, 1))
        else:
            self.feature_stats['temporal_mean'] = temporal_data.mean(axis=0)
            self.feature_stats['temporal_std'] = temporal_data.std(axis=0)
        
        # Static stats
        if static_data.ndim == 2:
            self.feature_stats['static_mean'] = static_data.mean(axis=0)
            self.feature_stats['static_std'] = static_data.std(axis=0)
        else:
            self.feature_stats['static_mean'] = static_data
            self.feature_stats['static_std'] = np.ones_like(static_data)
    
    def get_performance_stats(self) -> Dict[str, float]:
        """Get inference performance statistics"""
        if not self.inference_times:
            return {}
        
        return {}
            'avg_inference_time_ms': np.mean(self.inference_times) * 1000,
            'p50_inference_time_ms': np.percentile(self.inference_times, 50) * 1000,
            'p95_inference_time_ms': np.percentile(self.inference_times, 95) * 1000,
            'p99_inference_time_ms': np.percentile(self.inference_times, 99) * 1000,
            'total_predictions': len(self.inference_times),
            'avg_batch_size': np.mean(self.batch_sizes),
            'cache_size': len(self.prediction_cache),
            'cache_hit_rate': 0.0  # Placeholder, would need to track hits
        }


class ModelTrainer:
    """Advanced training logic with curriculum learning and knowledge distillation"""
    
    def __init__(self, model: HybridLSTMMLPModel, config: HybridModelConfig):
        self.model = model
        self.config = config
        
        # Multi-objective optimization
        self.task_losses = {}
            'price': nn.MSELoss(),
            'volatility': nn.MSELoss(),
            'signals': nn.CrossEntropyLoss(),
            'greeks': nn.L1Loss()
        }
        
        # Curriculum learning stages
        self.curriculum_stages = []
            {'epochs': 10, 'tasks': ['price'], 'freeze': ['static_encoder']},
            {'epochs': 10, 'tasks': ['price', 'volatility'], 'freeze': []},
            {'epochs': 20, 'tasks': ['price', 'volatility', 'signals'], 'freeze': []},
            {'epochs': 30, 'tasks': list(self.task_losses.keys()), 'freeze': []}
        ]
        self.current_stage = 0
        
        # Knowledge distillation
        self.teacher_model = None
        self.distillation_weight = 0.3
        self.temperature = 3.0
        
    def train_epoch(self, dataloader, optimizer, stage_config):
        """Train for one epoch with curriculum learning"""
        self.model.train()
        
        # Freeze/unfreeze components based on stage
        self._apply_freezing(stage_config.freeze)
        
        epoch_losses = {task: [] for task in stage_config.tasks}
        
        for batch in dataloader:
            # Forward pass
            outputs = self.model()
                batch['temporal_data'],
                batch['static_data'],
                batch.get('lengths')
            )
            
            # Compute losses for active tasks
            total_loss = 0
            for task in stage_config.tasks:
                if task in batch['targets']:
                    pred = outputs['predictions'][task]['prediction']
                    target = batch['targets'][task]
                    
                    # Task loss
                    task_loss = self.task_losses[task](pred, target)
                    
                    # Knowledge distillation if teacher available
                    if self.teacher_model is not None:
                        with torch.no_grad():
                            teacher_outputs = self.teacher_model()
                                batch['temporal_data'],
                                batch['static_data'],
                                batch.get('lengths')
                            )
                        
                        teacher_pred = teacher_outputs['predictions'][task]['prediction']
                        distill_loss = F.kl_div()
                            F.log_softmax(pred / self.temperature, dim=-1),
                            F.softmax(teacher_pred / self.temperature, dim=-1),
                            reduction='batchmean'
                        ) * self.temperature ** 2
                        
                        task_loss = (1 - self.distillation_weight) * task_loss + \
                                   self.distillation_weight * distill_loss
                    
                    # Weight by task importance
                    task_weight = outputs['predictions'][task]['task_weight']
                    weighted_loss = task_loss * task_weight
                    
                    total_loss += weighted_loss
                    epoch_losses[task].append(task_loss.item())
            
            # Backward pass
            optimizer.zero_grad()
            total_loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_()
                self.model.parameters(),
                self.config.gradient_clip
            )
            
            optimizer.step()
        
        # Compute average losses
        avg_losses = {task: np.mean(losses) for task, losses in epoch_losses.items() if losses}
        
        return avg_losses
    
    def _apply_freezing(self, components_to_freeze):
        """Freeze/unfreeze model components"""
        # Unfreeze all first
        for param in self.model.parameters():
            param.requires_grad = True
        
        # Freeze specified components
        for component_name in components_to_freeze:
            if hasattr(self.model, component_name):
                component = getattr(self.model, component_name)
                for param in component.parameters():
                    param.requires_grad = False
    
    def advance_curriculum(self):
        """Advance to next curriculum stage"""
        if self.current_stage < len(self.curriculum_stages) - 1:
            self.current_stage += 1
            logger.info(f"Advanced to curriculum stage {self.current_stage}")
            return True
        return False


class IntegrationAPI:
    """API for integration with MASTER_PRODUCTION_INTEGRATION.py"""
    
    def __init__(self, model_path: Optional[str] = None):
        self.config = HybridModelConfig()
        self.model = HybridLSTMMLPModel(self.config)
        
        if model_path:
            self.load_model(model_path)
        
        self.inference_engine = ProductionInferenceEngine(self.model, self.config)
        self.online_learner = OnlineLearningModule(self.model, self.config)
        
    def load_model(self, path: str):
        """Load model from checkpoint"""
        checkpoint = torch.load(path, map_location='cpu')
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.config = checkpoint.get('config', self.config)
        logger.info(f"Loaded model from {path}")
    
    def save_model(self, path: str):
        """Save model checkpoint"""
        torch.save({)
            'model_state_dict': self.model.state_dict(),
            'config': self.config,
            'metadata': {}
                'timestamp': datetime.now().isoformat(),
                'version': self.config.model_version
            }
        }, path)
        logger.info(f"Saved model to {path}")
    
    def predict(self, temporal_data: np.ndarray, static_data: np.ndarray, **kwargs) -> Dict[str, Any]:
        """Main prediction interface"""
        return self.inference_engine.predict(temporal_data, static_data, **kwargs)
    
    def update_online(self, batch: Dict[str, Any], importance_weight: float = 1.0) -> Dict[str, float]:
        """Online learning update"""
        if self.config.enable_online_learning:
            return self.online_learner.update(batch, importance_weight)
        else:
            logger.warning("Online learning is disabled")
            return {}
    
    def get_feature_importance(self, temporal_data: np.ndarray, static_data: np.ndarray) -> Dict[str, Any]:
        """Get feature importance scores"""
        temporal_tensor = torch.FloatTensor(temporal_data).unsqueeze(0)
        static_tensor = torch.FloatTensor(static_data).unsqueeze(0)
        
        importance = self.model.get_feature_importance(temporal_tensor, static_tensor)
        
        return {}
            'temporal_importance': importance['temporal_features'].cpu().numpy(),
            'static_importance': importance['static_features'].cpu().numpy()
        }
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get model information and statistics"""
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        
        return {}
            'model_version': self.config.model_version,
            'total_parameters': total_params,
            'trainable_parameters': trainable_params,
            'config': self.config.__dict__,
            'performance_stats': self.inference_engine.get_performance_stats(),
            'online_learning_stats': self.online_learner.update_stats
        }


def create_integration_function():
    """Create integration function for MASTER_PRODUCTION_INTEGRATION.py"""
    
    def integrate_hybrid_lstm_mlp()
        temporal_data: np.ndarray,
        static_data: np.ndarray,
        model_path: Optional[str] = None,
        return_uncertainty: bool = True,
        enable_online_update: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Integration function for Hybrid LSTM-MLP model
        
        Args:
            temporal_data: Sequential features [batch, seq_len, features]
            static_data: Static features [batch, features]
            model_path: Path to saved model checkpoint
            return_uncertainty: Include uncertainty estimates
            enable_online_update: Enable online learning updates
            **kwargs: Additional arguments
        
        Returns:
            Dictionary with predictions and metadata
        """
        # Initialize API
        api = IntegrationAPI(model_path)
        
        # Get predictions
        results = api.predict()
            temporal_data,
            static_data,
            return_uncertainty=return_uncertainty,
            **kwargs
        )
        
        # Online update if enabled and targets provided
        if enable_online_update and 'targets' in kwargs:
            update_batch = {}
                'temporal_data': torch.FloatTensor(temporal_data),
                'static_data': torch.FloatTensor(static_data),
                'targets': kwargs['targets']
            }
            update_losses = api.update_online(update_batch)
            results['online_update'] = update_losses
        
        # Add model info
        results['model_info'] = api.get_model_info()
        
        return results
    
    return integrate_hybrid_lstm_mlp


# Export integration function
integrate_hybrid_lstm_mlp = create_integration_function()


if __name__ == "__main__":
    # Example usage and testing
    import pandas as pd
    
    logger.info("Initializing Hybrid LSTM-MLP Model")
    
    # Create configuration
    config = HybridModelConfig()
        lstm_input_size=50,
        lstm_hidden_size=256,
        mlp_input_size=30,
        mlp_hidden_sizes=[256, 128, 64],
        attention_heads=8,
        fusion_method='gated',
        enable_uncertainty=True,
        enable_online_learning=True
    )
    
    # Initialize model
    model = HybridLSTMMLPModel(config)
    logger.info(f"Model initialized with {sum(p.numel() for p in model.parameters())} parameters")
    
    # Create sample data
    batch_size = 32
    seq_len = 60
    
    temporal_data = torch.randn(batch_size, seq_len, config.lstm_input_size)
    static_data = torch.randn(batch_size, config.mlp_input_size)
    
    # Forward pass
    outputs = model(temporal_data, static_data, return_intermediates=True)
    
    logger.info("Forward pass completed successfully")
    logger.info(f"Output tasks: {list(outputs['predictions'].keys())}")
    
    # Test inference engine
    inference_engine = ProductionInferenceEngine(model, config)
    
    # Single prediction
    single_temporal = temporal_data[0].numpy()
    single_static = static_data[0].numpy()
    
    prediction = inference_engine.predict(single_temporal, single_static)
    logger.info(f"Inference completed in {prediction['metadata']['inference_time_ms']:.2f}ms")
    
    # Test online learning
    online_learner = OnlineLearningModule(model, config)
    
    # Create sample batch with targets
    batch = {}
        'temporal_data': temporal_data,
        'static_data': static_data,
        'targets': {}
            'price': torch.randn(batch_size, 1),
            'volatility': torch.randn(batch_size, 1),
            'signals': torch.randint(0, 3, (batch_size,)),
            'greeks': torch.randn(batch_size, 5)
        }
    }
    
    # Perform online update
    update_losses = online_learner.update(batch)
    logger.info(f"Online update completed. Losses: {update_losses}")
    
    # Test integration API
    api = IntegrationAPI()
    api.model = model
    api.config = config
    
    # Test save/load
    api.save_model('hybrid_lstm_mlp_checkpoint.pth')
    api.load_model('hybrid_lstm_mlp_checkpoint.pth')
    
    # Get model info
    model_info = api.get_model_info()
    logger.info(f"Model info: {json.dumps(model_info, indent=2)}")
    
    logger.info("All tests completed successfully!")

# Class aliases and stubs
HybridModel = HybridModelConfig


# Module exports
__all__ = ['TemporalEncoder', 'HybridLSTMMLPModel', 'MultiTaskHead', 'ResidualBlock', 'CrossAttention', 'ProductionInferenceEngine', 'StaticEncoder', 'GatedFusion', 'HybridModelConfig', 'OnlineLearningModule', 'ModelTrainer', 'IntegrationAPI', 'MultiHeadSelfAttention', 'HybridModel']
