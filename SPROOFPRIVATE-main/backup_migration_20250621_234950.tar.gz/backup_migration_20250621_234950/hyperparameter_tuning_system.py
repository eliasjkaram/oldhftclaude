#!/usr/bin/env python3
"""
Automated Hyperparameter Tuning System
Advanced optimization for trading model parameters
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from scipy.stats import uniform, randint, loguniform
from scipy.optimize import differential_evolution, minimize
import json
import joblib
from datetime import datetime
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

# Import custom modules
from v27_lightweight_ml_models import LightweightFeatureEngineering
from typing import Dict, List, Tuple, Any, Callable


class BayesianOptimizer:
    """Bayesian optimization for hyperparameter tuning"""
    
    def __init__(self, bounds: Dict[str, Tuple], n_calls: int = 50):
        self.bounds = bounds
        self.n_calls = n_calls
        self.X_observed = []
        self.y_observed = []
        
    def gaussian_process_surrogate(self, X):
        """Simple Gaussian Process surrogate model"""
        if len(self.X_observed) == 0:
            return 0, 1
            
        # Convert observations to array
        X_obs = np.array(self.X_observed)
        y_obs = np.array(self.y_observed)
        
        # Simple distance-based prediction
        distances = np.sum((X_obs - X)**2, axis=1)
        weights = np.exp(-distances)
        weights /= np.sum(weights)
        
        mean = np.sum(weights * y_obs)
        variance = np.sum(weights * (y_obs - mean)**2)
        
        return mean, np.sqrt(variance)
    
    def acquisition_function(self, X, xi=0.01):
        """Expected Improvement acquisition function"""
        mean, std = self.gaussian_process_surrogate(X)
        
        if std == 0:
            return 0
            
        if len(self.y_observed) > 0:
            y_best = np.max(self.y_observed)
        else:
            y_best = 0
            
        z = (mean - y_best - xi) / std
        ei = std * (z * norm.cdf(z) + norm.pdf(z)
        
        return ei
    
    def suggest_next(self):
        """Suggest next point to evaluate"""
        # Random sampling for first few points
        if len(self.X_observed) < 5:
            return self._random_sample()
            
        # Optimize acquisition function
        best_ei = -np.inf
        best_x = None
        
        for _ in range(1000):
            x = self._random_sample()
            ei = self.acquisition_function(x)
            
            if ei > best_ei:
                best_ei = ei
                best_x = x
                
        return best_x
    
    def _random_sample(self):
        """Generate random sample within bounds"""
        sample = []
        for param, (low, high) in self.bounds.items():
            if isinstance(low, int) and isinstance(high, int):
                value = np.random.randint(low, high + 1)
            else:
                value = np.random.uniform(low, high)
            sample.append(value)
        return np.array(sample)
    
    def update(self, X, y):
        """Update observations"""
        self.X_observed.append(X)
        self.y_observed.append(y)


class GridSearchOptimizer:
    """Exhaustive grid search optimization"""
    
    def __init__(self, param_grid: Dict[str, List]):
        self.param_grid = param_grid
        self.results = []
        
    def generate_combinations(self):
        """Generate all parameter combinations"""
        import itertools
        
        keys = list(self.param_grid.keys()
        values = [self.param_grid[k] for k in keys]
        
        for combination in itertools.product(*values):
            yield dict(zip(keys, combination)
    
    def search(self, objective_func: Callable, n_jobs: int = 1):
        """Perform grid search"""
        combinations = list(self.generate_combinations()
        
        print(f"Grid search: {len(combinations)} combinations")
        
        if n_jobs == 1:
            # Sequential execution
            for i, params in enumerate(combinations):
                score = objective_func(params)
                self.results.append((params, score)
                
                if (i + 1) % 10 == 0:
                    print(f"  Progress: {i+1}/{len(combinations)}")
        else:
            # Parallel execution
            from joblib import Parallel, delayed
            
            scores = Parallel(n_jobs=n_jobs)()
                delayed(objective_func)(params) for params in combinations
            )
            
            self.results = list(zip(combinations, scores)
        
        # Sort by score
        self.results.sort(key=lambda x: x[1], reverse=True)
        
        return self.results[0]


class RandomSearchOptimizer:
    """Random search optimization"""
    
    def __init__(self, param_distributions: Dict[str, Any], n_iter: int = 100):
        self.param_distributions = param_distributions
        self.n_iter = n_iter
        self.results = []
        
    def sample_params(self):
        """Sample parameters from distributions"""
        params = {}
        
        for param, dist in self.param_distributions.items():
            if hasattr(dist, 'rvs'):
                # Scipy distribution
                params[param] = dist.rvs()
            elif isinstance(dist, list):
                # List of choices
                params[param] = np.random.choice(dist)
            elif isinstance(dist, tuple) and len(dist) == 2:
                # Range
                if isinstance(dist[0], int):
                    params[param] = np.random.randint(dist[0], dist[1] + 1)
                else:
                    params[param] = np.random.uniform(dist[0], dist[1])
            else:
                params[param] = dist
                
        return params
    
    def search(self, objective_func: Callable):
        """Perform random search"""
        print(f"Random search: {self.n_iter} iterations")
        
        for i in range(self.n_iter):
            params = self.sample_params()
            score = objective_func(params)
            self.results.append((params, score)
            
            if (i + 1) % 10 == 0:
                print(f"  Progress: {i+1}/{self.n_iter}, Best: {max(r[1] for r in self.results):.4f}")
        
        # Sort by score
        self.results.sort(key=lambda x: x[1], reverse=True)
        
        return self.results[0]


class GeneticOptimizer:
    """Genetic algorithm for hyperparameter optimization"""
    
    def __init__(self, bounds: Dict[str, Tuple], population_size: int = 50, 
                 generations: int = 100, mutation_rate: float = 0.1):
        self.bounds = bounds
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.param_names = list(bounds.keys()
        
    def create_individual(self):
        """Create random individual"""
        individual = []
        
        for param in self.param_names:
            low, high = self.bounds[param]
            if isinstance(low, int) and isinstance(high, int):
                value = np.random.randint(low, high + 1)
            else:
                value = np.random.uniform(low, high)
            individual.append(value)
            
        return np.array(individual)
    
    def crossover(self, parent1, parent2):
        """Crossover two parents"""
        alpha = np.random.random()
        child = alpha * parent1 + (1 - alpha) * parent2
        
        # Handle integer parameters
        for i, param in enumerate(self.param_names):
            low, high = self.bounds[param]
            if isinstance(low, int) and isinstance(high, int):
                child[i] = int(child[i])
                
        return child
    
    def mutate(self, individual):
        """Mutate individual"""
        for i, param in enumerate(self.param_names):
            if np.random.random() < self.mutation_rate:
                low, high = self.bounds[param]
                if isinstance(low, int) and isinstance(high, int):
                    individual[i] = np.random.randint(low, high + 1)
                else:
                    individual[i] = np.random.uniform(low, high)
                    
        return individual
    
    def search(self, objective_func: Callable):
        """Perform genetic algorithm search"""
        print(f"Genetic algorithm: {self.population_size} population, {self.generations} generations")
        
        # Initialize population
        population = [self.create_individual() for _ in range(self.population_size)]
        
        best_score = -np.inf
        best_individual = None
        
        for generation in range(self.generations):
            # Evaluate fitness
            fitness_scores = []
            for individual in population:
                params = dict(zip(self.param_names, individual)
                score = objective_func(params)
                fitness_scores.append(score)
                
                if score > best_score:
                    best_score = score
                    best_individual = individual.copy()
            
            # Selection (tournament)
            new_population = []
            for _ in range(self.population_size):
                tournament_size = 5
                tournament_indices = np.random.choice(self.population_size, tournament_size)
                tournament_fitness = [fitness_scores[i] for i in tournament_indices]
                winner_idx = tournament_indices[np.argmax(tournament_fitness)]
                new_population.append(population[winner_idx].copy()
            
            # Crossover and mutation
            for i in range(0, self.population_size - 1, 2):
                if np.random.random() < 0.8:  # Crossover probability
                    child1 = self.crossover(new_population[i], new_population[i + 1])
                    child2 = self.crossover(new_population[i + 1], new_population[i])
                    new_population[i] = self.mutate(child1)
                    new_population[i + 1] = self.mutate(child2)
            
            population = new_population
            
            if (generation + 1) % 10 == 0:
                print(f"  Generation {generation + 1}, Best score: {best_score:.4f}")
        
        best_params = dict(zip(self.param_names, best_individual)
        return best_params, best_score


class HyperparameterTuner:
    """Main hyperparameter tuning system"""
    
    def __init__(self, model_class, feature_engineer=None):
        self.model_class = model_class
        self.feature_engineer = feature_engineer or LightweightFeatureEngineering()
        self.best_params = None
        self.best_score = None
        self.optimization_history = []
        
    def create_objective_function(self, X_train, y_train, X_val, y_val, 
                                metric='accuracy', cv_folds=None):
        """Create objective function for optimization"""
        
        def objective(params):
            # Handle parameter types
            processed_params = {}
            for key, value in params.items():
                if key in ['n_estimators', 'max_depth', 'min_samples_split', 
                          'min_samples_leaf', 'random_state']:
                    processed_params[key] = int(value)
                else:
                    processed_params[key] = value
            
            try:
                # Create model with parameters
                if self.model_class == RandomForestClassifier:
                    model = RandomForestClassifier(**processed_params)
                elif self.model_class == GradientBoostingClassifier:
                    model = GradientBoostingClassifier(**processed_params)
                else:
                    model = self.model_class(**processed_params)
                
                if cv_folds:
                    # Cross-validation
                    tscv = TimeSeriesSplit(n_splits=cv_folds)
                    scores = cross_val_score(model, X_train, y_train, cv=tscv, scoring=metric)
                    score = np.mean(scores)
                else:
                    # Single validation set
                    model.fit(X_train, y_train)
                    y_pred = model.predict(X_val)
                    
                    if metric == 'accuracy':
                        score = accuracy_score(y_val, y_pred)
                    elif metric == 'precision':
                        score = precision_score(y_val, y_pred, average='weighted')
                    elif metric == 'recall':
                        score = recall_score(y_val, y_pred, average='weighted')
                    elif metric == 'f1':
                        score = f1_score(y_val, y_pred, average='weighted')
                    else:
                        score = accuracy_score(y_val, y_pred)
                
                # Store in history
                self.optimization_history.append({)
                    'params': processed_params,
                    'score': score,
                    'timestamp': datetime.now()
                })
                
                return score
                
            except Exception as e:
                print(f"Error with params {processed_params}: {e}")
                return 0.0
        
        return objective
    
    def optimize(self, X_train, y_train, X_val, y_val, param_space, 
                method='random', metric='accuracy', n_iter=50, n_jobs=1):
        """
        Optimize hyperparameters
        
        Args:
            X_train, y_train: Training data
            X_val, y_val: Validation data
            param_space: Parameter search space
            method: 'grid', 'random', 'bayesian', 'genetic'
            metric: Evaluation metric
            n_iter: Number of iterations
            n_jobs: Number of parallel jobs
        """
        print(f"\n🔧 Hyperparameter Optimization")
        print(f"  Method: {method}")
        print(f"  Metric: {metric}")
        print(f"  Model: {self.model_class.__name__}")
        
        # Create objective function
        objective_func = self.create_objective_function()
            X_train, y_train, X_val, y_val, metric
        )
        
        # Run optimization
        if method == 'grid':
            optimizer = GridSearchOptimizer(param_space)
            best_params, best_score = optimizer.search(objective_func, n_jobs)
            
        elif method == 'random':
            optimizer = RandomSearchOptimizer(param_space, n_iter)
            best_params, best_score = optimizer.search(objective_func)
            
        elif method == 'bayesian':
            # Convert param space to bounds
            bounds = {}
            for param, space in param_space.items():
                if isinstance(space, list):
                    bounds[param] = (0, len(space) - 1)
                elif isinstance(space, tuple):
                    bounds[param] = space
                else:
                    bounds[param] = (space, space)
                    
            optimizer = BayesianOptimizer(bounds, n_calls=n_iter)
            
            best_score = -np.inf
            best_params = None
            
            for i in range(n_iter):
                # Get suggestion
                x = optimizer.suggest_next()
                
                # Convert to params dict
                params = {}
                for j, param in enumerate(bounds.keys():
                    if param in param_space and isinstance(param_space[param], list):
                        params[param] = param_space[param][int(x[j])]
                    else:
                        params[param] = x[j]
                
                # Evaluate
                score = objective_func(params)
                optimizer.update(x, score)
                
                if score > best_score:
                    best_score = score
                    best_params = params
                    
                if (i + 1) % 10 == 0:
                    print(f"  Progress: {i+1}/{n_iter}, Best: {best_score:.4f}")
                    
        elif method == 'genetic':
            # Convert param space to bounds
            bounds = {}
            for param, space in param_space.items():
                if isinstance(space, list):
                    bounds[param] = (0, len(space) - 1)
                elif isinstance(space, tuple):
                    bounds[param] = space
                else:
                    bounds[param] = (space, space)
                    
            optimizer = GeneticOptimizer(bounds, generations=n_iter)
            best_params, best_score = optimizer.search(objective_func)
            
        else:
            raise ValueError(f"Unknown optimization method: {method}")
        
        self.best_params = best_params
        self.best_score = best_score
        
        print(f"\n✅ Optimization Complete!")
        print(f"  Best Score: {best_score:.4f}")
        print(f"  Best Parameters: {best_params}")
        
        return best_params, best_score
    
    def get_optimization_report(self):
        """Generate optimization report"""
        if not self.optimization_history:
            return None
            
        # Convert to DataFrame
        df = pd.DataFrame(self.optimization_history)
        
        # Top 10 configurations
        top_10 = df.nlargest(10, 'score')
        
        # Parameter importance
        param_importance = {}
        if len(df) > 10:
            for param in self.best_params.keys():
                if param in df.iloc[0]['params']:
                    values = [row['params'].get(param, None) for _, row in df.iterrows()]
                    scores = df['score'].values
                    
                    # Calculate correlation if numeric
                    if all(isinstance(v, (int, float) for v in values if v is not None):)
                        correlation = np.corrcoef(values, scores)[0, 1]
                        param_importance[param] = abs(correlation)
        
        report = {}
            'total_evaluations': len(df),
            'best_score': self.best_score,
            'best_params': self.best_params,
            'top_10_configs': top_10.to_dict('records'),
            'param_importance': param_importance,
            'score_distribution': {}
                'mean': df['score'].mean(),
                'std': df['score'].std(),
                'min': df['score'].min(),
                'max': df['score'].max()
            }
        }
        
        return report


class AutoMLTuner:
    """Automated machine learning with hyperparameter tuning"""
    
    def __init__(self):
        self.models = {}
            'RandomForest': {}
                'class': RandomForestClassifier,
                'param_space': {}
                    'n_estimators': [50, 100, 200],
                    'max_depth': [5, 10, 20, None],
                    'min_samples_split': [2, 5, 10],
                    'min_samples_leaf': [1, 2, 4],
                    'max_features': ['sqrt', 'log2', None]
                }
            },
            'GradientBoosting': {}
                'class': GradientBoostingClassifier,
                'param_space': {}
                    'n_estimators': [50, 100, 200],
                    'learning_rate': [0.01, 0.1, 0.3],
                    'max_depth': [3, 5, 7],
                    'min_samples_split': [2, 5, 10],
                    'subsample': [0.8, 0.9, 1.0]
                }
            }
        }
        self.results = {}
        
    def run_automl(self, X_train, y_train, X_val, y_val, 
                  time_budget_minutes=30, method='random'):
        """
        Run AutoML with time budget
        
        Args:
            X_train, y_train: Training data
            X_val, y_val: Validation data  
            time_budget_minutes: Time budget in minutes
            method: Optimization method
        """
        print(f"\n🤖 AutoML Pipeline")
        print(f"  Time Budget: {time_budget_minutes} minutes")
        print(f"  Models: {list(self.models.keys()}")
        
        start_time = datetime.now()
        time_per_model = time_budget_minutes / len(self.models)
        
        for model_name, model_config in self.models.items():
            print(f"\n📊 Optimizing {model_name}...")
            
            # Calculate iterations based on time budget
            if method == 'grid':
                n_iter = 1000  # Grid search handles its own iterations
            else:
                # Estimate time per iteration (roughly 10 seconds)
                n_iter = int(time_per_model * 60 / 10)
            
            tuner = HyperparameterTuner(model_config['class'])
            
            best_params, best_score = tuner.optimize()
                X_train, y_train, X_val, y_val,
                model_config['param_space'],
                method=method,
                n_iter=n_iter
            )
            
            self.results[model_name] = {}
                'best_params': best_params,
                'best_score': best_score,
                'optimization_report': tuner.get_optimization_report()
            }
            
            # Check time budget
            elapsed = (datetime.now() - start_time).total_seconds() / 60
            if elapsed > time_budget_minutes:
                print(f"\n⏰ Time budget exceeded ({elapsed:.1f} minutes)")
                break
        
        # Find best model
        best_model = max(self.results.items(), key=lambda x: x[1]['best_score'])
        
        print(f"\n🏆 Best Model: {best_model[0]}")
        print(f"  Score: {best_model[1]['best_score']:.4f}")
        print(f"  Parameters: {best_model[1]['best_params']}")
        
        return self.results


def demo_hyperparameter_tuning():
    """Demo hyperparameter tuning system"""
    print("="*80)
    print("🔧 HYPERPARAMETER TUNING DEMO")
    print("="*80)
    
    # Generate synthetic data
    np.random.seed(42)
    n_samples = 1000
    n_features = 20
    
    X = np.random.randn(n_samples, n_features)
    # Create non-linear target
    y = (X[:, 0] * X[:, 1] + X[:, 2]**2 - X[:, 3] > 0).astype(int)
    
    # Add noise
    noise_idx = np.random.choice(n_samples, size=int(0.1 * n_samples), replace=False)
    y[noise_idx] = 1 - y[noise_idx]
    
    # Split data
    train_size = int(0.6 * n_samples)
    val_size = int(0.2 * n_samples)
    
    X_train = X[:train_size]
    y_train = y[:train_size]
    X_val = X[train_size:train_size + val_size]
    y_val = y[train_size:train_size + val_size]
    X_test = X[train_size + val_size:]
    y_test = y[train_size + val_size:]
    
    print(f"\n📊 Dataset:")
    print(f"  Training: {len(X_train)} samples")
    print(f"  Validation: {len(X_val)} samples")
    print(f"  Test: {len(X_test)} samples")
    print(f"  Features: {n_features}")
    print(f"  Classes: {len(np.unique(y)}")
    
    # 1. Grid Search
    print("\n1️⃣ Grid Search Optimization")
    tuner_grid = HyperparameterTuner(RandomForestClassifier)
    
    param_grid = {}
        'n_estimators': [50, 100],
        'max_depth': [5, 10],
        'min_samples_split': [2, 5]
    }
    
    best_params_grid, best_score_grid = tuner_grid.optimize()
        X_train, y_train, X_val, y_val,
        param_grid,
        method='grid',
        n_jobs=1
    )
    
    # 2. Random Search
    print("\n2️⃣ Random Search Optimization")
    tuner_random = HyperparameterTuner(RandomForestClassifier)
    
    param_distributions = {}
        'n_estimators': (50, 200),
        'max_depth': (3, 20),
        'min_samples_split': (2, 20),
        'min_samples_leaf': (1, 10)
    }
    
    best_params_random, best_score_random = tuner_random.optimize()
        X_train, y_train, X_val, y_val,
        param_distributions,
        method='random',
        n_iter=30
    )
    
    # 3. Genetic Algorithm
    print("\n3️⃣ Genetic Algorithm Optimization")
    tuner_genetic = HyperparameterTuner(GradientBoostingClassifier)
    
    param_bounds = {}
        'n_estimators': (50, 200),
        'learning_rate': (0.01, 0.3),
        'max_depth': (3, 10)
    }
    
    best_params_genetic, best_score_genetic = tuner_genetic.optimize()
        X_train, y_train, X_val, y_val,
        param_bounds,
        method='genetic',
        n_iter=20
    )
    
    # 4. AutoML
    print("\n4️⃣ AutoML Pipeline")
    automl = AutoMLTuner()
    
    automl_results = automl.run_automl()
        X_train, y_train, X_val, y_val,
        time_budget_minutes=2,  # Quick demo
        method='random'
    )
    
    # Summary
    print("\n" + "="*80)
    print("📊 OPTIMIZATION RESULTS SUMMARY")
    print("="*80)
    
    print(f"\n🎯 Best Scores:")
    print(f"  Grid Search: {best_score_grid:.4f}")
    print(f"  Random Search: {best_score_random:.4f}")
    print(f"  Genetic Algorithm: {best_score_genetic:.4f}")
    print(f"  AutoML Best: {max(r['best_score'] for r in automl_results.values():.4f}")
    
    # Test set evaluation
    print(f"\n🧪 Test Set Evaluation:")
    
    # Train best model on full training data
    best_model = RandomForestClassifier(**best_params_random)
    best_model.fit(X_train, y_train)
    test_score = best_model.score(X_test, y_test)
    
    print(f"  Test Accuracy: {test_score:.4f}")
    
    # Save results
    results_summary = {}
        'grid_search': {}
            'best_params': best_params_grid,
            'best_score': best_score_grid
        },
        'random_search': {}
            'best_params': best_params_random,
            'best_score': best_score_random
        },
        'genetic_algorithm': {}
            'best_params': best_params_genetic,
            'best_score': best_score_genetic
        },
        'automl': automl_results,
        'test_score': test_score
    }
    
    with open('hyperparameter_tuning_results.json', 'w') as f:
        json.dump(results_summary, f, indent=2, default=str)
    
    print(f"\n💾 Results saved to: hyperparameter_tuning_results.json")
    
    return results_summary


def main():
    """Run hyperparameter tuning demo"""
    results = demo_hyperparameter_tuning()
    
    print("\n✅ Hyperparameter Tuning Complete!")
    
    print("\n🚀 Key Capabilities:")
    print("  • Grid Search - Exhaustive parameter search")
    print("  • Random Search - Efficient sampling")
    print("  • Bayesian Optimization - Smart exploration")
    print("  • Genetic Algorithm - Evolutionary optimization")
    print("  • AutoML - Automated model selection")
    print("  • Time-based budgeting")
    print("  • Parallel execution support")
    print("  • Comprehensive reporting")
    
    print("\n💡 Integration with Trading System:")
    print("  • Optimize ML trading models")
    print("  • Tune technical indicators")
    print("  • Find best feature combinations")
    print("  • Optimize risk parameters")
    print("  • Continuous model improvement")


if __name__ == "__main__":
    from scipy.stats import norm
    main()