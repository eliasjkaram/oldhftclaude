
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Quick test of the orchestrator with historical data features
"""

# Alpaca imports

import logging
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import sys
import os
from datetime import datetime, timedelta
import random

# Add project path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the historical testing system
from historical_data_testing_system import ()
    HistoricalDataTestingSystem,
    MarketStatusDetector,
    HistoricalDataManager
)

# Simple test algorithms
# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class SimpleMovingAverageAlgo:
    def __init__(self):
    try:
            self.name = "SMA_Algo"
            self.positions = {}
        
        async def analyze(self, data):
            """Simple moving average crossover"""
            if len(data) < 50:
                return None
            
            sma_20 = data['close'].rolling(20).mean().iloc[-1]
            sma_50 = data['close'].rolling(50).mean().iloc[-1]
            current_price = data['close'].iloc[-1]
        
            if sma_20 > sma_50:
                return {'action': 'buy', 'confidence': 0.7}
            else:
                return {'action': 'sell', 'confidence': 0.7}
    
        async def execute_trade(self, symbol, action, quantity):
            """Execute a trade"""
            logger.info(f"  {self.name}: {action} {quantity} shares of {symbol}")
            self.positions[symbol] = self.positions.get(symbol, 0) + (quantity if action == 'buy' else -quantity)

    class MomentumAlgo:
        def __init__(self):
            self.name = "Momentum_Algo"
            self.positions = {}
        
        async def analyze(self, data):
            """Momentum based strategy"""
            if len(data) < 10:
                return None
            
            returns = data['close'].pct_change()
            momentum = returns.rolling(10).mean().iloc[-1]
        
            if momentum > 0.001:
                return {'action': 'buy', 'confidence': 0.6}
            elif momentum < -0.001:
                return {'action': 'sell', 'confidence': 0.6}
            else:
                return {'action': 'hold', 'confidence': 0.5}
    
        async def execute_trade(self, symbol, action, quantity):
            """Execute a trade"""
            logger.info(f"  {self.name}: {action} {quantity} shares of {symbol}")
            self.positions[symbol] = self.positions.get(symbol, 0) + (quantity if action == 'buy' else -quantity)

    async def main():
        logger.info("🚀 Testing Enhanced Orchestrator with Historical Data")
        logger.info("=" * 60)
    
        # Check market status
        logger.info("\n📊 Checking Market Status...")
        market_detector = MarketStatusDetector()
        is_open, reason = await market_detector.is_market_open()
    
        logger.info(f"Market Open: {is_open}")
        logger.info(f"Reason: {reason}")
    
        # Initialize testing system
        logger.info("\n🔧 Initializing Historical Testing System...")
        testing_system = HistoricalDataTestingSystem()
            data_sources=['yfinance'],  # Use yfinance for simplicity
            cache_dir='./cache/historical_test'
        )
    
        # Register algorithms
        sma_algo = SimpleMovingAverageAlgo()
        momentum_algo = MomentumAlgo()
    
        testing_system.register_algorithm('sma', sma_algo)
        testing_system.register_algorithm('momentum', momentum_algo)
    
        # Determine mode
        if is_open:
            logger.info("\n📈 Market is OPEN - Using live data mode")
            mode = 'live'
        else:
            logger.info("\n📅 Market is CLOSED - Using historical data mode")
            mode = 'historical'
    
        # Run a short test
        logger.info(f"\n🏃 Running 2-minute test in {mode.upper()} mode...")
    
        if mode == 'historical':
            # Get a random 5-day period from 2022-2023
            data_manager = HistoricalDataManager()
            period = data_manager.get_random_period(year_range=(2022, 2023))
            logger.info(f"Selected Period: {period['start_date']} to {period['end_date']}")
            logger.info(f"Trading Days: {period['trading_days']}")
    
        # Run testing session
        logger.info("\n📊 Starting testing session...")
        session = await testing_system.run_testing_session()
            duration_minutes=2,
            symbols=['SPY', 'AAPL', 'MSFT'],
            mode='historical' if not is_open else 'live'
        )
    
        # Display results
        logger.info("\n📈 Testing Results:")
        logger.info(f"Mode: {session.mode}")
        logger.info(f"Start: {session.start_time}")
        logger.info(f"End: {session.end_time}")
    
        if hasattr(session, 'historical_period'):
            logger.info(f"Historical Period: {session.historical_period['start_date']} to {session.historical_period['end_date']}")
    
        logger.info(f"\n💰 Performance Metrics:")
        metrics = session.performance_metrics
        logger.info(f"Total Trades: {metrics.get('total_trades', 0)}")
        logger.info(f"Win Rate: {metrics.get('win_rate', 0):.2%}")
        logger.info(f"Total Return: {metrics.get('total_return', 0):.2%}")
        logger.info(f"Sharpe Ratio: {metrics.get('sharpe_ratio', 0):.2f}")
        logger.info(f"Max Drawdown: {metrics.get('max_drawdown', 0):.2%}")
    
        logger.info("\n📊 Algorithm Performance:")
        for algo_name, algo_metrics in metrics.get('by_algorithm', {}).items():
            logger.info(f"\n{algo_name}:")
            logger.info(f"  Trades: {algo_metrics.get('trades', 0)}")
            logger.info(f"  Return: {algo_metrics.get('return', 0):.2%}")
    
        # Show positions
        logger.info("\n📈 Final Positions:")
        logger.info(f"SMA Algo: {sma_algo.positions}")
        logger.info(f"Momentum Algo: {momentum_algo.positions}")
    
        logger.info("\n✅ Test Complete!")
    
        # Cleanup recommendation
        if not is_open:
            logger.info("\n💡 Tip: Since markets are closed, the system used historical data.")
            logger.info("This is perfect for testing and training algorithms 24/7!")

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in __init__: {str(e)}")
        raise
    asyncio.run(main())