"""
Strategy P&L Attribution System

Comprehensive P&L attribution system that:
- Decomposes P&L by various factors
- Performs trade-level attribution
- Analyzes strategy performance drivers
- Provides risk-adjusted metrics
- Generates detailed attribution reports
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass, field
from enum import Enum
import logging
from datetime import datetime, timedelta
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import PCA
import warnings
import json
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class AttributionType(Enum):
    """Types of P&L attribution"""
    TRADE_LEVEL = "trade_level"
    TIME_BASED = "time_based"
    FACTOR_BASED = "factor_based"
    STRATEGY_COMPONENT = "strategy_component"
    RISK_FACTOR = "risk_factor"
    MARKET_IMPACT = "market_impact"
    ALPHA_BETA = "alpha_beta"


class PerformanceMetric(Enum):
    """Performance metrics"""
    TOTAL_RETURN = "total_return"
    SHARPE_RATIO = "sharpe_ratio"
    SORTINO_RATIO = "sortino_ratio"
    CALMAR_RATIO = "calmar_ratio"
    INFORMATION_RATIO = "information_ratio"
    MAX_DRAWDOWN = "max_drawdown"
    WIN_RATE = "win_rate"
    PROFIT_FACTOR = "profit_factor"


@dataclass
class Trade:
    """Trade information"""
    trade_id: str
    symbol: str
    entry_time: datetime
    exit_time: datetime
    entry_price: float
    exit_price: float
    quantity: float
    side: str  # 'long' or 'short'
    pnl: float
    fees: float = 0.0
    strategy_component: Optional[str] = None
    signals: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Position:
    """Current position information"""
    symbol: str
    quantity: float
    avg_price: float
    current_price: float
    unrealized_pnl: float
    realized_pnl: float
    entry_time: datetime
    strategy_component: Optional[str] = None


@dataclass
class AttributionResult:
    """P&L attribution result"""
    attribution_type: AttributionType
    period_start: datetime
    period_end: datetime
    total_pnl: float
    components: Dict[str, float]
    statistics: Dict[str, float]
    confidence_intervals: Optional[Dict[str, Tuple[float, float]]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PerformanceAnalysis:
    """Strategy performance analysis"""
    period_start: datetime
    period_end: datetime
    total_return: float
    annualized_return: float
    volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    win_rate: float
    profit_factor: float
    trades_count: int
    attribution_summary: Dict[str, float]


class TradeLevelAttribution:
    """Trade-level P&L attribution"""
    
    def __init__(self):
        self.trades: List[Trade] = []
        
    def add_trade(self, trade: Trade):
        """Add trade to analysis"""
        self.trades.append(trade)
        
    def calculate_attribution(self) -> AttributionResult:
        """Calculate trade-level attribution"""
        if not self.trades:
            return self._empty_result()
            
        # Group by various dimensions
        by_symbol = defaultdict(float)
        by_side = defaultdict(float)
        by_strategy = defaultdict(float)
        by_duration = defaultdict(float)
        by_time_of_day = defaultdict(float)
        by_day_of_week = defaultdict(float)
        
        total_pnl = 0
        winning_trades = 0
        losing_trades = 0
        
        for trade in self.trades:
            pnl = trade.pnl - trade.fees
            total_pnl += pnl
            
            # By symbol
            by_symbol[trade.symbol] += pnl
            
            # By side
            by_side[trade.side] += pnl
            
            # By strategy component
            if trade.strategy_component:
                by_strategy[trade.strategy_component] += pnl
            else:
                by_strategy['unspecified'] += pnl
                
            # By holding duration
            duration = (trade.exit_time - trade.entry_time).total_seconds() / 3600  # hours
            if duration < 1:
                by_duration['< 1 hour'] += pnl
            elif duration < 24:
                by_duration['1-24 hours'] += pnl
            elif duration < 168:  # 1 week
                by_duration['1-7 days'] += pnl
            else:
                by_duration['> 7 days'] += pnl
                
            # By time of day
            hour = trade.entry_time.hour
            if hour < 12:
                by_time_of_day['morning'] += pnl
            elif hour < 16:
                by_time_of_day['afternoon'] += pnl
            else:
                by_time_of_day['evening'] += pnl
                
            # By day of week
            by_day_of_week[trade.entry_time.strftime('%A')] += pnl
            
            # Win/loss tracking
            if pnl > 0:
                winning_trades += 1
            else:
                losing_trades += 1
                
        # Calculate statistics
        win_rate = winning_trades / len(self.trades) if self.trades else 0
        avg_win = sum(t.pnl for t in self.trades if t.pnl > 0) / max(winning_trades, 1)
        avg_loss = sum(t.pnl for t in self.trades if t.pnl < 0) / max(losing_trades, 1)
        profit_factor = abs(avg_win * winning_trades / (avg_loss * losing_trades)) if losing_trades > 0 else float('inf')
        
        components = {}
            'by_symbol': dict(by_symbol),
            'by_side': dict(by_side),
            'by_strategy': dict(by_strategy),
            'by_duration': dict(by_duration),
            'by_time_of_day': dict(by_time_of_day),
            'by_day_of_week': dict(by_day_of_week)
        }
        
        statistics = {}
            'total_trades': len(self.trades),
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'average_win': avg_win,
            'average_loss': avg_loss,
            'profit_factor': profit_factor,
            'avg_trade_pnl': total_pnl / len(self.trades) if self.trades else 0
        }
        
        return AttributionResult()
            attribution_type=AttributionType.TRADE_LEVEL,
            period_start=min(t.entry_time for t in self.trades),
            period_end=max(t.exit_time for t in self.trades),
            total_pnl=total_pnl,
            components=components,
            statistics=statistics
        )
        
    def _empty_result(self) -> AttributionResult:
        """Return empty result"""
        return AttributionResult()
            attribution_type=AttributionType.TRADE_LEVEL,
            period_start=datetime.now(),
            period_end=datetime.now(),
            total_pnl=0,
            components={},
            statistics={}
        )


class FactorBasedAttribution:
    """Factor-based P&L attribution"""
    
    def __init__(self, factors: List[str]):
        self.factors = factors
        self.returns: pd.Series = pd.Series()
        self.factor_returns: pd.DataFrame = pd.DataFrame()
        self.positions: pd.DataFrame = pd.DataFrame()
        
    def update_data(self, returns: pd.Series, factor_returns: pd.DataFrame,
                   positions: pd.DataFrame):
        """Update data for attribution"""
        self.returns = returns
        self.factor_returns = factor_returns
        self.positions = positions
        
    def calculate_attribution(self) -> AttributionResult:
        """Calculate factor-based attribution"""
        if self.returns.empty or self.factor_returns.empty:
            return self._empty_result()
            
        # Align data
        common_dates = self.returns.index.intersection(self.factor_returns.index)
        if self.positions is not None and not self.positions.empty:
            common_dates = common_dates.intersection(self.positions.index)
            
        returns = self.returns.loc[common_dates]
        factor_returns = self.factor_returns.loc[common_dates]
        
        # Factor regression
        X = factor_returns.values
        y = returns.values
        
        # Add intercept
        X_with_intercept = np.column_stack([np.ones(len(X)), X])
        
        # Regression
        model = LinearRegression(fit_intercept=False)
        model.fit(X_with_intercept, y)
        
        # Get coefficients
        alpha = model.coef_[0]
        betas = model.coef_[1:]
        
        # Calculate factor contributions
        factor_contributions = {}
        for i, factor in enumerate(self.factors):
            factor_contribution = betas[i] * factor_returns[factor].sum()
            factor_contributions[factor] = factor_contribution
            
        # Alpha contribution
        factor_contributions['alpha'] = alpha * len(returns)
        
        # Residual
        predicted_returns = model.predict(X_with_intercept)
        residual = (returns - predicted_returns).sum()
        factor_contributions['residual'] = residual
        
        # Calculate R-squared
        ss_res = np.sum((returns - predicted_returns) ** 2)
        ss_tot = np.sum((returns - returns.mean()) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
        
        # Statistics
        statistics = {}
            'r_squared': r_squared,
            'alpha': alpha,
            'alpha_t_stat': self._calculate_t_stat(alpha, returns, predicted_returns, 0),
            'total_observations': len(returns)
        }
        
        # Add beta statistics
        for i, factor in enumerate(self.factors):
            statistics[f'{factor}_beta'] = betas[i]
            statistics[f'{factor}_t_stat'] = self._calculate_t_stat()
                betas[i], returns, predicted_returns, i + 1
            )
            
        return AttributionResult()
            attribution_type=AttributionType.FACTOR_BASED,
            period_start=returns.index[0],
            period_end=returns.index[-1],
            total_pnl=returns.sum(),
            components=factor_contributions,
            statistics=statistics
        )
        
    def _calculate_t_stat(self, coefficient: float, actual: pd.Series,
                         predicted: np.ndarray, coef_index: int) -> float:
        """Calculate t-statistic for coefficient"""
        n = len(actual)
        k = len(self.factors) + 1  # Including intercept
        
        if n <= k:
            return 0
            
        residuals = actual - predicted
        mse = np.sum(residuals ** 2) / (n - k)
        
        # Standard error (simplified)
        se = np.sqrt(mse / n)
        
        return coefficient / se if se > 0 else 0
        
    def _empty_result(self) -> AttributionResult:
        """Return empty result"""
        return AttributionResult()
            attribution_type=AttributionType.FACTOR_BASED,
            period_start=datetime.now(),
            period_end=datetime.now(),
            total_pnl=0,
            components={},
            statistics={}
        )


class TimeBasedAttribution:
    """Time-based P&L attribution"""
    
    def __init__(self):
        self.daily_pnl: pd.Series = pd.Series()
        self.positions: pd.DataFrame = pd.DataFrame()
        
    def update_data(self, daily_pnl: pd.Series, positions: Optional[pd.DataFrame] = None):
        """Update data for attribution"""
        self.daily_pnl = daily_pnl
        self.positions = positions if positions is not None else pd.DataFrame()
        
    def calculate_attribution(self) -> AttributionResult:
        """Calculate time-based attribution"""
        if self.daily_pnl.empty:
            return self._empty_result()
            
        # By month
        by_month = self.daily_pnl.resample('M').sum()
        
        # By quarter
        by_quarter = self.daily_pnl.resample('Q').sum()
        
        # By day of week
        by_dow = self.daily_pnl.groupby(self.daily_pnl.index.day_name()).sum()
        
        # By market regime (simplified - based on volatility)
        rolling_vol = self.daily_pnl.rolling(20).std()
        high_vol_days = rolling_vol > rolling_vol.median()
        
        by_volatility = {}
            'high_volatility': self.daily_pnl[high_vol_days].sum(),
            'low_volatility': self.daily_pnl[~high_vol_days].sum()
        }
        
        # Intraday vs overnight (if we have position data)
        by_session = {'intraday': 0, 'overnight': 0}
        if not self.positions.empty and 'session' in self.positions.columns:
            for session in ['intraday', 'overnight']:
                mask = self.positions['session'] == session
                by_session[session] = self.daily_pnl[mask].sum()
                
        components = {}
            'by_month': by_month.to_dict(),
            'by_quarter': by_quarter.to_dict(),
            'by_day_of_week': by_dow.to_dict(),
            'by_volatility_regime': by_volatility,
            'by_session': by_session
        }
        
        # Calculate statistics
        statistics = {}
            'total_days': len(self.daily_pnl),
            'positive_days': (self.daily_pnl > 0).sum(),
            'negative_days': (self.daily_pnl < 0).sum(),
            'win_rate_daily': (self.daily_pnl > 0).sum() / len(self.daily_pnl),
            'avg_daily_pnl': self.daily_pnl.mean(),
            'daily_volatility': self.daily_pnl.std(),
            'best_day': self.daily_pnl.max(),
            'worst_day': self.daily_pnl.min(),
            'skewness': stats.skew(self.daily_pnl),
            'kurtosis': stats.kurtosis(self.daily_pnl)
        }
        
        return AttributionResult()
            attribution_type=AttributionType.TIME_BASED,
            period_start=self.daily_pnl.index[0],
            period_end=self.daily_pnl.index[-1],
            total_pnl=self.daily_pnl.sum(),
            components=components,
            statistics=statistics
        )
        
    def _empty_result(self) -> AttributionResult:
        """Return empty result"""
        return AttributionResult()
            attribution_type=AttributionType.TIME_BASED,
            period_start=datetime.now(),
            period_end=datetime.now(),
            total_pnl=0,
            components={},
            statistics={}
        )


class RiskAdjustedAttribution:
    """Risk-adjusted P&L attribution"""
    
    def __init__(self):
        self.returns: pd.Series = pd.Series()
        self.positions: pd.DataFrame = pd.DataFrame()
        self.risk_limits: Dict[str, float] = {}
        
    def update_data(self, returns: pd.Series, positions: pd.DataFrame,
                   risk_limits: Optional[Dict[str, float]] = None):
        """Update data for attribution"""
        self.returns = returns
        self.positions = positions
        self.risk_limits = risk_limits or {}
        
    def calculate_metrics(self) -> PerformanceAnalysis:
        """Calculate risk-adjusted performance metrics"""
        if self.returns.empty:
            return self._empty_analysis()
            
        # Basic metrics
        total_return = (1 + self.returns).prod() - 1
        days = len(self.returns)
        years = days / 252
        annualized_return = (1 + total_return) ** (1 / years) - 1 if years > 0 else 0
        
        # Volatility
        daily_vol = self.returns.std()
        annual_vol = daily_vol * np.sqrt(252)
        
        # Sharpe ratio
        risk_free_rate = 0.02  # Assumed
        excess_returns = self.returns - risk_free_rate / 252
        sharpe = np.sqrt(252) * excess_returns.mean() / self.returns.std() if daily_vol > 0 else 0
        
        # Sortino ratio
        downside_returns = self.returns[self.returns < 0]
        downside_vol = downside_returns.std() * np.sqrt(252)
        sortino = annualized_return / downside_vol if downside_vol > 0 else 0
        
        # Maximum drawdown
        cum_returns = (1 + self.returns).cumprod()
        running_max = cum_returns.expanding().max()
        drawdown = (cum_returns - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # Win rate and profit factor
        winning_days = (self.returns > 0).sum()
        total_days = len(self.returns)
        win_rate = winning_days / total_days if total_days > 0 else 0
        
        avg_win = self.returns[self.returns > 0].mean() if winning_days > 0 else 0
        avg_loss = self.returns[self.returns < 0].mean() if (total_days - winning_days) > 0 else 0
        profit_factor = abs(avg_win * winning_days / (avg_loss * (total_days - winning_days))) \
                       if avg_loss != 0 and (total_days - winning_days) > 0 else float('inf')
                       
        # Attribution summary
        attribution_summary = {}
            'market_beta': self._calculate_market_beta(),
            'alpha': annualized_return - self._calculate_market_beta() * 0.08,  # Assumed market return
            'selection': 0,  # Placeholder
            'timing': 0,  # Placeholder
            'risk_management': 0  # Placeholder
        }
        
        return PerformanceAnalysis()
            period_start=self.returns.index[0],
            period_end=self.returns.index[-1],
            total_return=total_return,
            annualized_return=annualized_return,
            volatility=annual_vol,
            sharpe_ratio=sharpe,
            sortino_ratio=sortino,
            max_drawdown=max_drawdown,
            win_rate=win_rate,
            profit_factor=profit_factor,
            trades_count=0,  # Would be updated from trade data
            attribution_summary=attribution_summary
        )
        
    def _calculate_market_beta(self) -> float:
        """Calculate market beta (simplified)"""
        # In production, this would use actual market returns
        return 0.8  # Placeholder
        
    def _empty_analysis(self) -> PerformanceAnalysis:
        """Return empty analysis"""
        return PerformanceAnalysis()
            period_start=datetime.now(),
            period_end=datetime.now(),
            total_return=0,
            annualized_return=0,
            volatility=0,
            sharpe_ratio=0,
            sortino_ratio=0,
            max_drawdown=0,
            win_rate=0,
            profit_factor=0,
            trades_count=0,
            attribution_summary={}
        )


class StrategyPLAttributionSystem:
    """Complete strategy P&L attribution system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.trade_attribution = TradeLevelAttribution()
        self.factor_attribution = FactorBasedAttribution()
            config.get('factors', ['market', 'sector', 'momentum', 'value'])
        )
        self.time_attribution = TimeBasedAttribution()
        self.risk_attribution = RiskAdjustedAttribution()
        
        self.trades: List[Trade] = []
        self.positions: List[Position] = []
        self.daily_pnl: pd.Series = pd.Series()
        self.returns: pd.Series = pd.Series()
        self.factor_returns: pd.DataFrame = pd.DataFrame()
        
        self.attribution_results: List[AttributionResult] = []
        self.performance_history: List[PerformanceAnalysis] = []
        
    def add_trade(self, trade: Trade):
        """Add completed trade"""
        self.trades.append(trade)
        self.trade_attribution.add_trade(trade)
        logger.info(f"Added trade: {trade.trade_id} - P&L: {trade.pnl:.2f}")
        
    def update_daily_pnl(self, date: datetime, pnl: float):
        """Update daily P&L"""
        self.daily_pnl[date] = pnl
        
    def update_returns(self, returns: pd.Series):
        """Update returns data"""
        self.returns = returns
        self.time_attribution.update_data(returns * 10000)  # Convert to P&L
        self.risk_attribution.update_data(returns, pd.DataFrame())
        
    def update_factor_returns(self, factor_returns: pd.DataFrame):
        """Update factor returns"""
        self.factor_returns = factor_returns
        self.factor_attribution.update_data(self.returns, factor_returns, pd.DataFrame())
        
    def calculate_all_attributions(self) -> Dict[str, AttributionResult]:
        """Calculate all types of attribution"""
        results = {}
        
        # Trade-level attribution
        trade_result = self.trade_attribution.calculate_attribution()
        results['trade_level'] = trade_result
        self.attribution_results.append(trade_result)
        
        # Time-based attribution
        if not self.daily_pnl.empty:
            time_result = self.time_attribution.calculate_attribution()
            results['time_based'] = time_result
            self.attribution_results.append(time_result)
            
        # Factor-based attribution
        if not self.returns.empty and not self.factor_returns.empty:
            factor_result = self.factor_attribution.calculate_attribution()
            results['factor_based'] = factor_result
            self.attribution_results.append(factor_result)
            
        # Risk-adjusted metrics
        if not self.returns.empty:
            performance = self.risk_attribution.calculate_metrics()
            self.performance_history.append(performance)
            
        return results
        
    def generate_attribution_report(self) -> Dict[str, Any]:
        """Generate comprehensive attribution report"""
        # Calculate all attributions
        attributions = self.calculate_all_attributions()
        
        # Get latest performance metrics
        latest_performance = self.performance_history[-1] if self.performance_history else None
        
        report = {}
            'report_date': datetime.now().isoformat(),
            'summary': {}
                'total_pnl': sum(t.pnl for t in self.trades),
                'total_trades': len(self.trades),
                'period_start': min(t.entry_time for t in self.trades).isoformat() if self.trades else None,
                'period_end': max(t.exit_time for t in self.trades).isoformat() if self.trades else None
            },
            'performance_metrics': {},
            'attribution_breakdown': {},
            'trade_analysis': {},
            'risk_analysis': {}
        }
        
        # Performance metrics
        if latest_performance:
            report['performance_metrics'] = {}
                'total_return': f"{latest_performance.total_return:.2%}",
                'annualized_return': f"{latest_performance.annualized_return:.2%}",
                'volatility': f"{latest_performance.volatility:.2%}",
                'sharpe_ratio': f"{latest_performance.sharpe_ratio:.2f}",
                'sortino_ratio': f"{latest_performance.sortino_ratio:.2f}",
                'max_drawdown': f"{latest_performance.max_drawdown:.2%}",
                'win_rate': f"{latest_performance.win_rate:.2%}",
                'profit_factor': f"{latest_performance.profit_factor:.2f}"
            }
            
        # Attribution breakdown
        for attr_type, result in attributions.items():
            if result.total_pnl != 0:
                report['attribution_breakdown'][attr_type] = {}
                    'total_pnl': result.total_pnl,
                    'components': result.components,
                    'statistics': result.statistics
                }
                
        # Trade analysis
        if 'trade_level' in attributions:
            trade_stats = attributions['trade_level'].statistics
            report['trade_analysis'] = {}
                'by_symbol': attributions['trade_level'].components.get('by_symbol', {}),
                'by_strategy': attributions['trade_level'].components.get('by_strategy', {}),
                'win_rate': trade_stats.get('win_rate', 0),
                'average_win': trade_stats.get('average_win', 0),
                'average_loss': trade_stats.get('average_loss', 0),
                'profit_factor': trade_stats.get('profit_factor', 0)
            }
            
        # Risk analysis
        report['risk_analysis'] = {}
            'var_95': self._calculate_var(0.95),
            'cvar_95': self._calculate_cvar(0.95),
            'max_position_size': max(abs(p.quantity * p.current_price) for p in self.positions) if self.positions else 0,
            'correlation_to_market': 0.65  # Placeholder
        }
        
        return report
        
    def _calculate_var(self, confidence: float) -> float:
        """Calculate Value at Risk"""
        if self.returns.empty:
            return 0
        return np.percentile(self.returns, (1 - confidence) * 100)
        
    def _calculate_cvar(self, confidence: float) -> float:
        """Calculate Conditional Value at Risk"""
        var = self._calculate_var(confidence)
        return self.returns[self.returns <= var].mean()
        
    def plot_attribution_analysis(self, save_path: Optional[str] = None):
        """Create attribution analysis visualizations"""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # Get latest attribution results
        attributions = self.calculate_all_attributions()
        
        # Plot 1: P&L by Symbol
        ax1 = axes[0, 0]
        if 'trade_level' in attributions:
            by_symbol = attributions['trade_level'].components.get('by_symbol', {})
            if by_symbol:
                symbols = list(by_symbol.keys())
                pnls = list(by_symbol.values())
                colors = ['green' if p > 0 else 'red' for p in pnls]
                
                ax1.bar(symbols, pnls, color=colors, alpha=0.7)
                ax1.set_xlabel('Symbol')
                ax1.set_ylabel('P&L')
                ax1.set_title('P&L by Symbol')
                ax1.tick_params(axis='x', rotation=45)
                
        # Plot 2: P&L by Time Period
        ax2 = axes[0, 1]
        if not self.daily_pnl.empty:
            cumulative_pnl = self.daily_pnl.cumsum()
            ax2.plot(cumulative_pnl.index, cumulative_pnl.values, linewidth=2)
            ax2.fill_between(cumulative_pnl.index, 0, cumulative_pnl.values, 
                           alpha=0.3, color='blue')
            ax2.set_xlabel('Date')
            ax2.set_ylabel('Cumulative P&L')
            ax2.set_title('Cumulative P&L Over Time')
            ax2.tick_params(axis='x', rotation=45)
            
        # Plot 3: Factor Attribution
        ax3 = axes[1, 0]
        if 'factor_based' in attributions:
            factor_contrib = attributions['factor_based'].components
            if factor_contrib:
                factors = list(factor_contrib.keys())
                contributions = list(factor_contrib.values())
                colors = ['green' if c > 0 else 'red' for c in contributions]
                
                ax3.barh(factors, contributions, color=colors, alpha=0.7)
                ax3.set_xlabel('Contribution')
                ax3.set_ylabel('Factor')
                ax3.set_title('Factor Attribution')
                
        # Plot 4: Performance Metrics
        ax4 = axes[1, 1]
        if self.performance_history:
            latest = self.performance_history[-1]
            metrics = {}
                'Return': latest.total_return * 100,
                'Volatility': latest.volatility * 100,
                'Sharpe': latest.sharpe_ratio,
                'Max DD': abs(latest.max_drawdown) * 100,
                'Win Rate': latest.win_rate * 100
            }
            
            metric_names = list(metrics.keys())
            metric_values = list(metrics.values())
            
            bars = ax4.bar(metric_names, metric_values, alpha=0.7)
            
            # Color code bars
            colors = ['green', 'orange', 'blue', 'red', 'purple']
            for bar, color in zip(bars, colors):
                bar.set_color(color)
                
            ax4.set_ylabel('Value')
            ax4.set_title('Performance Metrics')
            
            # Add value labels
            for bar, value in zip(bars, metric_values):
                height = bar.get_height()
                ax4.text(bar.get_x() + bar.get_width()/2., height,
                        f'{value:.1f}',
                        ha='center', va='bottom')
                        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
        return fig
        
    def export_attribution_data(self, filepath: str):
        """Export attribution data to file"""
        data = {}
            'trades': []
                {}
                    'trade_id': t.trade_id,
                    'symbol': t.symbol,
                    'entry_time': t.entry_time.isoformat(),
                    'exit_time': t.exit_time.isoformat(),
                    'pnl': t.pnl,
                    'strategy_component': t.strategy_component
                }
                for t in self.trades
            ],
            'daily_pnl': self.daily_pnl.to_dict() if not self.daily_pnl.empty else {},
            'attribution_results': []
                {}
                    'type': r.attribution_type.value,
                    'period_start': r.period_start.isoformat(),
                    'period_end': r.period_end.isoformat(),
                    'total_pnl': r.total_pnl,
                    'components': r.components
                }
                for r in self.attribution_results
            ]
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)
            
        logger.info(f"Attribution data exported to {filepath}")


def main():
    """Example usage of P&L attribution system"""
    
    # Configuration
    config = {}
        'factors': ['market', 'sector', 'momentum', 'value', 'volatility']
    }
    
    # Create system
    system = StrategyPLAttributionSystem(config)
    
    # Generate sample trades
    np.random.seed(42)
    symbols = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'FB', 'TSLA', 'NVDA', 'AMD']
    strategies = ['momentum', 'mean_reversion', 'breakout', 'pairs']
    
    start_date = datetime(2023, 1, 1)
    
    for i in range(100):
        # Random trade parameters
        symbol = np.random.choice(symbols)
        strategy = np.random.choice(strategies)
        
        entry_time = start_date + timedelta(days=np.random.randint(0, 300))
        hold_time = timedelta(hours=np.random.randint(1, 72))
        exit_time = entry_time + hold_time
        
        entry_price = 100 * (1 + np.random.normal(0, 0.1))
        
        # Generate P&L based on strategy
        if strategy == 'momentum':
            price_change = np.random.normal(0.002, 0.02)
        elif strategy == 'mean_reversion':
            price_change = np.random.normal(-0.001, 0.015)
        elif strategy == 'breakout':
            price_change = np.random.normal(0.003, 0.025)
        else:  # pairs
            price_change = np.random.normal(0, 0.01)
            
        exit_price = entry_price * (1 + price_change)
        
        side = np.random.choice(['long', 'short'])
        quantity = np.random.randint(10, 100)
        
        if side == 'long':
            pnl = (exit_price - entry_price) * quantity
        else:
            pnl = (entry_price - exit_price) * quantity
            
        fees = abs(quantity * 0.01)  # Simple fee model
        
        trade = Trade()
            trade_id=f"T{i+1:04d}",
            symbol=symbol,
            entry_time=entry_time,
            exit_time=exit_time,
            entry_price=entry_price,
            exit_price=exit_price,
            quantity=quantity,
            side=side,
            pnl=pnl,
            fees=fees,
            strategy_component=strategy,
            signals={'signal_strength': np.random.random()}
        )
        
        system.add_trade(trade)
        
    # Generate daily P&L
    dates = pd.date_range(start=start_date, end=start_date + timedelta(days=364), freq='D')
    daily_pnl = pd.Series(index=dates)
    
    for date in dates:
        # Sum P&L from trades that closed on this date
        day_pnl = sum(t.pnl - t.fees for t in system.trades)
                     if t.exit_time.date() == date.date())
        daily_pnl[date] = day_pnl
        
    system.update_daily_pnl(date, daily_pnl)
    
    # Generate returns
    initial_capital = 1000000
    returns = daily_pnl / initial_capital
    system.update_returns(returns)
    
    # Generate factor returns
    factor_returns = pd.DataFrame(index=dates)
    for factor in config['factors']:
        if factor == 'market':
            factor_returns[factor] = np.random.normal(0.0003, 0.01, len(dates))
        elif factor == 'momentum':
            factor_returns[factor] = np.random.normal(0.0001, 0.008, len(dates))
        else:
            factor_returns[factor] = np.random.normal(0, 0.005, len(dates))
            
    system.update_factor_returns(factor_returns)
    
    # Generate report
    report = system.generate_attribution_report()
    
    print("P&L Attribution Report")
    print("=" * 50)
    print(f"\nSummary:")
    print(f"Total P&L: ${report['summary']['total_pnl']:,.2f}")
    print(f"Total Trades: {report['summary']['total_trades']}")
    
    print(f"\nPerformance Metrics:")
    for metric, value in report['performance_metrics'].items():
        print(f"  {metric}: {value}")
        
    print(f"\nTrade Analysis:")
    print(f"  Top Symbols by P&L:")
    symbol_pnl = report['trade_analysis']['by_symbol']
    for symbol, pnl in sorted(symbol_pnl.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"    {symbol}: ${pnl:,.2f}")
        
    print(f"\n  Strategy Performance:")
    strategy_pnl = report['trade_analysis']['by_strategy']
    for strategy, pnl in sorted(strategy_pnl.items(), key=lambda x: x[1], reverse=True):
        print(f"    {strategy}: ${pnl:,.2f}")
        
    if 'factor_based' in report['attribution_breakdown']:
        print(f"\nFactor Attribution:")
        factor_attr = report['attribution_breakdown']['factor_based']
        for factor, contribution in factor_attr['components'].items():
            print(f"  {factor}: ${contribution:,.2f}")
            
    # Create visualizations
    fig = system.plot_attribution_analysis('pl_attribution.png')
    print("\nVisualization saved to 'pl_attribution.png'")
    
    # Export data
    system.export_attribution_data('attribution_data.json')
    print("Attribution data exported to 'attribution_data.json'")


if __name__ == "__main__":
    main()

# Class aliases and stubs
StrategyPLAttribution = StrategyPLAttributionSystem


# Module exports
__all__ = ['TradeLevelAttribution', 'RiskAdjustedAttribution', 'Trade', 'StrategyPLAttributionSystem', 'PerformanceMetric', 'FactorBasedAttribution', 'AttributionType', 'TimeBasedAttribution', 'StrategyPLAttribution', 'AttributionResult', 'PerformanceAnalysis', 'Position']
