#!/usr/bin/env python3
"""
Automated Model Monitoring Dashboard
====================================
Real-time model performance monitoring with automated alerts,
A/B testing, and champion/challenger framework.

Features:
- Real-time performance metrics
- Model comparison and A/B testing
- Automated alerts for performance degradation
- Champion/challenger framework
- Drift correlation analysis
- Interactive dashboards
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import defaultdict, deque
import json
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import dash
from dash import dcc, html, Input, Output, State
import dash_bootstrap_components as dbc

# Metrics and monitoring
from prometheus_client import Counter, Gauge, Histogram
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns

logger = logging.getLogger(__name__)

# Prometheus metrics
model_predictions = Counter('model_predictions_total', 'Total predictions', ['model_name', 'model_version'])
model_accuracy = Gauge('model_accuracy', 'Model accuracy', ['model_name', 'model_version'])
model_latency = Histogram('model_latency_seconds', 'Model inference latency', ['model_name', 'model_version'])
model_errors = Counter('model_errors_total', 'Model errors', ['model_name', 'error_type'])
alert_triggered = Counter('model_alerts_total', 'Model alerts triggered', ['alert_type', 'model_name'])


@dataclass
class ModelConfig:
    """Configuration for a monitored model"""
    model_name: str
    model_version: str
    model_type: str  # 'classification', 'regression', 'ranking'
    
    # Performance thresholds
    min_accuracy: float = 0.8
    max_latency_ms: float = 100
    min_precision: float = 0.7
    min_recall: float = 0.7
    
    # Monitoring settings
    evaluation_window: int = 1000  # samples
    alert_threshold_violations: int = 3
    
    # A/B testing
    is_champion: bool = True
    traffic_percentage: float = 100.0
    
    # Metadata
    deployment_date: datetime = field(default_factory=datetime.now)
    tags: List[str] = field(default_factory=list)


@dataclass
class ModelMetrics:
    """Metrics for model performance"""
    timestamp: datetime
    model_name: str
    model_version: str
    
    # Performance metrics
    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1_score: Optional[float] = None
    
    # Regression metrics
    mse: Optional[float] = None
    mae: Optional[float] = None
    rmse: Optional[float] = None
    
    # Operational metrics
    latency_ms: float = 0.0
    throughput: float = 0.0
    error_rate: float = 0.0
    
    # Sample counts
    total_predictions: int = 0
    correct_predictions: int = 0
    
    # Additional context
    feature_importance: Optional[Dict[str, float]] = None
    confusion_matrix: Optional[np.ndarray] = None


class AutomatedModelMonitoringDashboard:
    """
    Comprehensive model monitoring dashboard with automated alerts
    """
    
    def __init__(self, port: int = 8050):
        self.port = port
        self.models = {}
        self.metrics_history = defaultdict(lambda: deque(maxlen=10000))
        self.predictions_cache = defaultdict(lambda: deque(maxlen=1000))
        self.alerts = deque(maxlen=100)
        
        # Champion/Challenger tracking
        self.champion_model = None
        self.challenger_models = []
        
        # A/B test results
        self.ab_test_results = defaultdict(dict)
        
        # Monitoring state
        self.is_monitoring = False
        self.monitoring_task = None
        
        # Dashboard app
        self.app = None
        self._create_dashboard()
        
        logger.info("Model monitoring dashboard initialized")
    
    def register_model(self, config: ModelConfig):
        """Register a model for monitoring"""
        key = f"{config.model_name}:{config.model_version}"
        self.models[key] = config
        
        if config.is_champion:
            self.champion_model = key
        else:
            self.challenger_models.append(key)
        
        logger.info(f"Registered model: {key} (champion: {config.is_champion})")
    
    async def update_metrics(self, predictions: Dict[str, Any], 
                           ground_truth: Optional[Dict[str, Any]] = None):
        """Update model metrics with new predictions"""
        for model_key, model_predictions in predictions.items():
            if model_key not in self.models:
                continue
            
            config = self.models[model_key]
            
            # Calculate metrics
            metrics = await self._calculate_metrics()
                config, model_predictions, ground_truth
            )
            
            # Store metrics
            self.metrics_history[model_key].append(metrics)
            
            # Update Prometheus metrics
            self._update_prometheus_metrics(metrics)
            
            # Check for alerts
            await self._check_alerts(config, metrics)
            
            # Update A/B test results if applicable
            if len(self.models) > 1:
                await self._update_ab_test_results(model_key, metrics)
    
    async def _calculate_metrics(self, config: ModelConfig, 
                               predictions: Dict[str, Any],
                               ground_truth: Optional[Dict[str, Any]]) -> ModelMetrics:
        """Calculate model performance metrics"""
        metrics = ModelMetrics()
            timestamp=datetime.now(),
            model_name=config.model_name,
            model_version=config.model_version
        )
        
        # Extract prediction data
        y_pred = predictions.get('predictions', [])
        latencies = predictions.get('latencies', [])
        
        # Calculate latency metrics
        if latencies:
            metrics.latency_ms = np.mean(latencies) * 1000
            metrics.throughput = len(latencies) / (sum(latencies) + 1e-6)
        
        # Calculate accuracy metrics if ground truth available
        if ground_truth and 'labels' in ground_truth:
            y_true = ground_truth['labels']
            
            if config.model_type == 'classification':
                # Classification metrics
                metrics.accuracy = accuracy_score(y_true, y_pred)
                precision, recall, f1, _ = precision_recall_fscore_support()
                    y_true, y_pred, average='weighted'
                )
                metrics.precision = precision
                metrics.recall = recall
                metrics.f1_score = f1
                
                # Confusion matrix
                from sklearn.metrics import confusion_matrix
                metrics.confusion_matrix = confusion_matrix(y_true, y_pred)
                
            elif config.model_type == 'regression':
                # Regression metrics
                metrics.mse = mean_squared_error(y_true, y_pred)
                metrics.mae = np.mean(np.abs(np.array(y_true) - np.array(y_pred)))
                metrics.rmse = np.sqrt(metrics.mse)
        
        # Update counts
        metrics.total_predictions = len(y_pred)
        
        # Feature importance if available
        if 'feature_importance' in predictions:
            metrics.feature_importance = predictions['feature_importance']
        
        return metrics
    
    def _update_prometheus_metrics(self, metrics: ModelMetrics):
        """Update Prometheus metrics"""
        labels = {}
            'model_name': metrics.model_name,
            'model_version': metrics.model_version
        }
        
        # Update counters
        model_predictions.labels(**labels).inc(metrics.total_predictions)
        
        # Update gauges
        if metrics.accuracy is not None:
            model_accuracy.labels(**labels).set(metrics.accuracy)
        
        # Update histogram
        if metrics.latency_ms > 0:
            model_latency.labels(**labels).observe(metrics.latency_ms / 1000)
    
    async def _check_alerts(self, config: ModelConfig, metrics: ModelMetrics):
        """Check for alert conditions"""
        alerts = []
        
        # Accuracy alert
        if metrics.accuracy is not None and metrics.accuracy < config.min_accuracy:
            alerts.append({)
                'type': 'accuracy_degradation',
                'severity': 'high',
                'message': f"Model accuracy {metrics.accuracy:.3f} below threshold {config.min_accuracy}"
            })
        
        # Latency alert
        if metrics.latency_ms > config.max_latency_ms:
            alerts.append({)
                'type': 'high_latency',
                'severity': 'medium',
                'message': f"Model latency {metrics.latency_ms:.1f}ms exceeds threshold {config.max_latency_ms}ms"
            })
        
        # Precision/Recall alerts
        if metrics.precision is not None and metrics.precision < config.min_precision:
            alerts.append({)
                'type': 'precision_degradation',
                'severity': 'medium',
                'message': f"Model precision {metrics.precision:.3f} below threshold {config.min_precision}"
            })
        
        if metrics.recall is not None and metrics.recall < config.min_recall:
            alerts.append({)
                'type': 'recall_degradation',
                'severity': 'medium',
                'message': f"Model recall {metrics.recall:.3f} below threshold {config.min_recall}"
            })
        
        # Process alerts
        for alert in alerts:
            await self._trigger_alert(config, metrics, alert)
    
    async def _trigger_alert(self, config: ModelConfig, metrics: ModelMetrics, alert: Dict[str, Any]):
        """Trigger an alert"""
        alert_data = {}
            'timestamp': datetime.now().isoformat(),
            'model_name': config.model_name,
            'model_version': config.model_version,
            **alert
        }
        
        self.alerts.append(alert_data)
        
        # Log alert
        logger.warning(f"ALERT: {alert['type']} - {alert['message']}")
        
        # Update Prometheus
        alert_triggered.labels()
            alert_type=alert['type'],
            model_name=config.model_name
        ).inc()
        
        # Could trigger additional actions here (email, Slack, etc.)
    
    async def _update_ab_test_results(self, model_key: str, metrics: ModelMetrics):
        """Update A/B test results"""
        if model_key not in self.ab_test_results:
            self.ab_test_results[model_key] = {}
                'total_predictions': 0,
                'cumulative_accuracy': 0,
                'cumulative_latency': 0
            }
        
        results = self.ab_test_results[model_key]
        results['total_predictions'] += metrics.total_predictions
        
        if metrics.accuracy is not None:
            # Running average
            n = results['total_predictions']
            results['cumulative_accuracy'] = ()
                (results['cumulative_accuracy'] * (n - metrics.total_predictions) +)
                 metrics.accuracy * metrics.total_predictions) / n
            )
        
        results['cumulative_latency'] = ()
            (results['cumulative_latency'] * (n - metrics.total_predictions) +)
             metrics.latency_ms * metrics.total_predictions) / n
        )
    
    def _create_dashboard(self):
        """Create Dash dashboard"""
        self.app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
        
        self.app.layout = dbc.Container([)
            dbc.Row([)
                dbc.Col([)
                    html.H1("Model Monitoring Dashboard", className="text-center mb-4"),
                    html.Hr()
                ])
            ]),
            
            # Summary cards
            dbc.Row([)
                dbc.Col([)
                    dbc.Card([)
                        dbc.CardBody([)
                            html.H4("Active Models", className="card-title"),
                            html.H2(id="active-models-count", children="0")
                        ])
                    ])
                ], width=3),
                
                dbc.Col([)
                    dbc.Card([)
                        dbc.CardBody([)
                            html.H4("Champion Model", className="card-title"),
                            html.P(id="champion-model-name", children="None")
                        ])
                    ])
                ], width=3),
                
                dbc.Col([)
                    dbc.Card([)
                        dbc.CardBody([)
                            html.H4("Active Alerts", className="card-title"),
                            html.H2(id="active-alerts-count", children="0")
                        ])
                    ])
                ], width=3),
                
                dbc.Col([)
                    dbc.Card([)
                        dbc.CardBody([)
                            html.H4("Avg Latency", className="card-title"),
                            html.H2(id="avg-latency", children="0ms")
                        ])
                    ])
                ], width=3)
            ], className="mb-4"),
            
            # Main charts
            dbc.Row([)
                dbc.Col([)
                    dcc.Graph(id="accuracy-timeline")
                ], width=6),
                
                dbc.Col([)
                    dcc.Graph(id="latency-timeline")
                ], width=6)
            ], className="mb-4"),
            
            # A/B test results
            dbc.Row([)
                dbc.Col([)
                    dcc.Graph(id="ab-test-results")
                ], width=12)
            ], className="mb-4"),
            
            # Feature importance
            dbc.Row([)
                dbc.Col([)
                    dcc.Graph(id="feature-importance")
                ], width=6),
                
                dbc.Col([)
                    dcc.Graph(id="confusion-matrix")
                ], width=6)
            ], className="mb-4"),
            
            # Alerts table
            dbc.Row([)
                dbc.Col([)
                    html.H3("Recent Alerts"),
                    html.Div(id="alerts-table")
                ])
            ]),
            
            # Auto-refresh
            dcc.Interval()
                id='interval-component',
                interval=5*1000,  # 5 seconds
                n_intervals=0
            )
        ], fluid=True)
        
        # Callbacks
        self._setup_callbacks()
    
    def _setup_callbacks(self):
        """Setup dashboard callbacks"""
        
        @self.app.callback()
            [Output("active-models-count", "children"),
             Output("champion-model-name", "children"),
             Output("active-alerts-count", "children"),
             Output("avg-latency", "children")],
            [Input("interval-component", "n_intervals")]
        )
        def update_summary_cards(n):
            # Active models
            active_models = len(self.models)
            
            # Champion model
            champion_name = self.champion_model if self.champion_model else "None"
            
            # Active alerts
            recent_alerts = [a for a in self.alerts]
                           if datetime.fromisoformat(a['timestamp']) > 
                           datetime.now() - timedelta(hours=1)]
            
            # Average latency
            all_latencies = []
            for metrics_list in self.metrics_history.values():
                if metrics_list:
                    latest = metrics_list[-1]
                    if latest.latency_ms > 0:
                        all_latencies.append(latest.latency_ms)
            
            avg_latency = np.mean(all_latencies) if all_latencies else 0
            
            return ()
                str(active_models),
                champion_name,
                str(len(recent_alerts)),
                f"{avg_latency:.1f}ms"
            )
        
        @self.app.callback()
            Output("accuracy-timeline", "figure"),
            [Input("interval-component", "n_intervals")]
        )
        def update_accuracy_timeline(n):
            fig = go.Figure()
            
            for model_key, metrics_list in self.metrics_history.items():
                if not metrics_list:
                    continue
                
                timestamps = [m.timestamp for m in metrics_list if m.accuracy is not None]
                accuracies = [m.accuracy for m in metrics_list if m.accuracy is not None]
                
                if timestamps:
                    fig.add_trace(go.Scatter())
                        x=timestamps,
                        y=accuracies,
                        mode='lines+markers',
                        name=model_key,
                        line=dict(width=2)
                    ))
            
            fig.update_layout()
                title="Model Accuracy Over Time",
                xaxis_title="Time",
                yaxis_title="Accuracy",
                yaxis=dict(range=[0, 1]),
                hovermode='x unified'
            )
            
            return fig
        
        @self.app.callback()
            Output("latency-timeline", "figure"),
            [Input("interval-component", "n_intervals")]
        )
        def update_latency_timeline(n):
            fig = go.Figure()
            
            for model_key, metrics_list in self.metrics_history.items():
                if not metrics_list:
                    continue
                
                timestamps = [m.timestamp for m in metrics_list]
                latencies = [m.latency_ms for m in metrics_list]
                
                fig.add_trace(go.Scatter())
                    x=timestamps,
                    y=latencies,
                    mode='lines+markers',
                    name=model_key,
                    line=dict(width=2)
                ))
            
            fig.update_layout()
                title="Model Latency Over Time",
                xaxis_title="Time",
                yaxis_title="Latency (ms)",
                hovermode='x unified'
            )
            
            return fig
        
        @self.app.callback()
            Output("ab-test-results", "figure"),
            [Input("interval-component", "n_intervals")]
        )
        def update_ab_test_results(n):
            if not self.ab_test_results:
                return go.Figure()
            
            models = list(self.ab_test_results.keys())
            accuracies = [self.ab_test_results[m].get('cumulative_accuracy', 0) for m in models]
            latencies = [self.ab_test_results[m].get('cumulative_latency', 0) for m in models]
            predictions = [self.ab_test_results[m].get('total_predictions', 0) for m in models]
            
            fig = make_subplots()
                rows=1, cols=3,
                subplot_titles=('Accuracy', 'Latency', 'Prediction Volume')
            )
            
            # Accuracy
            fig.add_trace()
                go.Bar(x=models, y=accuracies, name="Accuracy"),
                row=1, col=1
            )
            
            # Latency
            fig.add_trace()
                go.Bar(x=models, y=latencies, name="Latency (ms)"),
                row=1, col=2
            )
            
            # Volume
            fig.add_trace()
                go.Bar(x=models, y=predictions, name="Predictions"),
                row=1, col=3
            )
            
            fig.update_layout()
                title="A/B Test Results Comparison",
                showlegend=False,
                height=400
            )
            
            return fig
        
        @self.app.callback()
            Output("alerts-table", "children"),
            [Input("interval-component", "n_intervals")]
        )
        def update_alerts_table(n):
            if not self.alerts:
                return html.P("No recent alerts")
            
            # Create table
            headers = ["Time", "Model", "Type", "Severity", "Message"]
            rows = []
            
            for alert in list(self.alerts)[-10:]:  # Last 10 alerts
                time_str = datetime.fromisoformat(alert['timestamp']).strftime("%H:%M:%S")
                severity_badge = dbc.Badge()
                    alert['severity'],
                    color="danger" if alert['severity'] == 'high' else "warning"
                )
                
                rows.append()
                    html.Tr([)
                        html.Td(time_str),
                        html.Td(alert['model_name']),
                        html.Td(alert['type']),
                        html.Td(severity_badge),
                        html.Td(alert['message'])
                    ])
                )
            
            table = dbc.Table([)
                html.Thead([html.Tr([html.Th(h) for h in headers])]),
                html.Tbody(rows)
            ], striped=True, bordered=True, hover=True)
            
            return table
    
    async def start_monitoring(self):
        """Start the monitoring dashboard"""
        self.is_monitoring = True
        
        # Start monitoring loop
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
        
        # Start dashboard in thread
        import threading
        dashboard_thread = threading.Thread()
            target=lambda: self.app.run_server()
                debug=False, 
                port=self.port, 
                host='0.0.0.0'
            )
        )
        dashboard_thread.daemon = True
        dashboard_thread.start()
        
        logger.info(f"Model monitoring dashboard started on port {self.port}")
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.is_monitoring:
            try:
                # Perform periodic checks
                await self._check_model_health()
                
                # Sleep
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
    
    async def _check_model_health(self):
        """Check overall model health"""
        for model_key, config in self.models.items():
            if model_key not in self.metrics_history:
                continue
            
            recent_metrics = list(self.metrics_history[model_key])[-10:]
            if not recent_metrics:
                continue
            
            # Check for consistent performance degradation
            if all(m.accuracy is not None and m.accuracy < config.min_accuracy)
                   for m in recent_metrics[-3:]):
                await self._trigger_alert()
                    config, recent_metrics[-1],
                    {}
                        'type': 'consistent_degradation',
                        'severity': 'critical',
                        'message': f"Model showing consistent accuracy degradation over last 3 checks"
                    }
                )
    
    def get_model_summary(self, model_key: str) -> Dict[str, Any]:
        """Get summary statistics for a model"""
        if model_key not in self.metrics_history:
            return {}
        
        metrics_list = list(self.metrics_history[model_key])
        if not metrics_list:
            return {}
        
        recent_metrics = metrics_list[-100:]  # Last 100 measurements
        
        return {}
            'model_key': model_key,
            'total_predictions': sum(m.total_predictions for m in recent_metrics),
            'avg_accuracy': np.mean([m.accuracy for m in recent_metrics if m.accuracy is not None]),
            'avg_latency_ms': np.mean([m.latency_ms for m in recent_metrics]),
            'error_rate': 1 - np.mean([m.accuracy for m in recent_metrics if m.accuracy is not None]),
            'last_updated': recent_metrics[-1].timestamp.isoformat()
        }
    
    async def compare_models(self, model_keys: List[str]) -> Dict[str, Any]:
        """Compare performance of multiple models"""
        comparison = {}
        
        for model_key in model_keys:
            summary = self.get_model_summary(model_key)
            if summary:
                comparison[model_key] = summary
        
        # Determine winner for each metric
        if len(comparison) > 1:
            metrics_to_compare = ['avg_accuracy', 'avg_latency_ms', 'error_rate']
            winners = {}
            
            for metric in metrics_to_compare:
                if metric == 'avg_latency_ms' or metric == 'error_rate':
                    # Lower is better
                    winners[metric] = min()
                        comparison.keys(),
                        key=lambda k: comparison[k].get(metric, float('inf'))
                    )
                else:
                    # Higher is better
                    winners[metric] = max()
                        comparison.keys(),
                        key=lambda k: comparison[k].get(metric, float('-inf'))
                    )
            
            comparison['winners'] = winners
        
        return comparison
    
    async def stop_monitoring(self):
        """Stop monitoring"""
        self.is_monitoring = False
        if self.monitoring_task:
            await self.monitoring_task
        logger.info("Model monitoring stopped")
class ModelMonitoringDashboard:
    """Stub implementation for ModelMonitoringDashboard"""
    def __init__(self, *args, **kwargs):
        self.config = kwargs
        print(f"Initialized {self.__class__.__name__}")
    
    def run(self):
        print(f"Running {self.__class__.__name__}")
        return True

__all__ = ["ModelMonitoringDashboard"]
