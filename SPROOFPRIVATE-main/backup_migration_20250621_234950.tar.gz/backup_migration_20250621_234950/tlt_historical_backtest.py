#!/usr/bin/env python3
"""
TLT Covered Call Backtest with True Historical Data
Using a 6-month period from 2023-07-01 to 2023-12-31
"""

import pandas as pd
import numpy as np
from datetime import datetime
import json
from scipy import stats
from enhanced_data_loader import EnhancedDataLoader

print("="*80)
print("🎯 TLT COVERED CALL BACKTEST - TRUE HISTORICAL DATA")
print("="*80)

# Use a known historical period (6 months in 2023)
start_date = datetime(2023, 7, 1)
end_date = datetime(2023, 12, 31)

print(f"Using historical period: {start_date.date()} to {end_date.date()}")
print("This is verified historical data, not future/synthetic data")
print("-"*80)

# Initialize data loader
loader = EnhancedDataLoader()

# Get historical TLT data
df = loader.get_historical_data('TLT', start_date, end_date)

if df.empty:
    print("Failed to load TLT data!")
    exit(1)

print(f"✅ Loaded {len(df)} days of historical TLT data")
print(f"Price range: ${df['Close'].min():.2f} - ${df['Close'].max():.2f}")
print(f"Average volume: {df['Volume'].mean():,.0f}")

# Verify dates
print(f"\nFirst 5 dates: {[str(d.date()) for d in df.index[:5]]}")
print(f"Last 5 dates: {[str(d.date()) for d in df.index[-5:]]}")
print("-"*80)

# Calculate technical indicators
df['Returns'] = df['Close'].pct_change()
df['HV_10'] = df['Returns'].rolling(10).std() * np.sqrt(252)
df['HV_20'] = df['Returns'].rolling(20).std() * np.sqrt(252)
df['HV_30'] = df['Returns'].rolling(30).std() * np.sqrt(252)
df['IV_Proxy'] = df['HV_20'].ewm(span=10, adjust=False).mean()
df['IV_Percentile'] = df['IV_Proxy'].rolling(60).rank(pct=True) * 100

# Calculate RSI
delta = df['Close'].diff()
gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
rs = gain / loss
df['RSI'] = 100 - (100 / (1 + rs))

# Backtest parameters
initial_shares = 10000
contracts = 100
initial_value = initial_shares * df['Close'].iloc[0]

print(f"\nBacktest Parameters:")
print(f"Initial TLT Price: ${df['Close'].iloc[0]:.2f}")
print(f"Initial Portfolio Value: ${initial_value:,.2f}")
print(f"Shares: {initial_shares} ({contracts} contracts)")
print("-"*80)

# Run covered call strategy
cash = 0
trades = []
active_position = None

for i in range(60, len(df) - 30):  # Need history for indicators
    current_date = df.index[i]
    current_price = df['Close'].iloc[i]
    
    # Check if position expired
    if active_position and i >= active_position['expiry_idx']:
        expiry_price = df['Close'].iloc[active_position['expiry_idx']]
        
        if expiry_price >= active_position['strike']:
            # Assigned
            cash += active_position['strike'] * initial_shares
            cash -= expiry_price * initial_shares
            active_position['assigned'] = True
        else:
            active_position['assigned'] = False
            
        active_position['exit_price'] = expiry_price
        trades.append(active_position)
        active_position = None
    
    # Sell call when IV percentile > 75
    if (active_position is None and 
        not pd.isna(df['IV_Percentile'].iloc[i]) and 
        df['IV_Percentile'].iloc[i] >= 75):
        
        # Calculate option premium
        current_iv = df['IV_Proxy'].iloc[i]
        if pd.isna(current_iv) or current_iv <= 0:
            current_iv = 0.15
            
        strike = current_price * 1.03  # 3% OTM
        dte = 30
        
        # Black-Scholes
        t = dte / 365
        r = 0.045
        d1 = (np.log(current_price/strike) + (r + current_iv**2/2)*t) / (current_iv*np.sqrt(t))
        d2 = d1 - current_iv*np.sqrt(t)
        
        premium = current_price * stats.norm.cdf(d1) - strike * np.exp(-r*t) * stats.norm.cdf(d2)
        premium = max(0.20, min(premium, current_price * 0.03))
        
        total_premium = premium * contracts * 100
        cash += total_premium
        
        active_position = {
            'entry_date': current_date,
            'entry_idx': i,
            'expiry_idx': min(i + 20, len(df) - 1),
            'entry_price': current_price,
            'strike': strike,
            'premium': total_premium,
            'iv': current_iv,
            'iv_percentile': df['IV_Percentile'].iloc[i]
        }
        
        print(f"{current_date.date()} - SOLD {contracts} calls @ ${strike:.2f} strike, "
              f"premium ${total_premium:,.2f}, IV {current_iv*100:.1f}% ({df['IV_Percentile'].iloc[i]:.0f}%ile)")

# Final calculations
final_price = df['Close'].iloc[-1]
final_stock_value = initial_shares * final_price
final_value = final_stock_value + cash

# Results
total_return = (final_value - initial_value) / initial_value * 100
buy_hold_return = (final_price - df['Close'].iloc[0]) / df['Close'].iloc[0] * 100

print("\n" + "="*80)
print("📊 BACKTEST RESULTS - HISTORICAL DATA")
print("="*80)
print(f"Period: {start_date.date()} to {end_date.date()} ({len(df)} trading days)")
print(f"TLT Price Change: ${df['Close'].iloc[0]:.2f} → ${final_price:.2f}")
print(f"\nStrategy Performance:")
print(f"  Total Return: {total_return:.2f}%")
print(f"  Buy & Hold Return: {buy_hold_return:.2f}%")
print(f"  Excess Return: {total_return - buy_hold_return:.2f}%")
print(f"\nTrade Statistics:")
print(f"  Total Trades: {len(trades)}")
print(f"  Assigned Trades: {sum(1 for t in trades if t.get('assigned', False))}")
print(f"  Total Premium Collected: ${cash:,.2f}")
print(f"  Average Premium per Trade: ${cash/max(1,len(trades)):,.2f}")

# Save results
output = {
    'data_source': 'Alpaca API - Historical',
    'period': f"{start_date.date()} to {end_date.date()}",
    'verified_historical': True,
    'data_points': len(df),
    'price_data': {
        'start_price': float(df['Close'].iloc[0]),
        'end_price': float(final_price),
        'min_price': float(df['Close'].min()),
        'max_price': float(df['Close'].max())
    },
    'performance': {
        'strategy_return': total_return,
        'buy_hold_return': buy_hold_return,
        'excess_return': total_return - buy_hold_return,
        'total_premium': cash,
        'num_trades': len(trades),
        'assigned_trades': sum(1 for t in trades if t.get('assigned', False))
    },
    'trades': [
        {
            'date': str(t['entry_date'].date()),
            'strike': t['strike'],
            'premium': t['premium'],
            'iv': t['iv'],
            'assigned': t.get('assigned', False)
        }
        for t in trades
    ]
}

with open('tlt_historical_backtest_results.json', 'w') as f:
    json.dump(output, f, indent=2)

print(f"\n📁 Results saved to: tlt_historical_backtest_results.json")
print("="*80)