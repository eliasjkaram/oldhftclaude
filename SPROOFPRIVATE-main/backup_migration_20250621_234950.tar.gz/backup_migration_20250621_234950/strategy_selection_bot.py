
#!/usr/bin/env python3
"""
Intelligent Strategy Selection Bot
Analyzes market conditions using multiple indicators and data sources to recommend optimal trading strategies
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import aiohttp
import requests
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum
import logging
import json
import time
import threading
from collections import defaultdict, deque
import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
import ta
from concurrent.futures import ThreadPoolExecutor
import warnings

from universal_market_data import get_current_market_data, validate_price

warnings.filterwarnings('ignore')

# Try to import optional packages
try:
    import polygon
    POLYGON_AVAILABLE = True
except ImportError:
    POLYGON_AVAILABLE = False

try:
    import alpha_vantage
    ALPHA_VANTAGE_AVAILABLE = True
except ImportError:
    ALPHA_VANTAGE_AVAILABLE = False

logger = logging.getLogger(__name__)

class MarketRegime(Enum):
    BULL_STRONG = "bull_strong"
    BULL_WEAK = "bull_weak"
    BEAR_STRONG = "bear_strong"
    BEAR_WEAK = "bear_weak"
    SIDEWAYS = "sideways"
    HIGH_VOLATILITY = "high_volatility"
    LOW_VOLATILITY = "low_volatility"
    UNCERTAIN = "uncertain"

class VolatilityRegime(Enum):
    EXTREMELY_LOW = "extremely_low"    # <10th percentile
    LOW = "low"                        # 10-30th percentile
    NORMAL = "normal"                  # 30-70th percentile
    HIGH = "high"                      # 70-90th percentile
    EXTREMELY_HIGH = "extremely_high"  # >90th percentile

class TradingStrategy(Enum):
    # Bullish strategies
    LONG_CALL = "long_call"
    BULL_CALL_SPREAD = "bull_call_spread"
    CASH_SECURED_PUT = "cash_secured_put"
    WHEEL_STRATEGY = "wheel_strategy"
    
    # Bearish strategies
    LONG_PUT = "long_put"
    BEAR_PUT_SPREAD = "bear_put_spread"
    COVERED_CALL = "covered_call"
    PROTECTIVE_PUT = "protective_put"
    
    # Neutral strategies
    IRON_CONDOR = "iron_condor"
    IRON_BUTTERFLY = "iron_butterfly"
    JADE_LIZARD = "jade_lizard"
    SHORT_STRANGLE = "short_strangle"
    
    # Volatility strategies
    LONG_STRADDLE = "long_straddle"
    LONG_STRANGLE = "long_strangle"
    CALENDAR_SPREAD = "calendar_spread"
    
    # Advanced strategies
    RATIO_SPREAD = "ratio_spread"
    BUTTERFLY_SPREAD = "butterfly_spread"
    CONDOR_SPREAD = "condor_spread"

@dataclass
class MarketCondition:
    """Current market condition analysis"""
    timestamp: datetime
    symbol: str
    
    # Price metrics
    price: float
    price_change_1d: float
    price_change_5d: float
    price_change_20d: float
    
    # Volatility metrics
    realized_vol_10d: float
    realized_vol_30d: float
    implied_vol: float
    vol_percentile: float
    vol_regime: VolatilityRegime
    
    # Trend indicators
    sma_20: float
    sma_50: float
    sma_200: float
    ema_12: float
    ema_26: float
    macd: float
    macd_signal: float
    rsi_14: float
    
    # Market structure
    support_level: float
    resistance_level: float
    trend_strength: float
    market_regime: MarketRegime
    
    # Options specific
    put_call_ratio: float
    options_volume: int
    max_pain: float
    skew: float
    
    # Sentiment indicators
    vix_level: float
    fear_greed_index: float
    news_sentiment: float
    
    # Liquidity metrics
    bid_ask_spread: float
    option_liquidity_score: float

@dataclass
class StrategyRecommendation:
    """Strategy recommendation with rationale"""
    strategy: TradingStrategy
    confidence: float  # 0-1
    expected_return: float
    max_risk: float
    win_probability: float
    time_horizon: str
    rationale: str
    specific_parameters: Dict
    market_conditions_needed: List[str]

class DataSourceManager:
    """Manages multiple data sources for comprehensive market analysis"""
    
    def __init__(self):
        self._cache = {}
        self.data_cache = {}
        self.cache_expiry = {}
        self.rate_limits = defaultdict(lambda: {'count': 0, 'reset_time': time.time()})
        
        # API configurations
        self.apis = {}
            'yahoo': {'rate_limit': 2000, 'window': 3600},  # 2000/hour
            'polygon': {'rate_limit': 1000, 'window': 60},   # 1000/minute
            'alpha_vantage': {'rate_limit': 500, 'window': 86400},  # 500/day
            'optiondata': {'rate_limit': 100, 'window': 3600},  # 100/hour
            'fear_greed': {'rate_limit': 10, 'window': 3600}   # 10/hour
        }
        
    def _check_rate_limit(self, source: str) -> bool:
        """Check if we can make API call within rate limits"""
        current_time = time.time()
        api_config = self.apis.get(source, {'rate_limit': 100, 'window': 3600})
        
        rate_info = self.rate_limits[source]
        
        # Reset counter if window has passed
        if current_time - rate_info['reset_time'] > api_config['window']:
            rate_info['count'] = 0
            rate_info['reset_time'] = current_time
            
        # Check if under limit
        if rate_info['count'] < api_config['rate_limit']:
            rate_info['count'] += 1
            return True
            
        return False
        
    def _get_cached_data(self, key: str, max_age: int = 300) -> Optional[Dict]:
        """Get cached data if still valid"""
        if key in self.data_cache and key in self.cache_expiry:
            if time.time() - self.cache_expiry[key] < max_age:
                return self.data_cache[key]
        return None
        
    def _cache_data(self, key: str, data: Dict):
        """Cache data with timestamp"""
        self.data_cache[key] = data
        self.cache_expiry[key] = time.time()
        
    async def get_yahoo_data(self, symbol: str, period: str = "1y") -> Optional[pd.DataFrame]:
        """Get data from Yahoo Finance"""
        try:
            cache_key = f"yahoo_{symbol}_{period}"
            cached = self._get_cached_data(cache_key, 60)  # 1 minute cache
            
            if cached:
                return pd.DataFrame(cached)
                
            if not self._check_rate_limit('yahoo'):
                logger.warning("Yahoo Finance rate limit exceeded")
                return None
                
            ticker = YFinanceWrapper().get_ticker(symbol)
            data = ticker.history(period=period)
            
            if not data.empty:
                self._cache_data(cache_key, data.to_dict())
                return data
                
        except Exception as e:
            logger.error(f"Yahoo Finance data error for {symbol}: {e}")
            
        return None
        
    async def get_options_data_org(self, symbol: str) -> Optional[Dict]:
        """Get options data from optiondata.org"""
        try:
            cache_key = f"optiondata_{symbol}"
            cached = self._get_cached_data(cache_key, 300)  # 5 minute cache
            
            if cached:
                return cached
                
            if not self._check_rate_limit('optiondata'):
                logger.warning("OptionData.org rate limit exceeded")
                return None
                
            # This would be the actual API call to optiondata.org
            # For demo, we'll simulate the response
            async with aiohttp.ClientSession() as session:
                # Note: This is a placeholder URL - replace with actual API endpoint
                url = f"https://api.optiondata.org/v1/quotes/{symbol}"
                
                try:
                    async with session.get(url, timeout=10) as response:
                        if response.status == 200:
                            data = await response.json()
                            self._cache_data(cache_key, data)
                            return data
                except:
                    # Fallback to simulated data
                    data = self._simulate_options_data(symbol)
                    self._cache_data(cache_key, data)
                    return data
                    
        except Exception as e:
            logger.error(f"OptionData.org error for {symbol}: {e}")
            
        return None
        
    def _simulate_options_data(self, symbol: str) -> Dict:
        """Simulate options data for demo purposes"""
        return {}
            'symbol': symbol,
            'implied_volatility': np.random.uniform(0.15, 0.45),
            'put_call_ratio': np.random.uniform(0.5, 1.5),
            'options_volume': np.random.randint(1000, 50000),
            'max_pain': np.random.uniform(90, 110),
            'skew': np.random.uniform(-0.1, 0.3),
            'bid_ask_spread': np.random.uniform(0.01, 0.10),
            'liquidity_score': np.random.uniform(0.3, 0.9),
            'open_interest': np.random.randint(1000, 100000)
        }
        
    async def get_fear_greed_index(self) -> Optional[float]:
        """Get Fear & Greed Index"""
        try:
            cache_key = "fear_greed_index"
            cached = self._get_cached_data(cache_key, 3600)  # 1 hour cache
            
            if cached:
                return cached.get('value', 50.0)
                
            if not self._check_rate_limit('fear_greed'):
                return 50.0  # Neutral default
                
            # Simulate API call (replace with actual endpoint)
            value = np.random.uniform(10, 90)
            self._cache_data(cache_key, {'value': value})
            return value
            
        except Exception as e:
            logger.error(f"Fear & Greed Index error: {e}")
            return 50.0
            
    async def get_vix_data(self) -> Optional[float]:
        """Get VIX data"""
        try:
            vix_data = await self.get_yahoo_data("^VIX", "5d")
            if vix_data is not None and not vix_data.empty:
                return float(vix_data['Close'].iloc[-1])
            return 20.0  # Default VIX level
            
        except Exception as e:
            logger.error(f"VIX data error: {e}")
            return 20.0

class TechnicalAnalyzer:
    """Advanced technical analysis with multiple indicators"""
    
    def __init__(self):
        self.lookback_periods = [5, 10, 20, 50, 100, 200]
        
    def analyze_price_action(self, data: pd.DataFrame) -> Dict:
        """Comprehensive price action analysis"""
        try:
            if data.empty or len(data) < 50:
                return {}
                
            close = data['Close']
            high = data['High']
            low = data['Low']
            volume = data['Volume']
            
            analysis = {}
            
            # Moving averages
            analysis['sma_20'] = ta.trend.sma_indicator(close, window=20).iloc[-1]
            analysis['sma_50'] = ta.trend.sma_indicator(close, window=50).iloc[-1]
            analysis['sma_200'] = ta.trend.sma_indicator(close, window=200).iloc[-1]
            analysis['ema_12'] = ta.trend.ema_indicator(close, window=12).iloc[-1]
            analysis['ema_26'] = ta.trend.ema_indicator(close, window=26).iloc[-1]
            
            # MACD
            macd_line = ta.trend.macd(close)
            macd_signal = ta.trend.macd_signal(close)
            analysis['macd'] = macd_line.iloc[-1] if not macd_line.empty else 0
            analysis['macd_signal'] = macd_signal.iloc[-1] if not macd_signal.empty else 0
            
            # RSI
            analysis['rsi_14'] = ta.momentum.rsi(close, window=14).iloc[-1]
            
            # Bollinger Bands
            bb_high = ta.volatility.bollinger_hband(close)
            bb_low = ta.volatility.bollinger_lband(close)
            analysis['bb_upper'] = bb_high.iloc[-1] if not bb_high.empty else close.iloc[-1] * 1.02
            analysis['bb_lower'] = bb_low.iloc[-1] if not bb_low.empty else close.iloc[-1] * 0.98
            
            # Support and Resistance
            analysis['support_level'] = self._find_support_level(data)
            analysis['resistance_level'] = self._find_resistance_level(data)
            
            # Trend strength
            analysis['trend_strength'] = self._calculate_trend_strength(close)
            
            # Volatility
            analysis['realized_vol_10d'] = self._calculate_realized_volatility(close, 10)
            analysis['realized_vol_30d'] = self._calculate_realized_volatility(close, 30)
            
            # Volume analysis
            analysis['volume_trend'] = self._analyze_volume_trend(volume)
            
            # Price changes
            analysis['price_change_1d'] = (close.iloc[-1] - close.iloc[-2]) / close.iloc[-2] * 100
            analysis['price_change_5d'] = (close.iloc[-1] - close.iloc[-6]) / close.iloc[-6] * 100
            analysis['price_change_20d'] = (close.iloc[-1] - close.iloc[-21]) / close.iloc[-21] * 100
            
            return analysis
            
        except Exception as e:
            logger.error(f"Technical analysis error: {e}")
            return {}
            
    def _find_support_level(self, data: pd.DataFrame, lookback: int = 20) -> float:
        """Find key support level"""
        try:
            low_prices = data['Low'].tail(lookback)
            # Find the most significant low (simplified approach)
            return low_prices.min()
        except:
            return data['Close'].iloc[-1] * 0.95
            
    def _find_resistance_level(self, data: pd.DataFrame, lookback: int = 20) -> float:
        """Find key resistance level"""
        try:
            high_prices = data['High'].tail(lookback)
            # Find the most significant high (simplified approach)
            return high_prices.max()
        except:
            return data['Close'].iloc[-1] * 1.05
            
    def _calculate_trend_strength(self, prices: pd.Series) -> float:
        """Calculate trend strength (0-1)"""
        try:
            if len(prices) < 20:
                return 0.5
                
            # Linear regression slope
            x = np.arange(len(prices[-20:]))
            y = prices[-20:].values
            slope = np.polyfit(x, y, 1)[0]
            
            # Normalize slope to 0-1 range
            price_range = prices[-20:].max() - prices[-20:].min()
            normalized_slope = abs(slope) / (price_range / 20) if price_range > 0 else 0
            
            return min(1.0, normalized_slope)
            
        except:
            return 0.5
            
    def _calculate_realized_volatility(self, prices: pd.Series, window: int) -> float:
        """Calculate realized volatility"""
        try:
            returns = prices.pct_change().dropna()
            if len(returns) < window:
                return 0.2
                
            vol = returns.tail(window).std() * np.sqrt(252)
            return vol
            
        except:
            return 0.2
            
    def _analyze_volume_trend(self, volume: pd.Series) -> str:
        """Analyze volume trend"""
        try:
            if len(volume) < 10:
                return "neutral"
                
            recent_avg = volume.tail(5).mean()
            historical_avg = volume.tail(20).mean()
            
            if recent_avg > historical_avg * 1.2:
                return "increasing"
            elif recent_avg < historical_avg * 0.8:
                return "decreasing"
            else:
                return "neutral"
                
        except:
            return "neutral"

class MarketRegimeDetector:
    """Detect current market regime using multiple indicators"""
    
    def __init__(self):
        self.regime_history = deque(maxlen=100)
        
    def detect_regime(self, market_condition: MarketCondition) -> MarketRegime:
        """Detect current market regime"""
        try:
            # Price trend analysis
            price_trend_score = self._analyze_price_trend(market_condition)
            
            # Volatility analysis
            vol_score = self._analyze_volatility(market_condition)
            
            # Momentum analysis
            momentum_score = self._analyze_momentum(market_condition)
            
            # Combine scores to determine regime
            regime = self._classify_regime(price_trend_score, vol_score, momentum_score)
            
            # Store in history
            self.regime_history.append({)
                'timestamp': market_condition.timestamp,
                'regime': regime,
                'price_trend_score': price_trend_score,
                'vol_score': vol_score,
                'momentum_score': momentum_score
            })
            
            return regime
            
        except Exception as e:
            logger.error(f"Regime detection error: {e}")
            return MarketRegime.UNCERTAIN
            
    def _analyze_price_trend(self, mc: MarketCondition) -> float:
        """Analyze price trend strength (-1 to 1)"""
        try:
            # Moving average relationships
            ma_score = 0
            if mc.price > mc.sma_20 > mc.sma_50 > mc.sma_200:
                ma_score = 1.0  # Strong uptrend
            elif mc.price < mc.sma_20 < mc.sma_50 < mc.sma_200:
                ma_score = -1.0  # Strong downtrend
            elif mc.price > mc.sma_20:
                ma_score = 0.5  # Weak uptrend
            elif mc.price < mc.sma_20:
                ma_score = -0.5  # Weak downtrend
                
            # Recent price changes
            price_momentum = (mc.price_change_5d / 100) * 2  # Scale to -1 to 1
            price_momentum = max(-1, min(1, price_momentum))
            
            # Combine scores
            return (ma_score * 0.6 + price_momentum * 0.4)
            
        except:
            return 0.0
            
    def _analyze_volatility(self, mc: MarketCondition) -> float:
        """Analyze volatility regime (0 to 1, where 1 is very high vol)"""
        try:
            # VIX analysis
            vix_score = min(1.0, mc.vix_level / 50.0)  # Normalize VIX
            
            # Realized volatility
            vol_score = min(1.0, mc.realized_vol_30d / 0.5)  # Normalize realized vol
            
            # Volatility percentile
            percentile_score = mc.vol_percentile / 100.0
            
            return (vix_score * 0.4 + vol_score * 0.4 + percentile_score * 0.2)
            
        except:
            return 0.5
            
    def _analyze_momentum(self, mc: MarketCondition) -> float:
        """Analyze momentum indicators (-1 to 1)"""
        try:
            # RSI analysis
            if mc.rsi_14 > 70:
                rsi_score = 1.0  # Overbought
            elif mc.rsi_14 < 30:
                rsi_score = -1.0  # Oversold
            else:
                rsi_score = (mc.rsi_14 - 50) / 20  # Normalize around 50
                
            # MACD analysis
            macd_score = 0
            if mc.macd > mc.macd_signal:
                macd_score = 0.5
            else:
                macd_score = -0.5
                
            return (rsi_score * 0.6 + macd_score * 0.4)
            
        except:
            return 0.0
            
    def _classify_regime(self, price_trend: float, volatility: float, momentum: float) -> MarketRegime:
        """Classify market regime based on component scores"""
        try:
            # High volatility regime
            if volatility > 0.7:
                return MarketRegime.HIGH_VOLATILITY
                
            # Low volatility regime
            if volatility < 0.3:
                return MarketRegime.LOW_VOLATILITY
                
            # Bull market regimes
            if price_trend > 0.6 and momentum > 0.3:
                return MarketRegime.BULL_STRONG
            elif price_trend > 0.2 and momentum > 0:
                return MarketRegime.BULL_WEAK
                
            # Bear market regimes
            if price_trend < -0.6 and momentum < -0.3:
                return MarketRegime.BEAR_STRONG
            elif price_trend < -0.2 and momentum < 0:
                return MarketRegime.BEAR_WEAK
                
            # Sideways market
            if abs(price_trend) < 0.2 and abs(momentum) < 0.3:
                return MarketRegime.SIDEWAYS
                
            return MarketRegime.UNCERTAIN
            
        except:
            return MarketRegime.UNCERTAIN

class StrategySelector:
    """Intelligent strategy selection based on market conditions"""
    
    def __init__(self):
        self.strategy_database = self._initialize_strategy_database()
        self.performance_history = defaultdict(list)
        
    def _initialize_strategy_database(self) -> Dict:
        """Initialize strategy database with conditions and parameters"""
        return {}
            TradingStrategy.WHEEL_STRATEGY: {}
                'optimal_regimes': [MarketRegime.SIDEWAYS, MarketRegime.LOW_VOLATILITY],
                'volatility_range': (0.15, 0.35),
                'rsi_range': (30, 70),
                'trend_requirement': 'neutral_to_bullish',
                'min_confidence': 0.7,
                'expected_return': 0.15,  # 15% annual
                'max_risk': 0.20,
                'win_probability': 0.75,
                'time_horizon': '30-45 days',
                'description': 'Sell puts, get assigned, sell calls'
            },
            
            TradingStrategy.IRON_CONDOR: {}
                'optimal_regimes': [MarketRegime.SIDEWAYS, MarketRegime.LOW_VOLATILITY],
                'volatility_range': (0.10, 0.30),
                'rsi_range': (40, 60),
                'trend_requirement': 'neutral',
                'min_confidence': 0.6,
                'expected_return': 0.12,
                'max_risk': 0.15,
                'win_probability': 0.70,
                'time_horizon': '30-45 days',
                'description': 'Sell put spread + call spread'
            },
            
            TradingStrategy.BULL_CALL_SPREAD: {}
                'optimal_regimes': [MarketRegime.BULL_WEAK, MarketRegime.BULL_STRONG],
                'volatility_range': (0.15, 0.40),
                'rsi_range': (30, 65),
                'trend_requirement': 'bullish',
                'min_confidence': 0.6,
                'expected_return': 0.25,
                'max_risk': 0.30,
                'win_probability': 0.65,
                'time_horizon': '15-30 days',
                'description': 'Buy lower strike call, sell higher strike call'
            },
            
            TradingStrategy.LONG_STRADDLE: {}
                'optimal_regimes': [MarketRegime.HIGH_VOLATILITY, MarketRegime.UNCERTAIN],
                'volatility_range': (0.25, 1.0),
                'rsi_range': (20, 80),
                'trend_requirement': 'any',
                'min_confidence': 0.5,
                'expected_return': 0.30,
                'max_risk': 0.50,
                'win_probability': 0.55,
                'time_horizon': '7-21 days',
                'description': 'Buy call and put at same strike'
            },
            
            TradingStrategy.COVERED_CALL: {}
                'optimal_regimes': [MarketRegime.BULL_WEAK, MarketRegime.SIDEWAYS],
                'volatility_range': (0.15, 0.35),
                'rsi_range': (50, 75),
                'trend_requirement': 'neutral_to_bullish',
                'min_confidence': 0.7,
                'expected_return': 0.08,
                'max_risk': 0.10,
                'win_probability': 0.80,
                'time_horizon': '30-45 days',
                'description': 'Own stock, sell call option'
            },
            
            TradingStrategy.CASH_SECURED_PUT: {}
                'optimal_regimes': [MarketRegime.BULL_WEAK, MarketRegime.SIDEWAYS],
                'volatility_range': (0.20, 0.45),
                'rsi_range': (30, 60),
                'trend_requirement': 'neutral_to_bullish',
                'min_confidence': 0.6,
                'expected_return': 0.12,
                'max_risk': 0.25,
                'win_probability': 0.75,
                'time_horizon': '15-45 days',
                'description': 'Sell put with cash backing'
            },
            
            TradingStrategy.BEAR_PUT_SPREAD: {}
                'optimal_regimes': [MarketRegime.BEAR_WEAK, MarketRegime.BEAR_STRONG],
                'volatility_range': (0.15, 0.40),
                'rsi_range': (35, 70),
                'trend_requirement': 'bearish',
                'min_confidence': 0.6,
                'expected_return': 0.25,
                'max_risk': 0.30,
                'win_probability': 0.65,
                'time_horizon': '15-30 days',
                'description': 'Buy higher strike put, sell lower strike put'
            },
            
            TradingStrategy.JADE_LIZARD: {}
                'optimal_regimes': [MarketRegime.BULL_WEAK, MarketRegime.SIDEWAYS],
                'volatility_range': (0.20, 0.40),
                'rsi_range': (35, 65),
                'trend_requirement': 'neutral_to_bullish',
                'min_confidence': 0.6,
                'expected_return': 0.18,
                'max_risk': 0.25,
                'win_probability': 0.70,
                'time_horizon': '30-45 days',
                'description': 'Short put + short call spread'
            },
            
            TradingStrategy.CALENDAR_SPREAD: {}
                'optimal_regimes': [MarketRegime.LOW_VOLATILITY, MarketRegime.SIDEWAYS],
                'volatility_range': (0.10, 0.25),
                'rsi_range': (40, 60),
                'trend_requirement': 'neutral',
                'min_confidence': 0.5,
                'expected_return': 0.15,
                'max_risk': 0.20,
                'win_probability': 0.60,
                'time_horizon': '20-35 days',
                'description': 'Sell near-term, buy far-term same strike'
            }
        }
        
    def select_optimal_strategies(self, market_condition: MarketCondition, 
                                count: int = 3) -> List[StrategyRecommendation]:
        """Select optimal strategies based on current market conditions"""
        try:
            recommendations = []
            
            for strategy, config in self.strategy_database.items():
                confidence = self._calculate_strategy_confidence(market_condition, config)
                
                if confidence >= config['min_confidence']:
                    # Generate specific parameters
                    specific_params = self._generate_strategy_parameters(strategy, market_condition)
                    
                    # Create recommendation
                    recommendation = StrategyRecommendation()
                        strategy=strategy,
                        confidence=confidence,
                        expected_return=config['expected_return'],
                        max_risk=config['max_risk'],
                        win_probability=config['win_probability'],
                        time_horizon=config['time_horizon'],
                        rationale=self._generate_rationale(strategy, market_condition, config),
                        specific_parameters=specific_params,
                        market_conditions_needed=self._get_required_conditions(config)
                    )
                    
                    recommendations.append(recommendation)
                    
            # Sort by confidence and return top recommendations
            recommendations.sort(key=lambda x: x.confidence, reverse=True)
            return recommendations[:count]
            
        except Exception as e:
            logger.error(f"Strategy selection error: {e}")
            return []
            
    def _calculate_strategy_confidence(self, mc: MarketCondition, config: Dict) -> float:
        """Calculate confidence score for strategy given market conditions"""
        try:
            confidence = 0.0
            
            # Regime match
            if mc.market_regime in config['optimal_regimes']:
                confidence += 0.4
            elif mc.market_regime == MarketRegime.UNCERTAIN:
                confidence += 0.1
                
            # Volatility match
            vol_min, vol_max = config['volatility_range']
            if vol_min <= mc.realized_vol_30d <= vol_max:
                confidence += 0.3
            else:
                # Partial credit for close matches
                vol_diff = min(abs(mc.realized_vol_30d - vol_min), abs(mc.realized_vol_30d - vol_max))
                confidence += max(0, 0.3 - vol_diff)
                
            # RSI match
            rsi_min, rsi_max = config['rsi_range']
            if rsi_min <= mc.rsi_14 <= rsi_max:
                confidence += 0.2
            else:
                rsi_diff = min(abs(mc.rsi_14 - rsi_min), abs(mc.rsi_14 - rsi_max))
                confidence += max(0, 0.2 - rsi_diff / 50)
                
            # Trend requirement
            trend_req = config['trend_requirement']
            if trend_req == 'bullish' and mc.trend_strength > 0.6 and mc.price_change_5d > 0:
                confidence += 0.1
            elif trend_req == 'bearish' and mc.trend_strength > 0.6 and mc.price_change_5d < 0:
                confidence += 0.1
            elif trend_req == 'neutral' and mc.trend_strength < 0.4:
                confidence += 0.1
            elif trend_req in ['neutral_to_bullish', 'any']:
                confidence += 0.05
                
            return min(1.0, confidence)
            
        except Exception as e:
            logger.error(f"Confidence calculation error: {e}")
            return 0.0
            
    def _generate_strategy_parameters(self, strategy: TradingStrategy, 
                                    mc: MarketCondition) -> Dict:
        """Generate specific parameters for strategy"""
        try:
            base_params = {}
                'symbol': mc.symbol,
                'current_price': mc.price,
                'target_dte': 30,
                'position_size': 1
            }
            
            if strategy == TradingStrategy.WHEEL_STRATEGY:
                base_params.update({)
                    'put_delta': 0.20,
                    'call_delta': 0.20,
                    'profit_target': 0.50,
                    'max_dte': 45
                })
                
            elif strategy == TradingStrategy.IRON_CONDOR:
                base_params.update({)
                    'put_delta': 0.15,
                    'call_delta': 0.15,
                    'wing_width': 10,
                    'profit_target': 0.50
                })
                
            elif strategy == TradingStrategy.BULL_CALL_SPREAD:
                base_params.update({)
                    'long_delta': 0.70,
                    'short_delta': 0.30,
                    'max_width': 5,
                    'profit_target': 0.75
                })
                
            elif strategy == TradingStrategy.COVERED_CALL:
                base_params.update({)
                    'call_delta': 0.25,
                    'profit_target': 0.50,
                    'strike_selection': 'otm'
                })
                
            # Adjust based on volatility
            if mc.vol_regime == VolatilityRegime.HIGH:
                base_params['profit_target'] = base_params.get('profit_target', 0.5) * 0.8
            elif mc.vol_regime == VolatilityRegime.LOW:
                base_params['target_dte'] = min(45, base_params.get('target_dte', 30) + 15)
                
            return base_params
            
        except Exception as e:
            logger.error(f"Parameter generation error: {e}")
            return {}
            
    def _generate_rationale(self, strategy: TradingStrategy, mc: MarketCondition, 
                          config: Dict) -> str:
        """Generate human-readable rationale for strategy selection"""
        try:
            rationale_parts = []
            
            # Market regime reasoning
            if mc.market_regime in config['optimal_regimes']:
                rationale_parts.append(f"Current {mc.market_regime.value} market is optimal for this strategy")
                
            # Volatility reasoning
            vol_min, vol_max = config['volatility_range']
            if vol_min <= mc.realized_vol_30d <= vol_max:
                rationale_parts.append(f"30-day volatility of {mc.realized_vol_30d:.1%} is in target range")
                
            # Technical indicators
            if 30 <= mc.rsi_14 <= 70:
                rationale_parts.append(f"RSI of {mc.rsi_14:.1f} indicates balanced momentum")
            elif mc.rsi_14 > 70:
                rationale_parts.append("Overbought RSI suggests selling premium strategies")
            elif mc.rsi_14 < 30:
                rationale_parts.append("Oversold RSI suggests buying opportunities")
                
            # Options-specific factors
            if mc.implied_vol > mc.realized_vol_30d * 1.2:
                rationale_parts.append("Elevated implied volatility favors premium selling")
            elif mc.implied_vol < mc.realized_vol_30d * 0.8:
                rationale_parts.append("Low implied volatility favors premium buying")
                
            # Fear/greed considerations
            if mc.fear_greed_index < 25:
                rationale_parts.append("Extreme fear creates contrarian opportunities")
            elif mc.fear_greed_index > 75:
                rationale_parts.append("Extreme greed suggests defensive positioning")
                
            return ". ".join(rationale_parts) + "."
            
        except Exception as e:
            logger.error(f"Rationale generation error: {e}")
            return f"Strategy selected based on current market analysis for {strategy.value}"
            
    def _get_required_conditions(self, config: Dict) -> List[str]:
        """Get list of required market conditions for strategy"""
        conditions = []
        
        if config['trend_requirement'] == 'bullish':
            conditions.append("Bullish trend")
        elif config['trend_requirement'] == 'bearish':
            conditions.append("Bearish trend")
        elif config['trend_requirement'] == 'neutral':
            conditions.append("Sideways/neutral trend")
            
        vol_min, vol_max = config['volatility_range']
        conditions.append(f"Volatility between {vol_min:.0%}-{vol_max:.0%}")
        
        rsi_min, rsi_max = config['rsi_range']
        conditions.append(f"RSI between {rsi_min}-{rsi_max}")
        
        return conditions

class StrategySelectionBot:
    """Main bot class that orchestrates strategy selection"""
    
    def __init__(self):
        self.data_manager = DataSourceManager()
        self.technical_analyzer = TechnicalAnalyzer()
        self.regime_detector = MarketRegimeDetector()
        self.strategy_selector = StrategySelector()
        
        # Bot state
        self.last_analysis = {}
        self.recommendations_history = deque(maxlen=100)
        
    async def analyze_and_recommend(self, symbol: str) -> Dict:
        """Main method to analyze market and recommend strategies"""
        try:
            logger.info(f"Starting analysis for {symbol}")
            
            # Gather market data
            market_condition = await self._gather_market_data(symbol)
            
            if not market_condition:
                return {'error': 'Failed to gather market data'}
                
            # Detect market regime
            market_condition.market_regime = self.regime_detector.detect_regime(market_condition)
            
            # Select optimal strategies
            recommendations = self.strategy_selector.select_optimal_strategies(market_condition)
            
            # Create comprehensive analysis
            analysis = {}
                'timestamp': datetime.now().isoformat(),
                'symbol': symbol,
                'market_condition': self._market_condition_to_dict(market_condition),
                'recommendations': [self._recommendation_to_dict(rec) for rec in recommendations],
                'market_summary': self._generate_market_summary(market_condition),
                'risk_assessment': self._assess_overall_risk(market_condition, recommendations)
            }
            
            # Store in history
            self.recommendations_history.append(analysis)
            self.last_analysis[symbol] = analysis
            
            logger.info(f"Analysis completed for {symbol} - {len(recommendations)} strategies recommended")
            
            return analysis
            
        except Exception as e:
            logger.error(f"Analysis failed for {symbol}: {e}")
            return {'error': str(e)}
            
    async def _gather_market_data(self, symbol: str) -> Optional[MarketCondition]:
        """Gather comprehensive market data from multiple sources"""
        try:
            # Gather data from multiple sources concurrently
            tasks = []
                self.data_manager.get_yahoo_data(symbol, "1y"),
                self.data_manager.get_options_data_org(symbol),
                self.data_manager.get_vix_data(),
                self.data_manager.get_fear_greed_index()
            ]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            price_data, options_data, vix_level, fear_greed = results
            
            # Handle failed data sources
            if isinstance(price_data, Exception) or price_data is None:
                logger.error(f"Failed to get price data for {symbol}")
                return None
                
            if isinstance(options_data, Exception):
                options_data = self.data_manager._simulate_options_data(symbol)
                
            if isinstance(vix_level, Exception):
                vix_level = 20.0
                
            if isinstance(fear_greed, Exception):
                fear_greed = 50.0
                
            # Perform technical analysis
            technical_analysis = self.technical_analyzer.analyze_price_action(price_data)
            
            if not technical_analysis:
                logger.error(f"Technical analysis failed for {symbol}")
                return None
                
            # Determine volatility regime
            vol_percentile = self._calculate_volatility_percentile()
                technical_analysis.get('realized_vol_30d', 0.2), price_data
            )
            vol_regime = self._classify_volatility_regime(vol_percentile)
            
            # Create market condition
            current_price = float(price_data['Close'].iloc[-1])
            
            market_condition = MarketCondition()
                timestamp=datetime.now(),
                symbol=symbol,
                
                # Price metrics
                price=current_price,
                price_change_1d=technical_analysis.get('price_change_1d', 0),
                price_change_5d=technical_analysis.get('price_change_5d', 0),
                price_change_20d=technical_analysis.get('price_change_20d', 0),
                
                # Volatility metrics
                realized_vol_10d=technical_analysis.get('realized_vol_10d', 0.2),
                realized_vol_30d=technical_analysis.get('realized_vol_30d', 0.2),
                implied_vol=options_data.get('implied_volatility', 0.25),
                vol_percentile=vol_percentile,
                vol_regime=vol_regime,
                
                # Technical indicators
                sma_20=technical_analysis.get('sma_20', current_price),
                sma_50=technical_analysis.get('sma_50', current_price),
                sma_200=technical_analysis.get('sma_200', current_price),
                ema_12=technical_analysis.get('ema_12', current_price),
                ema_26=technical_analysis.get('ema_26', current_price),
                macd=technical_analysis.get('macd', 0),
                macd_signal=technical_analysis.get('macd_signal', 0),
                rsi_14=technical_analysis.get('rsi_14', 50),
                
                # Market structure
                support_level=technical_analysis.get('support_level', current_price * 0.95),
                resistance_level=technical_analysis.get('resistance_level', current_price * 1.05),
                trend_strength=technical_analysis.get('trend_strength', 0.5),
                market_regime=MarketRegime.UNCERTAIN,  # Will be set by regime detector
                
                # Options specific
                put_call_ratio=options_data.get('put_call_ratio', 1.0),
                options_volume=options_data.get('options_volume', 1000),
                max_pain=options_data.get('max_pain', current_price),
                skew=options_data.get('skew', 0.0),
                
                # Sentiment
                vix_level=vix_level,
                fear_greed_index=fear_greed,
                news_sentiment=0.0,  # Could be added later
                
                # Liquidity
                bid_ask_spread=options_data.get('bid_ask_spread', 0.05),
                option_liquidity_score=options_data.get('liquidity_score', 0.5)
            )
            
            return market_condition
            
        except Exception as e:
            logger.error(f"Market data gathering error: {e}")
            return None
            
    def _calculate_volatility_percentile(self, current_vol: float, price_data: pd.DataFrame) -> float:
        """Calculate volatility percentile over historical data"""
        try:
            if len(price_data) < 252:
                return 50.0
                
            # Calculate rolling 30-day volatility for past year
            returns = price_data['Close'].pct_change().dropna()
            rolling_vol = returns.rolling(30).std() * np.sqrt(252)
            rolling_vol = rolling_vol.dropna()
            
            if len(rolling_vol) < 10:
                return 50.0
                
            # Calculate percentile
            percentile = (rolling_vol < current_vol).sum() / len(rolling_vol) * 100
            return percentile
            
        except Exception as e:
            logger.error(f"Volatility percentile calculation error: {e}")
            return 50.0
            
    def _classify_volatility_regime(self, percentile: float) -> VolatilityRegime:
        """Classify volatility regime based on percentile"""
        if percentile < 10:
            return VolatilityRegime.EXTREMELY_LOW
        elif percentile < 30:
            return VolatilityRegime.LOW
        elif percentile < 70:
            return VolatilityRegime.NORMAL
        elif percentile < 90:
            return VolatilityRegime.HIGH
        else:
            return VolatilityRegime.EXTREMELY_HIGH
            
    def _market_condition_to_dict(self, mc: MarketCondition) -> Dict:
        """Convert MarketCondition to dictionary"""
        return {}
            'symbol': mc.symbol,
            'price': mc.price,
            'price_changes': {}
                '1d': mc.price_change_1d,
                '5d': mc.price_change_5d,
                '20d': mc.price_change_20d
            },
            'volatility': {}
                'realized_10d': mc.realized_vol_10d,
                'realized_30d': mc.realized_vol_30d,
                'implied': mc.implied_vol,
                'percentile': mc.vol_percentile,
                'regime': mc.vol_regime.value
            },
            'technical_indicators': {}
                'rsi': mc.rsi_14,
                'macd': mc.macd,
                'trend_strength': mc.trend_strength,
                'support': mc.support_level,
                'resistance': mc.resistance_level
            },
            'market_regime': mc.market_regime.value,
            'sentiment': {}
                'vix': mc.vix_level,
                'fear_greed': mc.fear_greed_index,
                'put_call_ratio': mc.put_call_ratio
            }
        }
        
    def _recommendation_to_dict(self, rec: StrategyRecommendation) -> Dict:
        """Convert StrategyRecommendation to dictionary"""
        return {}
            'strategy': rec.strategy.value,
            'confidence': rec.confidence,
            'expected_return': rec.expected_return,
            'max_risk': rec.max_risk,
            'win_probability': rec.win_probability,
            'time_horizon': rec.time_horizon,
            'rationale': rec.rationale,
            'parameters': rec.specific_parameters,
            'required_conditions': rec.market_conditions_needed
        }
        
    def _generate_market_summary(self, mc: MarketCondition) -> str:
        """Generate human-readable market summary"""
        try:
            summary_parts = []
            
            # Price action
            if mc.price_change_1d > 2:
                summary_parts.append("Strong upward momentum")
            elif mc.price_change_1d < -2:
                summary_parts.append("Strong downward momentum")
            else:
                summary_parts.append("Moderate price action")
                
            # Volatility
            if mc.vol_regime == VolatilityRegime.EXTREMELY_HIGH:
                summary_parts.append("extremely high volatility environment")
            elif mc.vol_regime == VolatilityRegime.HIGH:
                summary_parts.append("elevated volatility")
            elif mc.vol_regime == VolatilityRegime.LOW:
                summary_parts.append("low volatility environment")
            else:
                summary_parts.append("normal volatility levels")
                
            # Market regime
            summary_parts.append(f"in a {mc.market_regime.value.replace('_', ' ')} market regime")
            
            # Sentiment
            if mc.fear_greed_index > 75:
                summary_parts.append("with extreme greed sentiment")
            elif mc.fear_greed_index < 25:
                summary_parts.append("with extreme fear sentiment")
                
            return f"{mc.symbol} is experiencing " + ", ".join(summary_parts) + "."
            
        except Exception as e:
            logger.error(f"Market summary generation error: {e}")
            return f"Market analysis completed for {mc.symbol}"
            
    def _assess_overall_risk(self, mc: MarketCondition, 
                           recommendations: List[StrategyRecommendation]) -> Dict:
        """Assess overall risk of current market environment"""
        try:
            risk_factors = []
            risk_score = 0.0
            
            # Volatility risk
            if mc.vol_regime in [VolatilityRegime.EXTREMELY_HIGH, VolatilityRegime.HIGH]:
                risk_factors.append("High volatility increases strategy risk")
                risk_score += 0.3
                
            # Trend risk
            if mc.trend_strength > 0.8:
                risk_factors.append("Strong trending market may challenge neutral strategies")
                risk_score += 0.2
                
            # Sentiment risk
            if mc.fear_greed_index > 80 or mc.fear_greed_index < 20:
                risk_factors.append("Extreme sentiment suggests potential reversal risk")
                risk_score += 0.2
                
            # Technical risk
            if mc.rsi_14 > 80 or mc.rsi_14 < 20:
                risk_factors.append("Extreme RSI levels suggest overbought/oversold conditions")
                risk_score += 0.1
                
            # Liquidity risk
            if mc.option_liquidity_score < 0.3:
                risk_factors.append("Low options liquidity may impact execution")
                risk_score += 0.2
                
            # Overall assessment
            if risk_score < 0.3:
                risk_level = "Low"
            elif risk_score < 0.6:
                risk_level = "Moderate"
            elif risk_score < 0.8:
                risk_level = "High"
            else:
                risk_level = "Very High"
                
            return {}
                'risk_level': risk_level,
                'risk_score': risk_score,
                'risk_factors': risk_factors,
                'recommendations_available': len(recommendations) > 0
            }
            
        except Exception as e:
            logger.error(f"Risk assessment error: {e}")
            return {'risk_level': 'Unknown', 'risk_score': 0.5, 'risk_factors': []}
            
    def get_analysis_history(self, symbol: str = None, count: int = 10) -> List[Dict]:
        """Get historical analysis results"""
        if symbol:
            return [analysis for analysis in list(self.recommendations_history)[-count:]]
                   if analysis.get('symbol') == symbol]
        else:
            return list(self.recommendations_history)[-count:]
            
    async def monitor_multiple_symbols(self, symbols: List[str]) -> Dict[str, Dict]:
        """Monitor multiple symbols and return analysis for each"""
        results = {}
        
        # Analyze symbols concurrently
        tasks = [self.analyze_and_recommend(symbol) for symbol in symbols]
        analyses = await asyncio.gather(*tasks, return_exceptions=True)
        
        for symbol, analysis in zip(symbols, analyses):
            if isinstance(analysis, Exception):
                results[symbol] = {'error': str(analysis)}
            else:
                results[symbol] = analysis
                
        return results

# Example usage and testing
async def main():
    """Main demo function"""
    print("=== Strategy Selection Bot Demo ===\n")
    
    # Initialize bot
    bot = StrategySelectionBot()
    
    # Test symbols
    test_symbols = ['SPY', 'QQQ', 'AAPL']
    
    print("Testing single symbol analysis...")
    analysis = await bot.analyze_and_recommend('SPY')
    
    if 'error' not in analysis:
        print(f"\n📊 Market Analysis for {analysis['symbol']}:")
        print(f"   {analysis['market_summary']}")
        
        print(f"\n🎯 Strategy Recommendations:")
        for i, rec in enumerate(analysis['recommendations'], 1):
            print(f"   {i}. {rec['strategy'].replace('_', ' ').title()}")
            print(f"      Confidence: {rec['confidence']:.1%}")
            print(f"      Expected Return: {rec['expected_return']:.1%}")
            print(f"      Win Probability: {rec['win_probability']:.1%}")
            print(f"      Rationale: {rec['rationale'][:100]}...")
            print()
            
        print(f"⚠️  Risk Assessment: {analysis['risk_assessment']['risk_level']}")
        if analysis['risk_assessment']['risk_factors']:
            for factor in analysis['risk_assessment']['risk_factors']:
                print(f"   • {factor}")
    else:
        print(f"Analysis failed: {analysis['error']}")
    
    print(f"\n{'='*50}")
    print("Testing multiple symbol monitoring...")
    
    multi_analysis = await bot.monitor_multiple_symbols(test_symbols)
    
    for symbol, result in multi_analysis.items():
        if 'error' not in result:
            top_strategy = result['recommendations'][0] if result['recommendations'] else None
            if top_strategy:
                print(f"{symbol}: {top_strategy['strategy'].replace('_', ' ').title()} ")
                      f"({top_strategy['confidence']:.1%} confidence)")
        else:
            print(f"{symbol}: Analysis failed")
    
    print(f"\n=== Strategy Selection Bot Demo Complete ===")

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the demo
    asyncio.run(main())