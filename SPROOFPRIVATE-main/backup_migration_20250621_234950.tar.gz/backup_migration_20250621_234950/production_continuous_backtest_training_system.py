
#!/usr/bin/env python3
"""
Continuous Backtesting & Training System
========================================
Automatically discovers, tests, and optimizes all trading strategies
"""

# Alpaca imports
from concurrent.futures import ThreadPoolExecutor
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
import ast
import json
import sqlite3
import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Set
from dataclasses import dataclass, field
from pathlib import Path
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import logging
import hashlib
import pickle
import warnings
warnings.filterwarnings('ignore')

# Import our core modules
sys.path.append(os.path.dirname(os.path.abspath(__file__))
from core.config_manager import get_config, ConfigManager
from core.ml_management import get_model_manager, ModelConfig, ModelType
from core.paper_trading_simulator import PaperTradingSimulator
from core.risk_metrics_dashboard import RiskMetricsDashboard

from universal_market_data import get_current_market_data, validate_price


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

@dataclass
class StrategyInfo:
    """Information about a discovered strategy"""
    name: str
    file_path: str
    class_name: str
    parameters: Dict[str, Any]
    performance_history: List[Dict] = field(default_factory=list)
    last_updated: datetime = field(default_factory=datetime.now)
    
@dataclass
class BacktestResult:
    """Result from a single backtest"""
    strategy_name: str
    parameters: Dict[str, Any]
    market_scenario: str
    backtest_type: str  # 'walk_forward', 'monte_carlo', 'bootstrap'
    metrics: Dict[str, float]
    trades: List[Dict]
    equity_curve: List[float]
    timestamp: datetime = field(default_factory=datetime.now)

class StrategyScanner:
    """Scans project for trading strategies and extracts parameters"""
    
    def __init__(self, base_path: str = "/home/harry/alpaca-mcp"):
        self.base_path = Path(base_path)
        self.discovered_strategies: Dict[str, StrategyInfo] = {}
        
    def scan_for_strategies(self) -> Dict[str, StrategyInfo]:
        """Scan all Python files for trading strategies"""
        logger.info("Scanning for trading strategies...")
        
        for file_path in self.base_path.rglob("*.py"):
            if any(skip in str(file_path) for skip in ['__pycache__', '.git', 'test_']):
                continue
                
            try:
                self._scan_file(file_path)
            except Exception as e:
                logger.debug(f"Error scanning {file_path}: {e}")
                
        logger.info(f"Found {len(self.discovered_strategies)} strategies")
        return self.discovered_strategies
        
    def _scan_file(self, file_path: Path):
        """Scan a single file for strategies"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                
            tree = ast.parse(content)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    # Look for strategy-like classes
                    if any(pattern in node.name.lower() for pattern in)
                          ['strategy', 'bot', 'trader', 'system', 'algo']):
                        
                        parameters = self._extract_parameters(node, content)
                        
                        strategy_info = StrategyInfo()
                            name=f"{file_path.stem}_{node.name}",
                            file_path=str(file_path),
                            class_name=node.name,
                            parameters=parameters
                        )
                        
                        self.discovered_strategies[strategy_info.name] = strategy_info
                        
        except Exception as e:
            logger.debug(f"Could not parse {file_path}: {e}")
            
    def _extract_parameters(self, class_node: ast.ClassDef, content: str) -> Dict[str, Any]:
        """Extract configurable parameters from a class"""
        parameters = {}
        
        # Look for __init__ method
        for node in class_node.body:
            if isinstance(node, ast.FunctionDef) and node.name == '__init__':
                # Extract default parameters
                for i, arg in enumerate(node.args.args[1:]):  # Skip 'self'
                    if i < len(node.args.defaults):
                        param_name = arg.arg
                        default_value = self._get_default_value(node.args.defaults[i])
                        if default_value is not None:
                            parameters[param_name] = default_value
                            
        # Also look for class attributes that look like parameters
        for node in class_node.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        if any(pattern in target.id.lower() for pattern in)
                              ['threshold', 'period', 'window', 'limit', 'size']):
                            value = self._get_default_value(node.value)
                            if value is not None:
                                parameters[target.id] = value
                                
        return parameters
        
    def _get_default_value(self, node):
        """Extract default value from AST node"""
        try:
            if isinstance(node, ast.Constant):
                return node.value
            elif isinstance(node, ast.Num):
                return node.n
            elif isinstance(node, ast.Str):
                return node.s
            elif isinstance(node, ast.List):
                return [self._get_default_value(elt) for elt in node.elts]
            elif isinstance(node, ast.Dict):
                return {}
                    self._get_default_value(k): self._get_default_value(v) 
                    for k, v in zip(node.keys, node.values)
                }
        except Exception:
            pass
        return None

class MarketSimulator:
    """Generates various market scenarios for backtesting"""
    
    @staticmethod
    def generate_market_data(scenario: str, days: int = 252, 
                           symbols: List[str] = None) -> pd.DataFrame:
        """Generate market data for a specific scenario"""
        if symbols is None:
            symbols = ['SPY', 'QQQ', 'IWM', 'TLT', 'GLD']
            
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        data = {}
        
        for symbol in symbols:
            if scenario == 'bull_market':
                trend = 0.0008
                volatility = 0.015
                
            elif scenario == 'bear_market':
                trend = -0.0005
                volatility = 0.025
                
            elif scenario == 'high_volatility':
                trend = 0.0001
                volatility = 0.035
                
            elif scenario == 'low_volatility':
                trend = 0.0003
                volatility = 0.008
                
            elif scenario == 'sideways':
                trend = 0.0
                volatility = 0.012
                
            elif scenario == 'crash':
                trend = -0.002
                volatility = 0.05
                
            elif scenario == 'recovery':
                trend = 0.0012
                volatility = 0.02
                
            elif scenario == 'mixed':
                # Mix of different regimes
                trend = 0.0002
                volatility = 0.018
                
            else:  # 'normal'
                trend = 0.0003
                volatility = 0.015
                
            # Generate returns with regime changes
            returns = []
            current_trend = trend
            current_vol = volatility
            
            for i in range(days):
                # Occasional regime changes
                if np.self.get_market_data() < 0.05:  # 5% chance of regime change
                    current_trend = trend * np.self.get_price_in_range(0.5, 1.5)
                    current_vol = volatility * np.self.get_price_in_range(0.8, 1.2)
                    
                # Add autocorrelation
                if i > 0 and np.self.get_market_data() < 0.3:
                    momentum = returns[-1] * 0.2
                else:
                    momentum = 0
                    
                daily_return = self.get_price_distribution(current_trend + momentum, current_vol)
                
                # Add occasional jumps/gaps
                if np.self.get_market_data() < 0.02:  # 2% chance of gap
                    daily_return += self.get_price_distribution(0, volatility * 3)
                    
                returns.append(daily_return)
                
            # Convert to prices
            prices = 100 * np.exp(np.cumsum(returns)
            
            # Add OHLCV data
            data[f'{symbol}_open'] = prices * (1 + self.get_uniform_prices(-0.002, 0.002, days)
            data[f'{symbol}_high'] = prices * (1 + np.abs(self.get_price_distribution(0, 0.005, days))
            data[f'{symbol}_low'] = prices * (1 - np.abs(self.get_price_distribution(0, 0.005, days))
            data[f'{symbol}_close'] = prices
            data[f'{symbol}_volume'] = np.random.lognormal(16, 0.5, days).astype(int)
            
        return pd.DataFrame(data, index=dates)

class BacktestEngine:
    """Runs various types of backtests"""
    
    def __init__(self):
        self.commission = 0.001  # 0.1% per trade
        self.slippage = 0.0005   # 0.05% slippage
        
    async def run_backtest(self, strategy_info: StrategyInfo, 
                          market_data: pd.DataFrame,
                          parameters: Dict[str, Any],
                          backtest_type: str = 'standard') -> BacktestResult:
        """Run a single backtest"""
        
        if backtest_type == 'walk_forward':
            return await self._walk_forward_backtest(strategy_info, market_data, parameters)
        elif backtest_type == 'monte_carlo':
            return await self._monte_carlo_backtest(strategy_info, market_data, parameters)
        elif backtest_type == 'bootstrap':
            return await self._bootstrap_backtest(strategy_info, market_data, parameters)
        else:
            return await self._standard_backtest(strategy_info, market_data, parameters)
            
    async def _standard_backtest(self, strategy_info: StrategyInfo,
                                market_data: pd.DataFrame,
                                parameters: Dict[str, Any]) -> BacktestResult:
        """Standard sequential backtest"""
        
        # Initialize
        initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000"))
        cash = initial_capital
        positions = {}
        trades = []
        equity_curve = [initial_capital]
        
        # Simulate trading
        for i in range(1, len(market_data):
            date = market_data.index[i]
            
            # Get signals (simplified - would call actual strategy)
            signals = self._generate_signals(market_data.iloc[:i], parameters)
            
            for symbol, signal in signals.items():
                current_price = market_data.iloc[i][f'{symbol}_close']
                
                if signal > 0 and symbol not in positions:  # Buy signal
                    # Calculate position size
                    position_size = int(cash * 0.1 / current_price)  # 10% per position
                    if position_size > 0:
                        cost = position_size * current_price * (1 + self.commission + self.slippage)
                        if cost <= cash:
                            positions[symbol] = {}
                                'quantity': position_size,
                                'entry_price': current_price * (1 + self.slippage),
                                'entry_date': date
                            }
                            cash -= cost
                            trades.append({)
                                'date': date,
                                'symbol': symbol,
                                'side': 'buy',
                                'quantity': position_size,
                                'price': current_price * (1 + self.slippage),
                                'commission': position_size * current_price * self.commission
                            })
                            
                elif signal < 0 and symbol in positions:  # Sell signal
                    position = positions[symbol]
                    sell_price = current_price * (1 - self.slippage)
                    proceeds = position['quantity'] * sell_price * (1 - self.commission)
                    cash += proceeds
                    
                    # Record trade
                    pnl = (sell_price - position['entry_price']) * position['quantity']
                    trades.append({)
                        'date': date,
                        'symbol': symbol,
                        'side': 'sell',
                        'quantity': position['quantity'],
                        'price': sell_price,
                        'pnl': pnl,
                        'commission': position['quantity'] * sell_price * self.commission
                    })
                    
                    del positions[symbol]
                    
            # Update equity curve
            positions_value = sum()
                pos['quantity'] * market_data.iloc[i][f'{sym}_close'] 
                for sym, pos in positions.items()
            )
            equity_curve.append(cash + positions_value)
            
        # Calculate metrics
        equity_series = pd.Series(equity_curve)
        returns = equity_series.pct_change().dropna()
        
        metrics = {}
            'total_return': (equity_curve[-1] / initial_capital - 1),
            'annual_return': (equity_curve[-1] / initial_capital) ** (252 / len(market_data) - 1,
            'sharpe_ratio': returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0,
            'max_drawdown': (equity_series / equity_series.cummax() - 1).min(),
            'win_rate': len([t for t in trades if t.get('pnl', 0) > 0]) / len(trades) if trades else 0,
            'profit_factor': abs(sum(t.get('pnl', 0) for t in trades if t.get('pnl', 0) > 0) /)
                               sum(t.get('pnl', 0) for t in trades if t.get('pnl', 0) < 0) 
                           if any(t.get('pnl', 0) < 0 for t in trades) else 0,
            'total_trades': len(trades),
            'avg_trade': np.mean([t.get('pnl', 0) for t in trades]) if trades else 0
        }
        
        return BacktestResult()
            strategy_name=strategy_info.name,
            parameters=parameters,
            market_scenario='mixed',
            backtest_type='standard',
            metrics=metrics,
            trades=trades,
            equity_curve=equity_curve
        )
        
    async def _walk_forward_backtest(self, strategy_info: StrategyInfo,
                                   market_data: pd.DataFrame,
                                   parameters: Dict[str, Any]) -> BacktestResult:
        """Walk-forward analysis"""
        
        # Split data into train/test windows
        window_size = len(market_data) // 5  # 5 windows
        results = []
        
        for i in range(4):
            train_start = i * window_size // 2
            train_end = train_start + window_size
            test_start = train_end
            test_end = min(test_start + window_size // 2, len(market_data)
            
            # Optimize on training data
            train_data = market_data.iloc[train_start:train_end]
            optimized_params = await self._optimize_parameters()
                strategy_info, train_data, parameters
            )
            
            # Test on out-of-sample data
            test_data = market_data.iloc[test_start:test_end]
            result = await self._standard_backtest()
                strategy_info, test_data, optimized_params
            )
            results.append(result)
            
        # Aggregate results
        avg_metrics = {}
        for metric in results[0].metrics.keys():
            avg_metrics[metric] = np.mean([r.metrics[metric] for r in results])
            
        return BacktestResult()
            strategy_name=strategy_info.name,
            parameters=parameters,
            market_scenario='mixed',
            backtest_type='walk_forward',
            metrics=avg_metrics,
            trades=[],
            equity_curve=[]
        )
        
    async def _monte_carlo_backtest(self, strategy_info: StrategyInfo,
                                  market_data: pd.DataFrame,
                                  parameters: Dict[str, Any],
                                  n_simulations: int = 100) -> BacktestResult:
        """Monte Carlo simulation"""
        
        results = []
        
        for _ in range(n_simulations):
            # Randomly resample returns
            returns = market_data.pct_change().dropna()
            resampled_returns = returns.sample(len(returns), replace=True)
            
            # Reconstruct price series
            resampled_prices = (1 + resampled_returns).cumprod() * 100
            resampled_data = market_data.copy()
            
            for col in market_data.columns:
                if '_close' in col:
                    symbol = col.replace('_close', '')
                    base_prices = resampled_prices.mean(axis=1)
                    resampled_data[f'{symbol}_close'] = base_prices
                    resampled_data[f'{symbol}_open'] = base_prices * (1 + np.self.get_price_in_range(-0.002, 0.002)
                    resampled_data[f'{symbol}_high'] = base_prices * (1 + np.abs(self.get_price_distribution(0, 0.005))
                    resampled_data[f'{symbol}_low'] = base_prices * (1 - np.abs(self.get_price_distribution(0, 0.005))
                    
            # Run backtest on resampled data
            result = await self._standard_backtest(strategy_info, resampled_data, parameters)
            results.append(result)
            
        # Calculate statistics
        metrics_stats = {}
        for metric in results[0].metrics.keys():
            values = [r.metrics[metric] for r in results]
            metrics_stats[f'{metric}_mean'] = np.mean(values)
            metrics_stats[f'{metric}_std'] = np.std(values)
            metrics_stats[f'{metric}_5percentile'] = np.percentile(values, 5)
            metrics_stats[f'{metric}_95percentile'] = np.percentile(values, 95)
            
        return BacktestResult()
            strategy_name=strategy_info.name,
            parameters=parameters,
            market_scenario='mixed',
            backtest_type='monte_carlo',
            metrics=metrics_stats,
            trades=[],
            equity_curve=[]
        )
        
    async def _bootstrap_backtest(self, strategy_info: StrategyInfo,
                                market_data: pd.DataFrame,
                                parameters: Dict[str, Any],
                                n_bootstrap: int = 100) -> BacktestResult:
        """Bootstrap resampling backtest"""
        
        # Run standard backtest first
        base_result = await self._standard_backtest(strategy_info, market_data, parameters)
        
        # Bootstrap the trades
        if not base_result.trades:
            return base_result
            
        bootstrap_results = []
        
        for _ in range(n_bootstrap):
            # Resample trades with replacement
            resampled_trades = np.random.choice()
                base_result.trades, 
                size=len(base_result.trades), 
                replace=True
            )
            
            # Calculate metrics from resampled trades
            total_pnl = sum(t.get('pnl', 0) for t in resampled_trades)
            win_rate = len([t for t in resampled_trades if t.get('pnl', 0) > 0]) / len(resampled_trades)
            
            bootstrap_results.append({)
                'total_pnl': total_pnl,
                'win_rate': win_rate
            })
            
        # Add confidence intervals to metrics
        base_result.metrics['pnl_confidence_lower'] = np.percentile()
            [r['total_pnl'] for r in bootstrap_results], 5
        )
        base_result.metrics['pnl_confidence_upper'] = np.percentile()
            [r['total_pnl'] for r in bootstrap_results], 95
        )
        base_result.metrics['win_rate_confidence_lower'] = np.percentile()
            [r['win_rate'] for r in bootstrap_results], 5
        )
        base_result.metrics['win_rate_confidence_upper'] = np.percentile()
            [r['win_rate'] for r in bootstrap_results], 95
        )
        
        return base_result
        
    def _generate_signals(self, data: pd.DataFrame, parameters: Dict[str, Any]) -> Dict[str, float]:
        """Generate trading signals (simplified)"""
        signals = {}
        
        # Simple momentum strategy as example
        lookback = parameters.get('lookback_period', 20)
        threshold = parameters.get('threshold', 0.02)
        
        for col in data.columns:
            if '_close' in col:
                symbol = col.replace('_close', '')
                prices = data[col]
                
                if len(prices) >= lookback:
                    returns = prices.pct_change(lookback).iloc[-1]
                    
                    if returns > threshold:
                        signals[symbol] = 1  # Buy
                    elif returns < -threshold:
                        signals[symbol] = -1  # Sell
                    else:
                        signals[symbol] = 0  # Hold
                        
        return signals
        
    async def _optimize_parameters(self, strategy_info: StrategyInfo,
                                 data: pd.DataFrame,
                                 base_parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Simple parameter optimization"""
        
        best_params = base_parameters.copy()
        best_sharpe = -np.inf
        
        # Grid search over parameter ranges
        for param_name, base_value in base_parameters.items():
            if isinstance(base_value, (int, float):)
                # Try different values
                for multiplier in [0.5, 0.75, 1.0, 1.25, 1.5]:
                    test_params = base_parameters.copy()
                    test_params[param_name] = base_value * multiplier
                    
                    # Quick backtest
                    result = await self._standard_backtest(strategy_info, data, test_params)
                    
                    if result.metrics['sharpe_ratio'] > best_sharpe:
                        best_sharpe = result.metrics['sharpe_ratio']
                        best_params = test_params.copy()
                        
        return best_params

class ParameterOptimizer:
    """Optimizes strategy parameters using ML"""
    
    def __init__(self):
        self.optimization_history: Dict[str, List[Dict]] = {}
        
    async def optimize_strategy(self, strategy_info: StrategyInfo,
                              backtest_results: List[BacktestResult]) -> Dict[str, Any]:
        """Optimize parameters based on backtest results"""
        
        if not backtest_results:
            return strategy_info.parameters
            
        # Use Bayesian optimization approach
        try:
            import optuna
            
            def objective(trial):
                # Create parameter suggestions
                params = {}
                for param_name, base_value in strategy_info.parameters.items():
                    if isinstance(base_value, int):
                        params[param_name] = trial.suggest_int()
                            param_name,
                            max(1, int(base_value * 0.5),
                            int(base_value * 2)
                        )
                    elif isinstance(base_value, float):
                        params[param_name] = trial.suggest_float()
                            param_name,
                            base_value * 0.5,
                            base_value * 2
                        )
                    else:
                        params[param_name] = base_value
                        
                # Find backtest with similar parameters
                best_score = -np.inf
                for result in backtest_results:
                    param_distance = sum()
                        abs(params.get(k, v) - result.parameters.get(k, v)
                        for k, v in params.items()
                        if isinstance(v, (int, float))
                    )
                    
                    if param_distance < 0.1:  # Close match
                        score = (result.metrics.get('sharpe_ratio', 0) * 0.4 +)
                               result.metrics.get('total_return', 0) * 0.3 +
                               (1 - abs(result.metrics.get('max_drawdown', 0)) * 0.3)
                        best_score = max(best_score, score)
                        
                return best_score
                
            # Create study
            study = optuna.create_study(direction='maximize')
            study.optimize(objective, n_trials=50, show_progress_bar=False)
            
            return study.best_params
            
        except ImportError:
            # Fallback to simple optimization
            best_params = strategy_info.parameters.copy()
            best_score = -np.inf
            
            for result in backtest_results:
                score = (result.metrics.get('sharpe_ratio', 0) * 0.4 +)
                        result.metrics.get('total_return', 0) * 0.3 +
                        (1 - abs(result.metrics.get('max_drawdown', 0)) * 0.3)
                        
                if score > best_score:
                    best_score = score
                    best_params = result.parameters.copy()
                    
            return best_params

class ConfigurationUpdater:
    """Updates configuration files with optimized parameters"""
    
    def __init__(self, base_path: str = "/home/harry/alpaca-mcp"):
        self.base_path = Path(base_path)
        self.config_manager = ConfigManager()
        
    def update_strategy_config(self, strategy_info: StrategyInfo,
                             optimized_params: Dict[str, Any],
                             performance_improvement: float):
        """Update configuration files with optimized parameters"""
        
        # Only update if improvement is significant
        if performance_improvement < 0.05:  # Less than 5% improvement
            logger.info(f"Skipping update for {strategy_info.name} - improvement too small")
            return
            
        try:
            # Find config file for strategy
            config_file = self._find_config_file(strategy_info)
            
            if config_file:
                # Load existing config
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    
                # Update with optimized parameters
                if 'parameters' not in config:
                    config['parameters'] = {}
                    
                for param, value in optimized_params.items():
                    old_value = config['parameters'].get(param)
                    config['parameters'][param] = value
                    
                    logger.info(f"Updated {strategy_info.name}.{param}: {old_value} -> {value}")
                    
                # Save updated config
                backup_file = config_file.with_suffix('.backup')
                config_file.rename(backup_file)
                
                with open(config_file, 'w') as f:
                    json.dump(config, f, indent=2)
                    
                logger.info(f"Updated config for {strategy_info.name} ")
                          f"(improvement: {performance_improvement:.1%})")
                          
            else:
                # Create new config file
                config = {}
                    'strategy': strategy_info.name,
                    'parameters': optimized_params,
                    'last_updated': datetime.now().isoformat(),
                    'performance_improvement': performance_improvement
                }
                
                config_file = self.base_path / 'configs' / f'{strategy_info.name}.json'
                config_file.parent.mkdir(exist_ok=True)
                
                with open(config_file, 'w') as f:
                    json.dump(config, f, indent=2)
                    
                logger.info(f"Created new config for {strategy_info.name}")
                
        except Exception as e:
            logger.error(f"Error updating config for {strategy_info.name}: {e}")
            
    def _find_config_file(self, strategy_info: StrategyInfo) -> Optional[Path]:
        """Find configuration file for a strategy"""
        
        # Look in common config locations
        search_paths = []
            self.base_path / 'configs' / f'{strategy_info.name}.json',
            self.base_path / 'config' / f'{strategy_info.name}.json',
            Path(strategy_info.file_path).parent / 'config.json',
            Path(strategy_info.file_path).with_suffix('.json')
        ]
        
        for path in search_paths:
            if path.exists():
                return path
                
        return None

class PerformanceTracker:
    """Tracks performance improvements over time"""
    
    def __init__(self, db_path: str = "continuous_training.db"):
        self.db_path = db_path
        self._init_database()
        
    def _init_database(self):
        """Initialize SQLite database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(""")
            CREATE TABLE IF NOT EXISTS backtest_results ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                strategy_name TEXT,
                parameters TEXT,
                market_scenario TEXT,
                backtest_type TEXT,
                sharpe_ratio REAL,
                total_return REAL,
                max_drawdown REAL,
                win_rate REAL,
                total_trades INTEGER
            )
        """)
        
        cursor.execute(""")
            CREATE TABLE IF NOT EXISTS optimization_history ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                strategy_name TEXT,
                old_parameters TEXT,
                new_parameters TEXT,
                performance_improvement REAL
            )
        """)
        
        conn.commit()
        conn.close()
        
    def record_backtest(self, result: BacktestResult):
        """Record backtest result"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(""")
            INSERT INTO backtest_results 
            (strategy_name, parameters, market_scenario, backtest_type,
             sharpe_ratio, total_return, max_drawdown, win_rate, total_trades)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, ()
            result.strategy_name,
            json.dumps(result.parameters),
            result.market_scenario,
            result.backtest_type,
            result.metrics.get('sharpe_ratio', 0),
            result.metrics.get('total_return', 0),
            result.metrics.get('max_drawdown', 0),
            result.metrics.get('win_rate', 0),
            result.metrics.get('total_trades', 0)
        )
        
        conn.commit()
        conn.close()
        
    def record_optimization(self, strategy_name: str, old_params: Dict, 
                          new_params: Dict, improvement: float):
        """Record parameter optimization"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(""")
            INSERT INTO optimization_history
            (strategy_name, old_parameters, new_parameters, performance_improvement)
            VALUES (?, ?, ?, ?)
        """, ()
            strategy_name,
            json.dumps(old_params),
            json.dumps(new_params),
            improvement
        )
        
        conn.commit()
        conn.close()
        
    def get_strategy_performance_history(self, strategy_name: str, 
                                       days: int = 30) -> pd.DataFrame:
        """Get performance history for a strategy"""
        conn = sqlite3.connect(self.db_path)
        
        query = """
            SELECT timestamp, sharpe_ratio, total_return, max_drawdown, win_rate
            FROM backtest_results
            WHERE strategy_name = ?
            AND timestamp > datetime('now', '-{} days')
            ORDER BY timestamp
        """.format(days)
        
        df = pd.read_sql_query(query, conn, params=(strategy_name,)
        conn.close()
        
        return df

class ReportGenerator:
    """Generates comprehensive reports"""
    
    def __init__(self, output_dir: str = "backtest_reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
    def generate_report(self, strategies: Dict[str, StrategyInfo],
                       all_results: List[BacktestResult],
                       optimizations: Dict[str, Dict]):
        """Generate comprehensive HTML report"""
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_path = self.output_dir / f"continuous_training_report_{timestamp}.html"
        
        html = f"""
        <html>
        <head>
            <title>Continuous Training Report - {timestamp}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1, h2, h3 {{ color: #333; }}
                table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .improved {{ background-color: #d4edda; }}
                .declined {{ background-color: #f8d7da; }}
                .metric {{ font-family: monospace; }}
            </style>
        </head>
        <body>
            <h1>Continuous Training Report</h1>
            <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            
            <h2>Summary</h2>
            <ul>
                <li>Strategies Analyzed: {len(strategies)}</li>
                <li>Total Backtests Run: {len(all_results)}</li>
                <li>Strategies Optimized: {len(optimizations)}</li>
            </ul>
            
            <h2>Strategy Performance</h2>
            <table>
                <tr>
                    <th>Strategy</th>
                    <th>Best Sharpe</th>
                    <th>Best Return</th>
                    <th>Best Win Rate</th>
                    <th>Optimization Status</th>
                </tr>
        """
        
        # Aggregate results by strategy
        strategy_results = {}
        for result in all_results:
            if result.strategy_name not in strategy_results:
                strategy_results[result.strategy_name] = []
            strategy_results[result.strategy_name].append(result)
            
        # Add strategy rows
        for strategy_name, results in strategy_results.items():
            best_sharpe = max(r.metrics.get('sharpe_ratio', 0) for r in results)
            best_return = max(r.metrics.get('total_return', 0) for r in results)
            best_win_rate = max(r.metrics.get('win_rate', 0) for r in results)
            
            optimization = optimizations.get(strategy_name, {})
            status = "Optimized" if optimization else "Not Optimized"
            row_class = "improved" if optimization.get('improvement', 0) > 0 else ""
            
            html += f"""
                <tr class="{row_class}">
                    <td>{strategy_name}</td>
                    <td class="metric">{best_sharpe:.3f}</td>
                    <td class="metric">{best_return:.2%}</td>
                    <td class="metric">{best_win_rate:.1%}</td>
                    <td>{status}</td>
                </tr>
            """
            
        html += """
            </table>
            
            <h2>Market Scenario Analysis</h2>
            <table>
                <tr>
                    <th>Scenario</th>
                    <th>Avg Sharpe</th>
                    <th>Avg Return</th>
                    <th>Success Rate</th>
                </tr>
        """
        
        # Analyze by market scenario
        scenarios = ['bull_market', 'bear_market', 'high_volatility', 
                    'low_volatility', 'sideways', 'crash']
                    
        for scenario in scenarios:
            scenario_results = [r for r in all_results if r.market_scenario == scenario]
            
            if scenario_results:
                avg_sharpe = np.mean([r.metrics.get('sharpe_ratio', 0) for r in scenario_results])
                avg_return = np.mean([r.metrics.get('total_return', 0) for r in scenario_results])
                success_rate = len([r for r in scenario_results if r.metrics.get('total_return', 0) > 0]) / len(scenario_results)
                
                html += f"""
                    <tr>
                        <td>{scenario.replace('_', ' ').title()}</td>
                        <td class="metric">{avg_sharpe:.3f}</td>
                        <td class="metric">{avg_return:.2%}</td>
                        <td class="metric">{success_rate:.1%}</td>
                    </tr>
                """
                
        html += """
            </table>
            
            <h2>Optimization Details</h2>
        """
        
        for strategy_name, opt_details in optimizations.items():
            if opt_details.get('improvement', 0) > 0:
                html += f"""
                    <h3>{strategy_name}</h3>
                    <p>Performance Improvement: {opt_details['improvement']:.1%}</p>
                    <h4>Parameter Changes:</h4>
                    <ul>
                """
                
                for param, new_value in opt_details.get('new_parameters', {}).items():
                    old_value = opt_details.get('old_parameters', {}).get(param, 'N/A')
                    html += f"<li>{param}: {old_value} → {new_value}</li>"
                    
                html += "</ul>"
                
        html += """
            <h2>Recommendations</h2>
            <ul>
                <li>Focus on strategies with Sharpe ratio > 1.0</li>
                <li>Consider disabling strategies that perform poorly in crash scenarios</li>
                <li>Increase position sizes for strategies with consistent win rates > 60%</li>
                <li>Run more backtests on high-performing strategies to validate results</li>
            </ul>
            
        </body>
        </html>
        """
        
        with open(report_path, 'w') as f:
            f.write(html)
            
        logger.info(f"Report generated: {report_path}")
        
        # Also save JSON report for programmatic access
        json_report = {}
            'timestamp': timestamp,
            'summary': {}
                'strategies_analyzed': len(strategies),
                'total_backtests': len(all_results),
                'strategies_optimized': len(optimizations)
            },
            'strategy_performance': strategy_results,
            'optimizations': optimizations
        }
        
        json_path = self.output_dir / f"continuous_training_report_{timestamp}.json"
        with open(json_path, 'w') as f:
            json.dump(json_report, f, indent=2, default=str)

class ContinuousBacktestTrainingSystem:
    """Main system that orchestrates continuous backtesting and training"""
    
    def __init__(self):
        self.scanner = StrategyScanner()
        self.market_sim = MarketSimulator()
        self.backtest_engine = BacktestEngine()
        self.optimizer = ParameterOptimizer()
        self.config_updater = ConfigurationUpdater()
        self.performance_tracker = PerformanceTracker()
        self.report_generator = ReportGenerator()
        
        # Scenarios to test
        self.market_scenarios = []
            'bull_market', 'bear_market', 'high_volatility',
            'low_volatility', 'sideways', 'crash', 'recovery', 'mixed'
        ]
        
        # Backtest types
        self.backtest_types = ['standard', 'walk_forward', 'monte_carlo']
        
    async def run_continuous_training(self, max_iterations: int = None):
        """Run continuous training loop"""
        
        iteration = 0
        while max_iterations is None or iteration < max_iterations:
            iteration += 1
            logger.info(f"\n{'='*60}")
            logger.info(f"Starting training iteration {iteration}")
            logger.info(f"{'='*60}")
            
            try:
                # 1. Scan for strategies
                strategies = self.scanner.scan_for_strategies()
                logger.info(f"Found {len(strategies)} strategies to analyze")
                
                # 2. Run backtests
                all_results = await self._run_all_backtests(strategies)
                logger.info(f"Completed {len(all_results)} backtests")
                
                # 3. Optimize parameters
                optimizations = await self._optimize_all_strategies(strategies, all_results)
                logger.info(f"Optimized {len(optimizations)} strategies")
                
                # 4. Update configurations
                for strategy_name, opt_details in optimizations.items():
                    if strategy_name in strategies:
                        self.config_updater.update_strategy_config()
                            strategies[strategy_name],
                            opt_details['new_parameters'],
                            opt_details['improvement']
                        )
                        
                # 5. Generate report
                self.report_generator.generate_report(strategies, all_results, optimizations)
                
                # 6. Sleep before next iteration
                if max_iterations is None or iteration < max_iterations:
                    sleep_time = 3600  # 1 hour
                    logger.info(f"Sleeping for {sleep_time/60:.0f} minutes before next iteration...")
                    await asyncio.sleep(sleep_time)
                    
            except Exception as e:
                logger.error(f"Error in training iteration {iteration}: {e}")
                await asyncio.sleep(300)  # Sleep 5 minutes on error
                
    async def _run_all_backtests(self, strategies: Dict[str, StrategyInfo]) -> List[BacktestResult]:
        """Run backtests for all strategies"""
        
        all_results = []
        
        # Use process pool for CPU-intensive backtests
        with ProcessPoolExecutor(max_workers=mp.cpu_count() as executor:
            
            # Generate market data for all scenarios
            market_data_cache = {}
            for scenario in self.market_scenarios:
                market_data_cache[scenario] = self.market_sim.generate_market_data(scenario)
                
            # Submit backtest tasks
            futures = []
            
            for strategy_name, strategy_info in strategies.items():
                for scenario in self.market_scenarios[:3]:  # Limit scenarios for speed
                    for backtest_type in self.backtest_types[:1]:  # Limit types for speed
                        
                        # Vary parameters slightly
                        param_variations = self._generate_parameter_variations()
                            strategy_info.parameters
                        )
                        
                        for params in param_variations[:5]:  # Limit variations
                            future = asyncio.create_task()
                                self.backtest_engine.run_backtest()
                                    strategy_info,
                                    market_data_cache[scenario],
                                    params,
                                    backtest_type
                                )
                            )
                            futures.append(future)
                            
            # Collect results
            for future in asyncio.as_completed(futures):
                try:
                    result = await future
                    all_results.append(result)
                    self.performance_tracker.record_backtest(result)
                except Exception as e:
                    logger.error(f"Backtest failed: {e}")
                    
        return all_results
        
    def _generate_parameter_variations(self, base_params: Dict[str, Any], 
                                     n_variations: int = 10) -> List[Dict[str, Any]]:
        """Generate parameter variations for testing"""
        
        variations = [base_params.copy()]
        
        for _ in range(n_variations - 1):
            variation = base_params.copy()
            
            # Randomly modify parameters
            for param, value in base_params.items():
                if isinstance(value, (int, float):)
                    # Add some noise
                    multiplier = np.self.get_price_in_range(0.8, 1.2)
                    if isinstance(value, int):
                        variation[param] = int(value * multiplier)
                    else:
                        variation[param] = value * multiplier
                        
            variations.append(variation)
            
        return variations
        
    async def _optimize_all_strategies(self, strategies: Dict[str, StrategyInfo],
                                     all_results: List[BacktestResult]) -> Dict[str, Dict]:
        """Optimize all strategies based on results"""
        
        optimizations = {}
        
        for strategy_name, strategy_info in strategies.items():
            # Get results for this strategy
            strategy_results = []
                r for r in all_results 
                if r.strategy_name == strategy_name
            ]
            
            if not strategy_results:
                continue
                
            # Find current best performance
            current_best = max()
                r.metrics.get('sharpe_ratio', 0) 
                for r in strategy_results 
                if r.parameters == strategy_info.parameters
            )
            
            # Optimize
            optimized_params = await self.optimizer.optimize_strategy()
                strategy_info, strategy_results
            )
            
            # Find new best performance
            new_best = max()
                r.metrics.get('sharpe_ratio', 0) 
                for r in strategy_results 
                if all()
                    abs(r.parameters.get(k, 0) - optimized_params.get(k, 0) < 0.01)
                    for k in optimized_params.keys()
                    if isinstance(optimized_params.get(k), (int, float))
                )
            )
            
            # Calculate improvement
            improvement = (new_best - current_best) / abs(current_best) if current_best != 0 else 0
            
            if improvement > 0.05:  # More than 5% improvement
                optimizations[strategy_name] = {}
                    'old_parameters': strategy_info.parameters,
                    'new_parameters': optimized_params,
                    'improvement': improvement
                }
                
                self.performance_tracker.record_optimization()
                    strategy_name,
                    strategy_info.parameters,
                    optimized_params,
                    improvement
                )
                
        return optimizations

async def main():
    """Main entry point"""
    
    # Create system
    system = ContinuousBacktestTrainingSystem()
    
    # Run one iteration for demo
    await system.run_continuous_training(max_iterations=1)
    
    logger.info("\nContinuous training system completed first iteration!")
    logger.info("Check 'backtest_reports' directory for detailed reports")
    logger.info("System will continue running if max_iterations is not set")

if __name__ == "__main__":
    asyncio.run(main()