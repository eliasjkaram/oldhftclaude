#!/usr/bin/env python3
"""
Concrete Market Regime Prediction Models
========================================

Complete implementations of market regime prediction models.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Tuple, Any
import logging
from dataclasses import dataclass
from abc import ABC, abstractmethod
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

# Import base classes
try:
    from core.market_regime_prediction import BaseRegimePredictor, MarketRegime, RegimePrediction
except ImportError:
    # Fallback definitions
    from enum import Enum
    
    class MarketRegime(Enum):
        BULL_MARKET = "bull_market"
        BEAR_MARKET = "bear_market"
        SIDEWAYS = "sideways"
        HIGH_VOLATILITY = "high_volatility"
        LOW_VOLATILITY = "low_volatility"
        CRISIS = "crisis"
        RECOVERY = "recovery"
    
    @dataclass
    class RegimePrediction:
        regime: MarketRegime
        confidence: float
        probability_distribution: Dict[MarketRegime, float]
        timestamp: datetime
        features_used: List[str]
        model_name: str
    
    class BaseRegimePredictor(ABC):
        @abstractmethod
        def train(self, data: pd.DataFrame) -> Dict[str, Any]:
            pass
        
        @abstractmethod
        def predict(self, data: pd.DataFrame) -> RegimePrediction:
            pass

# Optional imports for advanced models
try:
    import tensorflow as tf
    from tensorflow import keras
    TENSORFLOW_AVAILABLE = True
except ImportError:
    TENSORFLOW_AVAILABLE = False

try:
    import torch
    import torch.nn as nn
    PYTORCH_AVAILABLE = True
except ImportError:
    PYTORCH_AVAILABLE = False

class VolatilityRegimePredictor(BaseRegimePredictor):
    """Volatility-based regime prediction model"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Model parameters
        self.lookback_window = config.get('lookback_window', 252)  # 1 year
        self.volatility_window = config.get('volatility_window', 20)  # 20 days
        self.regime_threshold_high = config.get('high_vol_threshold', 0.02)  # 2% daily vol
        self.regime_threshold_low = config.get('low_vol_threshold', 0.01)   # 1% daily vol
        
        # Model state
        self.model = RandomForestClassifier()
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        self.feature_names = []
    
    def train(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Train the volatility regime model"""
        self.logger.info("Training volatility regime prediction model")
        
        try:
            # Prepare features
            features, labels = self._prepare_training_data(data)
            
            if len(features) == 0:
                raise ValueError("No training data available")
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split()
                features, labels, test_size=0.2, random_state=42, stratify=labels
            )
            
            # Scale features
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Train model
            self.model.fit(X_train_scaled, y_train)
            
            # Evaluate model
            train_score = self.model.score(X_train_scaled, y_train)
            test_score = self.model.score(X_test_scaled, y_test)
            
            # Predictions for detailed evaluation
            y_pred = self.model.predict(X_test_scaled)
            
            self.is_trained = True
            
            results = {}
                'model_type': 'VolatilityRegimePredictor',
                'train_accuracy': train_score,
                'test_accuracy': test_score,
                'n_samples': len(features),
                'n_features': len(self.feature_names),
                'feature_names': self.feature_names,
                'classification_report': classification_report(y_test, y_pred, output_dict=True),
                'training_completed': datetime.now()
            }
            
            self.logger.info(f"Model trained successfully. Test accuracy: {test_score:.3f}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Training failed: {e}")
            raise
    
    def predict(self, data: pd.DataFrame) -> RegimePrediction:
        """Predict market regime"""
        if not self.is_trained:
            raise RuntimeError("Model must be trained before prediction")
        
        try:
            # Prepare features for prediction
            features = self._extract_features(data)
            
            if len(features) == 0:
                raise ValueError("No features available for prediction")
            
            # Scale features
            features_scaled = self.scaler.transform([features])
            
            # Make prediction
            regime_probs = self.model.predict_proba(features_scaled)[0]
            regime_classes = self.model.classes_
            
            # Get most likely regime
            best_regime_idx = np.argmax(regime_probs)
            predicted_regime = MarketRegime(regime_classes[best_regime_idx])
            confidence = regime_probs[best_regime_idx]
            
            # Create probability distribution
            prob_dist = {}
            for i, regime_class in enumerate(regime_classes):
                prob_dist[MarketRegime(regime_class)] = regime_probs[i]
            
            return RegimePrediction()
                regime=predicted_regime,
                confidence=confidence,
                probability_distribution=prob_dist,
                timestamp=datetime.now(),
                features_used=self.feature_names,
                model_name='VolatilityRegimePredictor'
            )
            
        except Exception as e:
            self.logger.error(f"Prediction failed: {e}")
            raise
    
    def _prepare_training_data(self, data: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare training data with features and labels"""
        
        # Calculate features for all time points
        features_list = []
        labels_list = []
        
        for i in range(self.lookback_window, len(data):
            # Get historical window
            window_data = data.iloc[i-self.lookback_window:i+1]
            
            # Extract features
            features = self._extract_features(window_data)
            
            if len(features) > 0:
                # Determine regime label based on current volatility
                current_vol = self._calculate_volatility(window_data)
                regime_label = self._classify_regime(current_vol, window_data)
                
                features_list.append(features)
                labels_list.append(regime_label.value)
        
        if not features_list:
            return np.array([]), np.array([])
        
        return np.array(features_list), np.array(labels_list)
    
    def _extract_features(self, data: pd.DataFrame) -> List[float]:
        """Extract features from market data"""
        
        if len(data) < self.volatility_window:
            return []
        
        # Ensure we have required columns
        required_columns = ['close', 'high', 'low', 'volume']
        if not all(col in data.columns for col in required_columns):
            # Try different column name formats
            column_mapping = {}
                'close': ['close', 'Close', 'CLOSE'],
                'high': ['high', 'High', 'HIGH'],
                'low': ['low', 'Low', 'LOW'],
                'volume': ['volume', 'Volume', 'VOLUME']
            }
            
            for required_col, possible_names in column_mapping.items():
                for possible_name in possible_names:
                    if possible_name in data.columns:
                        data = data.rename(columns={possible_name: required_col})
                        break
        
        try:
            features = []
            
            # Price-based features
            returns = data['close'].pct_change().dropna()
            
            # Volatility features
            volatility_short = returns.rolling(5).std()
            volatility_medium = returns.rolling(20).std()
            volatility_long = returns.rolling(60).std()
            
            features.extend([)
                volatility_short.iloc[-1] if not pd.isna(volatility_short.iloc[-1]) else 0,
                volatility_medium.iloc[-1] if not pd.isna(volatility_medium.iloc[-1]) else 0,
                volatility_long.iloc[-1] if not pd.isna(volatility_long.iloc[-1]) else 0,
            ])
            
            # Trend features
            sma_short = data['close'].rolling(10).mean()
            sma_long = data['close'].rolling(50).mean()
            trend_strength = (sma_short.iloc[-1] - sma_long.iloc[-1]) / sma_long.iloc[-1] if not pd.isna(sma_long.iloc[-1]) else 0
            
            features.append(trend_strength)
            
            # Momentum features
            momentum_5 = (data['close'].iloc[-1] - data['close'].iloc[-6]) / data['close'].iloc[-6] if len(data) > 5 else 0
            momentum_20 = (data['close'].iloc[-1] - data['close'].iloc[-21]) / data['close'].iloc[-21] if len(data) > 20 else 0
            
            features.extend([momentum_5, momentum_20])
            
            # Volume features
            volume_ratio = data['volume'].rolling(5).mean().iloc[-1] / data['volume'].rolling(20).mean().iloc[-1] if not pd.isna(data['volume'].rolling(20).mean().iloc[-1]) else 1
            features.append(volume_ratio)
            
            # Range features
            true_range = np.maximum()
                data['high'] - data['low'],
                np.maximum()
                    abs(data['high'] - data['close'].shift(1),
                    abs(data['low'] - data['close'].shift(1)
                )
            )
            atr = true_range.rolling(14).mean().iloc[-1] if not pd.isna(true_range.rolling(14).mean().iloc[-1]) else 0
            features.append(atr / data['close'].iloc[-1])
            
            # Store feature names
            if not self.feature_names:
                self.feature_names = []
                    'volatility_5d', 'volatility_20d', 'volatility_60d',
                    'trend_strength', 'momentum_5d', 'momentum_20d',
                    'volume_ratio', 'atr_ratio'
                ]
            
            return features
            
        except Exception as e:
            self.logger.warning(f"Feature extraction failed: {e}")
            return []
    
    def _calculate_volatility(self, data: pd.DataFrame) -> float:
        """Calculate current volatility"""
        if len(data) < 2:
            return 0.0
        
        returns = data['close'].pct_change().dropna()
        if len(returns) == 0:
            return 0.0
        
        return returns.std() * np.sqrt(252)  # Annualized volatility
    
    def _classify_regime(self, volatility: float, data: pd.DataFrame) -> MarketRegime:
        """Classify market regime based on volatility and other factors"""
        
        # Calculate additional metrics for classification
        returns = data['close'].pct_change().dropna()
        
        if len(returns) < 5:
            return MarketRegime.SIDEWAYS
        
        # Check for crisis conditions (high volatility + negative trend)
        if volatility > 0.4:  # 40% annualized volatility
            recent_return = (data['close'].iloc[-1] - data['close'].iloc[-21]) / data['close'].iloc[-21] if len(data) > 20 else 0
            if recent_return < -0.1:  # 10% decline
                return MarketRegime.CRISIS
        
        # Volatility-based classification
        if volatility > self.regime_threshold_high:
            return MarketRegime.HIGH_VOLATILITY
        elif volatility < self.regime_threshold_low:
            return MarketRegime.LOW_VOLATILITY
        
        # Trend-based classification
        if len(data) > 50:
            long_term_return = (data['close'].iloc[-1] - data['close'].iloc[-51]) / data['close'].iloc[-51]
            
            if long_term_return > 0.15:  # 15% gain
                return MarketRegime.BULL_MARKET
            elif long_term_return < -0.15:  # 15% loss
                return MarketRegime.BEAR_MARKET
        
        return MarketRegime.SIDEWAYS

class TrendRegimePredictor(BaseRegimePredictor):
    """Trend-based regime prediction model"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Model parameters
        self.lookback_window = config.get('lookback_window', 252)
        self.trend_windows = config.get('trend_windows', [10, 20, 50, 200])
        
        # Model
        self.model = GradientBoostingClassifier()
            n_estimators=100,
            learning_rate=0.1,
            max_depth=6,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        self.feature_names = []
    
    def train(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Train the trend regime model"""
        self.logger.info("Training trend regime prediction model")
        
        try:
            features, labels = self._prepare_training_data(data)
            
            if len(features) == 0:
                raise ValueError("No training data available")
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split()
                features, labels, test_size=0.2, random_state=42
            )
            
            # Scale features
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Train model
            self.model.fit(X_train_scaled, y_train)
            
            # Evaluate
            train_score = self.model.score(X_train_scaled, y_train)
            test_score = self.model.score(X_test_scaled, y_test)
            
            self.is_trained = True
            
            results = {}
                'model_type': 'TrendRegimePredictor',
                'train_accuracy': train_score,
                'test_accuracy': test_score,
                'n_samples': len(features),
                'n_features': len(self.feature_names),
                'feature_importance': dict(zip(self.feature_names, self.model.feature_importances_),
                'training_completed': datetime.now()
            }
            
            self.logger.info(f"Trend model trained successfully. Test accuracy: {test_score:.3f}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Training failed: {e}")
            raise
    
    def predict(self, data: pd.DataFrame) -> RegimePrediction:
        """Predict market regime based on trends"""
        if not self.is_trained:
            raise RuntimeError("Model must be trained before prediction")
        
        try:
            features = self._extract_features(data)
            
            if len(features) == 0:
                raise ValueError("No features available for prediction")
            
            features_scaled = self.scaler.transform([features])
            
            # Make prediction
            regime_probs = self.model.predict_proba(features_scaled)[0]
            regime_classes = self.model.classes_
            
            best_regime_idx = np.argmax(regime_probs)
            predicted_regime = MarketRegime(regime_classes[best_regime_idx])
            confidence = regime_probs[best_regime_idx]
            
            # Create probability distribution
            prob_dist = {}
            for i, regime_class in enumerate(regime_classes):
                prob_dist[MarketRegime(regime_class)] = regime_probs[i]
            
            return RegimePrediction()
                regime=predicted_regime,
                confidence=confidence,
                probability_distribution=prob_dist,
                timestamp=datetime.now(),
                features_used=self.feature_names,
                model_name='TrendRegimePredictor'
            )
            
        except Exception as e:
            self.logger.error(f"Prediction failed: {e}")
            raise
    
    def _prepare_training_data(self, data: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare training data for trend model"""
        
        features_list = []
        labels_list = []
        
        for i in range(max(self.trend_windows) + 50, len(data):
            window_data = data.iloc[i-self.lookback_window:i+1]
            
            features = self._extract_features(window_data)
            
            if len(features) > 0:
                # Classify regime based on future performance
                future_window = 20  # Look ahead 20 days
                if i + future_window < len(data):
                    future_return = (data['close'].iloc[i + future_window] - data['close'].iloc[i]) / data['close'].iloc[i]
                    regime_label = self._classify_trend_regime(future_return, window_data)
                    
                    features_list.append(features)
                    labels_list.append(regime_label.value)
        
        if not features_list:
            return np.array([]), np.array([])
        
        return np.array(features_list), np.array(labels_list)
    
    def _extract_features(self, data: pd.DataFrame) -> List[float]:
        """Extract trend-based features"""
        
        if len(data) < max(self.trend_windows):
            return []
        
        try:
            features = []
            
            # Moving average features
            for window in self.trend_windows:
                if len(data) >= window:
                    ma = data['close'].rolling(window).mean()
                    current_vs_ma = (data['close'].iloc[-1] - ma.iloc[-1]) / ma.iloc[-1]
                    features.append(current_vs_ma)
                else:
                    features.append(0)
            
            # Trend slope features
            for window in self.trend_windows:
                if len(data) >= window:
                    ma = data['close'].rolling(window).mean()
                    if len(ma) >= 2:
                        slope = (ma.iloc[-1] - ma.iloc[-2]) / ma.iloc[-2]
                        features.append(slope)
                    else:
                        features.append(0)
                else:
                    features.append(0)
            
            # Cross-over features
            if len(data) >= max(self.trend_windows):
                ma_short = data['close'].rolling(self.trend_windows[0]).mean()
                ma_long = data['close'].rolling(self.trend_windows[-1]).mean()
                
                cross_over = (ma_short.iloc[-1] - ma_long.iloc[-1]) / ma_long.iloc[-1]
                features.append(cross_over)
            else:
                features.append(0)
            
            # Price position features (where price is relative to recent high/low)
            high_50 = data['high'].rolling(50).max().iloc[-1] if len(data) >= 50 else data['high'].iloc[-1]
            low_50 = data['low'].rolling(50).min().iloc[-1] if len(data) >= 50 else data['low'].iloc[-1]
            
            if high_50 != low_50:
                price_position = (data['close'].iloc[-1] - low_50) / (high_50 - low_50)
            else:
                price_position = 0.5
            
            features.append(price_position)
            
            # Store feature names
            if not self.feature_names:
                self.feature_names = []
                for window in self.trend_windows:
                    self.feature_names.append(f'price_vs_ma_{window}')
                for window in self.trend_windows:
                    self.feature_names.append(f'ma_slope_{window}')
                self.feature_names.extend(['ma_crossover', 'price_position'])
            
            return features
            
        except Exception as e:
            self.logger.warning(f"Feature extraction failed: {e}")
            return []
    
    def _classify_trend_regime(self, future_return: float, data: pd.DataFrame) -> MarketRegime:
        """Classify trend regime based on future performance"""
        
        # Calculate current trend strength
        if len(data) >= 50:
            trend_50 = (data['close'].iloc[-1] - data['close'].iloc[-51]) / data['close'].iloc[-51]
        else:
            trend_50 = 0
        
        # Classify based on future return and current trend
        if future_return > 0.1:  # Strong positive future return
            return MarketRegime.BULL_MARKET
        elif future_return < -0.1:  # Strong negative future return
            return MarketRegime.BEAR_MARKET
        elif abs(future_return) < 0.02:  # Low future return
            return MarketRegime.SIDEWAYS
        elif trend_50 > 0.05:  # Positive trend
            return MarketRegime.BULL_MARKET
        elif trend_50 < -0.05:  # Negative trend
            return MarketRegime.BEAR_MARKET
        else:
            return MarketRegime.SIDEWAYS

class EnsembleRegimePredictor(BaseRegimePredictor):
    """Ensemble model combining multiple regime predictors"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize component models
        self.models = {}
            'volatility': VolatilityRegimePredictor(config),
            'trend': TrendRegimePredictor(config)
        }
        
        # Ensemble weights
        self.model_weights = config.get('model_weights', {)
            'volatility': 0.6,
            'trend': 0.4
        })
        
        self.is_trained = False
    
    def train(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Train all component models"""
        self.logger.info("Training ensemble regime prediction model")
        
        results = {'ensemble_results': {}}
        
        for model_name, model in self.models.items():
            try:
                self.logger.info(f"Training {model_name} model")
                model_results = model.train(data)
                results['ensemble_results'][model_name] = model_results
                
            except Exception as e:
                self.logger.error(f"Failed to train {model_name} model: {e}")
                results['ensemble_results'][model_name] = {'error': str(e)}
        
        # Check if at least one model trained successfully
        trained_models = [name for name, result in results['ensemble_results'].items()]
                         if 'error' not in result]
        
        if trained_models:
            self.is_trained = True
            results['trained_models'] = trained_models
            results['ensemble_status'] = 'success'
            self.logger.info(f"Ensemble training completed. {len(trained_models)} models trained.")
        else:
            results['ensemble_status'] = 'failed'
            self.logger.error("No models trained successfully")
        
        results['training_completed'] = datetime.now()
        return results
    
    def predict(self, data: pd.DataFrame) -> RegimePrediction:
        """Make ensemble prediction"""
        if not self.is_trained:
            raise RuntimeError("Ensemble must be trained before prediction")
        
        predictions = {}
        weights = {}
        
        # Get predictions from all trained models
        for model_name, model in self.models.items():
            try:
                if hasattr(model, 'is_trained') and model.is_trained:
                    prediction = model.predict(data)
                    predictions[model_name] = prediction
                    weights[model_name] = self.model_weights.get(model_name, 1.0)
                    
            except Exception as e:
                self.logger.warning(f"Model {model_name} prediction failed: {e}")
        
        if not predictions:
            raise RuntimeError("No models available for prediction")
        
        # Combine predictions using weighted voting
        regime_votes = {}
        total_weight = sum(weights.values()
        
        # Initialize vote counts for all regimes
        for regime in MarketRegime:
            regime_votes[regime] = 0.0
        
        # Aggregate weighted votes
        for model_name, prediction in predictions.items():
            weight = weights[model_name] / total_weight
            
            # Add weighted confidence for predicted regime
            regime_votes[prediction.regime] += weight * prediction.confidence
            
            # Add weighted probabilities from probability distribution
            for regime, prob in prediction.probability_distribution.items():
                regime_votes[regime] += weight * prob * 0.5  # Lower weight for secondary probabilities
        
        # Find the regime with highest weighted vote
        best_regime = max(regime_votes, key=regime_votes.get)
        ensemble_confidence = regime_votes[best_regime]
        
        # Normalize probabilities
        total_votes = sum(regime_votes.values()
        if total_votes > 0:
            normalized_probs = {regime: votes / total_votes for regime, votes in regime_votes.items()}
        else:
            normalized_probs = {regime: 1.0 / len(MarketRegime) for regime in MarketRegime}
        
        # Collect all features used
        all_features = []
        for prediction in predictions.values():
            all_features.extend(prediction.features_used)
        
        return RegimePrediction()
            regime=best_regime,
            confidence=min(ensemble_confidence, 1.0),  # Cap at 1.0
            probability_distribution=normalized_probs,
            timestamp=datetime.now(),
            features_used=list(set(all_features),  # Remove duplicates)
            model_name=f'Ensemble({len(predictions)} models)'
        )

# Factory function for creating regime predictors
def create_regime_predictor(predictor_type: str, config: Dict) -> BaseRegimePredictor:
    """Factory function to create regime predictors"""
    
    predictors = {}
        'volatility': VolatilityRegimePredictor,
        'trend': TrendRegimePredictor,
        'ensemble': EnsembleRegimePredictor
    }
    
    predictor_class = predictors.get(predictor_type.lower()
    if not predictor_class:
        raise ValueError(f"Unknown regime predictor: {predictor_type}")
    
    return predictor_class(config)

# Default regime predictor for the system
def get_default_regime_predictor(config: Dict) -> BaseRegimePredictor:
    """Get the default regime predictor for the system"""
    return EnsembleRegimePredictor(config)

if __name__ == "__main__":
    # Test the regime prediction models
    import yfinance as yf
    
    # Download test data
    print("Downloading test data...")
    data = yf.download('SPY', start='2020-01-01', end='2023-01-01')
    data.columns = data.columns.str.lower()
    
    if data.empty:
        print("Failed to download data, creating synthetic data...")
        # Create synthetic data for testing
        dates = pd.date_range(start='2020-01-01', end='2023-01-01', freq='D')
        np.random.seed(42)
        returns = np.random.normal(0.001, 0.02, len(dates)
        prices = 100 * np.exp(np.cumsum(returns)
        
        data = pd.DataFrame({)
            'open': prices * (1 + np.random.normal(0, 0.01, len(dates)),
            'high': prices * (1 + np.abs(np.random.normal(0.01, 0.01, len(dates)),
            'low': prices * (1 - np.abs(np.random.normal(0.01, 0.01, len(dates)),
            'close': prices,
            'volume': np.random.randint(1000000, 10000000, len(dates)
        }, index=dates)
    
    print(f"Data shape: {data.shape}")
    
    # Test configuration
    config = {}
        'lookback_window': 100,  # Shorter for testing
        'volatility_window': 20,
        'high_vol_threshold': 0.02,
        'low_vol_threshold': 0.01,
        'trend_windows': [10, 20, 50]
    }
    
    # Test ensemble predictor
    print("\nTesting Ensemble Regime Predictor:")
    ensemble = EnsembleRegimePredictor(config)
    
    try:
        # Train model
        print("Training ensemble model...")
        training_results = ensemble.train(data)
        print(f"Training completed: {training_results['ensemble_status']}")
        
        # Make prediction
        print("Making prediction...")
        recent_data = data.tail(200)  # Use recent data for prediction
        prediction = ensemble.predict(recent_data)
        
        print(f"\nPrediction Results:")
        print(f"Predicted Regime: {prediction.regime.value}")
        print(f"Confidence: {prediction.confidence:.3f}")
        print(f"Model: {prediction.model_name}")
        print(f"Features Used: {len(prediction.features_used)}")
        
        print(f"\nProbability Distribution:")
        for regime, prob in prediction.probability_distribution.items():
            print(f"  {regime.value}: {prob:.3f}")
            
    except Exception as e:
        print(f"Ensemble test failed: {e}")
        import traceback
        traceback.print_exc()
    
    # Test individual models
    print("\n" + "="*50)
    print("Testing Individual Models:")
    
    for model_name, model_class in [('Volatility', VolatilityRegimePredictor),]
                                   ('Trend', TrendRegimePredictor)]:
        print(f"\nTesting {model_name} Model:")
        
        try:
            model = model_class(config)
            train_results = model.train(data)
            print(f"  Training accuracy: {train_results['test_accuracy']:.3f}")
            
            prediction = model.predict(data.tail(200)
            print(f"  Predicted regime: {prediction.regime.value}")
            print(f"  Confidence: {prediction.confidence:.3f}")
            
        except Exception as e:
            print(f"  {model_name} model test failed: {e}")
    
    print("\nRegime prediction testing completed!")