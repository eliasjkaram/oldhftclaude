#!/usr/bin/env python3
"""
Test fetching a single symbol to diagnose data issues
"""

import asyncio
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import json
import pandas as pd

async def test_single_symbol():
    # Load config
    with open('alpaca_config.json', 'r') as f:
        config = json.load(f)
    
    # Initialize client
    client = TradingClient()
        config.get('paper_api_key'),
        config.get('paper_secret_key'),
        config.get('paper_base_url')
    )
    
    # Test with AAPL
    symbol = 'AAPL'
    
    print(f"\nTesting data fetch for {symbol}...")
    
    # Get recent daily bars
    bars = client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start='2023-12-01',
        end='2023-12-31',
        adjustment='raw'
    ).df
    
    print(f"\nFetched {len(bars)} daily bars")
    print("\nFirst 5 rows:")
    print(bars.head())
    
    print("\nLast 5 rows:")
    print(bars.tail())
    
    print("\nData statistics:")
    print(f"Close price range: ${bars['close'].min():.2f} - ${bars['close'].max():.2f}")
    print(f"Average close: ${bars['close'].mean():.2f}")
    print(f"Volume range: {bars['volume'].min():,.0f} - {bars['volume'].max():,.0f}")
    
    # Check for splits
    print("\nChecking for potential splits/adjustments...")
    bars['price_change'] = bars['close'].pct_change()
    large_moves = bars[abs(bars['price_change']) > 0.2]
    
    if len(large_moves) > 0:
        print(f"Found {len(large_moves)} days with >20% price change:")
        print(large_moves[['close', 'price_change']])

if __name__ == "__main__":
    asyncio.run(test_single_symbol())