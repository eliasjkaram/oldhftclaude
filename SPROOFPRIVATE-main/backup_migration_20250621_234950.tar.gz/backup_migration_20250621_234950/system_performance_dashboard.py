#!/usr/bin/env python3
"""
System Performance Dashboard
============================
Real-time monitoring and visualization of all system components
"""

import os
import json
import time
import threading
import psutil
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict, deque
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import seaborn as sns
import tkinter as tk
from tkinter import ttk
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

from unified_logging import get_logger
from health_monitoring import get_health_monitor
from realtime_data_sync import get_data_sync
from unified_error_handling import get_error_handler

logger = get_logger(__name__)

class SystemPerformanceDashboard:
    """Real-time performance monitoring dashboard"""
    
    def __init__(self, master_system=None):
        self.master_system = master_system
        self.running = False
        
        # Data collectors
        self.health_monitor = get_health_monitor()
        self.data_sync = get_data_sync()
        self.error_handler = get_error_handler()
        
        # Performance metrics storage
        self.metrics_history = {}
            'system': deque(maxlen=1000),
            'trading': deque(maxlen=1000),
            'ai_bots': deque(maxlen=1000),
            'data_pipeline': deque(maxlen=1000),
            'error_rates': deque(maxlen=1000)
        }
        
        # Real-time stats
        self.current_stats = {}
            'uptime': 0,
            'trades_today': 0,
            'profit_today': 0.0,
            'active_strategies': 0,
            'ai_decisions': 0,
            'error_rate': 0.0,
            'system_health': 100.0
        }
        
        # Initialize GUI
        self.setup_gui()
        
        # Start monitoring threads
        self.start_monitoring()
    
    def setup_gui(self):
        """Setup the dashboard GUI"""
        self.root = tk.Tk()
        self.root.title("Trading System Performance Dashboard")
        self.root.geometry("1600x900")
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True)
        
        # Create tabs
        self.create_overview_tab()
        self.create_trading_tab()
        self.create_system_tab()
        self.create_ai_tab()
        self.create_errors_tab()
        
        # Status bar
        self.status_bar = ttk.Label()
            self.root,
            text="Dashboard Active",
            relief=tk.SUNKEN
        )
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def create_overview_tab(self):
        """Create overview tab with key metrics"""
        overview_frame = ttk.Frame(self.notebook)
        self.notebook.add(overview_frame, text="Overview")
        
        # Create metric cards
        metrics_frame = ttk.Frame(overview_frame)
        metrics_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Grid layout for metric cards
        self.metric_cards = {}
        metrics = []
            ('System Health', 'system_health', '%', 'green'),
            ('Trades Today', 'trades_today', '', 'blue'),
            ('Profit Today', 'profit_today', '$', 'green'),
            ('Active Strategies', 'active_strategies', '', 'orange'),
            ('AI Decisions', 'ai_decisions', '', 'purple'),
            ('Error Rate', 'error_rate', '%', 'red'),
            ('Uptime', 'uptime', 'h', 'blue'),
            ('Data Latency', 'data_latency', 'ms', 'yellow')
        ]
        
        for i, (label, key, unit, color) in enumerate(metrics):
            row = i // 4
            col = i % 4
            
            card = self.create_metric_card()
                metrics_frame, label, key, unit, color
            )
            card.grid(row=row, column=col, padx=5, pady=5, sticky='nsew')
            
            metrics_frame.grid_columnconfigure(col, weight=1)
            metrics_frame.grid_rowconfigure(row, weight=1)
        
        # Add real-time chart
        chart_frame = ttk.Frame(overview_frame)
        chart_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create matplotlib figure
        self.overview_fig, self.overview_axes = plt.subplots(2, 2, figsize=(12, 6))
        self.overview_fig.tight_layout(pad=3.0)
        
        self.overview_canvas = FigureCanvasTkAgg(self.overview_fig, chart_frame)
        self.overview_canvas.get_tk_widget().pack(fill='both', expand=True)
    
    def create_metric_card(self, parent, label, key, unit, color):
        """Create a metric display card"""
        card = ttk.LabelFrame(parent, text=label, padding=10)
        
        # Value label
        value_var = tk.StringVar(value="--")
        value_label = ttk.Label()
            card,
            textvariable=value_var,
            font=('Arial', 24, 'bold')
        )
        value_label.pack()
        
        # Unit label
        if unit:
            unit_label = ttk.Label(card, text=unit, font=('Arial', 12))
            unit_label.pack()
        
        # Trend indicator
        trend_var = tk.StringVar(value="→")
        trend_label = ttk.Label()
            card,
            textvariable=trend_var,
            font=('Arial', 16)
        )
        trend_label.pack()
        
        # Store references
        self.metric_cards[key] = {}
            'value': value_var,
            'trend': trend_var,
            'color': color
        }
        
        return card
    
    def create_trading_tab(self):
        """Create trading performance tab"""
        trading_frame = ttk.Frame(self.notebook)
        self.notebook.add(trading_frame, text="Trading")
        
        # Trading stats
        stats_frame = ttk.LabelFrame(trading_frame, text="Trading Statistics", padding=10)
        stats_frame.pack(fill='x', padx=10, pady=10)
        
        # Create trading metrics display
        self.trading_stats = {}
        trading_metrics = []
            'Total Trades', 'Win Rate', 'Average Profit', 'Sharpe Ratio',
            'Max Drawdown', 'Daily Volume', 'Open Positions', 'P&L'
        ]
        
        for i, metric in enumerate(trading_metrics):
            row = i // 4
            col = i % 4
            
            label = ttk.Label(stats_frame, text=f"{metric}:")
            label.grid(row=row*2, column=col, sticky='w', padx=5)
            
            value_var = tk.StringVar(value="--")
            value_label = ttk.Label()
                stats_frame,
                textvariable=value_var,
                font=('Arial', 12, 'bold')
            )
            value_label.grid(row=row*2+1, column=col, sticky='w', padx=5)
            
            self.trading_stats[metric] = value_var
        
        # Trading chart
        chart_frame = ttk.Frame(trading_frame)
        chart_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.trading_fig, self.trading_ax = plt.subplots(figsize=(12, 6))
        self.trading_canvas = FigureCanvasTkAgg(self.trading_fig, chart_frame)
        self.trading_canvas.get_tk_widget().pack(fill='both', expand=True)
    
    def create_system_tab(self):
        """Create system resources tab"""
        system_frame = ttk.Frame(self.notebook)
        self.notebook.add(system_frame, text="System")
        
        # Resource monitors
        resource_frame = ttk.Frame(system_frame)
        resource_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # CPU usage
        cpu_frame = ttk.LabelFrame(resource_frame, text="CPU Usage", padding=10)
        cpu_frame.grid(row=0, column=0, padx=5, pady=5, sticky='nsew')
        
        self.cpu_progress = ttk.Progressbar()
            cpu_frame,
            length=300,
            mode='determinate'
        )
        self.cpu_progress.pack(pady=5)
        
        self.cpu_label = ttk.Label(cpu_frame, text="0%")
        self.cpu_label.pack()
        
        # Memory usage
        mem_frame = ttk.LabelFrame(resource_frame, text="Memory Usage", padding=10)
        mem_frame.grid(row=0, column=1, padx=5, pady=5, sticky='nsew')
        
        self.mem_progress = ttk.Progressbar()
            mem_frame,
            length=300,
            mode='determinate'
        )
        self.mem_progress.pack(pady=5)
        
        self.mem_label = ttk.Label(mem_frame, text="0%")
        self.mem_label.pack()
        
        # Process list
        process_frame = ttk.LabelFrame(system_frame, text="Active Processes", padding=10)
        process_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create treeview for processes
        columns = ('Process', 'Status', 'CPU %', 'Memory', 'Threads')
        self.process_tree = ttk.Treeview(process_frame, columns=columns, show='tree headings')
        
        for col in columns:
            self.process_tree.heading(col, text=col)
            self.process_tree.column(col, width=120)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(process_frame, orient='vertical', command=self.process_tree.yview)
        self.process_tree.configure(yscrollcommand=scrollbar.set)
        
        self.process_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        resource_frame.grid_columnconfigure(0, weight=1)
        resource_frame.grid_columnconfigure(1, weight=1)
    
    def create_ai_tab(self):
        """Create AI bots performance tab"""
        ai_frame = ttk.Frame(self.notebook)
        self.notebook.add(ai_frame, text="AI Bots")
        
        # AI bot status
        bot_frame = ttk.LabelFrame(ai_frame, text="AI Bot Status", padding=10)
        bot_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create bot status grid
        columns = ('Bot Name', 'Status', 'Decisions', 'Success Rate', 'Last Action')
        self.bot_tree = ttk.Treeview(bot_frame, columns=columns, show='tree headings')
        
        for col in columns:
            self.bot_tree.heading(col, text=col)
            self.bot_tree.column(col, width=140)
        
        bot_scrollbar = ttk.Scrollbar(bot_frame, orient='vertical', command=self.bot_tree.yview)
        self.bot_tree.configure(yscrollcommand=bot_scrollbar.set)
        
        self.bot_tree.pack(side='left', fill='both', expand=True)
        bot_scrollbar.pack(side='right', fill='y')
        
        # AI performance chart
        perf_frame = ttk.Frame(ai_frame)
        perf_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.ai_fig, self.ai_ax = plt.subplots(figsize=(12, 4))
        self.ai_canvas = FigureCanvasTkAgg(self.ai_fig, perf_frame)
        self.ai_canvas.get_tk_widget().pack(fill='both', expand=True)
    
    def create_errors_tab(self):
        """Create errors and alerts tab"""
        errors_frame = ttk.Frame(self.notebook)
        self.notebook.add(errors_frame, text="Errors & Alerts")
        
        # Error summary
        summary_frame = ttk.LabelFrame(errors_frame, text="Error Summary", padding=10)
        summary_frame.pack(fill='x', padx=10, pady=10)
        
        self.error_summary_text = tk.Text(summary_frame, height=5, wrap='word')
        self.error_summary_text.pack(fill='both', expand=True)
        
        # Recent errors
        recent_frame = ttk.LabelFrame(errors_frame, text="Recent Errors", padding=10)
        recent_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Error list
        columns = ('Time', 'Component', 'Category', 'Severity', 'Message')
        self.error_tree = ttk.Treeview(recent_frame, columns=columns, show='tree headings')
        
        for col in columns:
            self.error_tree.heading(col, text=col)
            self.error_tree.column(col, width=120)
        
        error_scrollbar = ttk.Scrollbar(recent_frame, orient='vertical', command=self.error_tree.yview)
        self.error_tree.configure(yscrollcommand=error_scrollbar.set)
        
        self.error_tree.pack(side='left', fill='both', expand=True)
        error_scrollbar.pack(side='right', fill='y')
        
        # Alert controls
        alert_frame = ttk.Frame(errors_frame)
        alert_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Button()
            alert_frame,
            text="Clear Alerts",
            command=self.clear_alerts
        ).pack(side='left', padx=5)
        
        ttk.Button()
            alert_frame,
            text="Export Logs",
            command=self.export_logs
        ).pack(side='left', padx=5)
    
    def start_monitoring(self):
        """Start all monitoring threads"""
        self.running = True
        
        # Start update threads
        threading.Thread(target=self.update_metrics, daemon=True).start()
        threading.Thread(target=self.update_charts, daemon=True).start()
        threading.Thread(target=self.update_processes, daemon=True).start()
        threading.Thread(target=self.update_errors, daemon=True).start()
        
        logger.info("Performance dashboard monitoring started")
    
    def update_metrics(self):
        """Update performance metrics"""
        while self.running:
            try:
                # Get health data
                health = self.health_monitor.get_health()
                
                # Get data sync metrics
                data_metrics = self.data_sync.get_metrics()
                
                # Get error statistics
                error_stats = self.error_handler.get_error_statistics()
                
                # Calculate system health score
                system_health = self.calculate_system_health(health, error_stats)
                
                # Update current stats
                self.current_stats.update({)
                    'system_health': system_health,
                    'error_rate': error_stats.get('recent_error_rate', 0),
                    'data_latency': data_metrics.get('avg_latency_ms', 0),
                    'uptime': self.calculate_uptime()
                })
                
                # Get trading stats if available
                if self.master_system:
                    self.update_trading_stats()
                
                # Store metrics history
                timestamp = datetime.now()
                self.metrics_history['system'].append({)
                    'timestamp': timestamp,
                    'cpu': psutil.cpu_percent(),
                    'memory': psutil.virtual_memory().percent,
                    'disk': psutil.disk_usage('/').percent,
                    'health': system_health
                })
                
                self.metrics_history['error_rates'].append({)
                    'timestamp': timestamp,
                    'rate': error_stats.get('recent_error_rate', 0),
                    'total': error_stats.get('total_errors', 0)
                })
                
                # Update GUI
                self.root.after(0, self.refresh_metrics_display)
                
                time.sleep(1)  # Update every second
                
            except Exception as e:
                logger.error(f"Error updating metrics: {e}")
                time.sleep(5)
    
    def update_charts(self):
        """Update performance charts"""
        while self.running:
            try:
                self.root.after(0, self.refresh_charts)
                time.sleep(5)  # Update charts every 5 seconds
            except Exception as e:
                logger.error(f"Error updating charts: {e}")
                time.sleep(10)
    
    def update_processes(self):
        """Update process information"""
        while self.running:
            try:
                # Get process info from health monitor
                components = self.health_monitor.components
                
                # Update process tree
                self.root.after(0, self.refresh_process_list, components)
                
                time.sleep(3)  # Update every 3 seconds
                
            except Exception as e:
                logger.error(f"Error updating processes: {e}")
                time.sleep(5)
    
    def update_errors(self):
        """Update error information"""
        while self.running:
            try:
                # Get error statistics
                error_stats = self.error_handler.get_error_statistics()
                
                # Get recent errors
                recent_errors = list(self.error_handler.error_history)[-20:]  # Last 20
                
                # Update error display
                self.root.after(0, self.refresh_error_display, error_stats, recent_errors)
                
                time.sleep(2)  # Update every 2 seconds
                
            except Exception as e:
                logger.error(f"Error updating error display: {e}")
                time.sleep(5)
    
    def calculate_system_health(self, health_data: Dict, error_stats: Dict) -> float:
        """Calculate overall system health score"""
        score = 100.0
        
        # Deduct for unhealthy components
        for component, status in health_data.get('components', {}).items():
            if status.get('status') != 'healthy':
                score -= 10
        
        # Deduct for high error rate
        error_rate = error_stats.get('recent_error_rate', 0)
        if error_rate > 10:
            score -= 20
        elif error_rate > 5:
            score -= 10
        elif error_rate > 1:
            score -= 5
        
        # Deduct for resource usage
        resources = health_data.get('system', {})
        if resources.get('cpu_percent', 0) > 80:
            score -= 10
        if resources.get('memory_percent', 0) > 80:
            score -= 10
        
        return max(0, score)
    
    def calculate_uptime(self) -> float:
        """Calculate system uptime in hours"""
        if hasattr(self, 'start_time'):
            return (datetime.now() - self.start_time).total_seconds() / 3600
        return 0
    
    def update_trading_stats(self):
        """Update trading statistics from master system"""
        if not self.master_system:
            return
        
        try:
            # This would get real trading stats from the master system
            # For now, using placeholder values
            self.current_stats.update({)
                'trades_today': 150,
                'profit_today': 2500.50,
                'active_strategies': 12,
                'ai_decisions': 3200
            })
        except Exception as e:
            logger.error(f"Error getting trading stats: {e}")
    
    def refresh_metrics_display(self):
        """Refresh metric card displays"""
        for key, card in self.metric_cards.items():
            if key in self.current_stats:
                value = self.current_stats[key]
                
                # Format value
                if key == 'system_health':
                    card['value'].set(f"{value:.1f}")
                    color = 'green' if value > 80 else 'yellow' if value > 60 else 'red'
                elif key == 'profit_today':
                    card['value'].set(f"{value:,.2f}")
                    color = 'green' if value > 0 else 'red'
                elif key == 'error_rate':
                    card['value'].set(f"{value:.1f}")
                    color = 'green' if value < 1 else 'yellow' if value < 5 else 'red'
                else:
                    if isinstance(value, float):
                        card['value'].set(f"{value:.1f}")
                    else:
                        card['value'].set(str(value))
                
                # Update trend (simplified)
                card['trend'].set("↑" if value > 0 else "→")
        
        # Update resource monitors
        cpu_percent = psutil.cpu_percent()
        mem_percent = psutil.virtual_memory().percent
        
        self.cpu_progress['value'] = cpu_percent
        self.cpu_label.config(text=f"{cpu_percent:.1f}%")
        
        self.mem_progress['value'] = mem_percent
        self.mem_label.config(text=f"{mem_percent:.1f}%")
    
    def refresh_charts(self):
        """Refresh performance charts"""
        try:
            # Clear previous plots
            for ax in self.overview_axes.flat:
                ax.clear()
            
            # System metrics chart
            if len(self.metrics_history['system']) > 1:
                system_df = pd.DataFrame(list(self.metrics_history['system']))
                
                # CPU/Memory chart
                ax1 = self.overview_axes[0, 0]
                ax1.plot(system_df['timestamp'], system_df['cpu'], label='CPU %', color='blue')
                ax1.plot(system_df['timestamp'], system_df['memory'], label='Memory %', color='red')
                ax1.set_title('System Resources')
                ax1.set_ylabel('Usage %')
                ax1.legend()
                ax1.grid(True, alpha=0.3)
                
                # Health score chart
                ax2 = self.overview_axes[0, 1]
                ax2.plot(system_df['timestamp'], system_df['health'], color='green', linewidth=2)
                ax2.set_title('System Health Score')
                ax2.set_ylabel('Score')
                ax2.set_ylim(0, 100)
                ax2.grid(True, alpha=0.3)
            
            # Error rate chart
            if len(self.metrics_history['error_rates']) > 1:
                error_df = pd.DataFrame(list(self.metrics_history['error_rates']))
                
                ax3 = self.overview_axes[1, 0]
                ax3.plot(error_df['timestamp'], error_df['rate'], color='red')
                ax3.set_title('Error Rate')
                ax3.set_ylabel('Errors/min')
                ax3.grid(True, alpha=0.3)
            
            # Trading performance (placeholder)
            ax4 = self.overview_axes[1, 1]
            times = pd.date_range(end=datetime.now(), periods=100, freq='1min')
            profits = np.cumsum(np.random.randn(100) * 100)
            ax4.plot(times, profits, color='green')
            ax4.set_title('Cumulative P&L')
            ax4.set_ylabel('Profit ($)')
            ax4.grid(True, alpha=0.3)
            
            self.overview_fig.tight_layout()
            self.overview_canvas.draw()
            
        except Exception as e:
            logger.error(f"Error refreshing charts: {e}")
    
    def refresh_process_list(self, components: Dict):
        """Refresh process list display"""
        # Clear existing items
        for item in self.process_tree.get_children():
            self.process_tree.delete(item)
        
        # Add component processes
        for name, info in components.items():
            status = info.get('status', 'unknown')
            cpu = f"{info.get('metrics', {}).get('cpu_percent', 0):.1f}"
            memory = f"{info.get('metrics', {}).get('memory_mb', 0):.1f} MB"
            threads = info.get('metrics', {}).get('thread_count', 0)
            
            # Color based on status
            tags = ('healthy',) if status == 'healthy' else ('unhealthy',)
            
            self.process_tree.insert()
                '', 'end',
                values=(name, status, cpu, memory, threads),
                tags=tags
            )
        
        # Configure tag colors
        self.process_tree.tag_configure('healthy', foreground='green')
        self.process_tree.tag_configure('unhealthy', foreground='red')
    
    def refresh_error_display(self, error_stats: Dict, recent_errors: List):
        """Refresh error display"""
        # Update error summary
        summary = f"Total Errors: {error_stats.get('total_errors', 0)}\n"
        summary += f"Error Rate: {error_stats.get('recent_error_rate', 0):.1f}/min\n"
        summary += f"Circuit Breakers Active: {error_stats.get('circuit_breakers_active', 0)}\n"
        
        # Top errors
        top_errors = error_stats.get('top_errors', [])
        if top_errors:
            summary += "\nTop Errors:\n"
            for error in top_errors[:3]:
                summary += f"- {error['error']}: {error['count']} times\n"
        
        self.error_summary_text.delete('1.0', tk.END)
        self.error_summary_text.insert('1.0', summary)
        
        # Update recent errors list
        for item in self.error_tree.get_children():
            self.error_tree.delete(item)
        
        for error in reversed(recent_errors):
            timestamp = error.get('timestamp', '')
            if timestamp:
                time_str = datetime.fromisoformat(timestamp).strftime('%H:%M:%S')
            else:
                time_str = '--:--:--'
            
            values = ()
                time_str,
                error.get('component', 'unknown'),
                error.get('category', 'unknown'),
                error.get('severity', 'unknown'),
                error.get('error_message', '')[:50] + '...'
            )
            
            # Color based on severity
            severity = error.get('severity', 'low')
            tags = (severity,)
            
            self.error_tree.insert('', 'end', values=values, tags=tags)
        
        # Configure severity colors
        self.error_tree.tag_configure('critical', foreground='red')
        self.error_tree.tag_configure('high', foreground='orange')
        self.error_tree.tag_configure('medium', foreground='yellow')
        self.error_tree.tag_configure('low', foreground='gray')
    
    def clear_alerts(self):
        """Clear current alerts"""
        # This would clear alerts in the system
        logger.info("Clearing alerts")
    
    def export_logs(self):
        """Export system logs"""
        # This would export logs to a file
        logger.info("Exporting logs")
    
    def generate_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report"""
        report = {}
            'timestamp': datetime.now().isoformat(),
            'system_health': self.current_stats.get('system_health', 0),
            'uptime_hours': self.current_stats.get('uptime', 0),
            'metrics': self.current_stats,
            'resource_usage': {}
                'cpu_percent': psutil.cpu_percent(),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_percent': psutil.disk_usage('/').percent
            },
            'trading_performance': {}
                'trades_today': self.current_stats.get('trades_today', 0),
                'profit_today': self.current_stats.get('profit_today', 0),
                'active_strategies': self.current_stats.get('active_strategies', 0)
            },
            'error_summary': self.error_handler.get_error_statistics(),
            'data_sync_metrics': self.data_sync.get_metrics()
        }
        
        return report
    
    def save_performance_snapshot(self, filepath: str = None):
        """Save current performance snapshot"""
        if not filepath:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filepath = f"performance_snapshot_{timestamp}.json"
        
        report = self.generate_performance_report()
        
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"Performance snapshot saved to {filepath}")
    
    def run(self):
        """Run the dashboard"""
        self.start_time = datetime.now()
        logger.info("Starting performance dashboard")
        self.root.mainloop()
    
    def stop(self):
        """Stop the dashboard"""
        self.running = False
        self.root.quit()
        logger.info("Performance dashboard stopped")


# Integration function for master system
def integrate_performance_dashboard(master_system):
    """
    Integrate performance dashboard with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from system_performance_dashboard import integrate_performance_dashboard
    integrate_performance_dashboard(self)
    """
    
    # Create dashboard instance
    master_system.performance_dashboard = SystemPerformanceDashboard(master_system)
    
    # Add dashboard methods to master system
    def show_performance_dashboard(self):
        """Show the performance dashboard"""
        self.performance_dashboard.run()
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Get current performance report"""
        return self.performance_dashboard.generate_performance_report()
    
    def save_performance_snapshot(self, filepath: str = None):
        """Save performance snapshot"""
        self.performance_dashboard.save_performance_snapshot(filepath)
    
    # Bind methods
    master_system.show_performance_dashboard = show_performance_dashboard.__get__(master_system)
    master_system.get_performance_report = get_performance_report.__get__(master_system)
    master_system.save_performance_snapshot = save_performance_snapshot.__get__(master_system)
    
    logger.info("Performance dashboard integrated with master system")


if __name__ == "__main__":
    # Test dashboard standalone
    dashboard = SystemPerformanceDashboard()
    
    try:
        dashboard.run()
    except KeyboardInterrupt:
        print("\nShutting down dashboard...")
        dashboard.stop()