
#!/usr/bin/env python3
"""
Quick Start Script - Launch the trading system with minimal setup
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import sys
import subprocess
import time

from universal_market_data import get_current_market_data, validate_price


print("🚀 " + "="*60)
print("    QUICK START - OPTIONS TRADING PLATFORM")
print("="*60)

def install_dependencies():
    """Install missing dependencies"""
    print("\n📦 Installing missing dependencies...")
    
    # Core dependencies that might be missing
    dependencies = []
        'aiohttp',
        'yfinance', 
        'ta',
        'scikit-learn',
        'matplotlib',
        'pandas',
        'numpy',
        'scipy'
    ]
    
    for dep in dependencies:
        try:
            __import__(dep.replace('-', '_')
            print(f"✅ {dep} - already installed")
        except ImportError:
            print(f"📦 Installing {dep}...")
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', dep])
                print(f"✅ {dep} - installed successfully")
            except subprocess.CalledProcessError:
                print(f"⚠️  {dep} - installation failed (optional)")

def launch_gui():
    """Launch the comprehensive GUI"""
    print("\n🚀 Launching Comprehensive Trading GUI...")
    print("   This will open a professional trading interface with:")
    print("   • Intelligent strategy selection")
    print("   • Real-time market analysis") 
    print("   • Multi-leg spread execution")
    print("   • Advanced analytics dashboard")
    print("\n   Note: The GUI will run until you close it.")
    print("   Use Ctrl+C to stop if running in terminal.")
    
    try:
        import tkinter as tk
        print("✅ Tkinter available - GUI ready to launch")
        
        # Import and run the GUI
        from comprehensive_trading_gui import ComprehensiveTradingGUI
        
        print("\n🎯 Starting GUI application...")
        app = ComprehensiveTradingGUI()
        
        print("✅ GUI initialized successfully!")
        print("📊 Professional trading interface is now running...")
        
        # Run the GUI (this will block until GUI is closed)
        app.run()
        
    except ImportError as e:
        print(f"❌ GUI launch failed: {e}")
        print("💡 Falling back to demo mode...")
        demo_mode()
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("💡 System components are available, try manual launch:")
        print("   python comprehensive_trading_gui.py")

def demo_mode():
    """Run in demo mode if GUI unavailable"""
    print("\n🎭 Demo Mode - Showing System Capabilities")
    
    # Show available components
    components = {}
        'Strategy Selection': 'strategy_selection_bot.py',
        'Market Data Engine': 'market_data_engine.py', 
        'Execution Engine': 'spread_execution_engine.py',
        'Options Strategies': 'advanced_options_strategies.py',
        'Pricing Models': 'advanced_pricing_models.py',
        'Trading GUI': 'comprehensive_trading_gui.py'
    }
    
    print("\n📁 Available System Components:")
    for name, file in components.items():
        print(f"   ✅ {name} ({file})")
        
    print("\n🎯 To run individual components:")
    print("   python strategy_selection_bot.py")
    print("   python market_data_engine.py") 
    print("   python spread_execution_engine.py")
    print("   python advanced_options_strategies.py")
    print("   python advanced_pricing_models.py")
    
    print("\n🚀 To launch full GUI:")
    print("   python comprehensive_trading_gui.py")

def main():
    """Main quick start function"""
    print("\n🔧 System Check...")
    
    # Check Python version
    if sys.version_info < (3, 7):
        print("❌ Python 3.7+ required")
        return
    else:
        print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} - OK")
    
    # Install dependencies
    install_dependencies()
    
    # Launch GUI
    launch_gui()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye! Thanks for using the Options Trading Platform!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("💡 Try running: python comprehensive_trading_gui.py")