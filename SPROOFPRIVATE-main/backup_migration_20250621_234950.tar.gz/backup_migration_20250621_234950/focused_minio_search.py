#!/usr/bin/env python3
"""
Focused MinIO Search for Options Complete Data
Searches specifically for 'options_complete' and related patterns
"""

import os
import sys
import json
from datetime import datetime
from typing import Dict, List, Any
import traceback

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


from minio import Minio
from minio.error import S3Error

# MinIO Configuration
MINIO_CONFIG = {}
    'endpoint': 'https://uschristmas.us',
    'access_key': os.getenv('MINIO_ACCESS_KEY'),
    'secret_key': os.getenv('MINIO_SECRET_KEY'),
    'bucket_name': 'stockdb',
    'secure': True
}

class FocusedMinIOSearch:
    """Focused search for options complete data"""
    
    def __init__(self):
        self.endpoint = MINIO_CONFIG['endpoint']
        self.access_key = MINIO_CONFIG['access_key']
        self.secret_key = MINIO_CONFIG['secret_key']
        self.bucket_name = MINIO_CONFIG['bucket_name']
        self.secure = MINIO_CONFIG['secure']
        
        # Clean endpoint for MinIO client
        self.clean_endpoint = self.endpoint.replace('https://', '').replace('http://', '')
        
        # Initialize client
        self.client = None
        self._connect()
    
    def _connect(self):
        """Connect to MinIO server"""
        try:
            self.client = Minio()
                self.clean_endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=self.secure
            )
            print(f"✓ Connected to MinIO server: {self.endpoint}")
        except Exception as e:
            print(f"✗ Failed to connect to MinIO: {e}")
            sys.exit(1)
    
    def search_top_level_directories(self) -> List[str]:
        """Get all top-level directories first"""
        print("📁 Scanning top-level directories...")
        
        directories = set()
        
        try:
            # List objects with delimiter to get only top-level
            objects = self.client.list_objects(self.bucket_name, delimiter='/')
            
            for obj in objects:
                if obj.is_dir:
                    directories.add(obj.object_name.rstrip('/')
                elif '/' in obj.object_name:
                    # Extract directory from file path
                    dir_name = obj.object_name.split('/')[0]
                    directories.add(dir_name)
        
        except Exception as e:
            print(f"❌ Error listing top-level directories: {e}")
            return []
        
        dir_list = sorted(list(directories)
        print(f"   Found {len(dir_list)} top-level directories")
        
        # Print all directories to see what's available
        print("   📂 All top-level directories:")
        for i, dir_name in enumerate(dir_list):
            print(f"      {i+1:2d}. {dir_name}")
        
        return dir_list
    
    def search_specific_patterns(self, directories: List[str]) -> Dict[str, Any]:
        """Search for specific patterns in directory names"""
        print("\n🎯 Searching for specific patterns...")
        
        results = {}
            'options_complete_variations': [],
            'complete_directories': [],
            'options_directories': [],
            'recent_year_directories': [],
            'promising_directories': []
        }
        
        # Patterns to search for
        options_complete_patterns = []
            'options_complete', 'options-complete', 'optionscomplete',
            'complete_options', 'complete-options', 'completeoptions',
            'options_full', 'options-full', 'optionsfull',
            'full_options', 'full-options', 'fulloptions'
        ]
        
        complete_patterns = ['complete', 'full', 'comprehensive', 'total', 'archive']
        options_patterns = ['options', 'option', 'derivatives', 'calls', 'puts']
        recent_years = ['2020', '2021', '2022', '2023', '2024']
        
        for dir_name in directories:
            dir_lower = dir_name.lower()
            
            # Check for exact options_complete patterns
            for pattern in options_complete_patterns:
                if pattern in dir_lower:
                    results['options_complete_variations'].append(dir_name)
                    print(f"   🎯 FOUND: {dir_name} (matches '{pattern}')")
            
            # Check for complete-related directories
            if any(pattern in dir_lower for pattern in complete_patterns):
                results['complete_directories'].append(dir_name)
                print(f"   ✅ Complete-related: {dir_name}")
            
            # Check for options-related directories
            if any(pattern in dir_lower for pattern in options_patterns):
                results['options_directories'].append(dir_name)
                print(f"   📈 Options-related: {dir_name}")
            
            # Check for recent years
            if any(year in dir_name for year in recent_years):
                results['recent_year_directories'].append(dir_name)
                print(f"   📅 Recent year: {dir_name}")
            
            # Check for promising combinations
            if (any(opt in dir_lower for opt in options_patterns) and)
                any(comp in dir_lower for comp in complete_patterns):
                results['promising_directories'].append(dir_name)
                print(f"   🚀 PROMISING: {dir_name} (options + complete)")
        
        return results
    
    def investigate_directory_contents(self, directory: str, max_files: int = 50) -> Dict[str, Any]:
        """Investigate contents of a specific directory"""
        print(f"\n🔍 Investigating directory: {directory}")
        
        try:
            objects = list(self.client.list_objects())
                self.bucket_name, 
                prefix=f"{directory}/",
                recursive=False
            )
            
            files = []
            subdirs = set()
            
            for obj in objects:
                if obj.object_name.endswith('/'):
                    # It's a subdirectory
                    subdir = obj.object_name.rstrip('/').split('/')[-1]
                    subdirs.add(subdir)
                else:
                    # It's a file
                    files.append({)
                        'name': obj.object_name,
                        'size_mb': obj.size / (1024**2) if obj.size else 0,
                        'modified': str(obj.last_modified)
                    })
            
            # Extract years from filenames
            years_found = set()
            for file_info in files:
                import re
                year_matches = re.findall(r'20[0-2]\d', file_info['name'])
                for year_str in year_matches:
                    try:
                        year = int(year_str)
                        if 2000 <= year <= 2025:
                            years_found.add(year)
                    except ValueError:
                        pass
            
            total_size_mb = sum(f['size_mb'] for f in files)
            
            print(f"   📊 Files: {len(files)}")
            print(f"   📁 Subdirectories: {len(subdirs)}")
            print(f"   💾 Total size: {total_size_mb:.1f} MB")
            print(f"   📅 Years found: {sorted(list(years_found)}")
            
            if subdirs:
                print(f"   📂 Subdirectories: {sorted(list(subdirs)}")
            
            if files:
                print(f"   📄 Sample files:")
                for file_info in files[:5]:
                    print(f"      • {file_info['name']} ({file_info['size_mb']:.1f} MB)")
            
            return {}
                'directory': directory,
                'file_count': len(files),
                'subdirectory_count': len(subdirs),
                'subdirectories': sorted(list(subdirs),
                'total_size_mb': total_size_mb,
                'years_found': sorted(list(years_found),
                'sample_files': files[:max_files],
                'has_recent_data': any(year >= 2020 for year in years_found),
                'year_range': f"{min(years_found)}-{max(years_found)}" if years_found else "No years found"
            }
            
        except Exception as e:
            print(f"   ❌ Error investigating directory: {e}")
            return {'directory': directory, 'error': str(e)}
    
    def focused_search(self) -> Dict[str, Any]:
        """Perform focused search for options complete data"""
        print("\n" + "="*80)
        print("FOCUSED MINIO SEARCH FOR OPTIONS COMPLETE DATA")
        print("="*80)
        
        # Step 1: Get all top-level directories
        directories = self.search_top_level_directories()
        
        # Step 2: Search for specific patterns
        pattern_results = self.search_specific_patterns(directories)
        
        # Step 3: Investigate promising directories
        directory_investigations = {}
        
        # Investigate options_complete variations first
        for dir_name in pattern_results['options_complete_variations']:
            directory_investigations[dir_name] = self.investigate_directory_contents(dir_name)
        
        # Investigate other promising directories
        for dir_name in pattern_results['promising_directories']:
            if dir_name not in directory_investigations:
                directory_investigations[dir_name] = self.investigate_directory_contents(dir_name)
        
        # Investigate all options directories
        for dir_name in pattern_results['options_directories']:
            if dir_name not in directory_investigations:
                directory_investigations[dir_name] = self.investigate_directory_contents(dir_name)
        
        return {}
            'timestamp': datetime.now().isoformat(),
            'total_directories': len(directories),
            'all_directories': directories,
            'pattern_matches': pattern_results,
            'directory_investigations': directory_investigations,
            'summary': self._create_summary(pattern_results, directory_investigations)
        }
    
    def _create_summary(self, pattern_results: Dict, investigations: Dict) -> Dict[str, Any]:
        """Create search summary"""
        
        # Find directories with recent data (2020-2024)
        recent_data_dirs = []
        for dir_name, investigation in investigations.items():
            if investigation.get('has_recent_data', False):
                recent_data_dirs.append({)
                    'directory': dir_name,
                    'years': investigation.get('years_found', []),
                    'file_count': investigation.get('file_count', 0),
                    'size_mb': investigation.get('total_size_mb', 0)
                })
        
        # Calculate total data available
        total_files = sum()
            investigation.get('file_count', 0) 
            for investigation in investigations.values()
        )
        total_size_mb = sum()
            investigation.get('total_size_mb', 0) 
            for investigation in investigations.values()
        )
        
        return {}
            'options_complete_found': len(pattern_results['options_complete_variations']) > 0,
            'options_complete_directories': pattern_results['options_complete_variations'],
            'promising_directories': pattern_results['promising_directories'],
            'recent_data_directories': recent_data_dirs,
            'total_options_files': total_files,
            'total_options_size_mb': total_size_mb,
            'key_findings': self._generate_key_findings(pattern_results, investigations)
        }
    
    def _generate_key_findings(self, pattern_results: Dict, investigations: Dict) -> List[str]:
        """Generate key findings"""
        findings = []
        
        if pattern_results['options_complete_variations']:
            findings.append(f"FOUND {len(pattern_results['options_complete_variations'])} 'options_complete' variations")
            for dir_name in pattern_results['options_complete_variations']:
                investigation = investigations.get(dir_name, {})
                years = investigation.get('years_found', [])
                if years:
                    findings.append(f"  - {dir_name}: {len(investigation.get('sample_files', [])} files, years {min(years)}-{max(years)}")
        
        if pattern_results['promising_directories']:
            findings.append(f"Found {len(pattern_results['promising_directories'])} promising directories")
        
        # Look for complete coverage
        all_years = set()
        for investigation in investigations.values():
            all_years.update(investigation.get('years_found', [])
        
        target_years = set(range(2009, 2025)
        missing_years = target_years - all_years
        
        if all_years:
            findings.append(f"Total year coverage: {min(all_years)}-{max(all_years)}")
            if missing_years:
                findings.append(f"Missing years: {sorted(list(missing_years)}")
        
        return findings

def main():
    """Main execution function"""
    print("FOCUSED MINIO SEARCH FOR OPTIONS COMPLETE DATA")
    print("=" * 60)
    print("Searching specifically for 'options_complete' directory and variations")
    print()
    
    try:
        # Initialize search
        searcher = FocusedMinIOSearch()
        
        # Perform focused search
        search_results = searcher.focused_search()
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"/home/harry/alpaca-mcp/focused_minio_search_results_{timestamp}.json"
        
        with open(report_file, 'w') as f:
            json.dump(search_results, f, indent=2, default=str)
        
        # Print final summary
        print("\n" + "="*80)
        print("FOCUSED SEARCH RESULTS")
        print("="*80)
        
        summary = search_results['summary']
        
        print(f"🎯 SEARCH COMPLETE")
        print(f"   Total directories scanned: {search_results['total_directories']}")
        print(f"   Options directories found: {len(search_results['pattern_matches']['options_directories'])}")
        print()
        
        if summary['options_complete_found']:
            print(f"✅ SUCCESS: Found 'options_complete' directories!")
            for dir_name in summary['options_complete_directories']:
                print(f"   📁 {dir_name}")
        else:
            print(f"❌ No 'options_complete' directories found")
        
        if summary['promising_directories']:
            print(f"\n🚀 Promising directories (options + complete):")
            for dir_name in summary['promising_directories']:
                print(f"   📁 {dir_name}")
        
        if summary['recent_data_directories']:
            print(f"\n📅 Directories with recent data (2020-2024):")
            for dir_info in summary['recent_data_directories']:
                years_range = f"{min(dir_info['years'])}-{max(dir_info['years'])}" if dir_info['years'] else "No years"
                print(f"   📁 {dir_info['directory']}: {dir_info['file_count']} files, {years_range}")
        
        print(f"\n📊 TOTAL OPTIONS DATA FOUND:")
        print(f"   Files: {summary['total_options_files']:,}")
        print(f"   Size: {summary['total_options_size_mb']:.1f} MB")
        
        if summary['key_findings']:
            print(f"\n🎯 KEY FINDINGS:")
            for finding in summary['key_findings']:
                print(f"   • {finding}")
        
        print(f"\n📄 Detailed results saved to: {report_file}")
        
        # Final assessment
        print(f"\n🚀 FINAL ASSESSMENT:")
        if summary['options_complete_found']:
            print(f"✅ The user was RIGHT - 'options_complete' directory exists!")
            print(f"   This confirms there is more complete options data available.")
        else:
            print(f"❌ No 'options_complete' directory found in focused search.")
            print(f"   Previous analysis appears to be comprehensive.")
        
    except Exception as e:
        print(f"❌ Error during focused search: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()