#!/usr/bin/env python3
"""
Test MinIO connection to uschristmas.us and explore available data
"""

import os
from minio import Minio
from minio.error import S3Error
from dotenv import load_dotenv
import json
import urllib3

# Disable SSL warnings for testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Load environment variables
load_dotenv()

print("="*80)
print("🔍 TESTING MINIO CONNECTION TO USCHRISTMAS.US")
print("="*80)

# Get MinIO credentials from environment
endpoint = os.getenv('MINIO_ENDPOINT', 'https://uschristmas.us')
access_key = os.getenv('MINIO_ACCESS_KEY', 'AKSTOCKDB2024')
secret_key = os.getenv('MINIO_SECRET_KEY', 'StockDB-Secret-Access-Key-2024-Secure!')

# Clean up endpoint
original_endpoint = endpoint
endpoint = endpoint.replace('https://', '').replace('http://', '')
if ':' not in endpoint:
    endpoint += ':9000'

print(f"Original endpoint: {original_endpoint}")
print(f"Cleaned endpoint: {endpoint}")
print(f"Access Key: {access_key}")
print(f"Secret Key: {secret_key[:10]}...")

# Test different configurations
configs = [
    {'endpoint': endpoint, 'secure': True},
    {'endpoint': endpoint, 'secure': False},
    {'endpoint': 'uschristmas.us:9000', 'secure': True},
    {'endpoint': 'uschristmas.us:9000', 'secure': False},
]

successful_client = None

for config in configs:
    print(f"\nTrying endpoint={config['endpoint']}, secure={config['secure']}...")
    try:
        client = Minio(
            config['endpoint'],
            access_key=access_key,
            secret_key=secret_key,
            secure=config['secure']
        )
        
        # Try to list buckets
        buckets = list(client.list_buckets())
        print(f"✅ Connected successfully! Found {len(buckets)} buckets:")
        for bucket in buckets[:10]:  # Show first 10
            print(f"  - {bucket.name} (created: {bucket.creation_date})")
        
        successful_client = client
        successful_config = config
        break
        
    except Exception as e:
        print(f"❌ Failed: {type(e).__name__}: {str(e)[:100]}...")

if not successful_client:
    print("\n❌ Could not connect to MinIO with any configuration")
    exit(1)

print(f"\n✅ Using successful configuration: {successful_config}")
client = successful_client

# Explore buckets
print("\n" + "="*80)
print("📦 EXPLORING BUCKETS")
print("="*80)

# Look for stock-related buckets
stock_buckets = ['stockdb', 'market-data', 'stocks', 'options', 'options-complete']

for bucket_name in stock_buckets:
    try:
        # Check if bucket exists
        if client.bucket_exists(bucket_name):
            print(f"\n📁 Bucket: {bucket_name}")
            
            # List top-level objects/folders
            objects = list(client.list_objects(bucket_name, recursive=False))
            if objects:
                print(f"  Found {len(objects)} top-level items:")
                for obj in objects[:20]:  # Show first 20
                    if obj.is_dir:
                        print(f"  📁 {obj.object_name}")
                    else:
                        print(f"  📄 {obj.object_name} ({obj.size:,} bytes)")
            else:
                print("  Empty bucket")
                
    except S3Error as e:
        print(f"  ❌ Error accessing {bucket_name}: {e.code} - {e.message}")
    except Exception as e:
        print(f"  ❌ Error accessing {bucket_name}: {e}")

# Search for TLT data specifically
print("\n" + "="*80)
print("🔍 SEARCHING FOR TLT DATA")
print("="*80)

tlt_found = False

for bucket_name in stock_buckets:
    try:
        if client.bucket_exists(bucket_name):
            # Try different path patterns
            patterns = [
                'stocks/TLT/',
                'TLT/',
                'data/TLT/',
                'historical/TLT/',
                'equities/TLT/',
                'stocks/tlt/',
                'tlt/'
            ]
            
            for pattern in patterns:
                try:
                    objects = list(client.list_objects(bucket_name, prefix=pattern, recursive=True))
                    if objects:
                        print(f"\n✅ Found TLT data in {bucket_name} with pattern '{pattern}':")
                        for obj in objects[:10]:  # Show first 10
                            print(f"  - {obj.object_name} ({obj.size:,} bytes, modified: {obj.last_modified})")
                        tlt_found = True
                        
                        # Try to download a sample file
                        if len(objects) > 0:
                            sample_object = objects[0].object_name
                            print(f"\n📥 Attempting to download sample: {sample_object}")
                            try:
                                data = client.get_object(bucket_name, sample_object)
                                content = data.read(1000)  # Read first 1000 bytes
                                print(f"✅ Successfully accessed file!")
                                print(f"First 100 bytes: {content[:100]}")
                                data.close()
                            except Exception as e:
                                print(f"❌ Could not download: {e}")
                        break
                except Exception as e:
                    pass
    except Exception as e:
        pass

if not tlt_found:
    print("\n⚠️  No TLT data found in the expected locations")
    print("\nSearching more broadly for any files containing 'TLT'...")
    
    for bucket_name in stock_buckets:
        try:
            if client.bucket_exists(bucket_name):
                # Search for any object containing TLT
                all_objects = list(client.list_objects(bucket_name, recursive=True))
                tlt_objects = [obj for obj in all_objects if 'TLT' in obj.object_name.upper()]
                
                if tlt_objects:
                    print(f"\n✅ Found {len(tlt_objects)} objects containing 'TLT' in {bucket_name}:")
                    for obj in tlt_objects[:10]:
                        print(f"  - {obj.object_name} ({obj.size:,} bytes)")
        except:
            pass

print("\n" + "="*80)
print("✅ TEST COMPLETE")
print("="*80)