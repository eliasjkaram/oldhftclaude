#!/usr/bin/env python3
"""
Fix ALL Alpaca Import and API Usage Issues
==========================================

This script properly fixes:
1. All alpaca-py import statements
2. API client usage (self.api vs self.trading_client vs self.data_client)
3. Method signatures for new alpaca-py API
4. Missing attribute initializations
5. Duplicate definitions
"""

import os
import re
import glob
import json
from pathlib import Path
from typing import List, Dict, Tuple, Set, Optional
from datetime import datetime

class AlpacaImportFixer:
    def __init__(self):
        self.fixed_files = []
        self.errors = []
        self.issues_fixed = {}
            'imports': 0,
            'api_client': 0,
            'method_calls': 0,
            'attributes': 0,
            'duplicates': 0
        }
        
    def fix_file(self, filepath: str) -> bool:
        """Fix all issues in a single file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # Apply all fixes
            content = self.fix_imports(content)
            content = self.fix_api_client_usage(content)
            content = self.fix_method_calls(content)
            content = self.add_missing_attributes(content)
            content = self.remove_duplicates(content)
            content = self.fix_broken_syntax(content)
            
            # Only write if changes were made
            if content != original_content:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                self.fixed_files.append(filepath)
                return True
            
            return False
            
        except Exception as e:
            self.errors.append(f"Error fixing {filepath}: {str(e)}")
            return False
    
    def fix_imports(self, content: str) -> str:
        """Fix all import statements"""
        lines = content.split('\n')
        new_lines = []
        imports_added = False
        skip_next = False
        
        for i, line in enumerate(lines):
            if skip_next:
                skip_next = False
                continue
                
            # Skip the auto-generated import block at the very beginning
            if i == 0 and line.strip() and not line.startswith('#'):
                # This is likely a misplaced import, skip it
                continue
            
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
                if not imports_added:
                    # Add proper imports once
                    new_lines.extend([)
                        "from alpaca.trading.client import TradingClient",
                        "from alpaca.data.historical import StockHistoricalDataClient", 
                        "from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest",
                        "from alpaca.data.timeframe import TimeFrame",
                        "from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass",
                        "from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest"
                    ])
                    imports_added = True
                    self.issues_fixed['imports'] += 1
                continue
            
            # Fix old-style imports
                if not imports_added:
                    new_lines.extend([)
                        "from alpaca.trading.client import TradingClient",
                        "from alpaca.data.historical import StockHistoricalDataClient"
                    ])
                    imports_added = True
                    self.issues_fixed['imports'] += 1
                continue
            
                if not imports_added:
                    new_lines.extend([)
                        "from alpaca.trading.client import TradingClient",
                        "from alpaca.data.historical import StockHistoricalDataClient"
                    ])
                    imports_added = True
                    self.issues_fixed['imports'] += 1
                continue
            
            # Fix broken REST imports
from alpaca.trading.client import TradingClient
                new_lines.append("from alpaca.trading.client import TradingClient")
                self.issues_fixed['imports'] += 1
                continue
            
            new_lines.append(line)
        
        return '\n'.join(new_lines)
    
    def fix_api_client_usage(self, content: str) -> str:
        """Fix API client usage patterns"""
        # Fix REST usage
        content = re.sub(r'REST\s*\(', 'TradingClient(', content)
        
        # Fix initialization patterns
        patterns = []
            # self.trading_client = TradingClient(...)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret) -> self.trading_client = TradingClient(...)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
            (r'self\.api\s*=\s*REST\s*\(', 'self.trading_client = TradingClient(')
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret),
            (r'self\.api\s*=\s*TradingClient\s*\(', 'self.trading_client = TradingClient(')
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret),
            
            # Add data client after trading client initialization
            (r'(self\.trading_client\s*=\s*TradingClient\([^)]+\))',
             r'\1\n        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)'),
        ]
        
        for pattern, replacement in patterns:
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                self.issues_fixed['api_client'] += 1
        
        # Fix API method calls
        api_replacements = []
            # Trading methods
            (r'self\.api\.get_account\(', 'self.trading_client.get_account('),
            (r'self\.api\.list_positions\(', 'self.trading_client.get_all_positions('),
            (r'self\.api\.get_position\(', 'self.trading_client.get_open_position('),
            (r'self\.api\.list_orders\(', 'self.trading_client.get_orders('),
            (r'self\.api\.submit_order\(', 'self.trading_client.submit_order('),
            (r'self\.api\.cancel_order\(', 'self.trading_client.cancel_order_by_id('),
            (r'self\.api\.cancel_all_orders\(', 'self.trading_client.cancel_orders('),
            
            # Data methods - these should use data_client
            (r'self\.api\.get_bars\(', 'self.data_client.get_stock_bars('),
            (r'self\.api\.get_latest_quote\(', 'self.data_client.get_stock_latest_quote('),
            (r'self\.api\.get_latest_trade\(', 'self.data_client.get_stock_latest_trade('),
            (r'self\.trading_client\.get_bars\(', 'self.data_client.get_stock_bars('),
            (r'self\.trading_client\.get_latest_quote\(', 'self.data_client.get_stock_latest_quote('),
            (r'self\.trading_client\.get_latest_trade\(', 'self.data_client.get_stock_latest_trade('),
            
            # Any remaining self.api references
            (r'self\.api\.', 'self.trading_client.'),
        ]
        
        for pattern, replacement in api_replacements:
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                self.issues_fixed['api_client'] += 1
        
        return content
    
    def fix_method_calls(self, content: str) -> str:
        """Fix method call signatures"""
        # Fix submit_order calls
        # Old: submit_order(order_data=MarketOrderRequest(symbol=..., qty=..., side=..., time_in_force=...))
        # New: submit_order(order_data=MarketOrderRequest(...) or LimitOrderRequest(...))
        
        submit_pattern = r'submit_order\(\s*symbol\s*=\s*([^,]+),\s*qty\s*=\s*([^,]+),\s*side\s*=\s*([^,]+),\s*type\s*=\s*([^,]+),\s*time_in_force\s*=\s*([^,\)]+)[^)]*\)'
        
        def fix_submit_order(match):
            symbol = match.group(1).strip()
            qty = match.group(2).strip()
            side = match.group(3).strip()
            order_type = match.group(4).strip()
            tif = match.group(5).strip()
            
            # Determine order request type
            if 'limit' in order_type.lower():
                # Need to extract limit_price if present
                return f'submit_order(order_data=LimitOrderRequest(symbol={symbol}, qty={qty}, side={side}, time_in_force={tif}, limit_price=price))'
            else:
                return f'submit_order(order_data=MarketOrderRequest(symbol={symbol}, qty={qty}, side={side}, time_in_force={tif}))'
        
        if re.search(submit_pattern, content):
            content = re.sub(submit_pattern, fix_submit_order, content)
            self.issues_fixed['method_calls'] += 1
        
        # Fix get_bars calls
        # Old: get_bars(symbol, timeframe, start=..., end=..., limit=...)
        # New: get_stock_bars(StockBarsRequest(symbol_or_symbols=StockBarsRequest(symbol_or_symbols=..., timeframe=timeframe=..., start=...)))
        
        bars_pattern = r'get_stock_bars\(([^,]+),\s*([^,]+)(?:,\s*start\s*=\s*([^,\)]+))?(?:,\s*end\s*=\s*([^,\)]+))?(?:,\s*limit\s*=\s*([^,\)]+))?\)'
        
        def fix_get_bars(match):
            symbol = match.group(1).strip()
            timeframe = match.group(2).strip()
            start = match.group(3).strip() if match.group(3) else None
            end = match.group(4).strip() if match.group(4) else None
            limit = match.group(5).strip() if match.group(5) else None
            
            params = [f'symbol_or_symbols={symbol}', f'timeframe={timeframe}']
            if start:
                params.append(f'start={start}')
            if end:
                params.append(f'end={end}')
            if limit:
                params.append(f'limit={limit}')
            
            return f'get_stock_bars(StockBarsRequest(symbol_or_symbols=StockBarsRequest({", timeframe=".join(params)})))'
        
        if re.search(bars_pattern, content):
            content = re.sub(bars_pattern, fix_get_bars, content)
            self.issues_fixed['method_calls'] += 1
        
        return content
    
    def fix_broken_syntax(self, content: str) -> str:
        """Fix broken syntax from previous fixes"""
        # Fix double assignments like symbol=symbol=
        content = re.sub(r'symbol_or_symbols=symbol=(\w+)', r'symbol_or_symbols=\1', content)
        content = re.sub(r'timeframe=timeframe=(\w+)', r'timeframe=\1', content)
        
        # Fix broken method definitions
        content = re.sub(r'def fix_get_stock_bars\(StockBarsRequest\(symbol_or_symbols=match\):',
                        'def fix_get_bars(match):', content)
        
        # Fix broken context managers
        content = re.sub(r'@contextmanager\._lock = threading\.Lock\(\)', '', content)
        
        # Fix duplicate lines
        lines = content.split('\n')
        cleaned_lines = []
        prev_line = None
        
        for line in lines:
            # Skip duplicate consecutive lines
            if line.strip() and line == prev_line:
                continue
            cleaned_lines.append(line)
            prev_line = line
        
        return '\n'.join(cleaned_lines)
    
    def add_missing_attributes(self, content: str) -> str:
        """Add missing attribute initializations"""
        # Find __init__ methods and add missing attributes
        init_pattern = r'def __init__\(self[^:]*\):\s*\n'
        
        # Common missing attributes
        missing_attrs = {}
            '_max_drawdown': '0.0',
            '_query_cache': '{}',
            '_last_update': 'None',
            '_performance_metrics': '{}',
            '_risk_metrics': '{}',
            '_cache': '{}',
            '_session': 'None',
            '_lock': 'threading.Lock()'
        }
        
        # Check if attributes are used but not initialized
        for attr, default in missing_attrs.items():
            if f'self.{attr}' in content and f'self.{attr} =' not in content:
                # Find __init__ method
                init_match = re.search(init_pattern, content)
                if init_match:
                    # Add initialization after __init__ definition
                    init_end = init_match.end()
                    # Find the indentation of the first line after __init__
                    lines = content[init_end:].split('\n')
                    for line in lines:
                        if line.strip():
                            indent = len(line) - len(line.lstrip())
                            break
                    else:
                        indent = 8
                    
                    # Insert initialization
                    insertion = f'\n{" " * indent}self.{attr} = {default}'
                    content = content[:init_end] + insertion + content[init_end:]
                    self.issues_fixed['attributes'] += 1
        
        return content
    
    def remove_duplicates(self, content: str) -> str:
        """Remove duplicate definitions"""
        # Remove duplicate enum definitions if they're imported
        if 'from alpaca.trading.enums import' in content:
            # Remove local enum definitions
            enum_patterns = []
                r'class OrderSide\(.*?\):\s*(?:(?!^class).)*?(?=^class|\Z)',
                r'class TimeInForce\(.*?\):\s*(?:(?!^class).)*?(?=^class|\Z)',
                r'class OrderType\(.*?\):\s*(?:(?!^class).)*?(?=^class|\Z)',
                r'class OrderClass\(.*?\):\s*(?:(?!^class).)*?(?=^class|\Z)',
            ]
            
            for pattern in enum_patterns:
                matches = re.finditer(pattern, content, re.MULTILINE | re.DOTALL)
                for match in matches:
                    content = content.replace(match.group(0), '')
                    self.issues_fixed['duplicates'] += 1
        
        return content
    
    def fix_all_files(self, directory: str = '.'):
        """Fix all Python files in directory"""
        # Get all Python files
        python_files = []
        for root, dirs, files in os.walk(directory):
            # Skip virtual environments and system directories
            dirs[:] = [d for d in dirs if d not in ['venv', 'env', '__pycache__', '.git', '.venv']]
            
            for file in files:
                if file.endswith('.py'):
                    python_files.append(os.path.join(root, file))
        
        print(f"Found {len(python_files)} Python files to check...")
        
        fixed_count = 0
        for filepath in python_files:
            if self.fix_file(filepath):
                fixed_count += 1
                print(f"✅ Fixed: {filepath}")
        
        # Summary
        print(f"\n📊 Summary:")
        print(f"   - Files checked: {len(python_files)}")
        print(f"   - Files fixed: {fixed_count}")
        print(f"   - Errors: {len(self.errors)}")
        
        print(f"\n📈 Issues Fixed:")
        for issue_type, count in self.issues_fixed.items():
            if count > 0:
                print(f"   - {issue_type}: {count}")
        
        if self.errors:
            print(f"\n❌ Errors:")
            for error in self.errors[:10]:
                print(f"   - {error}")
        
        # Save report
        report = {}
            'timestamp': datetime.now().isoformat(),
            'files_fixed': len(self.fixed_files),
            'issues_fixed': self.issues_fixed,
            'errors': self.errors
        }
        
        with open('alpaca_import_fixes_report.json', 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n📄 Report saved to: alpaca_import_fixes_report.json")


def main():
    """Main execution function"""
    print("🔧 Alpaca Import and API Fixer")
    print("=" * 50)
    
    fixer = AlpacaImportFixer()
    fixer.fix_all_files('.')
    
    print("\n✅ Fixes completed!")
    print("\n💡 Next steps:")
    print("   1. Install alpaca-py: pip install alpaca-py")
    print("   2. Review the changes")
    print("   3. Run your tests")


if __name__ == "__main__":
    main()