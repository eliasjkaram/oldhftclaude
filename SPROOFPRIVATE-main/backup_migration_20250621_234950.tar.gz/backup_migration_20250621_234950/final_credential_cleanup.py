#!/usr/bin/env python3
"""
Final Credential Cleanup
Removes credentials even from documentation and demo strings
"""

import os
import re
from pathlib import Path

def cleanup_file(filepath: Path) -> bool:
    """Clean up any remaining credential references"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Replace credentials even in print statements and documentation
        replacements = []
            # Alpaca Paper
            ('<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_KEY>'),
            ('<ALPACA_PAPER_KEY>', '<ALPACA_PAPER_KEY>'),  # Another paper key variant
            ('<ALPACA_PAPER_SECRET>', '<ALPACA_PAPER_SECRET>'),
            ('<ALPACA_PAPER_SECRET>', '<ALPACA_PAPER_SECRET>'),  # Another variant
            
            # Alpaca Live
            ('<ALPACA_LIVE_KEY>', '<ALPACA_LIVE_KEY>'),
            ('<ALPACA_LIVE_SECRET>', '<ALPACA_LIVE_SECRET>'),
            
            # MinIO
            ('<MINIO_ACCESS_KEY>', '<MINIO_ACCESS_KEY>'),
            ('<MINIO_SECRET_KEY>', '<MINIO_SECRET_KEY>'),
            ('<MINIO_ROOT_USER>', '<MINIO_ROOT_USER>'),
            ('<MINIO_ROOT_PASSWORD>', '<MINIO_ROOT_PASSWORD>'),
            
            # OpenRouter
            ('<OPENROUTER_KEY>', '<OPENROUTER_KEY>'),
        ]
        
        for old_val, new_val in replacements:
            content = content.replace(old_val, new_val)
        
        # Also fix any remaining patterns in specific files
        if 'options_market_scraper.py' in str(filepath) or 'simple_options_scraper.py' in str(filepath):
            # These files might have example secret patterns
            content = re.sub(r'secret_key\s*=\s*["\'][^"\']+["\']', 'secret_key = os.getenv("API_SECRET")', content)
            
        # Write back if changed
        if content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Cleaned: {filepath}")
            return True
            
    except Exception as e:
        print(f"Error cleaning {filepath}: {e}")
    
    return False

def main():
    """Clean up all remaining credential references"""
    root_dir = Path('/home/harry/alpaca-mcp')
    
    # Files identified by audit
    problem_files = []
        'fix_remaining_credentials.py',
        'system_demo_final.py', 
        'fix_all_credentials.py',
        'options_market_scraper.py',
        'simple_options_scraper.py',
        'production_demo_historical_vs_live.py',
        'test_single_symbol.py',
        'production_test_single_symbol.py',
        'autonomous_trading_engine.py'
    ]
    
    print("🧹 Final credential cleanup...")
    cleaned = 0
    
    # Clean known problem files
    for filename in problem_files:
        filepath = root_dir / filename
        if filepath.exists():
            if cleanup_file(filepath):
                cleaned += 1
    
    # Also scan all Python files one more time
    for py_file in root_dir.rglob('*.py'):
        if any(skip in str(py_file) for skip in ['.git', '__pycache__', 'venv', 'backup']):
            continue
        
        if cleanup_file(py_file):
            cleaned += 1
    
    print(f"\n✅ Cleaned {cleaned} files")
    print("🔒 Final cleanup complete!")

if __name__ == '__main__':
    main()