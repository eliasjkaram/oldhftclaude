#!/usr/bin/env python3
"""
Trading Environment Setup Script
===============================
Configures all necessary components for the integrated trading system
"""

import os
import sys
import subprocess
import json
from datetime import datetime

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


def setup_environment():
    """Setup complete trading environment"""
    
    print("🚀 Setting up Integrated Trading Environment")
    print("=" * 60)
    
    # 1. Check Python dependencies
    print("\n📦 Checking Python Dependencies...")
    required_packages = []
        'pandas', 'numpy', 'yfinance', 'requests', 'tkinter', 
        'threading', 'asyncio', 'pickle', 'datetime'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package} - MISSING")
    
    if missing_packages:
        print(f"\n⚠️  Install missing packages: pip install {' '.join(missing_packages)}")
    
    # 2. Setup environment variables
    print("\n🔧 Environment Variable Setup...")
    
    env_vars = {}
        'ALPACA_API_KEY': 'your_alpaca_api_key_here',
        'ALPACA_SECRET_KEY': 'your_alpaca_secret_key_here', 
        'ALPACA_BASE_URL': 'https://paper-api.alpaca.markets',
        'ALPHA_VANTAGE_KEY': 'optional_alpha_vantage_key'
    }
    
    env_file = '.env'
    if not os.path.exists(env_file):
        with open(env_file, 'w') as f:
            f.write("# Trading System Environment Variables\n")
            f.write(f"# Generated: {datetime.now()}\n\n")
            for key, value in env_vars.items():
                f.write(f"{key}={value}\n")
        print(f"✅ Created {env_file} with template variables")
    else:
        print(f"✅ {env_file} already exists")
    
    # 3. Create directories
    print("\n📁 Creating Directory Structure...")
    
    directories = []
        'logs', 'data', 'cache', 'config', 'strategies', 'reports'
    ]
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"✅ Created {directory}/")
        else:
            print(f"✅ {directory}/ exists")
    
    # 4. Create configuration files
    print("\n⚙️  Creating Configuration Files...")
    
    # Algorithm configuration
    algo_config = {}
        "algorithms": {}
            "technical_analysis": {}
                "enabled": True,
                "weight": 0.3,
                "parameters": {}
                    "sma_periods": [20, 50, 200],
                    "rsi_period": 14,
                    "momentum_periods": [5, 10, 20]
                }
            },
            "ml_pattern_recognition": {}
                "enabled": True,
                "weight": 0.3,
                "parameters": {}
                    "confidence_threshold": 0.6,
                    "pattern_window": 20,
                    "volatility_window": 30
                }
            },
            "volatility_forecasting": {}
                "enabled": True,
                "weight": 0.2,
                "parameters": {}
                    "garch_window": 60,
                    "decay_factor": 0.94
                }
            },
            "sentiment_analysis": {}
                "enabled": True,
                "weight": 0.2,
                "parameters": {}
                    "persistence_factor": 0.7,
                    "confidence_decay": 0.02
                }
            }
        },
        "risk_management": {}
            "max_position_size": 0.05,
            "max_portfolio_risk": 0.20,
            "volatility_limit": 0.40,
            "correlation_limit": 0.70
        },
        "execution": {}
            "auto_execute": False,
            "confirmation_required": True,
            "max_slippage": 0.02,
            "order_timeout": 300
        }
    }
    
    config_file = 'config/algorithm_config.json'
    if not os.path.exists(config_file):
        with open(config_file, 'w') as f:
            json.dump(algo_config, f, indent=2)
        print(f"✅ Created {config_file}")
    else:
        print(f"✅ {config_file} exists")
    
    # Trading system config
    trading_config = {}
        "data_sources": {}
            "primary": "yfinance",
            "secondary": "alpha_vantage",
            "fallback": "synthetic",
            "cache_duration": 6,
            "retry_attempts": 3
        },
        "symbols": {}
            "watchlist": ["SPY", "QQQ", "IWM", "TLT", "AAPL", "MSFT", "GOOGL"],
            "blacklist": [],
            "auto_scan": True,
            "scan_interval": 300
        },
        "strategies": {}
            "long_calls": {"enabled": True, "max_risk": 0.03},
            "bull_spreads": {"enabled": True, "max_risk": 0.02},
            "iron_condors": {"enabled": True, "max_risk": 0.01},
            "arbitrage": {"enabled": True, "max_risk": 0.05}
        },
        "notifications": {}
            "email": False,
            "console": True,
            "log_level": "INFO"
        }
    }
    
    trading_config_file = 'config/trading_config.json'
    if not os.path.exists(trading_config_file):
        with open(trading_config_file, 'w') as f:
            json.dump(trading_config, f, indent=2)
        print(f"✅ Created {trading_config_file}")
    else:
        print(f"✅ {trading_config_file} exists")
    
    # 5. Check existing trading engine
    print("\n🤖 Checking Trading Engine Status...")
    
    if os.path.exists('logs/trading_engine.log'):
        with open('logs/trading_engine.log', 'r') as f:
            lines = f.readlines()
            if lines:
                last_line = lines[-1].strip()
                if 'trading cycle' in last_line:
                    print("✅ Trading Engine: RUNNING")
                    print(f"   Last Activity: {last_line}")
                else:
                    print("⚠️  Trading Engine: STATUS UNKNOWN")
            else:
                print("⚠️  Trading Engine: NO ACTIVITY")
    else:
        print("❌ Trading Engine: NOT STARTED")
    
    # 6. Create startup script
    print("\n🚀 Creating Startup Scripts...")
    
    startup_script = '''#!/bin/bash
# Integrated Trading System Startup Script

echo "🚀 Starting Integrated Trading System..."

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
    echo "✅ Environment variables loaded"
fi

# Start trading engine in background (if not running)
if ! pgrep -f "python.*trading_engine.py" > /dev/null; then
    echo "🤖 Starting trading engine..."
    nohup python enhanced_continuous_perfection_system.py > logs/engine_startup.log 2>&1 &
    echo "✅ Trading engine started"
else
    echo "✅ Trading engine already running"
fi

# Start main trading GUI
echo "🎯 Starting integrated trading system..."
python integrated_trading_system.py

echo "👋 Trading system shutdown complete"
'''
    
    with open('start_trading_system.sh', 'w') as f:
        f.write(startup_script)
    
    # Make executable
    os.chmod('start_trading_system.sh', 0o755)
    print("✅ Created start_trading_system.sh")
    
    # 7. Create demo script
    demo_script = '''#!/usr/bin/env python3
"""
Trading System Demo
===================
Demonstrates all features without real trading
"""

import os
import sys

def run_demo():
    print("🎯 INTEGRATED TRADING SYSTEM DEMO")
    print("=" * 50)
    print()
    print("Available Demo Components:")
    print("1. 📊 Universal Symbol Analysis")
    print("2. 🤖 Algorithm Dashboard") 
    print("3. ⚡ Trade Execution Interface")
    print("4. 📈 Specific Ticker Recommendations")
    print("5. 🎨 Enhanced Trading Analyzer")
    print()
    
    while True:
        choice = input("Select demo (1-5) or 'q' to quit: ").strip()
        
        if choice == 'q':
            break
        elif choice == '1':
            os.system('python integrated_trading_system.py')
        elif choice == '2':
            print("Algorithm Dashboard integrated in main system")
            os.system('python integrated_trading_system.py')
        elif choice == '3':
            print("Trade Execution integrated in main system")
            os.system('python integrated_trading_system.py')
        elif choice == '4':
            os.system('python specific_ticker_demo.py')
        elif choice == '5':
            os.system('python enhanced_trading_analyzer.py')
        else:
            print("Invalid choice. Please select 1-5 or 'q'")

if __name__ == "__main__":
    run_demo()
'''
    
    with open('trading_system_demo.py', 'w') as f:
        f.write(demo_script)
    
    print("✅ Created trading_system_demo.py")
    
    # 8. Final status
    print("\n" + "=" * 60)
    print("✅ SETUP COMPLETE!")
    print("=" * 60)
    print()
    print("🚀 TO START TRADING SYSTEM:")
    print("   ./start_trading_system.sh")
    print()
    print("🎯 TO RUN DEMO:")
    print("   python trading_system_demo.py")
    print()
    print("⚙️  TO CONFIGURE:")
    print("   1. Edit .env with your API keys")
    print("   2. Modify config/algorithm_config.json")
    print("   3. Adjust config/trading_config.json")
    print()
    print("📊 CURRENT STATUS:")
    print(f"   - Trading Engine: {'RUNNING' if os.path.exists('logs/trading_engine.log') else 'STOPPED'}")
    print(f"   - Algorithms: 35+ available")
    print(f"   - Data Sources: Universal support")
    print(f"   - API Integration: Alpaca ready")
    print()
    print("🎉 Ready for algorithmic trading!")

if __name__ == "__main__":
    setup_environment()