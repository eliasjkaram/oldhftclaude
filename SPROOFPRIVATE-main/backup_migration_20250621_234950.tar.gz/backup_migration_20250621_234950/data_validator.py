
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Data Validator
Comprehensive validation for all financial data
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import numpy as np
import pandas as pd
from typing import Optional, Dict, Any, List, Union
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class DataValidator:
    """Validate all financial data inputs"""
    
    def __init__(self):
        self.validation_stats = {}
            'total_validations': 0,
            'passed': 0,
            'failed': 0,
            'warnings': 0
        }
        
    def validate_ohlcv(self, data: pd.DataFrame) -> pd.DataFrame:
        """Validate OHLCV data"""
        self.validation_stats['total_validations'] += 1
        
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        
        # Check required columns
        missing_cols = set(required_columns) - set(data.columns)
        if missing_cols:
            logger.error(f"Missing required columns: {missing_cols}")
            self.validation_stats['failed'] += 1
            raise ValueError(f"Missing columns: {missing_cols}")
            
        # Validate OHLC relationships
        invalid_ohlc = ()
            (data['high'] < data['low']) |
            (data['high'] < data['open']) |
            (data['high'] < data['close']) |
            (data['low'] > data['open']) |
            (data['low'] > data['close'])
        )
        
        if invalid_ohlc.any():
            logger.warning(f"Found {invalid_ohlc.sum()} invalid OHLC relationships")
            self.validation_stats['warnings'] += 1
            # Fix invalid relationships
            data.loc[invalid_ohlc, 'high'] = data.loc[invalid_ohlc, ['open', 'close', 'high']].max(axis=1)
            data.loc[invalid_ohlc, 'low'] = data.loc[invalid_ohlc, ['open', 'close', 'low']].min(axis=1)
            
        # Validate prices
        for col in ['open', 'high', 'low', 'close']:
            # Check for negative prices
            negative_mask = data[col] < 0
            if negative_mask.any():
                logger.warning(f"Found {negative_mask.sum()} negative values in {col}")
                data.loc[negative_mask, col] = np.nan
                
            # Check for extreme values
            mean_price = data[col].mean()
            std_price = data[col].std()
            extreme_mask = np.abs(data[col] - mean_price) > (10 * std_price)
            if extreme_mask.any():
                logger.warning(f"Found {extreme_mask.sum()} extreme values in {col}")
                self.validation_stats['warnings'] += 1
                
        # Validate volume
        negative_volume = data['volume'] < 0
        if negative_volume.any():
            logger.warning(f"Found {negative_volume.sum()} negative volumes")
            data.loc[negative_volume, 'volume'] = 0
            
        # Fill NaN values
        data = data.fillna(method='ffill').fillna(method='bfill')
        
        self.validation_stats['passed'] += 1
        return data
        
    def validate_position_size(self, size: float, symbol: str, 
                             account_value: float, max_position_pct: float = 0.1) -> float:
        """Validate and adjust position size"""
        if size <= 0:
            logger.error(f"Invalid position size {size} for {symbol}")
            return 0
            
        max_position = account_value * max_position_pct
        if size > max_position:
            logger.warning(f"Position size {size} exceeds max {max_position} for {symbol}")
            return max_position
            
        return size
        
    def validate_order_params(self, order_params: Dict[str, Any]) -> bool:
        """Validate order parameters"""
        required_fields = ['symbol', 'qty', 'side', 'type']
        
        # Check required fields
        for field in required_fields:
            if field not in order_params or order_params[field] is None:
                logger.error(f"Missing required order field: {field}")
                return False
                
        # Validate quantity
        qty = order_params.get('qty', 0)
        if not isinstance(qty, (int, float)) or qty <= 0:
            logger.error(f"Invalid order quantity: {qty}")
            return False
            
        # Validate side
        if order_params['side'] not in ['buy', 'sell']:
            logger.error(f"Invalid order side: {order_params['side']}")
            return False
            
        # Validate order type
        valid_types = ['market', 'limit', 'stop', 'stop_limit', 'trailing_stop']
        if order_params['type'] not in valid_types:
            logger.error(f"Invalid order type: {order_params['type']}")
            return False
            
        # Validate limit price if limit order
        if order_params['type'] in ['limit', 'stop_limit']:
            limit_price = order_params.get('limit_price')
            if not isinstance(limit_price, (int, float)) or limit_price <= 0:
                logger.error(f"Invalid limit price: {limit_price}")
                return False
                
        return True
        
    def validate_symbol(self, symbol: str) -> bool:
        """Validate trading symbol format"""
        if not symbol or not isinstance(symbol, str):
            return False
            
        # Basic validation - can be expanded
        if len(symbol) > 10 or len(symbol) < 1:
            return False
            
        # Check for valid characters
        import re
        if not re.match(r'^[A-Z0-9\-\.]+$', symbol):
            return False
            
        return True
        
    def get_validation_report(self) -> Dict[str, Any]:
        """Get validation statistics"""
        return {}
            'stats': self.validation_stats,
            'success_rate': self.validation_stats['passed'] / max(self.validation_stats['total_validations'], 1),
            'warning_rate': self.validation_stats['warnings'] / max(self.validation_stats['total_validations'], 1)
        }

# Global validator instance
data_validator = DataValidator()
