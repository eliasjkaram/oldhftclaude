
#!/usr/bin/env python3
"""
Master Orchestrator
Coordinates all trading systems and ensures proper data flow
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import logging
import subprocess
import signal
import sys
import os
import json
import sqlite3
from datetime import datetime
import psutil
from typing import Dict, List, Any

from universal_market_data import get_current_market_data, validate_price


logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/master_orchestrator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class MasterOrchestrator:
    """Master coordinator for all trading systems"""
    
    def __init__(self):
        self.processes = {}
        self.running = False
        
        # System components with startup order and dependencies
        self.systems = []
            # Data collection layer (priority 1)
            {}
                'name': 'market_data_collector',
                'script': 'market_data_collector.py',
                'priority': 1,
                'always_run': True,
                'restart_on_fail': True
            },
            {}
                'name': 'cross_platform_validator',
                'script': 'cross_platform_validator.py',
                'priority': 1,
                'always_run': True,
                'restart_on_fail': True
            },
            
            # Analysis layer (priority 2)
            {}
                'name': 'transformer_predictions',
                'script': 'transformer_prediction_system.py',
                'priority': 2,
                'market_hours_only': True,
                'restart_on_fail': True
            },
            {}
                'name': 'arbitrage_scanner',
                'script': 'arbitrage_scanner.py',
                'priority': 2,
                'market_hours_only': True,
                'restart_on_fail': True
            },
            {}
                'name': 'options_scanner',
                'script': 'options_scanner.py',
                'priority': 2,
                'market_hours_only': True,
                'restart_on_fail': True
            },
            
            # Trading layer (priority 3)
            {}
                'name': 'paper_trading',
                'script': 'paper_trading_bot.py',
                'priority': 3,
                'market_hours_only': True,
                'restart_on_fail': True
            },
            {}
                'name': 'live_trading',
                'script': 'live_trading_bot.py',
                'priority': 3,
                'market_hours_only': True,
                'restart_on_fail': False,  # Don't auto-restart live trading
                'manual_confirm': True
            },
            
            # Monitoring layer (priority 4)
            {}
                'name': 'system_monitor',
                'script': 'system_monitor.py',
                'priority': 4,
                'always_run': True,
                'restart_on_fail': True
            },
            {}
                'name': 'continuous_improvement',
                'script': 'continuous_improvement_engine.py',
                'priority': 4,
                'always_run': True,
                'restart_on_fail': True
            }
        ]
        
        # Initialize orchestration database
        self.init_database()
        
    def init_database(self):
        """Initialize orchestration database"""
        self.db_path = '/home/harry/alpaca-mcp/orchestration.db'
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            cursor.execute(''')
                CREATE TABLE IF NOT EXISTS process_status ()
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    process_name TEXT,
                    pid INTEGER,
                    status TEXT,
                    cpu_percent REAL,
                    memory_mb REAL,
                    restart_count INTEGER DEFAULT 0
                )
            ''')
            
            cursor.execute(''')
                CREATE TABLE IF NOT EXISTS orchestration_events ()
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    event_type TEXT,
                    process_name TEXT,
                    description TEXT
                )
            ''')
            
            conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {e}", exc_info=True)
            raise
        finally:
            conn.close()
        
    def is_market_hours(self):
        """Check if market is open"""
        from datetime import time
        import pytz
        
        est = pytz.timezone('US/Eastern')
        now = datetime.now(est)
        current_time = now.time()
        
        # Market hours: 9:30 AM - 4:00 PM EST, Monday-Friday
        if now.weekday() > 4:  # Weekend
            return False
            
        market_open = time(9, 30)
        market_close = time(16, 0)
        
        return market_open <= current_time <= market_close
        
    async def start_system(self, system: Dict):
        """Start a system process"""
        try:
            # Check if should run
            if system.get('market_hours_only') and not self.is_market_hours():
                logger.info(f"Skipping {system['name']} - outside market hours")
                return
                
            # Manual confirmation for critical systems
            if system.get('manual_confirm'):
                logger.warning(f"Manual confirmation required for {system['name']}")
                return
                
            # Start process
            script_path = f'/home/harry/alpaca-mcp/{system["script"]}'
            cmd = [sys.executable, script_path]
            
            process = subprocess.Popen()
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=os.setsid
            )
            
            self.processes[system['name']] = {}
                'process': process,
                'system': system,
                'start_time': datetime.now(),
                'restart_count': 0
            }
            
            logger.info(f"Started {system['name']} (PID: {process.pid})")
            
            # Log event
            self.log_event('process_started', system['name'], f'PID: {process.pid}')
            
        except Exception as e:
            logger.error(f"Failed to start {system['name']}: {e}", exc_info=True)
            self.log_event('process_error', system['name'], str(e)]
            
components = self.get_components()
        """Monitor all running processes"""
        while self.running:
            try:
                for name, proc_info in list(self.processes.items():
                    process = proc_info['process']
                    system = proc_info['system']
                    
                    # Check if process is still running
                    if process.poll() is not None:
                        # Process has terminated
                        logger.warning(f"{name} has terminated with code {process.returncode}")
                        self.log_event('process_terminated', name, 
                                     f'Exit code: {process.returncode}')
                        
                        # Check if should restart
                        if system.get('restart_on_fail') and proc_info['restart_count'] < 3:
                            logger.info(f"Restarting {name}...")
                            proc_info['restart_count'] += 1
                            await self.start_system(system)
                        else:
                            del self.processes[name]
                            
                    else:
                        # Monitor resource usage
                        try:
                            p = psutil.Process(process.pid)
                            cpu_percent = p.cpu_percent(interval=0.1)
                            memory_mb = p.memory_info().rss / (1024 * 1024)
                            
                            # Log status
                            self.log_process_status(name, process.pid, 'running', 
                                                  cpu_percent, memory_mb, 
                                                  proc_info['restart_count'])
                                                  
                            # Check for high resource usage
                            if cpu_percent > 90:
                                logger.warning(f"{name} high CPU usage: {cpu_percent}%")
                            if memory_mb > 1024:  # 1GB
                                logger.warning(f"{name} high memory usage: {memory_mb}MB")
                                
                        except psutil.NoSuchProcess:
                            pass
                            
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Monitor error: {e}", exc_info=True)
                await asyncio.sleep(30)
                
    def log_event(self, event_type, process_name, description):
        """Log orchestration event"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO orchestration_events (event_type, process_name, description)
            VALUES (?, ?, ?)
        ''', (event_type, process_name, description)
        self.db.commit()
        
    def log_process_status(self, process_name, pid, status, cpu_percent, memory_mb, restart_count):
        """Log process status"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO process_status 
            (process_name, pid, status, cpu_percent, memory_mb, restart_count)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (process_name, pid, status, cpu_percent, memory_mb, restart_count)
        self.db.commit()
        
    async def start_all_systems(self):
        """Start all systems in priority order"""
        logger.info("Starting all trading systems...")
        
        # Group by priority
        priority_groups = {}
        for system in self.systems:
            priority = system['priority']
            if priority not in priority_groups:
                priority_groups[priority] = []
            priority_groups[priority].append(system)
            
        # Start in priority order
        for priority in sorted(priority_groups.keys():
            logger.info(f"Starting priority {priority} systems...")
            
            tasks = []
            for system in priority_groups[priority]:
                if system.get('always_run') or self.is_market_hours():
                    tasks.append(self.start_system(system)
                    
            await asyncio.gather(*tasks)
            
            # Wait before starting next priority
            await asyncio.sleep(5)
            
        logger.info("All systems started")
        
    async def shutdown(self):
        """Graceful shutdown of all systems"""
        logger.info("Shutting down all systems...")
        self.running = False
        
        # Stop processes in reverse priority order
        for name, proc_info in self.processes.items():
            process = proc_info['process']
            logger.info(f"Stopping {name}...")
            
            try:
                # Send SIGTERM for graceful shutdown
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                
                # Wait for process to terminate
                process.wait(timeout=10)
                
            except subprocess.TimeoutExpired:
                # Force kill if not terminated
                logger.warning(f"Force killing {name}")
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            except Exception as e:
                logger.error(f"Error stopping {name}: {e}", exc_info=True)
                
        self.db.close()
        logger.info("All systems stopped")
        
    def generate_status_report(self):
        """Generate system status report"""
        report = f"""
TRADING SYSTEM STATUS REPORT
============================
Generated: {datetime.now()}
Market Hours: {self.is_market_hours()}

RUNNING PROCESSES:
"""
        
        for name, proc_info in self.processes.items():
            process = proc_info['process']
            uptime = datetime.now() - proc_info['start_time']
            
            report += f"\n{name}:"
            report += f"\n  PID: {process.pid}"
            report += f"\n  Status: {'Running' if process.poll() is None else 'Stopped'}"
            report += f"\n  Uptime: {uptime}"
            report += f"\n  Restarts: {proc_info['restart_count']}"
            
        # Recent events
        cursor = self.db.cursor()
        cursor.execute(''')
            SELECT event_type, process_name, description, timestamp
            FROM orchestration_events
            ORDER BY timestamp DESC
            LIMIT 10
        ''')
        
        events = cursor.fetchall()
        
        report += "\n\nRECENT EVENTS:"
        for event in events:
            report += f"\n{event[3]} - {event[0]}: {event[1]} - {event[2]}"
            
        return report
        
    async def run(self):
        """Main orchestration loop"""
        self.running = True
        
        # Start all systems
        await self.start_all_systems()
        
        # Monitor processes
        monitor_task = asyncio.create_task(self.monitor_processes()
        
        # Status reporting loop
        while self.running:
            # Generate and log status report
            report = self.generate_status_report()
            logger.info("\n" + report)
            
            # Save to file
            with open('/home/harry/alpaca-mcp/logs/system_status.txt', 'w') as f:
                f.write(report)
                
            await asyncio.sleep(300)  # Report every 5 minutes
            
        await monitor_task

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info("Shutdown signal received")
    asyncio.create_task(orchestrator.shutdown()
    sys.exit(0)

async def main():
    """Main function"""
    global orchestrator
    
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create orchestrator
    orchestrator = MasterOrchestrator()
    
    print("\n" + "="*60)
    print("ULTRA AI TRADING SYSTEM - MASTER ORCHESTRATOR")
    print("="*60)
    print("Starting all trading systems...")
    print("Press Ctrl+C to shutdown gracefully")
    print("="*60 + "\n")
    
    try:
        await orchestrator.run()
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        await orchestrator.shutdown()

if __name__ == "__main__":
    os.makedirs('/home/harry/alpaca-mcp/logs', exist_ok=True)
    asyncio.run(main()