"""
Multi-Task Learning Framework for Options Pricing and Greeks Prediction
Jointly learns option prices and all Greeks with shared representations
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass, field
try:
    import wandb
except ImportError:
    wandb = None
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class MultiTaskConfig:
    """Configuration for multi-task learning framework"""
    # Architecture
    shared_hidden_dims: List[int] = field(default_factory=lambda: [512, 256, 128])
    task_specific_dims: Dict[str, List[int]] = field(default_factory=lambda: {)
        'price': [64, 32],
        'delta': [64, 32],
        'gamma': [64, 32],
        'vega': [64, 32],
        'theta': [64, 32],
        'rho': [64, 32]
    })
    
    # Task weights (for loss balancing)
    task_weights: Dict[str, float] = field(default_factory=lambda: {)
        'price': 1.0,
        'delta': 0.5,
        'gamma': 0.3,
        'vega': 0.4,
        'theta': 0.4,
        'rho': 0.3
    })
    
    # Dynamic weight adjustment
    use_dynamic_weights: bool = True
    weight_update_frequency: int = 10
    weight_learning_rate: float = 0.01
    
    # Training
    learning_rate: float = 1e-3
    batch_size: int = 128
    epochs: int = 100
    gradient_clip: float = 1.0
    dropout_rate: float = 0.2
    
    # Regularization
    l2_weight: float = 1e-5
    gradient_penalty: float = 0.1
    
    # Auxiliary tasks
    use_auxiliary_tasks: bool = True
    auxiliary_tasks: List[str] = field(default_factory=lambda: ['moneyness', 'time_value'])


class SharedEncoder(nn.Module):
    """Shared encoder for all tasks"""
    
    def __init__(self, input_dim: int, hidden_dims: List[int], dropout_rate: float):
        super().__init__()
        
        layers = []
        prev_dim = input_dim
        
        for i, hidden_dim in enumerate(hidden_dims):
            layers.extend([)
                nn.Linear(prev_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_dim = hidden_dim
            
        self.encoder = nn.Sequential(*layers)
        self.output_dim = hidden_dims[-1]
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)


class TaskHead(nn.Module):
    """Task-specific head for each output"""
    
    def __init__(self, input_dim: int, hidden_dims: List[int], output_dim: int, 
                 dropout_rate: float, task_name: str):
        super().__init__()
        self.task_name = task_name
        
        layers = []
        prev_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([)
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_dim = hidden_dim
            
        layers.append(nn.Linear(prev_dim, output_dim))
        
        self.head = nn.Sequential(*layers)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(x)


class GradientReversalLayer(nn.Module):
    """Gradient reversal layer for adversarial training"""
    
    def __init__(self, alpha: float = 1.0):
        super().__init__()
        self.alpha = alpha
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return GradientReversalFunction.apply(x, self.alpha)


class GradientReversalFunction(torch.autograd.Function):
    """Gradient reversal function"""
    
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)
        
    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.alpha, None


class MultiTaskLearningModel(nn.Module):
    """Multi-task learning model for options pricing"""
    
    def __init__(self, input_dim: int, config: MultiTaskConfig):
        super().__init__()
        self.config = config
        self.tasks = ['price', 'delta', 'gamma', 'vega', 'theta', 'rho']
        
        # Shared encoder
        self.shared_encoder = SharedEncoder()
            input_dim, 
            config.shared_hidden_dims,
            config.dropout_rate
        )
        
        # Task-specific heads
        self.task_heads = nn.ModuleDict()
        for task in self.tasks:
            self.task_heads[task] = TaskHead()
                self.shared_encoder.output_dim,
                config.task_specific_dims.get(task, [64, 32]),
                1,  # Single output per task
                config.dropout_rate,
                task
            )
            
        # Auxiliary task heads
        if config.use_auxiliary_tasks:
            self.aux_heads = nn.ModuleDict()
            
            # Moneyness classifier (ITM/ATM/OTM)
            self.aux_heads['moneyness'] = TaskHead()
                self.shared_encoder.output_dim,
                [32, 16],
                3,  # 3 classes
                config.dropout_rate,
                'moneyness'
            )
            
            # Time value predictor
            self.aux_heads['time_value'] = TaskHead()
                self.shared_encoder.output_dim,
                [32, 16],
                1,
                config.dropout_rate,
                'time_value'
            )
            
        # Uncertainty estimation heads
        self.uncertainty_heads = nn.ModuleDict()
        for task in self.tasks:
            self.uncertainty_heads[task] = nn.Sequential()
                nn.Linear(self.shared_encoder.output_dim, 32),
                nn.ReLU(),
                nn.Linear(32, 1)
            )
            
        # Task relationship modeling
        self.task_attention = nn.MultiheadAttention()
            embed_dim=len(self.tasks),
            num_heads=2,
            dropout=config.dropout_rate
        )
        
        # Dynamic weight parameters
        if config.use_dynamic_weights:
            self.log_task_weights = nn.Parameter()
                torch.log(torch.tensor([config.task_weights[task] for task in self.tasks]))
            )
            
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Forward pass through multi-task model"""
        # Shared encoding
        shared_features = self.shared_encoder(x)
        
        # Task predictions
        outputs = {}
        task_embeddings = []
        
        for task in self.tasks:
            # Main prediction
            prediction = self.task_heads[task](shared_features)
            outputs[f'{task}_prediction'] = prediction
            
            # Uncertainty estimation
            log_variance = self.uncertainty_heads[task](shared_features)
            outputs[f'{task}_log_variance'] = log_variance
            outputs[f'{task}_uncertainty'] = torch.exp(0.5 * log_variance)
            
            task_embeddings.append(prediction)
            
        # Task attention for relationship modeling
        task_tensor = torch.stack(task_embeddings, dim=1)  # [batch, n_tasks, 1]
        task_tensor = task_tensor.squeeze(-1).unsqueeze(0)  # [1, batch, n_tasks]
        
        attended_tasks, task_attention_weights = self.task_attention()
            task_tensor, task_tensor, task_tensor
        )
        outputs['task_attention'] = task_attention_weights
        
        # Auxiliary tasks
        if self.config.use_auxiliary_tasks:
            # Moneyness classification
            outputs['moneyness_logits'] = self.aux_heads['moneyness'](shared_features)
            
            # Time value prediction
            outputs['time_value_prediction'] = self.aux_heads['time_value'](shared_features)
            
        outputs['shared_features'] = shared_features
        
        return outputs
        
    def get_task_weights(self) -> torch.Tensor:
        """Get current task weights"""
        if self.config.use_dynamic_weights:
            return F.softmax(self.log_task_weights, dim=0) * len(self.tasks)
        else:
            return torch.tensor([self.config.task_weights[task] for task in self.tasks])


class MultiTaskLoss(nn.Module):
    """Multi-task loss function with uncertainty weighting"""
    
    def __init__(self, config: MultiTaskConfig):
        super().__init__()
        self.config = config
        self.tasks = ['price', 'delta', 'gamma', 'vega', 'theta', 'rho']
        
        # Task-specific loss functions
        self.task_losses = {}
            'price': nn.SmoothL1Loss(reduction='none'),
            'delta': nn.MSELoss(reduction='none'),
            'gamma': nn.MSELoss(reduction='none'),
            'vega': nn.MSELoss(reduction='none'),
            'theta': nn.MSELoss(reduction='none'),
            'rho': nn.MSELoss(reduction='none')
        }
        
        # Auxiliary task losses
        self.moneyness_loss = nn.CrossEntropyLoss()
        self.time_value_loss = nn.MSELoss()
        
    def forward(self, outputs: Dict[str, torch.Tensor], targets: Dict[str, torch.Tensor],
                model: MultiTaskLearningModel) -> Dict[str, torch.Tensor]:
        """Calculate multi-task loss"""
        losses = {}
        
        # Get task weights
        task_weights = model.get_task_weights()
        
        # Main task losses with uncertainty weighting
        total_loss = 0
        for i, task in enumerate(self.tasks):
            if f'{task}_target' in targets:
                prediction = outputs[f'{task}_prediction']
                target = targets[f'{task}_target']
                log_variance = outputs[f'{task}_log_variance']
                
                # Heteroscedastic uncertainty weighting
                task_loss = self.task_losses[task](prediction, target)
                weighted_loss = 0.5 * torch.exp(-log_variance) * task_loss + 0.5 * log_variance
                weighted_loss = weighted_loss.mean()
                
                # Apply task weight
                if self.config.use_dynamic_weights:
                    final_loss = task_weights[i] * weighted_loss
                else:
                    final_loss = self.config.task_weights[task] * weighted_loss
                    
                losses[f'{task}_loss'] = weighted_loss.item()
                total_loss += final_loss
                
        # Auxiliary task losses
        if self.config.use_auxiliary_tasks:
            # Moneyness classification
            if 'moneyness_target' in targets:
                moneyness_loss = self.moneyness_loss()
                    outputs['moneyness_logits'], 
                    targets['moneyness_target']
                )
                losses['moneyness_loss'] = moneyness_loss.item()
                total_loss += 0.1 * moneyness_loss
                
            # Time value prediction
            if 'time_value_target' in targets:
                time_value_loss = self.time_value_loss()
                    outputs['time_value_prediction'],
                    targets['time_value_target']
                )
                losses['time_value_loss'] = time_value_loss.item()
                total_loss += 0.1 * time_value_loss
                
        # Gradient penalty for smoothness
        if self.config.gradient_penalty > 0:
            grad_penalty = self._gradient_penalty(outputs, targets)
            losses['gradient_penalty'] = grad_penalty.item()
            total_loss += self.config.gradient_penalty * grad_penalty
            
        losses['total_loss'] = total_loss.item()
        
        return total_loss, losses
        
    def _gradient_penalty(self, outputs: Dict[str, torch.Tensor], 
                         targets: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Calculate gradient penalty for smooth predictions"""
        penalty = 0
        
        for task in self.tasks:
            if f'{task}_prediction' in outputs and outputs[f'{task}_prediction'].requires_grad:
                pred = outputs[f'{task}_prediction']
                grad = torch.autograd.grad()
                    pred.sum(), outputs['shared_features'],
                    create_graph=True, retain_graph=True
                )[0]
                penalty += (grad.norm(2, dim=1) ** 2).mean()
                
        return penalty / len(self.tasks)


class MultiTaskDataset(Dataset):
    """Dataset for multi-task learning"""
    
    def __init__(self, features: np.ndarray, targets: Dict[str, np.ndarray]):
        self.features = torch.FloatTensor(features)
        self.targets = {k: torch.FloatTensor(v) for k, v in targets.items()}
        
        # Calculate auxiliary targets
        if 'price_target' in targets and 'spot' in features:
            # Moneyness classification
            spot_idx = 0  # Assuming spot is first feature
            strike_idx = 1  # Assuming strike is second feature
            
            moneyness = features[:, spot_idx] / features[:, strike_idx]
            moneyness_classes = np.zeros(len(features), dtype=np.long)
            moneyness_classes[moneyness < 0.95] = 0  # OTM
            moneyness_classes[(moneyness >= 0.95) & (moneyness <= 1.05)] = 1  # ATM
            moneyness_classes[moneyness > 1.05] = 2  # ITM
            
            self.targets['moneyness_target'] = torch.LongTensor(moneyness_classes)
            
            # Time value (option price - intrinsic value)
            intrinsic = np.maximum(features[:, spot_idx] - features[:, strike_idx], 0)
            time_value = targets['price_target'] - intrinsic
            self.targets['time_value_target'] = torch.FloatTensor(time_value)
            
    def __len__(self):
        return len(self.features)
        
    def __getitem__(self, idx):
        sample = {'features': self.features[idx]}
        for key, values in self.targets.items():
            sample[key] = values[idx]
        return sample


class MultiTaskTrainer:
    """Trainer for multi-task learning model"""
    
    def __init__(self, model: MultiTaskLearningModel, config: MultiTaskConfig):
        self.model = model
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        # Optimizer
        self.optimizer = torch.optim.AdamW()
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.l2_weight
        )
        
        # Learning rate scheduler
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts()
            self.optimizer, T_0=20, T_mult=2
        )
        
        # Loss function
        self.loss_fn = MultiTaskLoss(config)
        
        # Metrics tracking
        self.train_history = []
        self.val_history = []
        self.task_weight_history = []
        
    def train_epoch(self, train_loader: DataLoader) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        epoch_losses = {}
        
        for batch_idx, batch in enumerate(train_loader):
            # Move to device
            features = batch['features'].to(self.device)
            targets = {k: v.to(self.device) for k, v in batch.items() if k != 'features'}
            
            # Forward pass
            outputs = self.model(features)
            
            # Calculate loss
            loss, losses_dict = self.loss_fn(outputs, targets, self.model)
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.gradient_clip)
            
            self.optimizer.step()
            
            # Accumulate losses
            for key, value in losses_dict.items():
                if key not in epoch_losses:
                    epoch_losses[key] = 0
                epoch_losses[key] += value
                
        # Average losses
        num_batches = len(train_loader)
        for key in epoch_losses:
            epoch_losses[key] /= num_batches
            
        return epoch_losses
        
    def validate(self, val_loader: DataLoader) -> Dict[str, float]:
        """Validate model"""
        self.model.eval()
        metrics = {}
        predictions = {task: [] for task in self.model.tasks}
        actuals = {task: [] for task in self.model.tasks}
        
        with torch.no_grad():
            for batch in val_loader:
                features = batch['features'].to(self.device)
                targets = {k: v.to(self.device) for k, v in batch.items() if k != 'features'}
                
                outputs = self.model(features)
                
                # Collect predictions
                for task in self.model.tasks:
                    if f'{task}_target' in targets:
                        predictions[task].extend()
                            outputs[f'{task}_prediction'].cpu().numpy()
                        )
                        actuals[task].extend()
                            targets[f'{task}_target'].cpu().numpy()
                        )
                        
        # Calculate metrics for each task
        for task in self.model.tasks:
            if predictions[task]:
                pred_array = np.array(predictions[task]).flatten()
                actual_array = np.array(actuals[task]).flatten()
                
                mse = np.mean((pred_array - actual_array) ** 2)
                mae = np.mean(np.abs(pred_array - actual_array))
                rmse = np.sqrt(mse)
                
                # Relative error for non-zero targets
                mask = actual_array != 0
                if mask.sum() > 0:
                    mape = np.mean(np.abs((actual_array[mask] - pred_array[mask]) / actual_array[mask])) * 100
                else:
                    mape = 0
                    
                metrics[f'{task}_rmse'] = rmse
                metrics[f'{task}_mae'] = mae
                metrics[f'{task}_mape'] = mape
                
        return metrics
        
    def update_task_weights(self, val_metrics: Dict[str, float]):
        """Update task weights based on validation performance"""
        if not self.config.use_dynamic_weights:
            return
            
        # Calculate task-specific performance changes
        if len(self.val_history) > 0:
            prev_metrics = self.val_history[-1]
            
            with torch.no_grad():
                for i, task in enumerate(self.model.tasks):
                    if f'{task}_rmse' in val_metrics and f'{task}_rmse' in prev_metrics:
                        # Increase weight if performance degraded
                        improvement = prev_metrics[f'{task}_rmse'] - val_metrics[f'{task}_rmse']
                        
                        # Update log weight
                        self.model.log_task_weights[i] += self.config.weight_learning_rate * (-improvement)
                        
                # Ensure weights don't become too extreme
                self.model.log_task_weights.clamp_(-2, 2)
                
    def train(self, train_loader: DataLoader, val_loader: DataLoader, use_wandb: bool = True):
        """Full training loop"""
        if use_wandb:
            wandb.init(project="multi-task-options", config=self.config.__dict__)
            
        logger.info("Starting multi-task training...")
        
        best_val_loss = float('inf')
        
        for epoch in range(self.config.epochs):
            # Train
            train_losses = self.train_epoch(train_loader)
            self.train_history.append(train_losses)
            
            # Validate
            val_metrics = self.validate(val_loader)
            self.val_history.append(val_metrics)
            
            # Update learning rate
            self.scheduler.step()
            
            # Update task weights
            if epoch > 0 and epoch % self.config.weight_update_frequency == 0:
                self.update_task_weights(val_metrics)
                
            # Track task weights
            current_weights = self.model.get_task_weights().detach().cpu().numpy()
            self.task_weight_history.append(current_weights)
            
            # Log metrics
            logger.info(f"Epoch {epoch+1}/{self.config.epochs}")
            logger.info(f"Train Loss: {train_losses['total_loss']:.4f}")
            
            # Log task-specific metrics
            for task in self.model.tasks:
                if f'{task}_rmse' in val_metrics:
                    logger.info(f"{task.capitalize()} - RMSE: {val_metrics[f'{task}_rmse']:.4f}, ")
                              f"Weight: {current_weights[self.model.tasks.index(task)]:.3f}")
                    
            if use_wandb:
                log_dict = {}
                    'epoch': epoch,
                    **{f'train_{k}': v for k, v in train_losses.items()},
                    **{f'val_{k}': v for k, v in val_metrics.items()}
                }
                
                # Add task weights
                for i, task in enumerate(self.model.tasks):
                    log_dict[f'weight_{task}'] = current_weights[i]
                    
                wandb.log(log_dict)
                
            # Save best model
            current_val_loss = sum(val_metrics.get(f'{task}_rmse', 0) for task in self.model.tasks)
            if current_val_loss < best_val_loss:
                best_val_loss = current_val_loss
                self.save_checkpoint('best_multitask_model.pth')
                logger.info("New best model saved!")
                
        if use_wandb:
            wandb.finish()
            
        # Plot task weight evolution
        self._plot_weight_evolution()
        
    def _plot_weight_evolution(self):
        """Plot how task weights evolved during training"""
        if not self.task_weight_history:
            return
            
        weights_array = np.array(self.task_weight_history)
        
        plt.figure(figsize=(10, 6))
        for i, task in enumerate(self.model.tasks):
            plt.plot(weights_array[:, i], label=task.capitalize())
            
        plt.xlabel('Epoch')
        plt.ylabel('Task Weight')
        plt.title('Task Weight Evolution During Training')
        plt.legend()
        plt.grid(True)
        plt.savefig('task_weight_evolution.png')
        plt.close()
        
    def save_checkpoint(self, path: str):
        """Save model checkpoint"""
        torch.save({)
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'config': self.config.__dict__,
            'train_history': self.train_history,
            'val_history': self.val_history,
            'task_weight_history': self.task_weight_history
        }, path)


class MultiTaskInference:
    """Inference engine for multi-task model"""
    
    def __init__(self, model_path: str, config: MultiTaskConfig):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.config = config
        
        # Load model
        checkpoint = torch.load(model_path, map_location=self.device)
        
        # Determine input dimension from saved weights
        input_dim = checkpoint['model_state_dict']['shared_encoder.encoder.0.weight'].shape[1]
        
        self.model = MultiTaskLearningModel(input_dim, config)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(self.device)
        self.model.eval()
        
    def predict(self, features: np.ndarray) -> Dict[str, Any]:
        """Make predictions for all tasks"""
        with torch.no_grad():
            features_tensor = torch.FloatTensor(features).unsqueeze(0).to(self.device)
            
            outputs = self.model(features_tensor)
            
            results = {}
            
            # Extract predictions and uncertainties
            for task in self.model.tasks:
                results[task] = {}
                    'prediction': outputs[f'{task}_prediction'].cpu().numpy().item(),
                    'uncertainty': outputs[f'{task}_uncertainty'].cpu().numpy().item()
                }
                
            # Auxiliary predictions
            if self.config.use_auxiliary_tasks:
                # Moneyness classification
                moneyness_probs = F.softmax(outputs['moneyness_logits'], dim=-1).cpu().numpy()[0]
                results['moneyness'] = {}
                    'class': np.argmax(moneyness_probs),
                    'probabilities': moneyness_probs,
                    'labels': ['OTM', 'ATM', 'ITM']
                }
                
                # Time value
                results['time_value'] = outputs['time_value_prediction'].cpu().numpy().item()
                
        return results
        
    def batch_predict(self, features: np.ndarray) -> Dict[str, np.ndarray]:
        """Batch predictions"""
        with torch.no_grad():
            features_tensor = torch.FloatTensor(features).to(self.device)
            
            outputs = self.model(features_tensor)
            
            results = {}
            
            for task in self.model.tasks:
                results[f'{task}_predictions'] = outputs[f'{task}_prediction'].cpu().numpy()
                results[f'{task}_uncertainties'] = outputs[f'{task}_uncertainty'].cpu().numpy()
                
        return results


def create_multi_task_options_data(n_samples: int = 10000) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
    """Create synthetic data for multi-task learning"""
    np.random.seed(42)
    
    features = []
    targets = {}
        'price_target': [],
        'delta_target': [],
        'gamma_target': [],
        'vega_target': [],
        'theta_target': [],
        'rho_target': []
    }
    
    for _ in range(n_samples):
        # Market parameters
        S = np.random.uniform(80, 120)  # Spot
        K = np.random.uniform(85, 115)  # Strike
        T = np.random.uniform(0.1, 2.0)  # Time to maturity
        r = np.random.uniform(0.01, 0.05)  # Risk-free rate
        sigma = np.random.uniform(0.1, 0.5)  # Volatility
        q = np.random.uniform(0, 0.03)  # Dividend yield
        
        # Market microstructure
        volume = np.log1p(np.random.lognormal(10, 1))
        open_interest = np.log1p(np.random.lognormal(11, 1))
        bid_ask_spread = np.random.exponential(0.1)
        
        # Feature vector
        feature_vector = [S, K, T, r, sigma, q, volume, open_interest, bid_ask_spread]
        
        # Calculate Black-Scholes values and Greeks
        from scipy.stats import norm
        
        d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        # Price
        call_price = S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        call_price += np.random.normal(0, 0.5)  # Add noise
        
        # Greeks (with noise)
        delta = np.exp(-q * T) * norm.cdf(d1) + np.random.normal(0, 0.02)
        gamma = np.exp(-q * T) * norm.pdf(d1) / (S * sigma * np.sqrt(T)) + np.random.normal(0, 0.001)
        vega = S * np.exp(-q * T) * norm.pdf(d1) * np.sqrt(T) / 100 + np.random.normal(0, 0.05)
        theta = (-(S * np.exp(-q * T) * norm.pdf(d1) * sigma) / (2 * np.sqrt(T)) -)
                r * K * np.exp(-r * T) * norm.cdf(d2) + 
                q * S * np.exp(-q * T) * norm.cdf(d1)) / 365 + np.random.normal(0, 0.02)
        rho = K * T * np.exp(-r * T) * norm.cdf(d2) / 100 + np.random.normal(0, 0.05)
        
        features.append(feature_vector)
        targets['price_target'].append(call_price)
        targets['delta_target'].append(delta)
        targets['gamma_target'].append(gamma)
        targets['vega_target'].append(vega)
        targets['theta_target'].append(theta)
        targets['rho_target'].append(rho)
        
    return np.array(features), {k: np.array(v).reshape(-1, 1) for k, v in targets.items()}


def main():
    """Main training and inference pipeline"""
    # Configuration
    config = MultiTaskConfig()
        shared_hidden_dims=[512, 256, 128],
        use_dynamic_weights=True,
        learning_rate=1e-3,
        batch_size=128,
        epochs=50,
        use_auxiliary_tasks=True
    )
    
    # Generate data
    logger.info("Generating multi-task options data...")
    features, targets = create_multi_task_options_data(n_samples=10000)
    
    # Split data
    train_size = int(0.8 * len(features))
    
    train_features = features[:train_size]
    train_targets = {k: v[:train_size] for k, v in targets.items()}
    
    val_features = features[train_size:]
    val_targets = {k: v[train_size:] for k, v in targets.items()}
    
    # Create datasets
    train_dataset = MultiTaskDataset(train_features, train_targets)
    val_dataset = MultiTaskDataset(val_features, val_targets)
    
    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size, shuffle=False)
    
    # Create model and trainer
    input_dim = features.shape[1]
    model = MultiTaskLearningModel(input_dim, config)
    trainer = MultiTaskTrainer(model, config)
    
    # Train model
    trainer.train(train_loader, val_loader, use_wandb=False)
    
    # Inference
    logger.info("Running inference...")
    inference = MultiTaskInference('best_multitask_model.pth', config)
    
    # Test prediction
    test_features = features[-1]
    results = inference.predict(test_features)
    
    logger.info("\nPrediction Results:")
    for task in ['price', 'delta', 'gamma', 'vega', 'theta', 'rho']:
        logger.info(f"{task.capitalize()}: {results[task]['prediction']:.4f} ")
                   f"± {results[task]['uncertainty']:.4f}")
                   
    logger.info(f"\nMoneyness: {results['moneyness']['labels'][results['moneyness']['class']]}")
    logger.info(f"Time Value: {results['time_value']:.4f}")


# Create wrapper for compatibility
class MultiTaskLearningFramework:
    def __init__(self, config=None):
        if config is None:
            config = MultiTaskConfig()
        if isinstance(config, dict):
            config = MultiTaskConfig(**config)
        # Default input_dim
        self.model = MultiTaskLearningModel(input_dim=10, config=config)
    
    def __getattr__(self, name):
        return getattr(self.model, name)


if __name__ == "__main__":
    main()

# Class aliases and stubs
MultiTaskLearning = MultiTaskLearningModel


# Module exports
__all__ = ['MultiTaskLearningModel', 'GradientReversalFunction', 'GradientReversalLayer', 'MultiTaskDataset', 'MultiTaskInference', 'SharedEncoder', 'MultiTaskConfig', 'MultiTaskTrainer', 'MultiTaskLearningFramework', 'MultiTaskLearning', 'MultiTaskLoss', 'TaskHead']
