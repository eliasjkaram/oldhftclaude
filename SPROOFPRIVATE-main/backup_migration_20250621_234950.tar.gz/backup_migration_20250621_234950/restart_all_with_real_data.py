#!/usr/bin/env python3
"""
Restart All Systems with REAL Market Data
========================================
"""

import subprocess
import time
import os
from datetime import datetime

print("=" * 80)
print("🔄 RESTARTING ALL SYSTEMS WITH REAL MARKET DATA")
print("=" * 80)
print(f"Timestamp: {datetime.now()}")
print("=" * 80)

# Kill existing processes
print("\n📛 Stopping existing systems...")
subprocess.run("pkill -f 'python.*ai.*discovery'", shell=True)
subprocess.run("pkill -f 'python.*trading'", shell=True)
subprocess.run("pkill -f 'python.*monitor'", shell=True)
time.sleep(2)

# Start systems with real data
systems = []
    ("AI Discovery System", "python fix_ai_discovery_system.py"),
    ("Real-Time AI Trading", "python realtime_ai_trading.py"),
    ("Production System", "python PRODUCTION_FIXED_DEPLOYMENT.py"),
    ("Unified Monitor", "python unified_monitoring_dashboard.py")
]

print("\n🚀 Starting systems with REAL market data...")
for name, cmd in systems:
    print(f"\nStarting {name}...")
    subprocess.Popen(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)

print("\n✅ All systems restarted with REAL market data!")
print("\n📊 Current Market Prices (REAL from Alpaca):")
print("-" * 60)

# Show current real prices
from universal_market_data import get_current_market_data
data = get_current_market_data(['AAPL', 'AMZN', 'GOOGL', 'TSLA', 'SPY'])
for symbol, info in data.items():
    print(f"{symbol}: ${info['price']:.2f} (Live from {info['source']})")

print("\n🎯 Key Points:")
print("  • All prices are REAL from Alpaca API")
print("  • No simulated or mock data used")
print("  • Fallback to YFinance if Alpaca fails")
print("  • AI Discovery using actual market spreads")

print("\n📍 Monitor with:")
print("  python unified_monitoring_dashboard.py")
print("  tail -f *.log")
print("=" * 80)