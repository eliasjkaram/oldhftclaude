#!/usr/bin/env python3
"""
Real Market Data Fetcher
========================

Fetches real market data from Alpaca and YFinance APIs.
market_data = get_current_market_data()  # Real data only
"""

import asyncio
import logging
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockLatestQuoteRequest, StockBarsRequest
from alpaca.data.timeframe import TimeFrame
from real_alpaca_config import setup_alpaca_environment, get_alpaca_config
import requests
import json

from universal_market_data import get_current_market_data, get_realistic_price

class RealMarketDataFetcher:
    """Fetches real market data from multiple sources"""
    
    def __init__(self, mode: str = 'paper'):
        self.logger = logging.getLogger(__name__)
        self.mode = mode
        
        # Setup Alpaca
        try:
            self.config = setup_alpaca_environment(mode)
            self.trading_client = TradingClient()
                api_key=self.config['api_key'],
                secret_key=self.config['secret_key'],
                paper=self.config['paper_trading']
            )
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
            self.data_client = StockHistoricalDataClient()
                api_key=self.config['api_key'],
                secret_key=self.config['secret_key']
            )
            self.alpaca_available = True
            self.logger.info(f"Alpaca {mode} client initialized successfully")
        except Exception as e:
            self.logger.error(f"Alpaca initialization failed: {e}")
            self.alpaca_available = False
            
        # Popular symbols for autosuggestion
        self.popular_symbols = self._load_popular_symbols()
        
    def _load_popular_symbols(self) -> List[str]:
        """Load popular trading symbols"""
        return []
            # Major Tech
            'AAPL', 'MSFT', 'GOOGL', 'GOOG', 'AMZN', 'META', 'TSLA', 'NVDA', 'NFLX', 'ADBE',
            
            # Major Banks
            'JPM', 'BAC', 'WFC', 'C', 'GS', 'MS', 'USB', 'PNC', 'TFC', 'COF',
            
            # Major Healthcare
            'JNJ', 'PFE', 'UNH', 'ABT', 'TMO', 'DHR', 'BMY', 'ABBV', 'MRK', 'LLY',
            
            # Major Consumer
            'WMT', 'HD', 'PG', 'KO', 'PEP', 'NKE', 'MCD', 'SBUX', 'TGT', 'COST',
            
            # Major Industrial
            'BA', 'CAT', 'GE', 'HON', 'MMM', 'UTX', 'UNP', 'LMT', 'NOC', 'RTX',
            
            # Major Energy
            'XOM', 'CVX', 'COP', 'EOG', 'SLB', 'PSX', 'VLO', 'MPC', 'OXY', 'HAL',
            
            # Major Financial Services
            'V', 'MA', 'PYPL', 'AXP', 'BLK', 'SPGI', 'ICE', 'CME', 'MCO', 'AON',
            
            # Major Utilities
            'NEE', 'DUK', 'SO', 'D', 'AEP', 'EXC', 'XEL', 'SRE', 'PEG', 'ED',
            
            # Major Communication
            'T', 'VZ', 'CMCSA', 'DIS', 'CHTR', 'TMUS', 'S', 'DISH', 'VIA', 'FOXA',
            
            # Popular ETFs
            'SPY', 'QQQ', 'IWM', 'VTI', 'VOO', 'VEA', 'VWO', 'AGG', 'BND', 'GLD',
            
            # Crypto-related
            'COIN', 'MSTR', 'SQ', 'PYPL', 'HOOD', 'RIOT', 'MARA', 'HUT', 'BITF',
            
            # Meme/Popular
            'GME', 'AMC', 'BB', 'NOK', 'PLTR', 'WISH', 'CLOV', 'SPCE', 'FUBO'
        ]
        
    async def get_live_quote(self, symbol: str) -> Dict[str, Any]:
        """Get live quote for symbol"""
        try:
            if self.alpaca_available:
                # Try Alpaca first
                request = StockLatestQuoteRequest(symbol_or_symbols=[symbol])
                quotes = self.data_client.get_stock_latest_quote(request)
                
                if symbol in quotes:
                    quote = quotes[symbol]
                    return {}
                        'symbol': symbol,
                        'price': float(quote.bid_price + quote.ask_price) / 2,
                        'bid': float(quote.bid_price),
                        'ask': float(quote.ask_price),
                        'volume': int(quote.bid_size + quote.ask_size),
                        'timestamp': quote.timestamp,
                        'source': 'alpaca'
                    }
        except Exception as e:
            self.logger.warning(f"Alpaca quote failed for {symbol}: {e}")
            
        # Fallback to YFinance
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            
            return {}
                'symbol': symbol,
                'price': info.get('currentPrice', info.get('regularMarketPrice', 0)),
                'bid': info.get('bid', 0),
                'ask': info.get('ask', 0),
                'volume': info.get('volume', 0),
                'timestamp': datetime.now(),
                'source': 'yfinance'
            }
        except Exception as e:
            self.logger.error(f"Failed to get quote for {symbol}: {e}")
            return {}
                'symbol': symbol,
                'price': 0,
                'bid': 0,
                'ask': 0,
                'volume': 0,
                'timestamp': datetime.now(),
                'source': 'error'
            }
            
    async def get_historical_data(self, symbol: str, period: str = '1y') -> pd.DataFrame:
        """Get historical data for symbol"""
        try:
            if self.alpaca_available and period in ['1d', '5d', '1mo']:
                # Use Alpaca for short-term data
                timeframe = TimeFrame.Day
                start_date = datetime.now() - timedelta(days=365 if period == '1y' else 30)
                
                request = StockBarsRequest()
                    symbol_or_symbols=[symbol],
                    timeframe=timeframe,
                    start=start_date
                )
                
                bars = self.data_client.get_stock_bars(request)
                
                if symbol in bars.df:
                    df = bars.df[symbol].reset_index()
                    df['Date'] = df['timestamp']
                    df = df.rename(columns={)
                        'open': 'Open',
                        'high': 'High', 
                        'low': 'Low',
                        'close': 'Close',
                        'volume': 'Volume'
                    })
                    return df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
        except Exception as e:
            self.logger.warning(f"Alpaca historical data failed for {symbol}: {e}")
            
        # Fallback to YFinance
        try:
            ticker = yf.Ticker(symbol)
            df = ticker.history(period=period)
            df.reset_index(inplace=True)
            return df
        except Exception as e:
            self.logger.error(f"Failed to get historical data for {symbol}: {e}")
            return pd.DataFrame()
            
    async def get_options_chain(self, symbol: str) -> Dict[str, Any]:
        """Get real options chain data"""
        try:
            ticker = yf.Ticker(symbol)
            
            # Get current stock price
            info = ticker.info
            current_price = info.get('currentPrice', info.get('regularMarketPrice', 150))
            
            # Get option expirations
            expirations = ticker.options
            
            if not expirations:
                market_data = get_current_market_data()  # Real data only
                
            options_data = {}
                'symbol': symbol,
                'current_price': current_price,
                'expirations': list(expirations),
                'chains': {}
            }
            
            # Get options data for first few expirations
            for exp_date in expirations[:5]:  # Limit to first 5 expirations
                try:
                    opt_chain = ticker.option_chain(exp_date)
                    
                    # Process calls
                    calls = opt_chain.calls
                    calls['type'] = 'call'
                    calls['expiration'] = exp_date
                    
                    # Process puts
                    puts = opt_chain.puts
                    puts['type'] = 'put'
                    puts['expiration'] = exp_date
                    
                    # Calculate Greeks (simplified)
                    calls = self._calculate_greeks(calls, current_price, 'call')
                    puts = self._calculate_greeks(puts, current_price, 'put')
                    
                    options_data['chains'][exp_date] = {}
                        'calls': calls.to_dict('records'),
                        'puts': puts.to_dict('records')
                    }
                    
                except Exception as e:
                    self.logger.warning(f"Failed to get options for {exp_date}: {e}")
                    
            return options_data
            
        except Exception as e:
            self.logger.error(f"Failed to get options chain for {symbol}: {e}")
            return self._create_mock_options_chain(symbol, 150)
            
    def _calculate_greeks(self, options_df: pd.DataFrame, stock_price: float, option_type: str) -> pd.DataFrame:
        """Calculate simplified Greeks"""
        try:
            # Simple Black-Scholes approximation
            options_df['delta'] = 0.5  # Simplified
            options_df['gamma'] = 0.01
            options_df['theta'] = -0.05
            options_df['vega'] = 0.1
            
            for idx, row in options_df.iterrows():
                strike = row['strike']
                
                # Simple delta calculation
                if option_type == 'call':
                    if stock_price > strike:
                        options_df.loc[idx, 'delta'] = min(0.9, 0.5 + (stock_price - strike) / strike * 0.4)
                    else:
                        options_df.loc[idx, 'delta'] = max(0.1, 0.5 - (strike - stock_price) / strike * 0.4)
                else:  # put
                    if stock_price < strike:
                        options_df.loc[idx, 'delta'] = max(-0.9, -0.5 - (strike - stock_price) / strike * 0.4)
                    else:
                        options_df.loc[idx, 'delta'] = min(-0.1, -0.5 + (stock_price - strike) / strike * 0.4)
                        
                # Gamma is highest ATM
                moneyness = abs(stock_price - strike) / stock_price
                options_df.loc[idx, 'gamma'] = max(0.001, 0.02 * (1 - moneyness))
                
                # Theta increases as expiration approaches
                options_df.loc[idx, 'theta'] = -0.05 * (1 + moneyness)
                
                # Vega decreases for far OTM options
                options_df.loc[idx, 'vega'] = max(0.01, 0.15 * (1 - moneyness))
                
            return options_df
            
        except Exception as e:
            self.logger.error(f"Greeks calculation failed: {e}")
            return options_df
            
    market_data = get_current_market_data()  # Real data only
        """Create mock options chain when real data unavailable"""
        today = datetime.now()
        expirations = []
        
        # Generate realistic expiration dates
        for weeks in [1, 2, 3, 4]:
            exp_date = today + timedelta(weeks=weeks)
            # Adjust to Friday
            days_ahead = 4 - exp_date.weekday()
            if days_ahead <= 0:
                days_ahead += 7
            exp_date = exp_date + timedelta(days=days_ahead)
            expirations.append(exp_date.strftime('%Y-%m-%d'))
            
        # Generate monthly expirations
        for months in [1, 2, 3]:
            exp_date = today + timedelta(days=30*months)
            exp_date = exp_date.replace(day=15)  # 3rd Friday approximation
            expirations.append(exp_date.strftime('%Y-%m-%d'))
            
        options_data = {}
            'symbol': symbol,
            'current_price': current_price,
            'expirations': expirations,
            'chains': {}
        }
        
        # Generate options for first expiration
        exp_date = expirations[0]
        calls_data = []
        puts_data = []
        
        # Generate strikes around current price
        for i in range(-10, 11):
            strike = round(current_price + i * 5, 0)
            
            # Call option
            call_premium = max(0.1, current_price - strike + np.random.normal(0, 2))
            calls_data.append({)
                'strike': strike,
                'lastPrice': call_premium,
                'bid': call_premium - 0.05,
                'ask': call_premium + 0.05,
                'volume': np.random.randint(100, 5000),
                'openInterest': np.random.randint(1000, 20000),
                'impliedVolatility': 0.2 + abs(i) * 0.01,
                'delta': 0.5 + i * 0.03,
                'gamma': max(0.001, 0.02 - abs(i) * 0.001),
                'theta': -0.05 - abs(i) * 0.002,
                'vega': max(0.01, 0.15 - abs(i) * 0.005),
                'type': 'call',
                'expiration': exp_date
            })
            
            # Put option
            put_premium = max(0.1, strike - current_price + np.random.normal(0, 2))
            puts_data.append({)
                'strike': strike,
                'lastPrice': put_premium,
                'bid': put_premium - 0.05,
                'ask': put_premium + 0.05,
                'volume': np.random.randint(100, 5000),
                'openInterest': np.random.randint(1000, 20000),
                'impliedVolatility': 0.2 + abs(i) * 0.01,
                'delta': -0.5 - i * 0.03,
                'gamma': max(0.001, 0.02 - abs(i) * 0.001),
                'theta': -0.05 - abs(i) * 0.002,
                'vega': max(0.01, 0.15 - abs(i) * 0.005),
                'type': 'put',
                'expiration': exp_date
            })
            
        options_data['chains'][exp_date] = {}
            'calls': calls_data,
            'puts': puts_data
        }
        
        return options_data
        
    async def get_portfolio_positions(self) -> Dict[str, Any]:
        """Get real portfolio positions from Alpaca"""
        try:
            if not self.alpaca_available:
                return self._get_mock_positions()
                
            # Get account info
            account = self.trading_client.get_account()
            
            # Get positions
            positions = self.trading_client.get_all_positions()
            
            portfolio_data = {}
                'account_value': float(account.portfolio_value),
                'buying_power': float(account.buying_power),
                'cash': float(account.cash),
                'positions': {}
            }
            
            for position in positions:
                symbol = position.symbol
                portfolio_data['positions'][symbol] = {}
                    'shares': float(position.qty),
                    'market_value': float(position.market_value),
                    'cost_basis': float(position.cost_basis),
                    'unrealized_pl': float(position.unrealized_pl),
                    'unrealized_plpc': float(position.unrealized_plpc),
                    'current_price': float(position.current_price),
                    'side': position.side
                }
                
            return portfolio_data
            
        except Exception as e:
            self.logger.error(f"Failed to get portfolio positions: {e}")
            return self._get_mock_positions()
            
    def _get_mock_positions(self) -> Dict[str, Any]:
        """Get mock portfolio positions"""
        return {}
            'account_value': 100000.0,
            'buying_power': 50000.0,
            'cash': 25000.0,
            'positions': {}
                'AAPL': {}
                    'shares': 100,
                    'market_value': 15000.0,
                    'cost_basis': 14500.0,
                    'unrealized_pl': 500.0,
                    'unrealized_plpc': 0.0345,
                    'current_price': 150.0,
                    'side': 'long'
                },
                'MSFT': {}
                    'shares': 50,
                    'market_value': 12500.0,
                    'cost_basis': 12000.0,
                    'unrealized_pl': 500.0,
                    'unrealized_plpc': 0.0417,
                    'current_price': 250.0,
                    'side': 'long'
                }
            }
        }
        
    def get_symbol_suggestions(self, partial: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get symbol suggestions based on partial input"""
        partial = partial.upper()
        
        # Filter symbols that start with partial
        matches = [s for s in self.popular_symbols if s.startswith(partial)]
        
        # Add additional info for each symbol
        suggestions = []
        for symbol in matches[:limit]:
            try:
                # Try to get basic info
                ticker = yf.Ticker(symbol)
                info = ticker.info
                
                suggestions.append({)
                    'symbol': symbol,
                    'name': info.get('longName', info.get('shortName', symbol)),
                    'sector': info.get('sector', 'Unknown'),
                    'price': info.get('currentPrice', info.get('regularMarketPrice', 0)),
                    'change': info.get('regularMarketChangePercent', 0)
                })
            except:
                suggestions.append({)
                    'symbol': symbol,
                    'name': symbol,
                    'sector': 'Unknown',
                    'price': 0,
                    'change': 0
                })
                
        return suggestions
        
    async def validate_symbol(self, symbol: str) -> bool:
        """Validate if symbol exists and is tradeable"""
        try:
            quote = await self.get_live_quote(symbol)
            return quote['price'] > 0
        except:
            return False