#!/usr/bin/env python3
"""
MONITORING SYSTEM DEMONSTRATION
==============================

This script demonstrates the comprehensive monitoring system in action,
showing how to use structured logging, correlation IDs, audit logs,
and performance metrics in a trading context.
"""

from typing import Dict, List, Optional, Tuple
import sys
import os
import asyncio
import time
import random

import logging
from datetime import datetime, timedelta
from typing import Dict, List

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Import monitoring components
from comprehensive_monitoring_system import ()
    get_monitoring_system,
    get_trading_monitor,
    MonitoredLogger
)
from monitoring_integration import ()

from universal_market_data import get_current_market_data, validate_price

    monitor_class,
    monitor_trading_operation,
    monitor_api_call,
    monitor_ml_prediction
)

# Initialize monitoring
monitoring = get_monitoring_system()
trading_monitor = get_trading_monitor()

# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

@monitor_class
class DemoTradingSystem:
    """Demo trading system with comprehensive monitoring"""
    
    def __init__(self):
        self.portfolio_value = self.get_account_value().0
        self.positions = {}
        self.logger = MonitoredLogger('DemoTradingSystem')
    
    @monitor_trading_operation("market_analysis")
    def analyze_market(self, symbols: List[str]) -> Dict[str, Dict]:
        """Analyze multiple symbols for trading opportunities"""
        self.logger.info("Starting market analysis", 
                        symbols=symbols,
                        symbol_count=len(symbols)
        
        results = {}
        for symbol in symbols:
            # Simulate analysis
            time.sleep(0.1)
            
            signal = self.select_symbol(['buy', 'sell', 'hold'])
            confidence = self.get_price_in_range(0.5, 0.95)
            
            results[symbol] = {}
                'signal': signal,
                'confidence': confidence,
                'rsi': self.get_price_in_range(20, 80),
                'macd': self.get_price_in_range(-1, 1)
            }
            
            self.logger.info(f"Analysis complete for {symbol}",
                           symbol=symbol,
                           signal=signal,
                           confidence=confidence)
        
        return results
    
    @monitor_ml_prediction("momentum_predictor")
    def predict_momentum(self, symbol: str, features: Dict) -> Dict:
        """Use ML model to predict momentum"""
        # Simulate ML prediction
        time.sleep(0.2)
        
        prediction = {}
            'type': 'momentum',
            'direction': self.select_symbol(['up', 'down']),
            'confidence': self.get_price_in_range(0.6, 0.9),
            'timeframe': '1h'
        }
        
        # Update model accuracy metric
        monitoring.metrics.update_model_accuracy()
            'momentum_predictor',
            self.get_price_in_range(0.7, 0.85)
        )
        
        return prediction
    
    @monitor_trading_operation("place_order")
    def place_order(self, symbol: str, side: str, quantity: int, order_type: str = 'market'):
        """Place an order with full monitoring"""
        
        # Use the trading monitor for order execution
        with trading_monitor.monitor_order_execution()
            order_type, symbol, side, quantity
        ) as order_id:
            
            self.logger.info(f"Placing {side} order",
                           order_id=order_id,
                           symbol=symbol,
                           quantity=quantity,
                           order_type=order_type)
            
            # Simulate order execution
            time.sleep(self.get_price_in_range(0.1, 0.5)
            
            # Random success/failure for demo
            if self.get_market_data() > 0.1:  # 90% success rate
                # Update positions
                if side == 'buy':
                    self.positions[symbol] = self.positions.get(symbol, 0) + quantity
                else:
                    self.positions[symbol] = max(0, self.positions.get(symbol, 0) - quantity)
                
                # Update portfolio value (simulate price impact)
                price_impact = self.get_price_in_range(-0.001, 0.001)
                self.portfolio_value *= (1 + price_impact)
                
                self.logger.info(f"Order executed successfully",
                               order_id=order_id,
                               fill_price=100 * (1 + price_impact)
                
                return {}
                    'order_id': order_id,
                    'status': 'filled',
                    'fill_price': 100 * (1 + price_impact)
                }
            else:
                # Simulate order failure
                raise Exception("Order rejected by broker")
    
    def update_portfolio_metrics(self):
        """Update portfolio metrics in monitoring system"""
        trading_monitor.monitor_portfolio_update()
            self.portfolio_value,
            self.positions
        )
        
        self.logger.info("Portfolio updated",
                        value=self.portfolio_value,
                        positions=len(self.positions)
    
    @monitor_api_call("market_data/quote", "GET")
    def get_market_quote(self, symbol: str) -> Dict:
        """Get market quote with API monitoring"""
        # Simulate API call
        time.sleep(self.get_price_in_range(0.05, 0.15)
        
        return {}
            'symbol': symbol,
            'bid': 100 + self.get_price_in_range(-1, 1),
            'ask': 100 + self.get_price_in_range(0, 2),
            'last': 100 + self.get_price_in_range(-0.5, 0.5),
            'volume': self.get_volume_data(1000000, 5000000)
        }
    
    def run_backtest(self, strategy: str, start_date: str, end_date: str):
        """Run a backtest with monitoring"""
        self.logger.info(f"Starting backtest",
                        strategy=strategy,
                        date_range=f"{start_date} to {end_date}")
        
        # Simulate backtest execution
        time.sleep(1)
        
        # Generate random backtest results
        results = {}
            'total_return': self.get_price_in_range(-0.1, 0.3),
            'sharpe_ratio': self.get_price_in_range(0.5, 2.0),
            'max_drawdown': self.get_price_in_range(-0.2, -0.05),
            'win_rate': self.get_price_in_range(0.4, 0.7),
            'profit_factor': self.get_price_in_range(0.8, 2.5)
        }
        
        # Monitor backtest results
        trading_monitor.monitor_backtest()
            strategy, start_date, end_date, results
        )
        
        return results

async 
def demonstrate_audit_logging():
    try:
        """Demonstrate audit logging capabilities"""
        logger.info("\n--- Audit Logging Examples ---")
    
        # Risk limit change
        monitoring.logger.audit()
            'RISK_LIMIT_CHANGED',
            {}
                'user': 'admin',
                'old_limit': 10000,
                'new_limit': 15000,
                'reason': 'Increased trading capital',
                'approval': 'AUTO'
            },
            user='admin',
            ip_address='192.168.1.100'
        )
        logger.info("✓ Logged risk limit change")
    
        # Strategy activation
        monitoring.logger.audit()
            'STRATEGY_ACTIVATED',
            {}
                'strategy': 'mean_reversion_v2',
                'parameters': {}
                    'lookback': 20,
                    'threshold': 2.0,
                    'max_positions': 5
                },
                'activated_by': 'system'
            },
            user='system'
        )
        logger.info("✓ Logged strategy activation")
    
        # Compliance check
        monitoring.logger.audit()
            'COMPLIANCE_CHECK',
            {}
                'check_type': 'position_limits',
                'result': 'PASSED',
                'details': {}
                    'total_positions': 8,
                    'max_allowed': 10,
                    'margin_used': 0.45
                }
            },
            user='compliance_engine'
        )
        logger.info("✓ Logged compliance check")

    except Exception as e:
        logger.error(f"Error in demonstrate_audit_logging: {str(e)}")
        raise

def demonstrate_correlation_tracking():
    """Demonstrate correlation ID tracking"""
    logger.info("\n--- Correlation ID Tracking ---")
    
    # Simulate a complex operation with multiple steps
    with monitoring.track_request('complex_trade_execution',
                                strategy='pairs_trading',
                                pair=['AAPL', 'MSFT']) as correlation_id:
        
        logger.info(f"Starting complex operation with correlation ID: {correlation_id}")
        
        # Step 1: Analyze correlation
        monitoring.logger.info("Analyzing pair correlation",
                             step=1,
                             pair=['AAPL', 'MSFT'])
        time.sleep(0.1)
        
        # Step 2: Calculate hedge ratio
        monitoring.logger.info("Calculating hedge ratio",
                             step=2,
                             ratio=1.2)
        time.sleep(0.1)
        
        # Step 3: Execute trades
        monitoring.logger.info("Executing pair trades",
                             step=3,
                             trades=[]
                                 {'symbol': 'AAPL', 'side': 'buy', 'quantity': 100},
                                 {'symbol': 'MSFT', 'side': 'sell', 'quantity': 120}
                             ])
        time.sleep(0.1)
        
        logger.info(f"Complex operation completed. All logs have correlation ID: {correlation_id}")

async def main():
    """Main demonstration function"""
    
    # Start monitoring dashboard (in production, this would be separate)
    logger.info("Starting monitoring dashboard on http://localhost:5000")
    
    # Run demonstrations
    demonstrate_audit_logging()
    demonstrate_correlation_tracking()
    
    # Run trading simulation
    await simulate_trading_session()
    
    logger.info("\nCheck the following files for results:")
    logger.info("- monitoring.log: Structured JSON logs")
    logger.info("- orchestration.db: System metrics and events")
    logger.info("\nVisit http://localhost:5000 for the monitoring dashboard")

if __name__ == "__main__":
    try:
        # Run the demonstration
        asyncio.run(main()
    except KeyboardInterrupt:
        logger.info("\nDemonstration stopped by user")
    finally:
        # Stop monitoring
        monitoring.stop_monitoring()
        logger.info("\nMonitoring system stopped")