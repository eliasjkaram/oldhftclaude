
#!/usr/bin/env python3
"""
Demo Updated Options Trader
===========================
Demonstrates the corrected Alpaca options API usage
"""

# Alpaca imports
import sys
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from alpaca.trading.requests import ()
    GetOptionContractsRequest,
    LimitOrderRequest,
    OptionLegRequest
)
from alpaca.trading.enums import ()
    AssetStatus,
    ExerciseStyle,
    OrderSide,
    TimeInForce,
    OrderClass,
    ContractType
)
from alpaca.data.requests import StockLatestQuoteRequest

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class DemoOptionsTrader:
    """Demo of corrected options trading"""
    
    def __init__(self):
    try:
            # Alpaca credentials
            self.API_KEY = os.getenv('ALPACA_PAPER_API_KEY')
            self.SECRET_KEY = os.getenv('ALPACA_PAPER_API_SECRET')
        
            # Initialize clients
            self.trading_client = TradingClient(self.API_KEY, self.SECRET_KEY, paper=True)
            self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
            self.stock_data_client = StockHistoricalDataClient(self.API_KEY, self.SECRET_KEY)
        
            # Set timezone
            self.tz = ZoneInfo("America/New_York")
        
            logger.info("🎯 Demo Options Trader Initialized")
        
            # Get account info
            account = self.trading_client.get_account()
            logger.info(f"💰 Account Equity: ${float(account.equity):,.2f}")
    
        async def demonstrate_correct_api_usage(self):
            """Demonstrate the correct API usage"""
        
            logger.info(f"\n{'='*60}")
            logger.info(f"🔧 DEMONSTRATING CORRECTED API USAGE")
            logger.info(f"{'='*60}")
        
            # 1. Get current stock price
            logger.info(f"\n📊 Step 1: Get current stock price")
            symbol = "SPY"
        
            quote_request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            quote = self.stock_data_client.get_stock_latest_quote(quote_request)
        
            if symbol in quote:
                current_price = float(quote[symbol].ask_price or quote[symbol].bid_price)
                logger.info(f"   Current {symbol} price: ${current_price:.2f}")
            else:
                current_price = 596.0
                logger.info(f"   Using fallback price: ${current_price:.2f}")
        
            # 2. Demonstrate corrected GetOptionContractsRequest
            logger.info(f"\n🔧 Step 2: Get options contracts (CORRECTED API)")
        
            now = datetime.now(tz=self.tz)
            start_date = now + timedelta(days=1)
            end_date = now + timedelta(days=30)
        
            # CORRECTED: underlying_symbols as list, strike prices as strings
            contracts_request = GetOptionContractsRequest()
                underlying_symbols=[symbol],  # ✅ CORRECTED: List instead of single string
                status=AssetStatus.ACTIVE,
                expiration_date_gte=start_date.strftime('%Y-%m-%d'),
                expiration_date_lte=end_date.strftime('%Y-%m-%d'),
                strike_price_gte=str(round(str(int(current_price * 0.95, 2)))),  # ✅ CORRECTED: String instead of float
                strike_price_lte=str(round(str(int(current_price * 1.05, 2)))),  # ✅ CORRECTED: String instead of float
                style=ExerciseStyle.AMERICAN,
                limit=20
            )
        
            logger.info(f"   Request parameters:")
            logger.info(f"     underlying_symbols: {contracts_request.underlying_symbols}")
            logger.info(f"     strike_price_gte: {contracts_request.strike_price_gte} (type: {type(contracts_request.strike_price_gte)})")
            logger.info(f"     strike_price_lte: {contracts_request.strike_price_lte} (type: {type(contracts_request.strike_price_lte)})")
        
            contracts = self.trading_client.get_option_contracts(contracts_request)
            logger.info(f"   ✅ SUCCESS: Found {len(contracts.option_contracts)} contracts")
        
            # 3. Show sample contracts
            logger.info(f"\n📋 Step 3: Sample contracts")
        
            calls = [c for c in contracts.option_contracts if c.type == ContractType.CALL]
            puts = [c for c in contracts.option_contracts if c.type == ContractType.PUT]
        
            logger.info(f"   Calls: {len(calls)}, Puts: {len(puts)}")
        
            if calls:
                sample_call = calls[0]
                logger.info(f"   Sample Call: {sample_call.symbol}")
                logger.info(f"     Strike: ${sample_call.strike_price}")
                logger.info(f"     Expiry: {sample_call.expiration_date}")
        
            if puts:
                sample_put = puts[0] 
                logger.info(f"   Sample Put: {sample_put.symbol}")
                logger.info(f"     Strike: ${sample_put.strike_price}")
                logger.info(f"     Expiry: {sample_put.expiration_date}")
        
            # 4. Demonstrate bull call spread setup
            if len(calls) >= 2:
                logger.info(f"\n🚀 Step 4: Bull Call Spread Setup")
            
                # Sort calls by strike
                calls.sort(key=lambda x: float(x.strike_price))
            
                # Find two adjacent strikes
                lower_call = calls[0]
                upper_call = calls[1]
            
                logger.info(f"   Lower Call: {lower_call.symbol} (${lower_call.strike_price})")
                logger.info(f"   Upper Call: {upper_call.symbol} (${upper_call.strike_price})")
            
                # Create multi-leg order (demonstration only - not executed)
                order_legs = []
                    OptionLegRequest()
                        symbol=lower_call.symbol,
                        side=OrderSide.BUY,
                        ratio_qty=1
                    ),
                    OptionLegRequest()
                        symbol=upper_call.symbol,
                        side=OrderSide.SELL,
                        ratio_qty=1
                    )
                ]
            
                # This would be the actual order (not executed in demo)
                spread_order = LimitOrderRequest()
                    qty=1,
                    order_class=OrderClass.MLEG,
                    time_in_force=TimeInForce.DAY,
                    legs=order_legs,
                    limit_price = get_realistic_price(symbol)  # Real price
                )
            
                logger.info(f"   ✅ Multi-leg spread order prepared successfully")
                logger.info(f"   Order type: {spread_order.order_class}")
                logger.info(f"   Number of legs: {len(spread_order.legs)}")
                logger.info(f"   Limit price: ${spread_order.limit_price}")
            
            # 5. Summary
            logger.info(f"\n{'='*60}")
            logger.info(f"✅ DEMONSTRATION COMPLETE")
            logger.info(f"{'='*60}")
        
            logger.info(f"🔧 Key fixes applied:")
            logger.info(f"   ✓ underlying_symbol → underlying_symbols=[symbol]")
            logger.info(f"   ✓ strike_price_gte/lte as strings, not floats")
            logger.info(f"   ✓ Proper multi-leg order structure")
            logger.info(f"   ✓ OrderClass.MLEG for spreads")
            logger.info(f"   ✓ OptionLegRequest for each leg")
        
            logger.info(f"\n🎯 All {len(contracts.option_contracts)} contracts retrieved successfully!")
            logger.info(f"   API calls work correctly with updated parameters")
        
            return True

    async def main():
        """Main demo function"""
        trader = DemoOptionsTrader()
        success = await trader.demonstrate_correct_api_usage()
    
        if success:
            logger.info(f"\n🎉 Demo completed successfully!")
            logger.info(f"   Options API updates are working correctly")
        else:
            logger.error(f"\n❌ Demo failed!")
    
        return success

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in __init__: {str(e)}")
        raise
    asyncio.run(main())