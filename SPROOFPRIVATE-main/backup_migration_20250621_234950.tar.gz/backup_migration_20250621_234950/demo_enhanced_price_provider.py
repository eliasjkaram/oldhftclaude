#!/usr/bin/env python3
"""
Demo: Enhanced Price Provider Integration
========================================

Demonstrates how to use the enhanced price provider with multiple data sources
for getting real-time, accurate market prices.
"""

import os
import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List
import pandas as pd

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Import the enhanced price provider
from enhanced_price_provider import EnhancedPriceProvider, PriceData

from universal_market_data import get_current_market_data, get_realistic_price


def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig()
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[]
            logging.StreamHandler(),
            logging.FileHandler('enhanced_price_provider_demo.log')
        ]
    )
    return logging.getLogger(__name__)


def load_api_keys() -> Dict[str, str]:
    """Load API keys from environment or config file"""
    # Try to load from alpaca_config.json first
    config_file = 'alpaca_config.json'
    api_keys = {}
    
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
                if 'api_key' in config:
                    api_keys['alpaca_api_key'] = config['api_key']
                if 'api_secret' in config:
                    api_keys['alpaca_api_secret'] = config['api_secret']
        except Exception as e:
            print(f"Error loading config file: {e}")
    
    # Override with environment variables if present
    env_keys = {}
        'alpaca_api_key': 'ALPACA_API_KEY',
        'alpaca_api_secret': 'ALPACA_API_SECRET',
        'alpha_vantage_api_key': 'ALPHA_VANTAGE_API_KEY',
        'iex_cloud_api_key': 'IEX_CLOUD_API_KEY',
        'finnhub_api_key': 'FINNHUB_API_KEY'
    }
    
    for key, env_var in env_keys.items():
        if os.getenv(env_var):
            api_keys[key] = os.getenv(env_var)
    
    return api_keys


def demo_basic_usage(provider: EnhancedPriceProvider, logger: logging.Logger):
    """Demonstrate basic price fetching"""
    logger.info("=== Basic Price Fetching Demo ===")
    
    symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA']
    
    for symbol in symbols:
        price_data = provider.get_price(symbol)
        
        if price_data:
            logger.info()
                f"{symbol}: ${price_data.price:.2f} "
                f"[Source: {price_data.source}, "]
                f"Confidence: {price_data.confidence:.2%}]"
            )
            
            # Show additional data if available
            if price_data.bid and price_data.ask:
                spread = price_data.ask - price_data.bid
                spread_pct = (spread / price_data.price) * 100
                logger.info()
                    f"  Bid/Ask: ${price_data.bid:.2f}/${price_data.ask:.2f} "
                    f"(Spread: ${spread:.2f} / {spread_pct:.3f}%)"
                )
                
            if price_data.volume:
                logger.info(f"  Volume: {price_data.volume:,}")
                
        else:
            logger.warning(f"Failed to get price for {symbol}")
            
        time.sleep(0.5)  # Small delay between requests


def demo_bulk_pricing(provider: EnhancedPriceProvider, logger: logging.Logger):
    """Demonstrate bulk price fetching"""
    logger.info("\n=== Bulk Price Fetching Demo ===")
    
    # Large list of symbols
    symbols = []
        'SPY', 'QQQ', 'IWM', 'DIA', 'VTI',
        'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META',
        'NVDA', 'TSLA', 'BRK.B', 'JPM', 'JNJ',
        'V', 'PG', 'UNH', 'HD', 'MA'
    ]
    
    start_time = time.time()
    prices = provider.get_bulk_prices(symbols)
    elapsed = time.time() - start_time
    
    logger.info(f"Fetched {len(prices)} prices in {elapsed:.2f} seconds")
    
    # Show prices grouped by confidence
    high_confidence = []
    medium_confidence = []
    low_confidence = []
    
    for symbol, price_data in prices.items():
        if price_data:
            if price_data.confidence >= 0.9:
                high_confidence.append((symbol, price_data)
            elif price_data.confidence >= 0.7:
                medium_confidence.append((symbol, price_data)
            else:
                low_confidence.append((symbol, price_data)
    
    logger.info(f"\nHigh Confidence (>= 90%): {len(high_confidence)} symbols")
    for symbol, data in high_confidence[:5]:
        logger.info(f"  {symbol}: ${data.price:.2f}")
        
    logger.info(f"\nMedium Confidence (70-90%): {len(medium_confidence)} symbols")
    for symbol, data in medium_confidence[:5]:
        logger.info(f"  {symbol}: ${data.price:.2f}")
        
    if low_confidence:
        logger.info(f"\nLow Confidence (< 70%): {len(low_confidence)} symbols")
        for symbol, data in low_confidence[:5]:
            logger.info(f"  {symbol}: ${data.price:.2f}")


def demo_market_hours_handling(provider: EnhancedPriceProvider, logger: logging.Logger):
    """Demonstrate market hours detection and handling"""
    logger.info("\n=== Market Hours Handling Demo ===")
    
    # Check a few major symbols
    symbols = ['AAPL', 'SPY', 'GOOGL']
    
    for symbol in symbols:
        price_data = provider.get_price(symbol)
        
        if price_data:
            market_status = "Open" if price_data.is_market_hours else "Closed"
            logger.info()
                f"{symbol}: ${price_data.price:.2f} "
                f"[Market: {market_status}]"
            )
            
            if not price_data.is_market_hours:
                logger.info()
                    f"  Note: Price may be from extended hours or previous close"
                )


def demo_source_failover(provider: EnhancedPriceProvider, logger: logging.Logger):
    """Demonstrate source failover capabilities"""
    logger.info("\n=== Source Failover Demo ===")
    
    # Get statistics before
    stats_before = provider.get_stats()
    
    # Try to get prices for various symbols
    test_symbols = ['AAPL', 'INVALID_SYMBOL_XYZ', 'MSFT', 'ANOTHER_INVALID']
    
    for symbol in test_symbols:
        logger.info(f"\nTrying to fetch {symbol}...")
        price_data = provider.get_price(symbol, use_cache=False)
        
        if price_data:
            logger.info()
                f"✅ Success: ${price_data.price:.2f} from {price_data.source}"
            )
        else:
            logger.info(f"❌ Failed: No valid price found")
    
    # Show source performance
    stats_after = provider.get_stats()
    logger.info("\n=== Source Performance ===")
    
    for source, stats in stats_after['sources'].items():
        before = stats_before['sources'].get(source, {})
        new_success = stats['success_count'] - before.get('success_count', 0)
        new_failures = stats['failure_count'] - before.get('failure_count', 0)
        
        if new_success > 0 or new_failures > 0:
            logger.info()
                f"{source}: +{new_success} success, +{new_failures} failures"
            )


def demo_price_validation(provider: EnhancedPriceProvider, logger: logging.Logger):
    """Demonstrate price validation across sources"""
    logger.info("\n=== Price Validation Demo ===")
    
    # Clear cache to force fresh fetches
    provider.clear_cache()
    
    # Get price for a liquid stock from multiple sources
    symbol = 'AAPL'
    logger.info(f"Fetching {symbol} from all available sources...")
    
    # Temporarily set high deviation threshold to see all prices
    original_deviation = provider.max_price_deviation
    provider.max_price_deviation = 1.0  # 100% to see all prices
    
    price_data = provider.get_price(symbol, use_cache=False)
    
    # Restore original setting
    provider.max_price_deviation = original_deviation
    
    if price_data:
        logger.info(f"\nFinal validated price: ${price_data.price:.2f}")
        logger.info(f"Confidence: {price_data.confidence:.2%}")
        logger.info(f"Sources used: {price_data.source}")


def demo_cache_performance(provider: EnhancedPriceProvider, logger: logging.Logger):
    """Demonstrate cache performance benefits"""
    logger.info("\n=== Cache Performance Demo ===")
    
    symbol = 'SPY'
    iterations = 5
    
    # Clear cache first
    provider.clear_cache()
    
    # First call (no cache)
    start = time.time()
    price1 = provider.get_price(symbol)
    time_no_cache = time.time() - start
    
    logger.info(f"First call (no cache): {time_no_cache*1000:.1f}ms")
    
    # Subsequent calls (with cache)
    cache_times = []
    for i in range(iterations):
        start = time.time()
        price = provider.get_price(symbol)
        cache_times.append(time.time() - start)
        time.sleep(0.1)
    
    avg_cache_time = sum(cache_times) / len(cache_times)
    logger.info(f"Cached calls average: {avg_cache_time*1000:.1f}ms")
    logger.info(f"Speedup: {time_no_cache/avg_cache_time:.1f}x")
    
    # Show cache statistics
    stats = provider.get_stats()
    logger.info(f"Current cache size: {stats['cache_size']} symbols")


def main():
    """Main demo function"""
    # Setup
    logger = setup_logging()
    logger.info("Starting Enhanced Price Provider Demo")
    
    # Load API keys
    api_keys = load_api_keys()
    
    # Configure provider
    config = {}
        **api_keys,
        'cache_ttl_seconds': 60,
        'max_price_deviation': 0.05,  # 5% maximum deviation
        'min_sources_for_confidence': 2,
        'reference_prices': {}
            'AAPL': 150.0,
            'MSFT': 400.0,
            'GOOGL': 140.0,
            'AMZN': 170.0,
            'TSLA': 250.0
        }
    }
    
    # Initialize provider
    provider = EnhancedPriceProvider(config)
    
    # Available data sources
    logger.info("\n=== Available Data Sources ===")
    for source in provider.sources:
        logger.info(f"- {source.name} (Priority: {source.priority})")
    
    try:
        # Run demos
        demo_basic_usage(provider, logger)
        demo_bulk_pricing(provider, logger)
        demo_market_hours_handling(provider, logger)
        demo_source_failover(provider, logger)
        demo_price_validation(provider, logger)
        demo_cache_performance(provider, logger)
        
        # Final statistics
        logger.info("\n=== Final Statistics ===")
        stats = provider.get_stats()
        
        logger.info("\nSource Performance Summary:")
        for source, source_stats in stats['sources'].items():
            if source_stats['success_count'] > 0:
                success_rate = (source_stats['success_count'] /)
                               (source_stats['success_count'] + source_stats['failure_count']) * 100)
                logger.info()
                    f"{source}: "
                    f"{source_stats['success_count']} successes, "
                    f"{source_stats['failure_count']} failures "
                    f"({success_rate:.1f}% success rate)"
                )
                
        # Symbol statistics
        if stats['symbols']:
            logger.info("\nPer-Symbol Statistics:")
            for symbol, symbol_stats in list(stats['symbols'].items()[:10]:
                logger.info(f"{symbol}: {symbol_stats}")
                
    except KeyboardInterrupt:
        logger.info("\nDemo interrupted by user")
    except Exception as e:
        logger.error(f"Demo error: {e}", exc_info=True)
    finally:
        logger.info("\nDemo completed")


if __name__ == "__main__":
    main()