#!/usr/bin/env python3
"""
MONITORING INTEGRATION MODULE
============================

This module integrates comprehensive monitoring and logging into all existing
trading system components. It provides decorators, mixins, and utilities to
add monitoring capabilities without modifying core business logic.
"""

import functools
import inspect
import time
import asyncio
from typing import Any, Callable, Dict, Optional, Type
from datetime import datetime

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


from comprehensive_monitoring_system import ()

class MonitoringIntegration:]

    get_monitoring_system,
    get_trading_monitor,
    MonitoredLogger,
    CorrelationContext
)

# Get global monitoring instances
monitoring_system = get_monitoring_system()
trading_monitor = get_trading_monitor()

class MonitoringMixin:
    """Mixin class to add monitoring capabilities to any class"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Create a logger for this class
        self.monitor_logger = MonitoredLogger(self.__class__.__name__)
        
        # Auto-instrument all public methods
        self._instrument_methods()
    
    def _instrument_methods(self):
        """Automatically instrument all public methods with monitoring"""
        for name, method in inspect.getmembers(self, predicate=inspect.ismethod):
            if not name.startswith('_'):  # Only public methods
                # Wrap the method with monitoring
                setattr(self, name, self._monitor_method(method)
    
    def _monitor_method(self, method: Callable) -> Callable:
        """Wrap a method with monitoring"""
        @functools.wraps(method)
        def sync_wrapper(*args, **kwargs):
            method_name = f"{self.__class__.__name__}.{method.__name__}"
            
            with monitoring_system.track_request(method_name) as correlation_id:
                self.monitor_logger.info(f"Calling {method_name}",
                                       method=method_name,
                                       args_count=len(args),
                                       kwargs_keys=list(kwargs.keys())
                
                try:
                    result = method(*args, **kwargs)
                    self.monitor_logger.info(f"Completed {method_name}",
                                           method=method_name,
                                           success=True)
                    return result
                except Exception as e:
                    self.monitor_logger.error(f"Failed {method_name}",
                                            method=method_name,
                                            error=str(e),
                                            error_type=type(e).__name__)
                    raise
        
        @functools.wraps(method)
        async def async_wrapper(*args, **kwargs):
            method_name = f"{self.__class__.__name__}.{method.__name__}"
            
            with monitoring_system.track_request(method_name) as correlation_id:
                self.monitor_logger.info(f"Calling {method_name}",
                                       method=method_name,
                                       args_count=len(args),
                                       kwargs_keys=list(kwargs.keys())
                
                try:
                    result = await method(*args, **kwargs)
                    self.monitor_logger.info(f"Completed {method_name}",
                                           method=method_name,
                                           success=True)
                    return result
                except Exception as e:
                    self.monitor_logger.error(f"Failed {method_name}",
                                            method=method_name,
                                            error=str(e),
                                            error_type=type(e).__name__)
                    raise
        
        return async_wrapper if asyncio.iscoroutinefunction(method) else sync_wrapper

def monitor_class(cls: Type) -> Type:
    """Class decorator to add monitoring to all methods of a class"""
    
    # Create a new class that inherits from MonitoringMixin and the original class
    class MonitoredClass(MonitoringMixin, cls):
        pass
    
    # Preserve the original class name and module
    MonitoredClass.__name__ = cls.__name__
    MonitoredClass.__module__ = cls.__module__
    MonitoredClass.__qualname__ = cls.__qualname__
    
    return MonitoredClass

def monitor_api_call(endpoint: str, method: str = "GET"):
    """Decorator to monitor API calls"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            
            with monitoring_system.track_request(f"api_call.{endpoint}",
                                               endpoint=endpoint,
                                               method=method) as correlation_id:
                try:
                    result = await func(*args, **kwargs)
                    duration = time.time() - start_time
                    
                    # Extract status code if available
                    status = getattr(result, 'status', 200) if hasattr(result, 'status') else 200
                    
                    monitoring_system.metrics.record_api_request()
                        endpoint, method, status, duration
                    )
                    
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    monitoring_system.metrics.record_api_request()
                        endpoint, method, 500, duration
                    )
                    raise
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            
            with monitoring_system.track_request(f"api_call.{endpoint}",
                                               endpoint=endpoint,
                                               method=method) as correlation_id:
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    
                    # Extract status code if available
                    status = getattr(result, 'status_code', 200) if hasattr(result, 'status_code') else 200
                    
                    monitoring_system.metrics.record_api_request()
                        endpoint, method, status, duration
                    )
                    
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    monitoring_system.metrics.record_api_request()
                        endpoint, method, 500, duration
                    )
                    raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    
    return decorator

def monitor_trading_operation(operation_type: str):
    """Decorator specifically for trading operations"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Extract relevant information from args/kwargs
            symbol = kwargs.get('symbol', args[1] if len(args) > 1 else 'UNKNOWN')
            quantity = kwargs.get('quantity', args[2] if len(args) > 2 else 0)
            
            with monitoring_system.track_request(f"trading.{operation_type}",
                                               operation=operation_type,
                                               symbol=symbol,
                                               quantity=quantity) as correlation_id:
                
                # Audit log the trading operation
                trading_monitor.monitoring.audit_trading_action()
                    operation_type,
                    {}
                        'function': func.__name__,
                        'symbol': symbol,
                        'quantity': quantity,
                        'timestamp': datetime.utcnow().isoformat(),
                        'correlation_id': correlation_id
                    }
                )
                
                try:
                    result = func(*args, **kwargs)
                    
                    # Log successful operation
                    monitoring_system.logger.info(f"Trading operation completed",
                                                operation=operation_type,
                                                symbol=symbol,
                                                quantity=quantity,
                                                success=True)
                    
                    return result
                except Exception as e:
                    # Log failed operation
                    monitoring_system.logger.error(f"Trading operation failed",
                                                 operation=operation_type,
                                                 symbol=symbol,
                                                 quantity=quantity,
                                                 error=str(e)
                    
                    monitoring_system.metrics.record_error()
                        type(e).__name__,
                        f"trading_{operation_type}"
                    )
                    raise
        
        return wrapper
    
    return decorator

def monitor_ml_prediction(model_name: str):
    """Decorator for ML model predictions"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with monitoring_system.track_request(f"ml_prediction.{model_name}",
                                               model=model_name) as correlation_id:
                
                start_time = time.time()
                
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    
                    # Extract prediction details if available
                    prediction_type = 'unknown'
                    confidence = 0.0
                    
                    if isinstance(result, dict):
                        prediction_type = result.get('type', 'unknown')
                        confidence = result.get('confidence', 0.0)
                    
                    # Record prediction metrics
                    monitoring_system.metrics.record_model_prediction()
                        model_name, prediction_type
                    )
                    
                    monitoring_system.logger.info(f"ML prediction completed",
                                                model=model_name,
                                                prediction_type=prediction_type,
                                                confidence=confidence,
                                                duration_ms=duration * 1000)
                    
                    return result
                except Exception as e:
                    monitoring_system.logger.error(f"ML prediction failed",
                                                 model=model_name,
                                                 error=str(e)
                    raise
        
        return wrapper
    
    return decorator

class MonitoredOrderExecutor:
    """Wrapper for order executors with comprehensive monitoring"""
    
    def __init__(self, executor):
        self.executor = executor
        self.logger = MonitoredLogger(f"OrderExecutor.{executor.__class__.__name__}")
    
    @monitor_trading_operation("place_order")
    def place_order(self, symbol: str, quantity: float, order_type: str, 
                   side: str, **kwargs) -> Dict:
        """Place order with monitoring"""
        
        with trading_monitor.monitor_order_execution()
            order_type, symbol, side, quantity
        ) as order_id:
            
            # Add order_id to kwargs
            kwargs['client_order_id'] = order_id
            
            # Execute the order
            result = self.executor.place_order()
                symbol, quantity, order_type, side, **kwargs
            )
            
            # Record order metrics
            monitoring_system.metrics.record_order(order_type, side, 'placed')
            
            return result
    
    def cancel_order(self, order_id: str) -> bool:
        """Cancel order with monitoring"""
        with monitoring_system.track_request("order_cancellation",
                                           order_id=order_id):
            
            result = self.executor.cancel_order(order_id)
            
            # Audit log cancellation
            trading_monitor.monitoring.audit_trading_action()
                "ORDER_CANCELLED",
                {}
                    'order_id': order_id,
                    'success': result,
                    'timestamp': datetime.utcnow().isoformat()
                }
            )
            
            return result

class MonitoredDataProvider:
    """Wrapper for data providers with monitoring"""
    
    def __init__(self, provider):
        self.provider = provider
        self.logger = MonitoredLogger(f"DataProvider.{provider.__class__.__name__}")
    
    @monitor_api_call("market_data/bars", "GET")
    def get_bars(self, symbol: str, timeframe: str, start: str, end: str, **kwargs):
        """Get market data bars with monitoring"""
        self.logger.info(f"Fetching bars for {symbol}",
                        symbol=symbol,
                        timeframe=timeframe,
                        date_range=f"{start} to {end}")
        
        return self.provider.get_bars(symbol, timeframe, start, end, **kwargs)
    
    @monitor_api_call("market_data/quote", "GET")
    def get_latest_quote(self, symbol: str):
        """Get latest quote with monitoring"""
        return self.provider.get_latest_quote(symbol)

class MonitoredBacktester:
    """Wrapper for backtesting with comprehensive monitoring"""
    
    def __init__(self, backtester):
        self.backtester = backtester
        self.logger = MonitoredLogger(f"Backtester.{backtester.__class__.__name__}")
    
    def run_backtest(self, strategy: str, start_date: str, end_date: str, 
                    config: Dict) -> Dict:
        """Run backtest with monitoring"""
        
        with monitoring_system.track_request("backtest_execution",
                                           strategy=strategy,
                                           start_date=start_date,
                                           end_date=end_date) as correlation_id:
            
            self.logger.info(f"Starting backtest",
                           strategy=strategy,
                           date_range=f"{start_date} to {end_date}",
                           config=config)
            
            # Run the backtest
            results = self.backtester.run_backtest()
                strategy, start_date, end_date, config
            )
            
            # Monitor results
            trading_monitor.monitor_backtest()
                strategy, start_date, end_date, results
            )
            
            return results

# Integration helper functions

def integrate_monitoring_with_orchestrator(orchestrator):
    """Integrate monitoring with the master orchestrator"""
    
    # Add monitoring mixin
    if not hasattr(orchestrator, 'monitor_logger'):
        orchestrator.monitor_logger = MonitoredLogger('MasterOrchestrator')
    
    # Register health checks
    monitoring_system.register_health_check()
        'orchestrator_status',
        lambda: {}
            'running': orchestrator.running,
            'active_systems': len(orchestrator.processes),
            'uptime': getattr(orchestrator, 'uptime', 'unknown')
        }
    )
    
    # Wrap key methods
    original_start = orchestrator.start_system
    
    def monitored_start_system(system_config):
        with monitoring_system.track_request(f"start_system.{system_config['name']}"):
            return original_start(system_config)
    
    orchestrator.start_system = monitored_start_system
    
    return orchestrator

def integrate_monitoring_with_trading_system(trading_system):
    """Integrate monitoring with a trading system"""
    
    # Wrap order executor
    if hasattr(trading_system, 'order_executor'):
        trading_system.order_executor = MonitoredOrderExecutor()
            trading_system.order_executor
        )
    
    # Wrap data provider
    if hasattr(trading_system, 'data_provider'):
        trading_system.data_provider = MonitoredDataProvider()
            trading_system.data_provider
        )
    
    # Add monitoring logger
    if not hasattr(trading_system, 'monitor_logger'):
        trading_system.monitor_logger = MonitoredLogger()
            trading_system.__class__.__name__
        )
    
    return trading_system

def create_monitoring_dashboard():
    """Create a simple monitoring dashboard endpoint"""
    from flask import Flask, jsonify
    
    app = Flask(__name__)
    
    @app.route('/metrics')
    def metrics():
        """Prometheus metrics endpoint"""
        return monitoring_system.metrics.get_metrics(), 200, {}
            'Content-Type': 'text/plain; charset=utf-8'
        }
    
    @app.route('/health')
    async def health():
        """Health check endpoint"""
        results = await monitoring_system.run_health_checks()
        status_code = 200 if results['status'] == 'healthy' else 503
        return jsonify(results), status_code
    
    @app.route('/logs/recent')
    def recent_logs():
        """Get recent logs"""
        # This would read from the log file or log buffer
        return jsonify({)
            'logs': 'Recent logs would be here',
            'timestamp': datetime.utcnow().isoformat()
        })
    
    return app

# Example of how to use the monitoring integration
if __name__ == "__main__":
    
    # Example 1: Monitor a simple function
    @monitoring_system.monitor_function
    def calculate_portfolio_value(positions: Dict[str, float], prices: Dict[str, float]) -> float:
        return sum(positions[symbol] * prices[symbol] for symbol in positions)
    
    # Example 2: Monitor a class
    @monitor_class
    class TradingStrategy:
        def analyze_market(self, symbol: str):
            return {'signal': 'buy', 'confidence': 0.8}
        
        def execute_trade(self, symbol: str, signal: str):
            return {'order_id': '12345', 'status': 'placed'}
    
    # Example 3: Use monitoring in existing code
    strategy = TradingStrategy()
    
    # This will be automatically monitored
    result = strategy.analyze_market('AAPL')
    print(f"Analysis result: {result}")
    
    # Example 4: Manual monitoring
    with monitoring_system.track_request('custom_operation', 
                                       custom_tag='example') as correlation_id:
        print(f"Performing custom operation with correlation ID: {correlation_id}")
        time.sleep(0.1)
        print("Custom operation completed")
    
    print("\nMonitoring integration examples completed.")