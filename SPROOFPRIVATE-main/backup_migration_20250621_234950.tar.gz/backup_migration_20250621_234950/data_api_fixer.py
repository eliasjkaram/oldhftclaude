
#!/usr/bin/env python3
"""
Comprehensive Data API Fixer
============================

A robust solution that fixes all data processing and API issues:
1. Fixes yfinance API errors (JSON parsing, timezone issues)
2. Implements proper Alpaca API integration with error handling
3. Adds MinIO data fallback when APIs fail
4. Creates robust data validation and cleaning
5. Implements rate limiting to prevent API throttling
6. Adds caching to reduce API calls
7. Creates a unified data interface that handles all sources
8. Adds retry logic with exponential backoff

Author: AI Assistant
Date: 2025-01-11
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
import json
import time
import logging
import asyncio
import aiohttp
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Union, Tuple, Any
from pathlib import Path
from functools import wraps, lru_cache
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import pytz
import warnings
warnings.filterwarnings('ignore')

# Import MinIO client
try:
    from minio import Minio
    from minio.error import S3Error
    MINIO_AVAILABLE = True
except ImportError:
    MINIO_AVAILABLE = False
    print("Warning: MinIO not available. Install with: pip install minio")

# Import Alpaca client
try:
    from alpaca.trading.client import TradingClient
    ALPACA_AVAILABLE = True
except ImportError:
    ALPACA_AVAILABLE = False
    print("Warning: Alpaca not available. Install with: pip install alpaca-trade-api")

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('data_api_fixer.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class RateLimiter:
    """Rate limiter to prevent API throttling"""
    
    def __init__(self, calls_per_minute: int = 60, calls_per_hour: int = 3000):
        self.calls_per_minute = calls_per_minute
        self.calls_per_hour = calls_per_hour
        self.minute_calls = defaultdict(int)
        self.hour_calls = defaultdict(int)
        self.lock = asyncio.Lock() if asyncio.get_event_loop().is_running() else None
        
    def can_make_request(self) -> bool:
        """Check if request can be made"""
        now = datetime.now()
        current_minute = now.strftime("%Y-%m-%d %H:%M")
        current_hour = now.strftime("%Y-%m-%d %H")
        
        # Check minute limit
        if self.minute_calls[current_minute] >= self.calls_per_minute:
            return False
            
        # Check hour limit
        if self.hour_calls[current_hour] >= self.calls_per_hour:
            return False
            
        return True
        
    def record_request(self):
        """Record a request"""
        now = datetime.now()
        current_minute = now.strftime("%Y-%m-%d %H:%M")
        current_hour = now.strftime("%Y-%m-%d %H")
        
        self.minute_calls[current_minute] += 1
        self.hour_calls[current_hour] += 1
        
        # Clean old entries
        self._cleanup_old_entries()
        
    def _cleanup_old_entries(self):
        """Remove old entries to prevent memory bloat"""
        now = datetime.now()
        cutoff_minute = (now - timedelta(minutes=2)).strftime("%Y-%m-%d %H:%M")
        cutoff_hour = (now - timedelta(hours=2)).strftime("%Y-%m-%d %H")
        
        # Remove old minute entries
        old_minutes = [k for k in self.minute_calls.keys() if k < cutoff_minute]
        for k in old_minutes:
            del self.minute_calls[k]
            
        # Remove old hour entries
        old_hours = [k for k in self.hour_calls.keys() if k < cutoff_hour]
        for k in old_hours:
            del self.hour_calls[k]


def retry_with_backoff(max_retries: int = 3, initial_delay: float = 1.0, 
                      backoff_factor: float = 2.0, max_delay: float = 60.0):
    """Decorator for retry logic with exponential backoff"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            delay = initial_delay
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        sleep_time = min(delay, max_delay)
                        logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {sleep_time:.1f}s...")
                        time.sleep(sleep_time)
                        delay *= backoff_factor
                    else:
                        logger.error(f"All {max_retries} attempts failed for {func.__name__}")
                        
            raise last_exception
        return wrapper
    return decorator


class DataCache:
    """In-memory cache with TTL support"""
    
    def __init__(self, default_ttl: int = 300):  # 5 minutes default
        self.cache = {}
        self.timestamps = {}
        self.default_ttl = default_ttl
        
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache if not expired"""
        if key in self.cache:
            timestamp = self.timestamps[key]
            if (datetime.now() - timestamp).total_seconds() < self.default_ttl:
                return self.cache[key]
            else:
                # Remove expired entry
                del self.cache[key]
                del self.timestamps[key]
        return None
        
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set value in cache with TTL"""
        self.cache[key] = value
        self.timestamps[key] = datetime.now()
        
    def clear(self):
        """Clear all cache entries"""
        self.cache.clear()
        self.timestamps.clear()


class UnifiedDataAPI:
    """Unified data interface that handles all sources"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the unified data API
        
        Args:
            config: Configuration dictionary with API keys and settings
        """
        self.config = config or self._load_default_config()
        
        # Initialize components
        self.rate_limiter = RateLimiter()
            calls_per_minute=self.config.get('rate_limit_per_minute', 60),
            calls_per_hour=self.config.get('rate_limit_per_hour', 3000)
        )
        
        self.cache = DataCache(default_ttl=self.config.get('cache_ttl', 300))
        
        # Initialize data sources
        self._init_yfinance()
        self._init_alpaca()
        self._init_minio()
        
        # Session for HTTP requests
        self.session = self._create_session()
        
        # Timezone handling
        self.market_tz = pytz.timezone('America/New_York')
        self.utc_tz = pytz.UTC
        
    def _load_default_config(self) -> Dict:
        """Load default configuration"""
        config = {}
            'cache_ttl': 300,  # 5 minutes
            'rate_limit_per_minute': 60,
            'rate_limit_per_hour': 3000,
            'max_retries': 3,
            'retry_delay': 1.0,
            'backoff_factor': 2.0,
            'timeout': 30,
            'yfinance_enabled': True,
            'alpaca_enabled': False,
            'minio_enabled': False
        }
        
        # Try to load from environment or config file
        config_file = Path('data_api_config.json')
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    file_config = json.load(f)
                    config.update(file_config)
            except Exception as e:
                logger.warning(f"Could not load config file: {e}")
                
        # Environment variables override
        if os.getenv('ALPACA_API_KEY'):
            config['alpaca_api_key'] = os.getenv('ALPACA_API_KEY')
            config['alpaca_secret_key'] = os.getenv('ALPACA_SECRET_KEY')
            config['alpaca_base_url'] = os.getenv('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')
            config['alpaca_enabled'] = True
            
        if os.getenv('MINIO_ENDPOINT'):
            config['minio_endpoint'] = os.getenv('MINIO_ENDPOINT')
            config['minio_access_key'] = os.getenv('MINIO_ACCESS_KEY')
            config['minio_secret_key'] = os.getenv('MINIO_SECRET_KEY')
            config['minio_bucket'] = os.getenv('MINIO_BUCKET', 'stockdb')
            config['minio_secure'] = os.getenv('MINIO_SECURE', 'True').lower() == 'true'
            config['minio_enabled'] = True
            
        return config
        
    def _create_session(self) -> requests.Session:
        """Create HTTP session with retry logic"""
        session = requests.Session()
        
        retry_strategy = Retry()
            total=self.config.get('max_retries', 3),
            backoff_factor=self.config.get('backoff_factor', 2.0),
            status_forcelist=[429, 500, 502, 503, 504],
            method_whitelist=["HEAD", "GET", "OPTIONS", "POST"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        
        return session
        
    def _init_yfinance(self):
        """Initialize yfinance with custom settings"""
        # Set yfinance session to use our session with retries
        yf.set_tz_cache_location("./yfinance_cache")
        
    def _init_alpaca(self):
        """Initialize Alpaca API client"""
        self.alpaca_client = None
        
        if ALPACA_AVAILABLE and self.config.get('alpaca_enabled'):
            try:
                self.alpaca_client = TradingClient(self.config.get('alpaca_api_key'), self.config.get('alpaca_secret_key'), paper=True)
                # Test connection
                self.alpaca_client.get_account()
                logger.info("Alpaca API initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize Alpaca API: {e}")
                self.alpaca_client = None
                
    def _init_minio(self):
        """Initialize MinIO client"""
        self.minio_client = None
        
        if MINIO_AVAILABLE and self.config.get('minio_enabled'):
            try:
                self.minio_client = Minio()
                    self.config.get('minio_endpoint'),
                    access_key=self.config.get('minio_access_key'),
                    secret_key=self.config.get('minio_secret_key'),
                    secure=self.config.get('minio_secure', True)
                )
                # Test connection
                self.minio_client.list_buckets()
                logger.info("MinIO client initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize MinIO client: {e}")
                self.minio_client = None
                
    @retry_with_backoff(max_retries=3)
    def fetch_data(self, symbol: str, start_date: Optional[datetime] = None,
                   end_date: Optional[datetime] = None, interval: str = '1d',
                   source: str = 'auto') -> pd.DataFrame:
        """
        Fetch data from available sources with fallback
        
        Args:
            symbol: Stock symbol
            start_date: Start date for data
            end_date: End date for data
            interval: Data interval (1m, 5m, 15m, 30m, 60m, 1h, 1d, 1wk, 1mo)
            source: Data source (auto, yfinance, alpaca, minio)
            
        Returns:
            DataFrame with OHLCV data
        """
        # Generate cache key
        cache_key = f"{symbol}_{interval}_{start_date}_{end_date}_{source}"
        
        # Check cache first
        cached_data = self.cache.get(cache_key)
        if cached_data is not None:
            logger.info(f"Using cached data for {symbol}")
            return cached_data
            
        # Check rate limit
        if not self.rate_limiter.can_make_request():
            logger.warning("Rate limit reached, waiting...")
            time.sleep(2)  # Wait a bit before retry
            
        # Set default dates if not provided
        if end_date is None:
            end_date = datetime.now()
        if start_date is None:
            if interval in ['1m', '5m', '15m', '30m']:
                start_date = end_date - timedelta(days=7)  # 7 days for intraday
            elif interval in ['60m', '1h']:
                start_date = end_date - timedelta(days=30)  # 30 days for hourly
            else:
                start_date = end_date - timedelta(days=365)  # 1 year for daily
                
        # Determine sources to try
        if source == 'auto':
            sources = []
            if self.config.get('yfinance_enabled', True):
                sources.append('yfinance')
            if self.alpaca_client and self.config.get('alpaca_enabled', False):
                sources.append('alpaca')
            if self.minio_client and self.config.get('minio_enabled', False):
                sources.append('minio')
            sources.append('synthetic')  # Always have synthetic as fallback
        else:
            sources = [source]
            
        # Try each source
        last_error = None
        for data_source in sources:
            try:
                logger.info(f"Fetching {symbol} from {data_source}...")
                
                if data_source == 'yfinance':
                    data = self._fetch_yfinance(symbol, start_date, end_date, interval)
                elif data_source == 'alpaca':
                    data = self._fetch_alpaca(symbol, start_date, end_date, interval)
                elif data_source == 'minio':
                    data = self._fetch_minio(symbol, start_date, end_date, interval)
                elif data_source == 'synthetic':
                    data = self._generate_synthetic_data(symbol, start_date, end_date, interval)
                else:
                    raise ValueError(f"Unknown data source: {data_source}")
                    
                if data is not None and not data.empty:
                    # Validate and clean data
                    data = self._validate_and_clean_data(data, symbol)
                    
                    # Cache the result
                    self.cache.set(cache_key, data)
                    
                    # Record the request
                    self.rate_limiter.record_request()
                    
                    logger.info(f"Successfully fetched {len(data)} rows for {symbol} from {data_source}")
                    return data
                    
            except Exception as e:
                last_error = e
                logger.warning(f"Failed to fetch from {data_source}: {e}")
                continue
                
        # If all sources failed, raise the last error
        raise ValueError(f"Failed to fetch data for {symbol} from any source. Last error: {last_error}")
        
    def _fetch_yfinance(self, symbol: str, start_date: datetime, 
                       end_date: datetime, interval: str) -> pd.DataFrame:
        """Fetch data from yfinance with enhanced error handling"""
        try:
            # Convert interval format
            interval_map = {}
                '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m',
                '60m': '60m', '1h': '60m', '1d': '1d', '1wk': '1wk', '1mo': '1mo'
            }
            yf_interval = interval_map.get(interval, interval)
            
            # Create ticker object
            ticker = yf.Ticker(symbol)
            
            # Handle timezone properly
            if start_date.tzinfo is None:
                start_date = self.market_tz.localize(start_date)
            if end_date.tzinfo is None:
                end_date = self.market_tz.localize(end_date)
                
            # Fetch data with timeout
            df = ticker.history()
                start=start_date,
                end=end_date,
                interval=yf_interval,
                prepost=True,
                actions=True,
                auto_adjust=True,
                back_adjust=False,
                repair=True,
                keepna=False,
                proxy=None,
                rounding=True,
                timeout=self.config.get('timeout', 30)
            )
            
            if df.empty:
                raise ValueError(f"No data returned from yfinance for {symbol}")
                
            # Standardize column names
            df.columns = [col.lower() for col in df.columns]
            
            # Ensure timezone aware index
            if df.index.tz is None:
                df.index = df.index.tz_localize(self.market_tz)
                
            return df
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error in yfinance: {e}")
            raise ValueError(f"yfinance returned invalid JSON for {symbol}")
        except Exception as e:
            logger.error(f"Error fetching from yfinance: {e}")
            raise
            
    def _fetch_alpaca(self, symbol: str, start_date: datetime,
                     end_date: datetime, interval: str) -> pd.DataFrame:
        """Fetch data from Alpaca API"""
        if not self.alpaca_client:
            raise ValueError("Alpaca client not initialized")
            
        try:
            # Convert interval to Alpaca timeframe
            timeframe_map = {}
                '1m': '1Min', '5m': '5Min', '15m': '15Min', '30m': '30Min',
                '60m': '1Hour', '1h': '1Hour', '1d': '1Day', '1wk': '1Week'
            }
            timeframe = timeframe_map.get(interval)
            if not timeframe:
                raise ValueError(f"Unsupported interval for Alpaca: {interval}")
                
            # Ensure timezone aware
            if start_date.tzinfo is None:
                start_date = self.market_tz.localize(start_date)
            if end_date.tzinfo is None:
                end_date = self.market_tz.localize(end_date)
                
            # Fetch bars
            bars = self.alpaca_client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=timeframe, start=start_date.isoformat(),
                end=end_date.isoformat(),
                adjustment='raw',
                asof=None,
                feed=None,
                page_limit=10000
            )).df
            
            if bars.empty:
                raise ValueError(f"No data returned from Alpaca for {symbol}")
                
            # Ensure timezone aware index
            if bars.index.tz is None:
                bars.index = bars.index.tz_localize('UTC').tz_convert(self.market_tz)
                
            return bars
            
        except Exception as e:
            logger.error(f"Error fetching from Alpaca: {e}")
            raise
            
    def _fetch_minio(self, symbol: str, start_date: datetime,
                    end_date: datetime, interval: str) -> pd.DataFrame:
        """Fetch data from MinIO storage"""
        if not self.minio_client:
            raise ValueError("MinIO client not initialized")
            
        try:
            bucket_name = self.config.get('minio_bucket', 'stockdb')
            
            # Construct object name based on date range
            year = start_date.year
            object_name = f"historical/{year}/{symbol}.csv"
            
            # Download object
            response = self.minio_client.get_object(bucket_name, object_name)
            
            # Read CSV data
            df = pd.read_csv(response)
            response.close()
            response.release_conn()
            
            # Parse dates and set index
            date_col = None
            for col in ['Date', 'date', 'Datetime', 'datetime', 'timestamp']:
                if col in df.columns:
                    date_col = col
                    break
                    
            if date_col:
                df[date_col] = pd.to_datetime(df[date_col])
                df = df.set_index(date_col)
                
            # Filter by date range
            if df.index.tz is None:
                df.index = df.index.tz_localize(self.market_tz)
                
            df = df[(df.index >= start_date) & (df.index <= end_date)]
            
            # Resample if needed
            if interval != '1d':
                df = self._resample_data(df, interval)
                
            return df
            
        except S3Error as e:
            logger.error(f"MinIO S3 error: {e}")
            raise
        except Exception as e:
            logger.error(f"Error fetching from MinIO: {e}")
            raise
            
    def _generate_synthetic_data(self, symbol: str, start_date: datetime,
                                end_date: datetime, interval: str) -> pd.DataFrame:
        """Generate synthetic data as fallback"""
        logger.info(f"Generating synthetic data for {symbol}")
        
        # Determine frequency
        freq_map = {}
            '1m': 'T', '5m': '5T', '15m': '15T', '30m': '30T',
            '60m': 'H', '1h': 'H', '1d': 'D', '1wk': 'W', '1mo': 'M'
        }
        freq = freq_map.get(interval, 'D')
        
        # Generate date range
        dates = pd.date_range(start=start_date, end=end_date, freq=freq)
        
        # Generate realistic price movement
        np.random.seed(hash(symbol) % 2**32)
        
        # Base price based on symbol characteristics
        if symbol in ['SPY', 'QQQ', 'IWM']:
            base_price = 400 + np.random.uniform(-50, 50)
            volatility = 0.015
        elif symbol in ['AAPL', 'MSFT', 'GOOGL', 'AMZN']:
            base_price = 150 + np.random.uniform(-30, 30)
            volatility = 0.02
        else:
            base_price = 50 + np.random.uniform(-20, 20)
            volatility = 0.025
            
        # Generate returns
        returns = np.random.normal(0.0001, volatility, len(dates))
        
        # Add trend
        trend = np.linspace(0, np.random.uniform(-0.1, 0.1), len(dates))
        returns += trend / len(dates)
        
        # Generate prices
        prices = base_price * np.exp(np.cumsum(returns))
        
        # Generate OHLCV
        data = []
        for i, (date, price) in enumerate(zip(dates, prices)):
            daily_vol = volatility * np.random.uniform(0.5, 1.5)
            
            open_price = price * (1 + np.random.uniform(-daily_vol/2, daily_vol/2))
            close_price = price
            high_price = max(open_price, close_price) * (1 + np.random.uniform(0, daily_vol))
            low_price = min(open_price, close_price) * (1 - np.random.uniform(0, daily_vol))
            
            volume = int(1000000 * np.random.lognormal(0, 0.5))
            
            data.append({)
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'volume': volume
            })
            
        df = pd.DataFrame(data, index=dates)
        
        # Ensure timezone aware
        if df.index.tz is None:
            df.index = df.index.tz_localize(self.market_tz)
            
        return df
        
    def _validate_and_clean_data(self, df: pd.DataFrame, symbol: str) -> pd.DataFrame:
        """Validate and clean data"""
        if df.empty:
            return df
            
        # Ensure numeric columns
        numeric_columns = ['open', 'high', 'low', 'close', 'volume']
        for col in numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
                
        # Remove rows with all NaN values
        df = df.dropna(how='all')
        
        # Forward fill missing values
        df = df.fillna(method='ffill')
        
        # Validate OHLC relationships
        if all(col in df.columns for col in ['open', 'high', 'low', 'close']):
            # High should be >= max(open, close)
            df['high'] = df[['high', 'open', 'close']].max(axis=1)
            
            # Low should be <= min(open, close)
            df['low'] = df[['low', 'open', 'close']].min(axis=1)
            
            # Remove rows with invalid prices
            df = df[(df['high'] >= df['low']) & (df['low'] > 0)]
            
        # Check for extreme price changes
        if 'close' in df.columns and len(df) > 1:
            price_changes = df['close'].pct_change()
            extreme_changes = price_changes.abs() > 0.5  # 50% change
            
            if extreme_changes.any():
                logger.warning(f"Found {extreme_changes.sum()} extreme price changes for {symbol}")
                # You could choose to remove or cap these
                
        # Ensure volume is non-negative
        if 'volume' in df.columns:
            df['volume'] = df['volume'].clip(lower=0)
            
        # Sort by date
        df = df.sort_index()
        
        # Remove duplicate indices
        df = df[~df.index.duplicated(keep='first')]
        
        return df
        
    def _resample_data(self, df: pd.DataFrame, target_interval: str) -> pd.DataFrame:
        """Resample data to target interval"""
        # Resample rules
        resample_map = {}
            '5m': '5T', '15m': '15T', '30m': '30T',
            '60m': 'H', '1h': 'H', '1d': 'D', '1wk': 'W', '1mo': 'M'
        }
        
        rule = resample_map.get(target_interval)
        if not rule:
            return df
            
        # Resample OHLCV data
        resampled = df.resample(rule).agg({)
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        })
        
        return resampled.dropna()
        
    def fetch_multiple_symbols(self, symbols: List[str], start_date: Optional[datetime] = None,
                             end_date: Optional[datetime] = None, interval: str = '1d',
                             parallel: bool = True) -> Dict[str, pd.DataFrame]:
        """
        Fetch data for multiple symbols
        
        Args:
            symbols: List of stock symbols
            start_date: Start date for data
            end_date: End date for data
            interval: Data interval
            parallel: Whether to fetch in parallel
            
        Returns:
            Dictionary mapping symbols to DataFrames
        """
        results = {}
        
        if parallel and len(symbols) > 1:
            # Use thread pool for parallel fetching
            with ThreadPoolExecutor(max_workers=min(10, len(symbols))) as executor:
                futures = {}
                for symbol in symbols:
                    future = executor.submit()
                        self.fetch_data, symbol, start_date, end_date, interval
                    )
                    futures[future] = symbol
                    
                for future in futures:
                    symbol = futures[future]
                    try:
                        data = future.result(timeout=60)
                        results[symbol] = data
                    except Exception as e:
                        logger.error(f"Failed to fetch {symbol}: {e}")
                        results[symbol] = pd.DataFrame()
        else:
            # Sequential fetching
            for symbol in symbols:
                try:
                    data = self.fetch_data(symbol, start_date, end_date, interval)
                    results[symbol] = data
                except Exception as e:
                    logger.error(f"Failed to fetch {symbol}: {e}")
                    results[symbol] = pd.DataFrame()
                    
        return results
        
    def get_latest_price(self, symbol: str) -> Optional[float]:
        """Get latest price for a symbol"""
        try:
            # Try to get 1-minute data for the last trading day
            end_date = datetime.now()
            start_date = end_date - timedelta(days=5)  # Cover weekends
            
            df = self.fetch_data(symbol, start_date, end_date, '1m')
            
            if not df.empty and 'close' in df.columns:
                return float(df['close'].iloc[-1])
                
        except Exception as e:
            logger.error(f"Failed to get latest price for {symbol}: {e}")
            
        return None
        
    def get_options_chain(self, symbol: str, expiration: Optional[str] = None) -> pd.DataFrame:
        """Get options chain data"""
        try:
            ticker = yf.Ticker(symbol)
            
            # Get available expiration dates
            expirations = ticker.options
            
            if not expirations:
                logger.warning(f"No options available for {symbol}")
                return pd.DataFrame()
                
            # Use specified expiration or nearest
            if expiration and expiration in expirations:
                target_exp = expiration
            else:
                target_exp = expirations[0]
                
            # Get options chain
            opt_chain = ticker.option_chain(target_exp)
            
            # Combine calls and puts
            calls = opt_chain.calls.copy()
            calls['type'] = 'call'
            
            puts = opt_chain.puts.copy()
            puts['type'] = 'put'
            
            options = pd.concat([calls, puts], ignore_index=True)
            options['symbol'] = symbol
            options['expiration'] = target_exp
            
            return options
            
        except Exception as e:
            logger.error(f"Failed to get options chain for {symbol}: {e}")
            return pd.DataFrame()
            
    def get_market_status(self) -> Dict[str, Any]:
        """Get current market status"""
        now = datetime.now(self.market_tz)
        
        # Basic market hours (9:30 AM - 4:00 PM ET)
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        # Check if weekend
        is_weekend = now.weekday() >= 5
        
        # Check if market hours
        is_market_hours = market_open <= now <= market_close and not is_weekend
        
        # Check if extended hours (4:00 AM - 8:00 PM ET)
        extended_open = now.replace(hour=4, minute=0, second=0, microsecond=0)
        extended_close = now.replace(hour=20, minute=0, second=0, microsecond=0)
        is_extended_hours = extended_open <= now <= extended_close and not is_weekend
        
        return {}
            'current_time': now.isoformat(),
            'is_open': is_market_hours,
            'is_extended_hours': is_extended_hours,
            'is_weekend': is_weekend,
            'next_open': market_open.isoformat() if now < market_open else (market_open + timedelta(days=1)).isoformat(),
            'next_close': market_close.isoformat() if now < market_close else (market_close + timedelta(days=1)).isoformat()
        }
        
    def health_check(self) -> Dict[str, Any]:
        """Check health of all data sources"""
        health = {}
            'timestamp': datetime.now().isoformat(),
            'sources': {}
        }
        
        # Check yfinance
        try:
            df = self.fetch_data('SPY', source='yfinance')
            health['sources']['yfinance'] = {}
                'status': 'healthy' if not df.empty else 'unhealthy',
                'last_data_point': df.index[-1].isoformat() if not df.empty else None
            }
        except Exception as e:
            health['sources']['yfinance'] = {}
                'status': 'error',
                'error': str(e)
            }
            
        # Check Alpaca
        if self.alpaca_client:
            try:
                account = self.alpaca_client.get_account()
                health['sources']['alpaca'] = {}
                    'status': 'healthy',
                    'account_status': account.status
                }
            except Exception as e:
                health['sources']['alpaca'] = {}
                    'status': 'error',
                    'error': str(e)
                }
        else:
            health['sources']['alpaca'] = {'status': 'disabled'}
            
        # Check MinIO
        if self.minio_client:
            try:
                buckets = self.minio_client.list_buckets()
                health['sources']['minio'] = {}
                    'status': 'healthy',
                    'buckets': len(buckets)
                }
            except Exception as e:
                health['sources']['minio'] = {}
                    'status': 'error',
                    'error': str(e)
                }
        else:
            health['sources']['minio'] = {'status': 'disabled'}
            
        # Overall health
        statuses = [s.get('status', 'unknown') for s in health['sources'].values()]
        if all(s == 'healthy' or s == 'disabled' for s in statuses):
            health['overall_status'] = 'healthy'
        elif any(s == 'error' for s in statuses):
            health['overall_status'] = 'degraded'
        else:
            health['overall_status'] = 'unknown'
            
        return health


def main():
    """Test the unified data API"""
    print("🔧 Testing Unified Data API")
    print("=" * 50)
    
    # Initialize API
    api = UnifiedDataAPI()
    
    # Test health check
    print("\n📊 Health Check:")
    health = api.health_check()
    print(json.dumps(health, indent=2))
    
    # Test market status
    print("\n🕐 Market Status:")
    status = api.get_market_status()
    print(json.dumps(status, indent=2))
    
    # Test single symbol fetch
    print("\n📈 Fetching AAPL data:")
    try:
        df = api.fetch_data('AAPL', interval='1d')
        print(f"  ✅ Fetched {len(df)} rows")
        print(f"  📅 Date range: {df.index[0]} to {df.index[-1]}")
        print(f"  💰 Latest close: ${df['close'].iloc[-1]:.2f}")
    except Exception as e:
        print(f"  ❌ Error: {e}")
        
    # Test multiple symbols
    print("\n📊 Fetching multiple symbols:")
    symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'INVALID_SYMBOL']
    
    results = api.fetch_multiple_symbols(symbols, interval='1d')
    
    for symbol, df in results.items():
        if not df.empty:
            print(f"  ✅ {symbol}: {len(df)} rows, latest close: ${df['close'].iloc[-1]:.2f}")
        else:
            print(f"  ❌ {symbol}: No data")
            
    # Test latest prices
    print("\n💵 Latest prices:")
    for symbol in ['SPY', 'AAPL', 'MSFT']:
        price = api.get_latest_price(symbol)
        if price:
            print(f"  {symbol}: ${price:.2f}")
        else:
            print(f"  {symbol}: N/A")
            
    # Test options chain
    print("\n📊 Options chain for SPY:")
    options = api.get_options_chain('SPY')
    if not options.empty:
        print(f"  ✅ Found {len(options)} options")
        print(f"  📅 Expiration: {options['expiration'].iloc[0]}")
        print(f"  🎯 Strikes: {options['strike'].min():.0f} - {options['strike'].max():.0f}")
    else:
        print("  ❌ No options data")
        
    print("\n✅ Test completed!")
    

if __name__ == "__main__":
    main()