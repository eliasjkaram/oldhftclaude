#!/usr/bin/env python3
"""
V25 Enhanced Algorithm Backtest
Tests the improved algorithms against the original versions
"""

import pandas as pd
import numpy as np
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import json
from datetime import datetime
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

from v24_complete_algorithms_backtest import CompleteAlgorithmSet
from v25_enhanced_algorithms import EnhancedAlgorithms, EnhancedBacktestSystem

class ComparativeBacktest:
    """Compare original vs enhanced algorithm performance"""
    
    def __init__(self):
        # Load configuration
        with open('alpaca_config.json', 'r') as f:
            config = json.load(f)
        
        self.client = TradingClient()
            config.get('paper_api_key'),
            config.get('paper_secret_key'),
            config.get('paper_base_url')
        )
        
        # Initialize algorithm sets
        self.original_algos = CompleteAlgorithmSet()
        self.enhanced_algos = EnhancedAlgorithms()
        self.enhanced_backtest = EnhancedBacktestSystem()
        
    def fetch_data(self, symbol, start_date='2023-01-01', end_date='2023-12-31'):
        """Fetch historical data from Alpaca"""
        print(f"Fetching data for {symbol}...")
        
        bars = self.client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=start_date,
            end=end_date,
            adjustment='raw'
        ).df
        
        if bars.empty:
            print(f"No data found for {symbol}")
            return None
            
        return bars
    
    def run_backtest(self, data, signals, initial_capital=100000):
        """Run backtest with given signals"""
        if data is None or signals is None:
            return None
            
        # Initialize portfolio
        cash = initial_capital
        shares = 0
        trades = []
        portfolio_value = []
        
        for i in range(len(data):
            current_price = data['close'].iloc[i]
            signal = signals.iloc[i] if i < len(signals) else 0
            
            # Calculate current portfolio value
            current_value = cash + shares * current_price
            portfolio_value.append(current_value)
            
            # Execute trades based on signals
            if signal > 0 and cash > current_price:  # Buy signal
                # Buy shares
                shares_to_buy = int(cash * abs(signal) / current_price)
                if shares_to_buy > 0:
                    cost = shares_to_buy * current_price
                    cash -= cost
                    shares += shares_to_buy
                    trades.append({)
                        'date': data.index[i],
                        'action': 'BUY',
                        'shares': shares_to_buy,
                        'price': current_price,
                        'value': cost
                    })
                    
            elif signal < 0 and shares > 0:  # Sell signal
                # Sell shares
                shares_to_sell = int(shares * abs(signal)
                if shares_to_sell > 0:
                    proceeds = shares_to_sell * current_price
                    cash += proceeds
                    shares -= shares_to_sell
                    trades.append({)
                        'date': data.index[i],
                        'action': 'SELL',
                        'shares': shares_to_sell,
                        'price': current_price,
                        'value': proceeds
                    })
        
        # Calculate final metrics
        final_value = portfolio_value[-1] if portfolio_value else initial_capital
        total_return = (final_value - initial_capital) / initial_capital * 100
        
        # Calculate other metrics
        portfolio_series = pd.Series(portfolio_value, index=data.index)
        returns = portfolio_series.pct_change().dropna()
        
        if len(returns) > 0:
            sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0
            max_drawdown = (portfolio_series / portfolio_series.cummax() - 1).min() * 100
        else:
            sharpe_ratio = 0
            max_drawdown = 0
        
        # Win rate
        winning_trades = sum(1 for t in trades if t['action'] == 'SELL' and)
                           any(buy['price'] < t['price'] for buy in trades if buy['action'] == 'BUY')
        total_sell_trades = sum(1 for t in trades if t['action'] == 'SELL')
        win_rate = winning_trades / total_sell_trades * 100 if total_sell_trades > 0 else 0
        
        return {}
            'total_return': total_return,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'num_trades': len(trades),
            'final_value': final_value
        }
    
    def compare_algorithms(self, symbol='AAPL'):
        """Compare original vs enhanced algorithms"""
        # Fetch data
        data = self.fetch_data(symbol)
        if data is None:
            return
        
        print(f"\n{'='*80}")
        print(f"COMPARING ALGORITHMS FOR {symbol}")
        print(f"{'='*80}")
        
        # Algorithms to compare
        algorithms_to_test = []
            'rsi', 'macd', 'bollinger_bands', 'stochastic',
            'mean_reversion', 'momentum', 'ml_ensemble'
        ]
        
        results = []
        
        for algo_base in algorithms_to_test:
            print(f"\n📊 Testing {algo_base.upper()}...")
            
            # Test original algorithm
            original_name = f"{algo_base}_oversold" if algo_base == 'rsi' else algo_base
            if algo_base == 'bollinger_bands':
                original_name = 'bollinger_squeeze'
            elif algo_base == 'stochastic':
                original_name = 'stochastic_oscillator'
            elif algo_base == 'momentum':
                original_name = 'momentum_alpha'
            elif algo_base == 'ml_ensemble':
                original_name = 'ensemble_learning'
            
            # Get original algorithm signals
            if hasattr(self.original_algos, original_name):
                try:
                    original_signals = getattr(self.original_algos, original_name)(data)
                    original_results = self.run_backtest(data, original_signals)
                except Exception as e:
                    print(f"  ❌ Original algorithm error: {e}")
                    original_results = None
            else:
                original_results = None
            
            # Test enhanced algorithm
            enhanced_name = f"enhanced_{algo_base}"
            if hasattr(self.enhanced_algos, enhanced_name):
                try:
                    enhanced_signals = getattr(self.enhanced_algos, enhanced_name)(data)
                    enhanced_results = self.run_backtest(data, enhanced_signals)
                except Exception as e:
                    print(f"  ❌ Enhanced algorithm error: {e}")
                    enhanced_results = None
            else:
                enhanced_results = None
            
            # Compare results
            if original_results and enhanced_results:
                improvement = enhanced_results['total_return'] - original_results['total_return']
                
                result = {}
                    'algorithm': algo_base,
                    'original_return': original_results['total_return'],
                    'enhanced_return': enhanced_results['total_return'],
                    'improvement': improvement,
                    'original_sharpe': original_results['sharpe_ratio'],
                    'enhanced_sharpe': enhanced_results['sharpe_ratio'],
                    'original_trades': original_results['num_trades'],
                    'enhanced_trades': enhanced_results['num_trades']
                }
                results.append(result)
                
                print(f"  Original: {original_results['total_return']:.2f}% return, ")
                      f"Sharpe: {original_results['sharpe_ratio']:.2f}")
                print(f"  Enhanced: {enhanced_results['total_return']:.2f}% return, ")
                      f"Sharpe: {enhanced_results['sharpe_ratio']:.2f}")
                print(f"  ✨ Improvement: {improvement:+.2f}%")
        
        return results
    
    def run_full_comparison(self):
        """Run comparison across multiple symbols"""
        symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'SPY']
        all_results = {}
        
        print("="*80)
        print("🚀 V25 ENHANCED ALGORITHMS PERFORMANCE COMPARISON")
        print("="*80)
        print(f"Testing enhanced algorithms with:")
        print("  • Dynamic parameter optimization")
        print("  • Market regime detection")
        print("  • Multi-timeframe analysis")
        print("  • Risk-adjusted position sizing")
        print("  • Machine learning enhancements")
        print("="*80)
        
        for symbol in symbols:
            results = self.compare_algorithms(symbol)
            all_results[symbol] = results
        
        # Summary statistics
        print("\n" + "="*80)
        print("📈 OVERALL PERFORMANCE IMPROVEMENT SUMMARY")
        print("="*80)
        
        # Calculate average improvements
        total_improvements = []
        sharpe_improvements = []
        
        for symbol, results in all_results.items():
            for result in results:
                if result:
                    total_improvements.append(result['improvement'])
                    sharpe_improvements.append()
                        result['enhanced_sharpe'] - result['original_sharpe']
                    )
        
        if total_improvements:
            avg_return_improvement = np.mean(total_improvements)
            avg_sharpe_improvement = np.mean(sharpe_improvements)
            
            print(f"\n🎯 Average Performance Improvements:")
            print(f"  • Return Improvement: {avg_return_improvement:+.2f}%")
            print(f"  • Sharpe Ratio Improvement: {avg_sharpe_improvement:+.2f}")
            print(f"  • Success Rate: {sum(1 for x in total_improvements if x > 0) / len(total_improvements) * 100:.1f}%")
            
            # Best improvements
            print(f"\n🏆 Top 5 Improvements:")
            all_improvements = []
            for symbol, results in all_results.items():
                for result in results:
                    if result:
                        all_improvements.append({)
                            'symbol': symbol,
                            'algorithm': result['algorithm'],
                            'improvement': result['improvement'],
                            'enhanced_return': result['enhanced_return']
                        })
            
            sorted_improvements = sorted(all_improvements, 
                                       key=lambda x: x['improvement'], 
                                       reverse=True)[:5]
            
            for i, imp in enumerate(sorted_improvements, 1):
                print(f"  {i}. {imp['algorithm']} on {imp['symbol']}: ")
                      f"{imp['improvement']:+.2f}% improvement "
                      f"({imp['enhanced_return']:.2f}% total return)")
        
        return all_results

def main():
    """Run the comparative backtest"""
    backtest = ComparativeBacktest()
    results = backtest.run_full_comparison()
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results_file = f'enhanced_algorithm_results_{timestamp}.json'
    
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n📁 Detailed results saved to: {results_file}")
    print("\n✅ Enhanced algorithm testing complete!")

if __name__ == "__main__":
    main()