
#!/usr/bin/env python3
"""
Demo of Comprehensive Options Analysis with All Metrics
Shows enhanced display format with sample data
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import logging
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List

logging.basicConfig()
    level=logging.INFO,
    format='%(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

@dataclass
class MockContract:
    symbol: str
    strike: float
    option_type: str
    mid_price: float
    delta: float
    gamma: float
    theta: float
    vega: float

@dataclass 
class MockLeg:
    contract: MockContract
    action: str
    quantity: int

@dataclass
class MockOpportunity:
    strategy_name: str
    underlying_symbol: str
    legs: List[MockLeg]
    net_premium: float
    max_profit: float
    max_loss: float
    probability_profit: float
    break_even_points: List[float]
    expiry_dates: List[str]

def create_sample_opportunities():
    """Create sample opportunities to demonstrate the analysis"""
    
    # SPY Bull Put Spread
    spy_put_short = MockContract("SPY240621P00590000", 590.0, "put", 3.50, -0.25, 0.008, -0.15, 0.12)
    spy_put_long = MockContract("SPY240621P00585000", 585.0, "put", 2.10, -0.18, 0.006, -0.12, 0.10)
    
    bull_put_spread = MockOpportunity()
        strategy_name="Bull Put Spread",
        underlying_symbols=["SPY",
        legs=[]
            MockLeg(spy_put_short, "sell", 1),
            MockLeg(spy_put_long, "buy", 1)
        ],
        net_premium=1.40,  # Credit received
        max_profit=1.40,
        max_loss=3.60,     # (590-585) - 1.40
        probability_profit=0.75,
        break_even_points=[588.60],  # 590 - 1.40
        expiry_dates=["2024-06-21"]
    )
    
    # AAPL Iron Condor
    aapl_put_short = MockContract("AAPL240621P00185000", 185.0, "put", 2.20, -0.22, 0.012, -0.18, 0.15)
    aapl_put_long = MockContract("AAPL240621P00180000", 180.0, "put", 1.30, -0.15, 0.008, -0.14, 0.12)
    aapl_call_short = MockContract("AAPL240621C00200000", 200.0, "call", 1.80, 0.20, 0.011, -0.16, 0.14)
    aapl_call_long = MockContract("AAPL240621C00205000", 205.0, "call", 1.10, 0.14, 0.007, -0.12, 0.11)
    
    iron_condor = MockOpportunity()
        strategy_name="Iron Condor",
        underlying_symbols=["AAPL",
        legs=[]
            MockLeg(aapl_put_short, "sell", 1),
            MockLeg(aapl_put_long, "buy", 1),
            MockLeg(aapl_call_short, "sell", 1),
            MockLeg(aapl_call_long, "buy", 1)
        ],
        net_premium=1.60,  # Net credit
        max_profit=1.60,
        max_loss=3.40,     # Max(5, 5) - 1.60
        probability_profit=0.68,
        break_even_points=[186.60, 198.40],
        expiry_dates=["2024-06-21"]
    )
    
    # QQQ Long Straddle
    qqq_call = MockContract("QQQ240621C00460000", 460.0, "call", 8.50, 0.52, 0.025, -0.35, 0.28)
    qqq_put = MockContract("QQQ240621P00460000", 460.0, "put", 7.20, -0.48, 0.025, -0.32, 0.28)
    
    long_straddle = MockOpportunity()
        strategy_name="Long Straddle",
        underlying_symbols=["QQQ",
        legs=[]
            MockLeg(qqq_call, "buy", 1),
            MockLeg(qqq_put, "buy", 1)
        ],
        net_premium=-15.70,  # Debit paid
        max_profit=float('inf'),
        max_loss=15.70,
        probability_profit=0.42,
        break_even_points=[444.30, 475.70],
        expiry_dates=["2024-06-21"]
    )
    
    return {}
        'credit_spreads': [bull_put_spread],
        'iron_condors': [iron_condor], 
        'straddles': [long_straddle],
        'debit_spreads': [],
        'strangles': [],
        'butterflies': [],
        'arbitrage': []
    }

def calculate_advanced_metrics(opportunity):
    """Calculate comprehensive metrics for any opportunity"""
    metrics = {}
    
    # Basic metrics
    metrics['net_premium'] = opportunity.net_premium
    metrics['max_profit'] = opportunity.max_profit
    metrics['max_loss'] = opportunity.max_loss
    metrics['probability_profit'] = opportunity.probability_profit
    
    # Risk/Reward ratios
    if metrics['max_loss'] > 0:
        metrics['profit_loss_ratio'] = metrics['max_profit'] / metrics['max_loss']
        metrics['risk_reward_ratio'] = metrics['max_loss'] / metrics['max_profit'] if metrics['max_profit'] > 0 else float('inf')
    else:
        metrics['profit_loss_ratio'] = float('inf')
        metrics['risk_reward_ratio'] = 0
    
    # Expected values
    prob_win = metrics['probability_profit']
    prob_lose = 1 - prob_win
    metrics['expected_profit'] = (prob_win * metrics['max_profit']) - (prob_lose * metrics['max_loss'])
    metrics['expected_return'] = metrics['expected_profit'] / max(abs(metrics['net_premium']), metrics['max_loss']) if max(abs(metrics['net_premium']), metrics['max_loss']) > 0 else 0
    
    # Break-even analysis
    metrics['break_even_points'] = opportunity.break_even_points
    metrics['break_even_range'] = max(metrics['break_even_points']) - min(metrics['break_even_points']) if len(metrics['break_even_points']) > 1 else 0
    
    # Time analysis
    expiry = datetime.strptime(opportunity.expiry_dates[0], '%Y-%m-%d')
    metrics['days_to_expiry'] = (expiry - datetime.now().days)
    metrics['daily_theta_decay'] = abs(metrics['net_premium']) / metrics['days_to_expiry'] if metrics['days_to_expiry'] > 0 else 0
    
    # Greeks analysis (aggregate from legs)
    total_delta = 0
    total_gamma = 0
    total_theta = 0
    total_vega = 0
    
    for leg in opportunity.legs:
        multiplier = leg.quantity if leg.action == 'buy' else -leg.quantity
        total_delta += leg.contract.delta * multiplier
        total_gamma += leg.contract.gamma * multiplier
        total_theta += leg.contract.theta * multiplier
        total_vega += leg.contract.vega * multiplier
    
    metrics['net_delta'] = total_delta
    metrics['net_gamma'] = total_gamma
    metrics['net_theta'] = total_theta
    metrics['net_vega'] = total_vega
    
    # Kelly Criterion for position sizing
    if metrics['max_loss'] > 0 and prob_win > 0:
        win_amount = metrics['max_profit']
        lose_amount = metrics['max_loss']
        kelly_fraction = (prob_win * win_amount - prob_lose * lose_amount) / (win_amount * lose_amount)
        metrics['kelly_fraction'] = max(0, min(0.25, kelly_fraction)  # Cap at 25%)
    else:
        metrics['kelly_fraction'] = 0
    
    # Sharpe-like ratio for options
    if metrics['max_loss'] > 0:
        metrics['return_to_risk'] = metrics['expected_profit'] / metrics['max_loss']
    else:
        metrics['return_to_risk'] = 0
    
    # Composite opportunity score
    metrics['opportunity_score'] = ()
        metrics['expected_return'] * 0.35 +           # Expected return weight
        metrics['probability_profit'] * 0.25 +        # Win probability weight  
        (1 / max(metrics['risk_reward_ratio'], 0.1) * 0.20 +  # Risk/reward weight)
        min(metrics['profit_loss_ratio'], 5) * 0.15 +  # P/L ratio weight
        metrics['return_to_risk'] * 0.05               # Return to risk weight
    )
    
    return metrics

def display_opportunity_details(opp, rank):
    """Display comprehensive analysis of a single opportunity"""
    metrics = calculate_advanced_metrics(opp)
    
    logger.info(f"\n{'='*90}")
    logger.info(f"🏆 RANK #{rank}: {opp.strategy_name} - {opp.underlying_symbol}")
    logger.info(f"{'='*90}")
    
    # Core Strategy Metrics
    logger.info("📊 CORE STRATEGY METRICS")
    logger.info(f"   💰 Net Premium:           ${metrics['net_premium']:>8.2f}")
    logger.info(f"   📈 Max Profit:            ${metrics['max_profit']:>8.2f}")
    logger.info(f"   📉 Max Loss:              ${metrics['max_loss']:>8.2f}")
    logger.info(f"   🎯 Win Probability:       {metrics['probability_profit']:>8.1%}")
    logger.info(f"   ⚖️  Profit/Loss Ratio:     {metrics['profit_loss_ratio']:>8.2f}")
    logger.info(f"   🔥 Opportunity Score:     {metrics['opportunity_score']:>8.2f}")
    
    # Expected Value Analysis
    logger.info("\n💡 EXPECTED VALUE ANALYSIS")
    logger.info(f"   💵 Expected Profit:       ${metrics['expected_profit']:>8.2f}")
    logger.info(f"   📊 Expected Return:       {metrics['expected_return']:>8.1%}")
    logger.info(f"   ⚠️  Risk/Reward Ratio:     {metrics['risk_reward_ratio']:>8.2f}")
    logger.info(f"   📈 Return-to-Risk:        {metrics['return_to_risk']:>8.2f}")
    logger.info(f"   🎲 Kelly Fraction:        {metrics['kelly_fraction']:>8.1%}")
    
    # Greeks Analysis
    logger.info("\n🧮 GREEKS ANALYSIS")
    logger.info(f"   Δ  Net Delta:             {metrics['net_delta']:>8.3f}")
    logger.info(f"   Γ  Net Gamma:             {metrics['net_gamma']:>8.3f}")
    logger.info(f"   Θ  Net Theta:             {metrics['net_theta']:>8.3f}")
    logger.info(f"   ν  Net Vega:              {metrics['net_vega']:>8.3f}")
    logger.info(f"   ⏰ Daily Theta Decay:     ${metrics['daily_theta_decay']:>8.2f}")
    
    # Time & Break-Even Analysis
    logger.info("\n⏱️  TIME & BREAK-EVEN ANALYSIS")
    logger.info(f"   📅 Days to Expiry:        {metrics['days_to_expiry']:>8.0f}")
    if metrics['break_even_points']:
        logger.info(f"   🎯 Break-Even Points:     {', '.join(f'${bp:.2f}' for bp in metrics['break_even_points'])}")
        if metrics['break_even_range'] > 0:
            logger.info(f"   📏 Break-Even Range:      ${metrics['break_even_range']:>8.2f}")
    
    # Strategy Legs Details
    logger.info("\n🦵 STRATEGY LEGS")
    for i, leg in enumerate(opp.legs, 1):
        action_icon = "📈" if leg.action == "buy" else "📉"
        logger.info(f"   {action_icon} Leg {i}: {leg.action.upper()} {leg.quantity}x {leg.contract.symbol}")
        logger.info(f"      💰 Strike: ${leg.contract.strike:.2f} | Premium: ${leg.contract.mid_price:.2f}")
        logger.info(f"      🔢 Delta: {leg.contract.delta:>6.3f} | Gamma: {leg.contract.gamma:>6.3f}")
        logger.info(f"      🔢 Theta: {leg.contract.theta:>6.3f} | Vega:  {leg.contract.vega:>6.3f}")

def display_comprehensive_opportunities(all_opportunities):
    """Display full comprehensive analysis"""
    logger.info("\n" + "="*100)
    logger.info("🚀 COMPREHENSIVE OPTIONS SPREAD ANALYSIS")
    logger.info("="*100)
    
    # Collect and rank all opportunities
    all_opps = []
    for strategy_type, opportunities in all_opportunities.items():
        for opp in opportunities:
            metrics = calculate_advanced_metrics(opp)
            all_opps.append((opp, metrics, strategy_type)
    
    # Sort by opportunity score
    all_opps.sort(key=lambda x: x[1]['opportunity_score'], reverse=True)
    
    # Summary by strategy type
    logger.info("\n📊 SUMMARY BY STRATEGY TYPE")
    logger.info("-" * 100)
    
    for strategy_type, opportunities in all_opportunities.items():
        if opportunities:
            metrics_list = [calculate_advanced_metrics(opp) for opp in opportunities]
            avg_score = sum(m['opportunity_score'] for m in metrics_list) / len(metrics_list)
            avg_win_prob = sum(m['probability_profit'] for m in metrics_list) / len(metrics_list)
            avg_expected = sum(m['expected_profit'] for m in metrics_list) / len(metrics_list)
            avg_kelly = sum(m['kelly_fraction'] for m in metrics_list) / len(metrics_list)
            
            logger.info(f"{strategy_type.upper():20} | Count: {len(opportunities):3} | ")
                       f"Avg Score: {avg_score:5.2f} | Win%: {avg_win_prob:5.1%} | "
                       f"Expected: ${avg_expected:6.2f} | Kelly: {avg_kelly:4.1%}")
    
    # Top 10 Overall Opportunities
    logger.info(f"\n🏆 TOP {len(all_opps)} OPPORTUNITIES (Ranked by Opportunity Score)")
    logger.info("-" * 110)
    
    for i, (opp, metrics, strategy_type) in enumerate(all_opps, 1):
        logger.info(f"\n#{i:2} | {opp.strategy_name:20} | {opp.underlying_symbol:4} | ")
                   f"Score: {metrics['opportunity_score']:5.2f} | "
                   f"Win%: {metrics['probability_profit']:5.1%} | "
                   f"Expected: ${metrics['expected_profit']:6.2f}")
        
        logger.info(f"     Premium: ${metrics['net_premium']:6.2f} | ")
                   f"Max P/L: ${metrics['max_profit']:6.2f}/${metrics['max_loss']:6.2f} | "
                   f"P/L Ratio: {metrics['profit_loss_ratio']:4.2f} | "
                   f"Kelly: {metrics['kelly_fraction']:4.1%} | "
                   f"DTE: {metrics['days_to_expiry']:3.0f}")
    
    # Detailed analysis of all opportunities
    logger.info(f"\n🔍 DETAILED ANALYSIS - ALL OPPORTUNITIES")
    for i, (opp, metrics, strategy_type) in enumerate(all_opps, 1):
        display_opportunity_details(opp, i)
    
    # Portfolio Risk Analysis
    logger.info(f"\n⚠️  PORTFOLIO RISK ANALYSIS")
    logger.info("-" * 100)
    
    if all_opps:
        total_max_loss = sum(abs(m[1]['max_loss']) for m in all_opps)
        total_expected = sum(m[1]['expected_profit'] for m in all_opps)
        avg_win_prob = sum(m[1]['probability_profit'] for m in all_opps) / len(all_opps)
        total_kelly = sum(m[1]['kelly_fraction'] for m in all_opps)
        
        # Portfolio Greeks
        total_delta = sum(m[1]['net_delta'] for m in all_opps)
        total_gamma = sum(m[1]['net_gamma'] for m in all_opps)
        total_theta = sum(m[1]['net_theta'] for m in all_opps)
        total_vega = sum(m[1]['net_vega'] for m in all_opps)
        
        logger.info(f"📊 Portfolio Metrics (if all positions taken):")
        logger.info(f"   💰 Total Max Loss:        ${total_max_loss:>10,.2f}")
        logger.info(f"   📈 Total Expected Profit: ${total_expected:>10,.2f}")
        logger.info(f"   🎯 Portfolio Win Rate:    {avg_win_prob:>10.1%}")
        logger.info(f"   📊 Expected Return:       {(total_expected/total_max_loss)*100 if total_max_loss > 0 else 0:>10.1f}%")
        logger.info(f"   🎲 Total Kelly Fraction:  {total_kelly:>10.1%}")
        
        logger.info(f"\n🧮 Portfolio Greeks:")
        logger.info(f"   Δ  Portfolio Delta:       {total_delta:>10.2f}")
        logger.info(f"   Γ  Portfolio Gamma:       {total_gamma:>10.3f}")
        logger.info(f"   Θ  Portfolio Theta:       {total_theta:>10.2f}")
        logger.info(f"   ν  Portfolio Vega:        {total_vega:>10.2f}")
        logger.info(f"   💵 Daily Theta Income:    ${total_theta:>10.2f}")

def main():
    logger.info("🎯 COMPREHENSIVE OPTIONS ANALYSIS DEMO")
    logger.info("Showing enhanced metrics and display format")
    
    # Get sample opportunities
    opportunities = create_sample_opportunities()
    
    # Display comprehensive analysis
    display_comprehensive_opportunities(opportunities)
    
    logger.info(f"\n{'='*100}")
    logger.info("✅ Demo Complete! This shows the enhanced analysis format.")
    logger.info("   All metrics include: Expected profit, Kelly sizing, Greeks aggregation,")
    logger.info("   Risk ratios, Break-even analysis, Time decay, and Opportunity scoring.")
    logger.info("="*100)

if __name__ == "__main__":
    main()