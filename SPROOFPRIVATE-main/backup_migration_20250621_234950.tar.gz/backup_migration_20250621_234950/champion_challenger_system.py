"""
Production-Ready Champion-Challenger Model System

A comprehensive system for deploying, testing, and managing multiple models in production
with sophisticated traffic management, monitoring, and automated decision-making.
"""

import asyncio
import json
import logging
import pickle
import time
import uuid
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
import hashlib
import numpy as np
from scipy import stats
import threading
import concurrent.futures
import aiofiles
import redis
from prometheus_client import Counter, Histogram, Gauge, Summary
import pandas as pd


# Metrics
model_predictions_counter = Counter('model_predictions_total', 'Total predictions', ['model_id', 'version'])
model_latency_histogram = Histogram('model_prediction_latency_seconds', 'Prediction latency', ['model_id'])
model_errors_counter = Counter('model_errors_total', 'Model errors', ['model_id', 'error_type'])
traffic_allocation_gauge = Gauge('traffic_allocation_percentage', 'Traffic allocation', ['model_id'])
active_models_gauge = Gauge('active_models_count', 'Number of active models')
model_performance_gauge = Gauge('model_performance_score', 'Model performance score', ['model_id', 'metric'])


class ModelStatus(Enum):
    """Model lifecycle states"""
    REGISTERED = "registered"
    TESTING = "testing"
    SHADOW = "shadow"
    CHALLENGER = "challenger"
    CHAMPION = "champion"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class DeploymentStrategy(Enum):
    """Deployment strategies"""
    PERCENTAGE = "percentage"
    USER_BASED = "user_based"
    REGION_BASED = "region_based"
    FEATURE_BASED = "feature_based"
    CANARY = "canary"
    BLUE_GREEN = "blue_green"
    MULTI_ARMED_BANDIT = "multi_armed_bandit"


class RoutingDecision(Enum):
    """Routing decision types"""
    CHAMPION = "champion"
    CHALLENGER = "challenger"
    SHADOW = "shadow"
    FALLBACK = "fallback"


@dataclass
class ModelMetadata:
    """Model metadata"""
    model_id: str
    version: str
    name: str
    description: str
    created_at: datetime
    updated_at: datetime
    training_date: datetime
    features: List[str]
    target: str
    framework: str
    metrics: Dict[str, float]
    tags: Set[str] = field(default_factory=set)
    status: ModelStatus = ModelStatus.REGISTERED
    parent_model_id: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)
    dependencies: Dict[str, str] = field(default_factory=dict)
    

@dataclass
class PredictionResult:
    """Result of a model prediction"""
    model_id: str
    version: str
    prediction: Any
    confidence: Optional[float] = None
    latency_ms: float = 0
    timestamp: datetime = field(default_factory=datetime.utcnow)
    features: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PerformanceMetrics:
    """Performance metrics for a model"""
    model_id: str
    version: str
    total_predictions: int = 0
    successful_predictions: int = 0
    failed_predictions: int = 0
    average_latency_ms: float = 0
    p95_latency_ms: float = 0
    p99_latency_ms: float = 0
    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1_score: Optional[float] = None
    custom_metrics: Dict[str, float] = field(default_factory=dict)
    last_updated: datetime = field(default_factory=datetime.utcnow)


@dataclass
class ABTestResult:
    """Results of A/B testing"""
    champion_id: str
    challenger_id: str
    champion_metrics: PerformanceMetrics
    challenger_metrics: PerformanceMetrics
    statistical_significance: float
    confidence_interval: Tuple[float, float]
    p_value: float
    effect_size: float
    sample_size: int
    test_duration_hours: float
    recommendation: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class ModelWrapper(ABC):
    """Abstract base class for model wrappers"""
    
    @abstractmethod
    async def predict(self, features: Dict[str, Any]) -> PredictionResult:
        """Make a prediction"""
        pass
    
    @abstractmethod
    async def load(self) -> None:
        """Load model into memory"""
        pass
    
    @abstractmethod
    async def unload(self) -> None:
        """Unload model from memory"""
        pass
    
    @abstractmethod
    def get_memory_usage(self) -> int:
        """Get model memory usage in bytes"""
        pass


class BaseModel(ModelWrapper):
    """Base implementation of ModelWrapper"""
    
    def __init__(self, model_id: str, version: str, model_path: Path):
        self.model_id = model_id
        self.version = version
        self.model_path = model_path
        self.model = None
        self.preprocessor = None
        self.is_loaded = False
        
    async def load(self) -> None:
        """Load model and preprocessor"""
        if self.is_loaded:
            return
            
        # Load model
        model_file = self.model_path / f"model_{self.version}.pkl"
        async with aiofiles.open(model_file, 'rb') as f:
            content = await f.read()
            self.model = pickle.loads(content)
        
        # Load preprocessor if exists
        preprocessor_file = self.model_path / f"preprocessor_{self.version}.pkl"
        if preprocessor_file.exists():
            async with aiofiles.open(preprocessor_file, 'rb') as f:
                content = await f.read()
                self.preprocessor = pickle.loads(content)
                
        self.is_loaded = True
        
    async def unload(self) -> None:
        """Unload model from memory"""
        self.model = None
        self.preprocessor = None
        self.is_loaded = False
        
    async def predict(self, features: Dict[str, Any]) -> PredictionResult:
        """Make a prediction"""
        if not self.is_loaded:
            await self.load()
            
        start_time = time.time()
        
        try:
            # Preprocess features if preprocessor exists
            if self.preprocessor:
                processed_features = self.preprocessor.transform(features)
            else:
                processed_features = features
                
            # Make prediction
            prediction = self.model.predict(processed_features)
            confidence = None
            
            # Get confidence if available
            if hasattr(self.model, 'predict_proba'):
                probabilities = self.model.predict_proba(processed_features)
                confidence = float(np.max(probabilities))
                
            latency_ms = (time.time() - start_time) * 1000
            
            return PredictionResult()
                model_id=self.model_id,
                version=self.version,
                prediction=prediction,
                confidence=confidence,
                latency_ms=latency_ms,
                features=features
            )
            
        except Exception as e:
            model_errors_counter.labels()
                model_id=self.model_id,
                error_type=type(e).__name__
            ).inc()
            raise
            
    def get_memory_usage(self) -> int:
        """Estimate memory usage"""
        if not self.is_loaded:
            return 0
        # Simplified estimation
        return len(pickle.dumps(self.model)) + len(pickle.dumps(self.preprocessor or {}))


class ModelRegistry:
    """Centralized model storage and management"""
    
    def __init__(self, storage_path: Path, redis_client: Optional[redis.Redis] = None):
        self.storage_path = storage_path
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.redis_client = redis_client
        self.models: Dict[str, ModelMetadata] = {}
        self.model_artifacts: Dict[str, Path] = {}
        self._lock = threading.RLock()
        self._load_registry()
        
    def _load_registry(self):
        """Load registry from disk"""
        registry_file = self.storage_path / "registry.json"
        if registry_file.exists():
            with open(registry_file, 'r') as f:
                data = json.load(f)
                for model_data in data.get('models', []):
                    metadata = ModelMetadata(**model_data)
                    metadata.created_at = datetime.fromisoformat(metadata.created_at)
                    metadata.updated_at = datetime.fromisoformat(metadata.updated_at)
                    metadata.training_date = datetime.fromisoformat(metadata.training_date)
                    metadata.status = ModelStatus(metadata.status)
                    metadata.tags = set(metadata.tags)
                    self.models[metadata.model_id] = metadata
                    
    def _save_registry(self):
        """Save registry to disk"""
        registry_file = self.storage_path / "registry.json"
        data = {}
            'models': []
                {}
                    **vars(metadata),
                    'created_at': metadata.created_at.isoformat(),
                    'updated_at': metadata.updated_at.isoformat(),
                    'training_date': metadata.training_date.isoformat(),
                    'status': metadata.status.value,
                    'tags': list(metadata.tags)
                }
                for metadata in self.models.values()
            ]
        }
        with open(registry_file, 'w') as f:
            json.dump(data, f, indent=2)
            
    def register_model()
        self,
        model: Any,
        metadata: ModelMetadata,
        preprocessor: Optional[Any] = None,
        additional_artifacts: Optional[Dict[str, Any]] = None
    ) -> str:
        """Register a new model"""
        with self._lock:
            # Generate model ID if not provided
            if not metadata.model_id:
                metadata.model_id = str(uuid.uuid4())
                
            # Create model directory
            model_dir = self.storage_path / metadata.model_id / metadata.version
            model_dir.mkdir(parents=True, exist_ok=True)
            
            # Save model
            model_file = model_dir / f"model_{metadata.version}.pkl"
            with open(model_file, 'wb') as f:
                pickle.dump(model, f)
                
            # Save preprocessor if provided
            if preprocessor:
                preprocessor_file = model_dir / f"preprocessor_{metadata.version}.pkl"
                with open(preprocessor_file, 'wb') as f:
                    pickle.dump(preprocessor, f)
                    
            # Save additional artifacts
            if additional_artifacts:
                for name, artifact in additional_artifacts.items():
                    artifact_file = model_dir / f"{name}_{metadata.version}.pkl"
                    with open(artifact_file, 'wb') as f:
                        pickle.dump(artifact, f)
                        
            # Save metadata
            metadata_file = model_dir / "metadata.json"
            with open(metadata_file, 'w') as f:
                json.dump(vars(metadata), f, indent=2, default=str)
                
            # Update registry
            self.models[metadata.model_id] = metadata
            self.model_artifacts[metadata.model_id] = model_dir
            self._save_registry()
            
            # Update Redis if available
            if self.redis_client:
                self.redis_client.hset()
                    "model_registry",
                    metadata.model_id,
                    json.dumps(vars(metadata), default=str)
                )
                
            logging.info(f"Registered model {metadata.model_id} version {metadata.version}")
            return metadata.model_id
            
    def get_model(self, model_id: str, version: Optional[str] = None) -> Tuple[ModelMetadata, Path]:
        """Get model metadata and path"""
        with self._lock:
            if model_id not in self.models:
                raise ValueError(f"Model {model_id} not found")
                
            metadata = self.models[model_id]
            
            if version and version != metadata.version:
                # Look for specific version
                version_dir = self.storage_path / model_id / version
                if not version_dir.exists():
                    raise ValueError(f"Version {version} not found for model {model_id}")
                return metadata, version_dir
                
            return metadata, self.model_artifacts.get(model_id, self.storage_path / model_id / metadata.version)
            
    def search_models()
        self,
        tags: Optional[Set[str]] = None,
        status: Optional[ModelStatus] = None,
        min_performance: Optional[Dict[str, float]] = None
    ) -> List[ModelMetadata]:
        """Search models by criteria"""
        results = []
        
        with self._lock:
            for metadata in self.models.values():
                # Filter by tags
                if tags and not tags.issubset(metadata.tags):
                    continue
                    
                # Filter by status
                if status and metadata.status != status:
                    continue
                    
                # Filter by performance
                if min_performance:
                    meets_criteria = all()
                        metadata.metrics.get(metric, 0) >= min_value
                        for metric, min_value in min_performance.items()
                    )
                    if not meets_criteria:
                        continue
                        
                results.append(metadata)
                
        return results
        
    def update_model_status(self, model_id: str, status: ModelStatus) -> None:
        """Update model status"""
        with self._lock:
            if model_id not in self.models:
                raise ValueError(f"Model {model_id} not found")
                
            self.models[model_id].status = status
            self.models[model_id].updated_at = datetime.utcnow()
            self._save_registry()
            
            if self.redis_client:
                self.redis_client.hset()
                    "model_registry",
                    model_id,
                    json.dumps(vars(self.models[model_id]), default=str)
                )
                
    def get_model_lineage(self, model_id: str) -> List[ModelMetadata]:
        """Get model lineage (parent models)"""
        lineage = []
        current_id = model_id
        
        with self._lock:
            while current_id:
                if current_id not in self.models:
                    break
                    
                metadata = self.models[current_id]
                lineage.append(metadata)
                current_id = metadata.parent_model_id
                
        return lineage


class TrafficManager:
    """Manages traffic routing between models"""
    
    def __init__(self, redis_client: Optional[redis.Redis] = None):
        self.redis_client = redis_client
        self.routing_rules: Dict[str, Dict[str, Any]] = {}
        self.sticky_sessions: Dict[str, str] = {}
        self.circuit_breakers: Dict[str, 'CircuitBreaker'] = {}
        self._lock = threading.RLock()
        
    def set_routing_rule()
        self,
        rule_id: str,
        strategy: DeploymentStrategy,
        champion_id: str,
        challenger_ids: List[str],
        config: Dict[str, Any]
    ) -> None:
        """Set routing rule"""
        with self._lock:
            self.routing_rules[rule_id] = {}
                'strategy': strategy,
                'champion_id': champion_id,
                'challenger_ids': challenger_ids,
                'config': config,
                'created_at': datetime.utcnow()
            }
            
            # Update Redis if available
            if self.redis_client:
                self.redis_client.hset()
                    "routing_rules",
                    rule_id,
                    json.dumps(self.routing_rules[rule_id], default=str)
                )
                
    def get_model_for_request()
        self,
        rule_id: str,
        user_id: Optional[str] = None,
        features: Optional[Dict[str, Any]] = None,
        region: Optional[str] = None
    ) -> Tuple[str, RoutingDecision]:
        """Get model to use for a request"""
        with self._lock:
            if rule_id not in self.routing_rules:
                raise ValueError(f"Routing rule {rule_id} not found")
                
            rule = self.routing_rules[rule_id]
            strategy = rule['strategy']
            champion_id = rule['champion_id']
            challenger_ids = rule['challenger_ids']
            config = rule['config']
            
            # Check sticky session
            if user_id and user_id in self.sticky_sessions:
                return self.sticky_sessions[user_id], RoutingDecision.CHALLENGER
                
            # Check circuit breakers
            for model_id in [champion_id] + challenger_ids:
                if model_id in self.circuit_breakers:
                    breaker = self.circuit_breakers[model_id]
                    if breaker.is_open():
                        continue
                        
            # Route based on strategy
            if strategy == DeploymentStrategy.PERCENTAGE:
                return self._percentage_routing(champion_id, challenger_ids, config)
            elif strategy == DeploymentStrategy.USER_BASED:
                return self._user_based_routing(champion_id, challenger_ids, user_id, config)
            elif strategy == DeploymentStrategy.REGION_BASED:
                return self._region_based_routing(champion_id, challenger_ids, region, config)
            elif strategy == DeploymentStrategy.FEATURE_BASED:
                return self._feature_based_routing(champion_id, challenger_ids, features, config)
            elif strategy == DeploymentStrategy.CANARY:
                return self._canary_routing(champion_id, challenger_ids, config)
            elif strategy == DeploymentStrategy.BLUE_GREEN:
                return self._blue_green_routing(champion_id, challenger_ids, config)
            elif strategy == DeploymentStrategy.MULTI_ARMED_BANDIT:
                return self._mab_routing(champion_id, challenger_ids, config)
            else:
                return champion_id, RoutingDecision.CHAMPION
                
    def _percentage_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """Percentage-based routing"""
        challenger_percentage = config.get('challenger_percentage', 10)
        shadow_percentage = config.get('shadow_percentage', 0)
        
        rand = np.random.random() * 100
        
        if rand < shadow_percentage:
            # Shadow mode - return champion but mark for shadow
            return champion_id, RoutingDecision.SHADOW
        elif rand < shadow_percentage + challenger_percentage:
            # Route to challenger
            challenger = np.random.choice(challenger_ids)
            return challenger, RoutingDecision.CHALLENGER
        else:
            # Route to champion
            return champion_id, RoutingDecision.CHAMPION
            
    def _user_based_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        user_id: Optional[str],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """User-based routing with consistent hashing"""
        if not user_id:
            return champion_id, RoutingDecision.CHAMPION
            
        # Use consistent hashing
        hash_value = int(hashlib.md5(user_id.encode()).hexdigest(), 16)
        total_models = len(challenger_ids) + 1
        index = hash_value % total_models
        
        if index == 0:
            return champion_id, RoutingDecision.CHAMPION
        else:
            return challenger_ids[index - 1], RoutingDecision.CHALLENGER
            
    def _region_based_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        region: Optional[str],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """Region-based routing"""
        if not region:
            return champion_id, RoutingDecision.CHAMPION
            
        region_mapping = config.get('region_mapping', {})
        
        if region in region_mapping:
            model_id = region_mapping[region]
            if model_id in challenger_ids:
                return model_id, RoutingDecision.CHALLENGER
                
        return champion_id, RoutingDecision.CHAMPION
        
    def _feature_based_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        features: Optional[Dict[str, Any]],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """Feature-based routing"""
        if not features:
            return champion_id, RoutingDecision.CHAMPION
            
        routing_rules = config.get('feature_rules', [])
        
        for rule in routing_rules:
            feature_name = rule.get('feature')
            feature_value = rule.get('value')
            model_id = rule.get('model_id')
            
            if feature_name in features and features[feature_name] == feature_value:
                if model_id in challenger_ids:
                    return model_id, RoutingDecision.CHALLENGER
                    
        return champion_id, RoutingDecision.CHAMPION
        
    def _canary_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """Canary deployment routing with gradual rollout"""
        start_time = config.get('start_time', datetime.utcnow())
        if isinstance(start_time, str):
            start_time = datetime.fromisoformat(start_time)
            
        ramp_duration_hours = config.get('ramp_duration_hours', 24)
        max_percentage = config.get('max_percentage', 50)
        
        # Calculate current percentage based on time
        elapsed_hours = (datetime.utcnow() - start_time).total_seconds() / 3600
        current_percentage = min()
            (elapsed_hours / ramp_duration_hours) * max_percentage,
            max_percentage
        )
        
        if np.random.random() * 100 < current_percentage:
            return np.random.choice(challenger_ids), RoutingDecision.CHALLENGER
        else:
            return champion_id, RoutingDecision.CHAMPION
            
    def _blue_green_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """Blue-green deployment routing"""
        active_environment = config.get('active_environment', 'blue')
        blue_model = config.get('blue_model', champion_id)
        green_model = config.get('green_model', challenger_ids[0] if challenger_ids else champion_id)
        
        if active_environment == 'blue':
            return blue_model, RoutingDecision.CHAMPION
        else:
            return green_model, RoutingDecision.CHALLENGER
            
    def _mab_routing()
        self,
        champion_id: str,
        challenger_ids: List[str],
        config: Dict[str, Any]
    ) -> Tuple[str, RoutingDecision]:
        """Multi-armed bandit routing with Thompson sampling"""
        all_models = [champion_id] + challenger_ids
        
        # Get current statistics
        successes = config.get('successes', {})
        failures = config.get('failures', {})
        
        # Thompson sampling
        samples = []
        for model_id in all_models:
            s = successes.get(model_id, 1)  # Prior
            f = failures.get(model_id, 1)   # Prior
            sample = np.random.beta(s, f)
            samples.append(sample)
            
        # Select model with highest sample
        selected_index = np.argmax(samples)
        selected_model = all_models[selected_index]
        
        if selected_model == champion_id:
            return selected_model, RoutingDecision.CHAMPION
        else:
            return selected_model, RoutingDecision.CHALLENGER
            
    def update_sticky_session(self, user_id: str, model_id: str, duration_seconds: int = 3600):
        """Update sticky session"""
        with self._lock:
            self.sticky_sessions[user_id] = model_id
            
            if self.redis_client:
                self.redis_client.setex()
                    f"sticky_session:{user_id}",
                    duration_seconds,
                    model_id
                )
                
    def register_circuit_breaker(self, model_id: str, breaker: 'CircuitBreaker'):
        """Register circuit breaker for a model"""
        with self._lock:
            self.circuit_breakers[model_id] = breaker


class CircuitBreaker:
    """Circuit breaker for model protection"""
    
    def __init__()
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type = Exception
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'closed'  # closed, open, half_open
        self._lock = threading.Lock()
        
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Call function with circuit breaker protection"""
        with self._lock:
            if self.state == 'open':
                if self._should_attempt_reset():
                    self.state = 'half_open'
                else:
                    raise Exception("Circuit breaker is open")
                    
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except self.expected_exception as e:
            self._on_failure()
            raise
            
    def _should_attempt_reset(self) -> bool:
        """Check if we should attempt to reset"""
        return ()
            self.last_failure_time and
            (time.time() - self.last_failure_time) >= self.recovery_timeout
        )
        
    def _on_success(self):
        """Handle successful call"""
        with self._lock:
            self.failure_count = 0
            self.state = 'closed'
            
    def _on_failure(self):
        """Handle failed call"""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self.state = 'open'
                
    def is_open(self) -> bool:
        """Check if circuit breaker is open"""
        return self.state == 'open' and not self._should_attempt_reset()


class PerformanceMonitor:
    """Monitors model performance"""
    
    def __init__(self, window_size: int = 1000):
        self.window_size = window_size
        self.metrics: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window_size))
        self.latencies: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window_size))
        self.predictions: Dict[str, List[PredictionResult]] = defaultdict(list)
        self.ground_truth: Dict[str, List[Any]] = defaultdict(list)
        self._lock = threading.RLock()
        
    def record_prediction(self, result: PredictionResult):
        """Record a prediction"""
        with self._lock:
            model_key = f"{result.model_id}:{result.version}"
            
            # Record metrics
            self.predictions[model_key].append(result)
            self.latencies[model_key].append(result.latency_ms)
            
            # Update Prometheus metrics
            model_predictions_counter.labels()
                model_id=result.model_id,
                version=result.version
            ).inc()
            
            model_latency_histogram.labels()
                model_id=result.model_id
            ).observe(result.latency_ms / 1000)
            
    def record_ground_truth(self, model_id: str, version: str, prediction_id: str, actual: Any):
        """Record ground truth for evaluation"""
        with self._lock:
            model_key = f"{model_id}:{version}"
            self.ground_truth[model_key].append({)
                'prediction_id': prediction_id,
                'actual': actual,
                'timestamp': datetime.utcnow()
            })
            
    def get_metrics(self, model_id: str, version: str) -> PerformanceMetrics:
        """Get performance metrics for a model"""
        with self._lock:
            model_key = f"{model_id}:{version}"
            
            predictions = self.predictions.get(model_key, [])
            latencies = list(self.latencies.get(model_key, []))
            
            if not predictions:
                return PerformanceMetrics(model_id=model_id, version=version)
                
            # Calculate metrics
            total = len(predictions)
            successful = sum(1 for p in predictions if p.prediction is not None)
            failed = total - successful
            
            metrics = PerformanceMetrics()
                model_id=model_id,
                version=version,
                total_predictions=total,
                successful_predictions=successful,
                failed_predictions=failed
            )
            
            if latencies:
                metrics.average_latency_ms = np.mean(latencies)
                metrics.p95_latency_ms = np.percentile(latencies, 95)
                metrics.p99_latency_ms = np.percentile(latencies, 99)
                
            # Calculate accuracy if ground truth available
            ground_truth = self.ground_truth.get(model_key, [])
            if ground_truth:
                # Match predictions with ground truth
                # (Simplified - in production, use proper ID matching)
                correct = 0
                total_evaluated = min(len(predictions), len(ground_truth))
                
                for i in range(total_evaluated):
                    if predictions[i].prediction == ground_truth[i]['actual']:
                        correct += 1
                        
                if total_evaluated > 0:
                    metrics.accuracy = correct / total_evaluated
                    
            return metrics
            
    def calculate_statistical_significance()
        self,
        champion_metrics: PerformanceMetrics,
        challenger_metrics: PerformanceMetrics,
        metric_name: str = 'accuracy'
    ) -> ABTestResult:
        """Calculate statistical significance between two models"""
        # Get metric values
        champion_value = getattr(champion_metrics, metric_name, None)
        challenger_value = getattr(challenger_metrics, metric_name, None)
        
        if champion_value is None or challenger_value is None:
            champion_value = champion_metrics.custom_metrics.get(metric_name, 0)
            challenger_value = challenger_metrics.custom_metrics.get(metric_name, 0)
            
        # Calculate sample sizes
        n1 = champion_metrics.successful_predictions
        n2 = challenger_metrics.successful_predictions
        
        if n1 < 30 or n2 < 30:
            return ABTestResult()
                champion_id=champion_metrics.model_id,
                challenger_id=challenger_metrics.model_id,
                champion_metrics=champion_metrics,
                challenger_metrics=challenger_metrics,
                statistical_significance=0,
                confidence_interval=(0, 0),
                p_value=1.0,
                effect_size=0,
                sample_size=n1 + n2,
                test_duration_hours=0,
                recommendation="Insufficient data"
            )
            
        # Perform two-sample t-test
        # (Simplified - in production, use proper statistical tests based on metric type)
        effect_size = challenger_value - champion_value
        pooled_variance = ((n1 - 1) * 0.1 + (n2 - 1) * 0.1) / (n1 + n2 - 2)
        standard_error = np.sqrt(pooled_variance * (1/n1 + 1/n2))
        
        if standard_error > 0:
            t_statistic = effect_size / standard_error
            p_value = 2 * (1 - stats.t.cdf(abs(t_statistic), df=n1 + n2 - 2))
        else:
            p_value = 1.0
            
        # Calculate confidence interval
        confidence_level = 0.95
        margin_of_error = stats.t.ppf((1 + confidence_level) / 2, df=n1 + n2 - 2) * standard_error
        confidence_interval = (effect_size - margin_of_error, effect_size + margin_of_error)
        
        # Make recommendation
        if p_value < 0.05 and effect_size > 0:
            recommendation = "Promote challenger"
        elif p_value < 0.05 and effect_size < 0:
            recommendation = "Keep champion"
        else:
            recommendation = "Continue testing"
            
        return ABTestResult()
            champion_id=champion_metrics.model_id,
            challenger_id=challenger_metrics.model_id,
            champion_metrics=champion_metrics,
            challenger_metrics=challenger_metrics,
            statistical_significance=1 - p_value,
            confidence_interval=confidence_interval,
            p_value=p_value,
            effect_size=effect_size,
            sample_size=n1 + n2,
            test_duration_hours=0,  # Would calculate from timestamps
            recommendation=recommendation
        )
        
    def check_degradation()
        self,
        model_id: str,
        version: str,
        baseline_metrics: PerformanceMetrics,
        threshold: float = 0.1
    ) -> bool:
        """Check if model performance has degraded"""
        current_metrics = self.get_metrics(model_id, version)
        
        # Check various metrics
        checks = []
        
        # Latency check
        if baseline_metrics.average_latency_ms > 0:
            latency_increase = ()
                (current_metrics.average_latency_ms - baseline_metrics.average_latency_ms) /
                baseline_metrics.average_latency_ms
            )
            checks.append(latency_increase > threshold)
            
        # Accuracy check
        if baseline_metrics.accuracy is not None and current_metrics.accuracy is not None:
            accuracy_decrease = baseline_metrics.accuracy - current_metrics.accuracy
            checks.append(accuracy_decrease > threshold)
            
        # Error rate check
        if baseline_metrics.total_predictions > 0:
            baseline_error_rate = baseline_metrics.failed_predictions / baseline_metrics.total_predictions
            current_error_rate = ()
                current_metrics.failed_predictions / current_metrics.total_predictions
                if current_metrics.total_predictions > 0 else 0
            )
            error_increase = current_error_rate - baseline_error_rate
            checks.append(error_increase > threshold)
            
        return any(checks)


class TestingFramework:
    """Comprehensive testing framework for models"""
    
    def __init__(self, model_registry: ModelRegistry):
        self.model_registry = model_registry
        self.test_results: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=10)
        
    async def run_shadow_test()
        self,
        champion_model: ModelWrapper,
        challenger_model: ModelWrapper,
        test_data: List[Dict[str, Any]],
        duration_seconds: int = 3600
    ) -> Dict[str, Any]:
        """Run shadow testing"""
        start_time = time.time()
        results = {}
            'champion_predictions': [],
            'challenger_predictions': [],
            'discrepancies': [],
            'performance_comparison': {}
        }
        
        for data_point in test_data:
            if time.time() - start_time > duration_seconds:
                break
                
            # Get predictions from both models
            champion_pred = await champion_model.predict(data_point)
            challenger_pred = await challenger_model.predict(data_point)
            
            results['champion_predictions'].append(champion_pred)
            results['challenger_predictions'].append(challenger_pred)
            
            # Check for discrepancies
            if champion_pred.prediction != challenger_pred.prediction:
                results['discrepancies'].append({)
                    'features': data_point,
                    'champion_prediction': champion_pred.prediction,
                    'challenger_prediction': challenger_pred.prediction,
                    'champion_confidence': champion_pred.confidence,
                    'challenger_confidence': challenger_pred.confidence
                })
                
        # Calculate performance comparison
        champion_latencies = [p.latency_ms for p in results['champion_predictions']]
        challenger_latencies = [p.latency_ms for p in results['challenger_predictions']]
        
        results['performance_comparison'] = {}
            'champion_avg_latency': np.mean(champion_latencies),
            'challenger_avg_latency': np.mean(challenger_latencies),
            'champion_p95_latency': np.percentile(champion_latencies, 95),
            'challenger_p95_latency': np.percentile(challenger_latencies, 95),
            'discrepancy_rate': len(results['discrepancies']) / len(test_data) if test_data else 0
        }
        
        return results
        
    async def run_synthetic_test()
        self,
        model: ModelWrapper,
        generator: Callable[[], Dict[str, Any]],
        num_samples: int = 1000
    ) -> Dict[str, Any]:
        """Run synthetic data testing"""
        results = {}
            'predictions': [],
            'latencies': [],
            'errors': [],
            'edge_cases': []
        }
        
        for i in range(num_samples):
            try:
                # Generate synthetic data
                synthetic_data = generator()
                
                # Make prediction
                prediction = await model.predict(synthetic_data)
                results['predictions'].append(prediction)
                results['latencies'].append(prediction.latency_ms)
                
                # Check for edge cases
                if self._is_edge_case(synthetic_data, prediction):
                    results['edge_cases'].append({)
                        'features': synthetic_data,
                        'prediction': prediction
                    })
                    
            except Exception as e:
                results['errors'].append({)
                    'features': synthetic_data,
                    'error': str(e),
                    'error_type': type(e).__name__
                })
                
        return results
        
    async def run_load_test()
        self,
        model: ModelWrapper,
        test_data: List[Dict[str, Any]],
        target_qps: int = 1000,
        duration_seconds: int = 60
    ) -> Dict[str, Any]:
        """Run load testing"""
        results = {}
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'latencies': [],
            'throughput_qps': 0,
            'errors_by_type': defaultdict(int)
        }
        
        start_time = time.time()
        request_interval = 1.0 / target_qps
        
        async def make_request(data):
            try:
                start = time.time()
                await model.predict(data)
                latency = (time.time() - start) * 1000
                results['latencies'].append(latency)
                results['successful_requests'] += 1
            except Exception as e:
                results['failed_requests'] += 1
                results['errors_by_type'][type(e).__name__] += 1
                
        # Generate load
        tasks = []
        while time.time() - start_time < duration_seconds:
            data = test_data[results['total_requests'] % len(test_data)]
            task = asyncio.create_task(make_request(data))
            tasks.append(task)
            results['total_requests'] += 1
            
            await asyncio.sleep(request_interval)
            
        # Wait for all requests to complete
        await asyncio.gather(*tasks, return_exceptions=True)
        
        # Calculate throughput
        elapsed_time = time.time() - start_time
        results['throughput_qps'] = results['successful_requests'] / elapsed_time
        
        return results
        
    def _is_edge_case(self, features: Dict[str, Any], prediction: PredictionResult) -> bool:
        """Detect edge cases"""
        # Check for extreme values
        for key, value in features.items():
            if isinstance(value, (int, float)):
                if abs(value) > 1e6 or abs(value) < 1e-6:
                    return True
                    
        # Check for low confidence predictions
        if prediction.confidence is not None and prediction.confidence < 0.5:
            return True
            
        # Check for unusual latency
        if prediction.latency_ms > 1000:  # > 1 second
            return True
            
        return False
        
    async def run_regression_test()
        self,
        model: ModelWrapper,
        test_cases: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Run regression testing"""
        results = {}
            'passed': 0,
            'failed': 0,
            'failures': []
        }
        
        for test_case in test_cases:
            features = test_case['features']
            expected = test_case['expected']
            
            try:
                prediction = await model.predict(features)
                
                if prediction.prediction == expected:
                    results['passed'] += 1
                else:
                    results['failed'] += 1
                    results['failures'].append({)
                        'features': features,
                        'expected': expected,
                        'actual': prediction.prediction
                    })
                    
            except Exception as e:
                results['failed'] += 1
                results['failures'].append({)
                    'features': features,
                    'expected': expected,
                    'error': str(e)
                })
                
        return results


class DecisionEngine:
    """Automated decision making for model promotion"""
    
    def __init__()
        self,
        performance_monitor: PerformanceMonitor,
        model_registry: ModelRegistry
    ):
        self.performance_monitor = performance_monitor
        self.model_registry = model_registry
        self.promotion_history: List[Dict[str, Any]] = []
        self.decision_criteria: Dict[str, Any] = {}
            'min_sample_size': 1000,
            'confidence_level': 0.95,
            'min_improvement': 0.02,
            'max_latency_increase': 0.1,
            'min_test_duration_hours': 24
        }
        
    def evaluate_promotion()
        self,
        champion_id: str,
        challenger_id: str,
        custom_metrics: Optional[Dict[str, Callable]] = None
    ) -> Dict[str, Any]:
        """Evaluate if challenger should be promoted"""
        # Get model metadata
        champion_meta, _ = self.model_registry.get_model(champion_id)
        challenger_meta, _ = self.model_registry.get_model(challenger_id)
        
        # Get performance metrics
        champion_metrics = self.performance_monitor.get_metrics()
            champion_meta.model_id,
            champion_meta.version
        )
        challenger_metrics = self.performance_monitor.get_metrics()
            challenger_meta.model_id,
            challenger_meta.version
        )
        
        # Run statistical tests
        ab_result = self.performance_monitor.calculate_statistical_significance()
            champion_metrics,
            challenger_metrics
        )
        
        # Evaluate business metrics
        business_evaluation = self._evaluate_business_metrics()
            champion_metrics,
            challenger_metrics,
            custom_metrics
        )
        
        # Check decision criteria
        criteria_results = self._check_criteria(ab_result, business_evaluation)
        
        # Make decision
        should_promote = all(criteria_results.values())
        
        decision = {}
            'timestamp': datetime.utcnow(),
            'champion_id': champion_id,
            'challenger_id': challenger_id,
            'should_promote': should_promote,
            'ab_test_result': ab_result,
            'business_evaluation': business_evaluation,
            'criteria_results': criteria_results,
            'confidence_score': self._calculate_confidence_score()
                ab_result,
                business_evaluation,
                criteria_results
            )
        }
        
        # Record decision
        self.promotion_history.append(decision)
        
        return decision
        
    def _evaluate_business_metrics()
        self,
        champion_metrics: PerformanceMetrics,
        challenger_metrics: PerformanceMetrics,
        custom_metrics: Optional[Dict[str, Callable]] = None
    ) -> Dict[str, Any]:
        """Evaluate business metrics"""
        evaluation = {}
            'revenue_impact': 0,
            'cost_impact': 0,
            'risk_score': 0,
            'custom_metrics': {}
        }
        
        # Calculate standard business metrics
        # Revenue impact (simplified)
        if champion_metrics.accuracy and challenger_metrics.accuracy:
            accuracy_improvement = challenger_metrics.accuracy - champion_metrics.accuracy
            evaluation['revenue_impact'] = accuracy_improvement * 10000  # $10k per 1% accuracy
            
        # Cost impact (based on latency)
        latency_increase = ()
            challenger_metrics.average_latency_ms - champion_metrics.average_latency_ms
        )
        evaluation['cost_impact'] = latency_increase * 0.01  # $0.01 per ms increase
        
        # Risk score
        evaluation['risk_score'] = self._calculate_risk_score()
            champion_metrics,
            challenger_metrics
        )
        
        # Custom metrics
        if custom_metrics:
            for name, metric_func in custom_metrics.items():
                evaluation['custom_metrics'][name] = metric_func()
                    champion_metrics,
                    challenger_metrics
                )
                
        return evaluation
        
    def _check_criteria()
        self,
        ab_result: ABTestResult,
        business_evaluation: Dict[str, Any]
    ) -> Dict[str, bool]:
        """Check if promotion criteria are met"""
        criteria = {}
        
        # Sample size check
        criteria['sufficient_sample'] = ()
            ab_result.sample_size >= self.decision_criteria['min_sample_size']
        )
        
        # Statistical significance check
        criteria['statistically_significant'] = ()
            ab_result.statistical_significance >= self.decision_criteria['confidence_level']
        )
        
        # Improvement check
        criteria['sufficient_improvement'] = ()
            ab_result.effect_size >= self.decision_criteria['min_improvement']
        )
        
        # Latency check
        latency_increase = ()
            ab_result.challenger_metrics.average_latency_ms -
            ab_result.champion_metrics.average_latency_ms
        ) / ab_result.champion_metrics.average_latency_ms
        
        criteria['acceptable_latency'] = ()
            latency_increase <= self.decision_criteria['max_latency_increase']
        )
        
        # Business metrics check
        criteria['positive_business_impact'] = ()
            business_evaluation['revenue_impact'] - business_evaluation['cost_impact'] > 0
        )
        
        # Risk check
        criteria['acceptable_risk'] = business_evaluation['risk_score'] < 0.5
        
        return criteria
        
    def _calculate_risk_score()
        self,
        champion_metrics: PerformanceMetrics,
        challenger_metrics: PerformanceMetrics
    ) -> float:
        """Calculate risk score for model change"""
        risk_factors = []
        
        # Error rate increase
        if champion_metrics.total_predictions > 0:
            champion_error_rate = ()
                champion_metrics.failed_predictions / champion_metrics.total_predictions
            )
            challenger_error_rate = ()
                challenger_metrics.failed_predictions / challenger_metrics.total_predictions
                if challenger_metrics.total_predictions > 0 else 0
            )
            error_increase = max(0, challenger_error_rate - champion_error_rate)
            risk_factors.append(error_increase * 10)  # Weight: 10
            
        # Latency variance
        if challenger_metrics.p99_latency_ms > 0:
            latency_variance = ()
                challenger_metrics.p99_latency_ms / challenger_metrics.average_latency_ms
            )
            risk_factors.append(max(0, latency_variance - 2) * 0.5)  # Weight: 0.5
            
        # Sample size risk
        sample_size_risk = max(0, 1 - challenger_metrics.total_predictions / 10000)
        risk_factors.append(sample_size_risk * 0.3)  # Weight: 0.3
        
        return min(1.0, sum(risk_factors))
        
    def _calculate_confidence_score()
        self,
        ab_result: ABTestResult,
        business_evaluation: Dict[str, Any],
        criteria_results: Dict[str, bool]
    ) -> float:
        """Calculate overall confidence score"""
        factors = []
        
        # Statistical confidence
        factors.append(ab_result.statistical_significance)
        
        # Criteria met ratio
        criteria_score = sum(criteria_results.values()) / len(criteria_results)
        factors.append(criteria_score)
        
        # Business impact score
        if business_evaluation['revenue_impact'] != 0:
            roi = ()
                (business_evaluation['revenue_impact'] - business_evaluation['cost_impact']) /
                abs(business_evaluation['revenue_impact'])
            )
            factors.append(min(1.0, max(0.0, roi)))
            
        # Risk adjustment
        factors.append(1 - business_evaluation['risk_score'])
        
        return np.mean(factors)
        
    def set_promotion_criteria(self, criteria: Dict[str, Any]):
        """Update promotion criteria"""
        self.decision_criteria.update(criteria)
        
    def override_decision()
        self,
        decision_id: str,
        override_action: str,
        reason: str,
        user: str
    ):
        """Allow human override of automated decisions"""
        override = {}
            'decision_id': decision_id,
            'override_action': override_action,
            'reason': reason,
            'user': user,
            'timestamp': datetime.utcnow()
        }
        
        # Find and update the decision
        for decision in self.promotion_history:
            if decision.get('id') == decision_id:
                decision['override'] = override
                break
                
        logging.info(f"Decision {decision_id} overridden by {user}: {override_action}")


class ChampionChallengerSystem:
    """Main champion-challenger system"""
    
    def __init__()
        self,
        storage_path: Path,
        redis_client: Optional[redis.Redis] = None,
        max_concurrent_models: int = 10
    ):
        self.storage_path = storage_path
        self.redis_client = redis_client
        self.max_concurrent_models = max_concurrent_models
        
        # Initialize components
        self.model_registry = ModelRegistry(storage_path / "registry", redis_client)
        self.traffic_manager = TrafficManager(redis_client)
        self.performance_monitor = PerformanceMonitor()
        self.testing_framework = TestingFramework(self.model_registry)
        self.decision_engine = DecisionEngine(self.performance_monitor, self.model_registry)
        
        # Model cache
        self.loaded_models: Dict[str, ModelWrapper] = {}
        self.model_load_times: Dict[str, datetime] = {}
        self._model_lock = threading.RLock()
        
        # Audit log
        self.audit_log: List[Dict[str, Any]] = []
        
        # Background tasks
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=20)
        self._running = True
        self._background_tasks = []
        
        # Start background tasks
        self._start_background_tasks()
        
    def _start_background_tasks(self):
        """Start background tasks"""
        # Model lifecycle management
        task1 = asyncio.create_task(self._model_lifecycle_task())
        self._background_tasks.append(task1)
        
        # Performance monitoring
        task2 = asyncio.create_task(self._performance_monitoring_task())
        self._background_tasks.append(task2)
        
        # Garbage collection
        task3 = asyncio.create_task(self._garbage_collection_task())
        self._background_tasks.append(task3)
        
    async def _model_lifecycle_task(self):
        """Manage model lifecycle"""
        while self._running:
            try:
                # Check for models to promote
                for rule_id, rule in self.traffic_manager.routing_rules.items():
                    champion_id = rule['champion_id']
                    
                    for challenger_id in rule['challenger_ids']:
                        decision = self.decision_engine.evaluate_promotion()
                            champion_id,
                            challenger_id
                        )
                        
                        if decision['should_promote']:
                            await self.promote_challenger()
                                rule_id,
                                challenger_id,
                                decision
                            )
                            
                # Check for models to deprecate
                await self._check_model_deprecation()
                
            except Exception as e:
                logging.error(f"Error in model lifecycle task: {e}")
                
            await asyncio.sleep(300)  # Run every 5 minutes
            
    async def _performance_monitoring_task(self):
        """Monitor performance and trigger alerts"""
        while self._running:
            try:
                for model_id, model in self.loaded_models.items():
                    metadata, _ = self.model_registry.get_model(model_id)
                    metrics = self.performance_monitor.get_metrics()
                        metadata.model_id,
                        metadata.version
                    )
                    
                    # Update Prometheus metrics
                    model_performance_gauge.labels()
                        model_id=model_id,
                        metric='accuracy'
                    ).set(metrics.accuracy or 0)
                    
                    model_performance_gauge.labels()
                        model_id=model_id,
                        metric='latency_p95'
                    ).set(metrics.p95_latency_ms)
                    
                    # Check for degradation
                    baseline = metadata.metrics
                    if baseline and self.performance_monitor.check_degradation()
                        metadata.model_id,
                        metadata.version,
                        PerformanceMetrics()
                            model_id=metadata.model_id,
                            version=metadata.version,
                            average_latency_ms=baseline.get('average_latency_ms', 0),
                            accuracy=baseline.get('accuracy')
                        )
                    ):
                        await self._trigger_alert()
                            model_id,
                            "Performance degradation detected"
                        )
                        
            except Exception as e:
                logging.error(f"Error in performance monitoring task: {e}")
                
            await asyncio.sleep(60)  # Run every minute
            
    async def _garbage_collection_task(self):
        """Clean up unused models"""
        while self._running:
            try:
                with self._model_lock:
                    current_time = datetime.utcnow()
                    models_to_unload = []
                    
                    for model_id, load_time in self.model_load_times.items():
                        # Unload models not used for 1 hour
                        if (current_time - load_time).total_seconds() > 3600:
                            models_to_unload.append(model_id)
                            
                    for model_id in models_to_unload:
                        model = self.loaded_models.pop(model_id, None)
                        if model:
                            await model.unload()
                            del self.model_load_times[model_id]
                            logging.info(f"Unloaded model {model_id}")
                            
            except Exception as e:
                logging.error(f"Error in garbage collection task: {e}")
                
            await asyncio.sleep(300)  # Run every 5 minutes
            
    async def predict()
        self,
        features: Dict[str, Any],
        routing_rule_id: str,
        user_id: Optional[str] = None,
        region: Optional[str] = None,
        request_id: Optional[str] = None
    ) -> PredictionResult:
        """Make a prediction using the champion-challenger system"""
        if not request_id:
            request_id = str(uuid.uuid4())
            
        start_time = time.time()
        
        try:
            # Get model to use
            model_id, routing_decision = self.traffic_manager.get_model_for_request()
                routing_rule_id,
                user_id,
                features,
                region
            )
            
            # Load model if needed
            model = await self._get_or_load_model(model_id)
            
            # Make prediction
            result = await model.predict(features)
            result.metadata['routing_decision'] = routing_decision.value
            result.metadata['request_id'] = request_id
            
            # Record prediction
            self.performance_monitor.record_prediction(result)
            
            # Shadow mode - also run on challenger
            if routing_decision == RoutingDecision.SHADOW:
                rule = self.traffic_manager.routing_rules[routing_rule_id]
                challenger_id = np.random.choice(rule['challenger_ids'])
                challenger_model = await self._get_or_load_model(challenger_id)
                
                # Run async in background
                asyncio.create_task(self._shadow_predict())
                    challenger_model,
                    features,
                    request_id
                ))
                
            # Audit log
            self._log_prediction(request_id, model_id, routing_decision, result)
            
            # Update traffic allocation metrics
            traffic_allocation_gauge.labels(model_id=model_id).set()
                self._calculate_traffic_percentage(model_id)
            )
            
            return result
            
        except Exception as e:
            logging.error(f"Prediction error: {e}")
            model_errors_counter.labels()
                model_id=model_id,
                error_type=type(e).__name__
            ).inc()
            
            # Fallback to champion
            rule = self.traffic_manager.routing_rules.get(routing_rule_id)
            if rule:
                champion_id = rule['champion_id']
                champion_model = await self._get_or_load_model(champion_id)
                return await champion_model.predict(features)
            else:
                raise
                
    async def _get_or_load_model(self, model_id: str) -> ModelWrapper:
        """Get or load a model"""
        with self._model_lock:
            if model_id in self.loaded_models:
                self.model_load_times[model_id] = datetime.utcnow()
                return self.loaded_models[model_id]
                
            # Check capacity
            if len(self.loaded_models) >= self.max_concurrent_models:
                # Evict least recently used
                oldest_id = min()
                    self.model_load_times.keys(),
                    key=lambda k: self.model_load_times[k]
                )
                oldest_model = self.loaded_models.pop(oldest_id)
                await oldest_model.unload()
                del self.model_load_times[oldest_id]
                
            # Load model
            metadata, model_path = self.model_registry.get_model(model_id)
            model = BaseModel(model_id, metadata.version, model_path)
            await model.load()
            
            self.loaded_models[model_id] = model
            self.model_load_times[model_id] = datetime.utcnow()
            
            active_models_gauge.set(len(self.loaded_models))
            
            return model
            
    async def _shadow_predict()
        self,
        model: ModelWrapper,
        features: Dict[str, Any],
        request_id: str
    ):
        """Run shadow prediction"""
        try:
            result = await model.predict(features)
            result.metadata['is_shadow'] = True
            result.metadata['request_id'] = request_id
            self.performance_monitor.record_prediction(result)
        except Exception as e:
            logging.error(f"Shadow prediction error: {e}")
            
    def _log_prediction()
        self,
        request_id: str,
        model_id: str,
        routing_decision: RoutingDecision,
        result: PredictionResult
    ):
        """Log prediction for audit"""
        log_entry = {}
            'timestamp': datetime.utcnow(),
            'request_id': request_id,
            'model_id': model_id,
            'routing_decision': routing_decision.value,
            'latency_ms': result.latency_ms,
            'prediction': str(result.prediction)[:100],  # Truncate for storage
            'confidence': result.confidence
        }
        
        self.audit_log.append(log_entry)
        
        # Persist to Redis if available
        if self.redis_client:
            self.redis_client.lpush()
                "prediction_log",
                json.dumps(log_entry, default=str)
            )
            self.redis_client.ltrim("prediction_log", 0, 100000)  # Keep last 100k
            
    def _calculate_traffic_percentage(self, model_id: str) -> float:
        """Calculate traffic percentage for a model"""
        total_predictions = 0
        model_predictions = 0
        
        for predictions in self.performance_monitor.predictions.values():
            for pred in predictions[-1000:]:  # Last 1000 predictions
                total_predictions += 1
                if pred.model_id == model_id:
                    model_predictions += 1
                    
        return (model_predictions / total_predictions * 100) if total_predictions > 0 else 0
        
    async def promote_challenger()
        self,
        rule_id: str,
        challenger_id: str,
        decision: Dict[str, Any]
    ):
        """Promote challenger to champion"""
        try:
            rule = self.traffic_manager.routing_rules[rule_id]
            old_champion_id = rule['champion_id']
            
            # Update routing rule
            self.traffic_manager.set_routing_rule()
                rule_id,
                rule['strategy'],
                challenger_id,
                [old_champion_id],  # Old champion becomes challenger
                rule['config']
            )
            
            # Update model statuses
            self.model_registry.update_model_status(challenger_id, ModelStatus.CHAMPION)
            self.model_registry.update_model_status(old_champion_id, ModelStatus.CHALLENGER)
            
            # Log promotion
            self._log_promotion(old_champion_id, challenger_id, decision)
            
            logging.info(f"Promoted {challenger_id} to champion, demoted {old_champion_id}")
            
        except Exception as e:
            logging.error(f"Error promoting challenger: {e}")
            await self._trigger_alert(challenger_id, f"Promotion failed: {e}")
            
    def _log_promotion()
        self,
        old_champion_id: str,
        new_champion_id: str,
        decision: Dict[str, Any]
    ):
        """Log model promotion"""
        log_entry = {}
            'timestamp': datetime.utcnow(),
            'old_champion_id': old_champion_id,
            'new_champion_id': new_champion_id,
            'decision': decision,
            'event': 'model_promotion'
        }
        
        self.audit_log.append(log_entry)
        
        if self.redis_client:
            self.redis_client.lpush()
                "promotion_log",
                json.dumps(log_entry, default=str)
            )
            
    async def _check_model_deprecation(self):
        """Check and deprecate old models"""
        current_time = datetime.utcnow()
        
        for model_id, metadata in self.model_registry.models.items():
            if metadata.status in [ModelStatus.REGISTERED, ModelStatus.TESTING]:
                # Deprecate models older than 30 days without promotion
                if (current_time - metadata.created_at).days > 30:
                    self.model_registry.update_model_status()
                        model_id,
                        ModelStatus.DEPRECATED
                    )
                    logging.info(f"Deprecated model {model_id}")
                    
    async def _trigger_alert(self, model_id: str, message: str):
        """Trigger alert for model issues"""
        alert = {}
            'timestamp': datetime.utcnow(),
            'model_id': model_id,
            'message': message,
            'severity': 'high'
        }
        
        logging.error(f"ALERT: {model_id} - {message}")
        
        # Send to monitoring system
        if self.redis_client:
            self.redis_client.lpush()
                "model_alerts",
                json.dumps(alert, default=str)
            )
            
    async def rollback(self, rule_id: str):
        """Emergency rollback to previous champion"""
        try:
            rule = self.traffic_manager.routing_rules[rule_id]
            current_champion = rule['champion_id']
            
            # Find previous champion from audit log
            previous_champion = None
            for entry in reversed(self.audit_log):
                if (entry.get('event') == 'model_promotion' and)
                    entry.get('new_champion_id') == current_champion):
                    previous_champion = entry.get('old_champion_id')
                    break
                    
            if not previous_champion:
                raise ValueError("No previous champion found for rollback")
                
            # Perform rollback
            self.traffic_manager.set_routing_rule()
                rule_id,
                rule['strategy'],
                previous_champion,
                [current_champion],
                rule['config']
            )
            
            # Update statuses
            self.model_registry.update_model_status(previous_champion, ModelStatus.CHAMPION)
            self.model_registry.update_model_status(current_champion, ModelStatus.DEPRECATED)
            
            logging.info(f"Rolled back from {current_champion} to {previous_champion}")
            
            # Log rollback
            log_entry = {}
                'timestamp': datetime.utcnow(),
                'rule_id': rule_id,
                'rolled_back_from': current_champion,
                'rolled_back_to': previous_champion,
                'event': 'emergency_rollback'
            }
            self.audit_log.append(log_entry)
            
        except Exception as e:
            logging.error(f"Rollback failed: {e}")
            raise
            
    def get_system_status(self) -> Dict[str, Any]:
        """Get current system status"""
        status = {}
            'timestamp': datetime.utcnow(),
            'loaded_models': len(self.loaded_models),
            'active_routing_rules': len(self.traffic_manager.routing_rules),
            'total_predictions_last_hour': sum()
                len(preds) for preds in self.performance_monitor.predictions.values()
            ),
            'models_by_status': defaultdict(int),
            'current_champions': [],
            'current_challengers': []
        }
        
        # Count models by status
        for metadata in self.model_registry.models.values():
            status['models_by_status'][metadata.status.value] += 1
            
            if metadata.status == ModelStatus.CHAMPION:
                status['current_champions'].append(metadata.model_id)
            elif metadata.status == ModelStatus.CHALLENGER:
                status['current_challengers'].append(metadata.model_id)
                
        return status
        
    async def shutdown(self):
        """Graceful shutdown"""
        logging.info("Shutting down champion-challenger system")
        
        self._running = False
        
        # Cancel background tasks
        for task in self._background_tasks:
            task.cancel()
            
        # Unload all models
        with self._model_lock:
            for model in self.loaded_models.values():
                await model.unload()
                
        # Shutdown executor
        self._executor.shutdown(wait=True)
        
        logging.info("Shutdown complete")


def create_production_integration():
    """Create integration function for MASTER_PRODUCTION_INTEGRATION.py"""
    
    async def integrate_champion_challenger_system()
        config: Dict[str, Any],
        shared_components: Dict[str, Any]
    ) -> ChampionChallengerSystem:
        """
        Integrate champion-challenger system with production infrastructure
        
        Args:
            config: System configuration
            shared_components: Shared production components (redis, monitoring, etc)
            
        Returns:
            Configured ChampionChallengerSystem instance
        """
        # Extract configuration
        storage_path = Path(config.get('storage_path', '/tmp/models'))
        redis_client = shared_components.get('redis_client')
        max_concurrent_models = config.get('max_concurrent_models', 10)
        
        # Create system
        system = ChampionChallengerSystem()
            storage_path=storage_path,
            redis_client=redis_client,
            max_concurrent_models=max_concurrent_models
        )
        
        # Configure decision criteria
        if 'promotion_criteria' in config:
            system.decision_engine.set_promotion_criteria()
                config['promotion_criteria']
            )
            
        # Set up initial routing rules
        if 'routing_rules' in config:
            for rule_config in config['routing_rules']:
                system.traffic_manager.set_routing_rule(**rule_config)
                
        # Register models
        if 'initial_models' in config:
            for model_config in config['initial_models']:
                model = model_config.pop('model')
                metadata = ModelMetadata(**model_config['metadata'])
                system.model_registry.register_model(model, metadata)
                
        return system
        
    return integrate_champion_challenger_system


# Export integration function
integrate_champion_challenger = create_production_integration()


if __name__ == "__main__":
    # Example usage
    async def main():
        # Initialize system
        system = ChampionChallengerSystem()
            storage_path=Path("/tmp/champion_challenger"),
            redis_client=None,  # Would use actual Redis in production
            max_concurrent_models=5
        )
        
        # Register models
        # (In production, models would be actual trained models)
        
        # Create routing rule
        system.traffic_manager.set_routing_rule()
            rule_id="main_rule",
            strategy=DeploymentStrategy.PERCENTAGE,
            champion_id="model_v1",
            challenger_ids=["model_v2"],
            config={}
                'challenger_percentage': 10,
                'shadow_percentage': 5
            }
        )
        
        # Make predictions
        for i in range(100):
            features = {'feature1': i, 'feature2': i * 2}
            result = await system.predict()
                features=features,
                routing_rule_id="main_rule",
                user_id=f"user_{i}"
            )
            print(f"Prediction {i}: {result.prediction} from {result.model_id}")
            
        # Get system status
        status = system.get_system_status()
        print(f"System status: {status}")
        
        # Shutdown
        await system.shutdown()
        
    # Run example
    asyncio.run(main())