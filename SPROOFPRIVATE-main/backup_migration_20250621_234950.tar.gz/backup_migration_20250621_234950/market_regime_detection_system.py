"""
Market Regime Detection System

Advanced system for identifying market regimes using:
- Hidden Markov Models (HMM)
- Volatility regime detection
- Trend analysis
- Correlation regime shifts
- Machine learning clustering
- Real-time regime monitoring
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging
from datetime import datetime, timedelta
try:
    from hmmlearn import hmm
except ImportError:
    hmm = None
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, DBSCAN
from sklearn.mixture import GaussianMixture
from scipy import stats
from scipy.signal import find_peaks
import warnings
import json
import asyncio
from collections import deque
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class RegimeType(Enum):
    """Market regime types"""
    BULL_QUIET = "bull_quiet"
    BULL_VOLATILE = "bull_volatile"
    BEAR_QUIET = "bear_quiet"
    BEAR_VOLATILE = "bear_volatile"
    SIDEWAYS = "sideways"
    CRISIS = "crisis"
    RECOVERY = "recovery"
    UNCERTAIN = "uncertain"


class VolatilityRegime(Enum):
    """Volatility regime types"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    EXTREME = "extreme"


class TrendRegime(Enum):
    """Trend regime types"""
    STRONG_UP = "strong_up"
    UP = "up"
    SIDEWAYS = "sideways"
    DOWN = "down"
    STRONG_DOWN = "strong_down"


@dataclass
class RegimeIndicators:
    """Market regime indicators"""
    returns_mean: float
    returns_std: float
    volatility: float
    volatility_of_volatility: float
    skewness: float
    kurtosis: float
    trend_strength: float
    correlation_stability: float
    volume_ratio: float
    spread_ratio: float
    put_call_ratio: Optional[float] = None
    vix_level: Optional[float] = None
    term_structure_slope: Optional[float] = None


@dataclass
class MarketRegime:
    """Detected market regime"""
    regime_type: RegimeType
    volatility_regime: VolatilityRegime
    trend_regime: TrendRegime
    confidence: float
    start_date: datetime
    indicators: RegimeIndicators
    transition_probability: Optional[Dict[RegimeType, float]] = None
    expected_duration: Optional[int] = None  # days
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RegimeTransition:
    """Regime transition event"""
    from_regime: MarketRegime
    to_regime: MarketRegime
    transition_date: datetime
    transition_signals: List[str]
    confidence: float


class HMMRegimeDetector:
    """Hidden Markov Model for regime detection"""
    
    def __init__(self, n_states: int = 4):
        self.n_states = n_states
        self.model = None
        self.scaler = StandardScaler()
        self.fitted = False
        
    def prepare_features(self, returns: pd.Series, 
                        volume: Optional[pd.Series] = None) -> np.ndarray:
        """Prepare features for HMM"""
        features = []
        
        # Returns
        features.append(returns.values)
        
        # Rolling volatility
        vol_5 = returns.rolling(5).std()
        vol_20 = returns.rolling(20).std()
        features.append(vol_5.values)
        features.append(vol_20.values)
        
        # Rolling skewness
        skew = returns.rolling(20).skew()
        features.append(skew.values)
        
        # Volume ratio if available
        if volume is not None:
            volume_ratio = volume / volume.rolling(20).mean()
            features.append(volume_ratio.values)
            
        # Stack features
        X = np.column_stack(features)
        
        # Remove NaN rows
        mask = ~np.isnan(X).any(axis=1)
        return X[mask]
        
    def fit(self, returns: pd.Series, volume: Optional[pd.Series] = None):
        """Fit HMM model"""
        X = self.prepare_features(returns, volume)
        X_scaled = self.scaler.fit_transform(X)
        
        # Fit Gaussian HMM
        self.model = hmm.GaussianHMM()
            n_components=self.n_states,
            covariance_type="full",
            n_iter=100,
            random_state=42
        )
        
        self.model.fit(X_scaled)
        self.fitted = True
        
        logger.info(f"HMM fitted with {self.n_states} states")
        
    def predict(self, returns: pd.Series, 
                volume: Optional[pd.Series] = None) -> np.ndarray:
        """Predict regime states"""
        if not self.fitted:
            raise ValueError("Model not fitted")
            
        X = self.prepare_features(returns, volume)
        X_scaled = self.scaler.transform(X)
        
        states = self.model.predict(X_scaled)
        return states
        
    def get_regime_characteristics(self, returns: pd.Series, 
                                  states: np.ndarray) -> Dict[int, Dict[str, float]]:
        """Get characteristics of each regime"""
        characteristics = {}
        
        for state in range(self.n_states):
            mask = states == state
            state_returns = returns[mask]
            
            if len(state_returns) > 0:
                characteristics[state] = {}
                    'mean_return': state_returns.mean(),
                    'volatility': state_returns.std(),
                    'skewness': state_returns.skew(),
                    'kurtosis': state_returns.kurtosis(),
                    'frequency': len(state_returns) / len(returns),
                    'avg_duration': self._calculate_avg_duration(states, state)
                }
                
        return characteristics
        
    def _calculate_avg_duration(self, states: np.ndarray, state: int) -> float:
        """Calculate average duration in state"""
        durations = []
        current_duration = 0
        
        for s in states:
            if s == state:
                current_duration += 1
            else:
                if current_duration > 0:
                    durations.append(current_duration)
                current_duration = 0
                
        if current_duration > 0:
            durations.append(current_duration)
            
        return np.mean(durations) if durations else 0


class VolatilityRegimeDetector:
    """Detect volatility regimes"""
    
    def __init__(self, thresholds: Dict[str, float] = None):
        self.thresholds = thresholds or {}
            'low': 0.10,
            'normal': 0.20,
            'high': 0.35,
            'extreme': 0.50
        }
        
    def detect_regime(self, volatility: float) -> VolatilityRegime:
        """Detect volatility regime"""
        if volatility < self.thresholds['low']:
            return VolatilityRegime.LOW
        elif volatility < self.thresholds['normal']:
            return VolatilityRegime.NORMAL
        elif volatility < self.thresholds['high']:
            return VolatilityRegime.HIGH
        else:
            return VolatilityRegime.EXTREME
            
    def detect_volatility_clusters(self, returns: pd.Series,
                                 window: int = 20) -> pd.DataFrame:
        """Detect volatility clusters using GARCH approach"""
        volatility = returns.rolling(window).std() * np.sqrt(252)
        
        # Calculate volatility percentiles
        vol_percentiles = volatility.rank(pct=True)
        
        # Identify regime changes
        regimes = pd.DataFrame(index=returns.index)
        regimes['volatility'] = volatility
        regimes['regime'] = volatility.apply(self.detect_regime)
        regimes['percentile'] = vol_percentiles
        
        # Detect cluster changes
        regimes['regime_change'] = regimes['regime'] != regimes['regime'].shift(1)
        
        return regimes


class TrendRegimeDetector:
    """Detect trend regimes"""
    
    def __init__(self):
        self.lookback_periods = [20, 50, 200]
        
    def calculate_trend_strength(self, prices: pd.Series, 
                               lookback: int = 20) -> pd.Series:
        """Calculate trend strength using linear regression"""
        def trend_strength(window):
            if len(window) < lookback:
                return np.nan
            x = np.arange(len(window))
            slope, _, r_value, _, _ = stats.linregress(x, window)
            return slope * r_value**2  # Trend strength
            
        return prices.rolling(lookback).apply(trend_strength)
        
    def detect_regime(self, prices: pd.Series) -> pd.DataFrame:
        """Detect trend regime"""
        regimes = pd.DataFrame(index=prices.index)
        
        # Calculate various trend indicators
        for period in self.lookback_periods:
            ma = prices.rolling(period).mean()
            regimes[f'ma_{period}'] = ma
            regimes[f'position_{period}'] = (prices > ma).astype(int)
            
        # Calculate trend strength
        regimes['trend_strength_20'] = self.calculate_trend_strength(prices, 20)
        regimes['trend_strength_50'] = self.calculate_trend_strength(prices, 50)
        
        # Determine regime
        def classify_trend(row):
            strength = row['trend_strength_20']
            if pd.isna(strength):
                return TrendRegime.SIDEWAYS
                
            if strength > 0.5:
                return TrendRegime.STRONG_UP
            elif strength > 0.1:
                return TrendRegime.UP
            elif strength < -0.5:
                return TrendRegime.STRONG_DOWN
            elif strength < -0.1:
                return TrendRegime.DOWN
            else:
                return TrendRegime.SIDEWAYS
                
        regimes['trend_regime'] = regimes.apply(classify_trend, axis=1)
        
        return regimes


class MarketRegimeClassifier:
    """Classify overall market regime"""
    
    def __init__(self):
        self.regime_rules = self._define_regime_rules()
        
    def _define_regime_rules(self) -> Dict[RegimeType, Callable]:
        """Define rules for regime classification"""
        rules = {}
            RegimeType.BULL_QUIET: lambda i: ()
                i.returns_mean > 0.0001 and 
                i.volatility < 0.15 and
                i.trend_strength > 0.3
            ),
            RegimeType.BULL_VOLATILE: lambda i: ()
                i.returns_mean > 0.0001 and
                i.volatility >= 0.15 and
                i.trend_strength > 0.1
            ),
            RegimeType.BEAR_QUIET: lambda i: ()
                i.returns_mean < -0.0001 and
                i.volatility < 0.15 and
                i.trend_strength < -0.3
            ),
            RegimeType.BEAR_VOLATILE: lambda i: ()
                i.returns_mean < -0.0001 and
                i.volatility >= 0.15 and
                i.trend_strength < -0.1
            ),
            RegimeType.CRISIS: lambda i: ()
                i.volatility > 0.30 and
                i.skewness < -1 and
                i.correlation_stability < 0.5
            ),
            RegimeType.SIDEWAYS: lambda i: ()
                abs(i.returns_mean) < 0.0001 and
                abs(i.trend_strength) < 0.1
            )
        }
        return rules
        
    def classify(self, indicators: RegimeIndicators) -> Tuple[RegimeType, float]:
        """Classify market regime based on indicators"""
        scores = {}
        
        for regime_type, rule in self.regime_rules.items():
            try:
                if rule(indicators):
                    scores[regime_type] = 1.0
                else:
                    scores[regime_type] = 0.0
            except:
                scores[regime_type] = 0.0
                
        # If no clear regime, use probabilistic approach
        if sum(scores.values()) == 0:
            return RegimeType.UNCERTAIN, 0.5
            
        # Get regime with highest score
        best_regime = max(scores, key=scores.get)
        confidence = scores[best_regime] / max(sum(scores.values()), 1)
        
        return best_regime, confidence


class RegimeChangeDetector:
    """Detect regime changes"""
    
    def __init__(self, sensitivity: float = 0.05):
        self.sensitivity = sensitivity
        self.recent_regimes = deque(maxlen=20)
        
    def detect_change(self, current_regime: MarketRegime) -> Optional[RegimeTransition]:
        """Detect if regime has changed"""
        if len(self.recent_regimes) == 0:
            self.recent_regimes.append(current_regime)
            return None
            
        previous_regime = self.recent_regimes[-1]
        
        # Check if regime type changed
        if current_regime.regime_type != previous_regime.regime_type:
            # Identify transition signals
            signals = self._identify_transition_signals()
                previous_regime, current_regime
            )
            
            transition = RegimeTransition()
                from_regime=previous_regime,
                to_regime=current_regime,
                transition_date=current_regime.start_date,
                transition_signals=signals,
                confidence=current_regime.confidence
            )
            
            self.recent_regimes.append(current_regime)
            return transition
            
        self.recent_regimes.append(current_regime)
        return None
        
    def _identify_transition_signals(self, from_regime: MarketRegime,
                                   to_regime: MarketRegime) -> List[str]:
        """Identify what caused the regime transition"""
        signals = []
        
        # Volatility change
        if from_regime.volatility_regime != to_regime.volatility_regime:
            signals.append(f"Volatility: {from_regime.volatility_regime.value} -> ")
                         f"{to_regime.volatility_regime.value}")
                         
        # Trend change
        if from_regime.trend_regime != to_regime.trend_regime:
            signals.append(f"Trend: {from_regime.trend_regime.value} -> ")
                         f"{to_regime.trend_regime.value}")
                         
        # Returns change
        returns_change = (to_regime.indicators.returns_mean -)
                         from_regime.indicators.returns_mean)
        if abs(returns_change) > 0.0001:
            signals.append(f"Returns shifted by {returns_change:.2%}")
            
        return signals


class MarketRegimeDetectionSystem:
    """Complete market regime detection system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.hmm_detector = HMMRegimeDetector(n_states=config.get('n_states', 4))
        self.volatility_detector = VolatilityRegimeDetector()
        self.trend_detector = TrendRegimeDetector()
        self.regime_classifier = MarketRegimeClassifier()
        self.change_detector = RegimeChangeDetector()
        
        self.current_regime: Optional[MarketRegime] = None
        self.regime_history: List[MarketRegime] = []
        self.transition_history: List[RegimeTransition] = []
        self.is_running = False
        
    def calculate_indicators(self, data: pd.DataFrame) -> RegimeIndicators:
        """Calculate regime indicators from market data"""
        returns = data['returns'] if 'returns' in data else data['close'].pct_change()
        
        # Basic statistics
        returns_mean = returns.mean()
        returns_std = returns.std()
        volatility = returns_std * np.sqrt(252)
        
        # Higher moments
        skewness = returns.skew()
        kurtosis = returns.kurtosis()
        
        # Volatility of volatility
        rolling_vol = returns.rolling(20).std()
        vol_of_vol = rolling_vol.std() / rolling_vol.mean() if rolling_vol.mean() > 0 else 0
        
        # Trend strength
        if 'close' in data:
            trend_strength = self.trend_detector.calculate_trend_strength()
                data['close'], 20
            ).iloc[-1]
        else:
            trend_strength = 0
            
        # Correlation stability (simplified)
        correlation_stability = 0.8  # Placeholder
        
        # Volume ratio
        if 'volume' in data:
            volume_ratio = (data['volume'].iloc[-20:].mean() /)
                          data['volume'].iloc[-60:-20].mean())
        else:
            volume_ratio = 1.0
            
        # Spread ratio
        if 'high' in data and 'low' in data:
            spread = (data['high'] - data['low']) / data['close']
            spread_ratio = spread.iloc[-20:].mean() / spread.iloc[-60:-20].mean()
        else:
            spread_ratio = 1.0
            
        # Optional indicators
        put_call_ratio = data.get('put_call_ratio', pd.Series()).iloc[-1] if 'put_call_ratio' in data else None
        vix_level = data.get('vix', pd.Series()).iloc[-1] if 'vix' in data else None
        
        return RegimeIndicators()
            returns_mean=returns_mean,
            returns_std=returns_std,
            volatility=volatility,
            volatility_of_volatility=vol_of_vol,
            skewness=skewness,
            kurtosis=kurtosis,
            trend_strength=trend_strength,
            correlation_stability=correlation_stability,
            volume_ratio=volume_ratio,
            spread_ratio=spread_ratio,
            put_call_ratio=put_call_ratio,
            vix_level=vix_level
        )
        
    def detect_regime(self, data: pd.DataFrame) -> MarketRegime:
        """Detect current market regime"""
        # Calculate indicators
        indicators = self.calculate_indicators(data)
        
        # Detect sub-regimes
        volatility_regime = self.volatility_detector.detect_regime(indicators.volatility)
        
        if 'close' in data:
            trend_regimes = self.trend_detector.detect_regime(data['close'])
            trend_regime = trend_regimes['trend_regime'].iloc[-1]
        else:
            trend_regime = TrendRegime.SIDEWAYS
            
        # Classify overall regime
        regime_type, confidence = self.regime_classifier.classify(indicators)
        
        # Create regime object
        regime = MarketRegime()
            regime_type=regime_type,
            volatility_regime=volatility_regime,
            trend_regime=trend_regime,
            confidence=confidence,
            start_date=data.index[-1] if isinstance(data.index, pd.DatetimeIndex) else datetime.now(),
            indicators=indicators
        )
        
        # Estimate regime duration and transitions
        if self.hmm_detector.fitted:
            self._estimate_regime_dynamics(regime, data)
            
        return regime
        
    def _estimate_regime_dynamics(self, regime: MarketRegime, data: pd.DataFrame):
        """Estimate regime duration and transition probabilities"""
        try:
            # Get HMM state
            returns = data['returns'] if 'returns' in data else data['close'].pct_change()
            current_state = self.hmm_detector.predict(returns)[-1]
            
            # Transition probabilities
            trans_matrix = self.hmm_detector.model.transmat_
            transition_probs = {}
            
            # Map HMM states to regime types (simplified)
            state_mapping = {}
                0: RegimeType.BULL_QUIET,
                1: RegimeType.BULL_VOLATILE,
                2: RegimeType.BEAR_QUIET,
                3: RegimeType.BEAR_VOLATILE
            }
            
            for next_state, prob in enumerate(trans_matrix[current_state]):
                if next_state in state_mapping:
                    transition_probs[state_mapping[next_state]] = prob
                    
            regime.transition_probability = transition_probs
            
            # Expected duration (geometric distribution)
            stay_probability = trans_matrix[current_state, current_state]
            if stay_probability < 0.999:
                regime.expected_duration = int(1 / (1 - stay_probability))
                
        except Exception as e:
            logger.error(f"Error estimating regime dynamics: {e}")
            
    def train_hmm(self, historical_data: pd.DataFrame):
        """Train HMM on historical data"""
        returns = historical_data['returns'] if 'returns' in historical_data else \
                 historical_data['close'].pct_change()
        volume = historical_data.get('volume')
        
        self.hmm_detector.fit(returns, volume)
        logger.info("HMM training completed")
        
    async def monitor_regime_changes(self, data_stream):
        """Monitor for regime changes in real-time"""
        self.is_running = True
        
        while self.is_running:
            try:
                # Get latest data
                data = await data_stream.get_latest_data()
                
                # Detect current regime
                current_regime = self.detect_regime(data)
                
                # Check for regime change
                transition = self.change_detector.detect_change(current_regime)
                
                if transition:
                    logger.warning(f"Regime change detected: ")
                                 f"{transition.from_regime.regime_type.value} -> "
                                 f"{transition.to_regime.regime_type.value}")
                    self.transition_history.append(transition)
                    
                    # Notify listeners
                    await self._notify_regime_change(transition)
                    
                self.current_regime = current_regime
                self.regime_history.append(current_regime)
                
                # Sleep based on config
                await asyncio.sleep(self.config.get('update_interval', 60))
                
            except Exception as e:
                logger.error(f"Error in regime monitoring: {e}")
                await asyncio.sleep(60)
                
    async def _notify_regime_change(self, transition: RegimeTransition):
        """Notify about regime change"""
        # In production, this would send notifications to:
        # - Trading systems
        # - Risk management
        # - Portfolio managers
        # - Alert systems
        pass
        
    def generate_regime_report(self) -> Dict[str, Any]:
        """Generate regime analysis report"""
        if not self.current_regime:
            return {"error": "No regime detected yet"}
            
        report = {}
            'timestamp': datetime.now().isoformat(),
            'current_regime': {}
                'type': self.current_regime.regime_type.value,
                'volatility': self.current_regime.volatility_regime.value,
                'trend': self.current_regime.trend_regime.value,
                'confidence': self.current_regime.confidence,
                'expected_duration': self.current_regime.expected_duration,
                'indicators': {}
                    'volatility': self.current_regime.indicators.volatility,
                    'returns_mean': self.current_regime.indicators.returns_mean,
                    'trend_strength': self.current_regime.indicators.trend_strength,
                    'skewness': self.current_regime.indicators.skewness
                }
            },
            'regime_history': self._summarize_regime_history(),
            'recent_transitions': self._summarize_transitions(),
            'regime_statistics': self._calculate_regime_statistics()
        }
        
        return report
        
    def _summarize_regime_history(self) -> List[Dict[str, Any]]:
        """Summarize regime history"""
        summary = []
        
        # Group consecutive same regimes
        if not self.regime_history:
            return summary
            
        current_group = {}
            'regime': self.regime_history[0].regime_type.value,
            'start': self.regime_history[0].start_date,
            'end': self.regime_history[0].start_date,
            'duration': 1
        }
        
        for regime in self.regime_history[1:]:
            if regime.regime_type.value == current_group['regime']:
                current_group['end'] = regime.start_date
                current_group['duration'] += 1
            else:
                summary.append(current_group)
                current_group = {}
                    'regime': regime.regime_type.value,
                    'start': regime.start_date,
                    'end': regime.start_date,
                    'duration': 1
                }
                
        summary.append(current_group)
        return summary[-10:]  # Last 10 regime periods
        
    def _summarize_transitions(self) -> List[Dict[str, Any]]:
        """Summarize recent transitions"""
        summary = []
        
        for transition in self.transition_history[-5:]:
            summary.append({)
                'date': transition.transition_date.isoformat(),
                'from': transition.from_regime.regime_type.value,
                'to': transition.to_regime.regime_type.value,
                'signals': transition.transition_signals,
                'confidence': transition.confidence
            })
            
        return summary
        
    def _calculate_regime_statistics(self) -> Dict[str, Any]:
        """Calculate regime statistics"""
        if not self.regime_history:
            return {}
            
        regime_counts = {}
        regime_durations = {}
        
        for regime in self.regime_history:
            regime_type = regime.regime_type.value
            regime_counts[regime_type] = regime_counts.get(regime_type, 0) + 1
            
        # Calculate average durations
        for regime_summary in self._summarize_regime_history():
            regime_type = regime_summary['regime']
            if regime_type not in regime_durations:
                regime_durations[regime_type] = []
            regime_durations[regime_type].append(regime_summary['duration'])
            
        avg_durations = {}
            regime: np.mean(durations) 
            for regime, durations in regime_durations.items()
        }
        
        return {}
            'regime_frequencies': {}
                regime: count / len(self.regime_history) 
                for regime, count in regime_counts.items()
            },
            'average_durations': avg_durations,
            'total_transitions': len(self.transition_history)
        }
        
    def plot_regime_analysis(self, data: pd.DataFrame, 
                            save_path: Optional[str] = None):
        """Plot regime analysis"""
        fig, axes = plt.subplots(3, 1, figsize=(15, 12))
        
        # Plot 1: Price with regime colors
        ax1 = axes[0]
        if 'close' in data:
            ax1.plot(data.index, data['close'], label='Price', color='black', alpha=0.7)
            
            # Color background by regime
            if self.regime_history:
                for i, regime in enumerate(self.regime_history):
                    color_map = {}
                        RegimeType.BULL_QUIET: 'lightgreen',
                        RegimeType.BULL_VOLATILE: 'green',
                        RegimeType.BEAR_QUIET: 'lightcoral',
                        RegimeType.BEAR_VOLATILE: 'red',
                        RegimeType.SIDEWAYS: 'yellow',
                        RegimeType.CRISIS: 'darkred'
                    }
                    color = color_map.get(regime.regime_type, 'gray')
                    
                    start_idx = i
                    end_idx = i + 1 if i < len(self.regime_history) - 1 else len(data)
                    
                    ax1.axvspan(start_idx, end_idx, alpha=0.3, color=color)
                    
        ax1.set_title('Price with Market Regimes')
        ax1.set_ylabel('Price')
        ax1.legend()
        
        # Plot 2: Volatility regimes
        ax2 = axes[1]
        returns = data['returns'] if 'returns' in data else data['close'].pct_change()
        volatility = returns.rolling(20).std() * np.sqrt(252)
        
        ax2.plot(data.index, volatility, label='Volatility', color='blue')
        ax2.axhline(y=0.10, color='green', linestyle='--', label='Low Vol')
        ax2.axhline(y=0.20, color='orange', linestyle='--', label='Normal Vol')
        ax2.axhline(y=0.35, color='red', linestyle='--', label='High Vol')
        
        ax2.set_title('Volatility Regimes')
        ax2.set_ylabel('Annualized Volatility')
        ax2.legend()
        
        # Plot 3: Regime probabilities over time
        ax3 = axes[2]
        if self.hmm_detector.fitted and len(returns.dropna()) > 0:
            states = self.hmm_detector.predict(returns.dropna())
            
            # Plot state probabilities
            for state in range(self.hmm_detector.n_states):
                state_prob = (states == state).astype(float)
                state_prob = pd.Series(state_prob).rolling(20).mean()
                ax3.plot(state_prob, label=f'State {state}')
                
        ax3.set_title('Regime Probabilities (HMM)')
        ax3.set_ylabel('Probability')
        ax3.set_xlabel('Time')
        ax3.legend()
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
        return fig


def main():
    """Example usage of market regime detection system"""
    
    # Configuration
    config = {}
        'n_states': 4,
        'update_interval': 60,
        'sensitivity': 0.05
    }
    
    # Create system
    system = MarketRegimeDetectionSystem(config)
    
    # Generate sample data
    np.random.seed(42)
    dates = pd.date_range(start='2020-01-01', end='2023-12-31', freq='D')
    
    # Simulate different regimes
    n_days = len(dates)
    prices = np.zeros(n_days)
    volumes = np.zeros(n_days)
    
    # Initial price
    prices[0] = 100
    volumes[0] = 1000000
    
    # Generate regimes
    regime_changes = [0, 200, 400, 600, 800, 1000]
    regimes = ['bull_quiet', 'bull_volatile', 'bear_volatile', 
               'sideways', 'bull_quiet', 'crisis']
    
    for i in range(1, n_days):
        # Determine current regime
        regime_idx = 0
        for j, change_point in enumerate(regime_changes[1:]):
            if i >= change_point:
                regime_idx = j + 1
                
        current_regime = regimes[regime_idx]
        
        # Generate returns based on regime
        if current_regime == 'bull_quiet':
            ret = np.random.normal(0.0005, 0.01)
        elif current_regime == 'bull_volatile':
            ret = np.random.normal(0.0003, 0.025)
        elif current_regime == 'bear_volatile':
            ret = np.random.normal(-0.0005, 0.03)
        elif current_regime == 'sideways':
            ret = np.random.normal(0, 0.008)
        elif current_regime == 'crisis':
            ret = np.random.normal(-0.001, 0.04)
            if np.random.random() < 0.1:  # 10% chance of large drop
                ret = -0.05
        else:
            ret = 0
            
        prices[i] = prices[i-1] * (1 + ret)
        volumes[i] = volumes[i-1] * np.random.uniform(0.8, 1.2)
        
    # Create DataFrame
    data = pd.DataFrame({)
        'close': prices,
        'volume': volumes,
        'high': prices * np.random.uniform(1.001, 1.01, n_days),
        'low': prices * np.random.uniform(0.99, 0.999, n_days)
    }, index=dates)
    
    data['returns'] = data['close'].pct_change()
    
    # Train HMM
    print("Training HMM model...")
    system.train_hmm(data)
    
    # Detect regimes for different time periods
    print("\nDetecting regimes...")
    for i in range(100, len(data), 50):
        window_data = data.iloc[:i]
        regime = system.detect_regime(window_data)
        
        # Check for transitions
        transition = system.change_detector.detect_change(regime)
        if transition:
            print(f"\nRegime Change at {regime.start_date.strftime('%Y-%m-%d')}:")
            print(f"  From: {transition.from_regime.regime_type.value}")
            print(f"  To: {transition.to_regime.regime_type.value}")
            print(f"  Signals: {transition.transition_signals}")
            
    # Generate report
    report = system.generate_regime_report()
    print("\n\nRegime Analysis Report")
    print("=" * 50)
    print(f"Current Regime: {report['current_regime']['type']}")
    print(f"Confidence: {report['current_regime']['confidence']:.2f}")
    print(f"Expected Duration: {report['current_regime'].get('expected_duration', 'N/A')} days")
    
    print("\nCurrent Indicators:")
    for key, value in report['current_regime']['indicators'].items():
        if isinstance(value, float):
            print(f"  {key}: {value:.4f}")
            
    print("\nRegime Statistics:")
    if 'regime_statistics' in report:
        print("  Frequencies:")
        for regime, freq in report['regime_statistics'].get('regime_frequencies', {}).items():
            print(f"    {regime}: {freq:.2%}")
            
    # Create visualizations
    fig = system.plot_regime_analysis(data, 'regime_analysis.png')
    print("\nVisualization saved to 'regime_analysis.png'")


if __name__ == "__main__":
    main()

# Class aliases and stubs
MarketRegimeDetection = MarketRegime


# Module exports
__all__ = ['RegimeIndicators', 'MarketRegimeDetectionSystem', 'MarketRegimeDetection', 'MarketRegimeClassifier', 'RegimeType', 'HMMRegimeDetector', 'VolatilityRegimeDetector', 'TrendRegime', 'RegimeChangeDetector', 'TrendRegimeDetector', 'RegimeTransition', 'VolatilityRegime', 'MarketRegime']
