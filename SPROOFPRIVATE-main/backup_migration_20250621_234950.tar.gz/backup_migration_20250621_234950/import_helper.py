#!/usr/bin/env python3
"""Import helper to properly load core modules with their dependencies."""

import sys
import os

# Add all necessary paths
sys.path.insert(0, '/home/harry/alpaca-mcp')
sys.path.insert(0, '/home/harry/alpaca-mcp/src')
sys.path.insert(0, '/home/harry/alpaca-mcp/core')

# Import core modules through the package
import core

# Now export the components we need
ConfigManager = core.ConfigManager
TradingBot = core.TradingBot
DatabaseManager = core.DatabaseManager
ErrorHandler = core.ErrorHandler
HealthMonitor = core.HealthMonitor
GPUResourceManager = core.GPUResourceManager
DataCoordinator = core.DataCoordinator
ModelManager = core.ModelManager