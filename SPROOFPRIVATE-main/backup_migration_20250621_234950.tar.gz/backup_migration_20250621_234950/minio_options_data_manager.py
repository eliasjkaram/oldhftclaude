#!/usr/bin/env python3
"""
MinIO Options Data Manager
Unified interface for accessing historical options data from MinIO bucket
Supports 2009-2016 data from options/ and options-complete/ directories
"""

import pandas as pd
import numpy as np
from minio import Minio
from io import StringIO
import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple, Union
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import json

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


class MinIOOptionsDataManager:
    """
    High-performance options data manager for MinIO stockdb bucket
    Provides unified access to 2009-2016 historical options data
    """
    
    def __init__(self):
        # Load credentials from environment
        self.endpoint = os.getenv('MINIO_ENDPOINT', 'https://uschristmas.us')
        self.access_key = os.getenv('MINIO_ACCESS_KEY', os.getenv('MINIO_ACCESS_KEY'))
        self.secret_key = os.getenv('MINIO_SECRET_KEY', os.getenv('MINIO_SECRET_KEY'))
        self.bucket_name = os.getenv('MINIO_BUCKET', 'stockdb')
        
        # Initialize MinIO client
        self.client = Minio()
            self.endpoint.replace('https://', '').replace('http://', ''),
            access_key=self.access_key,
            secret_key=self.secret_key,
            secure=True
        )
        
        # Data source mapping
        self.data_sources = {}
            '2009': 'options/',
            '2010': 'options-complete/',
            '2011': 'options-complete/',
            '2012': 'options-complete/',
            '2013': 'options-complete/',
            '2014': 'options-complete/',
            '2015': 'options-complete/',
            '2016': 'options-complete/'
        }
        
        self.logger = logging.getLogger(__name__)
        
    def get_available_dates(self, year: int = None) -> List[str]:
        """Get list of available trading dates"""
        dates = []
        
        if year:
            years = [str(year)]
        else:
            years = list(self.data_sources.keys()
            
for year_str in years:
            source_dir = self.data_sources.get(year_str)
            if not source_dir:
                continue
                
            try:
                if source_dir == 'options/':
                    # options/ has year subdirectories
                    prefix = f"{source_dir}{year_str}/"
                else:
                    # options-complete/ has flat structure
                    prefix = source_dir
                    
                objects = self.client.list_objects(self.bucket_name, prefix=prefix)
                
                for obj in objects:
                    filename = obj.object_name.split('/')[-1]
                    if 'options' in filename and filename.endswith('.csv'):
                        # Extract date from filename (YYYY-MM-DD format)
                        date_part = filename.split('options')[0].rstrip('-')
                        if len(date_part) == 10:  # YYYY-MM-DD
                            dates.append(date_part)
                            
            except Exception as e:
                self.logger.error(f"Error listing dates for {year_str}: {e}")
                
        return sorted(list(set(dates))
    
    def load_options_data(self, date: str, symbols: List[str] = None) -> pd.DataFrame:
        """
        Load options data for specific date
        
        Args:
            date: Date in YYYY-MM-DD format
            symbols: Optional list of symbols to filter by
            
        Returns:
            DataFrame with options data
        """
        year = date[:4]
        source_dir = self.data_sources.get(year)
        
        if not source_dir:
            raise ValueError(f"No data source available for year {year}")
            
        # Construct object path
        if source_dir == 'options/':
            object_path = f"{source_dir}{year}/{date}options.csv"
        else:
            object_path = f"{source_dir}{date}options.csv"
            
        try:
            # Get object from MinIO
            response = self.client.get_object(self.bucket_name, object_path)
            data = response.read().decode('utf-8')
            
            # Load into DataFrame
            df = pd.read_csv(StringIO(data)
            
            # Filter by symbols if provided
            if symbols:
                df = df[df['underlying'].isin(symbols)]
                
            # Add metadata
            df['data_date'] = date
            df['data_source'] = source_dir
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error loading data for {date}: {e}")
            return pd.DataFrame()
    
    def load_date_range(self, start_date: str, end_date: str, 
                       symbols: List[str] = None, max_workers: int = 4) -> pd.DataFrame:
        """
        Load options data for date range using parallel processing
        
        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format  
            symbols: Optional list of symbols to filter by
            max_workers: Number of parallel workers
            
        Returns:
            Combined DataFrame with options data
        """
        # Get available dates in range
        all_dates = self.get_available_dates()
        date_range = [d for d in all_dates if start_date <= d <= end_date]
        
        if not date_range:
            self.logger.warning(f"No data available for range {start_date} to {end_date}")
            return pd.DataFrame()
            
        self.logger.info(f"Loading {len(date_range)} dates from {start_date} to {end_date}")
        
        # Load data in parallel
        dataframes = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_date = {}
                executor.submit(self.load_options_data, date, symbols): date 
                for date in date_range
            }
            
            for future in as_completed(future_to_date):
                date = future_to_date[future]
                try:
                    df = future.result()
                    if not df.empty:
                        dataframes.append(df)
                except Exception as e:
                    self.logger.error(f"Error processing {date}: {e}")
                    
        if dataframes:
            result = pd.concat(dataframes, ignore_index=True)
            self.logger.info(f"Loaded {len(result)} total records")
            return result
        else:
            return pd.DataFrame()
    
    def get_symbol_data(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Get all options data for specific symbol in date range"""
        return self.load_date_range(start_date, end_date, symbols=[symbol])
    
    def get_market_stats(self, date: str) -> Dict:
        """Get market statistics for specific date"""
        df = self.load_options_data(date)
        
        if df.empty:
            return {}
            
        # Calculate put/call ratio safely
        puts = len(df[df['type'] == 'P'])
        calls = len(df[df['type'] == 'C'])
        put_call_ratio = puts / calls if calls > 0 else 0
        
        stats = {}
            'date': date,
            'total_contracts': len(df),
            'unique_symbols': df['underlying'].nunique(),
            'total_volume': df['volume'].sum(),
            'total_open_interest': df['open_interest'].sum(),
            'avg_implied_vol': df['implied_volatility'].mean(),
            'put_call_ratio': put_call_ratio,
            'top_symbols': df.groupby('underlying')['volume'].sum().nlargest(10).to_dict()
        }
        
        return stats
    
    def find_arbitrage_opportunities(self, date: str, min_profit: float = 100) -> pd.DataFrame:
        """
        Simple arbitrage opportunity scanner
        Looks for basic put-call parity violations
        """
        df = self.load_options_data(date)
        
        if df.empty:
            return pd.DataFrame()
            
        # Group by underlying, expiration, strike
        opportunities = []
        
        grouped = df.groupby(['underlying', 'expiration', 'strike'])
        
        for (symbol, exp, strike), group in grouped:
            puts = group[group['type'] == 'P']
            calls = group[group['type'] == 'C']
            
            if len(puts) == 1 and len(calls) == 1:
                put = puts.iloc[0]
                call = calls.iloc[0]
                
                # Simple put-call parity check
                # C - P = S - K*e^(-r*T) (simplified assuming r=0, T small)
                theoretical_diff = 0  # Simplified - would need stock price and rates
                actual_diff = (call['bid'] + call['ask'])/2 - (put['bid'] + put['ask'])/2
                
                profit_potential = abs(actual_diff - theoretical_diff)
                
                if profit_potential > min_profit/100:  # Convert to price units
                    opportunities.append({)
                        'symbol': symbol,
                        'expiration': exp,
                        'strike': strike,
                        'profit_potential': profit_potential,
                        'call_mid': (call['bid'] + call['ask'])/2,
                        'put_mid': (put['bid'] + put['ask'])/2,
                        'call_volume': call['volume'],
                        'put_volume': put['volume']
                    })
        
        if opportunities:
            return pd.DataFrame(opportunities).sort_values('profit_potential', ascending=False)
        else:
            return pd.DataFrame()
    
    def export_to_csv(self, df: pd.DataFrame, filename: str):
        """Export DataFrame to CSV file"""
        df.to_csv(filename, index=False)
        self.logger.info(f"Exported {len(df)} records to {filename}")
    
    def get_data_summary(self) -> Dict:
        """Get summary of available data"""
        summary = {}
            'available_years': list(self.data_sources.keys()),
            'data_sources': self.data_sources,
            'total_coverage': '2009-2016 (8 years)',
            'estimated_size': '140+ GB',
            'estimated_files': '5500+'
        }
        
        # Get sample of available dates
        sample_dates = self.get_available_dates()[:10]
        summary['sample_dates'] = sample_dates
        
        return summary

def main():
    """Demo usage of MinIOOptionsDataManager"""
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Initialize manager
    manager = MinIOOptionsDataManager() 
    
    print("=== MinIO Options Data Manager Demo ===")
    
    # Get data summary
    summary = manager.get_data_summary()
    print(f"\nData Summary:")
    print(json.dumps(summary, indent=2)
    
    # Get available dates sample
    dates = manager.get_available_dates()
    print(f"\nFound {len(dates)} available trading dates")
    print(f"Date range: {dates[0] if dates else 'None'} to {dates[-1] if dates else 'None'}")
    
    if dates:
        # Load sample data
        sample_date = dates[len(dates)//2]  # Pick middle date
        print(f"\nLoading sample data for {sample_date}...")
        
        df = manager.load_options_data(sample_date)
        print(f"Loaded {len(df)} options contracts")
        
        if not df.empty:
            print(f"\nTop 5 symbols by volume:")
            top_symbols = df.groupby('underlying')['volume'].sum().nlargest(5)
            print(top_symbols)
            
            # Get market stats
            stats = manager.get_market_stats(sample_date)
            print(f"\nMarket Stats for {sample_date}:")
            print(f"  Total contracts: {stats.get('total_contracts', 0):,}")
            print(f"  Unique symbols: {stats.get('unique_symbols', 0):,}")
            print(f"  Total volume: {stats.get('total_volume', 0):,}")
            print(f"  Avg implied vol: {stats.get('avg_implied_vol', 0):.2%}")
            
            # Look for arbitrage opportunities
            print(f"\nScanning for arbitrage opportunities...")
            arb_ops = manager.find_arbitrage_opportunities(sample_date)
            print(f"Found {len(arb_ops)} potential opportunities")
            
            if not arb_ops.empty:
                print("Top 3 opportunities:")
                print(arb_ops.head(3)[['symbol', 'strike', 'profit_potential']])

if __name__ == "__main__":
    main()