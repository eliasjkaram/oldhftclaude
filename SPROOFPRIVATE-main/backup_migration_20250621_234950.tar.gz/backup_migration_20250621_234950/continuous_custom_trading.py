
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Continuous Custom Trading System
Runs continuously, finding and executing arbitrage opportunities
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import logging
import signal
import sys
from datetime import datetime, timedelta
import numpy as np
from typing import Dict, List, Optional

# Import our integrated trading system
from integrated_custom_trading_system import IntegratedTradingSystem

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('continuous_trading.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class ContinuousTradingBot:
    def __init__(self):
        """Initialize continuous trading bot"""
        self.system = IntegratedTradingSystem()
        self.running = True
        self.start_time = datetime.now()
        self.trades_executed = 0
        self.total_profit = 0
        
        # Performance tracking
        self.performance_history = []
        
        # Signal handler for graceful shutdown
        signal.signal(signal.SIGINT, self.handle_shutdown)
        signal.signal(signal.SIGTERM, self.handle_shutdown)
        
    def handle_shutdown(self, signum, frame):
        """Handle graceful shutdown"""
        logger.info("\n🛑 Shutdown signal received. Closing positions...")
        self.running = False
        
    async def run(self):
        """Main continuous trading loop"""
        logger.info("🚀 CONTINUOUS CUSTOM TRADING BOT STARTING")
        logger.info("=" * 60)
        logger.info("📊 Strategy: Multi-Strategy Arbitrage")
        logger.info("💰 Target: Find and execute profitable opportunities")
        logger.info("🎯 Focus: Options, Spreads, and Arbitrage")
        logger.info("=" * 60)
        
        try:
            # Start the integrated system
            await self.system.start()
            
        except KeyboardInterrupt:
            logger.info("\n⏹️ Stopping continuous trading...")
            
        except Exception as e:
            logger.error(f"Fatal error: {e}")
            
        finally:
            await self.shutdown()
            
    async def shutdown(self):
        """Clean shutdown procedure"""
        logger.info("📊 FINAL PERFORMANCE SUMMARY")
        logger.info("=" * 60)
        
        # Get final account status
        custom_summary = self.system.custom_account.get_portfolio_summary()
        
        runtime = datetime.now() - self.start_time
        logger.info(f"⏱️ Total Runtime: {runtime}")
        logger.info(f"📈 Trades Executed: {len(self.system.executed_trades)}")
        logger.info(f"💰 Final Portfolio Value: ${custom_summary['total_value']:,.2f}")
        logger.info(f"💹 Total P&L: ${custom_summary['total_pnl']:,.2f}")
        logger.info(f"📊 Return: {custom_summary['return_pct']:.2f}%")
        logger.info(f"✅ Win Rate: {custom_summary['win_rate']:.1f}%")
        
        # Show all positions
        if custom_summary['positions']:
            logger.info("\n📊 FINAL POSITIONS:")
            for symbol, pos in custom_summary['positions'].items():
                logger.info(f"   {symbol}: {pos['quantity']} @ ${pos['entry_price']:.2f} | P&L: ${pos['unrealized_pnl']:.2f}")
                
        # Save final snapshot
        self.system.custom_account.save_account_snapshot()
        logger.info(f"\n📁 Trading data saved to: {self.system.custom_account.db_path}")
        
        logger.info("\n✅ Continuous trading bot shutdown complete")

async def main():
    """Main entry point"""
    bot = ContinuousTradingBot()
    await bot.run()

if __name__ == "__main__":
    asyncio.run(main()