#!/usr/bin/env python3
"""
Test Resource Management Implementation
======================================

Comprehensive tests to verify resource management fixes are working correctly.
"""

import asyncio
import aiohttp
import sqlite3
import logging
import time
import psutil
import gc
from datetime import datetime
from typing import List, Dict, Any

from resource_management_fix import ()
    get_resource_manager,
    with_aiohttp_session,
    with_db_connection,
    cleanup_abandoned_resources
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ResourceLeakTester:
    """Test for resource leaks and proper cleanup"""
    
    def __init__(self):
        self.resource_manager = get_resource_manager()
        self.process = psutil.Process()
        self.initial_memory = None
        self.test_results = []
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage"""
        memory_info = self.process.memory_info()
        return {}
            'rss_mb': memory_info.rss / 1024 / 1024,
            'vms_mb': memory_info.vms / 1024 / 1024,
            'percent': self.process.memory_percent()
        }
    
    def get_resource_counts(self) -> Dict[str, int]:
        """Get current resource counts"""
        # Count open file descriptors
        try:
            num_fds = len(self.process.open_files())
        except:
            num_fds = 0
        
        # Count connections
        try:
            num_connections = len(self.process.connections())
        except:
            num_connections = 0
        
        # Count from resource manager
        rm_stats = {}
            'aiohttp_sessions': len(self.resource_manager._aiohttp_sessions),
            'db_connections': len(self.resource_manager._db_connections),
            'tasks': len(self.resource_manager._tasks),
            'file_descriptors': num_fds,
            'network_connections': num_connections
        }
        
        return rm_stats
    
    async def test_aiohttp_leak(self, iterations: int = 100):
        """Test for aiohttp session leaks"""
        logger.info(f"Testing aiohttp sessions with {iterations} iterations...")
        
        initial_stats = self.get_resource_counts()
        initial_memory = self.get_memory_usage()
        
        # Create many sessions with proper management
        for i in range(iterations):
            async with self.resource_manager.aiohttp_session() as session:
                # Make a simple request
                try:
                    async with session.get("https://httpbin.org/delay/0.1", timeout=5) as response:
                        await response.text()
                except Exception as e:
                    logger.debug(f"Request error (expected): {e}")
            
            if i % 10 == 0:
                gc.collect()  # Force garbage collection
                current_stats = self.get_resource_counts()
                logger.debug(f"Iteration {i}: Sessions={current_stats['aiohttp_sessions']}")
        
        # Wait a bit for cleanup
        await asyncio.sleep(1)
        gc.collect()
        
        final_stats = self.get_resource_counts()
        final_memory = self.get_memory_usage()
        
        # Check for leaks
        session_leak = final_stats['aiohttp_sessions'] > initial_stats['aiohttp_sessions'] + 2
        memory_leak = final_memory['rss_mb'] > initial_memory['rss_mb'] * 1.5  # 50% increase
        
        result = {}
            'test': 'aiohttp_leak',
            'passed': not (session_leak or memory_leak),
            'initial_sessions': initial_stats['aiohttp_sessions'],
            'final_sessions': final_stats['aiohttp_sessions'],
            'initial_memory_mb': initial_memory['rss_mb'],
            'final_memory_mb': final_memory['rss_mb'],
            'session_leak_detected': session_leak,
            'memory_leak_detected': memory_leak
        }
        
        self.test_results.append(result)
        logger.info(f"AioHTTP test: {'PASSED' if result['passed'] else 'FAILED'}")
        logger.info(f"  Sessions: {initial_stats['aiohttp_sessions']} -> {final_stats['aiohttp_sessions']}")
        logger.info(f"  Memory: {initial_memory['rss_mb']:.1f}MB -> {final_memory['rss_mb']:.1f}MB")
        
        return result
    
    def test_database_leak(self, iterations: int = 100):
        """Test for database connection leaks"""
        logger.info(f"Testing database connections with {iterations} iterations...")
        
        initial_stats = self.get_resource_counts()
        initial_memory = self.get_memory_usage()
        
        # Create many connections with proper management
        for i in range(iterations):
            with self.resource_manager.database_connection("test.db") as conn:
                cursor = conn.cursor()
                cursor.execute("CREATE TABLE IF NOT EXISTS test (id INTEGER, value TEXT)")
                cursor.execute("INSERT INTO test VALUES (?, ?)", (i, f"value_{i}"))
                conn.commit()
            
            if i % 10 == 0:
                gc.collect()
                current_stats = self.get_resource_counts()
                logger.debug(f"Iteration {i}: Connections={current_stats['db_connections']}")
        
        gc.collect()
        
        final_stats = self.get_resource_counts()
        final_memory = self.get_memory_usage()
        
        # Check for leaks
        conn_leak = final_stats['db_connections'] > initial_stats['db_connections'] + 2
        fd_leak = final_stats['file_descriptors'] > initial_stats['file_descriptors'] + 5
        memory_leak = final_memory['rss_mb'] > initial_memory['rss_mb'] * 1.5
        
        result = {}
            'test': 'database_leak',
            'passed': not (conn_leak or fd_leak or memory_leak),
            'initial_connections': initial_stats['db_connections'],
            'final_connections': final_stats['db_connections'],
            'initial_fds': initial_stats['file_descriptors'],
            'final_fds': final_stats['file_descriptors'],
            'initial_memory_mb': initial_memory['rss_mb'],
            'final_memory_mb': final_memory['rss_mb'],
            'connection_leak_detected': conn_leak,
            'fd_leak_detected': fd_leak,
            'memory_leak_detected': memory_leak
        }
        
        self.test_results.append(result)
        logger.info(f"Database test: {'PASSED' if result['passed'] else 'FAILED'}")
        logger.info(f"  Connections: {initial_stats['db_connections']} -> {final_stats['db_connections']}")
        logger.info(f"  File descriptors: {initial_stats['file_descriptors']} -> {final_stats['file_descriptors']}")
        logger.info(f"  Memory: {initial_memory['rss_mb']:.1f}MB -> {final_memory['rss_mb']:.1f}MB")
        
        return result
    
    async def test_task_management(self, iterations: int = 50):
        """Test for task leak and proper cancellation"""
        logger.info(f"Testing task management with {iterations} iterations...")
        
        initial_stats = self.get_resource_counts()
        
        async def sample_task(duration: float):
            await asyncio.sleep(duration)
            return "completed"
        
        # Create many tasks
        tasks = []
        for i in range(iterations):
            task = await self.resource_manager.create_task()
                sample_task(0.1 + i * 0.01),
                name=f"test_task_{i}"
            )
            tasks.append(task)
        
        # Wait for half to complete
        await asyncio.sleep(0.1)
        
        mid_stats = self.get_resource_counts()
        active_tasks = sum(1 for t in tasks if not t.done())
        
        # Cancel remaining tasks
        for task in tasks:
            if not task.done():
                task.cancel()
        
        # Wait for cancellation
        await asyncio.gather(*tasks, return_exceptions=True)
        gc.collect()
        
        final_stats = self.get_resource_counts()
        
        # Check for leaks
        task_leak = final_stats['tasks'] > initial_stats['tasks'] + 2
        
        result = {}
            'test': 'task_management',
            'passed': not task_leak,
            'initial_tasks': initial_stats['tasks'],
            'mid_tasks': mid_stats['tasks'],
            'final_tasks': final_stats['tasks'],
            'active_during_test': active_tasks,
            'task_leak_detected': task_leak
        }
        
        self.test_results.append(result)
        logger.info(f"Task management test: {'PASSED' if result['passed'] else 'FAILED'}")
        logger.info(f"  Tasks: {initial_stats['tasks']} -> {mid_stats['tasks']} -> {final_stats['tasks']}")
        
        return result
    
    async def test_cleanup_functionality(self):
        """Test cleanup functionality"""
        logger.info("Testing cleanup functionality...")
        
        # Create resources
        async with self.resource_manager.aiohttp_session() as session:
            pass
        
        with self.resource_manager.database_connection("test_cleanup.db") as conn:
            pass
        
        task = await self.resource_manager.create_task(asyncio.sleep(10), name="cleanup_test")
        
        initial_stats = self.get_resource_counts()
        
        # Run cleanup
        await self.resource_manager.cleanup_all()
        
        final_stats = self.get_resource_counts()
        
        result = {}
            'test': 'cleanup_functionality',
            'passed': all(final_stats[k] <= initial_stats[k] for k in ['aiohttp_sessions', 'tasks']),
            'stats_before': initial_stats,
            'stats_after': final_stats
        }
        
        self.test_results.append(result)
        logger.info(f"Cleanup test: {'PASSED' if result['passed'] else 'FAILED'}")
        
        return result
    
    @with_aiohttp_session
    async def test_decorator_functionality(self, session=None):
        """Test decorator functionality"""
        logger.info("Testing decorator functionality...")
        
        # Session should be injected
        if session is None:
            result = {'test': 'decorator_functionality', 'passed': False, 'error': 'Session not injected'}
        else:
            try:
                async with session.get("https://httpbin.org/get") as response:
                    data = await response.json()
                    result = {}
                        'test': 'decorator_functionality',
                        'passed': True,
                        'session_type': type(session).__name__,
                        'response_status': response.status
                    }
            except Exception as e:
                result = {'test': 'decorator_functionality', 'passed': False, 'error': str(e)}
        
        self.test_results.append(result)
        logger.info(f"Decorator test: {'PASSED' if result['passed'] else 'FAILED'}")
        
        return result
    
    async def run_all_tests(self):
        """Run all resource management tests"""
        logger.info("=" * 60)
        logger.info("Starting Resource Management Tests")
        logger.info("=" * 60)
        
        self.initial_memory = self.get_memory_usage()
        
        # Run tests
        await self.test_aiohttp_leak()
        logger.info("")
        
        self.test_database_leak()
        logger.info("")
        
        await self.test_task_management()
        logger.info("")
        
        await self.test_cleanup_functionality()
        logger.info("")
        
        await self.test_decorator_functionality()
        logger.info("")
        
        # Final cleanup
        await cleanup_abandoned_resources()
        
        # Summary
        logger.info("=" * 60)
        logger.info("Test Summary")
        logger.info("=" * 60)
        
        passed = sum(1 for r in self.test_results if r['passed'])
        total = len(self.test_results)
        
        for result in self.test_results:
            status = "✓ PASSED" if result['passed'] else "✗ FAILED"
            logger.info(f"{status} - {result['test']}")
        
        logger.info("")
        logger.info(f"Total: {passed}/{total} tests passed")
        
        final_memory = self.get_memory_usage()
        memory_increase = final_memory['rss_mb'] - self.initial_memory['rss_mb']
        logger.info(f"Memory usage: {self.initial_memory['rss_mb']:.1f}MB -> {final_memory['rss_mb']:.1f}MB ")
                   f"(+{memory_increase:.1f}MB)")
        
        return passed == total

async def stress_test():
    """Run stress test to check for leaks under load"""
    logger.info("\n" + "=" * 60)
    logger.info("Running Stress Test")
    logger.info("=" * 60)
    
    resource_manager = get_resource_manager()
    initial_memory = psutil.Process().memory_info().rss / 1024 / 1024
    
    async def worker(worker_id: int, iterations: int):
        """Worker that creates many resources"""
        for i in range(iterations):
            # HTTP requests
            async with resource_manager.aiohttp_session() as session:
                try:
                    async with session.get(f"https://httpbin.org/delay/0.01") as response:
                        await response.text()
                except Exception:
                    pass
            
            # Database operations
            with resource_manager.database_connection(f"stress_test_{worker_id}.db") as conn:
                conn.execute("CREATE TABLE IF NOT EXISTS test (id INTEGER)")
                conn.execute("INSERT INTO test VALUES (?)", (i,))
                conn.commit()
            
            # Small delay
            await asyncio.sleep(0.01)
    
    # Run multiple workers concurrently
    workers = 10
    iterations_per_worker = 50
    
    logger.info(f"Starting {workers} workers with {iterations_per_worker} iterations each...")
    
    tasks = []
    for i in range(workers):
        task = await resource_manager.create_task()
            worker(i, iterations_per_worker),
            name=f"stress_worker_{i}"
        )
        tasks.append(task)
    
    # Wait for completion
    await asyncio.gather(*tasks)
    
    # Cleanup
    await resource_manager.cleanup_all()
    gc.collect()
    
    final_memory = psutil.Process().memory_info().rss / 1024 / 1024
    memory_increase = final_memory - initial_memory
    
    logger.info(f"Stress test completed")
    logger.info(f"Memory usage: {initial_memory:.1f}MB -> {final_memory:.1f}MB (+{memory_increase:.1f}MB)")
    logger.info(f"Memory increase per operation: {memory_increase / (workers * iterations_per_worker):.3f}MB")
    
    # Check if memory increase is reasonable
    reasonable_increase = memory_increase < 50  # Less than 50MB increase
    logger.info(f"Stress test: {'PASSED' if reasonable_increase else 'FAILED - Possible memory leak'}")

async def main():
    """Main test runner"""
    # Run comprehensive tests
    tester = ResourceLeakTester()
    all_passed = await tester.run_all_tests()
    
    # Run stress test
    await stress_test()
    
    # Final cleanup
    await get_resource_manager().cleanup_all()
    
    return all_passed

if __name__ == "__main__":
    # Run tests
    success = asyncio.run(main())
    exit(0 if success else 1)