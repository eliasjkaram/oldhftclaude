
#!/usr/bin/env python3
"""
Comprehensive test of edge case handler with all trading algorithms
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import torch
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
from edge_case_handler import edge_handler, handle_edge_cases

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)

def create_edge_case_data():
    """Create data with various edge cases"""
    # Create problematic market data
    dates = pd.date_range(end=datetime.now(), periods=100, freq='D')
    
    # Data with NaN, inf, and extreme values
    market_data = pd.DataFrame({)
        'timestamp': dates,
        'open': [100] * 20 + [np.nan] * 5 + [150] * 75,
        'high': [105] * 20 + [np.inf] * 5 + [155] * 75,
        'low': [95] * 20 + [-np.inf] * 5 + [145] * 75,
        'close': [102] * 20 + [np.nan] * 5 + [152] * 75,
        'volume': [1000000] * 20 + [-1000] * 5 + [2000000] * 75,
        'volatility': [0.2] * 20 + [100] * 5 + [0.3] * 75
    })
    
    # Options data with various issues
    options_data = []
        {'strike': 100, 'type': 'call', 'bid': np.nan, 'ask': 1.5, 'mid': 1.0, 
         'implied_volatility': 0.3, 'expiration': datetime.now() + timedelta(days=30)},
        {'strike': 100, 'type': 'put', 'bid': 0.8, 'ask': np.inf, 'mid': 0.9,
         'implied_volatility': -0.5, 'expiration': datetime.now() + timedelta(days=30)},
        {'strike': 105, 'type': 'call', 'bid': -1.0, 'ask': 1.2, 'mid': 0.1,
         'implied_volatility': 10, 'expiration': datetime.now() - timedelta(days=1)},  # Expired
        {'strike': 105, 'type': 'put', 'bid': 1.5, 'ask': 1.7, 'mid': 1.6,
         'implied_volatility': 0.25, 'expiration': datetime.now() + timedelta(days=30)},
    ]
    
    return market_data, options_data

def test_transformer_edge_cases():
    """Test transformer model edge cases"""
    logger.info("\n=== Testing Transformer Edge Cases ===")
    
    # Create edge case inputs
    # 1. Empty tensor
    empty_tensor = torch.tensor([])
    
    # 2. Tensor with NaN and inf
    problematic_tensor = torch.tensor([)
        [1.0, 2.0, np.nan, 4.0],
        [np.inf, 6.0, 7.0, -np.inf],
        [9.0, 10.0, 11.0, 12.0]
    ]).unsqueeze(0)  # Add batch dimension
    
    # 3. Very long sequence
    long_sequence = torch.randn(1, 15000, 64)  # Exceeds max sequence length
    
    # Test each case
    test_cases = []
        ("Empty tensor", empty_tensor),
        ("Tensor with NaN/inf", problematic_tensor),
        ("Very long sequence", long_sequence)
    ]
    
    for name, tensor in test_cases:
        logger.info(f"\nTesting: {name}")
        try:
            result = edge_handler.handle_transformer_edge_cases(tensor)
            logger.info(f"Processed: {result['processed']}")
            if result['issues']:
                logger.info(f"Issues: {result['issues']['issues_found']}")
            if result['processed'] and result['data'] is not None:
                logger.info(f"Output shape: {result['data'].shape}")
        except Exception as e:
            logger.error(f"Failed: {str(e)}")

def test_options_edge_cases():
    """Test options trading edge cases"""
    logger.info("\n=== Testing Options Trading Edge Cases ===")
    
    _, options_data = create_edge_case_data()
    
    # Various market conditions
    market_conditions = []
        {"stock_price": 100, "volume": 0, "last_update": datetime.now()},  # Zero volume
        {"stock_price": 100, "volume": 1000000, "price_change": 0.6},  # 60% move
        {"stock_price": 100, "bid": 90, "ask": 110},  # 20% spread
        {"stock_price": 100, "volume": 1000000, "last_update": datetime.now() - timedelta(minutes=10)}  # Stale
    ]
    
    for i, market_data in enumerate(market_conditions):
        logger.info(f"\nTest case {i+1}: {list(market_data.keys())}")
        result = edge_handler.handle_options_edge_cases(options_data, market_data)
        logger.info(f"Processed: {result['processed']}")
        logger.info(f"Trading allowed: {result.get('trading_allowed', True)}")
        if result['market_issues']:
            logger.info(f"Market issues: {result['market_issues']}")
        if result['data']:
            logger.info(f"Valid options: {result['validated_count']}/{result['original_count']}")

def test_mamba_edge_cases():
    """Test Mamba state space model edge cases"""
    logger.info("\n=== Testing Mamba Edge Cases ===")
    
    # Test cases
    test_cases = []
        # Empty sequence
        {}
            'name': 'Empty sequence',
            'data': {'prices': torch.tensor([]), 'volumes': torch.tensor([])}
        },
        # Constant sequence
        {}
            'name': 'Constant prices',
            'data': {'prices': torch.ones(1, 100), 'volumes': torch.randn(1, 100)}
        },
        # Very long sequence
        {}
            'name': 'Long sequence',
            'data': {'prices': torch.randn(1, 20000), 'volumes': torch.randn(1, 20000)}
        },
        # Sequence with NaN
        {}
            'name': 'NaN values',
            'data': {}
                'prices': torch.tensor([[1.0, 2.0, np.nan, 4.0, 5.0]]),
                'volumes': torch.tensor([[100, 200, 300, np.nan, 500]])
            }
        }
    ]
    
    for test in test_cases:
        logger.info(f"\nTesting: {test['name']}")
        result = edge_handler.handle_mamba_edge_cases(test['data'])
        logger.info(f"Processed: {result['processed']}")
        if result['issues']:
            logger.info(f"Issues: {result['issues']}")
        if result['processed'] and result['data']:
            for key, tensor in result['data'].items():
                if isinstance(tensor, torch.Tensor):
                    logger.info(f"{key} shape: {tensor.shape}")

def test_multi_agent_edge_cases():
    """Test multi-agent system edge cases"""
    logger.info("\n=== Testing Multi-Agent Edge Cases ===")
    
    market_data, _ = create_edge_case_data()
    
    # Various agent states
    test_cases = []
        {}
            'name': 'All agents healthy',
            'agents': {}
                'agent1': {'status': 'active', 'last_update': datetime.now()},
                'agent2': {'status': 'active', 'last_update': datetime.now()},
                'agent3': {'status': 'active', 'last_update': datetime.now()},
            }
        },
        {}
            'name': 'Some agents failed',
            'agents': {}
                'agent1': {'status': 'failed', 'last_update': datetime.now()},
                'agent2': {'status': 'active', 'last_update': datetime.now()},
                'agent3': {'status': 'active', 'last_update': datetime.now()},
            }
        },
        {}
            'name': 'Majority agents failed',
            'agents': {}
                'agent1': {'status': 'failed'},
                'agent2': {'status': 'failed'},
                'agent3': {'status': 'active', 'last_update': datetime.now()},
            }
        },
        {}
            'name': 'Stale agents',
            'agents': {}
                'agent1': {'status': 'active', 'last_update': datetime.now() - timedelta(minutes=10)},
                'agent2': {'status': 'active', 'last_update': datetime.now() - timedelta(minutes=15)},
                'agent3': {'status': 'active', 'last_update': datetime.now()},
            }
        }
    ]
    
    for test in test_cases:
        logger.info(f"\nTesting: {test['name']}")
        result = edge_handler.handle_multi_agent_edge_cases()
            {'prices': market_data['close'].values},
            test['agents']
        )
        logger.info(f"Processed: {result['processed']}")
        if result['issues']:
            logger.info(f"Issues: {result['issues']}")
        if result['data']:
            logger.info(f"Active agents: {len(result['data']['active_agents'])}")
            logger.info(f"Failed agents: {result['data']['failed_agents']}")

def test_ppo_edge_cases():
    """Test PPO reinforcement learning edge cases"""
    logger.info("\n=== Testing PPO Edge Cases ===")
    
    # Test cases
    test_cases = []
        {}
            'name': 'Normal state',
            'state': np.array([100, 0.2, 1000000, 0.5]),
            'memory': [{'state': [100, 0.2], 'reward': 0.1, 'action': 0} for _ in range(100)]
        },
        {}
            'name': 'State with NaN',
            'state': np.array([100, np.nan, np.inf, -np.inf]),
            'memory': [{'state': [100, 0.2], 'reward': 0.1, 'action': 0} for _ in range(100)]
        },
        {}
            'name': 'Empty memory',
            'state': np.array([100, 0.2, 1000000, 0.5]),
            'memory': []
        },
        {}
            'name': 'Exploding rewards',
            'state': np.array([100, 0.2, 1000000, 0.5]),
            'memory': [{'state': [100, 0.2], 'reward': 10000 * i, 'action': 0} for i in range(100)]
        },
        {}
            'name': 'Constant rewards',
            'state': np.array([100, 0.2, 1000000, 0.5]),
            'memory': [{'state': [100, 0.2], 'reward': 0.1, 'action': 0} for _ in range(100)]
        },
        {}
            'name': 'Very large memory buffer',
            'state': np.array([100, 0.2, 1000000, 0.5]),
            'memory': [{'state': [100, 0.2], 'reward': 0.1, 'action': 0} for _ in range(150000)]
        }
    ]
    
    for test in test_cases:
        logger.info(f"\nTesting: {test['name']}")
        result = edge_handler.handle_ppo_edge_cases(test['state'], test['memory'])
        logger.info(f"Processed: {result['processed']}")
        if result['issues']:
            logger.info(f"Issues: {result['issues']}")
        if result['data']:
            logger.info(f"State shape: {result['data']['state'].shape}")
            logger.info(f"Memory buffer size: {len(result['data']['memory_buffer'])}")

def test_clip_edge_cases():
    """Test CLIP multi-modal edge cases"""
    logger.info("\n=== Testing CLIP Edge Cases ===")
    
    test_cases = []
        {}
            'name': 'All modalities present',
            'images': torch.randn(2, 3, 224, 224),
            'text_ids': torch.randint(0, 1000, (2, 100)),
            'numerical': torch.randn(2, 50)
        },
        {}
            'name': 'No modalities',
            'images': None,
            'text_ids': None,
            'numerical': None
        },
        {}
            'name': 'Invalid image shape',
            'images': torch.randn(2, 224, 224),  # Missing channel dimension
            'text_ids': torch.randint(0, 1000, (2, 100)),
            'numerical': torch.randn(2, 50)
        },
        {}
            'name': 'Images need normalization',
            'images': torch.randint(0, 256, (2, 3, 224, 224)).float(),
            'text_ids': None,
            'numerical': None
        },
        {}
            'name': 'Invalid token IDs',
            'images': None,
            'text_ids': torch.randint(0, 100000, (2, 100)),  # Too large
            'numerical': None
        },
        {}
            'name': 'Long text sequence',
            'images': None,
            'text_ids': torch.randint(0, 1000, (2, 1000)),  # Too long
            'numerical': None
        },
        {}
            'name': 'Wrong numerical features',
            'images': None,
            'text_ids': None,
            'numerical': torch.randn(2, 30)  # Should be 50
        }
    ]
    
    for test in test_cases:
        logger.info(f"\nTesting: {test['name']}")
        result = edge_handler.handle_clip_edge_cases()
            test.get('images'),
            test.get('text_ids'),
            test.get('numerical')
        )
        logger.info(f"Processed: {result['processed']}")
        if result['issues']:
            logger.info(f"Issues: {result['issues']}")
        if result['data']:
            for key, value in result['data'].items():
                if value is not None:
                    logger.info(f"{key} shape: {value.shape}")

def test_timegan_edge_cases():
    """Test TimeGAN market simulation edge cases"""
    logger.info("\n=== Testing TimeGAN Edge Cases ===")
    
    # Test cases
    test_cases = []
        {}
            'name': 'Insufficient data',
            'data': pd.DataFrame({)
                'open': [100, 101],
                'high': [102, 103],
                'low': [99, 100],
                'close': [101, 102],
                'volume': [1000, 2000]
            })
        },
        {}
            'name': 'Missing columns',
            'data': pd.DataFrame({)
                'close': np.random.randn(200) * 10 + 100,
                'volume': np.random.randint(1000, 10000, 200)
            })
        },
        {}
            'name': 'Invalid OHLC relationships',
            'data': pd.DataFrame({)
                'open': [100] * 200,
                'high': [95] * 200,  # High < Close
                'low': [105] * 200,  # Low > Close
                'close': [100] * 200,
                'volume': [1000] * 200
            })
        },
        {}
            'name': 'Data with NaN and inf',
            'data': pd.DataFrame({)
                'open': [100] * 50 + [np.nan] * 50 + [110] * 100,
                'high': [105] * 50 + [np.inf] * 50 + [115] * 100,
                'low': [95] * 50 + [-np.inf] * 50 + [105] * 100,
                'close': [102] * 50 + [np.nan] * 50 + [112] * 100,
                'volume': [1000] * 200
            })
        }
    ]
    
    for test in test_cases:
        logger.info(f"\nTesting: {test['name']}")
        result = edge_handler.handle_timegan_edge_cases(test['data'])
        logger.info(f"Processed: {result['processed']}")
        if result['issues']:
            logger.info(f"Issues: {result['issues']}")
        if result['processed'] and result['data'] is not None:
            logger.info(f"Output shape: {result['data'].shape}")
            logger.info(f"Columns: {list(result['data'].columns)}")

def test_safe_wrapper():
    """Test safe wrapper functionality"""
    logger.info("\n=== Testing Safe Wrapper ===")
    
    # Create functions that might fail
    def divide_by_zero(x):
        return x / 0
    
    def memory_hog():
        # Try to allocate huge array (will fail gracefully)
        return np.zeros((10000, 10000, 1000))
    
    def normal_function(x):
        return x * 2
    
    # Wrap functions
    safe_divide = edge_handler.create_safe_wrapper(divide_by_zero)
    safe_memory = edge_handler.create_safe_wrapper(memory_hog)
    safe_normal = edge_handler.create_safe_wrapper(normal_function)
    
    # Test each
    logger.info("\nTesting division by zero:")
    result = safe_divide(10)
    logger.info(f"Result: {result}")
    
    logger.info("\nTesting memory allocation:")
    result = safe_memory()
    logger.info(f"Result: {result}")
    
    logger.info("\nTesting normal function:")
    result = safe_normal(10)
    logger.info(f"Result: {result}")

def test_decorator():
    """Test edge case handling decorator"""
    logger.info("\n=== Testing Edge Case Decorator ===")
    
    @handle_edge_cases('transformer')
    def mock_transformer(input_tensor):
        # Simulate transformer processing
        return {'output': input_tensor.mean().item(), 'shape': input_tensor.shape}
    
    @handle_edge_cases('options')
    def mock_options_strategy(options_data, market_data):
        # Simulate options strategy
        return {'num_options': len(options_data), 'strategy': 'processed'}
    
    # Test transformer decorator
    logger.info("\nTesting transformer decorator with problematic input:")
    test_tensor = torch.tensor([[1.0, np.nan, np.inf, 4.0]])
    result = mock_transformer(test_tensor)
    logger.info(f"Result: {result}")
    
    # Test options decorator
    logger.info("\nTesting options decorator:")
    _, options_data = create_edge_case_data()
    market_data = {"stock_price": 100, "volume": 0}  # Zero volume edge case
    result = mock_options_strategy(options_data, market_data)
    logger.info(f"Result: {result}")

def run_all_tests():
    """Run all edge case tests"""
    logger.info("Starting comprehensive edge case testing for all algorithms...")
    logger.info("=" * 60)
    
    # Test each algorithm's edge case handling
    test_transformer_edge_cases()
    test_options_edge_cases()
    test_mamba_edge_cases()
    test_multi_agent_edge_cases()
    test_ppo_edge_cases()
    test_clip_edge_cases()
    test_timegan_edge_cases()
    
    # Test utility functions
    test_safe_wrapper()
    test_decorator()
    
    # Test memory management
    logger.info("\n=== Testing Memory Management ===")
    memory = edge_handler.memory_manager.check_memory()
    logger.info(f"Current memory usage: {memory['cpu']['percent']:.1f}%")
    edge_handler.memory_manager.optimize_memory()
    logger.info("Memory optimization completed")
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("Edge case testing completed successfully!")
    logger.info("All algorithms have robust edge case handling.")

if __name__ == "__main__":
    run_all_tests()