#!/usr/bin/env python3
"""
Test loading TLT data from MinIO
"""

from datetime import datetime
from enhanced_data_loader import EnhancedDataLoader
import logging

logging.basicConfig(level=logging.INFO)

print("="*80)
print("Testing MinIO TLT Data Loading")
print("="*80)

# Initialize loader (will try MinIO first now)
loader = EnhancedDataLoader()

# Test with different date ranges
test_cases = [
    (datetime(2020, 1, 1), datetime(2020, 12, 31), "2020 Full Year"),
    (datetime(2023, 1, 1), datetime(2023, 12, 31), "2023 Full Year"),
    (datetime(2024, 1, 1), datetime(2024, 6, 1), "2024 YTD"),
]

for start_date, end_date, label in test_cases:
    print(f"\n{'='*60}")
    print(f"Testing: {label}")
    print(f"Period: {start_date.date()} to {end_date.date()}")
    print('-'*60)
    
    df = loader.get_historical_data('TLT', start_date, end_date)
    
    if not df.empty:
        print(f"✅ Successfully loaded {len(df)} days of data")
        print(f"Date range: {df.index[0]} to {df.index[-1]}")
        print(f"Price range: ${df['Close'].min():.2f} - ${df['Close'].max():.2f}")
        print(f"Average volume: {df['Volume'].mean():,.0f}")
        
        # Check data quality
        print("\nData quality check:")
        print(f"- Missing values: {df.isnull().sum().sum()}")
        print(f"- Negative prices: {(df[['Open', 'High', 'Low', 'Close']] < 0).sum().sum()}")
        print(f"- Zero volume days: {(df['Volume'] == 0).sum()}")
        
        # Show sample data
        print("\nFirst 3 rows:")
        print(df.head(3))
        
        print("\nLast 3 rows:")
        print(df.tail(3))
    else:
        print("❌ No data returned")

print("\n" + "="*80)
print("TEST COMPLETE")
print("="*80)