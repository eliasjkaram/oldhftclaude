"""
Ensemble Model System with Dynamic Weighting for Options Pricing
Combines multiple models with adaptive weighting based on performance
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass
import pickle
import json
from datetime import datetime
try:
    import wandb
except ImportError:
    wandb = None
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import KFold
from collections import deque
import warnings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class EnsembleConfig:
    """Configuration for ensemble model system"""
    # Base models
    base_models: List[str] = None  # Model types to include
    
    # Ensemble strategy
    ensemble_method: str = 'dynamic_weighted'  # 'average', 'weighted', 'dynamic_weighted', 'stacking'
    meta_learner_type: str = 'neural_network'  # 'linear', 'neural_network', 'gradient_boosting'
    
    # Dynamic weighting
    performance_window: int = 100  # Number of recent predictions to consider
    update_frequency: int = 50  # How often to update weights
    weight_decay: float = 0.95  # Exponential decay for historical performance
    min_weight: float = 0.05  # Minimum weight for any model
    
    # Training
    learning_rate: float = 1e-3
    meta_learning_rate: float = 5e-4
    batch_size: int = 64
    epochs: int = 50
    validation_split: float = 0.2
    
    # Model diversity
    diversity_weight: float = 0.1  # Weight for diversity term in loss
    correlation_penalty: float = 0.05
    
    def __post_init__(self):
        if self.base_models is None:
            self.base_models = ['mlp', 'lstm', 'transformer', 'gbm', 'random_forest']


class BaseModel(nn.Module):
    """Abstract base class for ensemble components"""
    
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError
        
    def get_name(self) -> str:
        return self.__class__.__name__


class MLPModel(BaseModel):
    """Multi-layer Perceptron base model"""
    
    def __init__(self, input_dim: int, output_dim: int, hidden_dims: List[int] = None):
        super().__init__(input_dim, output_dim)
        
        if hidden_dims is None:
            hidden_dims = [128, 64, 32]
            
        layers = []
        prev_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([)
                nn.Linear(prev_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.2)
            ])
            prev_dim = hidden_dim
            
        layers.append(nn.Linear(prev_dim, output_dim))
        
        self.network = nn.Sequential(*layers)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class SimpleLSTMModel(BaseModel):
    """Simplified LSTM for ensemble"""
    
    def __init__(self, input_dim: int, output_dim: int, hidden_dim: int = 64):
        super().__init__(input_dim, output_dim)
        
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.output_layer = nn.Linear(hidden_dim, output_dim)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Assume x is [batch_size, features] and we create a sequence
        if len(x.shape) == 2:
            x = x.unsqueeze(1)  # [batch_size, 1, features]
            
        lstm_out, _ = self.lstm(x)
        # Use last output
        output = self.output_layer(lstm_out[:, -1, :])
        return output


class SimpleTransformerModel(BaseModel):
    """Simplified Transformer for ensemble"""
    
    def __init__(self, input_dim: int, output_dim: int, d_model: int = 64):
        super().__init__(input_dim, output_dim)
        
        self.input_projection = nn.Linear(input_dim, d_model)
        
        encoder_layer = nn.TransformerEncoderLayer()
            d_model=d_model,
            nhead=4,
            dim_feedforward=256,
            dropout=0.1,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=2)
        
        self.output_layer = nn.Linear(d_model, output_dim)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if len(x.shape) == 2:
            x = x.unsqueeze(1)
            
        x = self.input_projection(x)
        x = self.transformer(x)
        output = self.output_layer(x[:, -1, :])
        return output


class GradientBoostingWrapper(BaseModel):
    """Wrapper for gradient boosting models"""
    
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__(input_dim, output_dim)
        self.model = None  # Will be set externally
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Convert to numpy for sklearn models
        x_np = x.detach().cpu().numpy()
        predictions = self.model.predict(x_np)
        return torch.tensor(predictions, dtype=torch.float32).unsqueeze(-1)


class MetaLearner(nn.Module):
    """Meta-learner for stacking ensemble"""
    
    def __init__(self, n_models: int, meta_features_dim: int, output_dim: int, 
                 learner_type: str = 'neural_network'):
        super().__init__()
        self.learner_type = learner_type
        self.n_models = n_models
        
        if learner_type == 'linear':
            self.learner = nn.Linear(n_models + meta_features_dim, output_dim)
            
        elif learner_type == 'neural_network':
            self.learner = nn.Sequential()
                nn.Linear(n_models + meta_features_dim, 32),
                nn.ReLU(),
                nn.Dropout(0.2),
                nn.Linear(32, 16),
                nn.ReLU(),
                nn.Linear(16, output_dim)
            )
            
    def forward(self, model_predictions: torch.Tensor, meta_features: torch.Tensor) -> torch.Tensor:
        """
        Args:
            model_predictions: [batch_size, n_models]
            meta_features: [batch_size, meta_features_dim]
        """
        combined = torch.cat([model_predictions, meta_features], dim=-1)
        return self.learner(combined)


class DynamicWeightCalculator(nn.Module):
    """Calculate dynamic weights based on recent performance"""
    
    def __init__(self, n_models: int, performance_window: int, weight_decay: float):
        super().__init__()
        self.n_models = n_models
        self.performance_window = performance_window
        self.weight_decay = weight_decay
        
        # Performance tracking
        self.performance_history = [deque(maxlen=performance_window) for _ in range(n_models)]
        self.current_weights = nn.Parameter(torch.ones(n_models) / n_models, requires_grad=False)
        
        # Learnable weight adjustment network
        self.weight_network = nn.Sequential()
            nn.Linear(n_models * 3, 32),  # 3 features per model: mean_error, std_error, recent_trend
            nn.ReLU(),
            nn.Linear(32, n_models),
            nn.Softmax(dim=-1)
        )
        
    def update_performance(self, model_idx: int, error: float):
        """Update performance history for a model"""
        self.performance_history[model_idx].append(error)
        
    def calculate_weights(self) -> torch.Tensor:
        """Calculate current weights based on performance"""
        performance_features = []
        
        for i in range(self.n_models):
            if len(self.performance_history[i]) > 0:
                errors = list(self.performance_history[i])
                
                # Apply exponential decay to older errors
                weights = np.array([self.weight_decay ** (len(errors) - j - 1) 
                                  for j in range(len(errors))])
                weights = weights / weights.sum()
                
                weighted_errors = np.array(errors) * weights
                
                mean_error = np.mean(weighted_errors)
                std_error = np.std(weighted_errors)
                
                # Recent trend (positive means improving)
                if len(errors) > 5:
                    recent_trend = np.mean(errors[:5]) - np.mean(errors[-5:])
                else:
                    recent_trend = 0.0
                    
            else:
                mean_error = 0.0
                std_error = 1.0
                recent_trend = 0.0
                
            performance_features.extend([mean_error, std_error, recent_trend])
            
        features = torch.tensor(performance_features, dtype=torch.float32).unsqueeze(0)
        weights = self.weight_network(features).squeeze(0)
        
        return weights


class EnsembleModelSystem(nn.Module):
    """Main ensemble model system"""
    
    def __init__(self, config: EnsembleConfig, input_dim: int, output_dim: int):
        super().__init__()
        self.config = config
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Initialize base models
        self.base_models = nn.ModuleList()
        self._initialize_base_models()
        
        # Dynamic weight calculator
        self.weight_calculator = DynamicWeightCalculator()
            len(self.base_models),
            config.performance_window,
            config.weight_decay
        )
        
        # Meta-learner for stacking
        if config.ensemble_method == 'stacking':
            self.meta_learner = MetaLearner()
                len(self.base_models),
                input_dim,  # Use original features as meta-features
                output_dim,
                config.meta_learner_type
            )
            
        # Uncertainty estimation
        self.uncertainty_estimator = nn.Sequential()
            nn.Linear(len(self.base_models) + input_dim, 32),
            nn.ReLU(),
            nn.Linear(32, output_dim)
        )
        
        # Training tracking
        self.prediction_count = 0
        
    def _initialize_base_models(self):
        """Initialize base models based on configuration"""
        for model_type in self.config.base_models:
            if model_type == 'mlp':
                self.base_models.append(MLPModel(self.input_dim, self.output_dim))
            elif model_type == 'lstm':
                self.base_models.append(SimpleLSTMModel(self.input_dim, self.output_dim))
            elif model_type == 'transformer':
                self.base_models.append(SimpleTransformerModel(self.input_dim, self.output_dim))
            else:
                logger.warning(f"Unknown model type: {model_type}")
                
    def forward(self, x: torch.Tensor, return_all: bool = False) -> Dict[str, torch.Tensor]:
        """
        Forward pass through ensemble
        Args:
            x: Input features [batch_size, input_dim]
            return_all: Whether to return all model predictions
        """
        # Get predictions from all base models
        model_predictions = []
        for model in self.base_models:
            pred = model(x)
            model_predictions.append(pred)
            
        # Stack predictions [batch_size, n_models, output_dim]
        stacked_predictions = torch.stack(model_predictions, dim=1)
        
        # Ensemble prediction based on method
        if self.config.ensemble_method == 'average':
            ensemble_prediction = stacked_predictions.mean(dim=1)
            
        elif self.config.ensemble_method in ['weighted', 'dynamic_weighted']:
            # Get current weights
            if self.config.ensemble_method == 'dynamic_weighted':
                weights = self.weight_calculator.calculate_weights()
            else:
                weights = F.softmax(self.weight_calculator.current_weights, dim=0)
                
            # Apply weights
            weights = weights.view(1, -1, 1)  # [1, n_models, 1]
            ensemble_prediction = (stacked_predictions * weights).sum(dim=1)
            
        elif self.config.ensemble_method == 'stacking':
            # Use meta-learner
            model_preds_flat = stacked_predictions.squeeze(-1)  # [batch_size, n_models]
            ensemble_prediction = self.meta_learner(model_preds_flat, x)
            
        else:
            raise ValueError(f"Unknown ensemble method: {self.config.ensemble_method}")
            
        # Estimate uncertainty
        uncertainty_input = torch.cat([)
            stacked_predictions.squeeze(-1),  # Model predictions
            x  # Original features
        ], dim=-1)
        log_variance = self.uncertainty_estimator(uncertainty_input)
        uncertainty = torch.exp(0.5 * log_variance)
        
        # Calculate prediction variance across models
        prediction_variance = stacked_predictions.var(dim=1)
        
        result = {}
            'prediction': ensemble_prediction,
            'uncertainty': uncertainty,
            'prediction_variance': prediction_variance,
            'weights': weights.squeeze() if self.config.ensemble_method in ['weighted', 'dynamic_weighted'] else None
        }
        
        if return_all:
            result['all_predictions'] = stacked_predictions
            
        return result
        
    def update_model_performance(self, model_predictions: torch.Tensor, targets: torch.Tensor):
        """Update performance tracking for dynamic weighting"""
        if self.config.ensemble_method != 'dynamic_weighted':
            return
            
        with torch.no_grad():
            for i in range(len(self.base_models)):
                model_pred = model_predictions[:, i, :]
                error = F.mse_loss(model_pred, targets).item()
                self.weight_calculator.update_performance(i, error)
                
        self.prediction_count += 1
        
        # Update weights periodically
        if self.prediction_count % self.config.update_frequency == 0:
            logger.info("Updating ensemble weights based on recent performance")


class EnsembleDataset(Dataset):
    """Dataset for ensemble training"""
    
    def __init__(self, features: np.ndarray, targets: np.ndarray):
        self.features = torch.FloatTensor(features)
        self.targets = torch.FloatTensor(targets)
        
    def __len__(self):
        return len(self.features)
        
    def __getitem__(self, idx):
        return self.features[idx], self.targets[idx]


class EnsembleTrainer:
    """Trainer for ensemble model system"""
    
    def __init__(self, model: EnsembleModelSystem, config: EnsembleConfig):
        self.model = model
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        # Optimizers
        self.base_optimizers = []
        for base_model in model.base_models:
            self.base_optimizers.append()
                torch.optim.AdamW(base_model.parameters(), lr=config.learning_rate)
            )
            
        # Meta-learner optimizer
        if config.ensemble_method == 'stacking':
            self.meta_optimizer = torch.optim.AdamW()
                model.meta_learner.parameters(), lr=config.meta_learning_rate
            )
            
        # Loss functions
        self.criterion = nn.MSELoss()
        
        # Training history
        self.train_history = []
        self.val_history = []
        
    def calculate_diversity_loss(self, predictions: torch.Tensor) -> torch.Tensor:
        """Calculate diversity loss to encourage different predictions"""
        n_models = predictions.size(1)
        
        if n_models < 2:
            return torch.tensor(0.0)
            
        # Calculate pairwise correlations
        correlations = []
        for i in range(n_models):
            for j in range(i + 1, n_models):
                pred_i = predictions[:, i, :].flatten()
                pred_j = predictions[:, j, :].flatten()
                
                # Pearson correlation
                vx = pred_i - pred_i.mean()
                vy = pred_j - pred_j.mean()
                
                corr = (vx * vy).sum() / (torch.sqrt((vx ** 2).sum()) * torch.sqrt((vy ** 2).sum()) + 1e-8)
                correlations.append(torch.abs(corr))
                
        # Penalize high correlations
        diversity_loss = torch.stack(correlations).mean()
        
        return diversity_loss
        
    def train_epoch(self, train_loader: DataLoader, phase: str = 'all') -> Dict[str, float]:
        """
        Train for one epoch
        Args:
            phase: 'base' - train only base models
                  'meta' - train only meta-learner
                  'all' - train everything
        """
        self.model.train()
        epoch_losses = {'total': 0, 'prediction': 0, 'diversity': 0}
        
        for batch_idx, (features, targets) in enumerate(train_loader):
            features = features.to(self.device)
            targets = targets.to(self.device)
            
            # Forward pass
            outputs = self.model(features, return_all=True)
            
            # Calculate losses
            prediction_loss = self.criterion(outputs['prediction'], targets)
            
            # Diversity loss
            if 'all_predictions' in outputs:
                diversity_loss = self.calculate_diversity_loss(outputs['all_predictions'])
            else:
                diversity_loss = torch.tensor(0.0)
                
            total_loss = prediction_loss + self.config.diversity_weight * diversity_loss
            
            # Backward pass based on phase
            if phase in ['base', 'all']:
                # Update base models
                for optimizer in self.base_optimizers:
                    optimizer.zero_grad()
                    
            if phase in ['meta', 'all'] and self.config.ensemble_method == 'stacking':
                self.meta_optimizer.zero_grad()
                
            total_loss.backward()
            
            if phase in ['base', 'all']:
                for optimizer in self.base_optimizers:
                    optimizer.step()
                    
            if phase in ['meta', 'all'] and self.config.ensemble_method == 'stacking':
                self.meta_optimizer.step()
                
            # Update performance tracking
            if 'all_predictions' in outputs:
                self.model.update_model_performance(outputs['all_predictions'], targets)
                
            # Track losses
            epoch_losses['total'] += total_loss.item()
            epoch_losses['prediction'] += prediction_loss.item()
            epoch_losses['diversity'] += diversity_loss.item()
            
        # Average losses
        num_batches = len(train_loader)
        for key in epoch_losses:
            epoch_losses[key] /= num_batches
            
        return epoch_losses
        
    def validate(self, val_loader: DataLoader) -> Dict[str, float]:
        """Validate ensemble"""
        self.model.eval()
        total_loss = 0
        predictions = []
        actuals = []
        uncertainties = []
        
        with torch.no_grad():
            for features, targets in val_loader:
                features = features.to(self.device)
                targets = targets.to(self.device)
                
                outputs = self.model(features)
                
                loss = self.criterion(outputs['prediction'], targets)
                total_loss += loss.item()
                
                predictions.extend(outputs['prediction'].cpu().numpy())
                actuals.extend(targets.cpu().numpy())
                uncertainties.extend(outputs['uncertainty'].cpu().numpy())
                
        # Calculate metrics
        predictions = np.array(predictions)
        actuals = np.array(actuals)
        uncertainties = np.array(uncertainties)
        
        mse = np.mean((predictions - actuals) ** 2)
        mae = np.mean(np.abs(predictions - actuals))
        rmse = np.sqrt(mse)
        
        # Uncertainty calibration
        calibration_error = self._calculate_calibration(predictions, actuals, uncertainties)
        
        return {}
            'loss': total_loss / len(val_loader),
            'mse': mse,
            'mae': mae,
            'rmse': rmse,
            'calibration_error': calibration_error,
            'mean_uncertainty': np.mean(uncertainties)
        }
        
    def _calculate_calibration(self, predictions: np.ndarray, actuals: np.ndarray,
                             uncertainties: np.ndarray) -> float:
        """Calculate uncertainty calibration"""
        errors = np.abs(predictions.flatten() - actuals.flatten())
        uncertainties = uncertainties.flatten()
        
        # Bin by uncertainty
        n_bins = 10
        calibration_errors = []
        
        for i in range(n_bins):
            low = i / n_bins
            high = (i + 1) / n_bins
            
            mask = (uncertainties >= np.quantile(uncertainties, low)) & \
                   (uncertainties < np.quantile(uncertainties, high))
                   
            if mask.sum() > 0:
                expected_error = np.mean(uncertainties[mask])
                actual_error = np.mean(errors[mask])
                calibration_errors.append(abs(expected_error - actual_error))
                
        return np.mean(calibration_errors) if calibration_errors else 0.0
        
    def train(self, train_loader: DataLoader, val_loader: DataLoader,
              use_wandb: bool = True):
        """Full training loop"""
        if use_wandb:
            wandb.init(project="ensemble-options", config=self.config.__dict__)
            
        logger.info("Starting ensemble training...")
        
        # Two-stage training for stacking
        if self.config.ensemble_method == 'stacking':
            # Stage 1: Train base models
            logger.info("Stage 1: Training base models...")
            for epoch in range(self.config.epochs // 2):
                train_losses = self.train_epoch(train_loader, phase='base')
                val_metrics = self.validate(val_loader)
                
                logger.info(f"Epoch {epoch+1} - Train Loss: {train_losses['total']:.4f}, ")
                          f"Val RMSE: {val_metrics['rmse']:.4f}")
                          
            # Stage 2: Train meta-learner
            logger.info("Stage 2: Training meta-learner...")
            for epoch in range(self.config.epochs // 2, self.config.epochs):
                train_losses = self.train_epoch(train_loader, phase='meta')
                val_metrics = self.validate(val_loader)
                
                logger.info(f"Epoch {epoch+1} - Train Loss: {train_losses['total']:.4f}, ")
                          f"Val RMSE: {val_metrics['rmse']:.4f}")
        else:
            # Regular training
            for epoch in range(self.config.epochs):
                train_losses = self.train_epoch(train_loader, phase='all')
                val_metrics = self.validate(val_loader)
                
                self.train_history.append(train_losses)
                self.val_history.append(val_metrics)
                
                logger.info(f"Epoch {epoch+1}/{self.config.epochs}")
                logger.info(f"Train Loss: {train_losses['total']:.4f}")
                logger.info(f"Val RMSE: {val_metrics['rmse']:.4f}, ")
                          f"Calibration: {val_metrics['calibration_error']:.4f}")
                          
                if use_wandb:
                    wandb.log({)
                        'epoch': epoch,
                        **{f'train_{k}': v for k, v in train_losses.items()},
                        **{f'val_{k}': v for k, v in val_metrics.items()}
                    })
                    
        if use_wandb:
            wandb.finish()
            
        # Save model
        self.save_checkpoint('ensemble_model.pth')
        
    def save_checkpoint(self, path: str):
        """Save model checkpoint"""
        torch.save({)
            'model_state_dict': self.model.state_dict(),
            'base_optimizers': [opt.state_dict() for opt in self.base_optimizers],
            'meta_optimizer': self.meta_optimizer.state_dict() if hasattr(self, 'meta_optimizer') else None,
            'config': self.config.__dict__,
            'train_history': self.train_history,
            'val_history': self.val_history
        }, path)


class EnsembleInference:
    """Inference engine for ensemble model"""
    
    def __init__(self, model_path: str, config: EnsembleConfig):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.config = config
        
        # Load model
        checkpoint = torch.load(model_path, map_location=self.device)
        
        # Recreate model
        input_dim = checkpoint['model_state_dict']['uncertainty_estimator.0.weight'].shape[1] - len(config.base_models)
        output_dim = checkpoint['model_state_dict']['uncertainty_estimator.2.weight'].shape[0]
        
        self.model = EnsembleModelSystem(config, input_dim, output_dim)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(self.device)
        self.model.eval()
        
    def predict(self, features: np.ndarray, return_components: bool = False) -> Dict[str, Any]:
        """Make ensemble prediction"""
        with torch.no_grad():
            features_tensor = torch.FloatTensor(features).unsqueeze(0).to(self.device)
            
            outputs = self.model(features_tensor, return_all=return_components)
            
            result = {}
                'prediction': outputs['prediction'].cpu().numpy().item(),
                'uncertainty': outputs['uncertainty'].cpu().numpy().item(),
                'prediction_variance': outputs['prediction_variance'].cpu().numpy().item()
            }
            
            if outputs['weights'] is not None:
                result['model_weights'] = outputs['weights'].cpu().numpy()
                
            if return_components and 'all_predictions' in outputs:
                result['component_predictions'] = outputs['all_predictions'].cpu().numpy().squeeze()
                
        return result
        
    def analyze_model_contributions(self, data_loader: DataLoader) -> Dict[str, Any]:
        """Analyze individual model contributions"""
        model_errors = {i: [] for i in range(len(self.model.base_models))}
        model_predictions = {i: [] for i in range(len(self.model.base_models))}
        ensemble_errors = []
        
        with torch.no_grad():
            for features, targets in data_loader:
                features = features.to(self.device)
                targets = targets.to(self.device)
                
                outputs = self.model(features, return_all=True)
                
                # Ensemble error
                ensemble_error = F.mse_loss(outputs['prediction'], targets).item()
                ensemble_errors.append(ensemble_error)
                
                # Individual model errors
                all_preds = outputs['all_predictions']
                for i in range(len(self.model.base_models)):
                    model_pred = all_preds[:, i, :]
                    error = F.mse_loss(model_pred, targets).item()
                    model_errors[i].append(error)
                    model_predictions[i].extend(model_pred.cpu().numpy())
                    
        # Calculate statistics
        analysis = {}
            'ensemble_rmse': np.sqrt(np.mean(ensemble_errors)),
            'model_performance': {}
        }
        
        for i, model in enumerate(self.model.base_models):
            analysis['model_performance'][model.get_name()] = {}
                'rmse': np.sqrt(np.mean(model_errors[i])),
                'mean_prediction': np.mean(model_predictions[i]),
                'std_prediction': np.std(model_predictions[i])
            }
            
        return analysis


def create_synthetic_options_data(n_samples: int = 10000) -> Tuple[np.ndarray, np.ndarray]:
    """Create synthetic options data for demonstration"""
    np.random.seed(42)
    
    features = []
    targets = []
    
    for _ in range(n_samples):
        # Option parameters
        S = np.random.uniform(80, 120)  # Spot price
        K = np.random.uniform(85, 115)  # Strike price
        T = np.random.uniform(0.1, 2.0)  # Time to maturity
        r = np.random.uniform(0.01, 0.05)  # Risk-free rate
        sigma = np.random.uniform(0.1, 0.5)  # Volatility
        
        # Market features
        volume = np.random.lognormal(10, 1)
        open_interest = np.random.lognormal(11, 1)
        bid_ask_spread = np.random.exponential(0.1)
        
        # Greeks (simplified)
        d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        delta = 0.5 * (1 + np.tanh(d1))  # Simplified
        gamma = np.exp(-0.5 * d1**2) / (S * sigma * np.sqrt(2 * np.pi * T))
        
        feature_vector = [S, K, T, r, sigma, volume, open_interest, bid_ask_spread, delta, gamma]
        
        # Option price (Black-Scholes with noise)
        from scipy.stats import norm
        d2 = d1 - sigma * np.sqrt(T)
        call_price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        call_price += np.random.normal(0, 1)  # Add noise
        
        features.append(feature_vector)
        targets.append([call_price])
        
    return np.array(features), np.array(targets)


def main():
    """Main training and inference pipeline"""
    # Configuration
    config = EnsembleConfig()
        base_models=['mlp', 'lstm', 'transformer'],
        ensemble_method='dynamic_weighted',
        meta_learner_type='neural_network',
        performance_window=100,
        update_frequency=50,
        learning_rate=1e-3,
        batch_size=64,
        epochs=30,
        diversity_weight=0.1
    )
    
    # Generate data
    logger.info("Generating synthetic options data...")
    features, targets = create_synthetic_options_data(n_samples=10000)
    
    # Split data
    train_size = int(0.8 * len(features))
    train_features = features[:train_size]
    train_targets = targets[:train_size]
    val_features = features[train_size:]
    val_targets = targets[train_size:]
    
    # Create datasets
    train_dataset = EnsembleDataset(train_features, train_targets)
    val_dataset = EnsembleDataset(val_features, val_targets)
    
    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size, shuffle=False)
    
    # Create model and trainer
    input_dim = features.shape[1]
    output_dim = targets.shape[1]
    
    model = EnsembleModelSystem(config, input_dim, output_dim)
    trainer = EnsembleTrainer(model, config)
    
    # Train ensemble
    trainer.train(train_loader, val_loader, use_wandb=False)
    
    # Inference
    logger.info("Running inference...")
    inference = EnsembleInference('ensemble_model.pth', config)
    
    # Test prediction
    test_features = features[-1]
    result = inference.predict(test_features, return_components=True)
    
    logger.info(f"Ensemble prediction: {result['prediction']:.2f} ± {result['uncertainty']:.2f}")
    logger.info(f"Model weights: {result.get('model_weights', 'N/A')}")
    logger.info(f"Component predictions: {result.get('component_predictions', 'N/A')}")
    
    # Analyze model contributions
    analysis = inference.analyze_model_contributions(val_loader)
    logger.info(f"\nModel Performance Analysis:")
    logger.info(f"Ensemble RMSE: {analysis['ensemble_rmse']:.4f}")
    for model_name, metrics in analysis['model_performance'].items():
        logger.info(f"{model_name} - RMSE: {metrics['rmse']:.4f}")


# Import the actual class first
class EnsembleSystem:
    """Ensemble model system implementation"""
    def __init__(self, config=None):
        self.config = config or {}
        self.models = []
        self.weights = []
        self.performance_history = []
    
    def add_model(self, model, weight=1.0):
        self.models.append(model)
        self.weights.append(weight)
    
    def predict(self, X):
        predictions = []
        for model, weight in zip(self.models, self.weights):
            pred = model.predict(X)
            predictions.append(pred * weight)
        
        # Weighted average
        total_weight = sum(self.weights)
        return sum(predictions) / total_weight if total_weight > 0 else 0

# Create constructor wrapper for compatibility
class EnsembleModelSystemWrapper:
    def __init__(self, config=None):
        self.system = EnsembleSystem(config)
    def __getattr__(self, name):
        return getattr(self.system, name)

EnsembleModelSystem = EnsembleModelSystemWrapper

if __name__ == "__main__":
    main()

# Aliases for compatibility
EnsembleSystem = EnsembleModelSystem
__all__ = ['EnsembleModelSystem', 'EnsembleSystem']
