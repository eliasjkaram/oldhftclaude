
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Demo Enhanced Trading Predictor with Simulated Data
Shows the improved prediction capabilities with realistic financial data
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler, RobustScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import time
import warnings
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional

from universal_market_data import get_current_market_data, validate_price

warnings.filterwarnings('ignore')

class EnhancedTransformer(nn.Module):
    """Advanced Transformer for financial prediction"""
    
    def __init__(self, input_size=15, d_model=128, nhead=8, num_layers=4, seq_len=60):
        super(EnhancedTransformer, self).__init__()
        self.d_model = d_model
        
        # Input projection
        self.input_projection = nn.Linear(input_size, d_model)
        
        # Positional encoding
        self.pos_encoding = self._create_positional_encoding(seq_len, d_model)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer()
            d_model=d_model, nhead=nhead, dim_feedforward=512,
            dropout=0.2, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # Output prediction
        self.output_layers = nn.Sequential()
            nn.LayerNorm(d_model),
            nn.Linear(d_model, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 3)  # price_change, volatility, trend_strength
        )
        
    def _create_positional_encoding(self, seq_len, d_model):
        pe = torch.zeros(seq_len, d_model)
        position = torch.arange(0, seq_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * -(np.log(10000.0) / d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe.unsqueeze(0)
    
    def forward(self, x):
        # Project and add positional encoding
        x = self.input_projection(x)
        x = x + self.pos_encoding[:, :x.size(1), :].to(x.device)
        
        # Transformer encoding
        transformer_out = self.transformer(x)
        
        # Global average pooling
        pooled = transformer_out.mean(dim=1)
        
        return self.output_layers(pooled)

class AdvancedLSTMEnsemble(nn.Module):
    """Enhanced LSTM with multiple scales and attention"""
    
    def __init__(self, input_size=15, hidden_size=256):
        super(AdvancedLSTMEnsemble, self).__init__()
        
        # Multi-scale LSTM
        self.lstm_short = nn.LSTM(input_size, hidden_size//2, 2, batch_first=True, dropout=0.2)
        self.lstm_long = nn.LSTM(input_size, hidden_size//2, 3, batch_first=True, dropout=0.2)
        
        # Attention mechanism
        self.attention = nn.MultiheadAttention(hidden_size, num_heads=8, batch_first=True)
        
        # Output layers
        self.output_layers = nn.Sequential()
            nn.LayerNorm(hidden_size),
            nn.Linear(hidden_size, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 3)
        )
        
    def forward(self, x):
        # Multi-scale processing
        short_out, _ = self.lstm_short(x)
        long_out, _ = self.lstm_long(x)
        
        # Combine scales
        combined = torch.cat([short_out, long_out], dim=-1)
        
        # Apply attention
        attn_out, _ = self.attention(combined, combined, combined)
        
        # Use last timestep
        last_output = attn_out[:, -1, :]
        
        return self.output_layers(last_output)

class DemoEnhancedPredictor:
    """Demo predictor with simulated enhanced data"""
    
    def __init__(self, symbols=['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'NVDA']):
        self.symbols = symbols
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.models = {}
        self.scalers = {}
        self.sequence_length = 60
        
        print(f"🚀 Demo Enhanced Trading Prediction AI")
        print(f"Device: {self.device}")
        if torch.cuda.is_available():
            print(f"GPU: {torch.cuda.get_device_name(0)}")
            print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
    
    def generate_enhanced_market_data(self, symbol: str, periods: int = 2000) -> pd.DataFrame:
        """Generate realistic market data with enhanced features"""
        np.random.seed(hash(symbol) % 2**32)
        
        # Base parameters for different stocks
        base_params = {}
            'AAPL': {'price': 195.0, 'vol': 0.015, 'trend': 0.0001},
            'MSFT': {'price': 425.0, 'vol': 0.012, 'trend': 0.0002},
            'GOOGL': {'price': 175.0, 'vol': 0.018, 'trend': 0.0001},
            'TSLA': {'price': 245.0, 'vol': 0.030, 'trend': -0.0001},
            'NVDA': {'price': 875.0, 'vol': 0.025, 'trend': 0.0003}
        }
        
        params = base_params.get(symbol, {'price': 200.0, 'vol': 0.02, 'trend': 0.0})
        
        # Generate price series with realistic patterns
        returns = np.random.normal(params['trend'], params['vol'], periods)
        
        # Add market regime changes
        regime_changes = np.random.random(periods) < 0.01  # 1% chance of regime change
        regime_multiplier = np.ones(periods)
        for i in np.where(regime_changes)[0]:
            regime_multiplier[i:i+50] *= np.random.choice([0.5, 1.5], p=[0.3, 0.7])
        
        returns *= regime_multiplier
        
        # Generate prices
        prices = [params['price']]
        for ret in returns:
            prices.append(prices[-1] * (1 + ret)
        
        prices = np.array(prices[1:])
        
        # Create OHLCV data
        df = pd.DataFrame(index=pd.date_range(start='2023-01-01', periods=periods, freq='1H')
        df['Close'] = prices
        
        # Generate realistic OHLC
        noise = np.random.normal(0, 0.001, periods)
        df['Open'] = df['Close'].shift(1) * (1 + noise)
        df['High'] = np.maximum(df['Open'], df['Close']) * (1 + np.abs(np.random.normal(0, 0.002, periods))
        df['Low'] = np.minimum(df['Open'], df['Close']) * (1 - np.abs(np.random.normal(0, 0.002, periods))
        df['Volume'] = np.random.lognormal(15, 1, periods)
        
        # Fill NaN values
        df = df.fillna(method='ffill').fillna(method='bfill')
        
        # Add technical features
        df = self.add_technical_features(df)
        
        return df.dropna()
    
    def add_technical_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add comprehensive technical analysis features"""
        
        # Price-based features
        df['returns'] = df['Close'].pct_change()
        df['log_returns'] = np.log(df['Close'] / df['Close'].shift(1)
        df['volatility'] = df['returns'].rolling(20).std()
        
        # Moving averages
        df['sma_5'] = df['Close'].rolling(5).mean()
        df['sma_20'] = df['Close'].rolling(20).mean()
        df['sma_50'] = df['Close'].rolling(50).mean()
        df['ema_12'] = df['Close'].ewm(span=12).mean()
        df['ema_26'] = df['Close'].ewm(span=26).mean()
        
        # MACD
        df['macd'] = df['ema_12'] - df['ema_26']
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # RSI (simplified)
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0).rolling(window=14).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=14).mean())
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs)
        
        # Bollinger Bands
        df['bb_middle'] = df['Close'].rolling(20).mean()
        bb_std = df['Close'].rolling(20).std()
        df['bb_upper'] = df['bb_middle'] + (bb_std * 2)
        df['bb_lower'] = df['bb_middle'] - (bb_std * 2)
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
        df['bb_position'] = (df['Close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
        
        # Volume features
        df['volume_sma'] = df['Volume'].rolling(20).mean()
        df['volume_ratio'] = df['Volume'] / df['volume_sma']
        
        # Price position features
        df['price_position_20'] = df['Close'] / df['sma_20']
        df['price_position_50'] = df['Close'] / df['sma_50']
        
        # Momentum
        df['momentum_10'] = df['Close'] / df['Close'].shift(10)
        df['momentum_20'] = df['Close'] / df['Close'].shift(20)
        
        return df
    
    def prepare_training_data(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare training sequences with enhanced features"""
        
        feature_columns = []
            'returns', 'volatility', 'sma_5', 'sma_20', 'ema_12', 'ema_26',
            'macd', 'macd_signal', 'rsi', 'bb_width', 'bb_position',
            'volume_ratio', 'price_position_20', 'momentum_10', 'momentum_20'
        ]
        
        # Select available features
        available_features = [col for col in feature_columns if col in df.columns and not df[col].isna().all()]
        features = df[available_features].values
        
        # Scale features
        scaler = RobustScaler()
        features_scaled = scaler.fit_transform(features)
        
        # Create sequences
        X, y = [], []
        for i in range(self.sequence_length, len(features_scaled):
            X.append(features_scaled[i-self.sequence_length:i])
            
            # Multi-target prediction
            current_price = df['Close'].iloc[i-1]
            next_price = df['Close'].iloc[i]
            price_change = (next_price - current_price) / current_price
            
            volatility = df['volatility'].iloc[i] if not pd.isna(df['volatility'].iloc[i]) else 0
            trend_strength = np.tanh(price_change * 100)  # Normalize trend strength
            
            y.append([price_change, volatility, trend_strength])
        
        return np.array(X), np.array(y), scaler
    
    def train_enhanced_model(self, symbol: str, epochs: int = 100):
        """Train enhanced ensemble models"""
        print(f"\n🎯 Training enhanced models for {symbol}")
        
        # Generate enhanced data
        df = self.generate_enhanced_market_data(symbol)
        X, y, scaler = self.prepare_training_data(df)
        self.scalers[symbol] = scaler
        
        # Split data
        split_idx = int(len(X) * 0.8)
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Convert to tensors
        X_train = torch.FloatTensor(X_train).to(self.device)
        y_train = torch.FloatTensor(y_train).to(self.device)
        X_test = torch.FloatTensor(X_test).to(self.device)
        y_test = torch.FloatTensor(y_test).to(self.device)
        
        input_size = X_train.shape[-1]
        
        # Create ensemble models
        models = {}
            'transformer': EnhancedTransformer(input_size=input_size, d_model=128, num_layers=4).to(self.device),
            'lstm_advanced': AdvancedLSTMEnsemble(input_size=input_size, hidden_size=256).to(self.device),
            'lstm_compact': AdvancedLSTMEnsemble(input_size=input_size, hidden_size=128).to(self.device)
        }
        
        self.models[symbol] = {}
        
        # Train each model
        for model_name, model in models.items():
            print(f"  📚 Training {model_name}...")
            
            optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)
            scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=10)
            criterion = nn.MSELoss()
            
            best_loss = float('inf')
            patience = 10
            patience_counter = 0
            
            for epoch in range(epochs):
                model.train()
                optimizer.zero_grad()
                
                outputs = model(X_train)
                loss = criterion(outputs, y_train)
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                scheduler.step()
                
                if epoch % 10 == 0:
                    model.eval()
                    with torch.no_grad():
                        val_outputs = model(X_test)
                        val_loss = criterion(val_outputs, y_test).item()
                    
                    if val_loss < best_loss:
                        best_loss = val_loss
                        patience_counter = 0
                        self.models[symbol][model_name] = {}
                            'model': model.state_dict(),
                            'loss': val_loss,
                            'architecture': model
                        }
                    else:
                        patience_counter += 1
                    
                    if patience_counter >= patience:
                        break
            
            print(f"    ✅ {model_name} - Best validation loss: {best_loss:.6f}")
        
        return True
    
    def predict_enhanced(self, symbol: str) -> Dict:
        """Make enhanced ensemble predictions"""
        if symbol not in self.models:
            return {}
        
        # Generate recent data for prediction
        df = self.generate_enhanced_market_data(symbol)
        features = self.add_technical_features(df)
        
        feature_columns = []
            'returns', 'volatility', 'sma_5', 'sma_20', 'ema_12', 'ema_26',
            'macd', 'macd_signal', 'rsi', 'bb_width', 'bb_position',
            'volume_ratio', 'price_position_20', 'momentum_10', 'momentum_20'
        ]
        
        available_features = [col for col in feature_columns if col in features.columns and not features[col].isna().all()]
        feature_data = features[available_features].values
        
        # Scale and prepare sequence
        feature_scaled = self.scalers[symbol].transform(feature_data)
        last_sequence = feature_scaled[-self.sequence_length:].reshape(1, self.sequence_length, -1)
        last_sequence = torch.FloatTensor(last_sequence).to(self.device)
        
        # Ensemble predictions
        predictions = {}
        ensemble_preds = []
        weights = []
        
        for model_name, model_data in self.models[symbol].items():
            model = model_data['architecture']
            model.load_state_dict(model_data['model'])
            model.eval()
            
            with torch.no_grad():
                pred = model(last_sequence).cpu().numpy()[0]
                confidence = 1.0 / (1.0 + model_data['loss'])
                
                predictions[model_name] = {}
                    'price_change': pred[0],
                    'volatility': pred[1],
                    'trend_strength': pred[2],
                    'confidence': confidence
                }
                
                ensemble_preds.append(pred)
                weights.append(confidence)
        
        # Weighted ensemble average
        weights = np.array(weights) / sum(weights)
        ensemble_pred = np.average(ensemble_preds, axis=0, weights=weights)
        
        current_price = features['Close'].iloc[-1]
        predicted_price = current_price * (1 + ensemble_pred[0])
        
        return {}
            'symbol': symbol,
            'current_price': current_price,
            'predicted_price': predicted_price,
            'price_change_pct': ensemble_pred[0] * 100,
            'predicted_volatility': ensemble_pred[1],
            'trend_strength': ensemble_pred[2],
            'ensemble_confidence': np.mean(weights),
            'individual_models': predictions
        }
    
    def run_demo_system(self):
        """Run the complete demo enhanced prediction system"""
        print("🧠 Enhanced Trading Prediction AI - Demo Mode")
        print("=" * 60)
        
        # Train models for all symbols
        for symbol in self.symbols:
            self.train_enhanced_model(symbol, epochs=80)
        
        print("\n" + "=" * 60)
        print("🔮 ENHANCED PREDICTION RESULTS")
        print("=" * 60)
        
        # Generate predictions
        all_predictions = {}
        for symbol in self.symbols:
            pred = self.predict_enhanced(symbol)
            if pred:
                all_predictions[symbol] = pred
                
                direction = "📈" if pred['price_change_pct'] > 0 else "📉"
                print(f"\n{direction} {symbol}")
                print(f"  Current: ${pred['current_price']:.2f}")
                print(f"  Predicted: ${pred['predicted_price']:.2f} ({pred['price_change_pct']:+.2f}%)")
                print(f"  Volatility: {pred['predicted_volatility']:.4f}")
                print(f"  Trend Strength: {pred['trend_strength']:+.3f}")
                print(f"  Confidence: {pred['ensemble_confidence']:.3f}")
        
        # Summary
        if all_predictions:
            print(f"\n📊 TRADING SIGNALS SUMMARY")
            print("-" * 40)
            strong_bullish = [s for s, p in all_predictions.items() if p['price_change_pct'] > 1.0]
            bullish = [s for s, p in all_predictions.items() if 0.5 < p['price_change_pct'] <= 1.0]
            bearish = [s for s, p in all_predictions.items() if -1.0 < p['price_change_pct'] <= -0.5]
            strong_bearish = [s for s, p in all_predictions.items() if p['price_change_pct'] <= -1.0]
            
            if strong_bullish:
                print(f"🚀 STRONG BUY: {', '.join(strong_bullish)}")
            if bullish:
                print(f"📈 BUY: {', '.join(bullish)}")
            if bearish:
                print(f"📉 SELL: {', '.join(bearish)}")
            if strong_bearish:
                print(f"💥 STRONG SELL: {', '.join(strong_bearish)}")
        
        return all_predictions

if __name__ == "__main__":
    # Run the demo enhanced prediction system
    predictor = DemoEnhancedPredictor()
    results = predictor.run_demo_system()