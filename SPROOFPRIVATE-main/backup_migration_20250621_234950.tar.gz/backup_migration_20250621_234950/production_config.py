#!/usr/bin/env python3
"""
Production Configuration Module
==============================

Centralized configuration for all production trading systems.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


class ProductionConfig:
    """Production configuration manager"""
    
    def __init__(self, config_path: str = "production_config.json"):
        self.config_path = Path(config_path)
        self.config = self._load_config()
        self._validate_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or environment"""
        config = {}
            # API Configuration
            "alpaca": {}
                "api_key": os.getenv("ALPACA_API_KEY"),
                "secret_key": os.getenv("ALPACA_SECRET_KEY"),
                "base_url": os.getenv("ALPACA_BASE_URL", "https://api.alpaca.markets"),
                "data_url": os.getenv("ALPACA_DATA_URL", "https://data.alpaca.markets"),
                "paper_trading": os.getenv("PAPER_TRADING", "true").lower() == "true"
            },
            
            # AI Configuration
            "ai": {}
                "openrouter_api_key": os.getenv("OPENROUTER_API_KEY"),
                "openrouter_base_url": "https://openrouter.ai/api/v1",
                "models": {}
                    "primary": os.getenv("AI_PRIMARY_MODEL", "deepseek/deepseek-r1"),
                    "secondary": os.getenv("AI_SECONDARY_MODEL", "google/gemini-flash-1.5-8b"),
                    "fast": os.getenv("AI_FAST_MODEL", "qwen/qwen-2.5-coder-32b-instruct")
                },
                "min_confidence": float(os.getenv("AI_MIN_CONFIDENCE", "0.7")),
                "max_concurrent_requests": int(os.getenv("AI_MAX_CONCURRENT", "5"))
            },
            
            # Data Sources
            "data": {}
                "minio": {}
                    "endpoint": os.getenv("MINIO_ENDPOINT", "uschristmas.us"),
                    "access_key": os.getenv("MINIO_ACCESS_KEY"),
                    "secret_key": os.getenv("MINIO_SECRET_KEY"),
                    "bucket": os.getenv("MINIO_BUCKET", "stockdb"),
                    "secure": os.getenv("MINIO_SECURE", "true").lower() == "true"
                },
                "yfinance": {}
                    "enabled": os.getenv("YFINANCE_ENABLED", "true").lower() == "true",
                    "cache_dir": os.getenv("YFINANCE_CACHE_DIR", "./cache/yfinance")
                },
                "polygon": {}
                    "api_key": os.getenv("POLYGON_API_KEY"),
                    "enabled": os.getenv("POLYGON_ENABLED", "false").lower() == "true"
                }
            },
            
            # Trading Configuration
            "trading": {}
                "initial_capital": float(os.getenv("INITIAL_CAPITAL", "100000")),
                "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
                "max_positions": int(os.getenv("MAX_POSITIONS", "10")),
                "stop_loss": float(os.getenv("STOP_LOSS", "0.02")),
                "take_profit": float(os.getenv("TAKE_PROFIT", "0.05")),
                "trailing_stop": float(os.getenv("TRAILING_STOP", "0.015")),
                "symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL,AMZN,NVDA,META,TSLA,JPM").split(","),
                "excluded_symbols": os.getenv("EXCLUDED_SYMBOLS", "").split(",") if os.getenv("EXCLUDED_SYMBOLS") else [],
                "enable_options": os.getenv("ENABLE_OPTIONS", "true").lower() == "true",
                "enable_crypto": os.getenv("ENABLE_CRYPTO", "false").lower() == "true",
                "enable_futures": os.getenv("ENABLE_FUTURES", "false").lower() == "true"
            },
            
            # Risk Management
            "risk": {}
                "max_daily_loss": float(os.getenv("MAX_DAILY_LOSS", "0.02")),
                "max_drawdown": float(os.getenv("MAX_DRAWDOWN", "0.10")),
                "var_confidence": float(os.getenv("VAR_CONFIDENCE", "0.95")),
                "position_sizing_method": os.getenv("POSITION_SIZING", "kelly"),
                "rebalance_frequency": os.getenv("REBALANCE_FREQ", "daily"),
                "risk_free_rate": float(os.getenv("RISK_FREE_RATE", "0.05"))
            },
            
            # Machine Learning
            "ml": {}
                "enabled": os.getenv("ML_ENABLED", "true").lower() == "true",
                "model_path": os.getenv("ML_MODEL_PATH", "./models"),
                "training_frequency": os.getenv("ML_TRAINING_FREQ", "weekly"),
                "min_training_samples": int(os.getenv("ML_MIN_SAMPLES", "1000")),
                "feature_importance_threshold": float(os.getenv("ML_FEATURE_THRESHOLD", "0.01")),
                "ensemble_models": os.getenv("ML_ENSEMBLE", "true").lower() == "true"
            },
            
            # Options Trading
            "options": {}
                "enabled": os.getenv("OPTIONS_ENABLED", "true").lower() == "true",
                "strategies": os.getenv("OPTIONS_STRATEGIES", "covered_call,cash_secured_put,iron_condor,butterfly").split(","),
                "min_premium": float(os.getenv("OPTIONS_MIN_PREMIUM", "0.50")),
                "min_volume": int(os.getenv("OPTIONS_MIN_VOLUME", "10")),
                "max_dte": int(os.getenv("OPTIONS_MAX_DTE", "45")),
                "min_dte": int(os.getenv("OPTIONS_MIN_DTE", "7")),
                "delta_threshold": float(os.getenv("OPTIONS_DELTA", "0.30"))
            },
            
            # System Configuration
            "system": {}
                "environment": os.getenv("ENVIRONMENT", "production"),
                "log_level": os.getenv("LOG_LEVEL", "INFO"),
                "log_dir": os.getenv("LOG_DIR", "./logs"),
                "data_dir": os.getenv("DATA_DIR", "./data"),
                "cache_dir": os.getenv("CACHE_DIR", "./cache"),
                "database_url": os.getenv("DATABASE_URL", "sqlite:///production_trading.db"),
                "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
                "enable_monitoring": os.getenv("ENABLE_MONITORING", "true").lower() == "true",
                "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
                "notification_webhook": os.getenv("NOTIFICATION_WEBHOOK"),
                "health_check_interval": int(os.getenv("HEALTH_CHECK_INTERVAL", "300"))
            },
            
            # Performance Optimization
            "performance": {}
                "enable_gpu": os.getenv("ENABLE_GPU", "false").lower() == "true",
                "num_workers": int(os.getenv("NUM_WORKERS", "4")),
                "batch_size": int(os.getenv("BATCH_SIZE", "32")),
                "cache_ttl": int(os.getenv("CACHE_TTL", "3600")),
                "enable_profiling": os.getenv("ENABLE_PROFILING", "false").lower() == "true"
            },
            
            # Backtesting
            "backtesting": {}
                "enabled": os.getenv("BACKTESTING_ENABLED", "true").lower() == "true",
                "start_date": os.getenv("BACKTEST_START", "2020-01-01"),
                "end_date": os.getenv("BACKTEST_END", "2024-12-31"),
                "initial_capital": float(os.getenv("BACKTEST_CAPITAL", "100000")),
                "commission": float(os.getenv("BACKTEST_COMMISSION", "0.001")),
                "slippage": float(os.getenv("BACKTEST_SLIPPAGE", "0.0005"))
            }
        }
        
        # Load from file if exists
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    file_config = json.load(f)
                # Merge with environment config (env takes precedence)
                config = self._deep_merge(file_config, config)
            except Exception as e:
                logger.warning(f"Failed to load config file: {e}")
        
        return config
    
    def _deep_merge(self, base: Dict, override: Dict) -> Dict:
        """Deep merge two dictionaries"""
        result = base.copy()
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            elif value is not None:  # Only override if value is not None
                result[key] = value
        return result
    
    def _validate_config(self):
        """Validate configuration"""
        # Check required API keys
        if not self.config["alpaca"]["api_key"] or not self.config["alpaca"]["secret_key"]:
            logger.warning("Alpaca API credentials not configured")
        
        # Validate trading symbols
        if not self.config["trading"]["symbols"]:
            logger.error("No trading symbols configured")
            self.config["trading"]["symbols"] = ["SPY"]
        
        # Validate risk parameters
        if self.config["risk"]["max_daily_loss"] > 0.1:
            logger.warning("Max daily loss seems high (>10%)")
        
        # Create required directories
        for dir_key in ["log_dir", "data_dir", "cache_dir"]:
            dir_path = Path(self.config["system"][dir_key])
            if not dir_path.exists():
                dir_path.mkdir(parents=True, exist_ok=True)
        
        # Validate ML model path
        if self.config["ml"]["enabled"]:
            model_path = Path(self.config["ml"]["model_path"])
            if not model_path.exists():
                model_path.mkdir(parents=True, exist_ok=True)
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """Get configuration value by dot notation path"""
        keys = key_path.split('.')
        value = self.config
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    def set(self, key_path: str, value: Any):
        """Set configuration value by dot notation path"""
        keys = key_path.split('.')
        config = self.config
        
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        config[keys[-1]] = value
    
    def save(self):
        """Save configuration to file"""
        try:
            with open(self.config_path, 'w') as f:
                json.dump(self.config, f, indent=2, default=str)
            logger.info(f"Configuration saved to {self.config_path}")
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
    
    def get_secure_value(self, key: str) -> Optional[str]:
        """Get encrypted value (for sensitive data)"""
        encrypted_key = f"{key}_encrypted"
        if encrypted_key in os.environ:
            try:
                cipher = Fernet(os.getenv("ENCRYPTION_KEY"))
                encrypted_value = os.getenv(encrypted_key)
                return cipher.decrypt(encrypted_value.encode()).decode()
            except Exception as e:
                logger.error(f"Failed to decrypt {key}: {e}")
        return None
    
    def validate_trading_hours(self) -> bool:
        """Check if current time is within trading hours"""
        now = datetime.now()
        
        # Check if weekend
        if now.weekday() >= 5:  # Saturday = 5, Sunday = 6
            return False
        
        # Check market hours (9:30 AM - 4:00 PM ET)
        # You might want to adjust for your timezone
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        return market_open <= now <= market_close
    
    def get_trading_mode(self) -> str:
        """Get current trading mode based on config and time"""
        if self.config["alpaca"]["paper_trading"]:
            return "paper"
        elif self.validate_trading_hours():
            return "live"
        else:
            return "after_hours"
    
    def to_dict(self) -> Dict[str, Any]:
        """Get full configuration as dictionary"""
        return self.config.copy()
    
    def __repr__(self) -> str:
        return f"ProductionConfig(environment={self.config['system']['environment']})"


# Global configuration instance
config = ProductionConfig()


# Helper functions for common config access
def get_api_key(service: str) -> Optional[str]:
    """Get API key for a service"""
    if service == "alpaca":
        return config.get("alpaca.api_key")
    elif service == "openrouter":
        return config.get("ai.openrouter_api_key")
    elif service == "polygon":
        return config.get("data.polygon.api_key")
    elif service == "minio":
        return config.get("data.minio.access_key")
    else:
        return None


def get_trading_symbols() -> List[str]:
    """Get list of trading symbols"""
    symbols = config.get("trading.symbols", ["SPY"])
    excluded = config.get("trading.excluded_symbols", [])
    return [s for s in symbols if s not in excluded]


def is_feature_enabled(feature: str) -> bool:
    """Check if a feature is enabled"""
    feature_map = {}
        "options": "options.enabled",
        "ml": "ml.enabled",
        "crypto": "trading.enable_crypto",
        "futures": "trading.enable_futures",
        "monitoring": "system.enable_monitoring",
        "notifications": "system.enable_notifications",
        "gpu": "performance.enable_gpu",
        "backtesting": "backtesting.enabled"
    }
    
    return config.get(feature_map.get(feature, f"{feature}.enabled"), False)


def get_risk_limits() -> Dict[str, float]:
    """Get risk management limits"""
    return {}
        "max_position_size": config.get("trading.max_position_size", 0.1),
        "max_daily_loss": config.get("risk.max_daily_loss", 0.02),
        "max_drawdown": config.get("risk.max_drawdown", 0.10),
        "stop_loss": config.get("trading.stop_loss", 0.02),
        "take_profit": config.get("trading.take_profit", 0.05)
    }


if __name__ == "__main__":
    # Test configuration
    print(f"Environment: {config.get('system.environment')}")
    print(f"Trading Mode: {config.get_trading_mode()}")
    print(f"Trading Symbols: {get_trading_symbols()}")
    print(f"Risk Limits: {get_risk_limits()}")
    print(f"ML Enabled: {is_feature_enabled('ml')}")
    print(f"Options Enabled: {is_feature_enabled('options')}")
    
    # Save default config
    config.save()