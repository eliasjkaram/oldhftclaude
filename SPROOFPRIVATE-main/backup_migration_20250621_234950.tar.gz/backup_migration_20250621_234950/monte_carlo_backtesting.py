#!/usr/bin/env python3
"""
Advanced Monte Carlo Simulation for Backtesting
Implements sophisticated risk analysis and strategy validation
"""

import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import norm, t, skew, kurtosis
import json
from datetime import datetime, timedelta
import multiprocessing as mp
from functools import partial
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, get_realistic_price

warnings.filterwarnings('ignore')

class MonteCarloBacktester:
    """Advanced Monte Carlo simulation for trading strategy validation"""
    
    def __init__(self, initial_capital=100000, confidence_levels=[0.95, 0.99]):
        self.initial_capital = initial_capital
        self.confidence_levels = confidence_levels
        self.simulation_results = None
        
    def block_bootstrap(self, returns, block_size=None, n_samples=None):
        """
        Block bootstrap for time series data to preserve autocorrelation
        
        Args:
            returns: Historical returns series
            block_size: Size of blocks (auto-calculated if None)
            n_samples: Number of samples to generate
        """
        n = len(returns)
        
        if block_size is None:
            # Optimal block size based on data characteristics
            block_size = int(np.ceil(n ** (1/3)))
        
        if n_samples is None:
            n_samples = n
        
        # Generate blocks
        n_blocks = int(np.ceil(n_samples / block_size))
        sampled_returns = []
        
        for _ in range(n_blocks):
            # Random starting point
            start_idx = np.random.randint(0, n - block_size + 1)
            block = returns.iloc[start_idx:start_idx + block_size].values
            sampled_returns.extend(block)
        
        # Trim to exact size
        return np.array(sampled_returns[:n_samples])
    
    def fit_return_distribution(self, returns):
        """
        Fit various distributions to returns and select best fit
        
        Args:
            returns: Historical returns
            
        Returns:
            Best fitting distribution parameters
        """
        # Remove any NaN values
        clean_returns = returns.dropna()
        
        # Test multiple distributions
        distributions = {}
            'normal': stats.norm,
            't': stats.t,
            'skewnorm': stats.skewnorm,
            'gennorm': stats.gennorm
        }
        
        best_fit = None
        best_aic = np.inf
        
        for dist_name, dist_func in distributions.items():
            try:
                # Fit distribution
                params = dist_func.fit(clean_returns)
                
                # Calculate log-likelihood
                log_likelihood = np.sum(dist_func.logpdf(clean_returns, *params))
                
                # Calculate AIC (Akaike Information Criterion)
                n_params = len(params)
                aic = 2 * n_params - 2 * log_likelihood
                
                if aic < best_aic:
                    best_aic = aic
                    best_fit = {}
                        'distribution': dist_name,
                        'params': params,
                        'aic': aic
                    }
            except:
                continue
        
        return best_fit
    
    def generate_scenarios(self, historical_data, n_scenarios=1000,
                         horizon_days=252, method='bootstrap'):
        """
        Generate future price scenarios using various methods
        
        Args:
            historical_data: Historical price/return data
            n_scenarios: Number of scenarios to generate
            horizon_days: Forecast horizon in days
            method: 'bootstrap', 'parametric', 'garch', 'regime_switching'
        """
        if 'returns' not in historical_data.columns:
            historical_data['returns'] = historical_data['close'].pct_change()
        
        returns = historical_data['returns'].dropna()
        scenarios = []
        
        if method == 'bootstrap':
            # Block bootstrap method
            for _ in range(n_scenarios):
                scenario_returns = self.block_bootstrap(returns, n_samples=horizon_days)
                scenarios.append(scenario_returns)
                
        elif method == 'parametric':
            # Parametric method with best-fit distribution
            dist_fit = self.fit_return_distribution(returns)
            
            if dist_fit['distribution'] == 'normal':
                mu, sigma = dist_fit['params']
                for _ in range(n_scenarios):
                    scenario_returns = np.random.normal(mu, sigma, horizon_days)
                    scenarios.append(scenario_returns)
                    
            elif dist_fit['distribution'] == 't':
                df, loc, scale = dist_fit['params']
                for _ in range(n_scenarios):
                    scenario_returns = stats.t.rvs(df, loc=loc, scale=scale, size=horizon_days)
                    scenarios.append(scenario_returns)
                    
        elif method == 'garch':
            # Simplified GARCH(1,1) simulation
            scenarios = self._simulate_garch(returns, n_scenarios, horizon_days)
            
        elif method == 'regime_switching':
            # Regime switching model
            scenarios = self._simulate_regime_switching(returns, n_scenarios, horizon_days)
        
        return np.array(scenarios)
    
    def _simulate_garch(self, returns, n_scenarios, horizon_days):
        """Simulate returns using GARCH(1,1) model"""
        # Estimate GARCH parameters (simplified)
        returns_sq = returns ** 2
        
        # Initial variance estimate
        omega = np.var(returns) * 0.1
        alpha = 0.1  # ARCH parameter
        beta = 0.8   # GARCH parameter
        
        scenarios = []
        
        for _ in range(n_scenarios):
            scenario = []
            current_var = np.var(returns)
            
            for _ in range(horizon_days):
                # Update variance
                shock = np.random.standard_normal()
                ret = np.sqrt(current_var) * shock
                
                # Update conditional variance
                current_var = omega + alpha * (ret ** 2) + beta * current_var
                
                scenario.append(ret)
            
            scenarios.append(scenario)
        
        return scenarios
    
    def _simulate_regime_switching(self, returns, n_scenarios, horizon_days):
        """Simulate returns with regime switching"""
        # Identify regimes using simple volatility clustering
        vol = returns.rolling(20).std()
        median_vol = vol.median()
        
        # Two regimes: low and high volatility
        low_vol_returns = returns[vol <= median_vol]
        high_vol_returns = returns[vol > median_vol]
        
        # Estimate parameters for each regime
        low_vol_params = (low_vol_returns.mean(), low_vol_returns.std())
        high_vol_params = (high_vol_returns.mean(), high_vol_returns.std())
        
        # Transition probabilities
        p_stay_low = 0.95
        p_stay_high = 0.90
        
        scenarios = []
        
        for _ in range(n_scenarios):
            scenario = []
            current_regime = 'low' if np.random.random() > 0.5 else 'high'
            
            for _ in range(horizon_days):
                # Generate return based on current regime
                if current_regime == 'low':
                    ret = np.random.normal(*low_vol_params)
                    # Transition probability
                    if np.random.random() > p_stay_low:
                        current_regime = 'high'
                else:
                    ret = np.random.normal(*high_vol_params)
                    # Transition probability
                    if np.random.random() > p_stay_high:
                        current_regime = 'low'
                
                scenario.append(ret)
            
            scenarios.append(scenario)
        
        return scenarios
    
    def run_strategy_simulation(self, strategy_signals, price_scenarios,
                              transaction_cost=0.001):
        """
        Run trading strategy across multiple price scenarios
        
        Args:
            strategy_signals: Function that generates trading signals
            price_scenarios: Array of price scenarios
            transaction_cost: Cost per transaction
        """
        n_scenarios = len(price_scenarios)
        portfolio_values = []
        
        for scenario_returns in price_scenarios:
            # Convert returns to prices
            prices = self._returns_to_prices(scenario_returns, 100)
            
            # Generate trading signals
            signals = strategy_signals(prices)
            
            # Simulate trading
            portfolio = self._simulate_trading(prices, signals, transaction_cost)
            portfolio_values.append(portfolio)
        
        self.simulation_results = {}
            'portfolio_values': np.array(portfolio_values),
            'final_values': np.array([pv[-1] for pv in portfolio_values]),
            'returns': np.array([(pv[-1] - self.initial_capital) / self.initial_capital)
                                for pv in portfolio_values])
        }
        
        return self.simulation_results
    
    def _returns_to_prices(self, returns, initial_price=None):  # Use real price
        """Convert returns to price series"""
        price_multipliers = (1 + returns).cumprod()
        prices = initial_price * np.concatenate([[1], price_multipliers])
        return prices
    
    @staticmethod
    def get_market_data(symbols):
        return get_current_market_data(symbols)
    
    def _simulate_trading(self, prices, signals, transaction_cost=0.001):
        """Simulate trading with given signals"""
        cash = self.initial_capital
        shares = 0
        portfolio_values = []
        
        # Ensure signals and prices are aligned
        # Signals should be one less than prices (can't trade on last price)
        if len(signals) != len(prices) - 1:
            # Adjust signals length if needed
            if len(signals) > len(prices) - 1:
                signals = signals[:len(prices) - 1]
            else:
                # Pad with zeros if signals are too short
                signals = np.pad(signals, (0, len(prices) - 1 - len(signals)), 'constant')
        
        for i in range(len(prices)):
            # Current portfolio value
            portfolio_value = cash + shares * prices[i]
            portfolio_values.append(portfolio_value)
            
            # Only trade up to the second-to-last price
            if i < len(prices) - 1 and i < len(signals):
                signal = signals[i]
                
                if signal == 1 and shares == 0:  # Buy
                    # Buy with 95% of cash
                    investment = cash * 0.95
                    shares_to_buy = int(investment / prices[i])
                    cost = shares_to_buy * prices[i] * (1 + transaction_cost)
                    
                    if cost <= cash:
                        cash -= cost
                        shares += shares_to_buy
                        
                elif signal == -1 and shares > 0:  # Sell
                    proceeds = shares * prices[i] * (1 - transaction_cost)
                    cash += proceeds
                    shares = 0
        
        return portfolio_values
    
    def calculate_risk_metrics(self):
        """Calculate comprehensive risk metrics from simulation results"""
        if self.simulation_results is None:
            raise ValueError("No simulation results available")
        
        returns = self.simulation_results['returns']
        final_values = self.simulation_results['final_values']
        
        metrics = {}
            # Basic statistics
            'mean_return': np.mean(returns),
            'median_return': np.median(returns),
            'std_return': np.std(returns),
            'skewness': skew(returns),
            'kurtosis': kurtosis(returns),
            
            # Risk metrics
            'var_95': np.percentile(returns, 5),
            'var_99': np.percentile(returns, 1),
            'cvar_95': np.mean(returns[returns <= np.percentile(returns, 5)]),
            'cvar_99': np.mean(returns[returns <= np.percentile(returns, 1)]),
            
            # Probability metrics
            'prob_profit': np.mean(returns > 0),
            'prob_loss_10pct': np.mean(returns < -0.10),
            'prob_loss_20pct': np.mean(returns < -0.20),
            
            # Tail risk
            'worst_case': np.min(returns),
            'best_case': np.max(returns),
            'tail_ratio': abs(np.percentile(returns, 95) / np.percentile(returns, 5)),
            
            # Advanced metrics
            'sortino_ratio': self._calculate_sortino_ratio(returns),
            'calmar_ratio': self._calculate_calmar_ratio(returns),
            'omega_ratio': self._calculate_omega_ratio(returns),
            'gain_loss_ratio': self._calculate_gain_loss_ratio(returns)
        }
        
        return metrics
    
    def _calculate_sortino_ratio(self, returns, target_return=0):
        """Calculate Sortino ratio (downside deviation)"""
        excess_returns = returns - target_return
        downside_returns = excess_returns[excess_returns < 0]
        
        if len(downside_returns) == 0:
            return np.inf
        
        downside_deviation = np.std(downside_returns)
        
        if downside_deviation == 0:
            return np.inf
        
        return np.mean(excess_returns) / downside_deviation
    
    def _calculate_calmar_ratio(self, returns):
        """Calculate Calmar ratio (return / max drawdown)"""
        cumulative_returns = (1 + returns).cumprod()
        running_max = np.maximum.accumulate(cumulative_returns)
        drawdowns = (cumulative_returns - running_max) / running_max
        max_drawdown = np.min(drawdowns)
        
        if max_drawdown == 0:
            return np.inf
        
        annual_return = np.mean(returns) * 252
        return annual_return / abs(max_drawdown)
    
    def _calculate_omega_ratio(self, returns, threshold=0):
        """Calculate Omega ratio"""
        gains = returns[returns > threshold] - threshold
        losses = threshold - returns[returns <= threshold]
        
        if np.sum(losses) == 0:
            return np.inf
        
        return np.sum(gains) / np.sum(losses)
    
    def _calculate_gain_loss_ratio(self, returns):
        """Calculate average gain to average loss ratio"""
        gains = returns[returns > 0]
        losses = returns[returns < 0]
        
        if len(losses) == 0:
            return np.inf
        
        avg_gain = np.mean(gains) if len(gains) > 0 else 0
        avg_loss = np.mean(losses)
        
        return abs(avg_gain / avg_loss)
    
    def plot_simulation_results(self):
        """Create visualization of Monte Carlo results"""
        import matplotlib.pyplot as plt
        
        if self.simulation_results is None:
            raise ValueError("No simulation results available")
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # 1. Distribution of returns
        ax = axes[0, 0]
        returns = self.simulation_results['returns']
        ax.hist(returns, bins=50, density=True, alpha=0.7, color='blue', edgecolor='black')
        ax.axvline(np.mean(returns), color='red', linestyle='--', label=f'Mean: {np.mean(returns):.2%}')
        ax.axvline(np.percentile(returns, 5), color='orange', linestyle='--', label=f'VaR 95%: {np.percentile(returns, 5):.2%}')
        ax.set_xlabel('Returns')
        ax.set_ylabel('Density')
        ax.set_title('Distribution of Strategy Returns')
        ax.legend()
        
        # 2. Portfolio paths
        ax = axes[0, 1]
        portfolio_values = self.simulation_results['portfolio_values']
        # Plot subset of paths
        n_paths_to_plot = min(100, len(portfolio_values))
        indices = np.random.choice(len(portfolio_values), n_paths_to_plot, replace=False)
        
        for idx in indices:
            ax.plot(portfolio_values[idx], alpha=0.3, color='gray')
        
        # Plot percentiles
        percentiles = [5, 25, 50, 75, 95]
        colors = ['red', 'orange', 'green', 'orange', 'red']
        
        for pct, color in zip(percentiles, colors):
            pct_path = np.percentile(portfolio_values, pct, axis=0)
            ax.plot(pct_path, color=color, linewidth=2, label=f'{pct}th percentile')
        
        ax.set_xlabel('Time')
        ax.set_ylabel('Portfolio Value')
        ax.set_title('Monte Carlo Portfolio Paths')
        ax.legend()
        
        # 3. Risk-Return scatter
        ax = axes[1, 0]
        # Calculate rolling metrics for each scenario
        scenario_returns = []
        scenario_volatilities = []
        
        for pv in portfolio_values[:100]:  # Use subset for clarity
            daily_returns = np.diff(pv) / pv[:-1]
            scenario_returns.append(np.mean(daily_returns) * 252)
            scenario_volatilities.append(np.std(daily_returns) * np.sqrt(252))
        
        ax.scatter(scenario_volatilities, scenario_returns, alpha=0.5)
        ax.set_xlabel('Volatility (Annualized)')
        ax.set_ylabel('Return (Annualized)')
        ax.set_title('Risk-Return Profile of Scenarios')
        
        # 4. Cumulative distribution
        ax = axes[1, 1]
        sorted_returns = np.sort(returns)
        cumulative_prob = np.arange(1, len(sorted_returns) + 1) / len(sorted_returns)
        
        ax.plot(sorted_returns, cumulative_prob, linewidth=2)
        ax.axvline(0, color='black', linestyle='--', alpha=0.5)
        ax.axhline(0.05, color='red', linestyle='--', alpha=0.5, label='5% VaR')
        ax.axhline(0.01, color='orange', linestyle='--', alpha=0.5, label='1% VaR')
        ax.set_xlabel('Returns')
        ax.set_ylabel('Cumulative Probability')
        ax.set_title('Cumulative Distribution of Returns')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('monte_carlo_results.png', dpi=150, bbox_inches='tight')
        print("\n📊 Monte Carlo results plot saved to: monte_carlo_results.png")
        
    def stress_test_scenarios(self, historical_data, stress_scenarios):
        """
        Run specific stress test scenarios
        
        Args:
            historical_data: Historical price data
            stress_scenarios: Dict of stress scenarios with parameters
        """
        stress_results = {}
        
        for scenario_name, scenario_params in stress_scenarios.items():
            print(f"\n🔍 Running stress scenario: {scenario_name}")
            
            # Generate stressed returns
            if scenario_params['type'] == 'crash':
                # Market crash scenario
                magnitude = scenario_params['magnitude']
                duration = scenario_params['duration']
                
                stressed_returns = self._generate_crash_scenario()
                    historical_data['returns'].dropna(),
                    magnitude,
                    duration
                )
                
            elif scenario_params['type'] == 'volatility_spike':
                # Volatility spike scenario
                vol_multiplier = scenario_params['multiplier']
                
                stressed_returns = self._generate_volatility_spike()
                    historical_data['returns'].dropna(),
                    vol_multiplier
                )
                
            elif scenario_params['type'] == 'correlation_breakdown':
                # Correlation breakdown (for portfolio)
                stressed_returns = self._generate_correlation_breakdown()
                    historical_data['returns'].dropna()
                )
            
            # Run strategy on stressed scenario
            prices = self._returns_to_prices(stressed_returns, 100)
            
            # Simple momentum strategy for testing
            signals = self._simple_momentum_strategy(prices)
            
            portfolio = self._simulate_trading(prices, signals)
            
            final_return = (portfolio[-1] - self.initial_capital) / self.initial_capital
            max_drawdown = self._calculate_max_drawdown(portfolio)
            
            stress_results[scenario_name] = {}
                'final_return': final_return,
                'max_drawdown': max_drawdown,
                'survival': portfolio[-1] > 0,
                'portfolio_path': portfolio
            }
        
        return stress_results
    
    def _generate_crash_scenario(self, returns, magnitude, duration):
        """Generate market crash scenario"""
        n = len(returns)
        stressed_returns = returns.copy()
        
        # Random crash start
        crash_start = np.random.randint(n // 4, 3 * n // 4)
        
        # Generate crash returns
        crash_returns = np.random.normal(-magnitude / duration, 0.02, duration)
        
        # Insert crash
        if crash_start + duration < n:
            stressed_returns[crash_start:crash_start + duration] = crash_returns
        
        return stressed_returns
    
    def _generate_volatility_spike(self, returns, vol_multiplier):
        """Generate volatility spike scenario"""
        mean_return = returns.mean()
        base_vol = returns.std()
        
        # Increase volatility
        stressed_returns = np.random.normal(mean_return, base_vol * vol_multiplier, len(returns))
        
        return stressed_returns
    
    def _generate_correlation_breakdown(self, returns):
        """Generate correlation breakdown scenario"""
        # Add random shocks
        shocks = np.random.normal(0, returns.std() * 0.5, len(returns))
        stressed_returns = returns + shocks
        
        return stressed_returns
    
    def _simple_momentum_strategy(self, prices, lookback=20):
        """Simple momentum strategy for testing"""
        # Return signals that match price length minus 1 (for alignment)
        signals = np.zeros(len(prices) - 1)
        
        if len(prices) < lookback + 1:
            return signals
        
        for i in range(lookback, len(prices) - 1):
            momentum = (prices[i] - prices[i - lookback]) / prices[i - lookback]
            
            if momentum > 0.05:
                signals[i] = 1
            elif momentum < -0.05:
                signals[i] = -1
            else:
                signals[i] = signals[i-1] if i > 0 else 0
        
        return signals
    
    def _calculate_max_drawdown(self, portfolio_values):
        """Calculate maximum drawdown"""
        running_max = np.maximum.accumulate(portfolio_values)
        drawdowns = (portfolio_values - running_max) / running_max
        return np.min(drawdowns)


class MonteCarloDemo:
    """Demo class for Monte Carlo backtesting"""
    
    def __init__(self):
        self.backtester = MonteCarloBacktester()
        
    def run_demo(self):
        """Run comprehensive Monte Carlo demo"""
        print("="*80)
        print("🎲 MONTE CARLO BACKTESTING DEMO")
        print("="*80)
        
        # Generate synthetic data for demo
        np.random.seed(42)
        n_days = 1000
        
        # Generate realistic returns
        mean_return = 0.0005  # 0.05% daily
        volatility = 0.02     # 2% daily
        
        returns = np.random.normal(mean_return, volatility, n_days)
        
        # Add some autocorrelation
        for i in range(1, len(returns)):
            returns[i] = 0.1 * returns[i-1] + 0.9 * returns[i]
        
        # Create price series
        prices = 100 * np.exp(np.cumsum(returns))
        
        # Ensure arrays have the same length
        # prices has same length as returns, so we need to pad returns with initial 0
        padded_returns = np.concatenate([[0], returns])
        
        # Make sure both arrays have the same length
        min_length = min(len(prices), len(padded_returns))
        prices = prices[:min_length]
        padded_returns = padded_returns[:min_length]
        
        historical_data = pd.DataFrame({)
            'close': prices,
            'returns': padded_returns
        })
        
        print("\n📊 Historical Data Summary:")
        print(f"  Days: {len(historical_data)}")
        print(f"  Mean Daily Return: {returns.mean():.2%}")
        print(f"  Daily Volatility: {returns.std():.2%}")
        print(f"  Annualized Sharpe: {(returns.mean() / returns.std() * np.sqrt(252)):.2f}")
        
        # 1. Generate scenarios
        print("\n🎯 Generating Monte Carlo Scenarios...")
        
        methods = ['bootstrap', 'parametric', 'garch', 'regime_switching']
        all_scenarios = {}
        
        for method in methods:
            print(f"\n  Method: {method}")
            scenarios = self.backtester.generate_scenarios()
                historical_data,
                n_scenarios=1000,
                horizon_days=252,
                method=method
            )
            all_scenarios[method] = scenarios
            
            # Summary statistics
            scenario_means = [np.mean(s) for s in scenarios]
            scenario_stds = [np.std(s) for s in scenarios]
            
            print(f"    Mean of means: {np.mean(scenario_means):.4f}")
            print(f"    Mean of stds: {np.mean(scenario_stds):.4f}")
        
        # 2. Run strategy simulation
        print("\n💹 Running Strategy Simulations...")
        
        # Use bootstrap scenarios for main simulation
        scenarios = all_scenarios['bootstrap']
        
        # Define a simple momentum strategy
        def momentum_strategy(prices):
            signals = np.zeros(len(prices))
            lookback = 20
            
            for i in range(lookback, len(prices)):
                momentum = (prices[i] - prices[i-lookback]) / prices[i-lookback]
                
                if momentum > 0.05:
                    signals[i] = 1
                elif momentum < -0.05:
                    signals[i] = -1
                else:
                    signals[i] = signals[i-1] if i > 0 else 0
            
            return signals
        
        # Run simulation
        results = self.backtester.run_strategy_simulation()
            momentum_strategy,
            scenarios,
            transaction_cost=0.001
        )
        
        # 3. Calculate risk metrics
        print("\n📈 Risk Metrics:")
        metrics = self.backtester.calculate_risk_metrics()
        
        print(f"\n  Expected Return: {metrics['mean_return']:.2%}")
        print(f"  Median Return: {metrics['median_return']:.2%}")
        print(f"  Standard Deviation: {metrics['std_return']:.2%}")
        print(f"  Skewness: {metrics['skewness']:.2f}")
        print(f"  Kurtosis: {metrics['kurtosis']:.2f}")
        
        print(f"\n  💰 Value at Risk (VaR):")
        print(f"    95% VaR: {metrics['var_95']:.2%}")
        print(f"    99% VaR: {metrics['var_99']:.2%}")
        
        print(f"\n  📉 Conditional VaR (CVaR):")
        print(f"    95% CVaR: {metrics['cvar_95']:.2%}")
        print(f"    99% CVaR: {metrics['cvar_99']:.2%}")
        
        print(f"\n  📊 Probability Metrics:")
        print(f"    Probability of Profit: {metrics['prob_profit']:.1%}")
        print(f"    Probability of 10% Loss: {metrics['prob_loss_10pct']:.1%}")
        print(f"    Probability of 20% Loss: {metrics['prob_loss_20pct']:.1%}")
        
        print(f"\n  🎯 Advanced Ratios:")
        print(f"    Sortino Ratio: {metrics['sortino_ratio']:.2f}")
        print(f"    Calmar Ratio: {metrics['calmar_ratio']:.2f}")
        print(f"    Omega Ratio: {metrics['omega_ratio']:.2f}")
        print(f"    Gain/Loss Ratio: {metrics['gain_loss_ratio']:.2f}")
        
        # 4. Stress testing
        print("\n⚡ Stress Test Scenarios:")
        
        stress_scenarios = {}
            'Market Crash': {}
                'type': 'crash',
                'magnitude': 0.30,  # 30% crash
                'duration': 10      # Over 10 days
            },
            'Volatility Spike': {}
                'type': 'volatility_spike',
                'multiplier': 3.0   # 3x normal volatility
            },
            'Flash Crash': {}
                'type': 'crash',
                'magnitude': 0.10,  # 10% crash
                'duration': 1       # In 1 day
            }
        }
        
        stress_results = self.backtester.stress_test_scenarios()
            historical_data,
            stress_scenarios
        )
        
        for scenario_name, results in stress_results.items():
            print(f"\n  {scenario_name}:")
            print(f"    Final Return: {results['final_return']:.2%}")
            print(f"    Max Drawdown: {results['max_drawdown']:.2%}")
            print(f"    Survival: {'✅ Yes' if results['survival'] else '❌ No'}")
        
        # 5. Generate plots
        print("\n📊 Generating Visualizations...")
        self.backtester.plot_simulation_results()
        
        # 6. Summary and recommendations
        print("\n" + "="*80)
        print("📋 MONTE CARLO ANALYSIS SUMMARY")
        print("="*80)
        
        print("\n🎯 Key Findings:")
        print(f"  • Expected annual return: {metrics['mean_return'] * 252:.1%}")
        print(f"  • 95% confidence interval: [{metrics['var_95'] * 252:.1%}, {np.percentile(results['returns'], 95) * 252:.1%}]")
        print(f"  • Maximum expected loss (99% confidence): {metrics['var_99'] * 252:.1%}")
        print(f"  • Risk-adjusted performance (Sortino): {metrics['sortino_ratio']:.2f}")
        
        print("\n💡 Risk Management Recommendations:")
        print(f"  • Set stop-loss at: {metrics['var_95']:.1%} (based on 95% VaR)")
        print(f"  • Position sizing: Limit to {100 / (abs(metrics['var_99']) * 100):.0f}% of portfolio")
        print(f"  • Expected drawdown: Prepare for {metrics['worst_case']:.1%} in worst case")
        print(f"  • Stress test result: Strategy {'survives' if all(r['survival'] for r in stress_results.values()) else 'fails'} extreme scenarios")
        
        print("\n✅ Monte Carlo Backtesting Complete!")
        print("📁 Results saved to: monte_carlo_results.png")
        
        return {}
            'metrics': metrics,
            'scenarios': all_scenarios,
            'stress_results': stress_results
        }


def main():
    """Run the Monte Carlo demo"""
    demo = MonteCarloDemo()
    results = demo.run_demo()
    
    print("\n🚀 Next Steps:")
    print("  1. Integrate with actual trading strategies")
    print("  2. Add more sophisticated risk models")
    print("  3. Implement portfolio-level simulations")
    print("  4. Create real-time risk monitoring")
    print("  5. Add machine learning for scenario generation")


if __name__ == "__main__":
    main()
class MonteCarloBacktesting:
    """Stub implementation for MonteCarloBacktesting"""
    def __init__(self, *args, **kwargs):
        self.config = kwargs
        print(f"Initialized {self.__class__.__name__}")
    
    def run(self):
        print(f"Running {self.__class__.__name__}")
        return True

__all__ = ["MonteCarloBacktesting"]
