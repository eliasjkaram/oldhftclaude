#!/usr/bin/env python3
"""
OPTIONS PRICING & GREEKS CALCULATOR
===================================
Advanced options pricing with real-time Greeks calculation
and spread strategy optimization.
"""

import numpy as np
import pandas as pd
from scipy.stats import norm
from scipy.optimize import minimize_scalar, brentq
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import asyncio

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOptionContractsRequest
from alpaca.trading.enums import OrderSide, TimeInForce, AssetClass, ContractType
from alpaca.data.historical import StockHistoricalDataClient, OptionHistoricalDataClient
from alpaca.data.requests import StockLatestQuoteRequest, OptionLatestQuoteRequest, StockBarsRequest
from alpaca.data.timeframe import TimeFrame

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class OptionGreeks:
    """Complete option Greeks"""
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float
    lambda_: float  # Leverage
    charm: float   # Delta decay
    vanna: float   # Delta/vega sensitivity
    volga: float   # Vega convexity
    
@dataclass
class OptionPrice:
    """Option pricing result"""
    call_price: float
    put_price: float
    implied_volatility: float
    greeks: OptionGreeks

@dataclass
class SpreadStrategy:
    """Options spread strategy"""
    name: str
    legs: List[Dict]
    max_profit: float
    max_loss: float
    breakeven_points: List[float]
    probability_profit: float
    expected_value: float
    greeks: OptionGreeks

class OptionsPricingEngine:
    """Advanced options pricing and Greeks calculator"""
    
    def __init__(self):
        # API credentials
        self.api_key = os.getenv('ALPACA_API_KEY', 'PKEP9PIBDKOSUGHHY44Z')
        self.api_secret = os.getenv('ALPACA_API_SECRET', 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ')
        
        # Initialize clients
        self.trading_client = TradingClient(self.api_key, self.api_secret, paper=True)
        self.stock_data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        try:
            self.options_data_client = OptionHistoricalDataClient(self.api_key, self.api_secret)
            self.options_enabled = True
        except:
            logger.warning("Options data client not available")
            self.options_enabled = False
        
        # Market parameters
        self.risk_free_rate = 0.05  # 5% risk-free rate
        self.dividend_yield = 0.02  # 2% dividend yield
        
        logger.info("Options Pricing Engine initialized")
    
    def black_scholes(self, S: float, K: float, T: float, r: float, sigma: float, 
                     q: float = 0) -> Tuple[float, float]:
        """
        Black-Scholes option pricing
        S: Spot price
        K: Strike price
        T: Time to maturity
        r: Risk-free rate
        sigma: Volatility
        q: Dividend yield
        """
        d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        call_price = S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        put_price = K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)
        
        return call_price, put_price
    
    def calculate_greeks(self, S: float, K: float, T: float, r: float, sigma: float,
                        q: float = 0, option_type: str = 'call') -> OptionGreeks:
        """Calculate all option Greeks"""
        
        # Handle edge cases
        if T <= 0:
            T = 0.001  # 1 day
        if sigma <= 0:
            sigma = 0.001
        
        # Calculate d1 and d2
        d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        # Standard Greeks
        if option_type == 'call':
            delta = np.exp(-q * T) * norm.cdf(d1)
            theta = (-S * norm.pdf(d1) * sigma * np.exp(-q * T) / (2 * np.sqrt(T))
                    - r * K * np.exp(-r * T) * norm.cdf(d2)
                    + q * S * np.exp(-q * T) * norm.cdf(d1))
            rho = K * T * np.exp(-r * T) * norm.cdf(d2)
        else:  # put
            delta = -np.exp(-q * T) * norm.cdf(-d1)
            theta = (-S * norm.pdf(d1) * sigma * np.exp(-q * T) / (2 * np.sqrt(T))
                    + r * K * np.exp(-r * T) * norm.cdf(-d2)
                    - q * S * np.exp(-q * T) * norm.cdf(-d1))
            rho = -K * T * np.exp(-r * T) * norm.cdf(-d2)
        
        # Common Greeks
        gamma = norm.pdf(d1) * np.exp(-q * T) / (S * sigma * np.sqrt(T))
        vega = S * norm.pdf(d1) * np.exp(-q * T) * np.sqrt(T)
        
        # Advanced Greeks
        lambda_ = delta * S / self.black_scholes(S, K, T, r, sigma, q)[0 if option_type == 'call' else 1]
        
        # Charm (delta decay)
        charm = -np.exp(-q * T) * (norm.pdf(d1) * (2 * (r - q) * T - d2 * sigma * np.sqrt(T)) /)
                                   (2 * T * sigma * np.sqrt(T)))
        
        # Vanna (delta sensitivity to volatility)
        vanna = -np.exp(-q * T) * norm.pdf(d1) * d2 / sigma
        
        # Volga (vega convexity)
        volga = vega * d1 * d2 / sigma
        
        # Convert to daily theta
        theta = theta / 365
        
        # Convert vega and rho to percentage
        vega = vega / 100
        rho = rho / 100
        
        return OptionGreeks()
            delta=delta,
            gamma=gamma,
            theta=theta,
            vega=vega,
            rho=rho,
            lambda_=lambda_,
            charm=charm,
            vanna=vanna,
            volga=volga
        )
    
    def implied_volatility(self, option_price: float, S: float, K: float, T: float,
                          r: float, q: float = 0, option_type: str = 'call') -> float:
        """Calculate implied volatility using Newton-Raphson method"""
        
        # Define objective function
        def objective(sigma):
            theoretical = self.black_scholes(S, K, T, r, sigma, q)
            return theoretical[0 if option_type == 'call' else 1] - option_price
        
        # Initial guess
        sigma_init = 0.3
        
        try:
            # Use Brent's method for robustness
            iv = brentq(objective, 0.001, 5.0, maxiter=100)
            return iv
        except:
            # Fallback to simple approximation
            return sigma_init
    
    def calculate_spread_greeks(self, legs: List[Dict]) -> OptionGreeks:
        """Calculate net Greeks for a spread"""
        net_delta = 0
        net_gamma = 0
        net_theta = 0
        net_vega = 0
        net_rho = 0
        
        for leg in legs:
            greeks = leg['greeks']
            quantity = leg['quantity']
            side = 1 if leg['side'] == 'buy' else -1
            
            net_delta += greeks.delta * quantity * side
            net_gamma += greeks.gamma * quantity * side
            net_theta += greeks.theta * quantity * side
            net_vega += greeks.vega * quantity * side
            net_rho += greeks.rho * quantity * side
        
        return OptionGreeks()
            delta=net_delta,
            gamma=net_gamma,
            theta=net_theta,
            vega=net_vega,
            rho=net_rho,
            lambda_=0,  # Not meaningful for spreads
            charm=0,
            vanna=0,
            volga=0
        )
    
    def analyze_vertical_spread(self, S: float, K1: float, K2: float, T: float,
                               r: float, sigma: float, spread_type: str = 'bull_call') -> SpreadStrategy:
        """Analyze vertical spread strategies"""
        
        # Calculate individual option prices and Greeks
        call1, put1 = self.black_scholes(S, K1, T, r, sigma)
        call2, put2 = self.black_scholes(S, K2, T, r, sigma)
        
        greeks1 = self.calculate_greeks(S, K1, T, r, sigma, option_type='call' if 'call' in spread_type else 'put')
        greeks2 = self.calculate_greeks(S, K2, T, r, sigma, option_type='call' if 'call' in spread_type else 'put')
        
        if spread_type == 'bull_call':
            # Buy lower strike call, sell higher strike call
            legs = []
                {'type': 'call', 'strike': K1, 'side': 'buy', 'quantity': 1, 'price': call1, 'greeks': greeks1},
                {'type': 'call', 'strike': K2, 'side': 'sell', 'quantity': 1, 'price': call2, 'greeks': greeks2}
            ]
            net_debit = call1 - call2
            max_profit = K2 - K1 - net_debit
            max_loss = net_debit
            breakeven = K1 + net_debit
            
        elif spread_type == 'bear_put':
            # Buy higher strike put, sell lower strike put
            legs = []
                {'type': 'put', 'strike': K2, 'side': 'buy', 'quantity': 1, 'price': put2, 'greeks': greeks2},
                {'type': 'put', 'strike': K1, 'side': 'sell', 'quantity': 1, 'price': put1, 'greeks': greeks1}
            ]
            net_debit = put2 - put1
            max_profit = K2 - K1 - net_debit
            max_loss = net_debit
            breakeven = K2 - net_debit
        
        # Calculate probability of profit
        if spread_type == 'bull_call':
            prob_profit = 1 - norm.cdf((np.log(breakeven / S) - (r - 0.5 * sigma**2) * T) / (sigma * np.sqrt(T)))
        else:
            prob_profit = norm.cdf((np.log(breakeven / S) - (r - 0.5 * sigma**2) * T) / (sigma * np.sqrt(T)))
        
        # Expected value (simplified)
        expected_value = prob_profit * max_profit - (1 - prob_profit) * max_loss
        
        # Calculate spread Greeks
        spread_greeks = self.calculate_spread_greeks(legs)
        
        return SpreadStrategy()
            name=spread_type,
            legs=legs,
            max_profit=max_profit,
            max_loss=max_loss,
            breakeven_points=[breakeven],
            probability_profit=prob_profit,
            expected_value=expected_value,
            greeks=spread_greeks
        )
    
    def analyze_iron_condor(self, S: float, K1: float, K2: float, K3: float, K4: float,
                           T: float, r: float, sigma: float) -> SpreadStrategy:
        """Analyze iron condor strategy"""
        
        # Calculate all option prices
        put1 = self.black_scholes(S, K1, T, r, sigma)[1]
        put2 = self.black_scholes(S, K2, T, r, sigma)[1]
        call3 = self.black_scholes(S, K3, T, r, sigma)[0]
        call4 = self.black_scholes(S, K4, T, r, sigma)[0]
        
        # Calculate Greeks
        greeks_p1 = self.calculate_greeks(S, K1, T, r, sigma, option_type='put')
        greeks_p2 = self.calculate_greeks(S, K2, T, r, sigma, option_type='put')
        greeks_c3 = self.calculate_greeks(S, K3, T, r, sigma, option_type='call')
        greeks_c4 = self.calculate_greeks(S, K4, T, r, sigma, option_type='call')
        
        # Iron condor legs
        legs = []
            {'type': 'put', 'strike': K1, 'side': 'buy', 'quantity': 1, 'price': put1, 'greeks': greeks_p1},
            {'type': 'put', 'strike': K2, 'side': 'sell', 'quantity': 1, 'price': put2, 'greeks': greeks_p2},
            {'type': 'call', 'strike': K3, 'side': 'sell', 'quantity': 1, 'price': call3, 'greeks': greeks_c3},
            {'type': 'call', 'strike': K4, 'side': 'buy', 'quantity': 1, 'price': call4, 'greeks': greeks_c4}
        ]
        
        # Calculate P&L
        net_credit = put2 - put1 + call3 - call4
        max_profit = net_credit
        max_loss = min(K2 - K1, K4 - K3) - net_credit
        
        # Breakeven points
        breakeven_low = K2 - net_credit
        breakeven_high = K3 + net_credit
        
        # Probability of profit (between breakevens)
        d_low = (np.log(breakeven_low / S) - (r - 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d_high = (np.log(breakeven_high / S) - (r - 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        prob_profit = norm.cdf(d_high) - norm.cdf(d_low)
        
        # Expected value
        expected_value = prob_profit * max_profit - (1 - prob_profit) * max_loss
        
        # Calculate spread Greeks
        spread_greeks = self.calculate_spread_greeks(legs)
        
        return SpreadStrategy()
            name='iron_condor',
            legs=legs,
            max_profit=max_profit,
            max_loss=max_loss,
            breakeven_points=[breakeven_low, breakeven_high],
            probability_profit=prob_profit,
            expected_value=expected_value,
            greeks=spread_greeks
        )
    
    def optimize_spread_selection(self, S: float, volatility: float, 
                                 market_outlook: str = 'neutral') -> List[SpreadStrategy]:
        """Optimize spread selection based on market conditions"""
        
        strategies = []
        T = 30 / 365  # 30 days to expiration
        
        if market_outlook == 'bullish':
            # Bull call spread
            K1 = S * 0.98  # 2% OTM
            K2 = S * 1.02  # 2% ITM
            strategies.append(self.analyze_vertical_spread(S, K1, K2, T, self.risk_free_rate, volatility, 'bull_call'))
            
            # Call debit spread
            K1 = S
            K2 = S * 1.05
            strategies.append(self.analyze_vertical_spread(S, K1, K2, T, self.risk_free_rate, volatility, 'bull_call'))
            
        elif market_outlook == 'bearish':
            # Bear put spread
            K1 = S * 0.98
            K2 = S * 1.02
            strategies.append(self.analyze_vertical_spread(S, K1, K2, T, self.risk_free_rate, volatility, 'bear_put'))
            
        else:  # neutral
            # Iron condor
            K1 = S * 0.90
            K2 = S * 0.95
            K3 = S * 1.05
            K4 = S * 1.10
            strategies.append(self.analyze_iron_condor(S, K1, K2, K3, K4, T, self.risk_free_rate, volatility))
            
            # Butterfly
            K1 = S * 0.95
            K2 = S
            K3 = S * 1.05
            # Simplified butterfly analysis
            
        # Sort by expected value
        strategies.sort(key=lambda x: x.expected_value, reverse=True)
        
        return strategies
    
    async def real_time_options_analysis(self):
        """Real-time options analysis and trading"""
        
        symbols = ['SPY', 'QQQ', 'AAPL', 'TSLA', 'NVDA']
        
        while True:
            try:
                os.system('clear' if os.name != 'nt' else 'cls')
                
                print("=" * 120)
                print("📊 REAL-TIME OPTIONS PRICING & GREEKS")
                print("=" * 120)
                print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print("=" * 120)
                
                for symbol in symbols:
                    try:
                        # Get current stock price
                        request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
                        quotes = self.stock_data_client.get_stock_latest_quote(request)
                        current_price = float(quotes[symbol].ask_price)
                        
                        # Get historical volatility
                        bars_request = StockBarsRequest()
                            symbol_or_symbols=symbol,
                            timeframe=TimeFrame.Day,
                            start=datetime.now() - timedelta(days=30)
                        )
                        bars = self.stock_data_client.get_stock_bars(bars_request)
                        
                        # Calculate historical volatility
                        prices = [bar.close for bar in bars[symbol]]
                        returns = np.diff(np.log(prices))
                        hist_vol = np.std(returns) * np.sqrt(252)
                        
                        print(f"\n🎯 {symbol}")
                        print(f"Current Price: ${current_price:.2f}")
                        print(f"Historical Volatility: {hist_vol:.1%}")
                        
                        # Calculate ATM option pricing
                        strike = round(current_price)
                        T = 30 / 365  # 30 days
                        
                        call_price, put_price = self.black_scholes()
                            current_price, strike, T, self.risk_free_rate, hist_vol
                        )
                        
                        print(f"\nATM Options (Strike: ${strike}):")
                        print(f"  Call: ${call_price:.2f}")
                        print(f"  Put: ${put_price:.2f}")
                        
                        # Calculate Greeks
                        call_greeks = self.calculate_greeks()
                            current_price, strike, T, self.risk_free_rate, hist_vol, option_type='call'
                        )
                        
                        print(f"\nGreeks (ATM Call):")
                        print(f"  Delta: {call_greeks.delta:.3f}")
                        print(f"  Gamma: {call_greeks.gamma:.3f}")
                        print(f"  Theta: ${call_greeks.theta:.2f}/day")
                        print(f"  Vega: ${call_greeks.vega:.2f}")
                        print(f"  Rho: ${call_greeks.rho:.2f}")
                        
                        # Recommend strategies
                        print(f"\n📈 Recommended Strategies:")
                        
                        # Determine market outlook based on recent performance
                        recent_return = (prices[-1] - prices[-5]) / prices[-5]
                        if recent_return > 0.02:
                            outlook = 'bullish'
                        elif recent_return < -0.02:
                            outlook = 'bearish'
                        else:
                            outlook = 'neutral'
                        
                        strategies = self.optimize_spread_selection(current_price, hist_vol, outlook)
                        
                        for i, strategy in enumerate(strategies[:2]):
                            print(f"\n{i+1}. {strategy.name.upper()}")
                            print(f"   Max Profit: ${strategy.max_profit:.2f}")
                            print(f"   Max Loss: ${strategy.max_loss:.2f}")
                            print(f"   Probability: {strategy.probability_profit:.1%}")
                            print(f"   Expected Value: ${strategy.expected_value:.2f}")
                            print(f"   Net Delta: {strategy.greeks.delta:.3f}")
                            print(f"   Net Theta: ${strategy.greeks.theta:.2f}/day")
                        
                    except Exception as e:
                        logger.error(f"Error analyzing {symbol}: {e}")
                
                print(f"\n{'=' * 120}")
                print("Refreshing in 30 seconds... (Press Ctrl+C to stop)")
                
                await asyncio.sleep(30)
                
            except KeyboardInterrupt:
                print("\n\nStopping options analysis...")
                break
            except Exception as e:
                logger.error(f"Main loop error: {e}")
                await asyncio.sleep(60)

async def main():
    """Main entry point"""
    print("=" * 120)
    print("🎯 OPTIONS PRICING & GREEKS CALCULATOR")
    print("=" * 120)
    print("\nFeatures:")
    print("  ✅ Black-Scholes pricing model")
    print("  ✅ Complete Greeks calculation (including advanced Greeks)")
    print("  ✅ Implied volatility calculation")
    print("  ✅ Spread strategy analysis")
    print("  ✅ Probability calculations")
    print("  ✅ Real-time market integration")
    print("  ✅ Strategy optimization")
    
    engine = OptionsPricingEngine()
    await engine.real_time_options_analysis()

if __name__ == "__main__":
    import os
    asyncio.run(main())