#!/usr/bin/env python3
"""Fix component initialization issues"""

import os

# Fix 1: UnifiedLogger - needs to accept name parameter
unified_logger_fix = '''    def __new__(cls, name="default"):
        """Singleton pattern with name parameter"""
        if not hasattr(cls, '_instances'):
            cls._instances = {}
        if name not in cls._instances:
            instance = super(UnifiedLogger, cls).__new__(cls)
            cls._instances[name] = instance
        return cls._instances[name]'''

with open('/home/harry/unified_logging.py', 'r') as f:
    content = f.read()

# Find and replace the __new__ method
import re
pattern = r'def __new__\(cls\):[^}]+?return cls\._instance'
if re.search(pattern, content, re.DOTALL):
    content = re.sub(pattern, unified_logger_fix.strip(), content, flags=re.DOTALL)
else:
    # If pattern not found, look for simpler pattern
    pattern = r'def __new__\(cls\):\s*"""[^"]*"""\s*if[^}]+?return[^}]+?_instance'
    content = re.sub(pattern, unified_logger_fix.strip(), content, flags=re.DOTALL)

with open('/home/harry/unified_logging.py', 'w') as f:
    f.write(content)
print("Fixed UnifiedLogger")

# Fix 2: HealthCheckSystem - should accept config dict
health_check_fix = '''    def __init__(self, config: Dict[str, Any] = None):
        """Initialize health check system with optional config"""
        self.config = config or {}'''

with open('/home/harry/health_check_system.py', 'r') as f:
    content = f.read()

# Replace __init__ method
pattern = r'def __init__\(self\):\s*"""[^"]*"""'
replacement = health_check_fix.strip()
content = re.sub(pattern, replacement, content)

with open('/home/harry/health_check_system.py', 'w') as f:
    f.write(content)
print("Fixed HealthCheckSystem")

# Fix 3: ConfigurationManager - needs to accept config parameter
config_manager_fix = '''    def __new__(cls, config: Dict[str, Any] = None):
        """Singleton pattern with config parameter"""
        if not hasattr(cls, '_instance'):
            cls._instance = super(ConfigurationManager, cls).__new__(cls)
        return cls._instance'''

with open('/home/harry/configuration_manager.py', 'r') as f:
    content = f.read()

# Replace __new__ method
pattern = r'def __new__\(cls\):[^}]+?return cls\._instance'
content = re.sub(pattern, config_manager_fix.strip(), content, flags=re.DOTALL)

with open('/home/harry/configuration_manager.py', 'w') as f:
    f.write(content)
print("Fixed ConfigurationManager")

# Fix 4: Fix various __init__ methods that need config parameter
components_to_fix = {}
    'option_execution_engine.py': 'OptionExecutionEngine',
    'smart_order_routing.py': 'SmartOrderRouter',
    'position_management_system.py': 'PositionManager',
    'automated_backup_recovery.py': 'BackupRecoverySystem',
    'low_latency_inference_endpoint.py': 'LowLatencyInferenceEndpoint'
}

for filename, class_name in components_to_fix.items():
    filepath = f'/home/harry/{filename}'
    if os.path.exists(filepath):
        with open(filepath, 'r') as f:
            content = f.read()
        
        # Add config=None to __init__ if not present
        pattern = rf'def __init__\(self(?:,\s*config[^)]*)?'
        if 'def __init__(self, config' not in content:
            # Find the __init__ method and add config parameter
            pattern = r'(def __init__\(self)((?:,\s*[^)]+)?)\):'
            replacement = r'\1, config=None\2):'
            content = re.sub(pattern, replacement, content)
            
            # Also ensure config is used
            if 'self.config = config' not in content:
                pattern = r'(def __init__[^:]+:\s*(?:"""[^"]*"""\s*)?)'
                replacement = r'\1\n        self.config = config or {}'
                content = re.sub(pattern, replacement, content)
        
        with open(filepath, 'w') as f:
            f.write(content)
        print(f"Fixed {filename}")

# Fix 5: KubernetesDeployment export
k8s_fix = '''
# Export main class
KubernetesDeployment = KubernetesDeploymentConfig
'''

with open('/home/harry/kubernetes_deployment_configs.py', 'a') as f:
    f.write(k8s_fix)
print("Fixed KubernetesDeployment export")

# Fix 6: Fix cache file issue in low_latency_inference_endpoint
with open('/home/harry/low_latency_inference_endpoint.py', 'r') as f:
    content = f.read()

# Fix the cache initialization to handle None model_path
pattern = r'self\.cache = MemoryMappedCache\(\s*f"{model_path}\.cache",')
replacement = '''self.cache = MemoryMappedCache()
            f"{model_path or 'model'}.cache",'''
content = re.sub(pattern, replacement, content)

with open('/home/harry/low_latency_inference_endpoint.py', 'w') as f:
    f.write(content)
print("Fixed low_latency cache file issue")

print("\nAll component initialization issues fixed!")