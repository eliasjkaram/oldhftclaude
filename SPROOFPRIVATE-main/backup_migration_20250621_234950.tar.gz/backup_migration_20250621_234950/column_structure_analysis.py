#!/usr/bin/env python3
"""
Column Structure Analysis for Stock and Options Data

This script analyzes the actual column structure from sample files
and provides exact column mappings needed for preprocessing.
"""

import pandas as pd
import os

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


def analyze_column_structures():
    """Analyze the actual column structures from sample files"""
    
    print("📊 COLUMN STRUCTURE ANALYSIS")
    print("=" * 60)
    
    # 1. STOCK DATA ANALYSIS
    print("\n🏢 STOCK DATA STRUCTURE ANALYSIS")
    print("-" * 40)
    
    stock_files = []
        "/home/harry/alpaca-mcp/minio_cache/2022-08-24stocks.csv",
        "/home/harry/alpaca-mcp/minio_cache/multi_year/2009-01-02stocks.csv"
    ]
    
    for file_path in stock_files:
        if os.path.exists(file_path):
            df = pd.read_csv(file_path, nrows=5)
            print(f"\nFile: {file_path.split('/')[-1]}")
            print(f"Columns: {list(df.columns)}")
            print(f"Sample data:")
            print(df.head(2).to_string()
            print()
    
    # 2. OPTIONS DATA ANALYSIS
    print("\n📈 OPTIONS DATA STRUCTURE ANALYSIS")
    print("-" * 40)
    
    options_files = []
        "/home/harry/alpaca-mcp/minio_cache/2008-01-02options.csv",
        "/home/harry/alpaca-mcp/minio_cache/options_sample.csv",
        "/home/harry/alpaca-mcp/sample_2023_options-complete_2023-01-03options.csv"
    ]
    
    for file_path in options_files:
        if os.path.exists(file_path):
            df = pd.read_csv(file_path, nrows=5)
            print(f"\nFile: {file_path.split('/')[-1]}")
            print(f"Columns: {list(df.columns)}")
            print(f"Sample data:")
            print(df.head(2).to_string()
            print()
    
    # 3. COLUMN MAPPING ANALYSIS
    print("\n🔄 COLUMN MAPPING REQUIREMENTS")
    print("-" * 40)
    
    print("\n📋 STOCK DATA COLUMN MAPPING:")
    stock_actual_columns = ['symbol', 'open', 'high', 'low', 'close', 'volume', 'adjust_close']
    stock_expected_columns = ['date', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'adj_close']
    
    print("Actual columns in files:", stock_actual_columns)
    print("Expected columns in schema:", stock_expected_columns)
    print("\n🔧 Required mappings:")
    print("- 'adjust_close' → 'adj_close' (column name standardization)")
    print("- 'date' column missing (needs to be added from filename)")
    
    print("\n📋 OPTIONS DATA COLUMN MAPPING:")
    options_actual_columns = ['contract', 'underlying', 'expiration', 'type', 'strike', 'style', 'bid', 'bid_size', 'ask', 'ask_size', 'volume', 'open_interest', 'quote_date', 'delta', 'gamma', 'theta', 'vega', 'implied_volatility']
    options_expected_columns = ['date', 'underlying', 'contract', 'expiration', 'type', 'strike', 'style', 'bid', 'bid_size', 'ask', 'ask_size', 'volume', 'open_interest', 'delta', 'gamma', 'theta', 'vega', 'implied_volatility']
    
    print("Actual columns in files:", options_actual_columns)
    print("Expected columns in schema:", options_expected_columns)
    print("\n🔧 Required mappings:")
    print("- 'quote_date' → 'date' (main date field mapping)")
    print("- All other columns match expected schema")
    
    # 4. DATE COLUMN ANALYSIS
    print("\n📅 DATE COLUMN ANALYSIS")
    print("-" * 40)
    print("STOCK FILES:")
    print("- NO date column in CSV files")
    print("- Date must be extracted from filename pattern (e.g., '2022-08-24stocks.csv' → '2022-08-24')")
    print("- Date format in filenames: YYYY-MM-DD")
    
    print("\nOPTIONS FILES:")
    print("- Date column exists as 'quote_date'")
    print("- Format: YYYY-MM-DD (e.g., '2008-01-02', '2023-01-03')")
    print("- Should be mapped to 'date' field in processing")
    
    # 5. PREPROCESSING FIXES NEEDED
    print("\n🛠️  PREPROCESSING FIXES NEEDED")
    print("-" * 40)
    
    print("1. STOCK DATA PREPROCESSING:")
    print("   - Extract date from filename pattern")
    print("   - Map 'adjust_close' → 'adj_close'")
    print("   - Add date column before processing")
    
    print("\n2. OPTIONS DATA PREPROCESSING:")
    print("   - Map 'quote_date' → 'date'")
    print("   - Ensure all expected columns are present")
    print("   - Handle missing Greek values (delta, gamma, theta, vega)")
    
    print("\n3. UNIFIED DATABASE SCHEMA:")
    print("   - Stock table expects: date, symbol, open, high, low, close, volume, adj_close")
    print("   - Options table expects: date, underlying, contract, expiration, type, strike, etc.")
    print("   - Both tables require 'date' as primary key component")
    
    return {}
        'stock_columns': {}
            'actual': stock_actual_columns,
            'expected': stock_expected_columns,
            'mappings': {'adjust_close': 'adj_close'},
            'missing': ['date']
        },
        'options_columns': {}
            'actual': options_actual_columns,
            'expected': options_expected_columns,
            'mappings': {'quote_date': 'date'},
            'missing': []
        }
    }

if __name__ == "__main__":
    analysis = analyze_column_structures()
    
    print("\n✅ ANALYSIS COMPLETE")
    print("=" * 60)
    print("Column mapping requirements identified.")
    print("Use this analysis to fix preprocessing scripts.")