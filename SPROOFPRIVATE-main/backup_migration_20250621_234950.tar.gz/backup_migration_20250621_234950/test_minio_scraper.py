#!/usr/bin/env python3
"""
Test script for the MinIO Web Browser Interface Scraper
"""

from web_minio_scraper import MinIOWebScraper
import sys

def main():
    print("Testing MinIO Web Scraper...")
    print("="*50)
    
    # Initialize scraper with the target URL
    scraper = MinIOWebScraper("https://uschristmas.us/browser/stockdb")
    
    try:
        # Perform the scraping
        print("Starting scrape operation...")
        inventory = scraper.scrape_minio()
        
        # Print results
        scraper.print_summary()
        
        # Save results
        scraper.save_inventory("minio_inventory_stockdb.json")
        
        print("\nScraping completed successfully!")
        print(f"Results saved to: minio_inventory_stockdb.json")
        print(f"Detailed report saved to: minio_detailed_report.txt")
        
        return True
        
    except Exception as e:
        print(f"Error during scraping: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)