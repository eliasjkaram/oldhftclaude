
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Demo: Historical Backtesting vs Live Trading
Shows the same strategies running on historical data and live data
"""

# Alpaca imports
from typing import Dict, List, Optional, Tuple
import sys
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import sqlite3
import pandas as pd

# Alpaca imports

# Custom paper trading
from custom_paper_trading_system import ()
    CustomPaperTradingAccount, Order, OrderSide, OrderType, AssetType
)

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class HistoricalVsLiveDemo:
    def __init__(self):
        """Initialize demo system"""
        # Alpaca credentials
        self.api_key = os.getenv("ALPACA_PAPER_API_KEY")
        self.secret_key = os.getenv("ALPACA_PAPER_API_SECRET")
        
        # Initialize client
        self.data_client = StockHistoricalDataClient(self.api_key, self.secret_key)
        
        # Create accounts
        self.historical_account = CustomPaperTradingAccount()
            initial_balance=100000,
            db_path="self.get_production_config()
        )
        
        # Focus on a few symbols
        self.symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'TSLA']
        
        # Data storage
        self.historical_data = {}
        self.live_data = {}
        
    async def run_demo(self):
        """Run the demonstration"""
        logger.info("🎯 HISTORICAL VS LIVE TRADING DEMO")
        logger.info("=" * 60)
        
        # Part 1: Historical Backtest
        logger.info("\n📚 PART 1: HISTORICAL BACKTEST (Last 10 Days)")
        logger.info("-" * 60)
        await self.run_historical_backtest()
        
        # Part 2: Live Trading
        logger.info("\n🔴 PART 2: LIVE TRADING (Next 2 Minutes)")
        logger.info("-" * 60)
        await self.run_live_trading()
        
        # Part 3: Compare Results
        logger.info("\n📊 PART 3: COMPARISON")
        logger.info("-" * 60)
        await self.compare_results()
        
    async def run_historical_backtest(self):
        """Run backtest on historical data"""
        # Load historical data
        end_date = datetime.now()
        start_date = end_date - timedelta(days=10)
        
        logger.info(f"Loading data from {start_date.date()} to {end_date.date()}")
        
        try:
            request = StockBarsRequest()
                symbol_or_symbols=self.symbols,
                timeframe=TimeFrame.Hour,
                start=start_date,
                end=end_date
            )
            
            bars_data = self.data_client.get_stock_bars(request)
            
            # Process historical data
            for symbol in self.symbols:
                if symbol in bars_data.data:
                    bars = bars_data.data[symbol]
                    self.historical_data[symbol] = {}
                        'prices': [bar.close for bar in bars],
                        'volumes': [bar.volume for bar in bars],
                        'timestamps': [bar.timestamp for bar in bars]
                    }
                    
            # Simulate trading
            trade_count = 0
            for i in range(20, len(bars)):  # Need 20 bars for indicators
                # Update current prices
                for symbol in self.symbols:
                    if symbol in self.historical_data:
                        self.historical_data[symbol]['current_price'] = self.historical_data[symbol]['prices'][i]
                        self.historical_data[symbol]['current_index'] = i
                        
                # Simple moving average strategy
                for symbol in self.symbols:
                    if symbol in self.historical_data:
                        prices = self.historical_data[symbol]['prices'][:i+1]
                        current_price = prices[-1]
                        sma20 = np.mean(prices[-20:])
                        
                        # Buy signal
                        if current_price < sma20 * 0.98 and symbol not in self.historical_account.positions:
                            # Buy with 20% of available cash
                            position_size = self.historical_account.cash_balance * 0.2
                            quantity = int(position_size / current_price)
                            
                            if quantity > 0:
                                order = Order()
                                    order_id="",
                                    symbol=symbol,
                                    asset_type=AssetType.STOCK,
                                    side=OrderSide.BUY,
                                    order_type=OrderType.MARKET,
                                    quantity=quantity
                                )
                                
                                order_id = self.historical_account.submit_order(order)
                                if order_id:
                                    self.historical_account.execute_order(order_id, current_price)
                                    trade_count += 1
                                    timestamp = self.historical_data[symbol]['timestamps'][i]
                                    logger.info(f"[HIST] {timestamp.strftime('%m/%d %H:%M')}: BUY {quantity} {symbol} @ ${current_price:.2f}")
                                    
                        # Sell signal
                        elif current_price > sma20 * 1.02 and symbol in self.historical_account.positions:
                            position = self.historical_account.positions[symbol]
                            
                            order = Order()
                                order_id="",
                                symbol=symbol,
                                asset_type=AssetType.STOCK,
                                side=OrderSide.SELL,
                                order_type=OrderType.MARKET,
                                quantity=position.quantity
                            )
                            
                            order_id = self.historical_account.submit_order(order)
                            if order_id:
                                self.historical_account.execute_order(order_id, current_price)
                                trade_count += 1
                                pnl = (current_price - position.entry_price) * position.quantity
                                timestamp = self.historical_data[symbol]['timestamps'][i]
                                logger.info(f"[HIST] {timestamp.strftime('%m/%d %H:%M')}: SELL {position.quantity} {symbol} @ ${current_price:.2f} (P&L: ${pnl:.2f})")
                                
                # Update market prices
                price_updates = {symbol: data['current_price'] 
                               for symbol, data in self.historical_data.items()}
                self.historical_account.update_market_prices(price_updates)
                
            # Show results
            summary = self.historical_account.get_portfolio_summary()
            logger.info(f"\n📊 Historical Backtest Results:")
            logger.info(f"   Total Trades: {trade_count}")
            logger.info(f"   Final Value: ${summary['total_value']:,.2f}")
            logger.info(f"   P&L: ${summary['total_pnl']:,.2f}")
            logger.info(f"   Return: {summary['return_pct']:.2f}%")
            
        except Exception as e:
            logger.error(f"Historical backtest error: {e}")
            
    async def run_live_trading(self):
        """Run live trading simulation"""
        start_time = datetime.now()
        duration = timedelta(minutes=2)
        trade_count = 0
        
        while datetime.now() - start_time < duration:
            try:
                # Get live quotes
                request = StockLatestQuoteRequest(symbol_or_symbols=self.symbols)
                quotes = self.data_client.get_stock_latest_quote(request)
                
                # Update live data
                for symbol, quote in quotes.items():
                    if symbol not in self.live_data:
                        self.live_data[symbol] = {'prices': [], 'sma20': 0}
                        
                    # Calculate mid price
                    mid_price = (float(quote.bid_price) + float(quote.ask_price)) / 2
                    self.live_data[symbol]['current_price'] = mid_price
                    self.live_data[symbol]['bid'] = float(quote.bid_price)
                    self.live_data[symbol]['ask'] = float(quote.ask_price)
                    self.live_data[symbol]['prices'].append(mid_price)
                    
                    # Keep last 20 prices
                    if len(self.live_data[symbol]['prices']) > 20:
                        self.live_data[symbol]['prices'].pop(0)
                        self.live_data[symbol]['sma20'] = np.mean(self.live_data[symbol]['prices'])
                        
                # Trading logic (same as historical)
                for symbol in self.symbols:
                    if symbol in self.live_data and len(self.live_data[symbol]['prices']) >= 20:
                        current_price = self.live_data[symbol]['current_price']
                        sma20 = self.live_data[symbol]['sma20']
                        
                        if sma20 > 0:  # Ensure we have SMA
                            # Buy signal
                            if current_price < sma20 * 0.98 and symbol not in self.live_account.positions:
                                position_size = self.live_account.cash_balance * 0.2
                                quantity = int(position_size / current_price)
                                
                                if quantity > 0:
                                    order = Order()
                                        order_id="",
                                        symbol=symbol,
                                        asset_type=AssetType.STOCK,
                                        side=OrderSide.BUY,
                                        order_type=OrderType.MARKET,
                                        quantity=quantity
                                    )
                                    
                                    order_id = self.live_account.submit_order(order)
                                    if order_id:
                                        # Use ask price for buys
                                        self.live_account.execute_order(order_id, self.live_data[symbol]['ask'])
                                        trade_count += 1
                                        logger.info(f"[LIVE] {datetime.now().strftime('%H:%M:%S')}: BUY {quantity} {symbol} @ ${self.live_data[symbol]['ask']:.2f}")
                                        
                            # Sell signal
                            elif current_price > sma20 * 1.02 and symbol in self.live_account.positions:
                                position = self.live_account.positions[symbol]
                                
                                order = Order()
                                    order_id="",
                                    symbol=symbol,
                                    asset_type=AssetType.STOCK,
                                    side=OrderSide.SELL,
                                    order_type=OrderType.MARKET,
                                    quantity=position.quantity
                                )
                                
                                order_id = self.live_account.submit_order(order)
                                if order_id:
                                    # Use bid price for sells
                                    self.live_account.execute_order(order_id, self.live_data[symbol]['bid'])
                                    trade_count += 1
                                    pnl = (self.live_data[symbol]['bid'] - position.entry_price) * position.quantity
                                    logger.info(f"[LIVE] {datetime.now().strftime('%H:%M:%S')}: SELL {position.quantity} {symbol} @ ${self.live_data[symbol]['bid']:.2f} (P&L: ${pnl:.2f})")
                                    
                # Update positions
                price_updates = {symbol: data['current_price'] 
                               for symbol, data in self.live_data.items()
                               if symbol in self.live_account.positions}
                
                if price_updates:
                    self.live_account.update_market_prices(price_updates)
                    
                # Status update
                elapsed = datetime.now() - start_time
                remaining = duration - elapsed
                logger.info(f"⏱️  Live trading... {remaining.seconds} seconds remaining")
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Live trading error: {e}")
                await asyncio.sleep(10)
                
        # Show results
        summary = self.live_account.get_portfolio_summary()
        logger.info(f"\n📊 Live Trading Results:")
        logger.info(f"   Total Trades: {trade_count}")
        logger.info(f"   Final Value: ${summary['total_value']:,.2f}")
        logger.info(f"   P&L: ${summary['total_pnl']:,.2f}")
        logger.info(f"   Return: {summary['return_pct']:.2f}%")
        
    async def compare_results(self):
        """Compare historical vs live results"""
        hist_summary = self.historical_account.get_portfolio_summary()
        live_summary = self.live_account.get_portfolio_summary()
        
        logger.info("\n📊 PERFORMANCE COMPARISON")
        logger.info("=" * 60)
        logger.info(f"{'Metric':<20} {'Historical':>15} {'Live':>15}")
        logger.info("-" * 50)
        logger.info(f"{'Initial Capital':<20} ${100000:>14,.2f} ${100000:>14,.2f}")
        logger.info(f"{'Final Value':<20} ${hist_summary['total_value']:>14,.2f} ${live_summary['total_value']:>14,.2f}")
        logger.info(f"{'Total P&L':<20} ${hist_summary['total_pnl']:>14,.2f} ${live_summary['total_pnl']:>14,.2f}")
        logger.info(f"{'Return %':<20} {hist_summary['return_pct']:>14.2f}% {live_summary['return_pct']:>14.2f}%")
        logger.info(f"{'Win Rate':<20} {hist_summary['win_rate']:>14.1f}% {live_summary['win_rate']:>14.1f}%")
        logger.info(f"{'Total Trades':<20} {hist_summary['win_count'] + hist_summary['loss_count']:>15} {live_summary['win_count'] + live_summary['loss_count']:>15}")
        logger.info(f"{'Open Positions':<20} {hist_summary['position_count']:>15} {live_summary['position_count']:>15}")
        logger.info("=" * 60)
        
        # Show positions
        if hist_summary['positions']:
            logger.info("\n📈 Historical Positions:")
            for symbol, pos in hist_summary['positions'].items():
                logger.info(f"   {symbol}: {pos['quantity']} shares | P&L: ${pos['unrealized_pnl']:.2f}")
                
        if live_summary['positions']:
            logger.info("\n🔴 Live Positions:")
            for symbol, pos in live_summary['positions'].items():
                logger.info(f"   {symbol}: {pos['quantity']} shares | P&L: ${pos['unrealized_pnl']:.2f}")

async def main():
    """Main entry point"""
    demo = HistoricalVsLiveDemo()
    
    try:
        await demo.run_demo()
    except KeyboardInterrupt:
        logger.info("\n⏹️ Demo stopped by user")
        
if __name__ == "__main__":
    asyncio.run(main())