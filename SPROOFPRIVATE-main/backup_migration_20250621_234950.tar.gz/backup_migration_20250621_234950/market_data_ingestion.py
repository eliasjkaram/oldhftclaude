#!/usr/bin/env python3
"""
Production Market Data Ingestion System
Handles real-time market data collection from multiple sources
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from collections import defaultdict, deque
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
import websockets
import aiohttp
import redis
from prometheus_client import Counter, Histogram, Gauge

# Configure logging
logger = logging.getLogger(__name__)

# Metrics
data_points_received = Counter('market_data_points_received', 'Total data points received', ['source', 'symbol'])
data_latency = Histogram('market_data_latency_ms', 'Data latency in milliseconds', ['source'])
active_connections = Gauge('market_data_active_connections', 'Active data connections', ['source'])
data_quality_score = Gauge('market_data_quality_score', 'Data quality score', ['source'])

@dataclass
class MarketDataConfig:
    """Configuration for market data ingestion"""
    sources: List[str] = field(default_factory=lambda: ["alpaca", "polygon", "iex"])
    symbols: List[str] = field(default_factory=lambda: ["AAPL", "GOOGL", "MSFT", "SPY"])
    update_frequency: int = 100  # milliseconds
    buffer_size: int = 10000
    enable_options: bool = True
    enable_crypto: bool = True
    redis_host: str = "localhost"
    redis_port: int = 6379

@dataclass
class MarketDataPoint:
    """Single market data point"""
    symbol: str
    timestamp: datetime
    source: str
    bid: float
    ask: float
    bid_size: int
    ask_size: int
    last: float
    volume: int
    open: float
    high: float
    low: float
    close: float
    vwap: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

class DataSource:
    """Base class for data sources"""
    
    def __init__(self, name: str, config: MarketDataConfig):
        self.name = name
        self.config = config
        self.connected = False
        self.callbacks: List[Callable] = []
        
    async def connect(self):
        """Connect to data source"""
        raise NotImplementedError
        
    async def disconnect(self):
        """Disconnect from data source"""
        raise NotImplementedError
        
    async def subscribe(self, symbols: List[str]):
        """Subscribe to symbols"""
        raise NotImplementedError
        
    def add_callback(self, callback: Callable):
        """Add data callback"""
        self.callbacks.append(callback)
        
    async def _process_data(self, data: MarketDataPoint):
        """Process incoming data"""
        for callback in self.callbacks:
            try:
                await callback(data)
            except Exception as e:
                logger.error(f"Callback error: {e}")

class AlpacaDataSource(DataSource):
    """Alpaca market data source"""
    
    def __init__(self, config: MarketDataConfig, api_key: str, api_secret: str):
        super().__init__("alpaca", config)
        self.api_key = api_key
        self.api_secret = api_secret
        self.ws_url = "wss://stream.data.alpaca.markets/v2/iex"
        self.ws_connection = None
        
    async def connect(self):
        """Connect to Alpaca websocket"""
        try:
            self.ws_connection = await websockets.connect(self.ws_url)
            
            # Authenticate
            auth_data = {}
                "action": "auth",
                "key": self.api_key,
                "secret": self.api_secret
            }
            await self.ws_connection.send(json.dumps(auth_data))
            
            # Start message handler
            asyncio.create_task(self._handle_messages())
            
            self.connected = True
            active_connections.labels(source=self.name).inc()
            logger.info(f"Connected to Alpaca data stream")
            
        except Exception as e:
            logger.error(f"Failed to connect to Alpaca: {e}")
            raise
            
    async def disconnect(self):
        """Disconnect from Alpaca"""
        if self.ws_connection:
            await self.ws_connection.close()
            self.connected = False
            active_connections.labels(source=self.name).dec()
            
    async def subscribe(self, symbols: List[str]):
        """Subscribe to symbols"""
        if not self.connected:
            await self.connect()
            
        sub_data = {}
            "action": "subscribe",
            "trades": symbols,
            "quotes": symbols,
            "bars": symbols
        }
        await self.ws_connection.send(json.dumps(sub_data))
        logger.info(f"Subscribed to symbols: {symbols}")
        
    async def _handle_messages(self):
        """Handle incoming messages"""
        async for message in self.ws_connection:
            try:
                data = json.loads(message)
                
                for msg in data:
                    if msg['T'] in ['t', 'q', 'b']:  # trade, quote, bar
                        await self._process_message(msg)
                        
            except Exception as e:
                logger.error(f"Error processing Alpaca message: {e}")
                
    async def _process_message(self, msg: Dict[str, Any]):
        """Process single message"""
        try:
            if msg['T'] == 'q':  # Quote
                data_point = MarketDataPoint()
                    symbol=msg['S'],
                    timestamp=datetime.fromisoformat(msg['t'].replace('Z', '+00:00')),
                    source=self.name,
                    bid=msg['bp'],
                    ask=msg['ap'],
                    bid_size=msg['bs'],
                    ask_size=msg['as'],
                    last=0,  # Not in quote
                    volume=0,
                    open=0,
                    high=0,
                    low=0,
                    close=0
                )
                
                # Record metrics
                data_points_received.labels(source=self.name, symbol=msg['S']).inc()
                latency = (datetime.now(timezone.utc) - data_point.timestamp).total_seconds() * 1000
                data_latency.labels(source=self.name).observe(latency)
                
                await self._process_data(data_point)
                
        except Exception as e:
            logger.error(f"Error processing message: {e}")

class PolygonDataSource(DataSource):
    """Polygon.io data source"""
    
    def __init__(self, config: MarketDataConfig, api_key: str):
        super().__init__("polygon", config)
        self.api_key = api_key
        self.ws_url = f"wss://socket.polygon.io/stocks"
        self.ws_connection = None
        
    async def connect(self):
        """Connect to Polygon websocket"""
        try:
            self.ws_connection = await websockets.connect()
                f"{self.ws_url}?apikey={self.api_key}"
            )
            
            # Start message handler
            asyncio.create_task(self._handle_messages())
            
            self.connected = True
            active_connections.labels(source=self.name).inc()
            logger.info("Connected to Polygon data stream")
            
        except Exception as e:
            logger.error(f"Failed to connect to Polygon: {e}")
            raise
            
    async def _handle_messages(self):
        """Handle incoming messages"""
        async for message in self.ws_connection:
            try:
                data = json.loads(message)
                
                for event in data:
                    if event['ev'] in ['Q', 'T', 'A']:  # Quote, Trade, Aggregate
                        await self._process_event(event)
                        
            except Exception as e:
                logger.error(f"Error processing Polygon message: {e}")

class MarketDataIngestion:
    """Main market data ingestion system"""
    
    def __init__(self, config: Optional[MarketDataConfig] = None):
        self.config = config or MarketDataConfig()
        self.data_sources: Dict[str, DataSource] = {}
        self.data_buffer = asyncio.Queue(maxsize=self.config.buffer_size)
        self.redis_client = None
        self.running = False
        self.subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self.data_stats = defaultdict(lambda: {)
            'count': 0,
            'last_update': None,
            'quality_score': 1.0
        })
        
    async def initialize(self):
        """Initialize the ingestion system"""
        try:
            # Connect to Redis
            self.redis_client = redis.Redis()
                host=self.config.redis_host,
                port=self.config.redis_port,
                decode_responses=True
            )
            self.redis_client.ping()
            
            # Initialize data sources based on config
            if "alpaca" in self.config.sources:
                # In production, load from secure config
                alpaca_source = AlpacaDataSource()
                    self.config,
                    api_key="YOUR_ALPACA_KEY",
                    api_secret="YOUR_ALPACA_SECRET"
                )
                alpaca_source.add_callback(self._on_data_received)
                self.data_sources["alpaca"] = alpaca_source
                
            logger.info("Market data ingestion system initialized")
            
        except Exception as e:
            logger.error(f"Failed to initialize: {e}")
            raise
            
    async def start(self):
        """Start data ingestion"""
        self.running = True
        
        # Connect all data sources
        connect_tasks = []
        for source in self.data_sources.values():
            connect_tasks.append(source.connect())
            
        await asyncio.gather(*connect_tasks)
        
        # Subscribe to symbols
        for source in self.data_sources.values():
            await source.subscribe(self.config.symbols)
            
        # Start processing tasks
        asyncio.create_task(self._process_data_buffer())
        asyncio.create_task(self._monitor_data_quality())
        
        logger.info("Market data ingestion started")
        
    async def stop(self):
        """Stop data ingestion"""
        self.running = False
        
        # Disconnect all sources
        for source in self.data_sources.values():
            await source.disconnect()
            
        logger.info("Market data ingestion stopped")
        
    async def _on_data_received(self, data: MarketDataPoint):
        """Handle incoming data"""
        try:
            # Add to buffer
            await self.data_buffer.put(data)
            
            # Update stats
            stats = self.data_stats[data.symbol]
            stats['count'] += 1
            stats['last_update'] = data.timestamp
            
            # Publish to subscribers
            for callback in self.subscribers[data.symbol]:
                asyncio.create_task(callback(data))
                
            # Store in Redis
            if self.redis_client:
                key = f"market_data:{data.symbol}:latest"
                self.redis_client.hset(key, mapping={)
                    'bid': data.bid,
                    'ask': data.ask,
                    'last': data.last,
                    'volume': data.volume,
                    'timestamp': data.timestamp.isoformat()
                })
                self.redis_client.expire(key, 300)  # 5 minute expiry
                
        except Exception as e:
            logger.error(f"Error processing data: {e}")
            
    async def _process_data_buffer(self):
        """Process buffered data"""
        batch = []
        
        while self.running:
            try:
                # Collect batch
                deadline = asyncio.get_event_loop().time() + 0.1  # 100ms batch window
                
                while asyncio.get_event_loop().time() < deadline:
                    try:
                        data = await asyncio.wait_for()
                            self.data_buffer.get(), 
                            timeout=0.01
                        )
                        batch.append(data)
                        
                        if len(batch) >= 100:  # Max batch size
                            break
                            
                    except asyncio.TimeoutError:
                        break
                        
                # Process batch
                if batch:
                    await self._process_batch(batch)
                    batch = []
                    
            except Exception as e:
                logger.error(f"Buffer processing error: {e}")
                
    async def _process_batch(self, batch: List[MarketDataPoint]):
        """Process a batch of data points"""
        # Convert to DataFrame for efficient processing
        df = pd.DataFrame([)
            {}
                'symbol': d.symbol,
                'timestamp': d.timestamp,
                'bid': d.bid,
                'ask': d.ask,
                'spread': d.ask - d.bid,
                'mid': (d.bid + d.ask) / 2,
                'source': d.source
            }
            for d in batch
        ])
        
        # Calculate aggregates by symbol
        for symbol in df['symbol'].unique():
            symbol_data = df[df['symbol'] == symbol]
            
            # Store time series in Redis
            if self.redis_client:
                for _, row in symbol_data.iterrows():
                    ts_key = f"market_data:{symbol}:timeseries"
                    score = row['timestamp'].timestamp()
                    value = json.dumps({)
                        'bid': row['bid'],
                        'ask': row['ask'],
                        'mid': row['mid'],
                        'spread': row['spread']
                    })
                    self.redis_client.zadd(ts_key, {value: score})
                    
                # Trim old data (keep last hour)
                cutoff = time.time() - 3600
                self.redis_client.zremrangebyscore(ts_key, 0, cutoff)
                
    async def _monitor_data_quality(self):
        """Monitor data quality metrics"""
        while self.running:
            try:
                for symbol, stats in self.data_stats.items():
                    if stats['last_update']:
                        # Calculate staleness
                        staleness = (datetime.now(timezone.utc) - stats['last_update']).total_seconds()
                        
                        # Calculate quality score
                        if staleness < 1:  # Less than 1 second
                            quality = 1.0
                        elif staleness < 5:
                            quality = 0.8
                        elif staleness < 30:
                            quality = 0.5
                        else:
                            quality = 0.1
                            
                        stats['quality_score'] = quality
                        
                        # Update metric
                        for source in self.data_sources:
                            data_quality_score.labels(source=source).set(quality)
                            
                await asyncio.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                logger.error(f"Quality monitoring error: {e}")
                
    def subscribe(self, symbol: str, callback: Callable):
        """Subscribe to symbol updates"""
        self.subscribers[symbol].append(callback)
        
    def get_latest_data(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get latest data for symbol"""
        if self.redis_client:
            try:
                data = self.redis_client.hgetall(f"market_data:{symbol}:latest")
                return data if data else None
            except Exception as e:
                logger.error(f"Error getting latest data: {e}")
                return None
        return None
        
    def get_status(self) -> Dict[str, Any]:
        """Get system status"""
        return {}
            'running': self.running,
            'sources': {}
                name: {}
                    'connected': source.connected,
                    'type': source.__class__.__name__
                }
                for name, source in self.data_sources.items()
            },
            'buffer_size': self.data_buffer.qsize(),
            'symbols_tracked': len(self.data_stats),
            'total_data_points': sum(s['count'] for s in self.data_stats.values())
        }

# Example usage
async def main():
    config = MarketDataConfig()
        sources=["alpaca"],
        symbols=["AAPL", "GOOGL", "MSFT"],
        buffer_size=10000
    )
    
    ingestion = MarketDataIngestion(config)
    await ingestion.initialize()
    await ingestion.start()
    
    # Run for a while
    await asyncio.sleep(60)
    
    await ingestion.stop()

if __name__ == "__main__":
    asyncio.run(main())