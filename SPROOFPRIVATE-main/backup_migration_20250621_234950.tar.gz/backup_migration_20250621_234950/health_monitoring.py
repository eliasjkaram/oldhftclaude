#!/usr/bin/env python3
"""
Health Monitoring System
========================
Real-time health monitoring for all trading system components
"""

import time
import json
import threading
import psutil
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from collections import deque
import asyncio
from flask import Flask, jsonify, request
import requests

from unified_logging import get_logger

logger = get_logger(__name__)

class HealthMonitor:
    """Monitor health of all system components"""
    
    def __init__(self):
        self.start_time = datetime.now()
        self.components = {}
        self.metrics_history = deque(maxlen=1000)  # Keep last 1000 metrics
        self.alerts = deque(maxlen=100)  # Keep last 100 alerts
        self.monitoring_thread = None
        self.running = False
        
        # Initialize component health trackers
        self.init_component_trackers()
        
        # Flask app for health endpoints
        self.app = Flask(__name__)
        self.setup_endpoints()
    
    def init_component_trackers(self):
        """Initialize health trackers for each component"""
        components = []
            'alpaca_api',
            'minio_pipeline',
            'gpu_acceleration',
            'ai_bots',
            'trading_engine',
            'risk_management',
            'data_pipeline',
            'web_interface'
        ]
        
        for component in components:
            self.components[component] = {}
                'status': 'unknown',
                'last_check': None,
                'uptime': 0,
                'errors': 0,
                'last_error': None,
                'metrics': {}
            }
    
    def check_alpaca_health(self) -> Dict[str, Any]:
        """Check Alpaca API health"""
        try:
            from alpaca_config import default_config
            from alpaca.trading.client import TradingClient
            
            client = TradingClient(**default_config.get_trading_client_config())
            account = client.get_account()
            
            return {}
                'status': 'healthy',
                'account_status': account.status,
                'buying_power': float(account.buying_power),
                'api_calls_remaining': 200  # Placeholder - implement rate limit tracking
            }
        except Exception as e:
            logger.error(f"Alpaca health check failed: {e}")
            return {}
                'status': 'unhealthy',
                'error': str(e)
            }
    
    def check_minio_health(self) -> Dict[str, Any]:
        """Check MinIO pipeline health"""
        try:
            from DATA_PIPELINE_MINIO import DataPipelineMinIO
            
            pipeline = DataPipelineMinIO()
            
            if pipeline.minio_client:
                # Test bucket access
                buckets = pipeline.minio_client.list_buckets()
                
                return {}
                    'status': 'healthy',
                    'buckets': len(buckets),
                    'connected': True
                }
            else:
                return {}
                    'status': 'degraded',
                    'message': 'MinIO not available - using fallback'
                }
                
        except Exception as e:
            logger.error(f"MinIO health check failed: {e}")
            return {}
                'status': 'unhealthy',
                'error': str(e)
            }
    
    def check_gpu_health(self) -> Dict[str, Any]:
        """Check GPU health and utilization"""
        try:
            import torch
            
            if torch.cuda.is_available():
                # Get GPU stats
                gpu_props = torch.cuda.get_device_properties(0)
                memory_allocated = torch.cuda.memory_allocated() / 1e9
                memory_total = gpu_props.total_memory / 1e9
                
                # Try to get utilization (requires nvidia-ml-py)
                try:
                    import nvidia_ml_py.pynvml as nvml
                    nvml.nvmlInit()
                    handle = nvml.nvmlDeviceGetHandleByIndex(0)
                    util = nvml.nvmlDeviceGetUtilizationRates(handle)
                    gpu_util = util.gpu
                    memory_util = util.memory
                except:
                    gpu_util = -1
                    memory_util = (memory_allocated / memory_total) * 100
                
                return {}
                    'status': 'healthy',
                    'device': gpu_props.name,
                    'memory_gb': f"{memory_allocated:.2f}/{memory_total:.2f}",
                    'gpu_utilization': f"{gpu_util}%" if gpu_util >= 0 else "N/A",
                    'memory_utilization': f"{memory_util:.1f}%"
                }
            else:
                return {}
                    'status': 'not_available',
                    'message': 'GPU not available - using CPU'
                }
                
        except Exception as e:
            logger.error(f"GPU health check failed: {e}")
            return {}
                'status': 'error',
                'error': str(e)
            }
    
    def check_system_resources(self) -> Dict[str, Any]:
        """Check system resource utilization"""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            
            # Memory
            memory = psutil.virtual_memory()
            
            # Disk
            disk = psutil.disk_usage('/')
            
            # Network
            net_io = psutil.net_io_counters()
            
            return {}
                'cpu': {}
                    'percent': cpu_percent,
                    'cores': cpu_count,
                    'status': 'healthy' if cpu_percent < 80 else 'warning'
                },
                'memory': {}
                    'percent': memory.percent,
                    'available_gb': memory.available / 1e9,
                    'total_gb': memory.total / 1e9,
                    'status': 'healthy' if memory.percent < 80 else 'warning'
                },
                'disk': {}
                    'percent': disk.percent,
                    'free_gb': disk.free / 1e9,
                    'total_gb': disk.total / 1e9,
                    'status': 'healthy' if disk.percent < 90 else 'warning'
                },
                'network': {}
                    'bytes_sent': net_io.bytes_sent,
                    'bytes_recv': net_io.bytes_recv,
                    'status': 'healthy'
                }
            }
        except Exception as e:
            logger.error(f"System resource check failed: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def update_component_health(self, component: str, health_data: Dict[str, Any]):
        """Update component health status"""
        if component in self.components:
            self.components[component].update({)
                'status': health_data.get('status', 'unknown'),
                'last_check': datetime.now().isoformat(),
                'metrics': health_data
            })
            
            # Track errors
            if health_data.get('status') == 'unhealthy':
                self.components[component]['errors'] += 1
                self.components[component]['last_error'] = health_data.get('error', 'Unknown error')
                
                # Create alert
                self.create_alert(component, f"Component unhealthy: {health_data.get('error', '')}")
    
    def create_alert(self, component: str, message: str, severity: str = 'warning'):
        """Create a system alert"""
        alert = {}
            'timestamp': datetime.now().isoformat(),
            'component': component,
            'message': message,
            'severity': severity
        }
        
        self.alerts.append(alert)
        logger.warning(f"ALERT [{component}]: {message}")
    
    def run_health_checks(self):
        """Run all health checks"""
        # Check each component
        self.update_component_health('alpaca_api', self.check_alpaca_health())
        self.update_component_health('minio_pipeline', self.check_minio_health())
        self.update_component_health('gpu_acceleration', self.check_gpu_health())
        
        # Check system resources
        system_health = self.check_system_resources()
        
        # Record metrics
        metrics = {}
            'timestamp': datetime.now().isoformat(),
            'system': system_health,
            'components': {k: v['status'] for k, v in self.components.items()}
        }
        
        self.metrics_history.append(metrics)
        
        return metrics
    
    def start_monitoring(self, interval: int = 30):
        """Start background health monitoring"""
        self.running = True
        
        def monitor_loop():
            while self.running:
                try:
                    self.run_health_checks()
                    time.sleep(interval)
                except Exception as e:
                    logger.error(f"Health monitoring error: {e}")
                    time.sleep(interval)
        
        self.monitoring_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitoring_thread.start()
        logger.info(f"Health monitoring started (interval: {interval}s)")
    
    def stop_monitoring(self):
        """Stop health monitoring"""
        self.running = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        logger.info("Health monitoring stopped")
    
    def get_system_health(self) -> Dict[str, Any]:
        """Get overall system health summary"""
        # Calculate uptime
        uptime = (datetime.now() - self.start_time).total_seconds()
        
        # Count healthy components
        healthy_count = sum(1 for c in self.components.values() if c['status'] == 'healthy')
        total_count = len(self.components)
        
        # Overall status
        if healthy_count == total_count:
            overall_status = 'healthy'
        elif healthy_count >= total_count * 0.8:
            overall_status = 'degraded'
        else:
            overall_status = 'unhealthy'
        
        return {}
            'status': overall_status,
            'uptime_seconds': uptime,
            'uptime_formatted': str(timedelta(seconds=int(uptime))),
            'components_healthy': healthy_count,
            'components_total': total_count,
            'last_check': datetime.now().isoformat(),
            'alerts_count': len(self.alerts)
        }
    
    def setup_endpoints(self):
        """Setup Flask health endpoints"""
        
        @self.app.route('/health', methods=['GET'])
        def health():
            """Basic health check endpoint"""
            return jsonify({)
                'status': 'ok',
                'timestamp': datetime.now().isoformat()
            })
        
        @self.app.route('/health/detailed', methods=['GET'])
        def health_detailed():
            """Detailed health information"""
            return jsonify({)
                'system': self.get_system_health(),
                'components': self.components,
                'resources': self.check_system_resources()
            })
        
        @self.app.route('/health/components/<component>', methods=['GET'])
        def component_health(component):
            """Specific component health"""
            if component in self.components:
                return jsonify(self.components[component])
            return jsonify({'error': 'Component not found'}), 404
        
        @self.app.route('/health/metrics', methods=['GET'])
        def metrics():
            """Recent metrics history"""
            limit = request.args.get('limit', 100, type=int)
            return jsonify(list(self.metrics_history)[-limit:])
        
        @self.app.route('/health/alerts', methods=['GET'])
        def alerts():
            """Recent alerts"""
            return jsonify(list(self.alerts))
        
        @self.app.route('/health/run-check', methods=['POST'])
        def run_check():
            """Manually trigger health check"""
            result = self.run_health_checks()
            return jsonify(result)
    
    def run_server(self, host: str = '0.0.0.0', port: int = 5000):
        """Run the health monitoring server"""
        logger.info(f"Starting health monitoring server on {host}:{port}")
        self.app.run(host=host, port=port, debug=False)


# Singleton instance
_monitor_instance = None

def get_health_monitor() -> HealthMonitor:
    """Get health monitor instance"""
    global _monitor_instance
    
    if _monitor_instance is None:
        _monitor_instance = HealthMonitor()
    
    return _monitor_instance


def start_health_monitoring(interval: int = 30):
    """Start health monitoring"""
    monitor = get_health_monitor()
    monitor.start_monitoring(interval)
    return monitor


if __name__ == "__main__":
    # Test health monitoring
    monitor = HealthMonitor()
    
    # Start monitoring
    monitor.start_monitoring(interval=10)
    
    # Run server
    try:
        monitor.run_server(port=5555)
    except KeyboardInterrupt:
        monitor.stop_monitoring()
        print("\nHealth monitoring stopped")