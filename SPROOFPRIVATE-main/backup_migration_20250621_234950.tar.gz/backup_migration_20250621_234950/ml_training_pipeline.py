#!/usr/bin/env python3
"""
ML Training Pipeline for Options Arbitrage Detection
Advanced machine learning pipeline for training models on 301.9 GB options data
Includes multiple model architectures, ensemble methods, and real-time inference
"""

import pandas as pd
import numpy as np
import sqlite3
import pickle
import joblib
import asyncio
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import time
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

# ML Libraries
import sklearn
from sklearn.model_selection import train_test_split, TimeSeriesSplit, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler, LabelEncoder
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif
from sklearn.ensemble import ()
    RandomForestClassifier, RandomForestRegressor, 
    GradientBoostingClassifier, GradientBoostingRegressor,
    VotingClassifier, VotingRegressor, AdaBoostClassifier
)
from sklearn.linear_model import LogisticRegression, Ridge, Lasso, ElasticNet
from sklearn.svm import SVC, SVR
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import ()
    accuracy_score, precision_score, recall_score, f1_score,
    mean_absolute_error, mean_squared_error, r2_score,
    classification_report, confusion_matrix, roc_auc_score
)

# Advanced ML libraries
try:
    import xgboost as xgb
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

try:
    import lightgbm as lgb
    HAS_LIGHTGBM = True
except ImportError:
    HAS_LIGHTGBM = False

try:
    import tensorflow as tf
    from tensorflow import keras
    HAS_TENSORFLOW = True
except ImportError:
    HAS_TENSORFLOW = False

# Import our data pipeline
from comprehensive_data_pipeline import ComprehensiveDataPipeline, DataPipelineConfig

@dataclass
class MLTrainingConfig:
    """Configuration for ML training pipeline"""
    # Data configuration
    data_path: str = "./processed_data"
    feature_file: str = "feature_matrix.parquet"
    labels_file: str = "arbitrage_labels.parquet"
    train_file: str = "train_labels.parquet"
    test_file: str = "test_labels.parquet"
    
    # Model configuration
    models_to_train: List[str] = None
    ensemble_methods: List[str] = None
    cross_validation_folds: int = 5
    test_size: float = 0.2
    validation_size: float = 0.1
    
    # Training configuration
    random_state: int = 42
    n_jobs: int = -1
    max_training_time_minutes: int = 120
    early_stopping_patience: int = 10
    
    # Feature engineering
    feature_selection_k: int = 50
    scale_features: bool = True
    create_polynomial_features: bool = False
    polynomial_degree: int = 2
    
    # Output configuration
    models_output_dir: str = "./trained_models"
    metrics_output_file: str = "./model_metrics.json"
    predictions_output_file: str = "./predictions.parquet"
    
    # Advanced options
    hyperparameter_tuning: bool = True
    use_gpu: bool = False
    ensemble_voting: str = "soft"  # "hard" or "soft"
    
    def __post_init__(self):
        if self.models_to_train is None:
            self.models_to_train = []
                'random_forest', 'gradient_boosting', 'logistic_regression',
                'svm', 'neural_network', 'naive_bayes'
            ]
            if HAS_XGBOOST:
                self.models_to_train.append('xgboost')
            if HAS_LIGHTGBM:
                self.models_to_train.append('lightgbm')
        
        if self.ensemble_methods is None:
            self.ensemble_methods = ['voting', 'stacking']

@dataclass
class ModelPerformance:
    """Model performance metrics"""
    model_name: str
    task_type: str  # 'classification' or 'regression'
    
    # Training metrics
    train_accuracy: float = 0.0
    train_precision: float = 0.0
    train_recall: float = 0.0
    train_f1: float = 0.0
    train_auc: float = 0.0
    train_mae: float = 0.0
    train_mse: float = 0.0
    train_r2: float = 0.0
    
    # Validation metrics
    val_accuracy: float = 0.0
    val_precision: float = 0.0
    val_recall: float = 0.0
    val_f1: float = 0.0
    val_auc: float = 0.0
    val_mae: float = 0.0
    val_mse: float = 0.0
    val_r2: float = 0.0
    
    # Cross-validation metrics
    cv_mean_score: float = 0.0
    cv_std_score: float = 0.0
    
    # Training details
    training_time_seconds: float = 0.0
    feature_importance: Dict[str, float] = None
    hyperparameters: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.feature_importance is None:
            self.feature_importance = {}
        if self.hyperparameters is None:
            self.hyperparameters = {}

class MLTrainingPipeline:
    """
    Complete ML training pipeline for options arbitrage detection
    Supports multiple models, ensemble methods, and advanced techniques
    """
    
    def __init__(self, config: MLTrainingConfig = None):
        self.config = config or MLTrainingConfig()
        
        # Initialize directories
        self.data_dir = Path(self.config.data_path)
        self.models_dir = Path(self.config.models_output_dir)
        self.models_dir.mkdir(exist_ok=True)
        
        # Initialize components
        self.scalers = {}
        self.feature_selectors = {}
        self.label_encoders = {}
        self.trained_models = {}
        self.model_performances = {}
        self.ensemble_models = {}
        
        # Data containers
        self.X_train = None
        self.X_val = None
        self.X_test = None
        self.y_train = None
        self.y_val = None
        self.y_test = None
        self.feature_names = []
        
        # Logging setup
        logging.basicConfig()
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    async def run_complete_ml_pipeline(self):
        """Run the complete ML training pipeline"""
        
        print("🤖 ML TRAINING PIPELINE FOR OPTIONS ARBITRAGE")
        print("=" * 80)
        print(f"📊 Training on 301.9 GB processed options data")
        print(f"🎯 Models: {len(self.config.models_to_train)} algorithms")
        print(f"🔬 Advanced: Ensemble methods, hyperparameter tuning")
        print(f"⚡ Parallel: {self.config.n_jobs} workers")
        print("=" * 80)
        
        start_time = time.time()
        
        try:
            # Phase 1: Data Loading and Preparation
            await self._phase_1_data_preparation()
            
            # Phase 2: Feature Engineering and Selection
            await self._phase_2_feature_engineering()
            
            # Phase 3: Model Training
            await self._phase_3_model_training()
            
            # Phase 4: Ensemble Methods
            await self._phase_4_ensemble_training()
            
            # Phase 5: Model Evaluation and Selection
            await self._phase_5_model_evaluation()
            
            # Phase 6: Model Deployment Preparation
            await self._phase_6_deployment_preparation()
            
        except Exception as e:
            self.logger.error(f"ML pipeline failed: {e}")
            raise
        finally:
            total_time = time.time() - start_time
            await self._generate_training_report(total_time)
    
    async def _phase_1_data_preparation(self):
        """Phase 1: Load and prepare data for training"""
        print("\n📥 PHASE 1: DATA PREPARATION")
        print("-" * 50)
        
        # Load feature matrix
        feature_file = self.data_dir / "ml_features" / self.config.feature_file
        if feature_file.exists():
            print(f"   📊 Loading features from {feature_file}")
            features_df = pd.read_parquet(feature_file)
            print(f"   ✅ Loaded {features_df.shape[0]:,} samples, {features_df.shape[1]:,} features")
        else:
            # Generate features from database
            print("   🔧 Generating features from database...")
            features_df = await self._generate_features_from_db()
        
        # Load labels
        labels_file = self.data_dir / "ml_features" / self.config.labels_file
        if labels_file.exists():
            print(f"   🎯 Loading labels from {labels_file}")
            labels_df = pd.read_parquet(labels_file)
            print(f"   ✅ Loaded {len(labels_df):,} labeled samples")
        else:
            print("   ⚠️  No labels file found, creating synthetic labels...")
            labels_df = await self._create_synthetic_labels(features_df)
        
        # Merge features and labels
        if 'date' in features_df.columns and 'symbol' in features_df.columns:
            merged_df = features_df.merge()
                labels_df[['date', 'symbol', 'profit_potential', 'confidence_score', 'strategy_type']], 
                on=['date', 'symbol'], 
                how='inner'
            )
        else:
            # Simple join by index if no date/symbol columns
            min_length = min(len(features_df), len(labels_df))
            features_df = features_df.iloc[:min_length]
            labels_df = labels_df.iloc[:min_length]
            merged_df = pd.concat([features_df, labels_df], axis=1)
        
        print(f"   🔗 Merged dataset: {merged_df.shape[0]:,} samples")
        
        # Prepare features and targets
        self._prepare_features_and_targets(merged_df)
        
        # Split data
        self._split_data()
        
        print(f"   📊 Train: {len(self.X_train):,}, Val: {len(self.X_val):,}, Test: {len(self.X_test):,}")
    
    async def _generate_features_from_db(self) -> pd.DataFrame:
        """Generate features from database if parquet file doesn't exist"""
        db_path = self.data_dir / "options_master.db"
        
        if not db_path.exists():
            # Create minimal synthetic features for demo
            return self._create_synthetic_features()
        
        with sqlite3.connect(db_path) as conn:
            # Load features from database
            features_df = pd.read_sql_query(''')
                SELECT date, symbol, feature_name, feature_value
                FROM features
                ORDER BY date, symbol, feature_name
            ''', conn)
            
            if features_df.empty:
                return self._create_synthetic_features()
            
            # Pivot to create feature matrix
            feature_matrix = features_df.pivot_table()
                index=['date', 'symbol'],
                columns='feature_name',
                values='feature_value',
                fill_value=0
            ).reset_index()
            
            return feature_matrix
    
    def _create_synthetic_features(self) -> pd.DataFrame:
        """Create synthetic features for demonstration"""
        print("   🎲 Creating synthetic features for demonstration...")
        
        np.random.seed(self.config.random_state)
        n_samples = 10000
        n_features = 25
        
        # Generate synthetic feature data
        features = {}
        features['date'] = pd.date_range('2020-01-01', periods=n_samples, freq='H')
        features['symbol'] = np.random.choice(['SPY', 'QQQ', 'AAPL', 'MSFT', 'TSLA'], n_samples)
        
        # Technical features
        features['total_volume'] = np.random.lognormal(10, 1, n_samples)
        features['total_open_interest'] = np.random.lognormal(12, 1, n_samples)
        features['put_call_ratio'] = np.random.uniform(0.5, 2.0, n_samples)
        features['avg_iv'] = np.random.uniform(0.1, 0.8, n_samples)
        features['iv_std'] = np.random.uniform(0.01, 0.3, n_samples)
        features['avg_spread'] = np.random.uniform(0.01, 1.0, n_samples)
        features['avg_spread_pct'] = np.random.uniform(0.001, 0.1, n_samples)
        
        # Greeks features
        features['avg_delta'] = np.random.uniform(-1, 1, n_samples)
        features['avg_gamma'] = np.random.uniform(0, 0.1, n_samples)
        features['avg_theta'] = np.random.uniform(-0.1, 0, n_samples)
        features['avg_vega'] = np.random.uniform(0, 0.5, n_samples)
        
        # Market structure features
        features['unique_strikes'] = np.random.randint(5, 50, n_samples)
        features['unique_expirations'] = np.random.randint(1, 10, n_samples)
        features['otm_call_volume'] = np.random.lognormal(8, 1, n_samples)
        features['otm_put_volume'] = np.random.lognormal(8, 1, n_samples)
        
        # Volatility features
        features['iv_skew'] = np.random.uniform(-2, 2, n_samples)
        features['iv_percentile_25'] = np.random.uniform(0.1, 0.3, n_samples)
        features['iv_percentile_75'] = np.random.uniform(0.3, 0.8, n_samples)
        
        # Add some time-based features
        features['hour'] = features['date'].dt.hour
        features['day_of_week'] = features['date'].dt.dayofweek
        features['month'] = features['date'].dt.month
        
        # Add some derived features
        features['volume_oi_ratio'] = features['total_volume'] / (features['total_open_interest'] + 1)
        features['call_put_volume_ratio'] = 1 / features['put_call_ratio']
        features['iv_spread'] = features['iv_percentile_75'] - features['iv_percentile_25']
        
        return pd.DataFrame(features)
    
    async def _create_synthetic_labels(self, features_df: pd.DataFrame) -> pd.DataFrame:
        """Create synthetic labels for demonstration"""
        print("   🎯 Creating synthetic labels...")
        
        n_samples = len(features_df)
        
        # Create labels based on feature combinations
        labels = {}
        labels['date'] = features_df['date'] if 'date' in features_df.columns else pd.date_range('2020-01-01', periods=n_samples, freq='H')
        labels['symbol'] = features_df['symbol'] if 'symbol' in features_df.columns else np.random.choice(['SPY', 'QQQ', 'AAPL'], n_samples)
        
        # Generate profit potential based on features
        if 'avg_iv' in features_df.columns and 'put_call_ratio' in features_df.columns:
            # Higher IV and extreme P/C ratios suggest higher profit potential
            iv_factor = features_df['avg_iv'] * 100
            pc_factor = np.abs(features_df['put_call_ratio'] - 1) * 50
            labels['profit_potential'] = iv_factor + pc_factor + np.random.normal(0, 20, n_samples)
        else:
            labels['profit_potential'] = np.random.lognormal(4, 1, n_samples)
        
        # Generate confidence scores
        labels['confidence_score'] = np.random.beta(2, 2, n_samples)  # Concentrated around 0.5
        
        # Generate strategy types
        strategies = ['put_call_parity', 'box_spread', 'volatility_arbitrage', 'calendar_spread']
        labels['strategy_type'] = np.random.choice(strategies, n_samples)
        
        # Create binary classification target (profitable opportunity)
        labels['is_profitable'] = (labels['profit_potential'] > 100) & (labels['confidence_score'] > 0.7)
        
        return pd.DataFrame(labels)
    
    def _prepare_features_and_targets(self, merged_df: pd.DataFrame):
        """Prepare feature matrix and target variables"""
        
        # Identify feature columns (exclude target and metadata columns)
        exclude_cols = {}
            'date', 'symbol', 'profit_potential', 'confidence_score', 
            'strategy_type', 'is_profitable'
        }
        
        feature_cols = [col for col in merged_df.columns if col not in exclude_cols]
        self.feature_names = feature_cols
        
        # Prepare feature matrix
        X = merged_df[feature_cols].fillna(0)
        
        # Handle infinite values
        X = X.replace([np.inf, -np.inf], 0)
        
        # Prepare targets
        if 'is_profitable' in merged_df.columns:
            y_classification = merged_df['is_profitable'].astype(int)
        else:
            # Create binary target from profit potential
            y_classification = (merged_df['profit_potential'] > merged_df['profit_potential'].median().astype(int)
        
metrics["accuracy"] = accuracy_score(y_true, y_pred)
            y_regression = merged_df['profit_potential'].fillna(0)
        else:
            y_regression = np.random.lognormal(4, 1, len(X)
        
        # Store data
        self.X = X
        self.y_classification = y_classification
        self.y_regression = y_regression
        
        print(f"   📊 Features prepared: {X.shape[1]} features")
        print(f"   🎯 Classification target: {y_classification.sum()} positive samples")
        print(f"   📈 Regression target range: {y_regression.min():.2f} - {y_regression.max():.2f}")
    
    def _split_data(self):
        """Split data into train/validation/test sets"""
        
        # First split: separate test set
        X_temp, self.X_test, y_class_temp, y_class_test, y_reg_temp, y_reg_test = train_test_split()
            self.X, self.y_classification, self.y_regression,
            test_size=self.config.test_size,
            random_state=self.config.random_state,
            stratify=self.y_classification
        )
        
        # Second split: separate train and validation
        val_size = self.config.validation_size / (1 - self.config.test_size)
        self.X_train, self.X_val, y_class_train, y_class_val, y_reg_train, y_reg_val = train_test_split()
            X_temp, y_class_temp, y_reg_temp,
            test_size=val_size,
            random_state=self.config.random_state,
            stratify=y_class_temp
        )
        
        # Store targets for both tasks
        self.y_train = {'classification': y_class_train, 'regression': y_reg_train}
        self.y_val = {'classification': y_class_val, 'regression': y_reg_val}
        self.y_test = {'classification': y_class_test, 'regression': y_reg_test}
    
    async def _phase_2_feature_engineering(self):
        """Phase 2: Feature engineering and selection"""
        print("\n🔧 PHASE 2: FEATURE ENGINEERING")
        print("-" * 50)
        
        # Feature scaling
        if self.config.scale_features:
            print("   📏 Scaling features...")
            self.scalers['standard'] = StandardScaler()
            self.scalers['robust'] = RobustScaler()
            
            self.X_train_scaled = self.scalers['standard'].fit_transform(self.X_train)
            self.X_val_scaled = self.scalers['standard'].transform(self.X_val)
            self.X_test_scaled = self.scalers['standard'].transform(self.X_test)
            
            print("   ✅ Features scaled with StandardScaler")
        
        # Feature selection
        if self.config.feature_selection_k > 0:
            print(f"   🎯 Selecting top {self.config.feature_selection_k} features...")
            
            self.feature_selectors['classification'] = SelectKBest()
                score_func=f_classif, 
                k=min(self.config.feature_selection_k, len(self.feature_names)
            )
            
            self.feature_selectors['regression'] = SelectKBest()
                score_func=f_classif,  # Can also use mutual_info_regression
                k=min(self.config.feature_selection_k, len(self.feature_names)
            )
            
            # Fit feature selectors
            X_train_data = self.X_train_scaled if self.config.scale_features else self.X_train
            
            self.feature_selectors['classification'].fit(X_train_data, self.y_train['classification'])
            self.feature_selectors['regression'].fit(X_train_data, self.y_train['regression'])
            
            # Get selected feature names
            selected_features_class = []
                self.feature_names[i] for i in 
                self.feature_selectors['classification'].get_support(indices=True)
            ]
            
            print(f"   ✅ Selected {len(selected_features_class)} features for classification")
    
    async def _phase_3_model_training(self):
        """Phase 3: Train individual models"""
        print("\n🤖 PHASE 3: MODEL TRAINING")
        print("-" * 50)
        
        for model_name in self.config.models_to_train:
            print(f"   🔧 Training {model_name}...")
            
            try:
                # Train classification model
                class_model, class_perf = await self._train_single_model()
                    model_name, 'classification'
                )
                self.trained_models[f"{model_name}_classification"] = class_model
                self.model_performances[f"{model_name}_classification"] = class_perf
                
                # Train regression model
                reg_model, reg_perf = await self._train_single_model()
                    model_name, 'regression'
                )
                self.trained_models[f"{model_name}_regression"] = reg_model
                self.model_performances[f"{model_name}_regression"] = reg_perf
                
                print(f"   ✅ {model_name} - Classification F1: {class_perf.val_f1:.3f}, Regression R²: {reg_perf.val_r2:.3f}")
                
            except Exception as e:
                self.logger.error(f"Error training {model_name}: {e}")
        
        print(f"   🎯 Trained {len(self.trained_models)} models")
    
    async def _train_single_model(self, model_name: str, task_type: str) -> Tuple[Any, ModelPerformance]:
        """Train a single model for classification or regression"""
        
        start_time = time.time()
        
        # Get model
        model = self._get_model(model_name, task_type)
        
        # Prepare data
        X_train_data = self.X_train_scaled if self.config.scale_features else self.X_train
        X_val_data = self.X_val_scaled if self.config.scale_features else self.X_val
        
        # Apply feature selection if enabled
        if self.config.feature_selection_k > 0 and task_type in self.feature_selectors:
            X_train_data = self.feature_selectors[task_type].transform(X_train_data)
            X_val_data = self.feature_selectors[task_type].transform(X_val_data)
        
        y_train = self.y_train[task_type]
        y_val = self.y_val[task_type]
        
        # Train model
        if self.config.hyperparameter_tuning and hasattr(model, 'get_params'):
            model = self._hyperparameter_tune(model, X_train_data, y_train, task_type)
        else:
            model.fit(X_train_data, y_train)
        
        # Generate predictions
        train_pred = model.predict(X_train_data)
        val_pred = model.predict(X_val_data)
        
        # Calculate performance metrics
        performance = ModelPerformance()
            model_name=model_name,
            task_type=task_type,
            training_time_seconds=time.time() - start_time
        )
        
        if task_type == 'classification':
            # Classification metrics
            performance.train_accuracy = accuracy_score(y_train, train_pred)
            performance.train_precision = precision_score(y_train, train_pred, average='weighted', zero_division=0)
            performance.train_recall = recall_score(y_train, train_pred, average='weighted', zero_division=0)
            performance.train_f1 = f1_score(y_train, train_pred, average='weighted', zero_division=0)
            
            performance.val_accuracy = accuracy_score(y_val, val_pred)
            performance.val_precision = precision_score(y_val, val_pred, average='weighted', zero_division=0)
            performance.val_recall = recall_score(y_val, val_pred, average='weighted', zero_division=0)
            performance.val_f1 = f1_score(y_val, val_pred, average='weighted', zero_division=0)
            
            # AUC score if model supports predict_proba
            if hasattr(model, 'predict_proba'):
                try:
                    val_proba = model.predict_proba(X_val_data)[:, 1]
                    performance.val_auc = roc_auc_score(y_val, val_proba)
                except:
                    performance.val_auc = 0.0
        
        else:  # regression
            # Regression metrics
            performance.train_mae = mean_absolute_error(y_train, train_pred)
            performance.train_mse = mean_squared_error(y_train, train_pred)
            performance.train_r2 = r2_score(y_train, train_pred)
            
            performance.val_mae = mean_absolute_error(y_val, val_pred)
            performance.val_mse = mean_squared_error(y_val, val_pred)
            performance.val_r2 = r2_score(y_val, val_pred)
        
        # Cross-validation score
        if len(X_train_data) > 100:  # Only if sufficient data
            try:
                cv_scores = cross_val_score()
                    model, X_train_data, y_train, 
                    cv=min(5, self.config.cross_validation_folds),
                    n_jobs=1  # Avoid nested parallelism
                )
                performance.cv_mean_score = cv_scores.mean()
                performance.cv_std_score = cv_scores.std()
            except:
                performance.cv_mean_score = 0.0
                performance.cv_std_score = 0.0
        
        # Feature importance (if available)
        if hasattr(model, 'feature_importances_'):
            feature_names = self.feature_names
            if self.config.feature_selection_k > 0 and task_type in self.feature_selectors:
                selected_indices = self.feature_selectors[task_type].get_support(indices=True)
                feature_names = [self.feature_names[i] for i in selected_indices]
            
            if len(feature_names) == len(model.feature_importances_):
                performance.feature_importance = dict(zip(feature_names, model.feature_importances_)
        
        # Store hyperparameters
        if hasattr(model, 'get_params'):
            performance.hyperparameters = model.get_params()
        
        return model, performance
    
    def _get_model(self, model_name: str, task_type: str):
        """Get model instance based on name and task type"""
        
        if task_type == 'classification':
            models = {}
                'random_forest': RandomForestClassifier()
                    n_estimators=100, random_state=self.config.random_state, n_jobs=self.config.n_jobs
                ),
                'gradient_boosting': GradientBoostingClassifier()
                    n_estimators=100, random_state=self.config.random_state
                ),
                'logistic_regression': LogisticRegression()
                    random_state=self.config.random_state, max_iter=1000
                ),
                'svm': SVC()
                    random_state=self.config.random_state, probability=True
                ),
                'neural_network': MLPClassifier()
                    hidden_layer_sizes=(100, 50), random_state=self.config.random_state, max_iter=500
                ),
                'naive_bayes': GaussianNB()
            }
            
            if HAS_XGBOOST and model_name == 'xgboost':
                models['xgboost'] = xgb.XGBClassifier()
                    random_state=self.config.random_state, n_jobs=self.config.n_jobs
                )
            
            if HAS_LIGHTGBM and model_name == 'lightgbm':
                models['lightgbm'] = lgb.LGBMClassifier()
                    random_state=self.config.random_state, n_jobs=self.config.n_jobs
                )
        
        else:  # regression
            models = {}
                'random_forest': RandomForestRegressor()
                    n_estimators=100, random_state=self.config.random_state, n_jobs=self.config.n_jobs
                ),
                'gradient_boosting': GradientBoostingRegressor()
                    n_estimators=100, random_state=self.config.random_state
                ),
                'logistic_regression': Ridge(random_state=self.config.random_state),
                'svm': SVR(),
                'neural_network': MLPRegressor()
                    hidden_layer_sizes=(100, 50), random_state=self.config.random_state, max_iter=500
                ),
                'naive_bayes': Ridge(random_state=self.config.random_state)  # Fallback for NB
            }
            
            if HAS_XGBOOST and model_name == 'xgboost':
                models['xgboost'] = xgb.XGBRegressor()
                    random_state=self.config.random_state, n_jobs=self.config.n_jobs
                )
            
            if HAS_LIGHTGBM and model_name == 'lightgbm':
                models['lightgbm'] = lgb.LGBMRegressor()
                    random_state=self.config.random_state, n_jobs=self.config.n_jobs
                )
        
        return models.get(model_name, models['random_forest'])
    
    def _hyperparameter_tune(self, model, X_train, y_train, task_type: str):
        """Perform hyperparameter tuning"""
        
        # Define parameter grids (simplified for demo)
        param_grids = {}
            'random_forest': {}
                'n_estimators': [50, 100, 200],
                'max_depth': [5, 10, None],
                'min_samples_split': [2, 5, 10]
            },
            'gradient_boosting': {}
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7]
            },
            'logistic_regression': {}
                'C': [0.1, 1.0, 10.0],
                'penalty': ['l1', 'l2', 'elasticnet'],
                'solver': ['liblinear', 'saga']
            }
        }
        
        model_name = model.__class__.__name__.lower()
        for key in param_grids:
            if key in model_name:
                param_grid = param_grids[key]
                break
        else:
            return model  # No tuning available
        
        # Perform grid search
        scoring = 'f1_weighted' if task_type == 'classification' else 'r2'
        
        try:
            grid_search = GridSearchCV()
                model, param_grid, 
                cv=3,  # Reduced for speed
                scoring=scoring,
                n_jobs=1  # Avoid nested parallelism
            )
            
            grid_search.fit(X_train, y_train)
            return grid_search.best_estimator_
        
        except Exception as e:
            self.logger.warning(f"Hyperparameter tuning failed: {e}")
            return model
    
    async def _phase_4_ensemble_training(self):
        """Phase 4: Train ensemble models"""
        print("\n🎭 PHASE 4: ENSEMBLE TRAINING")
        print("-" * 50)
        
        if 'voting' in self.config.ensemble_methods:
            await self._train_voting_ensembles()
        
        if 'stacking' in self.config.ensemble_methods:
            await self._train_stacking_ensembles()
        
        print(f"   ✅ Trained {len(self.ensemble_models)} ensemble models")
    
    async def _train_voting_ensembles(self):
        """Train voting ensemble models"""
        print("   🗳️  Training voting ensembles...")
        
        # Get trained models for voting
        classification_models = []
            (name.replace('_classification', ''), model) 
            for name, model in self.trained_models.items() 
            if '_classification' in name
        ]
        
        regression_models = []
            (name.replace('_regression', ''), model)
            for name, model in self.trained_models.items()
            if '_regression' in name
        ]
        
        if len(classification_models) >= 2:
            voting_classifier = VotingClassifier()
                estimators=classification_models[:5],  # Limit to 5 models
                voting=self.config.ensemble_voting
            )
            
            X_train_data = self.X_train_scaled if self.config.scale_features else self.X_train
            voting_classifier.fit(X_train_data, self.y_train['classification'])
            
            self.ensemble_models['voting_classifier'] = voting_classifier
        
        if len(regression_models) >= 2:
            voting_regressor = VotingRegressor()
                estimators=regression_models[:5]  # Limit to 5 models
            )
            
            X_train_data = self.X_train_scaled if self.config.scale_features else self.X_train
            voting_regressor.fit(X_train_data, self.y_train['regression'])
            
            self.ensemble_models['voting_regressor'] = voting_regressor
    
    async def _train_stacking_ensembles(self):
        """Train stacking ensemble models"""
        print("   📚 Training stacking ensembles...")
        
        # Simplified stacking with LogisticRegression as meta-learner
        try:
            from sklearn.ensemble import StackingClassifier, StackingRegressor
            
            # Classification stacking
            classification_models = []
                (name.replace('_classification', ''), model) 
                for name, model in self.trained_models.items() 
                if '_classification' in name
            ]
            
            if len(classification_models) >= 2:
                stacking_classifier = StackingClassifier()
                    estimators=classification_models[:3],  # Limit for speed
                    final_estimator=LogisticRegression(random_state=self.config.random_state),
                    cv=3
                )
                
                X_train_data = self.X_train_scaled if self.config.scale_features else self.X_train
                stacking_classifier.fit(X_train_data, self.y_train['classification'])
                
                self.ensemble_models['stacking_classifier'] = stacking_classifier
            
            # Regression stacking
            regression_models = []
                (name.replace('_regression', ''), model)
                for name, model in self.trained_models.items()
                if '_regression' in name
            ]
            
            if len(regression_models) >= 2:
                stacking_regressor = StackingRegressor()
                    estimators=regression_models[:3],  # Limit for speed
                    final_estimator=Ridge(random_state=self.config.random_state),
                    cv=3
                )
                
                X_train_data = self.X_train_scaled if self.config.scale_features else self.X_train
                stacking_regressor.fit(X_train_data, self.y_train['regression'])
                
                self.ensemble_models['stacking_regressor'] = stacking_regressor
        
        except ImportError:
            print("   ⚠️  Stacking ensembles not available in this sklearn version")
    
    async def _phase_5_model_evaluation(self):
        """Phase 5: Evaluate all models"""
        print("\n📊 PHASE 5: MODEL EVALUATION")
        print("-" * 50)
        
        # Evaluate individual models
        print("   📈 Individual model performance:")
        
        best_classification_f1 = 0
        best_regression_r2 = 0
        best_class_model = None
        best_reg_model = None
        
        for model_name, performance in self.model_performances.items():
            if 'classification' in model_name:
                print(f"      {model_name:25} - F1: {performance.val_f1:.3f}, AUC: {performance.val_auc:.3f}")
                if performance.val_f1 > best_classification_f1:
                    best_classification_f1 = performance.val_f1
                    best_class_model = model_name
            else:
                print(f"      {model_name:25} - R²: {performance.val_r2:.3f}, MAE: {performance.val_mae:.2f}")
                if performance.val_r2 > best_regression_r2:
                    best_regression_r2 = performance.val_r2
                    best_reg_model = model_name
        
        # Evaluate ensemble models
        if self.ensemble_models:
            print("   🎭 Ensemble model performance:")
            await self._evaluate_ensemble_models()
        
        print(f"\n   🏆 Best Classification: {best_class_model} (F1: {best_classification_f1:.3f})")
        print(f"   🏆 Best Regression: {best_reg_model} (R²: {best_regression_r2:.3f})")
    
    async def _evaluate_ensemble_models(self):
        """Evaluate ensemble models"""
        
        X_val_data = self.X_val_scaled if self.config.scale_features else self.X_val
        
        for ensemble_name, ensemble_model in self.ensemble_models.items():
            try:
                if 'classifier' in ensemble_name:
                    val_pred = ensemble_model.predict(X_val_data)
                    f1 = f1_score(self.y_val['classification'], val_pred, average='weighted', zero_division=0)
                    acc = accuracy_score(self.y_val['classification'], val_pred)
                    print(f"      {ensemble_name:25} - F1: {f1:.3f}, Acc: {acc:.3f}")
                
                elif 'regressor' in ensemble_name:
                    val_pred = ensemble_model.predict(X_val_data)
                    r2 = r2_score(self.y_val['regression'], val_pred)
                    mae = mean_absolute_error(self.y_val['regression'], val_pred)
                    print(f"      {ensemble_name:25} - R²: {r2:.3f}, MAE: {mae:.2f}")
            
            except Exception as e:
                self.logger.error(f"Error evaluating {ensemble_name}: {e}")
    
    async def _phase_6_deployment_preparation(self):
        """Phase 6: Prepare models for deployment"""
        print("\n🚀 PHASE 6: DEPLOYMENT PREPARATION")
        print("-" * 50)
        
        # Save all trained models
        print("   💾 Saving models...")
        
        # Save individual models
        for model_name, model in self.trained_models.items():
            model_file = self.models_dir / f"{model_name}.joblib"
            joblib.dump(model, model_file)
        
        # Save ensemble models
        for ensemble_name, ensemble_model in self.ensemble_models.items():
            ensemble_file = self.models_dir / f"{ensemble_name}.joblib"
            joblib.dump(ensemble_model, ensemble_file)
        
        # Save scalers and preprocessors
        if self.scalers:
            scalers_file = self.models_dir / "scalers.joblib"
            joblib.dump(self.scalers, scalers_file)
        
        if self.feature_selectors:
            selectors_file = self.models_dir / "feature_selectors.joblib"
            joblib.dump(self.feature_selectors, selectors_file)
        
        # Save feature names
        feature_names_file = self.models_dir / "feature_names.json"
        with open(feature_names_file, 'w') as f:
            json.dump(self.feature_names, f)
        
        # Save model metadata
        metadata = {}
            'config': asdict(self.config),
            'feature_names': self.feature_names,
            'model_performances': {}
                name: asdict(perf) for name, perf in self.model_performances.items()
            },
            'training_timestamp': datetime.now().isoformat()
        }
        
        metadata_file = self.models_dir / "model_metadata.json"
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2, default=str)
        
        print(f"   ✅ Saved {len(self.trained_models + self.ensemble_models)} models")
        print(f"   📁 Models directory: {self.models_dir}")
    
    async def _generate_training_report(self, total_time: float):
        """Generate comprehensive training report"""
        
        print(f"\n🏆 ML TRAINING PIPELINE REPORT")
        print("=" * 80)
        print(f"⏱️  Total Training Time: {total_time/60:.1f} minutes")
        print(f"📊 Models Trained: {len(self.trained_models)}")
        print(f"🎭 Ensemble Models: {len(self.ensemble_models)}")
        print(f"📈 Features Used: {len(self.feature_names)}")
        
        # Training data statistics
        if self.X_train is not None:
            print(f"\n📊 TRAINING DATA:")
            print(f"   Train samples: {len(self.X_train):,}")
            print(f"   Validation samples: {len(self.X_val):,}")
            print(f"   Test samples: {len(self.X_test):,}")
            print(f"   Features: {self.X_train.shape[1]}")
        
        # Best model performance
        if self.model_performances:
            print(f"\n🏆 BEST MODELS:")
            
            # Best classification
            best_class = max()
                [(name, perf) for name, perf in self.model_performances.items() if 'classification' in name],
                key=lambda x: x[1].val_f1,
                default=(None, None)
            )
            
            if best_class[0]:
                print(f"   Classification: {best_class[0]} (F1: {best_class[1].val_f1:.3f})")
            
            # Best regression
            best_reg = max()
                [(name, perf) for name, perf in self.model_performances.items() if 'regression' in name],
                key=lambda x: x[1].val_r2,
                default=(None, None)
            )
            
            if best_reg[0]:
                print(f"   Regression: {best_reg[0]} (R²: {best_reg[1].val_r2:.3f})")
        
        print(f"\n✅ ML TRAINING PIPELINE COMPLETED!")
        print(f"   Models ready for options arbitrage detection")
        print(f"   Deployment files saved to: {self.models_dir}")
        
        # Save comprehensive report
        report = {}
            'training_summary': {}
                'total_time_minutes': total_time / 60,
                'models_trained': len(self.trained_models),
                'ensemble_models': len(self.ensemble_models),
                'features_used': len(self.feature_names)
            },
            'model_performances': {}
                name: asdict(perf) for name, perf in self.model_performances.items()
            },
            'configuration': asdict(self.config),
            'completion_timestamp': datetime.now().isoformat()
        }
        
        report_file = self.models_dir / f"training_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"📄 Detailed report saved: {report_file}")

async def main():
    """Main function to run the ML training pipeline"""
    
    print("🤖 LAUNCHING ML TRAINING PIPELINE")
    print("=" * 80)
    print("📊 Training models on processed options data")
    print("🎯 Multiple algorithms + ensemble methods")
    print("⚡ Optimized for arbitrage detection")
    print("=" * 80)
    
    # Initialize training pipeline
    config = MLTrainingConfig()
    pipeline = MLTrainingPipeline(config)
    
    try:
        # Run the complete ML training pipeline
        await pipeline.run_complete_ml_pipeline()
        
    except Exception as e:
        print(f"ML training failed: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main()