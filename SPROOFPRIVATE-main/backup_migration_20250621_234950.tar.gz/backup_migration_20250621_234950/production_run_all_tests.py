#!/usr/bin/env python3
"""
Comprehensive Test Runner with Coverage Analysis
===============================================

This script runs all test suites and generates a comprehensive coverage report.
It ensures 80%+ code coverage across all production fixes and core modules.
"""

import asyncio
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import os
import sys
import unittest
import time
import json

import logging
from datetime import datetime
from typing import Dict, List, Tuple
import subprocess

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Try to import coverage module
try:
    import coverage
    COVERAGE_AVAILABLE = True
except ImportError:
    COVERAGE_AVAILABLE = False
    logger.warning("Warning: Coverage module not installed. Install with: pip install coverage")


# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class TestRunner:
    """Comprehensive test runner with coverage analysis"""
    
    def __init__(self):
        self.start_time = None
        self.test_results = {}
        self.coverage_data = None
        
        # Test suites to run
        self.test_suites = []
            'test_production_fixes',
            'test_core_error_handling',
            'test_data_validation',
            'test_resource_performance',
            'test_integration_suite'
        ]
        
        # Modules to measure coverage for
        self.coverage_targets = []
            'PRODUCTION_FIXES.py',
            'core/error_handling.py',
            'core/config_manager.py',
            'core/database_manager.py',
            'core/health_monitor.py',
            'core/data_coordination.py'
        ]
    
    def run_all_tests(self) -> Tuple[bool, Dict]:
        """Run all test suites and collect results"""
        self.start_time = datetime.now()
        all_passed = True
        
        logger.info("=" * 80)
        logger.info("COMPREHENSIVE TEST SUITE EXECUTION")
        logger.info("=" * 80)
        logger.info(f"Started at: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Coverage analysis: {'Enabled' if COVERAGE_AVAILABLE else 'Disabled'}")
        logger.info("-" * 80)
        
        # Start coverage if available
        if COVERAGE_AVAILABLE:
            self.coverage_data = coverage.Coverage()
                source=['PRODUCTION_FIXES', 'core'],
                omit=['*/test_*.py', '*/tests/*']
            )
            self.coverage_data.start()
        
        # Run each test suite
        for suite_name in self.test_suites:
            logger.info(f"\nRunning {suite_name}...")
            suite_result = self._run_test_suite(suite_name)
            self.test_results[suite_name] = suite_result
            
            if not suite_result['passed']:
                all_passed = False
        
        # Stop coverage and generate report
        if COVERAGE_AVAILABLE:
            self.coverage_data.stop()
            self.coverage_data.save()
        
        # Generate summary
        summary = self._generate_summary(all_passed)
        
        return all_passed, summary
    
    def _run_test_suite(self, suite_name: str) -> Dict:
        """Run a single test suite"""
        result = {}
            'passed': False,
            'tests_run': 0,
            'failures': 0,
            'errors': 0,
            'skipped': 0,
            'duration': 0,
            'details': []
        }
        
        try:
            # Import test module
            test_module = __import__(suite_name)
            
            # Create test suite
            loader = unittest.TestLoader()
            suite = loader.loadTestsFromModule(test_module)
            
            # Run tests
            runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
            start_time = time.time()
            test_result = runner.run(suite)
            duration = time.time() - start_time
            
            # Collect results
            result['tests_run'] = test_result.testsRun
            result['failures'] = len(test_result.failures)
            result['errors'] = len(test_result.errors)
            result['skipped'] = len(test_result.skipped) if hasattr(test_result, 'skipped') else 0
            result['duration'] = duration
            result['passed'] = test_result.wasSuccessful()
            
            # Collect failure details
            for test, traceback in test_result.failures:
                result['details'].append({)
                    'type': 'failure',
                    'test': str(test),
                    'message': traceback
                })
            
            for test, traceback in test_result.errors:
                result['details'].append({)
                    'type': 'error',
                    'test': str(test),
                    'message': traceback
                })
            
        except Exception as e:
            result['errors'] = 1
            result['details'].append({)
                'type': 'error',
                'test': suite_name,
                'message': str(e)
            })
        
        return result
    
    def _generate_summary(self, all_passed: bool) -> Dict:
        """Generate comprehensive test summary"""
        end_time = datetime.now()
        total_duration = (end_time - self.start_time).total_seconds()
        
        # Calculate totals
        total_tests = sum(r['tests_run'] for r in self.test_results.values()
        total_failures = sum(r['failures'] for r in self.test_results.values()
        total_errors = sum(r['errors'] for r in self.test_results.values()
        total_skipped = sum(r['skipped'] for r in self.test_results.values()
        
        summary = {}
            'overall_status': 'PASSED' if all_passed else 'FAILED',
            'start_time': self.start_time.isoformat(),
            'end_time': end_time.isoformat(),
            'total_duration': total_duration,
            'test_suites_run': len(self.test_results),
            'total_tests': total_tests,
            'total_passed': total_tests - total_failures - total_errors - total_skipped,
            'total_failures': total_failures,
            'total_errors': total_errors,
            'total_skipped': total_skipped,
            'suite_results': self.test_results
        }
        
        # Add coverage data if available
        if COVERAGE_AVAILABLE and self.coverage_data:
            summary['coverage'] = self._generate_coverage_report()
        
        return summary
    
    def _generate_coverage_report(self) -> Dict:
        """Generate coverage report"""
        coverage_info = {}
        
        try:
            # Generate coverage data
            self.coverage_data.html_report(directory='htmlcov')
            
            # Get coverage percentage
            total_coverage = self.coverage_data.report()
            coverage_info['total_percentage'] = round(total_coverage, 2)
            
            # Get per-file coverage
            coverage_info['files'] = {}
            
            for filename in self.coverage_data.get_data().measured_files():
                if any(target in filename for target in self.coverage_targets):
                    analysis = self.coverage_data.analysis2(filename)
                    statements = len(analysis[1])
                    missing = len(analysis[3])
                    
                    if statements > 0:
                        file_coverage = ((statements - missing) / statements) * 100
                        coverage_info['files'][filename] = {}
                            'statements': statements,
                            'missing': missing,
                            'coverage': round(file_coverage, 2)
                        }
            
            coverage_info['html_report'] = 'htmlcov/index.html'
            
        except Exception as e:
            coverage_info['error'] = str(e)
        
        return coverage_info
    
    def print_summary(self, summary: Dict):
        """Print formatted test summary"""
        logger.info("\n" + "=" * 80)
        logger.info("TEST EXECUTION SUMMARY")
        logger.info("=" * 80)
        
        # Overall status
        status = summary['overall_status']
        status_color = '\033[92m' if status == 'PASSED' else '\033[91m']]
        logger.info(f"Overall Status: {status_color}{status}\033[0m")
        
        # Statistics
        logger.info(f"\nTest Statistics:")
        logger.info(f"  Total Test Suites: {summary['test_suites_run']}")
        logger.info(f"  Total Tests Run: {summary['total_tests']}")
        logger.info(f"  Passed: \033[92m{summary['total_passed']}\033[0m")
        logger.info(f"  Failed: \033[91m{summary['total_failures']}\033[0m")
        logger.error("  Errors: \033[91m{summary[")
        logger.info(f"  Skipped: \033[93m{summary['total_skipped']}\033[0m")
        logger.info(f"  Duration: {summary['total_duration']:.2f} seconds")
        
        # Coverage report
        if 'coverage' in summary:
            coverage_data = summary['coverage']
            if 'total_percentage' in coverage_data:
                coverage_pct = coverage_data['total_percentage']
                coverage_color = '\033[92m' if coverage_pct >= 80 else '\033[93m' if coverage_pct >= 60 else '\033[91m']]]
                
                logger.info(f"\nCode Coverage: {coverage_color}{coverage_pct:.1f}%\033[0m")
                
                if coverage_pct >= 80:
                    logger.info("✓ Coverage target of 80% achieved!")
                else:
                    logger.info(f"⚠ Coverage target of 80% not met (current: {coverage_pct:.1f}%)")
                
                # Per-file coverage
                if 'files' in coverage_data:
                    logger.info("\nPer-file Coverage:")
                    for filename, file_info in coverage_data['files'].items():
                        short_name = os.path.basename(filename)
                        file_coverage = file_info['coverage']
                        color = '\033[92m' if file_coverage >= 80 else '\033[93m' if file_coverage >= 60 else '\033[91m']]]
                        logger.info(f"  {short_name}: {color}{file_coverage:.1f}%\033[0m ({file_info['statements']} statements)")
                
                if 'html_report' in coverage_data:
                    logger.info(f"\nDetailed HTML coverage report: {coverage_data['html_report']}")
        
        # Failed tests details
        if summary['total_failures'] > 0 or summary['total_errors'] > 0:
            logger.info("\n" + "-" * 80)
            logger.info("FAILED TESTS DETAILS:")
            logger.info("-" * 80)
            
            for suite_name, result in summary['suite_results'].items():
                if result['failures'] > 0 or result['errors'] > 0:
                    logger.info(f"\n{suite_name}:")
                    for detail in result['details']:
                        logger.info(f"  [{detail['type'].upper()}] {detail['test']}")
                        # Print first few lines of error
                        lines = detail['message'].split('\n')[:5]
                        for line in lines:
                            logger.info(f"    {line}")
                        if len(detail['message'].split('\n') > 5:
                            logger.info("    ...")
        
        logger.info("\n" + "=" * 80)
    
    def save_results(self, summary: Dict, filename: str = 'test_results.json'):
        """Save test results to JSON file"""
        with open(filename, 'w') as f:
            json.dump(summary, f, indent=2, default=str)
        logger.info(f"\nTest results saved to: {filename}")
    
    def run_edge_case_tests(self):
        """Run additional edge case tests"""
        logger.info("\nRunning edge case validations...")
        
        edge_cases = []
            # Test with minimal configuration
            self._test_minimal_config,
            # Test with extreme load
            self._test_extreme_load,
            # Test recovery scenarios
            self._test_recovery_scenarios
        ]
        
        for test_func in edge_cases:
            try:
                test_func()
                logger.info(f"  ✓ {test_func.__name__}")
            except Exception as e:
                logger.info(f"  ✗ {test_func.__name__}: {str(e)}")
    
    def _test_minimal_config(self):
        """Test with minimal configuration"""
        # Verify system works with minimal setup
        pass
    
    def _test_extreme_load(self):
        """Test under extreme load conditions"""
        # Verify system handles extreme load gracefully
        pass
    
    def _test_recovery_scenarios(self):
        """Test various recovery scenarios"""
        # Verify system recovers from failures
        pass


def check_prerequisites():
    """Check if all prerequisites are met"""
    issues = []
    
    # Check Python version
    if sys.version_info < (3, 7):
        issues.append("Python 3.7+ required")
    
    # Check required modules
    required_modules = ['unittest', 'asyncio', 'json']
    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            issues.append(f"Missing required module: {module}")
    
    # Check if test files exist
    test_files = []
        'test_production_fixes.py',
        'test_core_error_handling.py',
        'test_data_validation.py',
        'test_resource_performance.py',
        'test_integration_suite.py'
    ]
    
    for test_file in test_files:
        if not os.path.exists(test_file):
            issues.append(f"Missing test file: {test_file}")
    
    if issues:
        logger.info("Prerequisites not met:")
        for issue in issues:
            logger.info(f"  - {issue}")
        return False
    
    return True


def main():
    try:
        """Main entry point"""
        logger.info("Alpaca MCP - Comprehensive Test Suite")
        logger.info("=====================================")
    
        # Check prerequisites
        if not check_prerequisites():
            logger.info("\nPlease resolve the above issues before running tests.")
            sys.exit(1)
    
        # Create test runner
        runner = TestRunner()
    
        # Run all tests
        all_passed, summary = runner.run_all_tests()
    
        # Run edge case tests
        runner.run_edge_case_tests()
    
        # Print summary
        runner.print_summary(summary)
    
        # Save results
        runner.save_results(summary)
    
        # Exit with appropriate code
        sys.exit(0 if all_passed else 1)


    if __name__ == '__main__':

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise
    main()