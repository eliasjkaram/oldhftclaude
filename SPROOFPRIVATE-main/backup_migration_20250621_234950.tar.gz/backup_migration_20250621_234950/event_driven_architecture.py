#!/usr/bin/env python3
"""
Event-Driven Architecture for Real-Time Options Trading
======================================================
Complete event-driven system with event bus, handlers, saga orchestration,
and distributed event streaming for scalable, reactive trading infrastructure.
"""

import asyncio
import json
import time
import uuid
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Union, Type, Set
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from collections import defaultdict, deque
import logging
import inspect
import pickle
import redis.asyncio as aioredis
import aiokafka
from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
import msgpack
import traceback

# Internal imports
from unified_logging import get_logger
# TODO: Review handle_errors usage - available decorators are: retry, circuit_breaker, timeout
# from unified_error_handling import retry, circuit_breaker, timeout, ErrorCategory, ErrorSeverity

logger = get_logger(__name__)


class EventType(Enum):
    """Core event types in the trading system"""
    # Market Events
    MARKET_DATA_UPDATE = "market.data.update"
    ORDER_BOOK_UPDATE = "market.orderbook.update"
    TRADE_EXECUTED = "market.trade.executed"
    OPTIONS_CHAIN_UPDATE = "market.options.chain"
    VOLATILITY_UPDATE = "market.volatility.update"
    
    # Trading Events
    SIGNAL_GENERATED = "trading.signal.generated"
    ORDER_PLACED = "trading.order.placed"
    ORDER_FILLED = "trading.order.filled"
    ORDER_CANCELLED = "trading.order.cancelled"
    ORDER_REJECTED = "trading.order.rejected"
    POSITION_OPENED = "trading.position.opened"
    POSITION_CLOSED = "trading.position.closed"
    
    # Risk Events
    RISK_LIMIT_BREACH = "risk.limit.breach"
    STOP_LOSS_TRIGGERED = "risk.stoploss.triggered"
    MARGIN_CALL = "risk.margin.call"
    VAR_UPDATE = "risk.var.update"
    
    # Model Events
    MODEL_PREDICTION = "model.prediction"
    MODEL_UPDATED = "model.updated"
    MODEL_DRIFT_DETECTED = "model.drift.detected"
    MODEL_RETRAINED = "model.retrained"
    
    # System Events
    SYSTEM_STARTED = "system.started"
    SYSTEM_STOPPED = "system.stopped"
    SYSTEM_ERROR = "system.error"
    SYSTEM_HEALTH_CHECK = "system.health.check"
    
    # Feature Events
    FEATURES_COMPUTED = "features.computed"
    FEATURES_STORED = "features.stored"
    
    # Alert Events
    ALERT_TRIGGERED = "alert.triggered"
    ALERT_RESOLVED = "alert.resolved"


class EventPriority(Enum):
    """Event priority levels"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class Event:
    """Base event class"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType = EventType.SYSTEM_ERROR
    timestamp: datetime = field(default_factory=datetime.now)
    source: str = "unknown"
    priority: EventPriority = EventPriority.NORMAL
    
    # Event data
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Routing
    correlation_id: Optional[str] = None
    causation_id: Optional[str] = None
    saga_id: Optional[str] = None
    
    # Delivery
    ttl_seconds: Optional[int] = None
    retry_count: int = 0
    max_retries: int = 3
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary"""
        return {}
            'event_id': self.event_id,
            'event_type': self.event_type.value,
            'timestamp': self.timestamp.isoformat(),
            'source': self.source,
            'priority': self.priority.value,
            'data': self.data,
            'metadata': self.metadata,
            'correlation_id': self.correlation_id,
            'causation_id': self.causation_id,
            'saga_id': self.saga_id,
            'ttl_seconds': self.ttl_seconds,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Event':
        """Create event from dictionary"""
        return cls()
            event_id=data.get('event_id', str(uuid.uuid4())),
            event_type=EventType(data['event_type']),
            timestamp=datetime.fromisoformat(data['timestamp']),
            source=data.get('source', 'unknown'),
            priority=EventPriority(data.get('priority', 1)),
            data=data.get('data', {}),
            metadata=data.get('metadata', {}),
            correlation_id=data.get('correlation_id'),
            causation_id=data.get('causation_id'),
            saga_id=data.get('saga_id'),
            ttl_seconds=data.get('ttl_seconds'),
            retry_count=data.get('retry_count', 0),
            max_retries=data.get('max_retries', 3)
        )


class EventHandler(ABC):
    """Abstract base class for event handlers"""
    
    @abstractmethod
    async def handle(self, event: Event) -> Optional[List[Event]]:
        """Handle an event and optionally return new events"""
        pass
    
    @abstractmethod
    def can_handle(self, event: Event) -> bool:
        """Check if this handler can process the event"""
        pass


class EventBus:
    """Central event bus for publishing and subscribing to events"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        
        # Subscribers
        self.handlers: Dict[EventType, List[EventHandler]] = defaultdict(list)
        self.async_handlers: Dict[EventType, List[Callable]] = defaultdict(list)
        
        # Event queue
        self.event_queue: asyncio.Queue = asyncio.Queue()
        self.priority_queues: Dict[EventPriority, asyncio.Queue] = {}
            priority: asyncio.Queue() for priority in EventPriority
        }
        
        # Dead letter queue
        self.dead_letter_queue: deque = deque(maxlen=10000)
        
        # Metrics
        self.event_counts: Dict[EventType, int] = defaultdict(int)
        self.handler_latencies: Dict[str, deque] = defaultdict()
            lambda: deque(maxlen=1000)
        )
        
        # Event store
        self.event_store: Optional[EventStore] = None
        if config.get('enable_event_store', True):
            self.event_store = EventStore(config.get('event_store_config', {}))
        
        # Background tasks
        self._running = False
        self._tasks = []
        
        logger.info("Event Bus initialized")
    
    def subscribe(self, event_type: EventType, handler: EventHandler):
        """Subscribe a handler to an event type"""
        self.handlers[event_type].append(handler)
        logger.info(f"Handler {handler.__class__.__name__} subscribed to {event_type.value}")
    
    def subscribe_async(self, event_type: EventType, handler: Callable):
        """Subscribe an async function to an event type"""
        self.async_handlers[event_type].append(handler)
        logger.info(f"Async handler {handler.__name__} subscribed to {event_type.value}")
    
    async def publish(self, event: Event):
        """Publish an event to the bus"""
        # Validate event
        if not isinstance(event, Event):
            raise ValueError(f"Invalid event type: {type(event)}")
        
        # Add to appropriate queue based on priority
        queue = self.priority_queues[event.priority]
        await queue.put(event)
        
        # Update metrics
        self.event_counts[event.event_type] += 1
        
        # Store event if enabled
        if self.event_store:
            await self.event_store.store(event)
    
    async def start(self):
        """Start the event bus"""
        self._running = True
        
        # Start processor tasks for each priority
        for priority in EventPriority:
            task = asyncio.create_task()
                self._process_events(priority)
            )
            self._tasks.append(task)
        
        # Start metrics reporter
        self._tasks.append()
            asyncio.create_task(self._report_metrics())
        )
        
        logger.info("Event Bus started")
    
    async def stop(self):
        """Stop the event bus"""
        self._running = False
        
        # Cancel all tasks
        for task in self._tasks:
            task.cancel()
        
        await asyncio.gather(*self._tasks, return_exceptions=True)
        
        logger.info("Event Bus stopped")
    
    async def _process_events(self, priority: EventPriority):
        """Process events from a priority queue"""
        queue = self.priority_queues[priority]
        
        while self._running:
            try:
                # Get event with timeout
                event = await asyncio.wait_for()
                    queue.get(),
                    timeout=1.0
                )
                
                # Check TTL
                if event.ttl_seconds:
                    age = (datetime.now() - event.timestamp).total_seconds()
                    if age > event.ttl_seconds:
                        logger.warning(f"Event {event.event_id} expired (TTL={event.ttl_seconds}s)")
                        continue
                
                # Process event
                await self._handle_event(event)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Event processing error: {e}")
    
    async def _handle_event(self, event: Event):
        """Handle a single event"""
        handled = False
        
        # Get handlers for this event type
        handlers = self.handlers.get(event.event_type, [])
        async_handlers = self.async_handlers.get(event.event_type, [])
        
        # Process with EventHandler classes
        for handler in handlers:
            try:
                if handler.can_handle(event):
                    start_time = time.time()
                    
                    # Handle event
                    new_events = await handler.handle(event)
                    
                    # Track latency
                    latency = (time.time() - start_time) * 1000
                    handler_name = handler.__class__.__name__
                    self.handler_latencies[handler_name].append(latency)
                    
                    # Publish any new events
                    if new_events:
                        for new_event in new_events:
                            new_event.causation_id = event.event_id
                            new_event.correlation_id = event.correlation_id or event.event_id
                            await self.publish(new_event)
                    
                    handled = True
                    
            except Exception as e:
                logger.error(f"Handler {handler.__class__.__name__} error: {e}")
                await self._handle_failed_event(event, e)
        
        # Process with async functions
        for handler in async_handlers:
            try:
                start_time = time.time()
                
                # Call handler
                result = await handler(event)
                
                # Track latency
                latency = (time.time() - start_time) * 1000
                handler_name = handler.__name__
                self.handler_latencies[handler_name].append(latency)
                
                handled = True
                
            except Exception as e:
                logger.error(f"Async handler {handler.__name__} error: {e}")
                await self._handle_failed_event(event, e)
        
        if not handled:
            logger.warning(f"No handler for event {event.event_type.value}")
    
    async def _handle_failed_event(self, event: Event, error: Exception):
        """Handle failed event processing"""
        event.retry_count += 1
        
        if event.retry_count <= event.max_retries:
            # Retry with exponential backoff
            delay = 2 ** event.retry_count
            await asyncio.sleep(delay)
            await self.publish(event)
        else:
            # Move to dead letter queue
            self.dead_letter_queue.append({)
                'event': event,
                'error': str(error),
                'timestamp': datetime.now()
            })
            
            # Publish error event
            error_event = Event()
                event_type=EventType.SYSTEM_ERROR,
                source='event_bus',
                data={}
                    'original_event_id': event.event_id,
                    'original_event_type': event.event_type.value,
                    'error': str(error),
                    'traceback': traceback.format_exc()
                },
                priority=EventPriority.HIGH
            )
            await self.publish(error_event)
    
    async def _report_metrics(self):
        """Report event bus metrics"""
        while self._running:
            try:
                metrics = {}
                    'timestamp': datetime.now().isoformat(),
                    'event_counts': dict(self.event_counts),
                    'queue_sizes': {}
                        priority.name: queue.qsize()
                        for priority, queue in self.priority_queues.items()
                    },
                    'dead_letter_count': len(self.dead_letter_queue),
                    'handler_latencies': {}
                }
                
                # Calculate handler latency stats
                for handler_name, latencies in self.handler_latencies.items():
                    if latencies:
                        metrics['handler_latencies'][handler_name] = {}
                            'avg': sum(latencies) / len(latencies),
                            'max': max(latencies),
                            'min': min(latencies)
                        }
                
                logger.info(f"Event Bus Metrics: {json.dumps(metrics)}")
                
                await asyncio.sleep(60)  # Report every minute
                
            except Exception as e:
                logger.error(f"Metrics reporting error: {e}")
                await asyncio.sleep(300)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current event bus metrics"""
        return {}
            'event_counts': dict(self.event_counts),
            'queue_sizes': {}
                priority.name: queue.qsize()
                for priority, queue in self.priority_queues.items()
            },
            'dead_letter_count': len(self.dead_letter_queue),
            'handler_count': sum(len(handlers) for handlers in self.handlers.values())
        }


class EventStore:
    """Persistent event storage"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.storage_backend = config.get('backend', 'redis')
        
        # Initialize storage
        if self.storage_backend == 'redis':
            self.redis_client = None  # Will be initialized async
        
        # In-memory cache
        self.cache: deque = deque(maxlen=10000)
        
    async def initialize(self):
        """Initialize storage connections"""
        if self.storage_backend == 'redis':
            self.redis_client = await aioredis.create_redis_pool()
                self.config.get('redis_url', 'redis://localhost:6379')
            )
    
    async def store(self, event: Event):
        """Store an event"""
        # Add to cache
        self.cache.append(event)
        
        # Persist to backend
        if self.storage_backend == 'redis' and self.redis_client:
            # Store in Redis with expiration
            key = f"event:{event.event_id}"
            value = json.dumps(event.to_dict())
            ttl = self.config.get('event_ttl_seconds', 86400)  # 24 hours default
            
            await self.redis_client.setex(key, ttl, value)
            
            # Add to event stream
            stream_key = f"event_stream:{event.event_type.value}"
            await self.redis_client.xadd()
                stream_key,
                {'data': value},
                max_len=10000  # Keep last 10k events per type
            )
    
    async def get_event(self, event_id: str) -> Optional[Event]:
        """Retrieve an event by ID"""
        # Check cache first
        for event in self.cache:
            if event.event_id == event_id:
                return event
        
        # Check backend
        if self.storage_backend == 'redis' and self.redis_client:
            key = f"event:{event_id}"
            value = await self.redis_client.get(key)
            
            if value:
                data = json.loads(value)
                return Event.from_dict(data)
        
        return None
    
    async def get_events_by_type()
        self,
        event_type: EventType,
        limit: int = 100,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[Event]:
        """Get events by type within time range"""
        events = []
        
        # Filter from cache
        for event in self.cache:
            if event.event_type == event_type:
                if start_time and event.timestamp < start_time:
                    continue
                if end_time and event.timestamp > end_time:
                    continue
                events.append(event)
                if len(events) >= limit:
                    break
        
        # If need more, query backend
        if len(events) < limit and self.storage_backend == 'redis' and self.redis_client:
            stream_key = f"event_stream:{event_type.value}"
            
            # Read from stream
            messages = await self.redis_client.xread()
                [stream_key],
                count=limit - len(events)
            )
            
            for stream, stream_messages in messages:
                for msg_id, msg_data in stream_messages:
                    data = json.loads(msg_data[b'data'])
                    event = Event.from_dict(data)
                    
                    if start_time and event.timestamp < start_time:
                        continue
                    if end_time and event.timestamp > end_time:
                        continue
                    
                    events.append(event)
        
        return events[:limit]


class Saga:
    """Base class for implementing sagas (long-running transactions)"""
    
    def __init__(self, saga_id: str, event_bus: EventBus):
        self.saga_id = saga_id
        self.event_bus = event_bus
        self.state: Dict[str, Any] = {}
        self.completed = False
        self.compensating = False
        
    @abstractmethod
    async def handle_event(self, event: Event) -> List[Event]:
        """Handle an event and return new events"""
        pass
    
    @abstractmethod
    async def compensate(self):
        """Compensate (rollback) the saga"""
        pass
    
    def is_complete(self) -> bool:
        """Check if saga is complete"""
        return self.completed


class SagaOrchestrator:
    """Orchestrates saga execution"""
    
    def __init__(self, event_bus: EventBus):
        self.event_bus = event_bus
        self.active_sagas: Dict[str, Saga] = {}
        self.saga_types: Dict[EventType, Type[Saga]] = {}
        
    def register_saga(self, trigger_event: EventType, saga_class: Type[Saga]):
        """Register a saga type"""
        self.saga_types[trigger_event] = saga_class
        
        # Subscribe to trigger event
        self.event_bus.subscribe_async(trigger_event, self._handle_saga_trigger)
    
    async def _handle_saga_trigger(self, event: Event):
        """Handle saga trigger event"""
        if event.event_type in self.saga_types:
            # Create new saga instance
            saga_id = str(uuid.uuid4())
            saga_class = self.saga_types[event.event_type]
            saga = saga_class(saga_id, self.event_bus)
            
            # Store saga
            self.active_sagas[saga_id] = saga
            
            # Set saga ID on event
            event.saga_id = saga_id
            
            # Handle initial event
            try:
                new_events = await saga.handle_event(event)
                
                # Publish new events
                for new_event in new_events:
                    new_event.saga_id = saga_id
                    await self.event_bus.publish(new_event)
                    
            except Exception as e:
                logger.error(f"Saga {saga_id} error: {e}")
                await saga.compensate()
                del self.active_sagas[saga_id]
    
    async def handle_saga_event(self, event: Event):
        """Handle event for existing saga"""
        if event.saga_id and event.saga_id in self.active_sagas:
            saga = self.active_sagas[event.saga_id]
            
            try:
                new_events = await saga.handle_event(event)
                
                # Publish new events
                for new_event in new_events:
                    new_event.saga_id = event.saga_id
                    await self.event_bus.publish(new_event)
                
                # Check if saga is complete
                if saga.is_complete():
                    del self.active_sagas[event.saga_id]
                    logger.info(f"Saga {event.saga_id} completed")
                    
            except Exception as e:
                logger.error(f"Saga {event.saga_id} error: {e}")
                await saga.compensate()
                del self.active_sagas[event.saga_id]


class EventStreamProcessor:
    """Processes event streams with windowing and aggregation"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.window_size = config.get('window_size_seconds', 60)
        self.slide_interval = config.get('slide_interval_seconds', 10)
        
        # Windows
        self.windows: Dict[str, deque] = defaultdict()
            lambda: deque(maxlen=1000)
        )
        
        # Aggregators
        self.aggregators: Dict[str, Callable] = {}
        
    def register_aggregator()
        self,
        name: str,
        event_filter: Callable[[Event], bool],
        aggregator: Callable[[List[Event]], Any]
    ):
        """Register an aggregator function"""
        self.aggregators[name] = {}
            'filter': event_filter,
            'function': aggregator
        }
    
    async def process_event(self, event: Event):
        """Process an event through aggregators"""
        # Add to windows
        for name, aggregator_info in self.aggregators.items():
            if aggregator_info['filter'](event):
                self.windows[name].append(event)
    
    async def compute_aggregates(self) -> Dict[str, Any]:
        """Compute current aggregates"""
        results = {}
        current_time = datetime.now()
        
        for name, aggregator_info in self.aggregators.items():
            # Get events in window
            window_start = current_time - timedelta(seconds=self.window_size)
            window_events = []
                e for e in self.windows[name]
                if e.timestamp >= window_start
            ]
            
            # Compute aggregate
            if window_events:
                try:
                    result = aggregator_info['function'](window_events)
                    results[name] = result
                except Exception as e:
                    logger.error(f"Aggregator {name} error: {e}")
        
        return results


class KafkaEventBridge:
    """Bridge between EventBus and Kafka for distributed event streaming"""
    
    def __init__(self, event_bus: EventBus, config: Dict[str, Any]):
        self.event_bus = event_bus
        self.config = config
        
        # Kafka configuration
        self.bootstrap_servers = config.get('bootstrap_servers', 'localhost:9092')
        self.topic_prefix = config.get('topic_prefix', 'trading')
        
        # Producers and consumers
        self.producer: Optional[AIOKafkaProducer] = None
        self.consumers: Dict[str, AIOKafkaConsumer] = {}
        
        # Serialization
        self.serializer = config.get('serializer', 'json')  # json or msgpack
        
        self._running = False
        self._tasks = []
    
    async def start(self):
        """Start Kafka bridge"""
        self._running = True
        
        # Start producer
        self.producer = AIOKafkaProducer()
            bootstrap_servers=self.bootstrap_servers,
            value_serializer=self._serialize_event
        )
        await self.producer.start()
        
        # Subscribe to all event types
        for event_type in EventType:
            self.event_bus.subscribe_async(event_type, self._publish_to_kafka)
        
        # Start consumers for configured topics
        topics = self.config.get('subscribe_topics', [])
        for topic in topics:
            task = asyncio.create_task(self._consume_from_kafka(topic))
            self._tasks.append(task)
        
        logger.info("Kafka Event Bridge started")
    
    async def stop(self):
        """Stop Kafka bridge"""
        self._running = False
        
        # Stop consumers
        for consumer in self.consumers.values():
            await consumer.stop()
        
        # Stop producer
        if self.producer:
            await self.producer.stop()
        
        # Cancel tasks
        for task in self._tasks:
            task.cancel()
        
        await asyncio.gather(*self._tasks, return_exceptions=True)
        
        logger.info("Kafka Event Bridge stopped")
    
    async def _publish_to_kafka(self, event: Event):
        """Publish event to Kafka"""
        if not self.producer:
            return
        
        try:
            # Determine topic
            topic = f"{self.topic_prefix}.{event.event_type.value}"
            
            # Send to Kafka
            await self.producer.send()
                topic,
                value=event,
                key=event.event_id.encode() if event.event_id else None
            )
            
        except Exception as e:
            logger.error(f"Kafka publish error: {e}")
    
    async def _consume_from_kafka(self, topic: str):
        """Consume events from Kafka topic"""
        consumer = AIOKafkaConsumer()
            topic,
            bootstrap_servers=self.bootstrap_servers,
            value_deserializer=self._deserialize_event,
            group_id=f"{self.config.get('consumer_group', 'trading-system')}-{topic}"
        )
        
        self.consumers[topic] = consumer
        await consumer.start()
        
        try:
            async for msg in consumer:
                if not self._running:
                    break
                
                try:
                    event = msg.value
                    if isinstance(event, Event):
                        # Publish to local event bus
                        await self.event_bus.publish(event)
                    
                except Exception as e:
                    logger.error(f"Kafka message processing error: {e}")
                    
        finally:
            await consumer.stop()
    
    def _serialize_event(self, event: Event) -> bytes:
        """Serialize event for Kafka"""
        if self.serializer == 'json':
            return json.dumps(event.to_dict()).encode()
        elif self.serializer == 'msgpack':
            return msgpack.packb(event.to_dict())
        else:
            return pickle.dumps(event)
    
    def _deserialize_event(self, data: bytes) -> Event:
        """Deserialize event from Kafka"""
        try:
            if self.serializer == 'json':
                event_dict = json.loads(data.decode())
            elif self.serializer == 'msgpack':
                event_dict = msgpack.unpackb(data)
            else:
                return pickle.loads(data)
            
            return Event.from_dict(event_dict)
            
        except Exception as e:
            logger.error(f"Event deserialization error: {e}")
            raise


# Example event handlers
class MarketDataHandler(EventHandler):
    """Handles market data update events"""
    
    def __init__(self, feature_engine):
        self.feature_engine = feature_engine
    
    async def handle(self, event: Event) -> Optional[List[Event]]:
        """Process market data and compute features"""
        market_data = event.data
        
        # Compute features
        features = await self.feature_engine.compute_features(market_data)
        
        # Create feature event
        feature_event = Event()
            event_type=EventType.FEATURES_COMPUTED,
            source='market_data_handler',
            data={'features': features, 'symbol': market_data.get('symbol')},
            correlation_id=event.correlation_id
        )
        
        return [feature_event]
    
    def can_handle(self, event: Event) -> bool:
        return event.event_type == EventType.MARKET_DATA_UPDATE


class TradingSignalHandler(EventHandler):
    """Handles trading signal events"""
    
    def __init__(self, execution_engine, risk_manager):
        self.execution_engine = execution_engine
        self.risk_manager = risk_manager
    
    async def handle(self, event: Event) -> Optional[List[Event]]:
        """Process trading signal and execute if approved"""
        signal = event.data
        
        # Risk check
        risk_approved = await self.risk_manager.check_trade(signal)
        
        if not risk_approved:
            # Create rejection event
            return [Event()
                event_type=EventType.ORDER_REJECTED,
                source='trading_signal_handler',
                data={'reason': 'risk_check_failed', 'signal': signal},
                correlation_id=event.correlation_id
            )]
        
        # Execute order
        order_result = await self.execution_engine.execute_order(signal)
        
        # Create order event
        order_event = Event()
            event_type=EventType.ORDER_PLACED,
            source='trading_signal_handler',
            data=order_result,
            correlation_id=event.correlation_id
        )
        
        return [order_event]
    
    def can_handle(self, event: Event) -> bool:
        return event.event_type == EventType.SIGNAL_GENERATED


# Example saga implementation
class OptionTradeSaga(Saga):
    """Saga for executing option trades with proper cleanup"""
    
    async def handle_event(self, event: Event) -> List[Event]:
        new_events = []
        
        if event.event_type == EventType.SIGNAL_GENERATED and not self.state.get('order_placed'):
            # Initial signal - place order
            self.state['signal'] = event.data
            
            order_event = Event()
                event_type=EventType.ORDER_PLACED,
                source='option_trade_saga',
                data={}
                    'symbol': event.data['symbol'],
                    'action': event.data['action'],
                    'quantity': event.data['quantity']
                }
            )
            
            self.state['order_placed'] = True
            new_events.append(order_event)
            
        elif event.event_type == EventType.ORDER_FILLED:
            # Order filled - update position
            self.state['order_filled'] = True
            self.state['fill_price'] = event.data['price']
            
            position_event = Event()
                event_type=EventType.POSITION_OPENED,
                source='option_trade_saga',
                data={}
                    'symbol': event.data['symbol'],
                    'quantity': event.data['quantity'],
                    'entry_price': event.data['price']
                }
            )
            
            new_events.append(position_event)
            self.completed = True
            
        elif event.event_type == EventType.ORDER_REJECTED:
            # Order rejected - saga failed
            self.state['failed'] = True
            self.completed = True
        
        return new_events
    
    async def compensate(self):
        """Compensate the saga by cancelling orders or closing positions"""
        if self.state.get('order_placed') and not self.state.get('order_filled'):
            # Cancel pending order
            cancel_event = Event()
                event_type=EventType.ORDER_CANCELLED,
                source='option_trade_saga',
                data={'order_id': self.state.get('order_id')},
                priority=EventPriority.HIGH
            )
            await self.event_bus.publish(cancel_event)
            
        elif self.state.get('order_filled'):
            # Close position
            close_event = Event()
                event_type=EventType.POSITION_CLOSED,
                source='option_trade_saga',
                data={}
                    'symbol': self.state['signal']['symbol'],
                    'reason': 'saga_compensation'
                },
                priority=EventPriority.HIGH
            )
            await self.event_bus.publish(close_event)


# Example aggregators
def trade_volume_aggregator(events: List[Event]) -> Dict[str, float]:
    """Aggregate trade volumes by symbol"""
    volumes = defaultdict(float)
    
    for event in events:
        if 'symbol' in event.data and 'volume' in event.data:
            volumes[event.data['symbol']] += event.data['volume']
    
    return dict(volumes)


def signal_count_aggregator(events: List[Event]) -> Dict[str, int]:
    """Count signals by type"""
    counts = defaultdict(int)
    
    for event in events:
        if 'action' in event.data:
            counts[event.data['action']] += 1
    
    return dict(counts)


# Helper function to create common events
def create_market_data_event()
    symbol: str,
    price: float,
    volume: int,
    **kwargs
) -> Event:
    """Create a market data update event"""
    return Event()
        event_type=EventType.MARKET_DATA_UPDATE,
        source='market_data_feed',
        data={}
            'symbol': symbol,
            'price': price,
            'volume': volume,
            'timestamp': datetime.now(),
            **kwargs
        }
    )


def create_trading_signal_event()
    symbol: str,
    action: str,
    quantity: int,
    confidence: float,
    **kwargs
) -> Event:
    """Create a trading signal event"""
    return Event()
        event_type=EventType.SIGNAL_GENERATED,
        source='signal_generator',
        data={}
            'symbol': symbol,
            'action': action,
            'quantity': quantity,
            'confidence': confidence,
            'timestamp': datetime.now(),
            **kwargs
        },
        priority=EventPriority.HIGH
    )


# Example usage and integration
if __name__ == "__main__":
    import asyncio
    
    async def demo_event_driven_system():
        """Demonstrate event-driven architecture capabilities"""
        
        # Initialize event bus
        event_bus = EventBus({)
            'enable_event_store': True,
            'event_store_config': {}
                'backend': 'redis',
                'redis_url': 'redis://localhost:6379',
                'event_ttl_seconds': 86400
            }
        })
        
        # Start event bus
        await event_bus.start()
        
        # Initialize components
        class MockFeatureEngine:
            async def compute_features(self, data):
                return {'features': np.random.randn(100).tolist()}
        
        class MockExecutionEngine:
            async def execute_order(self, signal):
                return {}
                    'order_id': str(uuid.uuid4()),
                    'status': 'placed',
                    'symbol': signal['symbol'],
                    'quantity': signal['quantity']
                }
        
        class MockRiskManager:
            async def check_trade(self, signal):
                return signal['confidence'] > 0.7
        
        # Create handlers
        market_handler = MarketDataHandler(MockFeatureEngine())
        signal_handler = TradingSignalHandler()
            MockExecutionEngine(),
            MockRiskManager()
        )
        
        # Subscribe handlers
        event_bus.subscribe(EventType.MARKET_DATA_UPDATE, market_handler)
        event_bus.subscribe(EventType.SIGNAL_GENERATED, signal_handler)
        
        # Initialize saga orchestrator
        saga_orchestrator = SagaOrchestrator(event_bus)
        saga_orchestrator.register_saga()
            EventType.SIGNAL_GENERATED,
            OptionTradeSaga
        )
        
        # Initialize stream processor
        stream_processor = EventStreamProcessor({)
            'window_size_seconds': 60,
            'slide_interval_seconds': 10
        })
        
        # Register aggregators
        stream_processor.register_aggregator()
            'trade_volume',
            lambda e: e.event_type == EventType.TRADE_EXECUTED,
            trade_volume_aggregator
        )
        
        stream_processor.register_aggregator()
            'signal_count',
            lambda e: e.event_type == EventType.SIGNAL_GENERATED,
            signal_count_aggregator
        )
        
        # Subscribe stream processor
        async def process_stream(event):
            await stream_processor.process_event(event)
        
        for event_type in EventType:
            event_bus.subscribe_async(event_type, process_stream)
        
        # Initialize Kafka bridge (if Kafka is available)
        # kafka_bridge = KafkaEventBridge(event_bus, {)
        #     'bootstrap_servers': 'localhost:9092',
        #     'topic_prefix': 'trading',
        #     'subscribe_topics': ['external.market.data'],
        #     'serializer': 'json'
        # })
        # await kafka_bridge.start()
        
        print("Event-Driven Architecture Demo")
        print("=" * 50)
        
        # Simulate market data events
        symbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'SPY']
        
        for i in range(10):
            # Create market data event
            symbol = np.random.choice(symbols)
            market_event = create_market_data_event()
                symbol=symbol,
                price=100 + np.random.randn() * 5,
                volume=int(np.random.exponential(1000)),
                bid=99.5 + np.random.randn() * 0.5,
                ask=100.5 + np.random.randn() * 0.5
            )
            
            await event_bus.publish(market_event)
            print(f"Published market data for {symbol}")
            
            # Randomly generate trading signals
            if np.random.random() > 0.6:
                signal_event = create_trading_signal_event()
                    symbol=symbol,
                    action=np.random.choice(['buy', 'sell']),
                    quantity=int(np.random.uniform(10, 100)),
                    confidence=np.random.uniform(0.5, 0.95),
                    strategy='momentum'
                )
                
                await event_bus.publish(signal_event)
                print(f"Generated trading signal for {symbol}")
            
            # Small delay
            await asyncio.sleep(0.1)
        
        # Wait for processing
        await asyncio.sleep(2)
        
        # Get metrics
        print("\nEvent Bus Metrics:")
        metrics = event_bus.get_metrics()
        for key, value in metrics.items():
            print(f"  {key}: {value}")
        
        # Get aggregates
        print("\nStream Aggregates:")
        aggregates = await stream_processor.compute_aggregates()
        for name, result in aggregates.items():
            print(f"  {name}: {result}")
        
        # Simulate order fill event
        fill_event = Event()
            event_type=EventType.ORDER_FILLED,
            source='exchange',
            data={}
                'order_id': str(uuid.uuid4()),
                'symbol': 'AAPL',
                'quantity': 100,
                'price': 150.25,
                'timestamp': datetime.now()
            }
        )
        await event_bus.publish(fill_event)
        
        # Simulate risk event
        risk_event = Event()
            event_type=EventType.RISK_LIMIT_BREACH,
            source='risk_manager',
            data={}
                'limit_type': 'position_size',
                'symbol': 'TSLA',
                'current_value': 1000000,
                'limit': 500000
            },
            priority=EventPriority.CRITICAL
        )
        await event_bus.publish(risk_event)
        
        # Wait for final processing
        await asyncio.sleep(1)
        
        print("\nDead Letter Queue:")
        print(f"  Items: {len(event_bus.dead_letter_queue)}")
        
        # Stop services
        # await kafka_bridge.stop()
        await event_bus.stop()
        
        print("\nDemo completed successfully!")
    
    # Run demo
    asyncio.run(demo_event_driven_system())
class EventDrivenArchitecture:
    """Stub implementation for EventDrivenArchitecture"""
    def __init__(self, *args, **kwargs):
        self.config = kwargs
        print(f"Initialized {self.__class__.__name__}")
    
    def run(self):
        print(f"Running {self.__class__.__name__}")
        return True

__all__ = ["EventDrivenArchitecture"]
