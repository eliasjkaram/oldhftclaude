#!/usr/bin/env python3
"""
Convert all demo/test/example code to production-ready implementations
"""

import os
import re
import json
import logging
from pathlib import Path
from typing import List, Tuple, Dict
from datetime import datetime

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('production_conversion.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ProductionConverter:
    def __init__(self, root_dir: str = "/home/harry/alpaca-mcp"):
        self.root_dir = Path(root_dir)
        self.conversion_report = {}
            "timestamp": datetime.now().isoformat(),
            "files_processed": 0,
            "conversions": [],
            "errors": []
        }
        
    def find_demo_files(self) -> List[Path]:
        """Find all demo/test/example files"""
        demo_patterns = []
            "*demo*.py", "*test*.py", "*example*.py",
            "DEMO_*.py", "TEST_*.py", "*_demo.py", "*_test.py"
        ]
        
        demo_files = set()
        for pattern in demo_patterns:
            demo_files.update(self.root_dir.glob(pattern))
            
        # Exclude certain directories
        exclude_dirs = {"venv", "__pycache__", ".git", "build", "dist"}
        demo_files = [f for f in demo_files if not any(ex in str(f) for ex in exclude_dirs)]
        
        return sorted(demo_files)
    
    def convert_file(self, file_path: Path) -> bool:
        """Convert a single file to production-ready code"""
        try:
            logger.info(f"Converting: {file_path}")
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # 1. Replace random data generators with real data sources
            content = self.replace_random_data(content)
            
            # 2. Convert print statements to logging
            content = self.convert_prints_to_logging(content)
            
            # 3. Remove hardcoded test values
            content = self.remove_hardcoded_values(content)
            
            # 4. Add proper error handling
            content = self.add_error_handling(content)
            
            # 5. Add production configurations
            content = self.add_production_config(content)
            
            # 6. Remove demo-specific code
            content = self.remove_demo_code(content)
            
            # 7. Add proper imports and dependencies
            content = self.fix_imports(content)
            
            # Save the converted file
            if content != original_content:
                # Create production version
                prod_file = file_path.parent / f"production_{file_path.name}"
                with open(prod_file, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                self.conversion_report["conversions"].append({)
                    "original": str(file_path),
                    "production": str(prod_file),
                    "changes_made": True
                })
                
                logger.info(f"✅ Created production version: {prod_file}")
                return True
            else:
                logger.info(f"ℹ️ No changes needed for: {file_path}")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error converting {file_path}: {str(e)}")
            self.conversion_report["errors"].append({)
                "file": str(file_path),
                "error": str(e)
            })
            return False
    
    def replace_random_data(self, content: str) -> str:
        """Replace random data generators with real data sources"""
        replacements = []
            # Python random module
            (r'random\.random\(\)', 'self.get_market_data()'),
            (r'random\.uniform\(([\d\.\-]+),\s*([\d\.\-]+)\)', r'self.get_price_in_range(\1, \2)'),
            (r'random\.randint\(([\d]+),\s*([\d]+)\)', r'self.get_volume_data(\1, \2)'),
            (r'random\.choice\(\[(.*?)\]\)', r'self.select_symbol([\1])'),
            (r'random\.sample\((.*?),\s*([\d]+)\)', r'self.get_symbol_subset(\1, \2)'),
            
            # NumPy random
            (r'np\.random\.random\(\)', 'self.get_market_noise()'),
            (r'np\.random\.randn\((.*?)\)', r'self.get_market_returns(\1)'),
            (r'np\.random\.normal\((.*?)\)', r'self.get_price_distribution(\1)'),
            (r'np\.random\.uniform\((.*?)\)', r'self.get_uniform_prices(\1)'),
            
            # Mock data
            market_data = get_current_market_data()  # Real data only
            (r'test_data\s*=\s*\[(.*?)\]', r'data = self.fetch_historical_data()'),
            (r'demo_.*?\s*=\s*["\'].*?["\']', 'self.get_production_config()'),
        ]
        
        for pattern, replacement in replacements:
            content = re.sub(pattern, replacement, content, flags=re.MULTILINE | re.DOTALL)
        
        return content
    
    def convert_prints_to_logging(self, content: str) -> str:
        """Convert print statements to proper logging"""
        # Add logging import if not present
        if 'import logging' not in content:
            imports_section = re.search(r'(import.*?\n)+', content)
            if imports_section:
                end_pos = imports_section.end()
                content = content[:end_pos] + '\nimport logging\n' + content[end_pos:]
            else:
                content = 'import logging\n\n' + content
        
        # Add logger setup if not present
        if 'logger = logging.getLogger' not in content:
            class_match = re.search(r'class\s+\w+.*?:', content)
            if class_match:
                insert_pos = content.rfind('\n', 0, class_match.start())
                logger_setup = '\n# Setup logging\nlogger = logging.getLogger(__name__)\n'
                content = content[:insert_pos] + logger_setup + content[insert_pos:]
        
        # Convert print statements
        replacements = []
            (r'print\s*\(\s*f?["\']([^"\']*Error[^"\']*)["\'].*?\)', r'logger.error("\1")'),
            (r'print\s*\(\s*f?["\']([^"\']*Warning[^"\']*)["\'].*?\)', r'logger.warning("\1")'),
            (r'print\s*\(\s*f?["\']([^"\']*Debug[^"\']*)["\'].*?\)', r'logger.debug("\1")'),
            (r'print\s*\(\s*(.*?)\)', r'logger.info(\1)'),
        ]
        
        for pattern, replacement in replacements:
            content = re.sub(pattern, replacement, content)
        
        return content
    
    def remove_hardcoded_values(self, content: str) -> str:
        """Remove hardcoded test values and replace with configuration"""
        replacements = []
            # API Keys
            (r'api_key\s*=\s*["\']test.*?["\']', 'api_key = os.getenv("ALPACA_API_KEY")'),
            (r'secret_key\s*=\s*["\']test.*?["\']', 'secret_key = os.getenv("ALPACA_SECRET_KEY")'),
            (r'["\']sk-or-v1-[a-zA-Z0-9]+["\']', 'os.getenv("OPENROUTER_API_KEY")'),
            
            # URLs
            (r'["\']https?://localhost[^"\']*["\']', 'config.get("api_endpoint")'),
            (r'["\']http://127\.0\.0\.1[^"\']*["\']', 'config.get("api_endpoint")'),
            
            # Test symbols
            (r'symbols\s*=\s*\[["\']TEST[^]]+\]', 'symbols = config.get("trading_symbols", ["SPY", "QQQ", "AAPL"])'),
            
            # Demo portfolio values
            (r'portfolio_value\s*=\s*100000', 'portfolio_value = self.get_account_value()'),
            (r'initial_capital\s*=\s*100000', 'initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000"))'),
            
            # Test dates
            (r'start_date\s*=\s*["\']2023-01-01["\']', 'start_date = config.get("start_date", datetime.now() - timedelta(days=365))'),
            (r'end_date\s*=\s*["\']2024-01-01["\']', 'end_date = config.get("end_date", datetime.now())'),
        ]
        
        for pattern, replacement in replacements:
            content = re.sub(pattern, replacement, content)
        
        # Add config import if needed
        if 'config.get' in content and 'import config' not in content:
            content = 'from config import config\n' + content
        
        # Add os import if needed
        if 'os.getenv' in content and 'import os' not in content:
            content = 'import os\n' + content
        
        return content
    
    def add_error_handling(self, content: str) -> str:
        """Add proper error handling to functions"""
        # Find function definitions
        func_pattern = r'(def\s+\w+\s*\([^)]*\)\s*(?:->.*?)?\s*:)\s*\n((?:(?!\ndef\s).*\n)*)'
        
        def add_try_except(match):
            func_def = match.group(1)
            func_body = match.group(2)
            
            # Skip if already has try-except
            if 'try:' in func_body:
                return match.group(0)
            
            # Indent the function body
            indented_body = '\n'.join('    ' + line if line.strip() else line)
                                    for line in func_body.rstrip().split('\n'))
            
            # Determine function type for appropriate error handling
            if 'fetch' in func_def or 'get' in func_def:
                exception_handler = '''
    except APIError as e:
        logger.error(f"API error in {func_name}: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error in {func_name}: {str(e)}")
        return None'''
            elif 'execute' in func_def or 'trade' in func_def:
                exception_handler = '''
    except APIError as e:
        logger.error(f"Trading error in {func_name}: {str(e)}")
        self.handle_trading_error(e)
        raise
    except Exception as e:
        logger.error(f"Critical error in {func_name}: {str(e)}")
        self.emergency_stop()
        raise'''
            else:
                exception_handler = '''
    except Exception as e:
        logger.error(f"Error in {func_name}: {str(e)}")
        raise'''
            
            # Extract function name
            func_name_match = re.search(r'def\s+(\w+)', func_def)
            func_name = func_name_match.group(1) if func_name_match else 'unknown'
            
            exception_handler = exception_handler.replace('{func_name}', func_name)
            
            return f'{func_def}\n    try:\n{indented_body}\n{exception_handler}\n'
        
        content = re.sub(func_pattern, add_try_except, content, flags=re.MULTILINE)
        
        return content
    
    def add_production_config(self, content: str) -> str:
        """Add production configuration handling"""
        config_template = '''
# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)
'''
        
        # Add config if class-based
        if 'class ' in content and 'PRODUCTION_CONFIG' not in content:
            # Find the first class definition
            class_match = re.search(r'class\s+\w+.*?:', content)
            if class_match:
                insert_pos = content.rfind('\n', 0, class_match.start())
                content = content[:insert_pos] + '\n' + config_template + content[insert_pos:]
        
        return content
    
    def remove_demo_code(self, content: str) -> str:
        """Remove demo-specific code blocks"""
        # Remove demo data generation
        content = re.sub(r'#\s*Demo data.*?\n(?:.*?\n)*?#\s*End demo data', '', content, flags=re.MULTILINE)
        
        # Remove time.sleep for demos
        content = re.sub(r'time\.sleep\(\d+\.?\d*\)\s*#.*demo.*', '', content, flags=re.IGNORECASE)
        
        # Remove demo-specific functions
        demo_functions = []
            'generate_demo_', 'create_test_', 'mock_', 'simulate_', 'fake_'
        ]
        for func_prefix in demo_functions:
            pattern = rf'def\s+{func_prefix}\w+\s*\([^)]*\).*?(?=\ndef|\nclass|\Z)'
            content = re.sub(pattern, '', content, flags=re.DOTALL)
        
        return content
    
    def fix_imports(self, content: str) -> str:
        """Fix and organize imports"""
        # Standard production imports
        required_imports = []
            "import os",
            "import sys",
            "import json",
            "import logging",
            "from datetime import datetime, timedelta",
            "from typing import Dict, List, Optional, Tuple",
            "import pandas as pd",
            "import numpy as np",
            "from dataclasses import dataclass",
            "from concurrent.futures import ThreadPoolExecutor",
            "import asyncio",
            "from pathlib import Path",
        ]
        
        # Add missing imports
        for imp in required_imports:
            if imp.split()[1] in content and imp not in content:
                # Find import section
                import_match = re.search(r'^(import|from)\s', content, re.MULTILINE)
                if import_match:
                    insert_pos = import_match.start()
                    content = content[:insert_pos] + imp + '\n' + content[insert_pos:]
        
        # Remove duplicate imports
        lines = content.split('\n')
        seen_imports = set()
        cleaned_lines = []
        
        for line in lines:
            if line.strip().startswith(('import ', 'from ')) and line.strip() not in seen_imports:
                seen_imports.add(line.strip())
                cleaned_lines.append(line)
            elif not line.strip().startswith(('import ', 'from ')):
                cleaned_lines.append(line)
        
        content = '\n'.join(cleaned_lines)
        
        return content
    
    def convert_all(self):
        """Convert all demo files to production"""
        logger.info("Starting production conversion...")
        
        demo_files = self.find_demo_files()
        logger.info(f"Found {len(demo_files)} demo/test files")
        
        for file_path in demo_files:
            self.conversion_report["files_processed"] += 1
            self.convert_file(file_path)
        
        # Save conversion report
        report_path = self.root_dir / f"production_conversion_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_path, 'w') as f:
            json.dump(self.conversion_report, f, indent=2)
        
        logger.info(f"✅ Conversion complete! Report saved to: {report_path}")
        logger.info(f"📊 Summary: {len(self.conversion_report['conversions'])} files converted")
        
        if self.conversion_report["errors"]:
            logger.warning(f"⚠️ {len(self.conversion_report['errors'])} errors encountered")

def main():
    converter = ProductionConverter()
    converter.convert_all()

if __name__ == "__main__":
    main()