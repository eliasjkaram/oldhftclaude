import sys
import os
#!/usr/bin/env python3
"""
Test script for Alpaca backtesting system
"""

import asyncio
import json

import logging
from datetime import datetime, timedelta
from v21_alpaca_backtest_system import BacktestConfig, AlpacaBacktester

async def test_backtest():
    try:
        """Run a quick test of the backtesting system"""
    
        # Use a shorter time period for testing
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
    
        config = BacktestConfig()
            start_date=start_date.strftime('%Y-%m-%d'),
            end_date=end_date.strftime('%Y-%m-%d'),
            initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000")),
            commission=0.001,
            data_cache_dir='test_cache'
        )
    
        # Test with just a few symbols and algorithms
        test_symbols = ['AAPL', 'MSFT', 'SPY']
        test_algorithms = ['RSI_Oversold', 'MACD_Crossover', 'Mean_Reversion', 'Momentum_Alpha']
    
        logger.info("\n" + "="*60)
        logger.info("🧪 ALPACA BACKTEST SYSTEM TEST")
        logger.info("="*60)
        logger.info(f"📅 Period: {config.start_date} to {config.end_date}")
        logger.info(f"📊 Symbols: {test_symbols}")
        logger.info(f"🤖 Algorithms: {test_algorithms}")
        logger.info("="*60 + "\n")
    
        # Initialize backtester
        backtester = AlpacaBacktester(config)
    
        # Check Alpaca connection
        if backtester.data_fetcher.alpaca_client:
            logger.info("✅ Alpaca client connected successfully!")
        
            # Test data fetching for one symbol
            logger.info("\n📥 Testing data fetch for AAPL...")
            data = backtester.data_fetcher.fetch_data('AAPL', '1H')
        
            if data is not None:
                logger.info(f"✅ Successfully fetched {len(data)} bars")
                logger.info(f"   Date range: {data.index[0]} to {data.index[-1]}")
                logger.info(f"   Latest price: ${data['close'].iloc[-1]:.2f}")
            else:
                logger.info("❌ Failed to fetch data")
                return
        
            # Run quick backtest
            logger.info("\n🚀 Running backtest...")
            await backtester.run_backtest(test_symbols, test_algorithms)
        
            # Generate report
            report = backtester.generate_report()
        
            if report and 'summary' in report:
                logger.info("\n📊 TEST RESULTS:")
                logger.info(f"Best Algorithm: {report['summary'].get('best_algorithm', 'N/A')}")
                logger.info(f"Best Return: {report['summary'].get('best_return', 0):.2%}")
                logger.info(f"Average Return: {report['summary'].get('average_return', 0):.2%}")
            
                logger.info("\n✅ Backtest system is working correctly!")
            else:
                logger.info("\n⚠️  No results generated")
            
        else:
            logger.info("❌ Alpaca client not connected")
            logger.info("\nPlease check your alpaca_config.json file")

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in test_backtest: {str(e)}")
        raise
    asyncio.run(test_backtest())