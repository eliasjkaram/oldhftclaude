
#!/usr/bin/env python3
"""
Data API Usage Examples
=======================

Examples of how to use the fixed data APIs in your trading code.

Author: AI Assistant
Date: 2025-01-11
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import pandas as pd
from datetime import datetime, timedelta

# Import the fixed APIs
from yfinance_wrapper import YFinanceWrapper
from data_api_fixer import UnifiedDataAPI


def example_yfinance_wrapper():
    """Example: Using YFinanceWrapper for robust yfinance calls"""
    print("\n=== YFinance Wrapper Example ===")
    
    # Initialize wrapper with configuration
    wrapper = YFinanceWrapper({)
        'max_retries': 3,
        'calls_per_minute': 30,
        'cache_duration_minutes': 15
    })
    
    # Download single ticker data
    print("\n1. Downloading AAPL data...")
    aapl_data = wrapper.download('AAPL', period='1mo', interval='1d')
    if not aapl_data.empty:
        print(f"   ✅ Got {len(aapl_data)} days of data")
        print(f"   Latest close: ${aapl_data['Close'].iloc[-1]:.2f}")
    
    # Download multiple tickers
    print("\n2. Downloading multiple tickers...")
    multi_data = wrapper.download(['SPY', 'QQQ', 'IWM'], period='1wk')
    if not multi_data.empty:
        print(f"   ✅ Got data for multiple tickers")
    
    # Get ticker object
    print("\n3. Getting ticker info...")
    ticker = wrapper.get_ticker('TSLA')
    if ticker:
        info = ticker.info
        print(f"   ✅ {info.get('longName', 'Unknown')}")
        print(f"   Market Cap: ${info.get('marketCap', 0):,.0f}")
    
    # Get options data
    print("\n4. Getting options chain...")
    options = wrapper.get_options('SPY')
    print(f"   ✅ Calls: {len(options['calls'])} contracts")
    print(f"   ✅ Puts: {len(options['puts'])} contracts")


def example_unified_data_api():
    """Example: Using UnifiedDataAPI for multi-source data fetching"""
    print("\n=== Unified Data API Example ===")
    
    # Initialize API with configuration
    api = UnifiedDataAPI({)
        'yfinance_enabled': True,
        'alpaca_enabled': True,  # Set to True if you have API keys
        'minio_enabled': False,   # Set to True if you have MinIO setup
        'cache_ttl': 300,
        'rate_limit_per_minute': 30
    })
    
    # Fetch data with automatic source selection
    print("\n1. Fetching data with auto source selection...")
    spy_data = api.fetch_data('SPY', interval='1h')
    if not spy_data.empty:
        print(f"   ✅ Got {len(spy_data)} hours of data")
        print(f"   Data source used: auto-selected")
    
    # Fetch from specific source
    print("\n2. Fetching from specific source...")
    try:
        aapl_data = api.fetch_data('AAPL', source='yfinance', interval='1d')
        print(f"   ✅ Got {len(aapl_data)} days from yfinance")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Fetch multiple symbols in parallel
    print("\n3. Fetching multiple symbols...")
    symbols = ['MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA']
    results = api.fetch_multiple_symbols(symbols, interval='1d', parallel=True)
    
    for symbol, df in results.items():
        if not df.empty:
            latest_close = df['close'].iloc[-1]
            print(f"   ✅ {symbol}: ${latest_close:.2f}")
    
    # Get latest prices
    print("\n4. Getting latest prices...")
    for symbol in ['SPY', 'QQQ', 'IWM']:
        price = api.get_latest_price(symbol)
        if price:
            print(f"   {symbol}: ${price:.2f}")
    
    # Check market status
    print("\n5. Market status:")
    status = api.get_market_status()
    print(f"   Market open: {status['is_open']}")
    print(f"   Current time: {status['current_time']}")
    
    # Health check
    print("\n6. System health check:")
    health = api.health_check()
    print(f"   Overall status: {health['overall_status']}")
    for source, info in health['sources'].items():
        print(f"   {source}: {info['status']}")


def example_error_handling():
    """Example: Proper error handling with the APIs"""
    print("\n=== Error Handling Example ===")
    
    wrapper = YFinanceWrapper()
    api = UnifiedDataAPI()
    
    # Handle invalid ticker
    print("\n1. Handling invalid ticker...")
    try:
        data = wrapper.download('INVALID_TICKER_XYZ', period='1d')
        if data.empty:
            print("   ✅ Properly handled invalid ticker (empty DataFrame)")
    except Exception as e:
        print(f"   ✅ Exception caught: {e}")
    
    # Handle network issues (simulated)
    print("\n2. Handling network issues...")
    try:
        # The wrapper will automatically retry with backoff
        data = api.fetch_data('AAPL', interval='1m')
        print("   ✅ Data fetched successfully (with automatic retries if needed)")
    except Exception as e:
        print(f"   ❌ Failed after retries: {e}")
    
    # Handle rate limiting
    print("\n3. Rate limiting is handled automatically")
    print("   The APIs will automatically throttle requests to avoid hitting limits")


def example_integration():
    """Example: Integrating with existing code"""
    print("\n=== Integration Example ===")
    
    # Drop-in replacement for yfinance
    print("\n1. Drop-in replacement for yfinance...")
    
    # Old code:
    # import yfinance as yf
    # data = yf.download('AAPL', period='1mo')
    
    # New code:
    from yfinance_wrapper import download
    data = download('AAPL', period='1mo')
    print(f"   ✅ Works as drop-in replacement")
    
    # Using in a trading strategy
    print("\n2. Using in a trading strategy...")
    
    api = UnifiedDataAPI()
    
    # Get data for analysis
    symbol = 'SPY'
    df = api.fetch_data(symbol, interval='1d')
    
    if not df.empty:
        # Calculate simple moving averages
        df['SMA_20'] = df['close'].rolling(window=20).mean()
        df['SMA_50'] = df['close'].rolling(window=50).mean()
        
        # Latest values
        latest = df.iloc[-1]
        print(f"   {symbol} Close: ${latest['close']:.2f}")
        print(f"   SMA(20): ${latest['SMA_20']:.2f}")
        print(f"   SMA(50): ${latest['SMA_50']:.2f}")
        
        # Generate signal
        if latest['SMA_20'] > latest['SMA_50']:
            print("   📈 Bullish signal (SMA20 > SMA50)")
        else:
            print("   📉 Bearish signal (SMA20 < SMA50)")


if __name__ == "__main__":
    print("Data API Usage Examples")
    print("=" * 50)
    
    # Run examples
    example_yfinance_wrapper()
    example_unified_data_api()
    example_error_handling()
    example_integration()
    
    print("\n✅ Examples completed!")
