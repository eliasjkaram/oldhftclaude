#!/usr/bin/env python3
"""
Comprehensive Data Validation Module
===================================

Extends DataValidator from PRODUCTION_FIXES to provide comprehensive
validation for all trading operations including:
- Symbol validation with exchange support
- Order parameter validation with bounds checking
- Price sanitization and validation
- API response validation
- Position and portfolio validation
"""

from typing import Dict, Any, List, Optional, Union
from decimal import Decimal, ROUND_HALF_UP
import logging
import re
from datetime import datetime, timedelta

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


from PRODUCTION_FIXES import DataValidator, DataValidationError, OrderValidation

from universal_market_data import get_current_market_data, validate_price


logger = logging.getLogger(__name__)


class ExtendedOrderValidation(OrderValidation):
    """Extended order validation with additional constraints"""
    
    # Additional validation parameters
    MIN_NOTIONAL_VALUE: Decimal = Decimal("1.00")  # Minimum $1 order value
    MAX_NOTIONAL_VALUE: Decimal = Decimal("1000000.00")  # Maximum $1M order value
    VALID_EXCHANGES: List[str] = ['NYSE', 'NASDAQ', 'AMEX', 'ARCA', 'BATS']
    MAX_SYMBOL_LENGTH: int = 5
    MAX_ORDERS_PER_SYMBOL_PER_DAY: int = 100
    MAX_POSITION_CONCENTRATION: float = 0.25  # Max 25% of portfolio in one position


class ComprehensiveDataValidator(DataValidator):
    """Comprehensive data validation for all trading operations"""
    
    @staticmethod
    def validate_symbol_extended(symbol: str, exchange: Optional[str] = None) -> bool:
        """Extended symbol validation with exchange support"""
        # Basic validation from parent
        DataValidator.validate_symbol(symbol)
        
        # Extended validation
        if len(symbol) > ExtendedOrderValidation.MAX_SYMBOL_LENGTH:
            raise DataValidationError(f"Symbol {symbol} exceeds maximum length of {ExtendedOrderValidation.MAX_SYMBOL_LENGTH}")
        
        # Check for invalid characters (only alphanumeric allowed)
        if not re.match(r'^[A-Z0-9]+$', symbol.upper()):
            raise DataValidationError(f"Symbol {symbol} contains invalid characters")
        
        # Validate exchange if provided
        if exchange and exchange.upper() not in ExtendedOrderValidation.VALID_EXCHANGES:
            raise DataValidationError(f"Invalid exchange {exchange}")
        
        return True
    
    @staticmethod
    def validate_order_extended(order: Dict[str, Any], portfolio_value: Optional[float] = None) -> bool:
        """Extended order validation with portfolio constraints"""
        # Basic validation from parent
        DataValidator.validate_order(order)
        
        # Extended validation
        extended_validation = ExtendedOrderValidation()
        
        # Validate notional value
        if 'price' in order:
            notional_value = Decimal(str(order['quantity'])) * Decimal(str(order['price']))
            
            if notional_value < extended_validation.MIN_NOTIONAL_VALUE:
                raise DataValidationError(f"Order notional value ${notional_value} below minimum ${extended_validation.MIN_NOTIONAL_VALUE}")
            
            if notional_value > extended_validation.MAX_NOTIONAL_VALUE:
                raise DataValidationError(f"Order notional value ${notional_value} exceeds maximum ${extended_validation.MAX_NOTIONAL_VALUE}")
            
            # Check position concentration if portfolio value provided
            if portfolio_value and portfolio_value > 0:
                concentration = float(notional_value) / portfolio_value
                if concentration > extended_validation.MAX_POSITION_CONCENTRATION:
                    raise DataValidationError(f"Position concentration {concentration:.1%} exceeds maximum {extended_validation.MAX_POSITION_CONCENTRATION:.1%}")
        
        # Validate order class if present
        if 'order_class' in order:
            valid_classes = ['simple', 'bracket', 'oco', 'oto']
            if order['order_class'] not in valid_classes:
                raise DataValidationError(f"Invalid order class: {order['order_class']}")
        
        # Validate extended attributes for bracket orders
        if order.get('order_class') == 'bracket':
            if 'take_profit' not in order or 'stop_loss' not in order:
                raise DataValidationError("Bracket orders require take_profit and stop_loss")
            
            # Validate bracket prices
            take_profit = Decimal(str(order['take_profit']))
            stop_loss = Decimal(str(order['stop_loss']))
            entry_price = Decimal(str(order.get('price', order.get('limit_price', 0))))
            
            if order['side'] == 'buy':
                if stop_loss >= entry_price:
                    raise DataValidationError("Stop loss must be below entry price for buy orders")
                if take_profit <= entry_price:
                    raise DataValidationError("Take profit must be above entry price for buy orders")
            else:  # sell
                if stop_loss <= entry_price:
                    raise DataValidationError("Stop loss must be above entry price for sell orders")
                if take_profit >= entry_price:
                    raise DataValidationError("Take profit must be below entry price for sell orders")
        
        return True
    
    @staticmethod
    def validate_api_response(response: Any, expected_fields: List[str]) -> bool:
        """Validate API response structure"""
        if response is None:
            raise DataValidationError("API response is None")
        
        # Check for expected fields
        for field in expected_fields:
            if not hasattr(response, field):
                raise DataValidationError(f"API response missing required field: {field}")
        
        return True
    
    @staticmethod
    def validate_market_data(data: Dict[str, Any]) -> bool:
        """Validate market data structure and values"""
        required_fields = ['symbol', 'price', 'timestamp']
        
        for field in required_fields:
            if field not in data:
                raise DataValidationError(f"Market data missing required field: {field}")
        
        # Validate price
        price = data.get('price')
        if not isinstance(price, (int, float)) or price <= 0:
            raise DataValidationError(f"Invalid market price: {price}")
        
        # Validate timestamp
        timestamp = data.get('timestamp')
        if isinstance(timestamp, str):
            try:
                dt = datetime.fromisoformat(timestamp)
                # Check if timestamp is reasonable (not too old or in future)
                now = datetime.now()
                if dt > now + timedelta(minutes=5):
                    raise DataValidationError("Market data timestamp is in the future")
                if dt < now - timedelta(days=7):
                    raise DataValidationError("Market data timestamp is too old")
            except ValueError:
                raise DataValidationError(f"Invalid timestamp format: {timestamp}")
        
        # Validate optional fields if present
        if 'volume' in data:
            volume = data['volume']
            if not isinstance(volume, (int, float)) or volume < 0:
                raise DataValidationError(f"Invalid volume: {volume}")
        
        if 'bid' in data and 'ask' in data:
            bid = data['bid']
            ask = data['ask']
            if bid > ask:
                raise DataValidationError(f"Bid {bid} is greater than ask {ask}")
        
        return True
    
    @staticmethod
    def validate_position(position: Dict[str, Any]) -> bool:
        """Validate position data"""
        required_fields = ['symbol', 'quantity', 'side', 'avg_entry_price']
        
        for field in required_fields:
            if field not in position:
                raise DataValidationError(f"Position missing required field: {field}")
        
        # Validate symbol
        DataValidator.validate_symbol(position['symbol'])
        
        # Validate quantity
        qty = position['quantity']
        if not isinstance(qty, (int, float)) or qty <= 0:
            raise DataValidationError(f"Invalid position quantity: {qty}")
        
        # Validate side
        if position['side'] not in ['long', 'short']:
            raise DataValidationError(f"Invalid position side: {position['side']}")
        
        # Validate average entry price
        avg_price = position['avg_entry_price']
        if not isinstance(avg_price, (int, float)) or avg_price <= 0:
            raise DataValidationError(f"Invalid average entry price: {avg_price}")
        
        return True
    
    @staticmethod
    def sanitize_quantity(quantity: Any, asset_type: str = 'stock') -> int:
        """Sanitize and validate quantity based on asset type"""
        try:
            if asset_type == 'stock':
                # Stocks must be whole shares
                qty = int(float(quantity))
                if qty <= 0:
                    raise DataValidationError(f"Invalid quantity: {quantity}")
                return qty
            elif asset_type == 'crypto':
                # Crypto can be fractional
                qty = float(quantity)
                if qty <= 0:
                    raise DataValidationError(f"Invalid quantity: {quantity}")
                # Round to 8 decimal places for crypto
                return round(qty, 8)
            else:
                # Default to whole units
                return int(float(quantity))
        except (ValueError, TypeError) as e:
            raise DataValidationError(f"Cannot convert quantity {quantity} to valid number") from e
    
    @staticmethod
    def validate_portfolio_allocation(positions: List[Dict[str, Any]], 
                                    cash: float, 
                                    total_value: float) -> Dict[str, Any]:
        """Validate portfolio allocation and risk limits"""
        if total_value <= 0:
            raise DataValidationError("Invalid portfolio total value")
        
        # Check cash percentage
        cash_percentage = cash / total_value
        if cash_percentage < 0:
            raise DataValidationError("Negative cash balance")
        
        # Calculate position concentrations
        position_values = {}
        total_position_value = 0
        
        for position in positions:
            symbol = position['symbol']
            value = position['quantity'] * position.get('current_price', position['avg_entry_price'])
            position_values[symbol] = value
            total_position_value += value
        
        # Validate individual position concentrations
        concentrations = {}
        max_concentration = 0
        max_symbol = None
        
        for symbol, value in position_values.items():
            concentration = value / total_value
            concentrations[symbol] = concentration
            
            if concentration > max_concentration:
                max_concentration = concentration
                max_symbol = symbol
            
            if concentration > ExtendedOrderValidation.MAX_POSITION_CONCENTRATION:
                logger.warning(f"Position {symbol} concentration {concentration:.1%} exceeds limit")
        
        return {}
            'valid': True,
            'cash_percentage': cash_percentage,
            'position_count': len(positions),
            'max_concentration': max_concentration,
            'max_concentration_symbol': max_symbol,
            'concentrations': concentrations
        }
    
    @staticmethod
    def validate_trading_hours(timestamp: Optional[datetime] = None) -> bool:
        """Validate if current time is within trading hours"""
        if timestamp is None:
            timestamp = datetime.now()
        
        # Check if weekend
        if timestamp.weekday() >= 5:  # Saturday = 5, Sunday = 6
            raise DataValidationError("Markets closed on weekends")
        
        # Check regular trading hours (9:30 AM - 4:00 PM ET)
        # This is simplified - real implementation would handle timezones properly
        hour = timestamp.hour
        minute = timestamp.minute
        
        market_open = 9 * 60 + 30  # 9:30 AM in minutes
        market_close = 16 * 60  # 4:00 PM in minutes
        current_minutes = hour * 60 + minute
        
        if current_minutes < market_open or current_minutes >= market_close:
            # Check for extended hours if needed
            if current_minutes < 4 * 60 or current_minutes >= 20 * 60:
                raise DataValidationError("Outside of extended trading hours")
        
        return True


def validate_trading_request(request: Dict[str, Any]) -> Dict[str, Any]:
    """Comprehensive validation for a complete trading request"""
    validator = ComprehensiveDataValidator()
    
    try:
        # Validate symbol
        symbol = request.get('symbol')
        validator.validate_symbol_extended(symbol)
        
        # Validate order details
        order_data = {}
            'symbol': symbol,
            'quantity': request.get('quantity'),
            'order_type': request.get('order_type'),
            'side': request.get('side'),
            'price': request.get('price'),
            'stop_price': request.get('stop_price')
        }
        
        portfolio_value = request.get('portfolio_value')
        validator.validate_order_extended(order_data, portfolio_value)
        
        # Sanitize values
        sanitized = {}
            'symbol': symbol.upper(),
            'quantity': validator.sanitize_quantity(request['quantity'], request.get('asset_type', 'stock')),
            'order_type': request['order_type'],
            'side': request['side']
        }
        
        if 'price' in request and request['price'] is not None:
            sanitized['price'] = float(validator.sanitize_price(request['price']))
        
        if 'stop_price' in request:
            sanitized['stop_price'] = float(validator.sanitize_price(request['stop_price']))
        
        return {}
            'valid': True,
            'sanitized': sanitized,
            'errors': []
        }
        
    except DataValidationError as e:
        return {}
            'valid': False,
            'errors': [str(e)],
            'sanitized': None
        }
    except Exception as e:
        return {}
            'valid': False,
            'errors': [f"Unexpected error: {str(e)}"],
            'sanitized': None
        }


# Example usage and testing
if __name__ == "__main__":
    # Test comprehensive validation
    test_requests = []
        {}
            'symbol': 'AAPL',
            'quantity': 100,
            'order_type': 'limit',
            'side': 'buy',
            'price': 150.50,
            'portfolio_value': 100000
        },
        {}
            'symbol': 'INVALID_SYMBOL_TOO_LONG',
            'quantity': 100,
            'order_type': 'market',
            'side': 'buy'
        },
        {}
            'symbol': 'TSLA',
            'quantity': 10000,  # Too large
            'order_type': 'market',
            'side': 'sell'
        }
    ]
    
    for request in test_requests:
        result = validate_trading_request(request)
        print(f"\nRequest: {request}")
        print(f"Result: {result}")