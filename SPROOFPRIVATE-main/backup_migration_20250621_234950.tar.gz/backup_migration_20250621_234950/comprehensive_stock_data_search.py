#!/usr/bin/env python3
"""
Comprehensive Stock Data Search for MinIO
This script searches for stock data files (as opposed to options data) in the MinIO system.
"""

import pandas as pd
import json
import requests
from datetime import datetime, timedelta
import logging
import re
import os
from typing import Dict, List, Any
import xml.etree.ElementTree as ET
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

# Set up logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('stock_data_search.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ComprehensiveStockDataSearch:
    def __init__(self):
        """Initialize the stock data search system."""
        self.base_url = "https://uschristmas.us"
        self.bucket = "stockdb"
        self.results = {}
            "search_timestamp": datetime.now().isoformat(),
            "search_focus": "Stock data files (not options)",
            "all_directories": [],
            "stock_file_patterns": [],
            "stock_data_directories": [],
            "2023_stock_files": [],
            "sample_stock_files": [],
            "directory_structure": {},
            "recommendations": []
        }
        
        # Stock file patterns to search for
        self.stock_patterns = []
            r'.*stocks\.csv',
            r'.*stock.*\.csv',
            r'.*equity.*\.csv', 
            r'.*price.*\.csv',
            r'.*daily.*\.csv',
            r'.*AAPL.*\.csv',
            r'.*MSFT.*\.csv',
            r'.*GOOGL.*\.csv',
            r'.*SPY.*\.csv',
            r'.*QQQ.*\.csv'
        ]
        
        # Date patterns for 2023
        self.date_2023_patterns = []
            r'2023-01-03',
            r'2023.*01.*03',
            r'20230103',
            r'2023'
        ]
        
        # Directories to search for stock data
        self.search_directories = []
            "",  # Root
            "stocks/",
            "equities/",
            "daily/",
            "prices/",
            "historical/",
            "data/",
            "archive/",
            "backup/",
            "2023/",
            "yearly/",
            "compressed/",
            "aws_backup/",
            "stock-data/",
            "equity-data/"
        ]

    def get_all_directories(self) -> List[str]:
        """Get all available directories in the bucket."""
        logger.info("Discovering all directories in bucket...")
        
        directories = []
        
        try:
            url = f"{self.base_url}/{self.bucket}/"
            response = requests.get(f"{url}?delimiter=/")
            
            if response.status_code == 200:
                # Parse XML to find CommonPrefixes (directories)
                root = ET.fromstring(response.content)
                
                # Find directories
                for prefix in root.findall('.//{http://s3.amazonaws.com/doc/2006-03-01/}CommonPrefixes'):
                    prefix_elem = prefix.find('{http://s3.amazonaws.com/doc/2006-03-01/}Prefix')
                    if prefix_elem is not None and prefix_elem.text:
                        directories.append(prefix_elem.text)
                        logger.info(f"Found directory: {prefix_elem.text}")
                
                logger.info(f"Total directories found: {len(directories)}")
                
            else:
                logger.error(f"Failed to list directories: HTTP {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error getting directories: {str(e)}")
        
        return directories

    def search_directory_for_stock_files(self, directory_path: str) -> Dict[str, Any]:
        """Search a specific directory for stock data files."""
        logger.info(f"Searching directory for stock files: {directory_path}")
        
        directory_results = {}
            "directory": directory_path,
            "stock_files": [],
            "total_files": 0,
            "file_patterns_found": [],
            "2023_files": [],
            "sample_files": []
        }
        
        try:
            # Get directory listing
            url = f"{self.base_url}/{self.bucket}/"
            if directory_path and not directory_path.endswith('/'):
                directory_path += '/'
            
            params = {"prefix": directory_path, "max-keys": "5000"}
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                # Parse XML response to find files
                root = ET.fromstring(response.content)
                
                for contents in root.findall('.//{http://s3.amazonaws.com/doc/2006-03-01/}Contents'):
                    key_elem = contents.find('{http://s3.amazonaws.com/doc/2006-03-01/}Key')
                    size_elem = contents.find('{http://s3.amazonaws.com/doc/2006-03-01/}Size')
                    
                    if key_elem is not None and key_elem.text:
                        filename = key_elem.text
                        file_size = int(size_elem.text) if size_elem is not None else 0
                        
                        directory_results["total_files"] += 1
                        
                        # Check for stock file patterns
                        for pattern in self.stock_patterns:
                            if re.search(pattern, filename, re.IGNORECASE):
                                stock_file_info = {}
                                    "filename": filename,
                                    "size_bytes": file_size,
                                    "size_mb": round(file_size / (1024 * 1024), 2),
                                    "pattern_matched": pattern
                                }
                                directory_results["stock_files"].append(stock_file_info)
                                directory_results["file_patterns_found"].append(pattern)
                                
                                # Check if it's a 2023 file
                                for date_pattern in self.date_2023_patterns:
                                    if re.search(date_pattern, filename, re.IGNORECASE):
                                        directory_results["2023_files"].append(stock_file_info)
                                        break
                                
                                logger.info(f"Found stock file: {filename} (pattern: {pattern})")
                                break
                        
                        # Keep sample of all files for analysis
                        if len(directory_results["sample_files"]) < 20:
                            directory_results["sample_files"].append({)
                                "filename": filename,
                                "size_mb": round(file_size / (1024 * 1024), 2)
                            })
                
                logger.info(f"Directory {directory_path}: {directory_results['total_files']} total files, {len(directory_results['stock_files'])} stock files")
                
            else:
                logger.warning(f"Could not access directory {directory_path}: HTTP {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error searching directory {directory_path}: {str(e)}")
        
        return directory_results

    def check_specific_2023_stock_files(self) -> List[Dict[str, Any]]:
        """Check for specific 2023 stock data files."""
        logger.info("Checking for specific 2023 stock files...")
        
        specific_stock_files = []
        
        # Potential 2023 stock file locations
        potential_files = []
            "2023-01-03stocks.csv",
            "stocks/2023-01-03.csv",
            "daily/2023-01-03.csv",
            "2023/01/03/stocks.csv",
            "2023/stocks.csv",
            "historical/2023/stocks.csv",
            "prices/2023-01-03.csv",
            "equity-data/2023-01-03.csv",
            "stock-data/2023-01-03.csv",
            "AAPL-2023-01-03.csv",
            "MSFT-2023-01-03.csv",
            "GOOGL-2023-01-03.csv"
        ]
        
        for file_path in potential_files:
            try:
                url = f"{self.base_url}/{self.bucket}/{file_path}"
                response = requests.head(url)
                
                if response.status_code == 200:
                    file_info = {}
                        "path": file_path,
                        "exists": True,
                        "size": response.headers.get('Content-Length', 'unknown'),
                        "last_modified": response.headers.get('Last-Modified', 'unknown'),
                        "content_type": response.headers.get('Content-Type', 'unknown')
                    }
                    specific_stock_files.append(file_info)
                    logger.info(f"Found specific 2023 stock file: {file_path}")
                
            except Exception as e:
                logger.debug(f"File {file_path} not found: {str(e)}")
        
        return specific_stock_files

    def sample_file_content(self, filename: str, max_lines: int = 10) -> Dict[str, Any]:
        """Sample content from a stock file to understand its structure."""
        logger.info(f"Sampling content from: {filename}")
        
        sample_info = {}
            "filename": filename,
            "accessible": False,
            "header": None,
            "columns": [],
            "sample_rows": [],
            "contains_stock_data": False,
            "error": None
        }
        
        try:
            url = f"{self.base_url}/{self.bucket}/{filename}"
            response = requests.get(url, stream=True)
            
            if response.status_code == 200:
                lines = []
                for i, line in enumerate(response.iter_lines(decode_unicode=True)):
                    if i >= max_lines:
                        break
                    lines.append(line)
                
                if lines:
                    sample_info["accessible"] = True
                    sample_info["header"] = lines[0]
                    sample_info["columns"] = lines[0].split(',')
                    sample_info["sample_rows"] = lines[1:min(5, len(lines))]
                    
                    # Check if it contains stock-like data
                    header_lower = lines[0].lower()
                    stock_indicators = ['open', 'high', 'low', 'close', 'volume', 'price', 'symbol']
                    sample_info["contains_stock_data"] = any(indicator in header_lower for indicator in stock_indicators)
                    
                    logger.info(f"Successfully sampled {filename}: {len(sample_info['columns'])} columns")
                else:
                    sample_info["error"] = "File appears to be empty"
            else:
                sample_info["error"] = f"HTTP {response.status_code}"
                
        except Exception as e:
            sample_info["error"] = str(e)
            logger.error(f"Error sampling {filename}: {str(e)}")
        
        return sample_info

    def perform_comprehensive_search(self) -> Dict[str, Any]:
        """Perform comprehensive search for stock data."""
        logger.info("Starting comprehensive stock data search...")
        
        # Get all directories
        all_directories = self.get_all_directories()
        self.results["all_directories"] = all_directories
        
        # Search each directory for stock files
        for directory in self.search_directories:
            directory_results = self.search_directory_for_stock_files(directory)
            
            if directory_results["stock_files"]:
                self.results["stock_data_directories"].append(directory_results)
            
            # Add any 2023 files found
            self.results["2023_stock_files"].extend(directory_results["2023_files"])
        
        # Check for specific 2023 files
        specific_files = self.check_specific_2023_stock_files()
        self.results["specific_2023_stock_files"] = specific_files
        
        # Sample some files to understand structure
        all_stock_files = []
        for dir_result in self.results["stock_data_directories"]:
            all_stock_files.extend(dir_result["stock_files"])
        
        # Sample first few stock files found
        for i, stock_file in enumerate(all_stock_files[:5]):
            sample = self.sample_file_content(stock_file["filename"])
            self.results["sample_stock_files"].append(sample)
        
        # Generate summary
        self.generate_stock_data_summary()
        
        return self.results

    def generate_stock_data_summary(self):
        """Generate summary of stock data findings."""
        logger.info("Generating stock data summary...")
        
        total_stock_files = sum(len(dir_result["stock_files"]) for dir_result in self.results["stock_data_directories"])
        total_2023_files = len(self.results["2023_stock_files"])
        directories_with_stock_data = len(self.results["stock_data_directories"])
        
        self.results["summary"] = {}
            "total_directories_searched": len(self.search_directories),
            "directories_with_stock_data": directories_with_stock_data,
            "total_stock_files_found": total_stock_files,
            "2023_stock_files_found": total_2023_files,
            "stock_data_available": "YES" if total_stock_files > 0 else "NO"
        }
        
        # Generate recommendations
        if total_stock_files > 0:
            self.results["recommendations"] = []
                f"✅ SUCCESS: Found {total_stock_files} stock data files in {directories_with_stock_data} directories",
                f"📅 2023 Data: {total_2023_files} files specifically for 2023",
                "🔍 Priority: Download and analyze the identified stock files",
                "📊 Integration: Use stock data for same-day trading algorithm validation",
                "⚡ Performance: Consider setting up local cache for frequently accessed stock files"
            ]
            
            if total_2023_files == 0:
                self.results["recommendations"].append("⚠️ Note: No 2023-specific stock files found - may need different search approach")
        else:
            self.results["recommendations"] = []
                "❌ No stock data files found with current search patterns",
                "🔍 Expand Search: Try additional file naming patterns",
                "📁 Directory Check: Verify if stock data is in different directory structure",
                "🔄 Alternative: Stock data might be embedded within options files",
                "📞 Contact: Verify MinIO setup and stock data availability"
            ]

    def save_results(self, filename: str = None):
        """Save search results to file."""
        if filename is None:
            filename = f"stock_data_search_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        logger.info(f"Results saved to {filename}")
        return filename

def main():
    """Main execution function."""
    logger.info("Starting comprehensive stock data search...")
    
    try:
        searcher = ComprehensiveStockDataSearch()
        results = searcher.perform_comprehensive_search()
        
        # Save results
        results_file = searcher.save_results()
        
        # Print comprehensive report
        print("\n" + "="*80)
        print("COMPREHENSIVE STOCK DATA SEARCH RESULTS")
        print("="*80)
        
        print(f"\nSearch completed at: {results['search_timestamp']}")
        print(f"Search focus: {results['search_focus']}")
        
        # Summary
        summary = results["summary"]
        print(f"\n📊 SEARCH SUMMARY:")
        print(f"  • Directories searched: {summary['total_directories_searched']}")
        print(f"  • Directories with stock data: {summary['directories_with_stock_data']}")
        print(f"  • Total stock files found: {summary['total_stock_files_found']}")
        print(f"  • 2023 stock files: {summary['2023_stock_files_found']}")
        print(f"  • Stock data available: {summary['stock_data_available']}")
        
        # All directories found
        if results["all_directories"]:
            print(f"\n📁 ALL DIRECTORIES IN BUCKET:")
            for directory in results["all_directories"]:
                print(f"  • {directory}")
        
        # Stock data directories
        if results["stock_data_directories"]:
            print(f"\n📈 DIRECTORIES WITH STOCK DATA:")
            for dir_result in results["stock_data_directories"]:
                print(f"  • {dir_result['directory']}: {len(dir_result['stock_files'])} stock files")
                
                # Show sample files
                for stock_file in dir_result['stock_files'][:3]:
                    print(f"    - {stock_file['filename']} ({stock_file['size_mb']} MB)")
                
                if len(dir_result['stock_files']) > 3:
                    print(f"    ... and {len(dir_result['stock_files']) - 3} more files")
        
        # 2023 specific files
        if results["2023_stock_files"]:
            print(f"\n📅 2023 STOCK FILES:")
            for file_info in results["2023_stock_files"]:
                print(f"  • {file_info['filename']} ({file_info['size_mb']} MB)")
        
        # Sample file analysis
        if results["sample_stock_files"]:
            print(f"\n🔍 SAMPLE FILE ANALYSIS:")
            for sample in results["sample_stock_files"]:
                if sample["accessible"]:
                    print(f"  • {sample['filename']}:")
                    print(f"    - Columns: {len(sample['columns'])}")
                    print(f"    - Contains stock data: {sample['contains_stock_data']}")
                    if sample["columns"]:
                        print(f"    - Headers: {', '.join(sample['columns'][:10])}")
                else:
                    print(f"  • {sample['filename']}: Not accessible ({sample.get('error', 'unknown error')})")
        
        # Recommendations
        print(f"\n💡 RECOMMENDATIONS:")
        for i, rec in enumerate(results["recommendations"], 1):
            print(f"  {i}. {rec}")
        
        print(f"\n📄 Full results saved to: {results_file}")
        print("="*80)
        
        return results
        
    except Exception as e:
        logger.error(f"Search failed: {str(e)}")
        raise

if __name__ == "__main__":
    main()