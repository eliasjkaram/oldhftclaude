#!/usr/bin/env python3
"""
Master Trading Orchestrator
Integrates all algorithms with comprehensive ranking and decision system
"""

import asyncio
import os
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Set
from dataclasses import dataclass, field
from enum import Enum
import json
from collections import defaultdict, deque
import sqlite3
from abc import ABC, abstractmethod

# Import all trading systems
try:
    from transformer_prediction_system import TransformerPredictionSystem
    from multi_agent_trading_system import MultiAgentTradingSystem
    from advanced_options_arbitrage_system import OptionsArbitrageScanner
    from leaps_arbitrage_scanner import LEAPSArbitrageScanner
    from arbitrage_scanner import ArbitrageScanner
    from advanced_pricing_models import EnsemblePricingEngine
    HAS_ADVANCED_SYSTEMS = True
except ImportError:
    HAS_ADVANCED_SYSTEMS = False

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame

from universal_market_data import get_current_market_data, validate_price


# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('master_orchestrator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class StrategyType(Enum):
    """All available trading strategies"""
    # Directional
    MOMENTUM = "momentum"
    MEAN_REVERSION = "mean_reversion"
    TREND_FOLLOWING = "trend_following"
    
    # Arbitrage
    STATISTICAL_ARB = "statistical_arbitrage"
    PAIRS_TRADING = "pairs_trading"
    TRIANGULAR_ARB = "triangular_arbitrage"
    OPTIONS_ARB = "options_arbitrage"
    
    # Options Income
    COVERED_CALL = "covered_call"
    CASH_SECURED_PUT = "cash_secured_put"
    WHEEL_STRATEGY = "wheel_strategy"
    
    # Options Spreads - Vertical
    BULL_CALL_SPREAD = "bull_call_spread"
    BEAR_PUT_SPREAD = "bear_put_spread"
    BULL_PUT_SPREAD = "bull_put_spread"
    BEAR_CALL_SPREAD = "bear_call_spread"
    
    # Options Spreads - Complex
    IRON_CONDOR = "iron_condor"
    IRON_BUTTERFLY = "iron_butterfly"
    BUTTERFLY_SPREAD = "butterfly_spread"
    CONDOR_SPREAD = "condor_spread"
    
    # Calendar/Diagonal
    CALENDAR_SPREAD = "calendar_spread"
    DIAGONAL_SPREAD = "diagonal_spread"
    DOUBLE_DIAGONAL = "double_diagonal"
]
    # Volatility
    STRADDLE = "straddle"
    STRANGLE = "strangle"
    STRIP = "strip"
    STRAP = "strap"
    GUTS = "guts"
    
    # Advanced
    RATIO_SPREAD = "ratio_spread"
    BACKSPREAD = "backspread"
    JADE_LIZARD = "jade_lizard"
    BROKEN_WING_BUTTERFLY = "broken_wing_butterfly"
    CHRISTMAS_TREE = "christmas_tree"
    
    # Exotic
    BOX_SPREAD = "box_spread"
    JELLY_ROLL = "jelly_roll"
    CONVERSION = "conversion"
    REVERSAL = "reversal"
    
    # ML/AI Based
    TRANSFORMER_PREDICTION = "transformer_prediction"
    MULTI_AGENT_CONSENSUS = "multi_agent_consensus"
    NEURAL_OPTION_PRICING = "neural_option_pricing"

@dataclass
class TradingSignal:
    """Comprehensive trading signal with all metadata"""
    signal_id: str
    timestamp: datetime
    strategy: StrategyType
    symbol: str
    action: str  # BUY, SELL, SPREAD, etc.
    
    # Core metrics
    confidence: float  # 0-1
    expected_return: float
    risk: float
    risk_reward_ratio: float
    
    # Algorithm source
    algorithm: str
    algorithm_version: str
    
    # Market context
    market_regime: str
    volatility_regime: str
    
    # Execution details
    entry_price: float
    stop_loss: Optional[float] = None
    profit_target: Optional[float] = None
    position_size: Optional[int] = None
    
    # Options specific
    option_legs: List[Dict] = field(default_factory=list)
    greeks: Optional[Dict] = None
    iv_rank: Optional[float] = None
    
    # Performance tracking
    backtest_metrics: Optional[Dict] = None
    historical_win_rate: Optional[float] = None
    avg_profit: Optional[float] = None
    avg_loss: Optional[float] = None
    sharpe_ratio: Optional[float] = None
    
    # Additional metadata
    correlated_signals: List[str] = field(default_factory=list)
    hedging_pairs: List[str] = field(default_factory=list)
    news_sentiment: Optional[float] = None
    
    def composite_score(self) -> float:
        """Calculate composite score for ranking"""
        score = 0.0
        
        # Base confidence weight (30%)
        score += self.confidence * 30
        
        # Risk-reward weight (25%)
        score += min(self.risk_reward_ratio / 3, 1.0) * 25
        
        # Expected return weight (20%)
        score += min(self.expected_return * 100, 1.0) * 20
        
        # Historical performance weight (15%)
        if self.historical_win_rate:
            score += self.historical_win_rate * 15
            
        # Sharpe ratio weight (10%)
        if self.sharpe_ratio:
            score += min(self.sharpe_ratio / 2, 1.0) * 10
            
        return score

@dataclass
class AlgorithmPerformance:
    """Track algorithm performance metrics"""
    algorithm_name: str
    total_signals: int = 0
    executed_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    total_pnl: float = 0.0
    avg_confidence: float = 0.0
    avg_return: float = 0.0
    sharpe_ratio: float = 0.0
    max_drawdown: float = 0.0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    
    def update(self, trade_result: Dict):
        """Update performance metrics"""
        self.executed_trades += 1
        
        if trade_result['pnl'] > 0:
            self.winning_trades += 1
        else:
            self.losing_trades += 1
            
        self.total_pnl += trade_result['pnl']
        self.win_rate = self.winning_trades / self.executed_trades if self.executed_trades > 0 else 0

class BaseAlgorithm(ABC):
    """Base class for all trading algorithms"""
    
    def __init__(self, name: str, version: str):
        self.name = name
        self.version = version
        self.performance = AlgorithmPerformance(algorithm_name=name)
        
    @abstractmethod
    async def generate_signals(self, market_data: Dict) -> List[TradingSignal]:
        """Generate trading signals"""
        pass
        
    @abstractmethod
    def get_supported_strategies(self) -> List[StrategyType]:
        """Return list of supported strategies"""
        pass

class MomentumAlgorithm(BaseAlgorithm):
    """Momentum-based trading algorithm"""
    
    def __init__(self):
        super().__init__("MomentumScanner", "2.0")
        
    async def generate_signals(self, market_data: Dict) -> List[TradingSignal]:
        signals = []
        
        for symbol, data in market_data.items():
            if not isinstance(data, dict) or 'prices' not in data:
                continue
                
            # Momentum criteria
            if len(data['prices']) >= 20:
                momentum = (data['prices'][-1] - data['prices'][-20]) / data['prices'][-20]
                
                if momentum > 0.05 and data.get('rsi', 50) > 50 and data.get('rsi', 50) < 70:
                    signal = TradingSignal()
                        signal_id=f"{self.name}_{symbol}_{datetime.now().timestamp()}",
                        timestamp=datetime.now(),
                        strategy=StrategyType.MOMENTUM,
                        symbol=symbol,
                        action="BUY",
                        confidence=0.75,
                        expected_return=0.03,
                        risk=0.01,
                        risk_reward_ratio=3.0,
                        algorithm=self.name,
                        algorithm_version=self.version,
                        market_regime="TRENDING",
                        volatility_regime="NORMAL",
                        entry_price=data['prices'][-1],
                        stop_loss=data['prices'][-1] * 0.98,
                        profit_target=data['prices'][-1] * 1.03,
                        historical_win_rate=0.65,
                        avg_profit=0.028,
                        avg_loss=0.009,
                        sharpe_ratio=1.8
                    )
                    signals.append(signal)
                    
        return signals
        
    def get_supported_strategies(self) -> List[StrategyType]:
        return [StrategyType.MOMENTUM, StrategyType.TREND_FOLLOWING]

class OptionsSpreadAlgorithm(BaseAlgorithm):
    """Advanced options spread algorithm"""
    
    def __init__(self):
        super().__init__("OptionsSpreadMaster", "3.0")
        
    async def generate_signals(self, market_data: Dict) -> List[TradingSignal]:
        signals = []
        
        # ETFs for spreads
        etf_symbols = ['SPY', 'QQQ', 'IWM', 'DIA', 'XLF', 'XLE']
        
        for symbol in etf_symbols:
            if symbol not in market_data:
                continue
                
            data = market_data[symbol]
            price = data.get('prices', [0])[-1] if 'prices' in data else 0
            volatility = data.get('volatility', 0.15)
            
            # Iron Condor signal
            if volatility < 0.20:  # Low volatility environment
                signal = TradingSignal()
                    signal_id=f"{self.name}_IC_{symbol}_{datetime.now().timestamp()}",
                    timestamp=datetime.now(),
                    strategy=StrategyType.IRON_CONDOR,
                    symbol=symbol,
                    action="SPREAD",
                    confidence=0.80,
                    expected_return=0.015,
                    risk=0.01,
                    risk_reward_ratio=1.5,
                    algorithm=self.name,
                    algorithm_version=self.version,
                    market_regime="RANGING",
                    volatility_regime="LOW",
                    entry_price=price,
                    option_legs=[]
                        {"type": "put", "strike": price * 0.93, "side": "buy"},
                        {"type": "put", "strike": price * 0.95, "side": "sell"},
                        {"type": "call", "strike": price * 1.05, "side": "sell"},
                        {"type": "call", "strike": price * 1.07, "side": "buy"}
                    ],
                    greeks={"delta": 0.02, "gamma": -0.01, "theta": 0.15, "vega": -0.5},
                    iv_rank=25,
                    historical_win_rate=0.78,
                    avg_profit=0.012,
                    avg_loss=0.018,
                    sharpe_ratio=1.4
                )
                signals.append(signal)
                
            # Butterfly spread for high IV
            elif volatility > 0.30:
                signal = TradingSignal()
                    signal_id=f"{self.name}_BF_{symbol}_{datetime.now().timestamp()}",
                    timestamp=datetime.now(),
                    strategy=StrategyType.BUTTERFLY_SPREAD,
                    symbol=symbol,
                    action="SPREAD",
                    confidence=0.70,
                    expected_return=0.025,
                    risk=0.01,
                    risk_reward_ratio=2.5,
                    algorithm=self.name,
                    algorithm_version=self.version,
                    market_regime="VOLATILE",
                    volatility_regime="HIGH",
                    entry_price=price,
                    option_legs=[]
                        {"type": "call", "strike": price * 0.95, "side": "buy"},
                        {"type": "call", "strike": price * 1.00, "side": "sell", "quantity": 2},
                        {"type": "call", "strike": price * 1.05, "side": "buy"}
                    ],
                    iv_rank=75,
                    historical_win_rate=0.65,
                    sharpe_ratio=1.6
                )
                signals.append(signal)
                
        return signals
        
    def get_supported_strategies(self) -> List[StrategyType]:
        return []
            StrategyType.IRON_CONDOR, StrategyType.IRON_BUTTERFLY,
            StrategyType.BUTTERFLY_SPREAD, StrategyType.CALENDAR_SPREAD,
            StrategyType.STRADDLE, StrategyType.STRANGLE
        ]

class ArbitrageAlgorithm(BaseAlgorithm):
    """Multi-strategy arbitrage algorithm"""
    
    def __init__(self):
        super().__init__("ArbitrageFinder", "2.5")
        
    async def generate_signals(self, market_data: Dict) -> List[TradingSignal]:
        signals = []
        
        # Pairs trading
        pairs = []
            ('XOM', 'CVX'), ('JPM', 'BAC'), ('GOOGL', 'META'),
            ('KO', 'PEP'), ('V', 'MA'), ('UNH', 'CI')
        ]
        
        for symbol1, symbol2 in pairs:
            if symbol1 in market_data and symbol2 in market_data:
                price1 = market_data[symbol1].get('prices', [0])[-1]
                price2 = market_data[symbol2].get('prices', [0])[-1]
                
                if price1 > 0 and price2 > 0:
                    ratio = price1 / price2
                    # Simplified - would need historical mean
                    mean_ratio = 1.0
                    z_score = (ratio - mean_ratio) / 0.1  # Simplified std
                    
                    if abs(z_score) > 2:
                        signal = TradingSignal()
                            signal_id=f"{self.name}_PAIRS_{symbol1}_{symbol2}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            strategy=StrategyType.PAIRS_TRADING,
                            symbol=f"{symbol1}/{symbol2}",
                            action="PAIRS_TRADE",
                            confidence=0.72,
                            expected_return=0.02,
                            risk=0.015,
                            risk_reward_ratio=1.33,
                            algorithm=self.name,
                            algorithm_version=self.version,
                            market_regime="NEUTRAL",
                            volatility_regime="NORMAL",
                            entry_price=ratio,
                            correlated_signals=[symbol1, symbol2],
                            historical_win_rate=0.68,
                            sharpe_ratio=1.2
                        )
                        signals.append(signal)
                        
        return signals
        
    def get_supported_strategies(self) -> List[StrategyType]:
        return []
            StrategyType.PAIRS_TRADING, StrategyType.STATISTICAL_ARB,
            StrategyType.BOX_SPREAD, StrategyType.CONVERSION
        ]

class MasterTradingOrchestrator:
    """Master system that orchestrates all trading algorithms"""
    
    def __init__(self):
        """Initialize the master orchestrator"""
        # Alpaca credentials
        self.api_key = os.getenv('ALPACA_PAPER_API_KEY')
        self.secret_key = os.getenv('ALPACA_PAPER_API_SECRET')
        self.base_url = "https://paper-api.alpaca.markets"
        
        # Initialize clients
        self.trading_client = TradingClient()
            self.api_key, self.secret_key, 
            paper=True, url_override=self.base_url
        )
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.data_client = StockHistoricalDataClient(self.api_key, self.secret_key)
        
        # Initialize algorithms
        self.algorithms = {}
            'momentum': MomentumAlgorithm(),
            'options_spread': OptionsSpreadAlgorithm(),
            'arbitrage': ArbitrageAlgorithm()
        }
        
        # Advanced algorithms if available
        if HAS_ADVANCED_SYSTEMS:
            try:
                self.algorithms['transformer'] = TransformerPredictionSystem()
                self.algorithms['multi_agent'] = MultiAgentTradingSystem()
                self.algorithms['options_arb'] = OptionsArbitrageScanner()
                logger.info("Advanced algorithms loaded successfully")
            except Exception as e:
                logger.warning(f"Could not load advanced algorithms: {e}")
        
        # Trading universe
        self.universe = self._get_trading_universe()
        
        # Performance tracking
        self.signal_history = deque(maxlen=10000)
        self.execution_history = deque(maxlen=5000)
        self.algorithm_performance = {}
        
        # Risk management
        self.max_positions = 20
        self.max_position_size = 0.05  # 5% per position
        self.max_daily_loss = 0.02  # 2% daily loss limit
        self.current_positions = {}
        
        # Database for persistence
        self.db_path = "master_orchestrator.db"
        self._init_database()
        
    def _get_trading_universe(self) -> List[str]:
        """Get comprehensive trading universe"""
        return []
            # Mega caps
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA',
            'BRK.B', 'V', 'JNJ', 'JPM', 'MA', 'UNH', 'HD', 'PG',
            
            # ETFs
            'SPY', 'QQQ', 'IWM', 'DIA', 'XLF', 'XLE', 'XLK', 'XLV',
            'GLD', 'SLV', 'USO', 'TLT', 'HYG', 'LQD', 'EMB',
            
            # Sectors
            'BAC', 'WFC', 'GS', 'MS', 'C',  # Financials
            'XOM', 'CVX', 'COP', 'SLB',  # Energy
            'PFE', 'MRK', 'ABT', 'TMO',  # Healthcare
            'BA', 'CAT', 'HON', 'LMT',  # Industrial
            
            # High volume
            'AMD', 'INTC', 'PYPL', 'NFLX', 'DIS', 'WMT', 'KO', 'PEP',
            'MCD', 'NKE', 'SBUX', 'T', 'VZ', 'CMCSA',
            
            # Volatility
            'VXX', 'UVXY', 'SVXY', 'VIXY'
        ]
        
    def _init_database(self):
        """Initialize SQLite database for tracking"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Signals table
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS signals ()
                signal_id TEXT PRIMARY KEY,
                timestamp DATETIME,
                strategy TEXT,
                symbol TEXT,
                action TEXT,
                confidence REAL,
                expected_return REAL,
                risk REAL,
                algorithm TEXT,
                composite_score REAL,
                executed BOOLEAN,
                execution_price REAL,
                pnl REAL
            )
        ''')
        
        # Algorithm performance table
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS algorithm_performance ()
                algorithm TEXT,
                date DATE,
                total_signals INTEGER,
                executed_trades INTEGER,
                winning_trades INTEGER,
                total_pnl REAL,
                win_rate REAL,
                sharpe_ratio REAL,
                PRIMARY KEY (algorithm, date)
            )
        ''')
        
        # Trade execution table
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS executions ()
                execution_id TEXT PRIMARY KEY,
                signal_id TEXT,
                timestamp DATETIME,
                symbol TEXT,
                side TEXT,
                quantity INTEGER,
                price REAL,
                pnl REAL,
                FOREIGN KEY (signal_id) REFERENCES signals(signal_id)
            )
        ''')
        
        conn.commit()
        conn.close()
        
    async def update_market_data(self) -> Dict:
        """Update market data for all symbols"""
        market_data = {}
        
        try:
            # Get latest bars
            request = StockBarsRequest()
                symbol_or_symbols=self.universe,
                timeframe=TimeFrame.Hour,
                start=datetime.now() - timedelta(days=5)
            )
            
            bars = self.data_client.get_stock_bars(request)
            
            # Process data
            for symbol in self.universe:
                if symbol in bars.data and len(bars.data[symbol]) >= 20:
                    symbol_bars = bars.data[symbol]
                    prices = [bar.close for bar in symbol_bars]
                    volumes = [bar.volume for bar in symbol_bars]
                    
                    market_data[symbol] = {}
                        'prices': prices,
                        'volumes': volumes,
                        'current_price': prices[-1],
                        'sma20': np.mean(prices[-20:]),
                        'sma50': np.mean(prices) if len(prices) >= 50 else np.mean(prices),
                        'volatility': np.std(prices[-20:]) / np.mean(prices[-20:]) * np.sqrt(252),
                        'rsi': self._calculate_rsi(prices),
                        'volume_avg': np.mean(volumes[-20:])
                    }
                    
        except Exception as e:
            logger.error(f"Error updating market data: {e}", exc_info=True)
            
        return market_data
        
    def _calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """Calculate RSI"""
        if len(prices) < period + 1:
            return 50
            
        deltas = np.diff(prices)
        seed = deltas[:period+1]
        up = seed[seed >= 0].sum() / period
        down = -seed[seed < 0].sum() / period
        
        if down == 0:
            return 100
            
        rs = up / down
        return 100 - (100 / (1 + rs))
        
    async def collect_all_signals(self, market_data: Dict) -> List[TradingSignal]:
        """Collect signals from all algorithms"""
        all_signals = []
        
        for algo_name, algorithm in self.algorithms.items():
            try:
                signals = await algorithm.generate_signals(market_data)
                all_signals.extend(signals)
                logger.info(f"{algo_name}: Generated {len(signals)} signals")
            except Exception as e:
                logger.error(f"Error in {algo_name}: {e}", exc_info=True)
                
        return all_signals
        
    def rank_signals(self, signals: List[TradingSignal]) -> List[TradingSignal]:
        """Rank signals using comprehensive scoring system"""
        # Calculate composite scores
        for signal in signals:
            signal.composite_score = signal.composite_score()
            
        # Sort by composite score
        ranked_signals = sorted(signals, key=lambda x: x.composite_score, reverse=True)
        
        # Apply additional filters
        filtered_signals = []
        
        for signal in ranked_signals:
            # Minimum score threshold
            if signal.composite_score < 60:
                continue
                
            # Risk management checks
            if signal.risk > 0.03:  # Max 3% risk per trade
                continue
                
            # Confidence threshold
            if signal.confidence < 0.65:
                continue
                
            filtered_signals.append(signal)
            
        return filtered_signals
        
    def apply_portfolio_constraints(self, signals: List[TradingSignal]) -> List[TradingSignal]:
        """Apply portfolio-level constraints"""
        selected_signals = []
        
        # Track exposure
        sector_exposure = defaultdict(float)
        strategy_exposure = defaultdict(int)
        
        for signal in signals:
            # Check position limits
            if len(self.current_positions) + len(selected_signals) >= self.max_positions:
                break
                
            # Check strategy diversification
            if strategy_exposure[signal.strategy] >= 3:  # Max 3 positions per strategy
                continue
                
            # Check correlation
            correlated_count = sum(1 for s in selected_signals)
                                 if s.symbol in signal.correlated_signals)
            if correlated_count >= 2:
                continue
                
            selected_signals.append(signal)
            strategy_exposure[signal.strategy] += 1
            
        return selected_signals
        
    async def execute_signal(self, signal: TradingSignal):
        """Execute a trading signal"""
        try:
            account = self.trading_client.get_account()
            buying_power = float(account.buying_power)
            
            # Calculate position size
            position_value = min()
                buying_power * self.max_position_size,
                buying_power * 0.1  # Max 10% in one position
            )
            
            if signal.action == "BUY":
                quantity = int(position_value / signal.entry_price)
                
                if quantity > 0:
                    order = MarketOrderRequest()
                        symbol=signal.symbol,
                        qty=quantity,
                        side=OrderSide.BUY,
                        time_in_force=TimeInForce.DAY
                    )
                    
                    response = self.trading_client.submit_order(order)
                    
                    logger.info(f"✅ EXECUTED: {signal.strategy.value} - ")
                              f"BUY {quantity} {signal.symbol} @ MARKET | "
                              f"Algorithm: {signal.algorithm} | "
                              f"Score: {signal.composite_score:.1f}")
                    
                    # Record execution
                    self._record_execution(signal, response)
                    
            elif signal.action == "SPREAD":
                # Execute option spread
                logger.info(f"📊 SPREAD ORDER: {signal.strategy.value} on {signal.symbol}")
                # Would implement actual spread execution here
                
        except Exception as e:
            logger.error(f"Execution error: {e}", exc_info=True)
            
    def _record_execution(self, signal: TradingSignal, order_response):
        """Record execution in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(''')
            UPDATE signals 
            SET executed = 1, execution_price = ?
            WHERE signal_id = ?
        ''', (signal.entry_price, signal.signal_id))
        
        conn.commit()
        conn.close()
        
    async def update_algorithm_performance(self):
        """Update performance metrics for all algorithms"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for algo_name, algorithm in self.algorithms.items():
            # Get today's performance
            cursor.execute(''')
                SELECT COUNT(*) as total_signals,
                       SUM(executed) as executed_trades,
                       SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as winning_trades,
                       SUM(pnl) as total_pnl
                FROM signals
                WHERE algorithm = ? AND DATE(timestamp) = DATE('now')
            ''', (algo_name,))
            
            row = cursor.fetchone()
            if row:
                win_rate = row[2] / row[1] if row[1] > 0 else 0
                
                cursor.execute(''')
                    INSERT OR REPLACE INTO algorithm_performance
                    VALUES (?, DATE('now'), ?, ?, ?, ?, ?, ?)
                ''', (algo_name, row[0], row[1], row[2], row[3], win_rate, 0))
                
        conn.commit()
        conn.close()
        
    def generate_performance_report(self) -> Dict:
        """Generate comprehensive performance report"""
        conn = sqlite3.connect(self.db_path)
        
        # Algorithm comparison
        algo_df = pd.read_sql_query(''')
            SELECT algorithm, 
                   SUM(total_signals) as total_signals,
                   SUM(executed_trades) as executed_trades,
                   SUM(winning_trades) as winning_trades,
                   SUM(total_pnl) as total_pnl,
                   AVG(win_rate) as avg_win_rate
            FROM algorithm_performance
            GROUP BY algorithm
        ''', conn)
        
        # Strategy performance
        strategy_df = pd.read_sql_query(''')
            SELECT strategy,
                   COUNT(*) as signal_count,
                   AVG(confidence) as avg_confidence,
                   AVG(composite_score) as avg_score,
                   SUM(CASE WHEN executed = 1 THEN 1 ELSE 0 END) as executions,
                   AVG(pnl) as avg_pnl
            FROM signals
            GROUP BY strategy
        ''', conn)
        
        conn.close()
        
        report = {}
            'algorithm_performance': algo_df.to_dict('records'),
            'strategy_performance': strategy_df.to_dict('records'),
            'best_algorithm': algo_df.loc[algo_df['total_pnl'].idxmax()]['algorithm'] if len(algo_df) > 0 else None,
            'best_strategy': strategy_df.loc[strategy_df['avg_pnl'].idxmax()]['strategy'] if len(strategy_df) > 0 else None
        }
        
        return report
        
    async def run_orchestrator(self):
        """Main orchestration loop"""
        logger.info("🎼 MASTER TRADING ORCHESTRATOR STARTING")
        logger.info("=" * 80)
        
        account = self.trading_client.get_account()
        logger.info(f"💰 Account Balance: ${float(account.equity):,.2f}")
        logger.info(f"📊 Algorithms Active: {len(self.algorithms)}")
        logger.info(f"🎯 Trading Universe: {len(self.universe)} symbols")
        logger.info("=" * 80)
        
        iteration = 0
        
        while True:
            try:
                iteration += 1
                logger.info(f"\n🔄 Iteration {iteration} - {datetime.now()}")
                
                # 1. Update market data
                market_data = await self.update_market_data()
                logger.info(f"📊 Market data updated for {len(market_data)} symbols")
                
                # 2. Collect signals from all algorithms
                all_signals = await self.collect_all_signals(market_data)
                logger.info(f"📡 Collected {len(all_signals)} total signals")
                
                # 3. Rank signals
                ranked_signals = self.rank_signals(all_signals)
                logger.info(f"🎯 {len(ranked_signals)} signals passed ranking")
                
                # 4. Apply portfolio constraints
                final_signals = self.apply_portfolio_constraints(ranked_signals)
                logger.info(f"✅ {len(final_signals)} signals selected for execution")
                
                # 5. Execute signals
                for signal in final_signals:
                    await self.execute_signal(signal)
                    
                # 6. Update performance
                await self.update_algorithm_performance()
                
                # 7. Show summary every 10 iterations
                if iteration % 10 == 0:
                    report = self.generate_performance_report()
                    logger.info("\n📊 PERFORMANCE SUMMARY")
                    logger.info(f"Best Algorithm: {report['best_algorithm']}")
                    logger.info(f"Best Strategy: {report['best_strategy']}")
                    
                # Wait before next iteration
                await asyncio.sleep(60)  # 1 minute
                
            except KeyboardInterrupt:
                logger.info("\n⏹️ Orchestrator stopped by user")
                break
            except Exception as e:
                logger.error(f"Orchestrator error: {e}", exc_info=True)
                await asyncio.sleep(60)
                
        # Final report
        final_report = self.generate_performance_report()
        logger.info("\n📊 FINAL PERFORMANCE REPORT")
        logger.info("=" * 80)
        
        for algo_perf in final_report['algorithm_performance']:
            logger.info(f"\n{algo_perf['algorithm']}:")
            logger.info(f"  Signals: {algo_perf['total_signals']}")
            logger.info(f"  Executed: {algo_perf['executed_trades']}")
            logger.info(f"  Win Rate: {algo_perf['avg_win_rate']:.1%}")
            logger.info(f"  Total P&L: ${algo_perf['total_pnl']:,.2f}")
            
        with open('orchestrator_report.json', 'w') as f:
            json.dump(final_report, f, indent=2)
            
        logger.info("\n📁 Full report saved to: orchestrator_report.json")
        logger.info("=" * 80)

async def main():
    """Main entry point"""
    orchestrator = MasterTradingOrchestrator()
    await orchestrator.run_orchestrator()

if __name__ == "__main__":
    asyncio.run(main())