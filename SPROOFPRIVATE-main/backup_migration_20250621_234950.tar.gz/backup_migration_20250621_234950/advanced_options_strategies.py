#!/usr/bin/env python3
# TODO: Consider using UnifiedDataAPI from data_api_fixer.py for robust data fetching
"""
Advanced Options Trading Strategies
Multiple sophisticated options strategies with risk management
"""

import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
import logging

# Import our GPU trader
sys.path.append('/home/harry')

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import LimitOrderRequest, MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.data.historical import StockHistoricalDataClient, OptionHistoricalDataClient
from alpaca.data.requests import StockLatestQuoteRequest, OptionLatestQuoteRequest

import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
from scipy.stats import norm
from dotenv import load_dotenv
from alpaca.data.historical import OptionHistoricalDataClient

from universal_market_data import get_current_market_data, validate_price


load_dotenv()

logger = logging.getLogger(__name__)

class StrategyType(Enum):
    """Available strategy types"""
    IRON_CONDOR = "iron_condor"
    BUTTERFLY = "butterfly"
    STRANGLE = "strangle"
    STRADDLE = "straddle"
    COVERED_CALL = "covered_call"
    CASH_SECURED_PUT = "cash_secured_put"
    CALENDAR_SPREAD = "calendar_spread"
    JADE_LIZARD = "jade_lizard"
    WHEEL = "wheel"
    IRON_BUTTERFLY = "iron_butterfly"

@dataclass
class StrategyLeg:
    """Individual leg of an options strategy"""
    symbol: str
    action: str  # 'buy' or 'sell'
    quantity: int
    option_type: str  # 'call' or 'put'
    strike: float
    expiry: datetime
    price: float

@dataclass
class OptionsStrategy:
    """Complete options strategy definition"""
    name: str
    strategy_type: StrategyType
    legs: List[StrategyLeg]
    underlying: str
    net_debit: float  # Negative for credit strategies
    max_profit: float
    max_loss: float
    breakeven_points: List[float]
    profit_probability: float
    target_dte: int
    risk_reward_ratio: float

class StrategyBuilder(ABC):
    """Abstract base class for strategy builders"""
    
    @abstractmethod
    def build_strategy(self, underlying: str, current_price: float, 
                      options_data: Dict) -> Optional[OptionsStrategy]:
        pass
        
    @abstractmethod
    def validate_market_conditions(self, market_data: Dict) -> bool:
        pass

class IronCondorBuilder(StrategyBuilder):
    """Iron Condor strategy builder"""
    
    def __init__(self, width: int = 10, target_delta: float = 0.16):
        self.width = width  # Strike width
        self.target_delta = target_delta
        
    def build_strategy(self, underlying: str, current_price: float, 
                      options_data: Dict) -> Optional[OptionsStrategy]:
        try:
            # Find strikes for iron condor
            # Sell put and call around target delta, buy protection
            
            call_strikes = sorted([float(opt['strike']) for opt in options_data['calls']])
            put_strikes = sorted([float(opt['strike']) for opt in options_data['puts']])
            
            # Find OTM call to sell (short call)
            short_call_strike = None
            for strike in call_strikes:
                if strike > current_price:
                    # Check if delta is close to target
                    short_call_strike = strike
                    break
                    
            # Find OTM put to sell (short put)  
            short_put_strike = None
            for strike in reversed(put_strikes):
                if strike < current_price:
                    short_put_strike = strike
                    break
                    
            if not short_call_strike or not short_put_strike:
                return None
                
            # Protection strikes
            long_call_strike = short_call_strike + self.width
            long_put_strike = short_put_strike - self.width
            
            # Build legs
            legs = []
                # Short put
                StrategyLeg()
                    symbol=f"{underlying}_{short_put_strike}P",
                    action="sell",
                    quantity=1,
                    option_type="put",
                    strike=short_put_strike,
                    expiry=datetime.now() + timedelta(days=30),
                    price=self._get_option_price(options_data, 'puts', short_put_strike)
                ),
                # Long put (protection)
                StrategyLeg()
                    symbol=f"{underlying}_{long_put_strike}P",
                    action="buy", 
                    quantity=1,
                    option_type="put",
                    strike=long_put_strike,
                    expiry=datetime.now() + timedelta(days=30),
                    price=self._get_option_price(options_data, 'puts', long_put_strike)
                ),
                # Short call
                StrategyLeg()
                    symbol=f"{underlying}_{short_call_strike}C",
                    action="sell",
                    quantity=1,
                    option_type="call", 
                    strike=short_call_strike,
                    expiry=datetime.now() + timedelta(days=30),
                    price=self._get_option_price(options_data, 'calls', short_call_strike)
                ),
                # Long call (protection)
                StrategyLeg()
                    symbol=f"{underlying}_{long_call_strike}C",
                    action="buy",
                    quantity=1,
                    option_type="call",
                    strike=long_call_strike,
                    expiry=datetime.now() + timedelta(days=30),
                    price=self._get_option_price(options_data, 'calls', long_call_strike)
                )
            ]
            
            # Calculate P&L metrics
            net_credit = sum(leg.price if leg.action == 'sell' else -leg.price for leg in legs)
            max_profit = net_credit
            max_loss = self.width - net_credit
            
            breakeven_lower = short_put_strike + net_credit
            breakeven_upper = short_call_strike - net_credit
            
            strategy = OptionsStrategy()
                name=f"Iron Condor {underlying}",
                strategy_type=StrategyType.IRON_CONDOR,
                legs=legs,
                underlying=underlying,
                net_debit=-net_credit,  # Negative for credit
                max_profit=max_profit,
                max_loss=max_loss,
                breakeven_points=[breakeven_lower, breakeven_upper],
                profit_probability=self._calculate_profit_probability()
                    current_price, breakeven_lower, breakeven_upper
                ),
                target_dte=30,
                risk_reward_ratio=max_profit / max_loss if max_loss > 0 else 0
            )
            
            return strategy
            
        except Exception as e:
            logger.error(f"Error building iron condor: {e}")
            return None
            
    def _get_option_price(self, options_data: Dict, option_type: str, strike: float) -> float:
        """Get option price for given strike"""
        for opt in options_data[option_type]:
            if abs(float(opt['strike']) - strike) < 0.01:
                return opt.get('mid', 0)
        return 0
        
    def _calculate_profit_probability(self, current_price: float, 
                                    lower_be: float, upper_be: float) -> float:
        """Estimate probability of profit"""
        # Simplified calculation - assumes normal distribution
        distance_lower = abs(current_price - lower_be) / current_price
        distance_upper = abs(current_price - upper_be) / current_price
        
        # Rough estimate based on distance from breakevens
        return max(0.4, min(0.8, (distance_lower + distance_upper) * 0.5))
        
    def validate_market_conditions(self, market_data: Dict) -> bool:
        """Check if market conditions favor iron condors"""
        try:
            # Iron condors work best in low volatility, range-bound markets
            volatility = market_data.get('volatility', 0.25)
            iv_rank = market_data.get('iv_rank', 50)
            
            # Prefer elevated IV for better premium collection
            return iv_rank > 40 and volatility < 0.4
            
        except Exception:
            return False

class StrangleBuilder(StrategyBuilder):
    """Short Strangle strategy builder"""
    
    def __init__(self, target_delta: float = 0.20):
        self.target_delta = target_delta
        
    def build_strategy(self, underlying: str, current_price: float,
                      options_data: Dict) -> Optional[OptionsStrategy]:
        try:
            # Find equidistant OTM strikes
            call_strike = self._find_strike_by_delta(options_data['calls'], 
                                                   self.target_delta, current_price, True)
            put_strike = self._find_strike_by_delta(options_data['puts'],
                                                  self.target_delta, current_price, False)
            
            if not call_strike or not put_strike:
                return None
                
            legs = []
                StrategyLeg()
                    symbol=f"{underlying}_{put_strike}P",
                    action="sell",
                    quantity=1,
                    option_type="put",
                    strike=put_strike,
                    expiry=datetime.now() + timedelta(days=30),
                    price=self._get_option_price(options_data, 'puts', put_strike)
                ),
                StrategyLeg()
                    symbol=f"{underlying}_{call_strike}C", 
                    action="sell",
                    quantity=1,
                    option_type="call",
                    strike=call_strike,
                    expiry=datetime.now() + timedelta(days=30),
                    price=self._get_option_price(options_data, 'calls', call_strike)
                )
            ]
            
            net_credit = sum(leg.price for leg in legs)
            
            strategy = OptionsStrategy()
                name=f"Short Strangle {underlying}",
                strategy_type=StrategyType.STRANGLE,
                legs=legs,
                underlying=underlying,
                net_debit=-net_credit,
                max_profit=net_credit,
                max_loss=float('inf'),  # Undefined for naked strategies
                breakeven_points=[put_strike - net_credit, call_strike + net_credit],
                profit_probability=0.6,  # Rough estimate
                target_dte=30,
                risk_reward_ratio=0.5  # Conservative for undefined risk
            )
            
            return strategy
            
        except Exception as e:
            logger.error(f"Error building strangle: {e}")
            return None
            
    def _find_strike_by_delta(self, options: List[Dict], target_delta: float,
                            current_price: float, is_call: bool) -> Optional[float]:
        """Find strike closest to target delta"""
        # Simplified - would need actual delta calculation
        if is_call:
            # Find OTM call
            for opt in options:
                strike = float(opt['strike'])
                if strike > current_price * 1.05:  # ~20 delta approximation
                    return strike
        else:
            # Find OTM put
            for opt in reversed(options):
                strike = float(opt['strike'])
                if strike < current_price * 0.95:  # ~20 delta approximation
                    return strike
        return None
        
    def _get_option_price(self, options_data: Dict, option_type: str, strike: float) -> float:
        """Get option price for given strike"""
        for opt in options_data[option_type]:
            if abs(float(opt['strike']) - strike) < 0.01:
                return opt.get('mid', 0)
        return 0
        
    def validate_market_conditions(self, market_data: Dict) -> bool:
        """Check if market conditions favor strangles"""
        try:
            # Strangles work best when expecting low volatility
            iv_rank = market_data.get('iv_rank', 50)
            trend_strength = market_data.get('trend_strength', 0.5)
            
            return iv_rank > 50 and trend_strength < 0.3
            
        except Exception:
            return False

class WheelStrategyBuilder(StrategyBuilder):
    """The Wheel Strategy builder"""
    
    def __init__(self, target_delta: float = 0.30):
        self.target_delta = target_delta
        self.cash_secured_put_active = False
        self.covered_call_active = False
        self.shares_owned = 0
        
    def build_strategy(self, underlying: str, current_price: float,
                      options_data: Dict) -> Optional[OptionsStrategy]:
        try:
            if not self.shares_owned:
                # Phase 1: Sell cash-secured put
                return self._build_cash_secured_put(underlying, current_price, options_data)
            else:
                # Phase 2: Sell covered call
                return self._build_covered_call(underlying, current_price, options_data)
                
        except Exception as e:
            logger.error(f"Error building wheel strategy: {e}")
            return None
            
    def _build_cash_secured_put(self, underlying: str, current_price: float,
                               options_data: Dict) -> Optional[OptionsStrategy]:
        """Build cash-secured put leg of wheel"""
        try:
            # Find strike around 30 delta
            put_strike = None
            for opt in reversed(options_data['puts']):
                strike = float(opt['strike'])
                if strike < current_price * 0.95:  # Approximate 30 delta
                    put_strike = strike
                    break
                    
            if not put_strike:
                return None
                
            leg = StrategyLeg()
                symbol=f"{underlying}_{put_strike}P",
                action="sell",
                quantity=1,
                option_type="put",
                strike=put_strike,
                expiry=datetime.now() + timedelta(days=30),
                price=self._get_option_price(options_data, 'puts', put_strike)
            )
            
            strategy = OptionsStrategy()
                name=f"Wheel CSP {underlying}",
                strategy_type=StrategyType.CASH_SECURED_PUT,
                legs=[leg],
                underlying=underlying,
                net_debit=-leg.price,
                max_profit=leg.price,
                max_loss=put_strike * 100 - leg.price,  # If assigned
                breakeven_points=[put_strike - leg.price],
                profit_probability=0.7,
                target_dte=30,
                risk_reward_ratio=leg.price / (put_strike - leg.price)
            )
            
            return strategy
            
        except Exception as e:
            logger.error(f"Error building cash-secured put: {e}")
            return None
            
    def _build_covered_call(self, underlying: str, current_price: float,
                           options_data: Dict) -> Optional[OptionsStrategy]:
        """Build covered call leg of wheel"""
        try:
            # Find strike above cost basis
            call_strike = None
            for opt in options_data['calls']:
                strike = float(opt['strike'])
                if strike > current_price * 1.05:  # Above current price
                    call_strike = strike
                    break
                    
            if not call_strike:
                return None
                
            leg = StrategyLeg()
                symbol=f"{underlying}_{call_strike}C",
                action="sell",
                quantity=1,
                option_type="call",
                strike=call_strike,
                expiry=datetime.now() + timedelta(days=30),
                price=self._get_option_price(options_data, 'calls', call_strike)
            )
            
            strategy = OptionsStrategy()
                name=f"Wheel CC {underlying}",
                strategy_type=StrategyType.COVERED_CALL,
                legs=[leg],
                underlying=underlying,
                net_debit=-leg.price,
                max_profit=leg.price + (call_strike - current_price),  # If called away
                max_loss=current_price * 100,  # If stock goes to zero
                breakeven_points=[current_price - leg.price],
                profit_probability=0.6,
                target_dte=30,
                risk_reward_ratio=0.3  # Conservative
            )
            
            return strategy
            
        except Exception as e:
            logger.error(f"Error building covered call: {e}")
            return None
            
    def _get_option_price(self, options_data: Dict, option_type: str, strike: float) -> float:
        """Get option price for given strike"""
        for opt in options_data[option_type]:
            if abs(float(opt['strike']) - strike) < 0.01:
                return opt.get('mid', 0)
        return 0
        
    def validate_market_conditions(self, market_data: Dict) -> bool:
        """Wheel works in most market conditions"""
        return True  # Wheel is market-neutral

class AdvancedOptionsStrategist:
    """Main class to orchestrate advanced options strategies"""
    
    def __init__(self):
        """Initialize the strategist"""
        self.api_key = os.getenv('ALPACA_PAPER_API_KEY')
        self.api_secret = os.getenv('ALPACA_PAPER_API_SECRET')
        
        self.trading_client = TradingClient(self.api_key, self.api_secret, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.stock_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.option_client = OptionHistoricalDataClient(self.api_key, self.api_secret)
        
        # Initialize strategy builders
        self.strategy_builders = {}
            StrategyType.IRON_CONDOR: IronCondorBuilder(),
            StrategyType.STRANGLE: StrangleBuilder(),
            StrategyType.WHEEL: WheelStrategyBuilder()
        }
        
        self.active_strategies: Dict[str, OptionsStrategy] = {}
        self.strategy_performance: Dict[str, Dict] = {}
        
        logger.info("Advanced Options Strategist initialized")
        
    def analyze_market_regime(self, symbol: str) -> Dict[str, Any]:
        """Analyze current market regime for strategy selection"""
        try:
            # Get market data
            ticker = YFinanceWrapper().get_ticker(symbol)
            hist = ticker.history(period="6mo")
            
            if len(hist) < 50:
                return {}
                
            # Calculate regime indicators
            volatility = hist['Close'].pct_change().rolling(30).std() * np.sqrt(252)
            current_vol = volatility.iloc[-1]
            
            # Trend analysis
            sma_20 = hist['Close'].rolling(20).mean()
            sma_50 = hist['Close'].rolling(50).mean()
            
            trend_strength = abs(sma_20.iloc[-1] - sma_50.iloc[-1]) / hist['Close'].iloc[-1]
            
            # IV rank approximation
            vol_percentile = (volatility.iloc[-1] - volatility.quantile(0.1)) / ()
                volatility.quantile(0.9) - volatility.quantile(0.1)
            ) * 100
            
            return {}
                'volatility': current_vol,
                'iv_rank': max(0, min(100, vol_percentile)),
                'trend_strength': trend_strength,
                'market_regime': self._classify_regime(current_vol, trend_strength)
            }
            
        except Exception as e:
            logger.error(f"Error analyzing market regime: {e}")
            return {}
            
    def _classify_regime(self, volatility: float, trend_strength: float) -> str:
        """Classify market regime"""
        if volatility > 0.3:
            return "high_volatility"
        elif trend_strength > 0.2:
            return "trending"
        else:
            return "range_bound"
            
    def recommend_strategy(self, symbol: str) -> Optional[OptionsStrategy]:
        """Recommend best strategy based on market conditions"""
        try:
            # Analyze market regime
            market_data = self.analyze_market_regime(symbol)
            if not market_data:
                return None
                
            # Get current price
            quote = self.stock_client.get_stock_latest_quote()
                StockLatestQuoteRequest(symbol_or_symbols=symbol)
            )
            current_price = float(quote[symbol].ask_price)
            
            # Mock options data (would get from API in production)
            market_data = get_current_market_data()  # Real data only
            
            # Evaluate strategies
            best_strategy = None
            best_score = 0
            
            for strategy_type, builder in self.strategy_builders.items():
                if builder.validate_market_conditions(market_data):
                    strategy = builder.build_strategy(symbol, current_price, options_data)
                    
                    if strategy:
                        score = self._score_strategy(strategy, market_data)
                        if score > best_score:
                            best_score = score
                            best_strategy = strategy
                            
            return best_strategy
            
        except Exception as e:
            logger.error(f"Error recommending strategy: {e}")
            return None
            
    market_data = get_current_market_data()  # Real data only
        """Generate mock options data for testing"""
        # In production, this would fetch real options data
        strikes = np.arange(current_price * 0.8, current_price * 1.2, 5)
        
        calls = []
        puts = []
        
        for strike in strikes:
            calls.append({)
                'strike': strike,
                'mid': max(0.1, current_price - strike + 2) if strike < current_price else 2,
                'bid': 1.8,
                'ask': 2.2
            })
            
            puts.append({)
                'strike': strike,
                'mid': max(0.1, strike - current_price + 2) if strike > current_price else 2,
                'bid': 1.8,
                'ask': 2.2
            })
            
        return {'calls': calls, 'puts': puts}
        
    def _score_strategy(self, strategy: OptionsStrategy, market_data: Dict) -> float:
        """Score strategy based on market conditions and metrics"""
        try:
            score = 0
            
            # Risk-reward ratio
            score += min(strategy.risk_reward_ratio * 20, 30)
            
            # Probability of profit
            score += strategy.profit_probability * 40
            
            # Market regime fit
            regime = market_data.get('market_regime', 'range_bound')
            
            if strategy.strategy_type == StrategyType.IRON_CONDOR and regime == 'range_bound':
                score += 20
            elif strategy.strategy_type == StrategyType.STRANGLE and regime == 'range_bound':
                score += 15
            elif strategy.strategy_type == StrategyType.WHEEL:
                score += 10  # Always decent
                
            # IV rank bonus
            iv_rank = market_data.get('iv_rank', 50)
            if iv_rank > 60:
                score += 10
                
            return score
            
        except Exception as e:
            logger.debug(f"Error scoring strategy: {e}")
            return 0
            
    def execute_strategy(self, strategy: OptionsStrategy) -> bool:
        """Execute the options strategy"""
        try:
            logger.info(f"Executing strategy: {strategy.name}")
            logger.info(f"Max Profit: ${strategy.max_profit:.2f}")
            logger.info(f"Max Loss: ${strategy.max_loss:.2f}")
            logger.info(f"Risk/Reward: {strategy.risk_reward_ratio:.2f}")
            
            # Execute each leg
            for leg in strategy.legs:
                side = OrderSide.SELL if leg.action == 'sell' else OrderSide.BUY
                
                # Mock order for now (would be real in production)
                logger.info(f"  {leg.action.upper()} {leg.quantity} {leg.symbol} @ ${leg.price:.2f}")
                
            # Track strategy
            self.active_strategies[strategy.name] = strategy
            self.strategy_performance[strategy.name] = {}
                'entry_time': datetime.now(),
                'entry_credit': strategy.net_debit,
                'max_profit': strategy.max_profit,
                'max_loss': strategy.max_loss
            }
            
            return True
            
        except Exception as e:
            logger.error(f"Error executing strategy: {e}")
            return False
            
    def display_strategy_analysis(self, symbol: str):
        """Display comprehensive strategy analysis"""
        logger.info("=" * 60)
        logger.info(f"🎯 ADVANCED STRATEGY ANALYSIS: {symbol}")
        logger.info("=" * 60)
        
        market_data = self.analyze_market_regime(symbol)
        recommended = self.recommend_strategy(symbol)
        
        if market_data:
            logger.info(f"Market Regime: {market_data.get('market_regime', 'unknown')}")
            logger.info(f"Volatility: {market_data.get('volatility', 0):.1%}")
            logger.info(f"IV Rank: {market_data.get('iv_rank', 0):.0f}")
            logger.info(f"Trend Strength: {market_data.get('trend_strength', 0):.2f}")
            
        if recommended:
            logger.info(f"\n📊 RECOMMENDED STRATEGY: {recommended.name}")
            logger.info(f"Type: {recommended.strategy_type.value}")
            logger.info(f"Net Credit/Debit: ${recommended.net_debit:.2f}")
            logger.info(f"Max Profit: ${recommended.max_profit:.2f}")
            logger.info(f"Max Loss: ${recommended.max_loss:.2f}")
            logger.info(f"Profit Probability: {recommended.profit_probability:.1%}")
            logger.info(f"Risk/Reward: {recommended.risk_reward_ratio:.2f}")
            
            logger.info(f"\n📋 STRATEGY LEGS:")
            for i, leg in enumerate(recommended.legs, 1):
                logger.info(f"  {i}. {leg.action.upper()} {leg.quantity} ")
                           f"{leg.option_type} @ ${leg.strike} for ${leg.price:.2f}")
                           
        logger.info("=" * 60)

if __name__ == "__main__":
    strategist = AdvancedOptionsStrategist()
    
    # Analyze strategies for different symbols
    symbols = ['SPY', 'QQQ', 'AAPL']
    
    for symbol in symbols:
        strategist.display_strategy_analysis(symbol)
        recommended = strategist.recommend_strategy(symbol)
        
        if recommended:
            print(f"\nExecute {recommended.name}? (y/n): ", end='')
            if input().lower() == 'y':
                strategist.execute_strategy(recommended)
        
        print("\n" + "="*60 + "\n")