
#!/usr/bin/env python3
"""
Cron Job Scheduler for US Market Hours
Manages automated trading tasks for paper and live trading
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import subprocess
import logging
from datetime import datetime, time
import pytz

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/cron_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class CronScheduler:
    """Manages cron job scheduling for trading systems"""
    
    def __init__(self):
        self.est = pytz.timezone('US/Eastern')
        self.scripts_dir = '/home/harry/alpaca-mcp'
        
    def is_market_hours(self):
        """Check if current time is during market hours"""
        now = datetime.now(self.est)
        current_time = now.time()
        
        # Regular market hours: 9:30 AM - 4:00 PM EST
        market_open = time(9, 30)
        market_close = time(16, 0)
        
        # Check if weekday (Monday = 0, Friday = 4)
        if now.weekday() > 4:  # Weekend
            return False
            
        return market_open <= current_time <= market_close
        
    def is_pre_market(self):
        """Check if current time is pre-market"""
        now = datetime.now(self.est)
        current_time = now.time()
        
        # Pre-market: 4:00 AM - 9:30 AM EST
        pre_market_open = time(4, 0)
        pre_market_close = time(9, 30)
        
        if now.weekday() > 4:  # Weekend
            return False
            
        return pre_market_open <= current_time < pre_market_close
        
    def is_after_hours(self):
        """Check if current time is after-hours"""
        now = datetime.now(self.est)
        current_time = now.time()
        
        # After-hours: 4:00 PM - 8:00 PM EST
        after_hours_open = time(16, 0)
        after_hours_close = time(20, 0)
        
        if now.weekday() > 4:  # Weekend
            return False
            
        return after_hours_open < current_time <= after_hours_close
        
    def create_crontab_entries(self):
        """Generate crontab entries for all trading tasks"""
        
        cron_entries = f"""
# Ultra AI Trading System - Cron Schedule
# All times in system local time (convert from EST as needed)
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
PYTHONPATH=/home/harry/alpaca-mcp

# === PRE-MARKET TASKS (4:00 AM - 9:30 AM EST) ===

# Data collection - Every 5 minutes during pre-market
*/5 4-9 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python market_data_collector.py >> /home/harry/alpaca-mcp/logs/data_collector.log 2>&1

# Transformer predictions - 15 minutes before market open
15 9 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python transformer_prediction_system.py >> /home/harry/alpaca-mcp/logs/transformer.log 2>&1

# Strategy analysis - 10 minutes before market open
20 9 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python strategy_enhancement_engine.py >> /home/harry/alpaca-mcp/logs/strategy_engine.log 2>&1

# === MARKET HOURS TASKS (9:30 AM - 4:00 PM EST) ===

# Paper trading bot - Continuous during market hours
30 9 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python paper_trading_bot.py >> /home/harry/alpaca-mcp/logs/paper_trading.log 2>&1

# Live trading bot - Continuous during market hours (CAREFULLY CONTROLLED)
# 30 9 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python live_trading_bot.py >> /home/harry/alpaca-mcp/logs/live_trading.log 2>&1

# Arbitrage scanner - Every minute during market hours
* 9-15 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python arbitrage_scanner.py >> /home/harry/alpaca-mcp/logs/arbitrage.log 2>&1
0-59 16 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python arbitrage_scanner.py >> /home/harry/alpaca-mcp/logs/arbitrage.log 2>&1

# Options strategy scanner - Every 15 minutes
*/15 9-15 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python options_scanner.py >> /home/harry/alpaca-mcp/logs/options.log 2>&1
0,15,30,45 16 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python options_scanner.py >> /home/harry/alpaca-mcp/logs/options.log 2>&1

# Market data collection - Every 5 minutes
*/5 9-15 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python market_data_collector.py >> /home/harry/alpaca-mcp/logs/data_collector.log 2>&1
0,5,10,15,20,25,30,35,40,45,50,55 16 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python market_data_collector.py >> /home/harry/alpaca-mcp/logs/data_collector.log 2>&1

# Performance tracking - Every 30 minutes
*/30 9-15 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python performance_tracker.py >> /home/harry/alpaca-mcp/logs/performance.log 2>&1
0,30 16 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python performance_tracker.py >> /home/harry/alpaca-mcp/logs/performance.log 2>&1

# === AFTER-HOURS TASKS (4:00 PM - 8:00 PM EST) ===

# End of day analysis - 15 minutes after market close
15 16 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python daily_analysis.py >> /home/harry/alpaca-mcp/logs/daily_analysis.log 2>&1

# Model training - 30 minutes after market close
30 16 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python model_training.py >> /home/harry/alpaca-mcp/logs/model_training.log 2>&1

# Database cleanup - 1 hour after market close
0 17 * * 1-5 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python database_maintenance.py >> /home/harry/alpaca-mcp/logs/db_maintenance.log 2>&1

# === WEEKEND TASKS ===

# Weekly performance report - Sunday night
0 20 * * 0 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python weekly_report.py >> /home/harry/alpaca-mcp/logs/weekly_report.log 2>&1

# Full system test - Saturday morning
0 10 * * 6 cd {self.scripts_dir} && /home/harry/miniconda3/bin/python comprehensive_system_test.py >> /home/harry/alpaca-mcp/logs/system_test.log 2>&1

# === MONITORING ===

# System health check - Every 10 minutes
*/10 * * * * cd {self.scripts_dir} && /home/harry/miniconda3/bin/python system_monitor.py >> /home/harry/alpaca-mcp/logs/monitor.log 2>&1
"""
        return cron_entries
        
    def install_crontab(self):
        """Install crontab entries"""
        try:
            # Save current crontab
            current_cron = subprocess.run(['crontab', '-l'], 
                                        capture_output=True, 
                                        text=True).stdout
            
            # Add our entries
            new_cron = current_cron + self.create_crontab_entries()
            
            # Write to temp file
            with open('/tmp/trading_cron', 'w') as f:
                f.write(new_cron)
                
            # Install new crontab
            result = subprocess.run(['crontab', '/tmp/trading_cron'], 
                                  capture_output=True, 
                                  text=True)
            
            if result.returncode == 0:
                logger.info("Crontab installed successfully")
                return True
            else:
                logger.error(f"Failed to install crontab: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Error installing crontab: {e}")
            return False
            
    def remove_crontab(self):
        """Remove our crontab entries"""
        try:
            # Get current crontab
            current_cron = subprocess.run(['crontab', '-l'], 
                                        capture_output=True, 
                                        text=True).stdout
            
            # Remove our section
            lines = current_cron.split('\n')
            filtered_lines = []
            skip = False
            
            for line in lines:
                if '# Ultra AI Trading System - Cron Schedule' in line:
                    skip = True
                elif skip and line.strip() == '':
                    skip = False
                    continue
                    
                if not skip:
                    filtered_lines.append(line)
                    
            # Write filtered crontab
            new_cron = '\n'.join(filtered_lines)
            with open('/tmp/trading_cron_filtered', 'w') as f:
                f.write(new_cron)
                
            # Install filtered crontab
            subprocess.run(['crontab', '/tmp/trading_cron_filtered'])
            logger.info("Trading crontab entries removed")
            
        except Exception as e:
            logger.error(f"Error removing crontab: {e}")

def main():
    """Main function"""
    scheduler = CronScheduler()
    
    print("Ultra AI Trading System - Cron Scheduler")
    print("========================================")
    print(f"Current time (EST): {datetime.now(scheduler.est).strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Market hours: {scheduler.is_market_hours()}")
    print(f"Pre-market: {scheduler.is_pre_market()}")
    print(f"After-hours: {scheduler.is_after_hours()}")
    print()
    
    # Show crontab entries
    print("Crontab entries to be installed:")
    print("-" * 50)
    print(scheduler.create_crontab_entries()
    
    # Install option
    response = input("\nInstall crontab entries? (y/n): ")
    if response.lower() == 'y':
        if scheduler.install_crontab():
            print("✅ Crontab installed successfully!")
            print("\nTo view: crontab -l")
            print("To edit: crontab -e")
            print("To remove: python cron_scheduler.py --remove")
        else:
            print("❌ Failed to install crontab")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--remove':
        scheduler = CronScheduler()
        scheduler.remove_crontab()
    else:
        main()