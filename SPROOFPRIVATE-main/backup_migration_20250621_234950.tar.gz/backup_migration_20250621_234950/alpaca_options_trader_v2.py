
#!/usr/bin/env python3
"""
Alpaca Options Trader V2 - Correct Implementation
================================================
Real options trading using Alpaca's official Python SDK
Based on official examples from alpaca-py repository
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import os
import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import logging
import json
import time
import random
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')

from alpaca.trading.client import TradingClient
from alpaca.data.historical.option import OptionHistoricalDataClient
from alpaca.data.live.option import OptionDataStream

from alpaca.data.requests import ()
    OptionLatestQuoteRequest,
    OptionChainRequest,
    StockLatestQuoteRequest
)
from alpaca.trading.requests import ()
    GetOptionContractsRequest,
    MarketOrderRequest,
    LimitOrderRequest,
    GetOrdersRequest,
    OptionLegRequest
)
from alpaca.trading.enums import ()
    AssetStatus,
    ExerciseStyle,
    OrderSide,
    OrderType,
    TimeInForce,
    QueryOrderStatus,
    OrderClass,
    ContractType
)
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.historical import OptionHistoricalDataClient

logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Alpaca credentials
API_KEY = os.getenv('ALPACA_PAPER_API_KEY')
SECRET_KEY = os.getenv('ALPACA_PAPER_API_SECRET')

@dataclass
class OptionsSpread:
    """Options spread structure"""
    spread_type: str
    underlying: str
    legs: List[Dict[str, Any]]
    total_cost: float
    max_profit: float
    max_loss: float
    breakeven: List[float]
    entry_time: datetime
    order_id: str
    status: str = "PENDING"

class AlpacaOptionsTraderV2:
    """Corrected Alpaca options trading implementation"""
    
    def __init__(self):
        # Initialize clients
        self.trading_client = TradingClient(API_KEY, SECRET_KEY, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.stock_data_client = StockHistoricalDataClient(API_KEY, SECRET_KEY)
        self.options_data_client = OptionHistoricalDataClient(API_KEY, SECRET_KEY)
        
        # Get account info
        self.account = self.trading_client.get_account()
        self.initial_capital = float(self.account.equity)
        
        logger.info(f"🎯 ALPACA OPTIONS TRADER V2 INITIALIZED")
        logger.info(f"💰 Account Equity: ${self.initial_capital:,.2f}")
        logger.info(f"💵 Buying Power: ${float(self.account.buying_power):,.2f}")
        logger.info(f"⚡ Options Trading: ENABLED")
        
        # High liquidity underlyings
        self.option_symbols = []
            'SPY', 'QQQ', 'AAPL', 'MSFT', 'NVDA', 'TSLA', 'AMZN', 'META'
        ]
        
        # Risk parameters
        self.max_risk_per_trade = 0.02  # 2% max risk
        self.min_profit_ratio = 0.5     # 50% profit to risk ratio
        self.max_positions = 10
        
        # Tracking
        self.active_spreads = {}
        self.total_trades = 0
        
        # Set timezone
        self.tz = ZoneInfo("America/New_York")
        
        logger.info(f"📊 Trading Symbols: {len(self.option_symbols)}")
    
    async def get_option_contracts(self, underlying: str, days_out: int = 30) -> List[Any]:
        """Get available option contracts with CORRECT string parameters"""
        try:
            # Get current stock price
            quote_request = StockLatestQuoteRequest(symbol_or_symbols=underlying)
            quote = self.stock_data_client.get_stock_latest_quote(quote_request)
            
            if underlying in quote:
                current_price = float(quote[underlying].ask_price or quote[underlying].bid_price)
            else:
                current_price = 100.0
                
            logger.info(f"Current price of {underlying}: ${current_price:.2f}")
            
            # Set date range
            now = datetime.now(tz=self.tz)
            start_date = now + timedelta(days=7)  # Skip weeklies
            end_date = now + timedelta(days=days_out)
            
            # Calculate strike range (±15% from current price)
            strike_low = str(int(current_price * 0.85))   # STRING!
            strike_high = str(int(current_price * 1.15))  # STRING!
            
            # Create request with STRING strike prices
            contracts_request = GetOptionContractsRequest()
                underlying_symbols=[underlying],
                status=AssetStatus.ACTIVE,
                expiration_date_gte=start_date.date(),
                expiration_date_lte=end_date.strftime("%Y-%m-%d"),
                style=ExerciseStyle.AMERICAN,
                strike_price_gte=strike_low,  # STRING
                strike_price_lte=strike_high,  # STRING
                limit=100
            )
            
            contracts = self.trading_client.get_option_contracts(contracts_request)
            
            if contracts.option_contracts:
                logger.info(f"Found {len(contracts.option_contracts)} option contracts for {underlying}")
                return contracts.option_contracts
            else:
                logger.warning(f"No contracts found for {underlying}")
                return []
                
        except Exception as e:
            logger.error(f"Error getting option contracts: {str(e)}")
            return []
    
    async def get_option_quote(self, symbol: str) -> Dict[str, float]:
        """Get current option quote"""
        try:
            quote_request = OptionLatestQuoteRequest(symbol_or_symbols=symbol)
            quotes = self.options_data_client.get_option_latest_quote(quote_request)
            
            if symbol in quotes:
                q = quotes[symbol]
                return {}
                    'bid': float(q.bid_price) if q.bid_price else 0,
                    'ask': float(q.ask_price) if q.ask_price else 0,
                    'mid': (float(q.bid_price or 0) + float(q.ask_price or 0)) / 2,
                    'bid_size': int(q.bid_size) if q.bid_size else 0,
                    'ask_size': int(q.ask_size) if q.ask_size else 0
                }
            
        except Exception as e:
            logger.error(f"Error getting option quote for {symbol}: {str(e)}")
        
        # Return default values if quote fails
        return {'bid': 1.0, 'ask': 1.5, 'mid': 1.25, 'bid_size': 10, 'ask_size': 10}
    
    async def find_bull_call_spreads(self, underlying: str, contracts: List[Any]) -> List[Dict]:
        """Find bull call spread opportunities"""
        spreads = []
        
        # Group contracts by expiration
        by_expiry = {}
        for contract in contracts:
            if contract.type == ContractType.CALL:
                expiry = contract.expiration_date
                if expiry not in by_expiry:
                    by_expiry[expiry] = []
                by_expiry[expiry].append(contract)
        
        # Find spreads for each expiration
        for expiry, calls in by_expiry.items():
            # Sort by strike price
            calls.sort(key=lambda x: float(x.strike_price))
            
            # Look for adjacent strikes
            for i in range(len(calls) - 1):
                lower_call = calls[i]
                upper_call = calls[i + 1]
                
                # Get quotes
                lower_quote = await self.get_option_quote(lower_call.symbol)
                upper_quote = await self.get_option_quote(upper_call.symbol)
                
                if lower_quote['ask'] > 0 and upper_quote['bid'] > 0:
                    # Calculate spread metrics
                    net_debit = lower_quote['ask'] - upper_quote['bid']
                    strike_diff = float(upper_call.strike_price) - float(lower_call.strike_price)
                    
                    if net_debit > 0 and strike_diff > net_debit:
                        max_profit = (strike_diff - net_debit) * 100
                        max_loss = net_debit * 100
                        
                        if max_profit > 0 and max_profit / max_loss >= self.min_profit_ratio:
                            spreads.append({)
                                'type': 'BULL_CALL_SPREAD',
                                'underlying': underlying,
                                'legs': []
                                    {'contract': lower_call, 'action': 'BUY', 'quote': lower_quote},
                                    {'contract': upper_call, 'action': 'SELL', 'quote': upper_quote}
                                ],
                                'net_debit': net_debit,
                                'max_profit': max_profit,
                                'max_loss': max_loss,
                                'profit_ratio': max_profit / max_loss,
                                'breakeven': float(lower_call.strike_price) + net_debit,
                                'expiry': expiry,
                                'lower_strike': float(lower_call.strike_price),
                                'upper_strike': float(upper_call.strike_price)
                            })
        
        return spreads
    
    async def find_iron_condors(self, underlying: str, contracts: List[Any]) -> List[Dict]:
        """Find iron condor opportunities"""
        condors = []
        
        # Get current stock price
        quote_request = StockLatestQuoteRequest(symbol_or_symbols=underlying)
        quote = self.stock_data_client.get_stock_latest_quote(quote_request)
        current_price = float(quote[underlying].ask_price) if underlying in quote else 100
        
        # Group contracts by expiration
        by_expiry = {}
        for contract in contracts:
            expiry = contract.expiration_date
            if expiry not in by_expiry:
                by_expiry[expiry] = {'calls': [], 'puts': []}
            
            if contract.type == ContractType.CALL:
                by_expiry[expiry]['calls'].append(contract)
            else:
                by_expiry[expiry]['puts'].append(contract)
        
        # Find iron condors for each expiration
        for expiry, options in by_expiry.items():
            calls = sorted(options['calls'], key=lambda x: float(x.strike_price))
            puts = sorted(options['puts'], key=lambda x: float(x.strike_price))
            
            # Find OTM options
            otm_puts = [p for p in puts if float(p.strike_price) < current_price * 0.95]
            otm_calls = [c for c in calls if float(c.strike_price) > current_price * 1.05]
            
            if len(otm_puts) >= 2 and len(otm_calls) >= 2:
                # Select strikes
                put_sell = otm_puts[-1]  # Highest OTM put
                put_buy = otm_puts[-2]   # Next highest
                call_sell = otm_calls[0]  # Lowest OTM call
                call_buy = otm_calls[1]   # Next lowest
                
                # Get quotes
                put_sell_quote = await self.get_option_quote(put_sell.symbol)
                put_buy_quote = await self.get_option_quote(put_buy.symbol)
                call_sell_quote = await self.get_option_quote(call_sell.symbol)
                call_buy_quote = await self.get_option_quote(call_buy.symbol)
                
                # Calculate iron condor metrics
                if all(q['bid'] > 0 for q in [put_sell_quote, call_sell_quote]):
                    net_credit = ()
                        put_sell_quote['bid'] - put_buy_quote['ask'] +
                        call_sell_quote['bid'] - call_buy_quote['ask']
                    )
                    
                    if net_credit > 0:
                        strike_width = float(put_sell.strike_price) - float(put_buy.strike_price)
                        max_profit = net_credit * 100
                        max_loss = (strike_width * 100) - max_profit
                        
                        if max_loss > 0 and max_profit / max_loss >= 0.3:  # 30% minimum for IC
                            condors.append({)
                                'type': 'IRON_CONDOR',
                                'underlying': underlying,
                                'legs': []
                                    {'contract': put_buy, 'action': 'BUY', 'quote': put_buy_quote},
                                    {'contract': put_sell, 'action': 'SELL', 'quote': put_sell_quote},
                                    {'contract': call_sell, 'action': 'SELL', 'quote': call_sell_quote},
                                    {'contract': call_buy, 'action': 'BUY', 'quote': call_buy_quote}
                                ],
                                'net_credit': net_credit,
                                'max_profit': max_profit,
                                'max_loss': max_loss,
                                'profit_ratio': max_profit / max_loss,
                                'breakeven_lower': float(put_sell.strike_price) - net_credit,
                                'breakeven_upper': float(call_sell.strike_price) + net_credit,
                                'expiry': expiry,
                                'current_price': current_price
                            })
        
        return condors
    
    async def execute_single_option(self, contract: Any, side: OrderSide, limit_price: float = None) -> Optional[str]:
        """Execute single option order"""
        try:
            if limit_price:
                # Limit order
                req = LimitOrderRequest()
                    symbol=contract.symbol,
                    qty=1,
                    side=side,
                    limit_price=round(limit_price, 2),
                    time_in_force=TimeInForce.DAY,
                )
            else:
                # Market order
                req = MarketOrderRequest()
                    symbol=contract.symbol,
                    qty=1,
                    side=side,
                    time_in_force=TimeInForce.DAY,
                )
            
            order = self.trading_client.submit_order(req)
            logger.info(f"✅ Order submitted: {side} {contract.symbol} @ {'MARKET' if not limit_price else f'${limit_price:.2f}'}")
            return order.id
            
        except Exception as e:
            logger.error(f"Order failed: {str(e)}")
            return None
    
    async def execute_spread(self, spread: Dict) -> bool:
        """Execute multi-leg spread order"""
        try:
            spread_id = f"{spread['underlying']}_{spread['type']}_{int(time.time())}"
            logger.info(f"\n🔥 EXECUTING {spread['type']}")
            logger.info(f"   Underlying: {spread['underlying']}")
            logger.info(f"   Max Profit: ${spread['max_profit']:.2f}")
            logger.info(f"   Max Loss: ${spread['max_loss']:.2f}")
            logger.info(f"   Profit Ratio: {spread['profit_ratio']:.2f}")
            
            # Build legs for multi-leg order
            order_legs = []
            for leg in spread['legs']:
                contract = leg['contract']
                side = OrderSide.BUY if leg['action'] == 'BUY' else OrderSide.SELL
                
                leg_req = OptionLegRequest()
                    symbol=contract.symbol,
                    side=side,
                    ratio_qty=1
                )
                order_legs.append(leg_req)
                
                logger.info(f"   Leg: {leg['action']} {contract.type} ${contract.strike_price} exp {contract.expiration_date}")
            
            # Submit multi-leg order
            if spread['type'] in ['BULL_CALL_SPREAD', 'BEAR_PUT_SPREAD']:
                # Debit spread - use limit order
                req = LimitOrderRequest()
                    qty=1,
                    order_class=OrderClass.MLEG,
                    time_in_force=TimeInForce.DAY,
                    legs=order_legs,
                    limit_price=round(spread['net_debit'] * 1.02, 2)  # 2% above mid
                )
            else:
                # Credit spread - use limit order
                req = LimitOrderRequest()
                    qty=1,
                    order_class=OrderClass.MLEG,
                    time_in_force=TimeInForce.DAY,
                    legs=order_legs,
                    limit_price=round(spread['net_credit'] * 0.98, 2)  # 2% below mid
                )
            
            order = self.trading_client.submit_order(req)
            
            # Track spread
            options_spread = OptionsSpread()
                spread_type=spread['type'],
                underlying=spread['underlying'],
                legs=spread['legs'],
                total_cost=spread.get('net_debit', -spread.get('net_credit', 0)),
                max_profit=spread['max_profit'],
                max_loss=spread['max_loss'],
                breakeven=[]
                    spread.get('breakeven', spread.get('breakeven_lower', 0)),
                    spread.get('breakeven_upper', 0)
                ],
                entry_time=datetime.now(),
                order_id=order.id
            )
            
            self.active_spreads[spread_id] = options_spread
            self.total_trades += 1
            
            logger.info(f"✅ SPREAD ORDER SUBMITTED: {order.id}")
            return True
            
        except Exception as e:
            logger.error(f"Spread execution error: {str(e)}")
            return False
    
    async def monitor_positions(self):
        """Monitor open orders and positions"""
        try:
            # Get open orders
            orders_request = GetOrdersRequest()
                status=QueryOrderStatus.OPEN,
                limit=100
            )
            open_orders = self.trading_client.get_orders(orders_request)
            
            # Get all positions
            positions = self.trading_client.get_all_positions()
            
            logger.info(f"📊 Monitoring: {len(positions)} positions, {len(open_orders)} open orders")
            
            # Check spread status
            for spread_id, spread in list(self.active_spreads.items()):
                try:
                    order = self.trading_client.get_order_by_id(spread.order_id)
                    
                    if order.status == 'filled' and spread.status == "PENDING":
                        spread.status = "FILLED"
                        logger.info(f"✅ Spread {spread_id} filled")
                    elif order.status in ['canceled', 'expired']:
                        spread.status = "CANCELED"
                        logger.info(f"❌ Spread {spread_id} canceled/expired")
                        del self.active_spreads[spread_id]
                        
                except Exception as e:
                    logger.error(f"Error checking order {spread.order_id}: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Monitoring error: {str(e)}")
    
    async def run_options_trading(self, duration_minutes: int = 2):
        """Run options trading session"""
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🎯 ALPACA OPTIONS TRADING SESSION V2")
        logger.info(f"{'='*100}")
        logger.info(f"⏰ Duration: {duration_minutes} minutes")
        logger.info(f"📊 Symbols: {len(self.option_symbols)}")
        logger.info(f"💰 Initial Capital: ${self.initial_capital:,.2f}")
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        cycle = 0
        
        while datetime.now() < end_time:
            cycle += 1
            cycle_start = time.time()
            
            logger.info(f"\n{'='*80}")
            logger.info(f"🔄 TRADING CYCLE {cycle}")
            logger.info(f"{'='*80}")
            
            # Monitor existing positions
            await self.monitor_positions()
            
            # Find opportunities
            total_opportunities = 0
            trades_executed = 0
            all_opportunities = []
            
            for symbol in self.option_symbols[:3]:  # Top 3 symbols
                logger.info(f"\n🔍 Analyzing {symbol}...")
                
                # Get option contracts
                contracts = await self.get_option_contracts(symbol, days_out=45)
                
                if contracts:
                    logger.info(f"   Found {len(contracts)} contracts")
                    
                    # Find spreads
                    bull_spreads = await self.find_bull_call_spreads(symbol, contracts)
                    iron_condors = await self.find_iron_condors(symbol, contracts)
                    
                    all_opportunities.extend(bull_spreads)
                    all_opportunities.extend(iron_condors)
                    
                    total_opportunities += len(bull_spreads) + len(iron_condors)
                    
                    if bull_spreads:
                        logger.info(f"   Found {len(bull_spreads)} bull call spreads")
                    if iron_condors:
                        logger.info(f"   Found {len(iron_condors)} iron condors")
            
            # Sort by profit ratio
            all_opportunities.sort(key=lambda x: x['profit_ratio'], reverse=True)
            
            # Execute top opportunities
            for opp in all_opportunities[:2]:  # Max 2 trades per cycle
                if trades_executed < 2 and len(self.active_spreads) < self.max_positions:
                    if opp['profit_ratio'] >= 0.5:  # Minimum 50% profit ratio
                        if await self.execute_spread(opp):
                            trades_executed += 1
                            await asyncio.sleep(1)
            
            # Get account status
            account = self.trading_client.get_account()
            equity = float(account.equity)
            total_pnl = equity - self.initial_capital
            
            # Cycle summary
            cycle_time = time.time() - cycle_start
            
            logger.info(f"\n📊 CYCLE {cycle} SUMMARY:")
            logger.info(f"   🔍 Opportunities Found: {total_opportunities}")
            logger.info(f"   ⚡ Trades Executed: {trades_executed}")
            logger.info(f"   📦 Active Spreads: {len(self.active_spreads)}")
            logger.info(f"   💰 Account Equity: ${equity:,.2f}")
            logger.info(f"   📊 Total P&L: ${total_pnl:+,.2f} ({total_pnl/self.initial_capital*100:+.1f}%)")
            logger.info(f"   🎯 Total Trades: {self.total_trades}")
            logger.info(f"   ⏱️ Cycle Time: {cycle_time:.1f}s")
            
            # Wait before next cycle
            await asyncio.sleep(max(5, 15 - cycle_time))
        
        # Final summary
        await self.display_final_summary()
    
    async def display_final_summary(self):
        """Display final summary"""
        
        logger.info("\n🔒 Session complete...")
        
        # Final stats
        account = self.trading_client.get_account()
        final_equity = float(account.equity)
        total_pnl = final_equity - self.initial_capital
        total_return = (total_pnl / self.initial_capital) * 100
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🏁 OPTIONS TRADING SESSION COMPLETE")
        logger.info(f"{'='*100}")
        
        logger.info(f"\n💰 FINANCIAL SUMMARY:")
        logger.info(f"   Initial Equity: ${self.initial_capital:,.2f}")
        logger.info(f"   Final Equity: ${final_equity:,.2f}")
        logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
        logger.info(f"   Total Return: {total_return:+.2f}%")
        
        logger.info(f"\n📊 TRADING STATISTICS:")
        logger.info(f"   Total Trades Attempted: {self.total_trades}")
        logger.info(f"   Active Spreads: {len(self.active_spreads)}")
        logger.info(f"   Filled Orders: {len([s for s in self.active_spreads.values() if s.status == 'FILLED'])}")
        
        # Save results
        results = {}
            'initial_equity': self.initial_capital,
            'final_equity': final_equity,
            'total_pnl': total_pnl,
            'total_return': total_return,
            'total_trades': self.total_trades,
            'active_spreads': []
                {}
                    'type': spread.spread_type,
                    'underlying': spread.underlying,
                    'max_profit': spread.max_profit,
                    'max_loss': spread.max_loss,
                    'status': spread.status,
                    'order_id': spread.order_id
                }
                for spread in self.active_spreads.values()
            ]
        }
        
        with open('alpaca_options_v2_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"\n📁 Results saved to alpaca_options_v2_results.json")
        logger.info(f"\n🎯 ALPACA OPTIONS TRADING V2 COMPLETE!")

async def main():
    """Main function"""
    trader = AlpacaOptionsTraderV2()
    await trader.run_options_trading(duration_minutes=10)

if __name__ == "__main__":
    asyncio.run(main())