
#!/usr/bin/env python3
"""
Live Trading Bot - PRODUCTION
Automated trading system for Alpaca live trading account
CAUTION: This trades with REAL MONEY
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
import signal
import sys
import json
import numpy as np
from datetime import datetime, timedelta
from alpaca.trading.client import TradingClient
from typing import Dict, List, Optional, Any
import sqlite3
import os
from decimal import Decimal

# Add parent directory
sys.path.append('/home/harry/alpaca-mcp')

# Import our systems
from transformer_prediction_system import TransformerPredictionSystem
from market_data_engine import MarketDataEngine
from performance_tracker import PerformanceTracker

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/live_trading.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class LiveTradingBot:
    """
    LIVE TRADING BOT - TRADES WITH REAL MONEY
    Extra safety measures and conservative parameters
    """
    
    def __init__(self):
        # Alpaca Live API
        self.trading_client = TradingClient(os.getenv('ALPACA_LIVE_API_KEY'), os.getenv('ALPACA_LIVE_API_SECRET'), paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        # Initialize components
        self.transformer_system = TransformerPredictionSystem()
        self.market_data = MarketDataEngine()
        self.performance = PerformanceTracker()
        
        # CONSERVATIVE Trading parameters for LIVE
        self.max_positions = 5  # Fewer positions
        self.position_size_pct = 0.02  # 2% per position (very conservative)
        self.max_daily_loss = 0.01  # 1% daily loss limit
        self.stop_loss_pct = 0.01  # 1% stop loss (tight)
        self.take_profit_pct = 0.03  # 3% take profit
        self.min_confidence = 0.85  # 85% minimum confidence (very high)
        self.max_trade_value = 1000  # $1000 max per trade
        
        # Safety features
        self.daily_trade_limit = 10
        self.require_confirmation = False  # Set True for manual confirmation
        self.allowed_symbols = self.load_allowed_symbols()
        
        # State
        self.running = False
        self.positions = {}
        self.pending_orders = {}
        self.daily_trades = 0
        self.daily_loss = 0
        self.start_of_day_balance = None
        
        # Database
        self.init_database()
        
        # Safety check
        self.safety_check()
        
    def load_allowed_symbols(self):
        """Load list of allowed symbols for trading"""
        # Only trade liquid, large-cap stocks
        return {}
            'SPY', 'QQQ', 'AAPL', 'MSFT', 'GOOGL', 'AMZN', 
            'META', 'NVDA', 'JPM', 'BAC', 'XOM', 'JNJ',
            'WMT', 'PG', 'HD', 'DIS', 'V', 'MA', 'PYPL'
        }
        
    def safety_check(self):
        """Perform safety checks before starting"""
        logger.warning("=" * 50)
        logger.warning("LIVE TRADING BOT - REAL MONEY")
        logger.warning("=" * 50)
        
        # Check account
        try:
            account = self.trading_client.get_account()
            logger.info(f"Live Account Balance: ${account.buying_power}")
            logger.info(f"Portfolio Value: ${account.portfolio_value}")
            
            if float(account.buying_power) < 1000:
                logger.error("Insufficient buying power. Minimum $1000 required.")
                sys.exit(1)
                
            # Check PDT status
            if account.pattern_day_trader:
                logger.warning("Account is marked as Pattern Day Trader")
                
        except Exception as e:
            logger.error(f"Failed to access live account: {e}", exc_info=True)
            sys.exit(1)
            
    def init_database(self):
        """Initialize live trading database"""
        self.db = sqlite3.connect('/home/harry/alpaca-mcp/live_trading.db')
        cursor = self.db.cursor()
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS live_trades ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                side TEXT,
                quantity INTEGER,
                price REAL,
                order_id TEXT,
                status TEXT,
                strategy TEXT,
                confidence REAL,
                profit_loss REAL,
                commission REAL,
                notes TEXT
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS risk_events ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                event_type TEXT,
                description TEXT,
                action_taken TEXT
            )
        ''')
        
        self.db.commit()
        
    async def start(self):
        """Start the live trading bot"""
        logger.warning("Starting LIVE Trading Bot...")
        logger.warning("Trading with REAL MONEY - Be careful!")
        
        # Confirmation
        if self.require_confirmation:
            confirm = input("Type 'START LIVE TRADING' to confirm: ")
            if confirm != "START LIVE TRADING":
                logger.info("Live trading cancelled")
                return
                
        self.running = True
        
        # Get starting balance
        account = self.trading_client.get_account()
        self.start_of_day_balance = float(account.portfolio_value)
        
        # Cancel any open orders
        self.trading_client.cancel_orders()
        
        # Main trading loop
        try:
            while self.running:
                await self.trading_cycle()
                await asyncio.sleep(300)  # Run every 5 minutes (conservative)
                
        except KeyboardInterrupt:
            logger.info("Shutdown requested...")
        except Exception as e:
            logger.error(f"Live trading bot error: {e}", exc_info=True)
            self.record_risk_event('system_error', str(e), 'shutdown')
        finally:
            await self.shutdown()
            
    async def trading_cycle(self):
        """Execute one trading cycle with safety checks"""
        try:
            # Check if market is open
            clock = self.trading_client.get_clock()
            if not clock.is_open:
                logger.info("Market is closed")
                return
                
            # Risk checks
            if not await self.perform_risk_checks():
                logger.warning("Risk checks failed, skipping cycle")
                return
                
            # Update positions
            await self.update_positions()
            
            # Get predictions (only if under position limit)
            if len(self.positions) < self.max_positions:
                predictions = await self.get_predictions()
                
                # Find opportunities
                opportunities = self.find_trading_opportunities(predictions)
                
                # Execute trades (with extra validation)
                await self.execute_trades(opportunities)
            
            # Manage existing positions
            await self.manage_positions()
            
            # Log performance
            self.log_performance()
            
        except Exception as e:
            logger.error(f"Trading cycle error: {e}", exc_info=True)
            self.record_risk_event('cycle_error', str(e), 'continue')
            
    async def perform_risk_checks(self):
        """Perform comprehensive risk checks"""
        try:
            account = self.trading_client.get_account()
            current_value = float(account.portfolio_value)
            
            # Check daily loss limit
            if self.start_of_day_balance:
                daily_pnl = (current_value - self.start_of_day_balance) / self.start_of_day_balance
                if daily_pnl < -self.max_daily_loss:
                    logger.error(f"Daily loss limit exceeded: {daily_pnl:.2%}")
                    self.record_risk_event('daily_loss_limit', f'Loss: {daily_pnl:.2%}', 'halt_trading')
                    self.running = False
                    return False
                    
            # Check trade limit
            if self.daily_trades >= self.daily_trade_limit:
                logger.warning("Daily trade limit reached")
                return False
                
            # Check account restrictions
            if account.trading_blocked or account.account_blocked:
                logger.error("Account is blocked from trading")
                self.running = False
                return False
                
            return True
            
        except Exception as e:
            logger.error(f"Risk check error: {e}", exc_info=True)
            return False
            
    async def get_predictions(self):
        """Get HIGH CONFIDENCE AI predictions only"""
        try:
            # Run transformer predictions
            results = await self.transformer_system.run_prediction_cycle()
            predictions = results.get('predictions', {})
            
            # Filter by HIGH confidence and allowed symbols
            filtered = {}
                symbol: pred for symbol, pred in predictions.items()
                if pred and 
                pred.confidence >= self.min_confidence and
                symbol in self.allowed_symbols and
                abs(pred.predicted_return) > 0.01  # At least 1% move expected
            }
            
            logger.info(f"Got {len(filtered)} high-confidence predictions for live trading")
            return filtered
            
        except Exception as e:
            logger.error(f"Prediction error: {e}", exc_info=True)
            return {}
            
    def find_trading_opportunities(self, predictions):
        """Find CONSERVATIVE trading opportunities"""
        opportunities = []
        
        # Get current positions
        positions = self.trading_client.get_all_positions()
        position_symbols = {p.symbol for p in positions}
        
        # Check account balance
        account = self.trading_client.get_account()
        buying_power = float(account.buying_power)
        
        # Calculate position size (very conservative)
        portfolio_value = float(account.portfolio_value)
        max_position_value = min()
            portfolio_value * self.position_size_pct,
            self.max_trade_value,
            buying_power * 0.5  # Use only half of buying power
        )
        
        # Rank predictions by confidence AND expected return
        sorted_preds = sorted()
            predictions.items(),
            key=lambda x: x[1].confidence * abs(x[1].predicted_return),
            reverse=True
        )
        
        for symbol, pred in sorted_preds:
            # Skip if already have position
            if symbol in position_symbols:
                continue
                
            # Skip if too many positions
            if len(position_symbols) >= self.max_positions:
                break
                
            # Only trade strong signals
            if pred.confidence >= self.min_confidence and abs(pred.predicted_return) > 0.015:
                opportunities.append({)
                    'symbol': symbol,
                    'side': 'buy' if pred.predicted_direction == 'up' else 'sell',
                    'confidence': pred.confidence,
                    'expected_return': pred.predicted_return,
                    'risk_score': pred.risk_score,
                    'max_position_value': max_position_value,
                    'strategy': 'high_confidence_transformer'
                })
                
        return opportunities[:1]  # Only take TOP opportunity
        
    async def execute_trades(self, opportunities):
        """Execute trades with extra validation"""
        for opp in opportunities:
            try:
                symbol = opp['symbol']
                side = opp['side']
                
                # Double-check symbol is allowed
                if symbol not in self.allowed_symbols:
                    logger.warning(f"Symbol {symbol} not in allowed list")
                    continue
                    
                # Get current price
                quote = self.data_client.get_stock_latest_quote(symbol)
                price = quote.ask_price if side == 'buy' else quote.bid_price
                
                # Validate price
                if price <= 0 or price > 10000:
                    logger.warning(f"Invalid price for {symbol}: ${price}")
                    continue
                    
                # Calculate conservative quantity
                quantity = int(opp['max_position_value'] / price)
                quantity = min(quantity, 100)  # Max 100 shares
                
                if quantity < 1:
                    continue
                    
                # Final confirmation
                trade_value = quantity * price
                logger.info(f"About to place LIVE order: {side} {quantity} {symbol} @ ${price:.2f} (${trade_value:.2f})")
                
                if self.require_confirmation:
                    confirm = input(f"Confirm LIVE trade? (y/n): ")
                    if confirm.lower() != 'y':
                        continue
                        
                # Place order with limit price
positions = self.get_positions()
                    limit_price=round(price, 2),
                    client_order_id=f"LIVE_{symbol}_{datetime.now().timestamp()}"
                )
                
                logger.warning(f"LIVE ORDER PLACED: {side} {quantity} {symbol} @ ${price:.2f}")
                
                # Record trade
                self.record_trade({)
                    'symbol': symbol,
                    'side': side,
                    'quantity': quantity,
                    'price': price,
                    'order_id': order.id,
                    'status': 'pending',
                    'strategy': opp['strategy'],
                    'confidence': opp['confidence']
                })
                
                # Increment daily trades
                self.daily_trades += 1
                
                # Store pending order with tight stops
                self.pending_orders[order.id] = {}
                    'symbol': symbol,
                    'side': side,
                    'quantity': quantity,
                    'price': price,
                    'stop_loss': price * (1 - self.stop_loss_pct) if side == 'buy' else price * (1 + self.stop_loss_pct),
                    'take_profit': price * (1 + self.take_profit_pct) if side == 'buy' else price * (1 - self.take_profit_pct),
                    'max_hold_time': datetime.now() + timedelta(hours=4)  # Max 4 hour hold
                }
                
            except Exception as e:
                logger.error(f"LIVE trade execution error for {opp['symbol']}: {e}", exc_info=True)
                self.record_risk_event('trade_error', str(e), 'skip_trade')
                
    async def manage_positions(self):
        """Manage positions with tight risk controls"""
        positions = self.trading_client.get_all_positions()
        
        for position in positions:
            try:
                symbol = position.symbol
                qty = int(position.qty)
                side = 'sell' if position.side == 'long' else 'buy'
                avg_price = float(position.avg_entry_price)
                current_price = float(position.current_price)
                unrealized_pl = float(position.unrealized_pl)
                unrealized_plpc = float(position.unrealized_plpc)
                
                # Log position status
                logger.info(f"Position {symbol}: PnL ${unrealized_pl:.2f} ({unrealized_plpc:.2%})")
                
                # Check stop loss (TIGHT)
                if unrealized_plpc <= -self.stop_loss_pct:
                    logger.warning(f"STOP LOSS triggered for {symbol}")
                    self.close_position(symbol, qty, side, 'stop_loss')
                    continue
                    
                # Check take profit
                if unrealized_plpc >= self.take_profit_pct:
                    logger.info(f"TAKE PROFIT triggered for {symbol}")
                    self.close_position(symbol, qty, side, 'take_profit')
                    continue
                    
                # Check time-based exit
                if symbol in self.pending_orders:
                    order_info = self.pending_orders[symbol]
                    if datetime.now() > order_info.get('max_hold_time', datetime.max):
                        logger.info(f"Time limit reached for {symbol}")
                        self.close_position(symbol, qty, side, 'time_limit')
                        continue
                        
                # Check for prediction reversal
                latest_prediction = await self.get_latest_prediction(symbol)
                if latest_prediction and latest_prediction.confidence > 0.8:
                    if (position.side == 'long' and latest_prediction.predicted_direction == 'down') or \
                       (position.side == 'short' and latest_prediction.predicted_direction == 'up'):
                        logger.warning(f"Prediction reversed for {symbol}, closing position")
                        self.close_position(symbol, qty, side, 'prediction_reversal')
                        
            except Exception as e:
                logger.error(f"Position management error for {symbol}: {e}", exc_info=True)
                
    def close_position(self, symbol, qty, side, reason):
        """Close a position immediately"""
        try:
            order = self.trading_client.submit_order(order_data=MarketOrderRequest(symbol=symbol, qty=qty, side=side, time_in_force='day',
                client_order_id=f"LIVE_CLOSE_{symbol}_{datetime.now().timestamp()}"
            )
            
            logger.warning(f"CLOSING LIVE POSITION: {qty} {symbol} ({reason})")
            
            # Record closing trade
            self.record_trade({)
                'symbol': symbol,
                'side': side,
                'quantity': qty,
                'price': None,  # Market order
                'order_id': order.id,
                'status': 'closing',
                'strategy': reason,
                'confidence': None
            })
            
        except Exception as e:
            logger.error(f"Error closing live position {symbol}: {e}", exc_info=True)
            self.record_risk_event('close_position_error', str(e), 'manual_intervention_required')
            
    def record_trade(self, trade_data):
        """Record trade in database"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO live_trades 
            (symbol, side, quantity, price, order_id, status, strategy, confidence)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', ()
            trade_data['symbol'],
            trade_data['side'],
            trade_data['quantity'],
            trade_data['price'],
            trade_data['order_id'],
            trade_data['status'],
            trade_data['strategy'],
            trade_data.get('confidence')
        ))
        self.db.commit()
        
    def record_risk_event(self, event_type, description, action_taken):
        """Record risk management event"""
        cursor = self.db.cursor()
        cursor.execute(''')
            INSERT INTO risk_events 
            (event_type, description, action_taken)
            VALUES (?, ?, ?)
        ''', (event_type, description, action_taken))
        self.db.commit()
        
    async def update_positions(self):
        """Update position tracking"""
        positions = self.trading_client.get_all_positions()
        self.positions = {p.symbol: p for p in positions}
        
    async def get_latest_prediction(self, symbol):
        """Get latest prediction for symbol"""
        try:
            data = await self.transformer_system.fetch_market_data(symbol)
            if not data.empty:
                return self.transformer_system.make_prediction(symbol, data)
        except Exception:
            pass
        return None
        
    def log_performance(self):
        """Log performance metrics"""
        try:
            account = self.trading_client.get_account()
            
            portfolio_value = float(account.portfolio_value)
            cash = float(account.cash)
            
            if self.start_of_day_balance:
                daily_pnl = portfolio_value - self.start_of_day_balance
                daily_pnl_pct = (daily_pnl / self.start_of_day_balance) * 100
                
                logger.info(f"LIVE Portfolio Value: ${portfolio_value:,.2f}")
                logger.info(f"Cash: ${cash:,.2f}")
                logger.info(f"Daily PnL: ${daily_pnl:,.2f} ({daily_pnl_pct:+.2f}%)")
                logger.info(f"Open Positions: {len(self.positions)}")
                logger.info(f"Daily Trades: {self.daily_trades}/{self.daily_trade_limit}")
                
        except Exception as e:
            logger.error(f"Performance logging error: {e}", exc_info=True)
            
    async def shutdown(self):
        """Graceful shutdown with safety measures"""
        logger.warning("Shutting down LIVE Trading Bot...")
        self.running = False
        
        # Log final status
        self.log_performance()
        
        # Close database
        self.db.close()
        
        logger.warning("LIVE Trading Bot stopped")

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info("Received shutdown signal")
    sys.exit(0)

async def main():
    """Main function"""
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Safety warning
    print("\n" + "="*60)
    print("WARNING: LIVE TRADING BOT - TRADES WITH REAL MONEY")
    print("="*60)
    print("\nSafety features enabled:")
    print("- Maximum 5 positions")
    print("- 2% position size limit")
    print("- 1% stop loss")
    print("- 85% minimum confidence")
    print("- $1000 max per trade")
    print("- 10 trades daily limit")
    print("\nPress Ctrl+C to stop at any time")
    print("="*60 + "\n")
    
    # Create and start bot
    bot = LiveTradingBot()
    await bot.start()

if __name__ == "__main__":
    # Create logs directory
    os.makedirs('/home/harry/alpaca-mcp/logs', exist_ok=True)
    
    # Run bot
    asyncio.run(main())