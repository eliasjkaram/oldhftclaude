#!/usr/bin/env python3
"""
Focused 2017-2025 MinIO Data Check
==================================

Quick focused search specifically for 2017-2025 options data
User mentioned data is "slowly transferring" so we need to check for new data
"""

import json
import logging
from datetime import datetime
from minio import Minio
from minio.error import S3Error
import re
from collections import defaultdict

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class Focused2017to2025DataCheck:
    def __init__(self):
        """Initialize MinIO client connection."""
        self.endpoint = "uschristmas.us"
        self.bucket_name = "stockdb"
        self.client = None
        self.target_years = list(range(2017, 2026)  # 2017-2025)
        
    def connect_to_minio(self):
        """Establish connection to MinIO bucket."""
        try:
            self.client = Minio(self.endpoint, secure=True)
            exists = self.client.bucket_exists(self.bucket_name)
            if exists:
                logger.info(f"✅ Connected to MinIO bucket: {self.bucket_name}")
                return True
            else:
                logger.error(f"❌ Bucket {self.bucket_name} does not exist")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to connect to MinIO: {e}")
            return False
    
    def quick_directory_scan(self, directory: str) -> dict:
        """Quick scan of directory for 2017-2025 data."""
        logger.info(f"🔍 Quick scanning: {directory}")
        
        result = {}
            "directory": directory,
            "years_found": set(),
            "files_by_year": defaultdict(list),
            "total_files": 0,
            "total_size_gb": 0,
            "sample_files": []
        }
        
        try:
            objects = self.client.list_objects()
                self.bucket_name, 
                prefix=f"{directory}/", 
                recursive=True
            )
            
            for obj in objects:
                if obj.object_name.endswith('/'):
                    continue
                    
                result["total_files"] += 1
                size_gb = obj.size / (1024**3)
                result["total_size_gb"] += size_gb
                
                # Extract years from filename
                years = re.findall(r'20[0-9]{2}', obj.object_name)
                for year_str in years:
                    year = int(year_str)
                    if year in self.target_years:
                        result["years_found"].add(year)
                        result["files_by_year"][year].append({)
                            "file": obj.object_name,
                            "size_gb": size_gb,
                            "modified": obj.last_modified.isoformat() if obj.last_modified else None
                        })
                
                # Keep sample files
                if len(result["sample_files"]) < 5:
                    result["sample_files"].append({)
                        "file": obj.object_name,
                        "size_gb": size_gb,
                        "modified": obj.last_modified.isoformat() if obj.last_modified else None
                    })
                
                # Early exit if we found all target years
                if len(result["years_found"]) == len(self.target_years):
                    logger.info(f"🎯 Found all target years in {directory}! Stopping scan.")
                    break
                    
        except S3Error as e:
            logger.error(f"Error scanning {directory}: {e}")
            result["error"] = str(e)
        
        # Convert sets to lists for JSON serialization
        result["years_found"] = sorted(list(result["years_found"])
        result["total_size_gb"] = round(result["total_size_gb"], 2)
        
        logger.info(f"✅ {directory}: {result['total_files']} files, {result['total_size_gb']}GB, years: {result['years_found']}")
        return result
    
    def run_focused_check(self):
        """Run focused check on key directories."""
        logger.info("🚀 Starting Focused 2017-2025 Data Check...")
        
        if not self.connect_to_minio():
            return None
        
        # Key directories to check (ordered by likelihood of containing recent data)
        key_directories = []
            "stocks-2010-2025",  # Most likely to have recent data
            "options-complete",   # Previously found 2010-2016
            "aws_backup",        # Backup might have newer data
            "options",           # Original options directory
            "options-2010",      # Specific 2010 data
            "samples",           # Might have recent samples
            "financials"         # Might have options-related data
        ]
        
        results = {}
            "search_timestamp": datetime.now().isoformat(),
            "target_years": self.target_years,
            "directory_results": {},
            "summary": {}
                "all_years_found": set(),
                "directories_with_target_data": [],
                "total_files_found": 0,
                "total_size_gb": 0
            }
        }
        
        for directory in key_directories:
            result = self.quick_directory_scan(directory)
            results["directory_results"][directory] = result
            
            # Update summary
            if result["years_found"]:
                results["summary"]["all_years_found"].update(result["years_found"])
                results["summary"]["directories_with_target_data"].append({)
                    "directory": directory,
                    "years": result["years_found"],
                    "files": result["total_files"],
                    "size_gb": result["total_size_gb"]
                })
                results["summary"]["total_files_found"] += result["total_files"]
                results["summary"]["total_size_gb"] += result["total_size_gb"]
        
        # Final analysis
        all_years_found = sorted(list(results["summary"]["all_years_found"])
        missing_years = [y for y in self.target_years if y not in all_years_found]
        coverage_percentage = (len(all_years_found) / len(self.target_years) * 100)
        
        results["final_analysis"] = {}
            "years_found": all_years_found,
            "missing_years": missing_years,
            "coverage_percentage": round(coverage_percentage, 1),
            "complete_coverage": len(missing_years) == 0,
            "directories_with_data": len(results["summary"]["directories_with_target_data"]),
            "total_size_gb": round(results["summary"]["total_size_gb"], 2)
        }
        
        # Recommendations
        if results["final_analysis"]["complete_coverage"]:
            verdict = "✅ COMPLETE: All 2017-2025 data found!"
        elif coverage_percentage >= 50:
            verdict = f"🟡 PARTIAL: {coverage_percentage:.1f}% coverage ({len(all_years_found)}/{len(self.target_years)} years)"
        else:
            verdict = f"❌ LIMITED: Only {coverage_percentage:.1f}% coverage ({len(all_years_found)}/{len(self.target_years)} years)"
        
        results["verdict"] = verdict
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"focused_2017_2025_check_{timestamp}.json"
        
        with open(report_file, 'w') as f:
            # Convert sets to lists for JSON serialization
            results_copy = json.loads(json.dumps(results, default=lambda x: list(x) if isinstance(x, set) else x))
            json.dump(results_copy, f, indent=2)
        
        logger.info(f"✅ Check complete. Report saved to: {report_file}")
        return results

def main():
    """Main execution function."""
    checker = Focused2017to2025DataCheck()
    results = checker.run_focused_check()
    
    if results:
        print("\n" + "="*80)
        print("FOCUSED 2017-2025 MINIO DATA CHECK RESULTS")
        print("="*80)
        
        analysis = results["final_analysis"]
        print(f"\n🎯 TARGET: 2017-2025 options data (9 years)")
        print(f"📊 COVERAGE: {analysis['coverage_percentage']}% ({len(analysis['years_found'])}/{len(results['target_years'])} years)")
        print(f"✅ YEARS FOUND: {analysis['years_found']}")
        print(f"❌ MISSING YEARS: {analysis['missing_years']}")
        print(f"📁 DIRECTORIES WITH DATA: {analysis['directories_with_data']}")
        print(f"💾 TOTAL SIZE: {analysis['total_size_gb']} GB")
        
        print(f"\n🎯 VERDICT: {results['verdict']}")
        
        if results["summary"]["directories_with_target_data"]:
            print(f"\n📂 DIRECTORIES WITH 2017-2025 DATA:")
            for dir_info in results["summary"]["directories_with_target_data"]:
                print(f"   📁 {dir_info['directory']}: {dir_info['years']} ({dir_info['files']} files, {dir_info['size_gb']}GB)")
        
        print("\n" + "="*80)
        
        # Quick answer to user's question
        if analysis["complete_coverage"]:
            print("🎉 USER QUESTION ANSWER: YES! Historical options data now covers 2016-2025!")
        elif analysis["coverage_percentage"] > 0:
            print(f"⚠️ USER QUESTION ANSWER: PARTIAL coverage - found {len(analysis['years_found'])} of 9 target years")
        else:
            print("❌ USER QUESTION ANSWER: NO - no 2017-2025 data found yet")
        
    else:
        print("❌ Check failed - could not connect to MinIO bucket")

if __name__ == "__main__":
    main()