#!/usr/bin/env python3
"""
Comprehensive Options Directory Explorer for MinIO stockdb bucket
Analyzes the options/ directory structure and provides detailed statistics
"""

import os
import sys
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import logging
from collections import defaultdict, Counter
import re
from pathlib import Path

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


from minio import Minio
from minio.error import S3Error

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class OptionsDirectoryExplorer:
    """
    Comprehensive explorer for options data in MinIO stockdb bucket
    """
    
    def __init__(self):
        """Initialize MinIO client with environment credentials"""
        self.endpoint = os.getenv('MINIO_ENDPOINT', 'https://uschristmas.us')
        self.access_key = os.getenv('MINIO_ACCESS_KEY', os.getenv('MINIO_ACCESS_KEY'))
        self.secret_key = os.getenv('MINIO_SECRET_KEY', os.getenv('MINIO_SECRET_KEY'))
        self.bucket_name = os.getenv('MINIO_BUCKET', 'stockdb')
        
        # Clean endpoint for MinIO client
        self.clean_endpoint = self.endpoint.replace('https://', '').replace('http://', '')
        
        # Initialize client
        self.client = None
        self.connected = False
        self.cache_dir = "/home/harry/alpaca-mcp/minio_cache"
        
        # Create cache directory
        os.makedirs(self.cache_dir, exist_ok=True)
        
        self._connect()
    
    def _connect(self):
        """Establish connection to MinIO server"""
        try:
            self.client = Minio()
                self.clean_endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=True
            )
            
            # Test connection by listing buckets
            list(self.client.list_buckets()
            self.connected = True
            logger.info(f"Successfully connected to MinIO server: {self.endpoint}")
            
        except Exception as e:
            logger.error(f"Failed to connect to MinIO: {e}")
            self.connected = False
            raise ConnectionError(f"Cannot connect to MinIO server: {e}")
    
    def explore_options_structure(self) -> Dict[str, Any]:
        """
        Explore the complete options/ directory structure
        """
        if not self.connected:
            raise ConnectionError("Not connected to MinIO server")
        
        logger.info("Starting comprehensive options directory exploration...")
        
        # Get all objects in the options/ directory
        try:
            objects = list(self.client.list_objects(self.bucket_name, prefix="options/", recursive=True)
            logger.info(f"Found {len(objects)} objects in options/ directory")
        except Exception as e:
            logger.error(f"Error listing options objects: {e}")
            return {}
        
        # Analyze structure
        structure_analysis = {}
            'total_files': len(objects),
            'total_size_bytes': sum(obj.size for obj in objects if obj.size),
            'total_size_gb': sum(obj.size for obj in objects if obj.size) / (1024**3),
            'file_types': defaultdict(int),
            'directory_structure': defaultdict(lambda: defaultdict(int),
            'years_available': set(),
            'date_coverage': {},
            'file_size_distribution': [],
            'sample_files': []
        }
        
        # Process each object
        for obj in objects:
            if not obj.size:
                continue
                
            # File type analysis
            file_ext = obj.object_name.split('.')[-1].lower() if '.' in obj.object_name else 'unknown'
            structure_analysis['file_types'][file_ext] += 1
            
            # Size distribution
            size_mb = obj.size / (1024**2)
            structure_analysis['file_size_distribution'].append({)
                'name': obj.object_name,
                'size_mb': size_mb,
                'size_bytes': obj.size,
                'last_modified': obj.last_modified.isoformat() if obj.last_modified else None
            })
            
            # Directory structure analysis
            path_parts = obj.object_name.split('/')
            if len(path_parts) >= 2:
                # options/year/file or options/year/month/file
                year_part = path_parts[1]
                if year_part.isdigit() and len(year_part) == 4:
                    year = int(year_part)
                    structure_analysis['years_available'].add(year)
                    structure_analysis['directory_structure'][year]['total_files'] += 1
                    structure_analysis['directory_structure'][year]['total_size_mb'] += size_mb
                    
                    # Monthly breakdown if available
                    if len(path_parts) >= 3:
                        month_part = path_parts[2]
                        if month_part.isdigit() and 1 <= int(month_part) <= 12:
                            month = int(month_part)
                            if 'monthly_breakdown' not in structure_analysis['directory_structure'][year]:
                                structure_analysis['directory_structure'][year]['monthly_breakdown'] = defaultdict(int)
                            structure_analysis['directory_structure'][year]['monthly_breakdown'][month] += 1
            
            # Extract date from filename for coverage analysis
            date_match = re.search(r'(\d{4}-\d{2}-\d{2})', obj.object_name)
            if date_match:
                date_str = date_match.group(1)
                try:
                    date_obj = datetime.strptime(date_str, '%Y-%m-%d')
                    year = date_obj.year
                    if year not in structure_analysis['date_coverage']:
                        structure_analysis['date_coverage'][year] = {'min_date': date_str, 'max_date': date_str, 'file_count': 0}
                    else:
                        if date_str < structure_analysis['date_coverage'][year]['min_date']:
                            structure_analysis['date_coverage'][year]['min_date'] = date_str
                        if date_str > structure_analysis['date_coverage'][year]['max_date']:
                            structure_analysis['date_coverage'][year]['max_date'] = date_str
                    structure_analysis['date_coverage'][year]['file_count'] += 1
                except Exception:
                    pass
        
        # Convert sets to sorted lists for JSON serialization
        structure_analysis['years_available'] = sorted(list(structure_analysis['years_available'])
        structure_analysis['file_types'] = dict(structure_analysis['file_types'])
        structure_analysis['directory_structure'] = dict(structure_analysis['directory_structure'])
        
        # Sort files by size for samples
        structure_analysis['file_size_distribution'].sort(key=lambda x: x['size_mb'], reverse=True)
        
        # Get sample files from different categories
        structure_analysis['sample_files'] = self._get_sample_files(objects)
        
        return structure_analysis
    
    def _get_sample_files(self, objects) -> List[Dict[str, Any]]:
        """Get representative sample files from different categories"""
        samples = {}
            'largest_files': [],
            'options_files': [],
            'stocks_files': [],
            'different_years': [],
            'different_formats': []
        }
        
        # Sort objects by size
        sorted_objects = sorted([obj for obj in objects if obj.size], key=lambda x: x.size, reverse=True)
        
        # Largest files
        samples['largest_files'] = [{]
            'name': obj.object_name,
            'size_mb': obj.size / (1024**2),
            'last_modified': obj.last_modified.isoformat() if obj.last_modified else None
        } for obj in sorted_objects[:5]]
        
        # Options vs stocks files
        for obj in objects[:50]:  # Check first 50 files
            if 'options' in obj.object_name.lower() and obj.object_name.endswith('.csv'):
                if len(samples['options_files']) < 5:
                    samples['options_files'].append({)
                        'name': obj.object_name,
                        'size_mb': obj.size / (1024**2) if obj.size else 0,
                        'last_modified': obj.last_modified.isoformat() if obj.last_modified else None
                    })
            elif 'stocks' in obj.object_name.lower() and obj.object_name.endswith('.csv'):
                if len(samples['stocks_files']) < 5:
                    samples['stocks_files'].append({)
                        'name': obj.object_name,
                        'size_mb': obj.size / (1024**2) if obj.size else 0,
                        'last_modified': obj.last_modified.isoformat() if obj.last_modified else None
                    })
        
        # Different years
        years_seen = set()
        for obj in objects:
            year_match = re.search(r'options/(\d{4})/', obj.object_name)
            if year_match:
                year = int(year_match.group(1)
                if year not in years_seen and len(samples['different_years']) < 10:
                    years_seen.add(year)
                    samples['different_years'].append({)
                        'name': obj.object_name,
                        'year': year,
                        'size_mb': obj.size / (1024**2) if obj.size else 0,
                        'last_modified': obj.last_modified.isoformat() if obj.last_modified else None
                    })
        
        # Different file formats
        formats_seen = set()
        for obj in objects:
            if obj.object_name and '.' in obj.object_name:
                ext = obj.object_name.split('.')[-1].lower()
                if ext not in formats_seen and len(samples['different_formats']) < 10:
                    formats_seen.add(ext)
                    samples['different_formats'].append({)
                        'name': obj.object_name,
                        'format': ext,
                        'size_mb': obj.size / (1024**2) if obj.size else 0,
                        'last_modified': obj.last_modified.isoformat() if obj.last_modified else None
                    })
        
        return samples
    
    def download_and_analyze_sample_files(self, sample_files: List[Dict[str, Any]], max_samples: int = 5) -> Dict[str, Any]:
        """
        Download and analyze sample files to understand data format
        """
        logger.info(f"Downloading and analyzing up to {max_samples} sample files...")
        
        analysis_results = {}
            'sample_analyses': [],
            'common_columns': [],
            'data_types_summary': {},
            'data_quality_issues': [],
            'date_ranges_in_data': {}
        }
        
        # Get sample files from different categories
        files_to_analyze = []
        
        # Add options files
        if 'options_files' in sample_files and sample_files['options_files']:
            files_to_analyze.extend(sample_files['options_files'][:2])
        
        # Add files from different years
        if 'different_years' in sample_files and sample_files['different_years']:
            files_to_analyze.extend(sample_files['different_years'][:2])
        
        # Add largest files if they're CSV
        if 'largest_files' in sample_files:
            for file in sample_files['largest_files'][:2]:
                if file['name'].endswith('.csv'):
                    files_to_analyze.append(file)
        
        # Limit to max_samples
        files_to_analyze = files_to_analyze[:max_samples]
        
        all_columns = []
        
        for file_info in files_to_analyze:
            try:
                logger.info(f"Analyzing file: {file_info['name']}")
                
                # Download file
                local_path = os.path.join(self.cache_dir, os.path.basename(file_info['name'])
                self.client.fget_object(self.bucket_name, file_info['name'], local_path)
                
                # Analyze file
                file_analysis = self._analyze_csv_file(local_path, file_info['name'])
                analysis_results['sample_analyses'].append(file_analysis)
                
                if file_analysis['columns']:
                    all_columns.extend(file_analysis['columns'])
                
                # Clean up
                if os.path.exists(local_path):
                    os.remove(local_path)
                
            except Exception as e:
                logger.error(f"Error analyzing file {file_info['name']}: {e}")
                analysis_results['data_quality_issues'].append({)
                    'file': file_info['name'],
                    'error': str(e),
                    'type': 'analysis_error'
                })
        
        # Find common columns
        if all_columns:
            column_counts = Counter(all_columns)
            analysis_results['common_columns'] = [col for col, count in column_counts.most_common(20)]
        
        return analysis_results
    
    def _analyze_csv_file(self, file_path: str, original_name: str) -> Dict[str, Any]:
        """Analyze a single CSV file"""
        analysis = {}
            'file_name': original_name,
            'file_size_mb': os.path.getsize(file_path) / (1024**2),
            'row_count': 0,
            'column_count': 0,
            'columns': [],
            'data_types': {},
            'sample_data': [],
            'date_columns': [],
            'numeric_columns': [],
            'string_columns': [],
            'date_range': {},
            'missing_data_summary': {},
            'unique_values_sample': {}
        }
        
        try:
            # Try to read the CSV file
            df = pd.read_csv(file_path, nrows=1000)  # Read first 1000 rows for analysis
            
            analysis['row_count'] = len(df)
            analysis['column_count'] = len(df.columns)
            analysis['columns'] = list(df.columns)
            
            # Data types
            analysis['data_types'] = {col: str(dtype) for col, dtype in df.dtypes.items()}
            
            # Sample data (first 5 rows)
            analysis['sample_data'] = df.head().to_dict('records')
            
            # Identify column types
            for col in df.columns:
                if df[col].dtype in ['int64', 'float64']:
                    analysis['numeric_columns'].append(col)
                elif df[col].dtype == 'object':
                    # Check if it could be a date
                    sample_values = df[col].dropna().head(10).astype(str)
                    if any(re.match(r'\d{4}-\d{2}-\d{2}', str(val) for val in sample_values):
                        analysis['date_columns'].append(col)
                    else:
                        analysis['string_columns'].append(col)
            
            # Date range analysis
            for col in analysis['date_columns']:
                try:
                    date_series = pd.to_datetime(df[col], errors='coerce')
                    valid_dates = date_series.dropna()
                    if len(valid_dates) > 0:
                        analysis['date_range'][col] = {}
                            'min_date': valid_dates.min().strftime('%Y-%m-%d'),
                            'max_date': valid_dates.max().strftime('%Y-%m-%d'),
                            'valid_count': len(valid_dates),
                            'invalid_count': len(df) - len(valid_dates)
                        }
                except Exception:
                    pass
            
            # Missing data summary
            analysis['missing_data_summary'] = {}
                col: int(df[col].isnull().sum() for col in df.columns)
            }
            
            # Sample unique values for key columns
            for col in df.columns[:10]:  # First 10 columns
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) <= 20:  # Only if not too many unique values
                    analysis['unique_values_sample'][col] = list(unique_vals)[:10]
                else:
                    analysis['unique_values_sample'][col] = f"{len(unique_vals)} unique values"
            
        except Exception as e:
            analysis['error'] = str(e)
            logger.error(f"Error analyzing CSV {file_path}: {e}")
        
        return analysis
    
    def generate_comprehensive_report(self) -> Dict[str, Any]:
        """
        Generate comprehensive report on options directory
        """
        logger.info("Generating comprehensive options directory report...")
        
        # Step 1: Explore structure
        structure = self.explore_options_structure()
        
        # Step 2: Analyze sample files
        sample_analysis = self.download_and_analyze_sample_files(structure.get('sample_files', {})
        
        # Step 3: Generate statistics
        statistics = self._generate_statistics(structure)
        
        # Step 4: Create final report
        report = {}
            'generated_at': datetime.now().isoformat(),
            'connection_info': {}
                'endpoint': self.endpoint,
                'bucket': self.bucket_name,
                'connected': self.connected
            },
            'directory_structure': structure,
            'sample_file_analysis': sample_analysis,
            'statistics': statistics,
            'recommendations': self._generate_recommendations(structure, sample_analysis, statistics)
        }
        
        return report
    
    def _generate_statistics(self, structure: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed statistics"""
        stats = {}
            'data_coverage': {}
                'total_years': len(structure.get('years_available', []),
                'year_range': {}
                    'min_year': min(structure.get('years_available', [0]) if structure.get('years_available') else None,
                    'max_year': max(structure.get('years_available', [0]) if structure.get('years_available') else None)
                },
                'years_with_data': structure.get('years_available', []),
                'total_trading_days_estimated': 0
            },
            'file_statistics': {}
                'total_files': structure.get('total_files', 0),
                'total_size_gb': structure.get('total_size_gb', 0),
                'average_file_size_mb': 0,
                'largest_file_mb': 0,
                'smallest_file_mb': 0,
                'file_types': structure.get('file_types', {})
            },
            'yearly_breakdown': {},
            'data_quality': {}
                'consistent_structure': None,
                'data_completeness': None,
                'estimated_records': 0
            }
        }
        
        # Calculate file size statistics
        file_sizes = structure.get('file_size_distribution', [])
        if file_sizes:
            sizes_mb = [f['size_mb'] for f in file_sizes]
            stats['file_statistics']['average_file_size_mb'] = np.mean(sizes_mb)
            stats['file_statistics']['largest_file_mb'] = max(sizes_mb)
            stats['file_statistics']['smallest_file_mb'] = min(sizes_mb)
        
        # Yearly breakdown
        for year, data in structure.get('directory_structure', {}).items():
            if isinstance(year, int):
                stats['yearly_breakdown'][year] = {}
                    'file_count': data.get('total_files', 0),
                    'total_size_mb': data.get('total_size_mb', 0),
                    'has_monthly_breakdown': 'monthly_breakdown' in data,
                    'months_available': list(data.get('monthly_breakdown', {}).keys() if 'monthly_breakdown' in data else []
                }
        
        # Estimate trading days (approximately 252 trading days per year)
        if structure.get('years_available'):
            years_span = max(structure['years_available']) - min(structure['years_available']) + 1
            stats['data_coverage']['total_trading_days_estimated'] = years_span * 252
        
        return stats
    
    def _generate_recommendations(self, structure: Dict, sample_analysis: Dict, statistics: Dict) -> List[str]:
        """Generate recommendations based on analysis"""
        recommendations = []
        
        # Data coverage recommendations
        years = structure.get('years_available', [])
        if years:
            recommendations.append(f"Dataset covers {len(years)} years from {min(years)} to {max(years)}")
            
            # Check for gaps
            if years:
                year_gaps = []
                for i in range(min(years), max(years):
                    if i not in years:
                        year_gaps.append(i)
                if year_gaps:
                    recommendations.append(f"Data gaps found in years: {year_gaps}")
        
        # File format recommendations
        file_types = structure.get('file_types', {})
        if 'csv' in file_types:
            recommendations.append(f"Primary data format is CSV ({file_types['csv']} files)")
        
        # Size recommendations
        total_size = structure.get('total_size_gb', 0)
        if total_size > 10:
            recommendations.append(f"Large dataset ({total_size:.2f} GB) - consider data sampling for initial analysis")
        
        # Sample analysis recommendations
        sample_analyses = sample_analysis.get('sample_analyses', [])
        if sample_analyses:
            avg_columns = np.mean([len(a.get('columns', []) for a in sample_analyses])
            recommendations.append(f"Average file has {avg_columns:.0f} columns")
            
            common_cols = sample_analysis.get('common_columns', [])
            if common_cols:
                recommendations.append(f"Most common columns: {', '.join(common_cols[:5])}")
        
        return recommendations

def main():
    """Main execution function"""
    print("Options Directory Explorer")
    print("=" * 50)
    
    try:
        # Initialize explorer
        explorer = OptionsDirectoryExplorer()
        
        # Generate comprehensive report
        report = explorer.generate_comprehensive_report()
        
        # Save report to file
        report_file = f"/home/harry/alpaca-mcp/options_directory_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"\\nReport saved to: {report_file}")
        
        # Print key findings
        print("\\n" + "="*50)
        print("KEY FINDINGS")
        print("="*50)
        
        structure = report['directory_structure']
        statistics = report['statistics']
        
        print(f"\\nData Coverage:")
        print(f"  - Total files: {structure['total_files']:,}")
        print(f"  - Total size: {structure['total_size_gb']:.2f} GB")
        print(f"  - Years available: {len(structure['years_available'])} years")
        print(f"  - Year range: {min(structure['years_available']) if structure['years_available'] else 'N/A'} - {max(structure['years_available']) if structure['years_available'] else 'N/A'}")
        
        print(f"\\nFile Types:")
        for file_type, count in structure['file_types'].items():
            print(f"  - {file_type}: {count:,} files")
        
        print(f"\\nSample Data Analysis:")
        sample_analyses = report['sample_file_analysis']['sample_analyses']
        if sample_analyses:
            print(f"  - Average columns per file: {np.mean([len(a.get('columns', []) for a in sample_analyses]):.0f}")
            print(f"  - Common columns: {', '.join(report['sample_file_analysis']['common_columns'][:5])}")
        
        print(f"\\nRecommendations:")
        for i, rec in enumerate(report['recommendations'], 1):
            print(f"  {i}. {rec}")
        
        return 0
        
    except Exception as e:
        print(f"Error: {e}")
        logger.error(f"Error in main execution: {e}")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)