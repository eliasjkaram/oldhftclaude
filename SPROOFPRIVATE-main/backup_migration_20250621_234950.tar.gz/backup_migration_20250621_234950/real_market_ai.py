
#!/usr/bin/env python3
# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import time
import warnings

from universal_market_data import get_current_market_data, validate_price

warnings.filterwarnings('ignore')

class SimpleNN(nn.Module):
    def __init__(self, input_size=5, hidden_size=64):
        super(SimpleNN, self).__init__()
        self.net = nn.Sequential()
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_size, 32),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, 1)
        )
    
    def forward(self, x):
        return self.net(x)

class RealMarketTradingAI:
    def __init__(self, symbols=['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'NVDA', 'AMZN']):
        self.symbols = symbols
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.scalers = {}
        self.models = {}
        
        print(f"🚀 Real Market GPU Trading AI")
        print(f"Device: {self.device}")
        if torch.cuda.is_available():
            print(f"GPU: {torch.cuda.get_device_name(0)}")
            print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
    
    def fetch_real_market_data(self, symbol, period="5d", interval="1m"):
        """Fetch real market data from yfinance with multiple fallback strategies"""
        print(f"  📡 Fetching {symbol}...")
        
        # Try different periods and intervals if first attempt fails
        fallback_configs = []
            {"period": "5d", "interval": "1m"},
            {"period": "5d", "interval": "5m"},
            {"period": "5d", "interval": "15m"},
            {"period": "1mo", "interval": "1h"},
            {"period": "3mo", "interval": "1d"}
        ]
        
        for config in fallback_configs:
            try:
                ticker = YFinanceWrapper().get_ticker(symbol)
                
                # Add headers and session to avoid rate limiting
                import requests
                session = requests.Session()
                session.headers.update({)
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                
                # Try downloading with session
                data = ticker.history()
                    period=config["period"],
                    interval=config["interval"],
                    session=session
                )
                
                if len(data) > 50:  # Need minimum data points
                    print(f"    ✅ {symbol}: {len(data)} records ({config['interval']} intervals)")
                    
                    # Calculate technical indicators
                    data['Returns'] = data['Close'].pct_change()
                    data['SMA_5'] = data['Close'].rolling(5).mean()
                    data['SMA_20'] = data['Close'].rolling(20).mean()
                    data['RSI'] = self.calculate_rsi(data['Close'])
                    data['MACD'] = self.calculate_macd(data['Close'])
                    data['Volatility'] = data['Returns'].rolling(10).std()
                    data['Volume_MA'] = data['Volume'].rolling(5).mean()
                    
                    # Price momentum indicators
                    data['Price_Change'] = data['Close'] - data['Open']
                    data['High_Low_Ratio'] = data['High'] / data['Low']
                    data['Volume_Price_Trend'] = data['Volume'] * data['Returns']
                    
                    # Remove NaN values
                    data = data.dropna()
                    
                    if len(data) > 30:
                        return data, config["interval"]
                
            except Exception as e:
                print(f"    ⚠️  Failed with {config['period']}/{config['interval']}: {str(e)[:50]}...")
                continue
        
        print(f"    ❌ Could not fetch data for {symbol}")
        return None, None
    
    def calculate_rsi(self, prices, window=14):
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window).mean())
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs)
        return rsi.fillna(50)  # Fill NaN with neutral value
    
    def calculate_macd(self, prices, fast=12, slow=26):
        """Calculate MACD"""
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        macd = ema_fast - ema_slow
        return macd.fillna(0)
    
    def prepare_training_data(self, data, target_col='Returns'):
        """Prepare features for training"""
        # Select most predictive features
        feature_cols = ['Returns', 'RSI', 'MACD', 'Volatility', 'Volume_Price_Trend']
        
        # Use only available features
        available_features = []
        feature_data = []
        
        for col in feature_cols:
            if col in data.columns:
                series = data[col].fillna(0)  # Fill NaN with 0
                if not series.isna().all() and series.std() > 1e-8:  # Check for valid data
                    available_features.append(col)
                    feature_data.append(series.values)
        
        if len(available_features) < 2:
            return None, None, None
        
        # Stack features
        X = np.column_stack(feature_data)
        y = data[target_col].fillna(0).values
        
        # Remove any remaining invalid data
        valid_mask = ~(np.isnan(X).any(axis=1) | np.isnan(y) | np.isinf(X).any(axis=1) | np.isinf(y)
        X, y = X[valid_mask], y[valid_mask]
        
        return X, y, available_features
    
    def train_real_market_model(self, symbol, data, interval, epochs=150):
        """Train model on real market data"""
        print(f"\n🔥 Training model for {symbol} ({interval} data)...")
        
        # Prepare data
        X, y, features = self.prepare_training_data(data)
        
        if X is None or len(X) < 30:
            print(f"    ❌ Insufficient data for {symbol}")
            return None
        
        # Split data (chronological)
        split_idx = int(0.8 * len(X)
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        print(f"    📊 Features: {features}")
        print(f"    📈 Training samples: {len(X_train)}, Test samples: {len(X_test)}")
        
        # Scale features
        scaler_X = MinMaxScaler()
        X_train_scaled = scaler_X.fit_transform(X_train)
        X_test_scaled = scaler_X.transform(X_test)
        
        # Convert to tensors
        X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
        y_train_tensor = torch.FloatTensor(y_train).to(self.device)
        X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
        y_test_tensor = torch.FloatTensor(y_test).to(self.device)
        
        # Create model
        model = SimpleNN(input_size=len(features).to(self.device)
        criterion = nn.MSELoss()
        optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=1e-4)
        
        # Training with GPU acceleration
        model.train()
        best_loss = float('inf')
        
        for epoch in range(epochs):
            optimizer.zero_grad()
            outputs = model(X_train_tensor)
            loss = criterion(outputs.squeeze(), y_train_tensor)
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            
            if epoch % 30 == 0:
                model.eval()
                with torch.no_grad():
                    val_pred = model(X_test_tensor)
                    val_loss = criterion(val_pred.squeeze(), y_test_tensor).item()
                    
                    if val_loss < best_loss:
                        best_loss = val_loss
                    
                    print(f"      Epoch {epoch:3d}: Train Loss = {loss.item():.8f}, Val Loss = {val_loss:.8f}")
                model.train()
        
        # Final evaluation
        model.eval()
        with torch.no_grad():
            test_pred = model(X_test_tensor).cpu().numpy().flatten()
            
            # Calculate metrics
            test_mse = mean_squared_error(y_test, test_pred)
            
            # Direction accuracy (key metric for trading)
            actual_direction = np.sign(y_test)
            pred_direction = np.sign(test_pred)
            direction_accuracy = np.mean(actual_direction == pred_direction) * 100
            
            # Profitable predictions (conservative threshold)
            profitable_mask = np.abs(test_pred) > 0.001  # Only count significant predictions
            if profitable_mask.sum() > 0:
                profitable_accuracy = np.mean()
                    actual_direction[profitable_mask] == pred_direction[profitable_mask]
                ) * 100
            else:
                profitable_accuracy = direction_accuracy
            
            print(f"    ✅ MSE: {test_mse:.8f}")
            print(f"    📊 Direction Accuracy: {direction_accuracy:.1f}%")
            print(f"    💰 Profitable Predictions: {profitable_accuracy:.1f}%")
        
        # Store model
        self.models[symbol] = model
        self.scalers[symbol] = scaler_X
        
        return {}
            'model': model,
            'scaler': scaler_X,
            'features': features,
            'test_mse': test_mse,
            'direction_accuracy': direction_accuracy,
            'profitable_accuracy': profitable_accuracy,
            'interval': interval
        }
    
    def predict_next_move(self, symbol, data):
        """Predict next price movement"""
        if symbol not in self.models:
            return None
        
        model = self.models[symbol]
        scaler = self.scalers[symbol]
        
        # Get latest data point
        latest_data = data.iloc[-1]
        features = ['Returns', 'RSI', 'MACD', 'Volatility', 'Volume_Price_Trend']
        
        try:
            feature_values = []
            for feature in features:
                if feature in data.columns:
                    val = latest_data[feature]
                    if pd.isna(val) or np.isinf(val):
                        val = 0.0
                    feature_values.append(val)
            
            if len(feature_values) < 2:
                return None
            
            # Scale and predict
            feature_array = np.array(feature_values).reshape(1, -1)
            feature_scaled = scaler.transform(feature_array)
            
            model.eval()
            with torch.no_grad():
                input_tensor = torch.FloatTensor(feature_scaled).to(self.device)
                pred_return = model(input_tensor).cpu().numpy()[0, 0]
                
                # Apply realistic constraints
                pred_return = np.clip(pred_return, -0.1, 0.1)  # Max 10% move
                
                current_price = latest_data['Close']
                predicted_price = current_price * (1 + pred_return)
                
                return {}
                    'current_price': current_price,
                    'predicted_return': pred_return * 100,
                    'predicted_price': predicted_price,
                    'signal_strength': min(abs(pred_return) * 100, 10),
                    'action': 'BUY' if pred_return > 0.005 else 'SELL' if pred_return < -0.005 else 'HOLD'
                }
        
        except Exception as e:
            print(f"    ⚠️  Prediction error for {symbol}: {e}")
            return None
    
    def run_real_market_analysis(self):
        """Run complete real market analysis"""
        print("🚀 Real Market GPU Trading AI Analysis")
        print("=" * 60)
        
        # Fetch real market data
        print(f"\n📡 Fetching REAL market data...")
        all_data = {}
        intervals = {}
        
        for symbol in self.symbols:
            data, interval = self.fetch_real_market_data(symbol)
            if data is not None:
                all_data[symbol] = data
                intervals[symbol] = interval
        
        if not all_data:
            print("❌ No data could be fetched. Check internet connection.")
            return None
        
        print(f"\n✅ Successfully fetched data for {len(all_data)} symbols")
        
        # Train models on real data
        print(f"\n🔥 Training on REAL market data...")
        results = {}
        total_start = time.time()
        
        for symbol in all_data:
            result = self.train_real_market_model(symbol, all_data[symbol], intervals[symbol])
            if result:
                results[symbol] = result
        
        total_time = time.time() - total_start
        print(f"\n⚡ Training complete in {total_time:.2f} seconds")
        
        # Generate real-time predictions
        print(f"\n🔮 REAL Market Predictions...")
        print("-" * 60)
        
        predictions = {}
        for symbol in results:
            prediction = self.predict_next_move(symbol, all_data[symbol])
            if prediction:
                predictions[symbol] = prediction
                
                current = prediction['current_price']
                pred_price = prediction['predicted_price']
                pred_return = prediction['predicted_return']
                action = prediction['action']
                strength = prediction['signal_strength']
                
                emoji = "🟢" if action == "BUY" else "🔴" if action == "SELL" else "🟡"
                
                print(f"{symbol:5s}: ${current:8.2f} → ${pred_price:8.2f} ({pred_return:+6.2f}%) {emoji} {action} [{strength:.1f}/10]")
        
        # Performance summary
        if results:
            print(f"\n📊 Model Performance on REAL Data:")
            print("-" * 60)
            
            total_direction_acc = 0
            total_profitable_acc = 0
            
            for symbol, result in results.items():
                dir_acc = result['direction_accuracy']
                prof_acc = result['profitable_accuracy']
                interval = result['interval']
                
                total_direction_acc += dir_acc
                total_profitable_acc += prof_acc
                
                print(f"{symbol:5s}: Direction={dir_acc:5.1f}% | Profitable={prof_acc:5.1f}% | Data={interval}")
            
            avg_dir_acc = total_direction_acc / len(results)
            avg_prof_acc = total_profitable_acc / len(results)
            
            print(f"\n🏆 REAL Market Performance:")
            print(f"    Average Direction Accuracy: {avg_dir_acc:.1f}%")
            print(f"    Average Profitable Accuracy: {avg_prof_acc:.1f}%")
            print(f"    Models Trained: {len(results)}")
            print(f"    GPU Training Time: {total_time:.2f}s")
            
            # Trading signals summary
            buy_signals = [p for p in predictions.values() if p['action'] == 'BUY']
            sell_signals = [p for p in predictions.values() if p['action'] == 'SELL']
            
            print(f"\n📈 Trading Signals:")
            print(f"    BUY signals: {len(buy_signals)}")
            print(f"    SELL signals: {len(sell_signals)}")
            print(f"    HOLD signals: {len(predictions) - len(buy_signals) - len(sell_signals)}")
        
        return results, predictions

if __name__ == "__main__":
    # Run with major tech stocks
    ai = RealMarketTradingAI(symbols=['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'NVDA', 'AMZN', 'META', 'AMD'])
    
    print("Real Market Analysis Starting...")
    print("This will fetch LIVE market data and train GPU models!")
    
    results, predictions = ai.run_real_market_analysis()
    
    if results:
        print(f"\n✅ REAL Market AI Analysis Complete!")
        print(f"🚀 {len(results)} models trained on live market data")
        print(f"📊 Ready for real-time trading decisions")
    else:
        print(f"\n❌ Analysis failed - check internet connection")