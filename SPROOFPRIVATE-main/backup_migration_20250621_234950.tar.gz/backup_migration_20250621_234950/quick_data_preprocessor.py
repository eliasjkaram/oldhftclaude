#!/usr/bin/env python3
"""
Quick Data Preprocessor
Fast preprocessing of sample data to validate the approach
"""

import os
import pandas as pd
import numpy as np
from minio import Minio
from minio.error import S3Error
import logging
from typing import Dict, List, Optional
from datetime import datetime
import sqlite3
import time

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


class QuickDataPreprocessor:
    """
    Quick preprocessing for validation and testing
    """
    
    def __init__(self):
        # MinIO configuration
        self.minio_endpoint = os.getenv('MINIO_ENDPOINT', 'https://uschristmas.us')
        self.minio_access_key = os.getenv('MINIO_ACCESS_KEY', os.getenv('MINIO_ACCESS_KEY'))
        self.minio_secret_key = os.getenv('MINIO_SECRET_KEY', os.getenv('MINIO_SECRET_KEY'))
        self.minio_bucket = os.getenv('MINIO_BUCKET', 'stockdb')
        
        # Initialize MinIO client
        self.minio_client = Minio()
            self.minio_endpoint.replace('https://', '').replace('http://', ''),
            access_key=self.minio_access_key,
            secret_key=self.minio_secret_key,
            secure=True
        )
        
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Quick database
        self.db_path = "quick_test.db"
        self.init_db()
    
    def init_db(self):
        """Initialize test database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Stocks table
        cursor.execute(""")
            CREATE TABLE IF NOT EXISTS stocks ()
                date TEXT,
                symbol TEXT,
                close REAL,
                volume INTEGER,
                PRIMARY KEY (date, symbol)
            )
        """)
        
        # Options table
        cursor.execute(""")
            CREATE TABLE IF NOT EXISTS options ()
                date TEXT,
                underlying TEXT,
                contract TEXT,
                type TEXT,
                strike REAL,
                bid REAL,
                ask REAL,
                volume INTEGER,
                PRIMARY KEY (date, contract)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def download_file(self, file_path: str) -> Optional[pd.DataFrame]:
        """Download single file from MinIO"""
        try:
            response = self.minio_client.get_object(self.minio_bucket, file_path)
            df = pd.read_csv(response)
            response.close()
            response.release_conn()
            return df
        except Exception as e:
            self.logger.debug(f"Error downloading {file_path}: {e}")
            return None
    
    def process_sample_data(self) -> Dict:
        """Process sample data to test the pipeline"""
        
        print("🔍 QUICK DATA PREPROCESSING TEST")
        print("=" * 50)
        
        results = {}
            'stocks_processed': 0,
            'options_processed': 0,
            'same_day_examples': []
        }
        
        # Test specific dates in 2023
        test_dates = ['2023-01-03', '2023-01-04', '2023-01-05']
        
        conn = sqlite3.connect(self.db_path)
        
        for date in test_dates:
            print(f"📅 Processing {date}...")
            
            # Process stock file for this date
            stock_file = f"stocks-2010-2025/{date}.csv"
            stock_df = self.download_file(stock_file)
            
            if stock_df is not None and not stock_df.empty:
                # Clean and prepare stock data
                if 'Close' in stock_df.columns:
                    stock_df = stock_df.rename(columns={'Close': 'close', 'Volume': 'volume', 'Symbol': 'symbol'})
                
                stock_df['date'] = date
                stock_df = stock_df[['date', 'symbol', 'close', 'volume']].dropna()
                
                # Insert to database
                stock_df.to_sql('stocks', conn, if_exists='append', index=False)
                results['stocks_processed'] += len(stock_df)
                print(f"   📈 Stock records: {len(stock_df)}")
            
            # Process options file for this date
            options_file = f"options-complete/{date}options.csv"
            options_df = self.download_file(options_file)
            
            if options_df is not None and not options_df.empty:
                # Clean and prepare options data
                options_df['date'] = date
                
                # Standardize columns
                column_mapping = {}
                    'quote_date': 'date',
                    'underlying': 'underlying',
                    'contract': 'contract',
                    'type': 'type',
                    'strike': 'strike',
                    'bid': 'bid',
                    'ask': 'ask',
                    'volume': 'volume'
                }
                
                for old_col, new_col in column_mapping.items():
                    if old_col in options_df.columns:
                        options_df[new_col] = options_df[old_col]
                
                # Select relevant columns
                cols_to_keep = ['date', 'underlying', 'contract', 'type', 'strike', 'bid', 'ask', 'volume']
                available_cols = [col for col in cols_to_keep if col in options_df.columns]
                options_df = options_df[available_cols].dropna()
                
                # Insert to database
                options_df.to_sql('options', conn, if_exists='append', index=False)
                results['options_processed'] += len(options_df)
                print(f"   📋 Options records: {len(options_df)}")
        
        conn.close()
        
        # Test same-day access
        print(f"\n🔗 TESTING SAME-DAY ACCESS")
        print("-" * 30)
        
        test_symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'AMZN']
        
        for symbol in test_symbols:
            same_day_data = self.get_same_day_data(symbol, '2023-01-03')
            if same_day_data['has_both']:
                results['same_day_examples'].append({)
                    'symbol': symbol,
                    'date': '2023-01-03',
                    'stock_price': same_day_data['stock_price'],
                    'options_contracts': same_day_data['options_count']
                })
                print(f"✅ {symbol}: ${same_day_data['stock_price']:.2f}, {same_day_data['options_count']} options")
            else:
                print(f"⚠️  {symbol}: Missing data")
        
        return results
    
    def get_same_day_data(self, symbol: str, date: str) -> Dict:
        """Get same-day stock and options data"""
        try:
            conn = sqlite3.connect(self.db_path)
            
            # Get stock data
            stock_query = "SELECT * FROM stocks WHERE symbol = ? AND date = ?"
            stock_data = pd.read_sql(stock_query, conn, params=[symbol, date])
            
            # Get options data
            options_query = "SELECT * FROM options WHERE underlying = ? AND date = ?"
            options_data = pd.read_sql(options_query, conn, params=[symbol, date])
            
            conn.close()
            
            has_both = not stock_data.empty and not options_data.empty
            stock_price = stock_data['close'].iloc[0] if not stock_data.empty else None
            options_count = len(options_data) if not options_data.empty else 0
            
            return {}
                'has_both': has_both,
                'stock_price': stock_price,
                'options_count': options_count,
                'stock_data': stock_data,
                'options_data': options_data
            }
            
        except Exception as e:
            self.logger.error(f"Error getting same-day data: {e}")
            return {'has_both': False, 'stock_price': None, 'options_count': 0}
    
    def create_ml_sample(self, symbol: str, date: str) -> pd.DataFrame:
        """Create ML-ready sample for a specific symbol and date"""
        try:
            same_day_data = self.get_same_day_data(symbol, date)
            
            if not same_day_data['has_both']:
                return pd.DataFrame()
            
            stock_data = same_day_data['stock_data']
            options_data = same_day_data['options_data']
            
            # Create unified record
            ml_record = {}
                'date': date,
                'symbol': symbol,
                'stock_price': stock_data['close'].iloc[0],
                'stock_volume': stock_data['volume'].iloc[0],
                'total_options_volume': options_data['volume'].sum(),
                'options_contracts_count': len(options_data),
                'call_volume': options_data[options_data['type'] == 'call']['volume'].sum(),
                'put_volume': options_data[options_data['type'] == 'put']['volume'].sum(),
                'avg_strike': options_data['strike'].mean(),
                'min_strike': options_data['strike'].min(),
                'max_strike': options_data['strike'].max()
            }
            
            # Calculate additional features
            ml_record['put_call_ratio'] = ml_record['put_volume'] / (ml_record['call_volume'] + 1e-6)
            ml_record['options_stock_volume_ratio'] = ml_record['total_options_volume'] / (ml_record['stock_volume'] + 1e-6)
            
            return pd.DataFrame([ml_record])
            
        except Exception as e:
            self.logger.error(f"Error creating ML sample: {e}")
            return pd.DataFrame()

def main():
    """Main execution"""
    
    print("🚀 QUICK DATA PREPROCESSING TEST")
    print("=" * 60)
    print("🎯 Goal: Validate same-day stock/options access")
    print("📅 Testing: 2023-01-03 to 2023-01-05")
    print("=" * 60)
    
    try:
        processor = QuickDataPreprocessor()
        
        # Process sample data
        results = processor.process_sample_data()
        
        print(f"\n🏆 PROCESSING RESULTS")
        print("=" * 50)
        print(f"📈 Stock records processed: {results['stocks_processed']}")
        print(f"📋 Options records processed: {results['options_processed']}")
        print(f"🔗 Same-day examples: {len(results['same_day_examples'])}")
        
        # Create ML samples
        print(f"\n🤖 CREATING ML SAMPLES")
        print("-" * 30)
        
        ml_samples = []
        for example in results['same_day_examples']:
            ml_sample = processor.create_ml_sample(example['symbol'], example['date'])
            if not ml_sample.empty:
                ml_samples.append(ml_sample)
                print(f"✅ {example['symbol']}: ML features created")
        
        if ml_samples:
            # Combine all ML samples
            combined_ml = pd.concat(ml_samples, ignore_index=True)
            
            # Save ML sample
            ml_file = "ml_sample_data.csv"
            combined_ml.to_csv(ml_file, index=False)
            
            print(f"\n📊 ML SAMPLE DATASET")
            print("-" * 30)
            print(f"📁 File: {ml_file}")
            print(f"📊 Shape: {combined_ml.shape}")
            print(f"📋 Columns: {list(combined_ml.columns)}")
            
            # Show sample
            print(f"\n📋 SAMPLE DATA:")
            print(combined_ml.head().to_string()
            
            print(f"\n🎉 SUCCESS: Same-day stock/options access validated!")
            print(f"🔗 Data is ready for ML pipeline integration")
        else:
            print(f"\n⚠️  No ML samples created - check data availability")
        
    except Exception as e:
        print(f"💥 Processing failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()