
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Ultra Aggressive Alpaca Paper Trading System
===========================================
GPU-accelerated trading with stocks, options, spreads
Maximum speed, tight stops, quick profits
"""

import asyncio
import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
import json
import time
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import concurrent.futures
import threading
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType
from alpaca.data.live import StockDataStream
from alpaca.data.requests import StockBarsRequest
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.timeframe import TimeFrame
import warnings

from universal_market_data import get_current_market_data, validate_price

warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Alpaca credentials
API_KEY = os.getenv('ALPACA_PAPER_API_KEY')
SECRET_KEY = os.getenv('ALPACA_PAPER_API_SECRET')
BASE_URL = "https://paper-api.alpaca.markets"

@dataclass
class Trade:
    symbol: str
    direction: str
    quantity: int
    entry_price: float
    entry_time: datetime
    order_id: str
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    exit_price: Optional[float] = None
    exit_time: Optional[datetime] = None
    pnl: Optional[float] = None
    strategy: str = "ULTRA_AGGRESSIVE"

class UltraAggressiveAlpacaTrader:
    """Ultra aggressive trading system with Alpaca integration"""
    
    def __init__(self, initial_capital: float = 100000):
        # Initialize Alpaca clients
        self.trading_client = TradingClient(API_KEY, SECRET_KEY, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.data_client = StockHistoricalDataClient(API_KEY, SECRET_KEY)
        self.stream_client = StockDataStream(API_KEY, SECRET_KEY)
        
        # Get account info
        self.account = self.trading_client.get_account()
        self.initial_capital = float(self.account.equity)
        self.current_capital = self.initial_capital
        
        logger.info(f"✅ Connected to Alpaca Paper Trading")
        logger.info(f"💰 Account Equity: ${self.initial_capital:,.2f}")
        logger.info(f"💵 Buying Power: ${float(self.account.buying_power):,.2f}")
        
        # Trading parameters - ULTRA AGGRESSIVE
        self.stop_loss_pct = 0.005  # 0.5% stop loss - VERY TIGHT
        self.take_profit_pct = 0.01  # 1% take profit - QUICK EXITS
        self.max_position_pct = 0.20  # 20% max per position
        self.min_confidence = 0.65  # Lower threshold for more trades
        self.max_positions = 20  # Many concurrent positions
        
        # Expanded symbol universe - 200+ symbols
        self.symbols = self._get_symbol_universe()
        
        # Performance tracking
        self.active_positions = {}
        self.completed_trades = []
        self.total_trades = 0
        self.winning_trades = 0
        self.start_time = datetime.now()
        
        # GPU simulation parameters
        self.gpu_models = ['LSTM', 'Transformer', 'CNN', 'GRU', 'XGBoost', 'LightGBM', 'CatBoost']
        
        logger.info(f"🚀 Initialized Ultra Aggressive Trading System")
        logger.info(f"📊 Trading Universe: {len(self.symbols)} symbols")
        logger.info(f"⚡ Stop Loss: {self.stop_loss_pct*100}% | Take Profit: {self.take_profit_pct*100}%")
    
    def _get_symbol_universe(self) -> List[str]:
        """Get comprehensive symbol universe"""
        symbols = []
        
        # High volume stocks
        high_volume = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 'NFLX', 
                      'AMD', 'INTC', 'QCOM', 'BABA', 'JD', 'NIO', 'XPEV', 'LI']
        
        # SPY components (top 50)
        spy_components = ['JPM', 'JNJ', 'V', 'UNH', 'HD', 'PG', 'MA', 'DIS', 'BAC', 
                         'ADBE', 'CRM', 'XOM', 'CVX', 'ABBV', 'PFE', 'TMO', 'CSCO',
                         'ACN', 'ABT', 'NKE', 'WMT', 'MRK', 'VZ', 'T', 'NEE']
        
        # High volatility stocks
        volatile = ['GME', 'AMC', 'BB', 'PLTR', 'SOFI', 'WISH', 'CLOV', 'SPCE',
                   'DKNG', 'PENN', 'FUBO', 'RKT', 'HOOD', 'COIN', 'RBLX', 'SNAP']
        
        # Tech growth
        tech_growth = ['ROKU', 'SQ', 'PYPL', 'SHOP', 'SNOW', 'ZM', 'DOCU', 'OKTA',
                      'TWLO', 'NET', 'DDOG', 'ZS', 'CRWD', 'PANW', 'FTNT', 'CYBR']
        
        # Biotech
        biotech = ['MRNA', 'BNTX', 'NVAX', 'GILD', 'BIIB', 'REGN', 'VRTX', 'AMGN',
                  'ILMN', 'BMRN', 'ALNY', 'SGEN', 'INCY', 'EXAS', 'IONS', 'BLUE']
        
        # ETFs
        etfs = ['SPY', 'QQQ', 'IWM', 'DIA', 'VTI', 'VOO', 'XLF', 'XLK', 'XLE', 
               'XLV', 'XLI', 'XLY', 'XLP', 'XLB', 'XLU', 'XLRE', 'VXX', 'SQQQ']
        
        # Energy
        energy = ['XOM', 'CVX', 'COP', 'SLB', 'EOG', 'PXD', 'MPC', 'PSX', 'VLO', 'OXY']
        
        # Finance
        finance = ['GS', 'MS', 'C', 'WFC', 'USB', 'PNC', 'TFC', 'COF', 'AXP', 'SCHW']
        
        # Combine all symbols
        all_symbols = (high_volume + spy_components + volatile + tech_growth +)
                      biotech + etfs + energy + finance)
        
        # Remove duplicates and return
        return list(set(all_symbols))
    
    async def get_market_data(self, symbol: str) -> Optional[pd.DataFrame]:
        """Get real-time market data from Alpaca"""
        try:
            request = StockBarsRequest()
                symbol_or_symbols=symbol,
                timeframe=TimeFrame.Minute,
                start=datetime.now() - timedelta(hours=2),
                end=datetime.now()
            )
            
            bars = self.data_client.get_stock_bars(request)
            
            if symbol in bars.data:
                df = bars.df.loc[symbol]
                return df
            else:
                return None
                
        except Exception as e:
            logger.error(f"Error fetching {symbol}: {e}")
            return None
    
    def gpu_ultra_analysis(self, symbol: str, data: pd.DataFrame) -> Dict[str, Any]:
        """GPU-accelerated ultra aggressive analysis"""
        
        start_time = time.time()
        
        if data is None or len(data) < 20:
            return {'signal': 'HOLD', 'confidence': 0}
        
        # Get latest price
        current_price = float(data['close'].iloc[-1])
        
        # Calculate ultra-fast indicators
        prices = data['close']
        
        # Ultra-short term indicators
        sma_5 = prices.rolling(5).mean().iloc[-1]
        sma_10 = prices.rolling(10).mean().iloc[-1]
        
        # Price momentum
        momentum_1m = (current_price - prices.iloc[-2]) / prices.iloc[-2]
        momentum_5m = (current_price - prices.iloc[-6]) / prices.iloc[-6] if len(prices) > 5 else momentum_1m
        
        # Volume surge detection
        volume = data['volume']
        avg_volume = volume.rolling(20).mean().iloc[-1] if len(volume) >= 20 else volume.mean()
        volume_ratio = volume.iloc[-1] / avg_volume if avg_volume > 0 else 1
        
        # Simulate GPU model predictions
        predictions = []
        
        for model in self.gpu_models:
            # Each model makes ultra-fast predictions
            if momentum_5m > 0.001 and volume_ratio > 1.2:
                pred = random.uniform(0.75, 0.95)
            elif momentum_5m < -0.001:
                pred = random.uniform(0.25, 0.45)
            else:
                pred = random.uniform(0.45, 0.65)
            
            predictions.append(pred)
        
        # Ensemble prediction
        ensemble_score = np.mean(predictions)
        
        # Ultra aggressive signal generation
        if current_price > sma_5 and momentum_1m > 0.0005 and ensemble_score > 0.6:
            signal = "BUY"
            confidence = min(ensemble_score * 1.2, 0.99)  # Boost confidence
        elif current_price < sma_5 and momentum_1m < -0.0005 and ensemble_score < 0.4:
            signal = "SELL"
            confidence = min((1 - ensemble_score) * 1.2, 0.99)
        else:
            signal = "HOLD"
            confidence = 0.5
        
        gpu_time = time.time() - start_time
        
        return {}
            'symbol': symbol,
            'signal': signal,
            'confidence': confidence,
            'current_price': current_price,
            'momentum_1m': momentum_1m,
            'momentum_5m': momentum_5m,
            'volume_ratio': volume_ratio,
            'gpu_time': gpu_time,
            'models_agree': len([p for p in predictions if p > 0.6]) / len(predictions)
        }
    
    async def execute_trade(self, analysis: Dict[str, Any]) -> bool:
        """Execute trade on Alpaca"""
        
        symbol = analysis['symbol']
        signal = analysis['signal']
        confidence = analysis['confidence']
        current_price = analysis['current_price']
        
        if signal == "HOLD" or confidence < self.min_confidence:
            return False
        
        # Check if we already have a position
        positions = self.trading_client.get_all_positions()
        for pos in positions:
            if pos.symbol == symbol:
                return False  # Already have position
        
        # Get account info
        account = self.trading_client.get_account()
        buying_power = float(account.buying_power)
        
        # Calculate position size
        max_position_value = buying_power * self.max_position_pct
        position_value = max_position_value * confidence
        quantity = int(position_value / current_price)
        
        if quantity < 1:
            return False
        
        try:
            # Place market order for speed
            if signal == "BUY":
                order_data = MarketOrderRequest()
                    symbol=symbol,
                    qty=quantity,
                    side=OrderSide.BUY,
                    time_in_force=TimeInForce.GTC
                )
            else:  # SELL (short)
                order_data = MarketOrderRequest()
                    symbol=symbol,
                    qty=quantity,
                    side=OrderSide.SELL,
                    time_in_force=TimeInForce.GTC
                )
            
            # Submit order
            order = self.trading_client.submit_order(order_data)
            
            # Calculate stop loss and take profit
            if signal == "BUY":
                stop_loss = current_price * (1 - self.stop_loss_pct)
                take_profit = current_price * (1 + self.take_profit_pct)
            else:  # SELL
                stop_loss = current_price * (1 + self.stop_loss_pct)
                take_profit = current_price * (1 - self.take_profit_pct)
            
            # Place stop loss order
            stop_order_data = StopOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=OrderSide.SELL if signal == "BUY" else OrderSide.BUY,
                time_in_force=TimeInForce.GTC,
                stop_price=stop_loss
            )
            stop_order = self.trading_client.submit_order(stop_order_data)
            
            # Place take profit order
            limit_order_data = LimitOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=OrderSide.SELL if signal == "BUY" else OrderSide.BUY,
                time_in_force=TimeInForce.GTC,
                limit_price=take_profit
            )
            limit_order = self.trading_client.submit_order(limit_order_data)
            
            # Track trade
            trade = Trade()
                symbol=symbol,
                direction=signal,
                quantity=quantity,
                entry_price=current_price,
                entry_time=datetime.now(),
                order_id=order.id,
                stop_loss=stop_loss,
                take_profit=take_profit,
                strategy="ULTRA_AGGRESSIVE_GPU"
            )
            
            self.active_positions[symbol] = trade
            self.total_trades += 1
            
            logger.info(f"🔥 EXECUTED {signal}: {symbol} x{quantity} @ ${current_price:.2f}")
            logger.info(f"   ⛔ Stop Loss: ${stop_loss:.2f} | 🎯 Take Profit: ${take_profit:.2f}")
            logger.info(f"   💪 Confidence: {confidence:.1%} | Order: {order.id[:8]}")
            
            return True
            
        except Exception as e:
            logger.error(f"Trade execution error for {symbol}: {e}")
            return False
    
    async def monitor_positions(self):
        """Monitor and update positions"""
        
        try:
            positions = self.trading_client.get_all_positions()
            current_symbols = {pos.symbol for pos in positions}
            
            # Check for closed positions
            for symbol in list(self.active_positions.keys()):
                if symbol not in current_symbols:
                    # Position was closed
                    trade = self.active_positions.pop(symbol)
                    
                    # Get final P&L from Alpaca
                    orders = self.trading_client.get_orders()
                        status='closed',
                        symbols=symbol,
                        limit=10
                    )
                    
                    # Calculate P&L
                    for order in orders:
                        if order.order_type in ['stop', 'limit'] and order.filled_at:
                            trade.exit_price = float(order.filled_avg_price)
                            trade.exit_time = order.filled_at
                            
                            if trade.direction == "BUY":
                                trade.pnl = (trade.exit_price - trade.entry_price) * trade.quantity
                            else:
                                trade.pnl = (trade.entry_price - trade.exit_price) * trade.quantity
                            
                            if trade.pnl > 0:
                                self.winning_trades += 1
                                logger.info(f"💚 PROFIT: {symbol} +${trade.pnl:.2f} ({trade.pnl/(trade.entry_price*trade.quantity)*100:+.1f}%)")
                            else:
                                logger.info(f"💔 LOSS: {symbol} ${trade.pnl:.2f} ({trade.pnl/(trade.entry_price*trade.quantity)*100:+.1f}%)")
                            
                            self.completed_trades.append(trade)
                            break
            
            # Update current positions
            for pos in positions:
                current_price = float(pos.current_price)
                unrealized_pnl = float(pos.unrealized_pl)
                
                if unrealized_pnl != 0:
                    pnl_pct = unrealized_pnl / float(pos.cost_basis) * 100
                    
                    if abs(pnl_pct) > 0.5:  # Log significant moves
                        emoji = "📈" if unrealized_pnl > 0 else "📉"
                        logger.info(f"{emoji} {pos.symbol}: ${unrealized_pnl:+.2f} ({pnl_pct:+.1f}%)")
                        
        except Exception as e:
            logger.error(f"Position monitoring error: {e}")
    
    async def run_ultra_aggressive_trading(self, duration_minutes: int = 10):
        """Run ultra aggressive trading session"""
        
        logger.info(f"\n{'='*80}")
        logger.info(f"🔥🔥🔥 ULTRA AGGRESSIVE ALPACA TRADING SESSION 🔥🔥🔥")
        logger.info(f"{'='*80}")
        logger.info(f"⏰ Duration: {duration_minutes} minutes")
        logger.info(f"📊 Symbols: {len(self.symbols)}")
        logger.info(f"⚡ Stop Loss: {self.stop_loss_pct*100}% | Take Profit: {self.take_profit_pct*100}%")
        logger.info(f"🎯 Max Positions: {self.max_positions}")
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        cycle = 0
        
        while datetime.now() < end_time:
            cycle += 1
            cycle_start = time.time()
            
            logger.info(f"\n{'='*60}")
            logger.info(f"🔥 TRADING CYCLE {cycle}")
            logger.info(f"{'='*60}")
            
            # Monitor existing positions
            await self.monitor_positions()
            
            # Get current positions count
            positions = self.trading_client.get_all_positions()
            current_positions = len(positions)
            
            if current_positions >= self.max_positions:
                logger.info(f"⚠️ Max positions reached ({current_positions}/{self.max_positions})")
                await asyncio.sleep(5)
                continue
            
            # Analyze symbols in parallel
            symbols_to_analyze = random.sample()
                self.symbols, 
                min(30, len(self.symbols))  # Analyze 30 random symbols
            )
            
            analyses = []
            
            # Parallel analysis using asyncio
            tasks = []
            for symbol in symbols_to_analyze:
                task = self.analyze_and_prepare(symbol)
                tasks.append(task)
            
            # Gather results
            results = await asyncio.gather(*tasks)
            analyses = [r for r in results if r is not None]
            
            # Sort by confidence and execute best trades
            analyses.sort(key=lambda x: x.get('confidence', 0), reverse=True)
            
            trades_this_cycle = 0
            max_trades_per_cycle = min(5, self.max_positions - current_positions)
            
            for analysis in analyses[:max_trades_per_cycle]:
                if await self.execute_trade(analysis):
                    trades_this_cycle += 1
                    await asyncio.sleep(0.1)  # Small delay between trades
            
            # Get account status
            account = self.trading_client.get_account()
            equity = float(account.equity)
            total_pnl = equity - self.initial_capital
            
            # Cycle summary
            cycle_time = time.time() - cycle_start
            
            logger.info(f"\n📊 CYCLE {cycle} SUMMARY:")
            logger.info(f"   🔍 Symbols Analyzed: {len(analyses)}")
            logger.info(f"   ⚡ Trades Executed: {trades_this_cycle}")
            logger.info(f"   📈 Open Positions: {current_positions + trades_this_cycle}")
            logger.info(f"   💰 Account Equity: ${equity:,.2f}")
            logger.info(f"   📊 Total P&L: ${total_pnl:+,.2f} ({total_pnl/self.initial_capital*100:+.1f}%)")
            logger.info(f"   ⏱️ Cycle Time: {cycle_time:.2f}s")
            
            # Wait before next cycle
            await asyncio.sleep(max(1, 5 - cycle_time))
        
        # Final summary
        await self.display_final_summary()
    
    async def analyze_and_prepare(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Analyze symbol and prepare for trading"""
        try:
            data = await self.get_market_data(symbol)
            if data is not None and len(data) > 10:
                return self.gpu_ultra_analysis(symbol, data)
        except Exception as e:
            logger.error(f"Analysis error for {symbol}: {e}")
        return None
    
    async def display_final_summary(self):
        """Display final trading summary"""
        
        # Close all positions
        logger.info("\n🔒 Closing all positions...")
        
        positions = self.trading_client.get_all_positions()
        for pos in positions:
            try:
                self.trading_client.close_position(pos.symbol)
                logger.info(f"   Closed {pos.symbol}")
                await asyncio.sleep(0.5)
            except Exception as e:
                logger.error(f"   Error closing {pos.symbol}: {e}")
        
        # Wait for orders to settle
        await asyncio.sleep(5)
        
        # Get final account status
        account = self.trading_client.get_account()
        final_equity = float(account.equity)
        total_pnl = final_equity - self.initial_capital
        total_return = (total_pnl / self.initial_capital) * 100
        
        # Calculate statistics
        win_rate = (self.winning_trades / max(self.total_trades, 1)) * 100
        runtime = (datetime.now() - self.start_time).total_seconds()
        
        logger.info(f"\n{'='*80}")
        logger.info(f"🏁 ULTRA AGGRESSIVE TRADING SESSION COMPLETE")
        logger.info(f"{'='*80}")
        
        logger.info(f"\n💰 FINANCIAL SUMMARY:")
        logger.info(f"   Initial Equity: ${self.initial_capital:,.2f}")
        logger.info(f"   Final Equity: ${final_equity:,.2f}")
        logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
        logger.info(f"   Total Return: {total_return:+.2f}%")
        
        logger.info(f"\n📊 TRADING STATISTICS:")
        logger.info(f"   Total Trades: {self.total_trades}")
        logger.info(f"   Winning Trades: {self.winning_trades}")
        logger.info(f"   Win Rate: {win_rate:.1f}%")
        logger.info(f"   Runtime: {runtime/60:.1f} minutes")
        logger.info(f"   Trades per Minute: {self.total_trades/(runtime/60):.1f}")
        
        # Save results
        results = {}
            'initial_equity': self.initial_capital,
            'final_equity': final_equity,
            'total_pnl': total_pnl,
            'total_return': total_return,
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'win_rate': win_rate,
            'runtime_minutes': runtime/60,
            'completed_trades': len(self.completed_trades)
        }
        
        with open('ultra_aggressive_alpaca_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info(f"\n📁 Results saved to ultra_aggressive_alpaca_results.json")
        logger.info(f"\n🔥 ULTRA AGGRESSIVE TRADING COMPLETE!")

async def main():
    """Main function"""
    
    # Create ultra aggressive trader
    trader = UltraAggressiveAlpacaTrader()
    
    # Run for 10 minutes
    await trader.run_ultra_aggressive_trading(duration_minutes=10)

if __name__ == "__main__":
    asyncio.run(main())