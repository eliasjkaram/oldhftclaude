#!/usr/bin/env python3
"""
Unified Error Handling System - Circuit breakers, retry logic, and graceful degradation
Production-ready implementation with comprehensive error management capabilities
"""

import time
import threading
import functools
import random
import traceback
from typing import Callable, Optional, Type, Union, List, Dict, Any, Tuple
from enum import Enum
from datetime import datetime, timedelta
from collections import deque, defaultdict
from dataclasses import dataclass
import logging
import asyncio
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError

from unified_logging import get_logger, LogLevel


class ErrorCategory(Enum):
    """Categories of errors for classification"""
    SYSTEM = "system"
    DATA = "data"
    NETWORK = "network"
    BUSINESS = "business"
    VALIDATION = "validation"
    PERFORMANCE = "performance"
    CALCULATION = "calculation"
    CONFIGURATION = "configuration"
    INFERENCE = "inference"


class ErrorSeverity(Enum):
    """Severity levels for errors"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"

class TradingError(Exception):
    """Custom exception for trading-related errors"""
    def __init__(self, message, error_code=None, details=None):
        super().__init__(message)
        self.error_code = error_code
        self.details = details or {}

    LOW = "low"
    INFO = "info"


class CircuitState(Enum):
    """Circuit breaker states"""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, not allowing calls
    HALF_OPEN = "half_open"  # Testing if service recovered


class RetryStrategy(Enum):
    """Retry strategies"""
    EXPONENTIAL_BACKOFF = "exponential_backoff"
    LINEAR_BACKOFF = "linear_backoff"
    FIXED_DELAY = "fixed_delay"
    EXPONENTIAL_JITTER = "exponential_jitter"


@dataclass
class ErrorMetrics:
    """Metrics for error tracking"""
    total_calls: int = 0
    failed_calls: int = 0
    successful_calls: int = 0
    last_failure_time: Optional[datetime] = None
    last_success_time: Optional[datetime] = None
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    error_types: Dict[str, int] = None
    
    def __post_init__(self):
        if self.error_types is None:
            self.error_types = defaultdict(int)


class CircuitBreaker:
    """
    Circuit breaker implementation to prevent cascading failures
    """
    
    def __init__()
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: Type[Exception] = Exception,
        success_threshold: int = 2,
        exclude_exceptions: Optional[List[Type[Exception]]] = None
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.success_threshold = success_threshold
        self.exclude_exceptions = exclude_exceptions or []
        
        self.state = CircuitState.CLOSED
        self.metrics = ErrorMetrics()
        self._lock = threading.RLock()
        self._state_change_callbacks = []
        
        self.logger = get_logger(f"circuit_breaker.{name}")
        
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection"""
        with self._lock:
            if self.state == CircuitState.OPEN:
                if self._should_attempt_reset():
                    self._transition_to_half_open()
                else:
                    raise CircuitOpenError()
                        f"Circuit breaker '{self.name}' is OPEN"
                    )
                    
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure(e)
            raise
            
    def _should_attempt_reset(self) -> bool:
        """Check if we should try to reset the circuit"""
        return ()
            self.metrics.last_failure_time and
            datetime.now() - self.metrics.last_failure_time > timedelta(seconds=self.recovery_timeout)
        )
        
    def _on_success(self):
        """Handle successful call"""
        with self._lock:
            self.metrics.total_calls += 1
            self.metrics.successful_calls += 1
            self.metrics.consecutive_successes += 1
            self.metrics.consecutive_failures = 0
            self.metrics.last_success_time = datetime.now()
            
            if self.state == CircuitState.HALF_OPEN:
                if self.metrics.consecutive_successes >= self.success_threshold:
                    self._transition_to_closed()
                    
    def _on_failure(self, exception: Exception):
        """Handle failed call"""
        # Check if this exception should be ignored
        if any(isinstance(exception, exc_type) for exc_type in self.exclude_exceptions):
            return
            
        with self._lock:
            self.metrics.total_calls += 1
            self.metrics.failed_calls += 1
            self.metrics.consecutive_failures += 1
            self.metrics.consecutive_successes = 0
            self.metrics.last_failure_time = datetime.now()
            self.metrics.error_types[type(exception).__name__] += 1
            
            self.logger.warning()
                f"Circuit breaker '{self.name}' recorded failure",
                error_type=type(exception).__name__,
                consecutive_failures=self.metrics.consecutive_failures
            )
            
            if self.state in (CircuitState.CLOSED, CircuitState.HALF_OPEN):
                if self.metrics.consecutive_failures >= self.failure_threshold:
                    self._transition_to_open()
                    
    def _transition_to_open(self):
        """Transition to OPEN state"""
        self.state = CircuitState.OPEN
        self.logger.error()
            f"Circuit breaker '{self.name}' transitioned to OPEN",
            consecutive_failures=self.metrics.consecutive_failures,
            failure_threshold=self.failure_threshold
        )
        self._notify_state_change(CircuitState.OPEN)
        
    def _transition_to_half_open(self):
        """Transition to HALF_OPEN state"""
        self.state = CircuitState.HALF_OPEN
        self.metrics.consecutive_failures = 0
        self.metrics.consecutive_successes = 0
        self.logger.info(f"Circuit breaker '{self.name}' transitioned to HALF_OPEN")
        self._notify_state_change(CircuitState.HALF_OPEN)
        
    def _transition_to_closed(self):
        """Transition to CLOSED state"""
        self.state = CircuitState.CLOSED
        self.metrics.consecutive_failures = 0
        self.logger.info(f"Circuit breaker '{self.name}' transitioned to CLOSED")
        self._notify_state_change(CircuitState.CLOSED)
        
    def _notify_state_change(self, new_state: CircuitState):
        """Notify callbacks of state change"""
        for callback in self._state_change_callbacks:
            try:
                callback(self.name, new_state)
            except Exception as e:
                self.logger.error(f"Error in state change callback: {e}")
                
    def register_state_change_callback(self, callback: Callable):
        """Register a callback for state changes"""
        self._state_change_callbacks.append(callback)
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get circuit breaker metrics"""
        with self._lock:
            return {}
                'name': self.name,
                'state': self.state.value,
                'total_calls': self.metrics.total_calls,
                'failed_calls': self.metrics.failed_calls,
                'successful_calls': self.metrics.successful_calls,
                'failure_rate': ()
                    self.metrics.failed_calls / self.metrics.total_calls 
                    if self.metrics.total_calls > 0 else 0
                ),
                'consecutive_failures': self.metrics.consecutive_failures,
                'consecutive_successes': self.metrics.consecutive_successes,
                'error_types': dict(self.metrics.error_types)
            }


class RetryHandler:
    """
    Sophisticated retry handler with multiple strategies
    """
    
    def __init__()
        self,
        max_retries: int = 3,
        strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_BACKOFF,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        jitter: bool = True,
        retry_on: Optional[List[Type[Exception]]] = None,
        dont_retry_on: Optional[List[Type[Exception]]] = None
    ):
        self.max_retries = max_retries
        self.strategy = strategy
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.retry_on = retry_on or [Exception]
        self.dont_retry_on = dont_retry_on or []
        
        self.logger = get_logger("retry_handler")
        
    def _calculate_delay(self, attempt: int) -> float:
        """Calculate delay based on retry strategy"""
        if self.strategy == RetryStrategy.FIXED_DELAY:
            delay = self.base_delay
        elif self.strategy == RetryStrategy.LINEAR_BACKOFF:
            delay = self.base_delay * attempt
        elif self.strategy == RetryStrategy.EXPONENTIAL_BACKOFF:
            delay = self.base_delay * (self.exponential_base ** (attempt - 1))
        elif self.strategy == RetryStrategy.EXPONENTIAL_JITTER:
            delay = self.base_delay * (self.exponential_base ** (attempt - 1))
            delay = random.uniform(0, delay)
        else:
            delay = self.base_delay
            
        # Apply jitter if enabled
        if self.jitter and self.strategy != RetryStrategy.EXPONENTIAL_JITTER:
            delay = delay * (0.5 + random.random())
            
        return min(delay, self.max_delay)
        
    def _should_retry(self, exception: Exception) -> bool:
        """Determine if the exception should trigger a retry"""
        # Don't retry if in the exclusion list
        if any(isinstance(exception, exc_type) for exc_type in self.dont_retry_on):
            return False
            
        # Retry if in the inclusion list
        return any(isinstance(exception, exc_type) for exc_type in self.retry_on)
        
    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with retry logic"""
        last_exception = None
        
        for attempt in range(1, self.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if not self._should_retry(e) or attempt == self.max_retries:
                    self.logger.error()
                        f"Retry handler exhausted or non-retryable error",
                        attempt=attempt,
                        max_retries=self.max_retries,
                        error_type=type(e).__name__,
                        error_message=str(e)
                    )
                    raise
                    
                delay = self._calculate_delay(attempt)
                self.logger.warning()
                    f"Retry attempt {attempt}/{self.max_retries} after {delay:.2f}s",
                    error_type=type(e).__name__,
                    error_message=str(e)
                )
                time.sleep(delay)
                
        raise last_exception
        
    async def execute_async(self, func: Callable, *args, **kwargs) -> Any:
        """Execute async function with retry logic"""
        last_exception = None
        
        for attempt in range(1, self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if not self._should_retry(e) or attempt == self.max_retries:
                    raise
                    
                delay = self._calculate_delay(attempt)
                self.logger.warning()
                    f"Async retry attempt {attempt}/{self.max_retries} after {delay:.2f}s",
                    error_type=type(e).__name__
                )
                await asyncio.sleep(delay)
                
        raise last_exception


class GracefulDegradation:
    """
    Graceful degradation handler for providing fallback functionality
    """
    
    def __init__(self, name: str):
        self.name = name
        self.fallback_chains = {}
        self.logger = get_logger(f"graceful_degradation.{name}")
        self.metrics = defaultdict(int)
        
    def register_fallback()
        self,
        primary_func: Callable,
        fallback_func: Callable,
        condition: Optional[Callable[[Exception], bool]] = None
    ):
        """Register a fallback function for a primary function"""
        key = primary_func.__name__
        if key not in self.fallback_chains:
            self.fallback_chains[key] = []
            
        self.fallback_chains[key].append({)
            'function': fallback_func,
            'condition': condition or (lambda e: True)
        })
        
    def execute(self, primary_func: Callable, *args, **kwargs) -> Any:
        """Execute with graceful degradation"""
        func_name = primary_func.__name__
        
        try:
            result = primary_func(*args, **kwargs)
            self.metrics[f"{func_name}_success"] += 1
            return result
        except Exception as e:
            self.metrics[f"{func_name}_failure"] += 1
            self.logger.warning()
                f"Primary function '{func_name}' failed, attempting fallbacks",
                error_type=type(e).__name__,
                error_message=str(e)
            )
            
            # Try fallbacks
            fallbacks = self.fallback_chains.get(func_name, [])
            for i, fallback in enumerate(fallbacks):
                if fallback['condition'](e):
                    try:
                        self.logger.info(f"Attempting fallback {i+1} for '{func_name}'")
                        result = fallback['function'](*args, **kwargs)
                        self.metrics[f"{func_name}_fallback_{i+1}_success"] += 1
                        return result
                    except Exception as fallback_error:
                        self.metrics[f"{func_name}_fallback_{i+1}_failure"] += 1
                        self.logger.error()
                            f"Fallback {i+1} for '{func_name}' failed",
                            error_type=type(fallback_error).__name__
                        )
                        
            # All fallbacks failed
            self.logger.error(f"All fallbacks exhausted for '{func_name}'")
            raise e
            
    def get_metrics(self) -> Dict[str, int]:
        """Get degradation metrics"""
        return dict(self.metrics)


class TimeoutHandler:
    """
    Timeout handler for preventing long-running operations
    """
    
    def __init__(self, default_timeout: float = 30.0):
        self.default_timeout = default_timeout
        self.executor = ThreadPoolExecutor(max_workers=10)
        self.logger = get_logger("timeout_handler")
        
    def execute(self, func: Callable, timeout: Optional[float] = None, *args, **kwargs) -> Any:
        """Execute function with timeout"""
        timeout = timeout or self.default_timeout
        
        future = self.executor.submit(func, *args, **kwargs)
        
        try:
            return future.result(timeout=timeout)
        except FuturesTimeoutError:
            future.cancel()
            self.logger.error()
                f"Function '{func.__name__}' timed out after {timeout}s"
            )
            raise TimeoutError(f"Operation timed out after {timeout} seconds")
        except Exception as e:
            self.logger.error()
                f"Function '{func.__name__}' raised exception",
                error_type=type(e).__name__
            )
            raise


class CircuitOpenError(Exception):
    """Exception raised when circuit breaker is open"""
    pass


class UnifiedErrorHandler:
    """Unified error handler with circuit breakers, retry logic, and graceful degradation"""
    
    def __init__(self, config=None):
        self.config = config or {}
        self.manager = ErrorHandlingManager()
        self.logger = get_logger("unified_error_handler")
        
    def handle_error(self, error, context=None):
        """Handle an error with appropriate strategy"""
        self.logger.error(f"Handling error: {error}", extra={"context": context})
        # Add error handling logic here
        
    def create_circuit_breaker(self, name, **kwargs):
        """Create a circuit breaker"""
        return self.manager.create_circuit_breaker(name, **kwargs)
        
    def create_retry_handler(self, name, **kwargs):
        """Create a retry handler"""
        return self.manager.create_retry_handler(name, **kwargs)
        
    def get_metrics(self):
        """Get error handling metrics"""
        return self.manager.get_all_metrics()


class ErrorHandlingManager:
    """
    Central manager for all error handling components
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
        
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
            
        self._initialized = True
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}
        self.retry_handlers: Dict[str, RetryHandler] = {}
        self.degradation_handlers: Dict[str, GracefulDegradation] = {}
        self.timeout_handler = TimeoutHandler()
        self.logger = get_logger("error_handling_manager")
        
    def create_circuit_breaker(self, name: str, **kwargs) -> CircuitBreaker:
        """Create and register a circuit breaker"""
        if name not in self.circuit_breakers:
            self.circuit_breakers[name] = CircuitBreaker(name, **kwargs)
            self.logger.info(f"Created circuit breaker: {name}")
        return self.circuit_breakers[name]
        
    def create_retry_handler(self, name: str, **kwargs) -> RetryHandler:
        """Create and register a retry handler"""
        if name not in self.retry_handlers:
            self.retry_handlers[name] = RetryHandler(**kwargs)
            self.logger.info(f"Created retry handler: {name}")
        return self.retry_handlers[name]
        
    def create_degradation_handler(self, name: str) -> GracefulDegradation:
        """Create and register a degradation handler"""
        if name not in self.degradation_handlers:
            self.degradation_handlers[name] = GracefulDegradation(name)
            self.logger.info(f"Created degradation handler: {name}")
        return self.degradation_handlers[name]
        
    def get_all_metrics(self) -> Dict[str, Any]:
        """Get metrics from all error handling components"""
        return {}
            'circuit_breakers': {}
                name: cb.get_metrics() 
                for name, cb in self.circuit_breakers.items()
            },
            'degradation_handlers': {}
                name: handler.get_metrics() 
                for name, handler in self.degradation_handlers.items()
            }
        }


# Decorators for easy use
def circuit_breaker()
    name: str,
    failure_threshold: int = 5,
    recovery_timeout: int = 60,
    expected_exception: Type[Exception] = Exception
):
    """Decorator to apply circuit breaker to a function"""
    def decorator(func):
        manager = ErrorHandlingManager()
        cb = manager.create_circuit_breaker()
            name,
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            expected_exception=expected_exception
        )
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return cb.call(func, *args, **kwargs)
            
        return wrapper
    return decorator


def retry()
    max_retries: int = 3,
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_BACKOFF,
    base_delay: float = 1.0,
    retry_on: Optional[List[Type[Exception]]] = None
):
    """Decorator to apply retry logic to a function"""
    def decorator(func):
        handler = RetryHandler()
            max_retries=max_retries,
            strategy=strategy,
            base_delay=base_delay,
            retry_on=retry_on
        )
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return handler.execute(func, *args, **kwargs)
            
        return wrapper
    return decorator


def timeout(seconds: float):
    """Decorator to apply timeout to a function"""
    def decorator(func):
        handler = TimeoutHandler()
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return handler.execute(func, seconds, *args, **kwargs)
            
        return wrapper
    return decorator


def log_performance(func_name: Optional[str] = None):
    """Decorator to log function performance metrics"""
    def decorator(func):
        name = func_name or func.__name__
        logger = get_logger(f"performance.{name}")
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                elapsed = time.time() - start_time
                logger.info()
                    f"Function '{name}' completed",
                    duration_ms=elapsed * 1000,
                    status="success"
                )
                return result
            except Exception as e:
                elapsed = time.time() - start_time
                logger.error()
                    f"Function '{name}' failed",
                    duration_ms=elapsed * 1000,
                    status="error",
                    error_type=type(e).__name__
                )
                raise
                
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = await func(*args, **kwargs)
                elapsed = time.time() - start_time
                logger.info()
                    f"Async function '{name}' completed",
                    duration_ms=elapsed * 1000,
                    status="success"
                )
                return result
            except Exception as e:
                elapsed = time.time() - start_time
                logger.error()
                    f"Async function '{name}' failed",
                    duration_ms=elapsed * 1000,
                    status="error",
                    error_type=type(e).__name__
                )
                raise
                
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator


def handle_errors()
    func_name: Optional[str] = None,
    category: ErrorCategory = ErrorCategory.SYSTEM,
    severity: ErrorSeverity = ErrorSeverity.MEDIUM,
    max_retries: int = 3,
    backoff_strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_BACKOFF
):
    """
    Comprehensive error handling decorator that combines retry logic with error categorization
    """
    def decorator(func):
        name = func_name or func.__name__
        logger = get_logger(f"error_handler.{name}")
        
        # Create retry handler
        retry_handler = RetryHandler()
            max_retries=max_retries,
            strategy=backoff_strategy,
            base_delay=1.0
        )
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return retry_handler.execute(func, *args, **kwargs)
            except Exception as e:
                logger.error()
                    f"Error in '{name}'",
                    category=category.value,
                    severity=severity.value,
                    error_type=type(e).__name__,
                    error_message=str(e),
                    traceback=traceback.format_exc()
                )
                raise
                
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                return await retry_handler.execute_async(func, *args, **kwargs)
            except Exception as e:
                logger.error()
                    f"Error in async '{name}'",
                    category=category.value,
                    severity=severity.value,
                    error_type=type(e).__name__,
                    error_message=str(e),
                    traceback=traceback.format_exc()
                )
                raise
                
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator


# Example usage
if __name__ == "__main__":
    import requests
    
    # Example with circuit breaker
    @circuit_breaker(name="api_service", failure_threshold=3, recovery_timeout=30)
    @retry(max_retries=3, strategy=RetryStrategy.EXPONENTIAL_BACKOFF)
    @timeout(seconds=10)
    def call_external_api():
        response = requests.get("https://api.example.com/data", timeout=5)
        return response.json()
        
    # Example with graceful degradation
    manager = ErrorHandlingManager()
    degradation = manager.create_degradation_handler("data_service")
    
    def get_live_data():
        # Simulated failure
        raise ConnectionError("Cannot connect to live data source")
        
    def get_cached_data():
        return {"data": "cached", "timestamp": datetime.now().isoformat()}
        
    def get_default_data():
        return {"data": "default", "timestamp": datetime.now().isoformat()}
        
    # Register fallbacks
    degradation.register_fallback()
        get_live_data,
        get_cached_data,
        condition=lambda e: isinstance(e, ConnectionError)
    )
    degradation.register_fallback()
        get_live_data,
        get_default_data
    )
    
    # Test degradation
    try:
        result = degradation.execute(get_live_data)
        print(f"Result: {result}")
    except Exception as e:
        print(f"All fallbacks failed: {e}")
        
    # Print metrics
    print("\nError Handling Metrics:")
    import json
    print(json.dumps(manager.get_all_metrics(), indent=2))