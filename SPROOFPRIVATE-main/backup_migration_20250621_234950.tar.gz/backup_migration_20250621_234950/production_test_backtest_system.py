import sys
import os
#!/usr/bin/env python3
"""
Test script for comprehensive backtesting system
Demonstrates usage with a small subset of data
"""

import asyncio
import logging
from comprehensive_backtest_system import ComprehensiveBacktestSystem, BacktestConfig

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

async def main():
    """Run a demo backtest"""
    logger.info("Starting Comprehensive Backtest System Demo")
    logger.info("=" * 60)
    
    # Create configuration with reduced settings for demo
    config = BacktestConfig()
        symbols=['AAPL', 'MSFT'],  # Just 2 symbols for quick demo
        start_date="2024-01-01",   # Recent data
        end_date="2024-11-01",
        rolling_window_days=30,     # Smaller windows
        step_days=15,
        fine_tune_epochs=5,         # Quick fine-tuning
        batch_size=32,
        initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000"))
    )
    
    logger.info(f"Configuration:")
    logger.info(f"  - Symbols: {config.symbols}")
    logger.info(f"  - Date Range: {config.start_date} to {config.end_date}")
    logger.info(f"  - Rolling Window: {config.rolling_window_days} days")
    logger.info(f"  - Initial Capital: ${config.initial_capital:,.2f}")
    logger.info("=" * 60)
    
    # Create backtest system
    system = ComprehensiveBacktestSystem(config)
    
    try:
        # Run the backtest
        report = await system.run_full_backtest()
        
        # Display results
        if report and 'summary' in report:
            logger.info("\n" + "=" * 60)
            logger.info("BACKTEST RESULTS")
            logger.info("=" * 60)
            
            summary = report['summary']
            logger.info(f"\nBest Overall Model: {summary.get('best_overall_model', 'N/A')}")
            logger.info(f"Best Returns: {summary.get('best_return', 'N/A')}")
            logger.info(f"Best Sharpe Ratio: {summary.get('best_sharpe_ratio', 'N/A')}")
            logger.info(f"Lowest Drawdown: {summary.get('lowest_drawdown', 'N/A')}")
            logger.info(f"Most Consistent: {summary.get('most_consistent', 'N/A')}")
            
            logger.info("\nRecommendations:")
            for rec in summary.get('recommendations', []):
                logger.info(f"  • {rec}")
            
            # Display aggregate metrics
            if 'aggregate_metrics' in report:
                logger.info("\n" + "=" * 60)
                logger.info("MODEL PERFORMANCE METRICS")
                logger.info("=" * 60)
                
                for model_name, metrics in report['aggregate_metrics'].items():
                    logger.info(f"\n{model_name.upper()}:")
                    
                    # Display key metrics
                    key_metrics = ['total_return', 'sharpe_ratio', 'max_drawdown', 'win_rate']
                    for metric in key_metrics:
                        if metric in metrics:
                            mean_val = metrics[metric]['mean']
                            std_val = metrics[metric]['std']
                            logger.info(f"  {metric.replace('_', ' ').title()}: ")
                                  f"{mean_val:.2f} ± {std_val:.2f}")
        
        logger.info("\n" + "=" * 60)
        logger.info("Backtest completed successfully!")
        logger.info(f"Reports saved to: {config.report_save_path}")
        logger.info(f"Models saved to: {config.model_save_path}")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error("\nError during backtest: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Run the demo
    asyncio.run(main())