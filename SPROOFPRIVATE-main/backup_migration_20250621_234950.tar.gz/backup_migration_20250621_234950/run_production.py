#!/usr/bin/env python3
"""
Production System Runner with Environment Loading
"""

import os
import sys
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Map the environment variables to expected names
env_mappings = {}
    'ALPACA_PAPER_KEY': 'ALPACA_PAPER_API_KEY',
    'ALPACA_PAPER_SECRET': 'ALPACA_PAPER_API_SECRET',
    'ALPACA_LIVE_KEY': 'ALPACA_LIVE_API_KEY',
    'ALPACA_LIVE_SECRET': 'ALPACA_LIVE_API_SECRET'
}

# Set the mapped environment variables
for expected, actual in env_mappings.items():
    value = os.getenv(actual)
    if value:
        os.environ[expected] = value

# Now run the production system
import run_production_system