"""
Production-Ready End-to-End Trading Signal Generation Model

A comprehensive system that integrates multiple ML models to generate actionable trading signals
with sophisticated risk management, execution logic, and performance tracking.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import asyncio
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import queue
import json
import pickle
import logging
from abc import ABC, abstractmethod
from enum import Enum
import warnings
from collections import deque, defaultdict
import heapq
import time

# Import ML frameworks
import torch
import torch.nn as nn
import tensorflow as tf
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, RobustScaler
import xgboost as xgb
import lightgbm as lgb

# Technical indicators and statistics
import talib
from scipy import stats, optimize
from scipy.signal import find_peaks
from scipy.stats import norm, t as t_dist
from statsmodels.tsa.stattools import adfuller, coint
from statsmodels.stats.diagnostic import het_breuschpagan
import arch

# For visualization
import matplotlib.pyplot as plt
import seaborn as sns
from plotly import graph_objects as go
import plotly.express as px

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Suppress warnings in production
warnings.filterwarnings('ignore')


class SignalType(Enum):
    """Enumeration of trading signal types"""
    DIRECTIONAL_LONG = "directional_long"
    DIRECTIONAL_SHORT = "directional_short"
    DIRECTIONAL_NEUTRAL = "directional_neutral"
    OPTIONS_STRATEGY = "options_strategy"
    VOLATILITY_TRADE = "volatility_trade"
    ARBITRAGE = "arbitrage"
    RISK_REDUCTION = "risk_reduction"
    PAIRS_TRADE = "pairs_trade"
    MEAN_REVERSION = "mean_reversion"
    MOMENTUM = "momentum"
    BREAKOUT = "breakout"


class MarketRegime(Enum):
    """Market regime classifications"""
    TRENDING_UP = "trending_up"
    TRENDING_DOWN = "trending_down"
    RANGE_BOUND = "range_bound"
    HIGH_VOLATILITY = "high_volatility"
    LOW_VOLATILITY = "low_volatility"
    CRISIS = "crisis"
    NORMAL = "normal"


class OrderType(Enum):
    """Order type classifications"""
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"
    TRAILING_STOP = "trailing_stop"
    ICEBERG = "iceberg"
    TWAP = "twap"
    VWAP = "vwap"


@dataclass
class TradingSignal:
    """Comprehensive trading signal with all necessary information"""
    signal_id: str
    timestamp: datetime
    asset: str
    signal_type: SignalType
    direction: str  # 'long', 'short', 'neutral'
    strength: float  # 0-100 scale
    confidence: float  # 0-1 probability
    
    # Position sizing
    position_size: float
    position_size_currency: float
    leverage: float = 1.0
    
    # Risk management
    stop_loss: float
    take_profit: float
    max_holding_period: timedelta
    
    # Execution details
    order_type: OrderType
    entry_price: float
    limit_price: Optional[float] = None
    
    # Model contributions
    model_scores: Dict[str, float] = field(default_factory=dict)
    feature_importance: Dict[str, float] = field(default_factory=dict)
    
    # Metadata
    market_regime: MarketRegime = MarketRegime.NORMAL
    volatility_regime: str = "normal"
    correlation_risk: float = 0.0
    
    # Options specific (if applicable)
    options_strategy: Optional[str] = None
    strike_prices: Optional[List[float]] = None
    expiration_dates: Optional[List[datetime]] = None
    
    # Performance tracking
    expected_return: float = 0.0
    expected_risk: float = 0.0
    sharpe_ratio: float = 0.0
    win_probability: float = 0.5
    
    # Signal persistence
    persistence_score: float = 0.0
    decay_rate: float = 0.1
    creation_time: datetime = field(default_factory=datetime.now)
    
    # Explanations
    explanation: str = ""
    supporting_factors: List[str] = field(default_factory=list)
    risk_factors: List[str] = field(default_factory=list)


class ModelEnsemble:
    """Ensemble of ML models for signal generation"""
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_importances = {}
        self.model_weights = {}
            'transformer': 0.3,
            'lstm': 0.25,
            'hybrid': 0.25,
            'xgboost': 0.1,
            'lightgbm': 0.1
        }
        self.initialize_models()
        
    def initialize_models(self):
        """Initialize all ML models"""
        # Transformer model
        self.models['transformer'] = self._create_transformer_model()
        
        # LSTM model
        self.models['lstm'] = self._create_lstm_model()
        
        # Hybrid model
        self.models['hybrid'] = self._create_hybrid_model()
        
        # XGBoost
        self.models['xgboost'] = xgb.XGBRegressor()
            n_estimators=1000,
            max_depth=8,
            learning_rate=0.01,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1,
            gpu_id=0 if torch.cuda.is_available() else -1
        )
        
        # LightGBM
        self.models['lightgbm'] = lgb.LGBMRegressor()
            n_estimators=1000,
            max_depth=8,
            learning_rate=0.01,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1,
            device='gpu' if torch.cuda.is_available() else 'cpu'
        )
        
        # Initialize scalers
        self.scalers['robust'] = RobustScaler()
        self.scalers['standard'] = StandardScaler()
        
    def _create_transformer_model(self) -> nn.Module:
        """Create transformer model for sequence modeling"""
        class TransformerModel(nn.Module):
            def __init__(self, input_dim=100, hidden_dim=256, num_heads=8, num_layers=6):
                super().__init__()
                self.input_projection = nn.Linear(input_dim, hidden_dim)
                self.positional_encoding = nn.Parameter(torch.randn(1, 1000, hidden_dim))
                
                encoder_layer = nn.TransformerEncoderLayer()
                    d_model=hidden_dim,
                    nhead=num_heads,
                    dim_feedforward=hidden_dim * 4,
                    dropout=0.1,
                    activation='gelu',
                    batch_first=True
                )
                self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
                
                self.output_layers = nn.Sequential()
                    nn.Linear(hidden_dim, hidden_dim // 2),
                    nn.ReLU(),
                    nn.Dropout(0.1),
                    nn.Linear(hidden_dim // 2, 3)  # [long_prob, short_prob, neutral_prob]
                )
                
            def forward(self, x):
                # x shape: (batch, seq_len, features)
                x = self.input_projection(x)
                seq_len = x.size(1)
                x = x + self.positional_encoding[:, :seq_len, :]
                
                x = self.transformer(x)
                x = x.mean(dim=1)  # Global average pooling
                return torch.softmax(self.output_layers(x), dim=-1)
                
        return TransformerModel()
        
    def _create_lstm_model(self) -> nn.Module:
        """Create LSTM model for time series prediction"""
        class LSTMModel(nn.Module):
            def __init__(self, input_dim=100, hidden_dim=256, num_layers=3):
                super().__init__()
                self.lstm = nn.LSTM()
                    input_size=input_dim,
                    hidden_size=hidden_dim,
                    num_layers=num_layers,
                    batch_first=True,
                    dropout=0.2,
                    bidirectional=True
                )
                
                self.attention = nn.MultiheadAttention()
                    embed_dim=hidden_dim * 2,
                    num_heads=8,
                    dropout=0.1,
                    batch_first=True
                )
                
                self.output_layers = nn.Sequential()
                    nn.Linear(hidden_dim * 2, hidden_dim),
                    nn.ReLU(),
                    nn.Dropout(0.2),
                    nn.Linear(hidden_dim, 3)
                )
                
            def forward(self, x):
                lstm_out, _ = self.lstm(x)
                attn_out, _ = self.attention(lstm_out, lstm_out, lstm_out)
                pooled = attn_out.mean(dim=1)
                return torch.softmax(self.output_layers(pooled), dim=-1)
                
        return LSTMModel()
        
    def _create_hybrid_model(self) -> nn.Module:
        """Create hybrid CNN-RNN model"""
        class HybridModel(nn.Module):
            def __init__(self, input_dim=100, conv_channels=64, lstm_hidden=128):
                super().__init__()
                # CNN for local pattern extraction
                self.conv_layers = nn.Sequential()
                    nn.Conv1d(input_dim, conv_channels, kernel_size=3, padding=1),
                    nn.BatchNorm1d(conv_channels),
                    nn.ReLU(),
                    nn.Conv1d(conv_channels, conv_channels * 2, kernel_size=3, padding=1),
                    nn.BatchNorm1d(conv_channels * 2),
                    nn.ReLU(),
                    nn.Conv1d(conv_channels * 2, conv_channels * 4, kernel_size=3, padding=1),
                    nn.BatchNorm1d(conv_channels * 4),
                    nn.ReLU()
                )
                
                # LSTM for sequential modeling
                self.lstm = nn.LSTM()
                    conv_channels * 4,
                    lstm_hidden,
                    num_layers=2,
                    batch_first=True,
                    dropout=0.2,
                    bidirectional=True
                )
                
                # Output layers
                self.output_layers = nn.Sequential()
                    nn.Linear(lstm_hidden * 2, lstm_hidden),
                    nn.ReLU(),
                    nn.Dropout(0.2),
                    nn.Linear(lstm_hidden, 3)
                )
                
            def forward(self, x):
                # x shape: (batch, seq_len, features)
                x = x.transpose(1, 2)  # (batch, features, seq_len)
                conv_out = self.conv_layers(x)
                conv_out = conv_out.transpose(1, 2)  # (batch, seq_len, conv_channels)
                
                lstm_out, _ = self.lstm(conv_out)
                pooled = lstm_out.mean(dim=1)
                return torch.softmax(self.output_layers(pooled), dim=-1)
                
        return HybridModel()
        
    def predict_ensemble(self, features: np.ndarray, 
                        market_data: pd.DataFrame) -> Dict[str, Any]:
        """Generate ensemble predictions from all models"""
        predictions = {}
        
        # Deep learning models
        with torch.no_grad():
            features_tensor = torch.FloatTensor(features).unsqueeze(0)
            
            if torch.cuda.is_available():
                features_tensor = features_tensor.cuda()
                for name in ['transformer', 'lstm', 'hybrid']:
                    self.models[name] = self.models[name].cuda()
            
            for name in ['transformer', 'lstm', 'hybrid']:
                pred = self.models[name](features_tensor).cpu().numpy()[0]
                predictions[name] = {}
                    'long': pred[0],
                    'short': pred[1],
                    'neutral': pred[2]
                }
        
        # Traditional ML models (if trained)
        try:
            # Prepare features for traditional models
            flat_features = features.flatten()[-1000:]  # Last 1000 features
            
            if hasattr(self.models['xgboost'], 'feature_importances_'):
                xgb_pred = self.models['xgboost'].predict(flat_features.reshape(1, -1))[0]
                predictions['xgboost'] = self._convert_regression_to_probs(xgb_pred)
                
            if hasattr(self.models['lightgbm'], 'feature_importances_'):
                lgb_pred = self.models['lightgbm'].predict(flat_features.reshape(1, -1))[0]
                predictions['lightgbm'] = self._convert_regression_to_probs(lgb_pred)
        except:
            pass
            
        # Weighted ensemble
        ensemble_pred = self._weighted_ensemble(predictions)
        
        return {}
            'ensemble': ensemble_pred,
            'individual': predictions,
            'confidence': self._calculate_confidence(predictions),
            'agreement': self._calculate_agreement(predictions)
        }
        
    def _convert_regression_to_probs(self, value: float) -> Dict[str, float]:
        """Convert regression output to probability distribution"""
        if value > 0.5:
            return {'long': value, 'short': 0.0, 'neutral': 1 - value}
        elif value < -0.5:
            return {'long': 0.0, 'short': abs(value), 'neutral': 1 - abs(value)}
        else:
            return {'long': 0.0, 'short': 0.0, 'neutral': 1.0}
            
    def _weighted_ensemble(self, predictions: Dict[str, Dict[str, float]]) -> Dict[str, float]:
        """Calculate weighted ensemble prediction"""
        ensemble = {'long': 0.0, 'short': 0.0, 'neutral': 0.0}
        total_weight = 0.0
        
        for model_name, pred in predictions.items():
            weight = self.model_weights.get(model_name, 0.1)
            ensemble['long'] += pred['long'] * weight
            ensemble['short'] += pred['short'] * weight
            ensemble['neutral'] += pred['neutral'] * weight
            total_weight += weight
            
        # Normalize
        for key in ensemble:
            ensemble[key] /= total_weight
            
        return ensemble
        
    def _calculate_confidence(self, predictions: Dict[str, Dict[str, float]]) -> float:
        """Calculate prediction confidence based on model agreement"""
        # Get the majority direction
        directions = []
        for pred in predictions.values():
            max_key = max(pred, key=pred.get)
            directions.append(max_key)
            
        # Calculate agreement percentage
        from collections import Counter
        direction_counts = Counter(directions)
        max_count = max(direction_counts.values())
        agreement = max_count / len(directions)
        
        # Calculate average probability for majority direction
        majority_direction = direction_counts.most_common(1)[0][0]
        avg_prob = np.mean([pred[majority_direction] for pred in predictions.values()])
        
        # Confidence is combination of agreement and probability
        confidence = 0.6 * agreement + 0.4 * avg_prob
        return confidence
        
    def _calculate_agreement(self, predictions: Dict[str, Dict[str, float]]) -> float:
        """Calculate model agreement score"""
        # Calculate standard deviation of predictions
        long_probs = [pred['long'] for pred in predictions.values()]
        short_probs = [pred['short'] for pred in predictions.values()]
        
        std_long = np.std(long_probs)
        std_short = np.std(short_probs)
        
        # Lower std means higher agreement
        agreement = 1.0 - (std_long + std_short) / 2.0
        return max(0.0, min(1.0, agreement))


class MarketRegimeDetector:
    """Detect current market regime for adaptive signal generation"""
    
    def __init__(self):
        self.regime_history = deque(maxlen=100)
        self.volatility_model = arch.arch_model(y=None, vol='Garch', p=1, q=1)
        
    def detect_regime(self, market_data: pd.DataFrame) -> MarketRegime:
        """Detect current market regime"""
        returns = market_data['close'].pct_change().dropna()
        
        # Trend detection
        sma_20 = market_data['close'].rolling(20).mean()
        sma_50 = market_data['close'].rolling(50).mean()
        sma_200 = market_data['close'].rolling(200).mean()
        
        current_price = market_data['close'].iloc[-1]
        
        # Volatility analysis
        volatility = returns.rolling(20).std().iloc[-1] * np.sqrt(252)
        historical_vol = returns.std() * np.sqrt(252)
        
        # Regime classification
        if volatility > historical_vol * 2:
            regime = MarketRegime.CRISIS
        elif volatility > historical_vol * 1.5:
            regime = MarketRegime.HIGH_VOLATILITY
        elif volatility < historical_vol * 0.5:
            regime = MarketRegime.LOW_VOLATILITY
        elif current_price > sma_20.iloc[-1] > sma_50.iloc[-1] > sma_200.iloc[-1]:
            regime = MarketRegime.TRENDING_UP
        elif current_price < sma_20.iloc[-1] < sma_50.iloc[-1] < sma_200.iloc[-1]:
            regime = MarketRegime.TRENDING_DOWN
        else:
            # Check for range-bound behavior
            price_range = market_data['close'].rolling(50).max() - market_data['close'].rolling(50).min()
            avg_range = price_range.mean()
            current_range = price_range.iloc[-1]
            
            if current_range < avg_range * 0.7:
                regime = MarketRegime.RANGE_BOUND
            else:
                regime = MarketRegime.NORMAL
                
        self.regime_history.append(regime)
        return regime
        
    def get_volatility_forecast(self, returns: pd.Series, horizon: int = 5) -> np.ndarray:
        """Forecast volatility using GARCH model"""
        try:
            # Fit GARCH model
            self.volatility_model.y = returns * 100  # Scale for numerical stability
            res = self.volatility_model.fit(disp='off')
            
            # Forecast volatility
            forecast = res.forecast(horizon=horizon)
            volatility_forecast = np.sqrt(forecast.variance.values[-1]) / 100
            
            return volatility_forecast
        except:
            # Fallback to simple volatility calculation
            return np.full(horizon, returns.std())


class SignalProcessor:
    """Process and filter trading signals"""
    
    def __init__(self):
        self.signal_history = deque(maxlen=1000)
        self.false_signal_patterns = []
        self.signal_performance = defaultdict(list)
        
    def process_signal(self, raw_signal: Dict[str, Any], 
                      market_context: Dict[str, Any]) -> Optional[TradingSignal]:
        """Process raw model output into trading signal"""
        
        # Extract base information
        ensemble_pred = raw_signal['ensemble']
        confidence = raw_signal['confidence']
        
        # Determine signal direction
        direction = max(ensemble_pred, key=ensemble_pred.get)
        if direction == 'neutral' or confidence < 0.6:
            return None
            
        # Calculate signal strength
        strength = self._calculate_signal_strength()
            ensemble_pred[direction],
            confidence,
            raw_signal['agreement']
        )
        
        if strength < 30:  # Minimum strength threshold
            return None
            
        # Filter false signals
        if self._is_false_signal(raw_signal, market_context):
            return None
            
        # Create trading signal
        signal = self._create_trading_signal()
            direction=direction,
            strength=strength,
            confidence=confidence,
            raw_signal=raw_signal,
            market_context=market_context
        )
        
        # Track signal
        self.signal_history.append(signal)
        
        return signal
        
    def _calculate_signal_strength(self, probability: float, 
                                 confidence: float, 
                                 agreement: float) -> float:
        """Calculate signal strength on 0-100 scale"""
        # Weighted combination of factors
        strength = ()
            probability * 40 +      # Model probability (0-1) -> 0-40
            confidence * 30 +       # Confidence (0-1) -> 0-30
            agreement * 30          # Agreement (0-1) -> 0-30
        )
        
        return min(100, max(0, strength))
        
    def _is_false_signal(self, raw_signal: Dict[str, Any], 
                        market_context: Dict[str, Any]) -> bool:
        """Check if signal matches known false signal patterns"""
        
        # Check for conflicting indicators
        if market_context.get('rsi', 50) > 70 and raw_signal['ensemble']['long'] > 0.7:
            # Overbought but strong long signal - potentially false
            return True
            
        if market_context.get('rsi', 50) < 30 and raw_signal['ensemble']['short'] > 0.7:
            # Oversold but strong short signal - potentially false
            return True
            
        # Check for low volume
        if market_context.get('volume_ratio', 1.0) < 0.5:
            # Low volume - signals less reliable
            return True
            
        # Check signal persistence
        if not self._check_signal_persistence(raw_signal):
            return True
            
        return False
        
    def _check_signal_persistence(self, raw_signal: Dict[str, Any]) -> bool:
        """Check if signal has been persistent across recent predictions"""
        if len(self.signal_history) < 3:
            return True
            
        # Get recent signals in same direction
        current_direction = max(raw_signal['ensemble'], key=raw_signal['ensemble'].get)
        recent_same_direction = sum()
            1 for sig in list(self.signal_history)[-5:]
            if sig.direction == current_direction
        )
        
        return recent_same_direction >= 2
        
    def _create_trading_signal(self, direction: str, strength: float,
                             confidence: float, raw_signal: Dict[str, Any],
                             market_context: Dict[str, Any]) -> TradingSignal:
        """Create comprehensive trading signal"""
        
        current_price = market_context['current_price']
        volatility = market_context.get('volatility', 0.02)
        
        # Determine signal type
        signal_type = self._determine_signal_type(direction, market_context)
        
        # Calculate position size
        position_size, position_size_currency = self._calculate_position_size()
            confidence, strength, volatility, market_context
        )
        
        # Calculate risk levels
        stop_loss, take_profit = self._calculate_risk_levels()
            direction, current_price, volatility, signal_type
        )
        
        # Determine order type
        order_type = self._determine_order_type(market_context, signal_type)
        
        # Generate explanation
        explanation, supporting_factors, risk_factors = self._generate_explanation()
            direction, raw_signal, market_context
        )
        
        return TradingSignal()
            signal_id=f"SIG_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{np.random.randint(1000, 9999)}",
            timestamp=datetime.now(),
            asset=market_context['asset'],
            signal_type=signal_type,
            direction=direction,
            strength=strength,
            confidence=confidence,
            position_size=position_size,
            position_size_currency=position_size_currency,
            stop_loss=stop_loss,
            take_profit=take_profit,
            max_holding_period=self._calculate_holding_period(signal_type),
            order_type=order_type,
            entry_price=current_price,
            limit_price=self._calculate_limit_price(direction, current_price, market_context),
            model_scores=raw_signal['individual'],
            market_regime=market_context['regime'],
            volatility_regime=self._classify_volatility_regime(volatility),
            expected_return=self._calculate_expected_return(direction, strength, volatility),
            expected_risk=volatility * np.sqrt(5),  # 5-day risk
            sharpe_ratio=self._calculate_expected_sharpe(direction, strength, volatility),
            win_probability=self._calculate_win_probability(confidence, strength),
            explanation=explanation,
            supporting_factors=supporting_factors,
            risk_factors=risk_factors
        )
        
    def _determine_signal_type(self, direction: str, 
                             market_context: Dict[str, Any]) -> SignalType:
        """Determine the type of trading signal"""
        regime = market_context['regime']
        
        if regime == MarketRegime.TRENDING_UP and direction == 'long':
            return SignalType.MOMENTUM
        elif regime == MarketRegime.TRENDING_DOWN and direction == 'short':
            return SignalType.MOMENTUM
        elif regime == MarketRegime.RANGE_BOUND:
            return SignalType.MEAN_REVERSION
        elif regime in [MarketRegime.HIGH_VOLATILITY, MarketRegime.CRISIS]:
            return SignalType.VOLATILITY_TRADE
        else:
            return SignalType.DIRECTIONAL_LONG if direction == 'long' else SignalType.DIRECTIONAL_SHORT
            
    def _calculate_position_size(self, confidence: float, strength: float,
                               volatility: float, market_context: Dict[str, Any]) -> Tuple[float, float]:
        """Calculate position size using Kelly Criterion with adjustments"""
        
        # Kelly Criterion: f = (p*b - q) / b
        # where f = fraction of capital to bet
        # p = probability of winning
        # q = probability of losing (1-p)
        # b = odds (win/loss ratio)
        
        win_prob = confidence
        loss_prob = 1 - confidence
        
        # Estimate win/loss ratio based on historical performance
        win_loss_ratio = 1.5  # Default conservative estimate
        
        # Kelly fraction
        kelly_fraction = (win_prob * win_loss_ratio - loss_prob) / win_loss_ratio
        
        # Apply safety factor (never use full Kelly)
        safety_factor = 0.25  # Use 25% of Kelly
        position_fraction = max(0, kelly_fraction * safety_factor)
        
        # Adjust for volatility
        volatility_adjustment = max(0.5, 1 - volatility / 0.5)
        position_fraction *= volatility_adjustment
        
        # Adjust for signal strength
        strength_adjustment = strength / 100
        position_fraction *= strength_adjustment
        
        # Maximum position size constraints
        max_position_fraction = 0.1  # 10% max per position
        position_fraction = min(position_fraction, max_position_fraction)
        
        # Convert to currency amount (assuming $100k portfolio)
        portfolio_value = market_context.get('portfolio_value', 100000)
        position_size_currency = position_fraction * portfolio_value
        
        return position_fraction, position_size_currency
        
    def _calculate_risk_levels(self, direction: str, current_price: float,
                             volatility: float, signal_type: SignalType) -> Tuple[float, float]:
        """Calculate stop loss and take profit levels"""
        
        # Base risk multiples
        if signal_type in [SignalType.MOMENTUM, SignalType.BREAKOUT]:
            stop_multiple = 1.5
            profit_multiple = 3.0
        elif signal_type == SignalType.MEAN_REVERSION:
            stop_multiple = 1.0
            profit_multiple = 1.5
        elif signal_type == SignalType.VOLATILITY_TRADE:
            stop_multiple = 2.0
            profit_multiple = 4.0
        else:
            stop_multiple = 1.2
            profit_multiple = 2.0
            
        # Calculate levels
        risk_amount = current_price * volatility * stop_multiple
        profit_amount = current_price * volatility * profit_multiple
        
        if direction == 'long':
            stop_loss = current_price - risk_amount
            take_profit = current_price + profit_amount
        else:
            stop_loss = current_price + risk_amount
            take_profit = current_price - profit_amount
            
        return stop_loss, take_profit
        
    def _determine_order_type(self, market_context: Dict[str, Any],
                            signal_type: SignalType) -> OrderType:
        """Determine optimal order type"""
        
        spread = market_context.get('spread', 0.0001)
        liquidity = market_context.get('liquidity', 'high')
        urgency = market_context.get('urgency', 'normal')
        
        if urgency == 'high' or signal_type == SignalType.BREAKOUT:
            return OrderType.MARKET
        elif liquidity == 'low':
            return OrderType.ICEBERG
        elif spread > 0.001:  # Wide spread
            return OrderType.LIMIT
        else:
            return OrderType.LIMIT
            
    def _calculate_limit_price(self, direction: str, current_price: float,
                             market_context: Dict[str, Any]) -> float:
        """Calculate limit order price"""
        
        spread = market_context.get('spread', 0.0001)
        
        if direction == 'long':
            # Place limit slightly below current ask
            return current_price + spread * 0.3
        else:
            # Place limit slightly above current bid
            return current_price - spread * 0.3
            
    def _calculate_holding_period(self, signal_type: SignalType) -> timedelta:
        """Calculate maximum holding period based on signal type"""
        
        if signal_type in [SignalType.MOMENTUM, SignalType.BREAKOUT]:
            return timedelta(days=10)
        elif signal_type == SignalType.MEAN_REVERSION:
            return timedelta(days=3)
        elif signal_type == SignalType.VOLATILITY_TRADE:
            return timedelta(days=5)
        else:
            return timedelta(days=7)
            
    def _classify_volatility_regime(self, volatility: float) -> str:
        """Classify volatility regime"""
        
        if volatility < 0.1:
            return "low"
        elif volatility < 0.2:
            return "normal"
        elif volatility < 0.4:
            return "high"
        else:
            return "extreme"
            
    def _calculate_expected_return(self, direction: str, strength: float,
                                 volatility: float) -> float:
        """Calculate expected return"""
        
        # Base expected return proportional to strength
        base_return = (strength / 100) * 0.02  # 2% max base return
        
        # Adjust for volatility (higher vol = higher potential return)
        volatility_adjustment = 1 + volatility
        
        return base_return * volatility_adjustment
        
    def _calculate_expected_sharpe(self, direction: str, strength: float,
                                 volatility: float) -> float:
        """Calculate expected Sharpe ratio"""
        
        expected_return = self._calculate_expected_return(direction, strength, volatility)
        risk_free_rate = 0.02 / 252  # Daily risk-free rate
        
        # Expected Sharpe = (Expected Return - Risk Free Rate) / Volatility
        expected_sharpe = (expected_return - risk_free_rate) / (volatility / np.sqrt(252))
        
        return expected_sharpe
        
    def _calculate_win_probability(self, confidence: float, strength: float) -> float:
        """Calculate probability of profitable trade"""
        
        # Combine confidence and strength
        base_prob = confidence * 0.7 + (strength / 100) * 0.3
        
        # Historical win rate adjustment (would be loaded from performance data)
        historical_adjustment = 0.95  # Slight downward adjustment for conservatism
        
        return base_prob * historical_adjustment
        
    def _generate_explanation(self, direction: str, raw_signal: Dict[str, Any],
                            market_context: Dict[str, Any]) -> Tuple[str, List[str], List[str]]:
        """Generate human-readable explanation for signal"""
        
        # Main explanation
        explanation = f"Strong {direction} signal detected with {raw_signal['confidence']:.1%} confidence. "
        explanation += f"Market regime: {market_context['regime'].value}. "
        
        # Supporting factors
        supporting_factors = []
        
        # Model agreement
        if raw_signal['agreement'] > 0.8:
            supporting_factors.append("High model agreement across ensemble")
            
        # Technical indicators
        if market_context.get('rsi', 50) < 30 and direction == 'long':
            supporting_factors.append("RSI indicates oversold conditions")
        elif market_context.get('rsi', 50) > 70 and direction == 'short':
            supporting_factors.append("RSI indicates overbought conditions")
            
        # Trend alignment
        if market_context.get('trend_alignment', False):
            supporting_factors.append("Signal aligns with prevailing trend")
            
        # Volume confirmation
        if market_context.get('volume_ratio', 1.0) > 1.5:
            supporting_factors.append("Above-average volume confirms signal")
            
        # Risk factors
        risk_factors = []
        
        # Volatility risk
        if market_context.get('volatility', 0.02) > 0.3:
            risk_factors.append("High volatility environment increases risk")
            
        # Correlation risk
        if market_context.get('correlation_risk', 0) > 0.7:
            risk_factors.append("High correlation with existing positions")
            
        # Regime risk
        if market_context['regime'] == MarketRegime.CRISIS:
            risk_factors.append("Crisis regime - increased uncertainty")
            
        return explanation, supporting_factors, risk_factors


class RiskManager:
    """Comprehensive risk management system"""
    
    def __init__(self):
        self.position_limits = {}
            'max_position_size': 0.1,  # 10% max per position
            'max_sector_exposure': 0.3,  # 30% max per sector
            'max_correlation': 0.7,     # Maximum correlation between positions
            'max_leverage': 2.0,        # Maximum portfolio leverage
            'max_var': 0.02,           # 2% maximum VaR
            'max_drawdown': 0.15       # 15% maximum drawdown
        }
        self.current_positions = []
        self.risk_metrics = {}
        
    def validate_signal(self, signal: TradingSignal, 
                       portfolio: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate signal against risk constraints"""
        
        violations = []
        
        # Position size check
        if signal.position_size > self.position_limits['max_position_size']:
            violations.append(f"Position size {signal.position_size:.1%} exceeds limit")
            
        # Correlation check
        correlation_risk = self._calculate_correlation_risk(signal, portfolio)
        if correlation_risk > self.position_limits['max_correlation']:
            violations.append(f"Correlation risk {correlation_risk:.2f} too high")
            
        # VaR check
        new_var = self._calculate_portfolio_var(signal, portfolio)
        if new_var > self.position_limits['max_var']:
            violations.append(f"Portfolio VaR {new_var:.1%} would exceed limit")
            
        # Drawdown check
        potential_drawdown = self._estimate_drawdown_impact(signal, portfolio)
        if potential_drawdown > self.position_limits['max_drawdown']:
            violations.append(f"Potential drawdown {potential_drawdown:.1%} too high")
            
        return len(violations) == 0, violations
        
    def calculate_dynamic_position_size(self, signal: TradingSignal,
                                      portfolio: Dict[str, Any]) -> float:
        """Calculate position size with dynamic risk adjustment"""
        
        base_size = signal.position_size
        
        # Adjust for portfolio heat
        portfolio_heat = self._calculate_portfolio_heat(portfolio)
        heat_adjustment = max(0.5, 1 - portfolio_heat)
        
        # Adjust for correlation
        correlation_adjustment = max(0.5, 1 - self._calculate_correlation_risk(signal, portfolio))
        
        # Adjust for regime
        regime_adjustment = self._get_regime_adjustment(signal.market_regime)
        
        # Final position size
        adjusted_size = base_size * heat_adjustment * correlation_adjustment * regime_adjustment
        
        return min(adjusted_size, self.position_limits['max_position_size'])
        
    def _calculate_correlation_risk(self, signal: TradingSignal,
                                  portfolio: Dict[str, Any]) -> float:
        """Calculate correlation risk with existing positions"""
        
        if not portfolio.get('positions'):
            return 0.0
            
        correlations = []
        for position in portfolio['positions']:
            # Calculate correlation (would use historical data)
            correlation = 0.3  # Placeholder
            correlations.append(abs(correlation))
            
        return max(correlations) if correlations else 0.0
        
    def _calculate_portfolio_var(self, signal: TradingSignal,
                               portfolio: Dict[str, Any]) -> float:
        """Calculate portfolio Value at Risk"""
        
        # Simplified VaR calculation
        positions = portfolio.get('positions', [])
        position_vars = []
        
        for position in positions:
            position_var = position['size'] * position.get('volatility', 0.02) * 2.33  # 99% VaR
            position_vars.append(position_var)
            
        # Add new position
        new_position_var = signal.position_size * signal.expected_risk * 2.33
        position_vars.append(new_position_var)
        
        # Portfolio VaR (assuming some diversification)
        portfolio_var = np.sqrt(sum(v**2 for v in position_vars)) * 0.8
        
        return portfolio_var
        
    def _estimate_drawdown_impact(self, signal: TradingSignal,
                                portfolio: Dict[str, Any]) -> float:
        """Estimate potential drawdown impact"""
        
        # Worst case scenario for new position
        worst_case_loss = signal.position_size * abs(signal.entry_price - signal.stop_loss) / signal.entry_price
        
        # Current drawdown
        current_drawdown = portfolio.get('current_drawdown', 0.0)
        
        # Potential new drawdown
        potential_drawdown = current_drawdown + worst_case_loss
        
        return potential_drawdown
        
    def _calculate_portfolio_heat(self, portfolio: Dict[str, Any]) -> float:
        """Calculate current portfolio heat (risk utilization)"""
        
        positions = portfolio.get('positions', [])
        total_exposure = sum(p['size'] for p in positions)
        
        # Heat based on exposure and number of positions
        exposure_heat = total_exposure / 1.0  # Assuming 100% as max
        position_heat = len(positions) / 20.0  # Assuming 20 as max positions
        
        return (exposure_heat + position_heat) / 2
        
    def _get_regime_adjustment(self, regime: MarketRegime) -> float:
        """Get position size adjustment based on market regime"""
        
        adjustments = {}
            MarketRegime.TRENDING_UP: 1.0,
            MarketRegime.TRENDING_DOWN: 0.8,
            MarketRegime.RANGE_BOUND: 0.9,
            MarketRegime.HIGH_VOLATILITY: 0.6,
            MarketRegime.LOW_VOLATILITY: 1.1,
            MarketRegime.CRISIS: 0.4,
            MarketRegime.NORMAL: 1.0
        }
        
        return adjustments.get(regime, 0.7)
        
    def generate_hedging_recommendations(self, signal: TradingSignal,
                                       portfolio: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate hedging recommendations for the signal"""
        
        recommendations = []
        
        # Options hedge for high-value positions
        if signal.position_size_currency > 50000:
            recommendations.append({)
                'type': 'protective_put',
                'strike': signal.stop_loss,
                'expiration': signal.timestamp + signal.max_holding_period,
                'rationale': 'Protect against significant downside'
            })
            
        # Portfolio hedge for correlation risk
        if self._calculate_correlation_risk(signal, portfolio) > 0.6:
            recommendations.append({)
                'type': 'index_hedge',
                'instrument': 'SPY_puts',
                'size': signal.position_size * 0.3,
                'rationale': 'Hedge systematic risk'
            })
            
        # Volatility hedge
        if signal.volatility_regime in ['high', 'extreme']:
            recommendations.append({)
                'type': 'volatility_hedge',
                'instrument': 'VIX_calls',
                'size': signal.position_size * 0.1,
                'rationale': 'Protect against volatility spike'
            })
            
        return recommendations


class ExecutionEngine:
    """Smart execution engine for optimal order execution"""
    
    def __init__(self):
        self.execution_algorithms = {}
            'twap': self._execute_twap,
            'vwap': self._execute_vwap,
            'iceberg': self._execute_iceberg,
            'smart': self._execute_smart
        }
        self.execution_metrics = defaultdict(list)
        
    def optimize_execution(self, signal: TradingSignal,
                         market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize execution strategy for the signal"""
        
        # Analyze market microstructure
        microstructure = self._analyze_microstructure(market_data)
        
        # Select execution algorithm
        algorithm = self._select_execution_algorithm(signal, microstructure)
        
        # Calculate execution parameters
        execution_params = self._calculate_execution_parameters()
            signal, microstructure, algorithm
        )
        
        # Generate execution plan
        execution_plan = {}
            'algorithm': algorithm,
            'parameters': execution_params,
            'estimated_slippage': self._estimate_slippage(signal, microstructure),
            'estimated_duration': self._estimate_execution_duration(signal, microstructure),
            'child_orders': self._generate_child_orders(signal, execution_params),
            'urgency_score': self._calculate_urgency(signal, market_data),
            'execution_risk': self._assess_execution_risk(signal, microstructure)
        }
        
        return execution_plan
        
    def _analyze_microstructure(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze market microstructure"""
        
        return {}
            'spread': market_data.get('spread', 0.0001),
            'depth': market_data.get('depth', 1000000),
            'volatility': market_data.get('volatility', 0.02),
            'avg_trade_size': market_data.get('avg_trade_size', 1000),
            'liquidity_score': self._calculate_liquidity_score(market_data),
            'price_impact': self._estimate_price_impact(market_data)
        }
        
    def _select_execution_algorithm(self, signal: TradingSignal,
                                  microstructure: Dict[str, Any]) -> str:
        """Select optimal execution algorithm"""
        
        # Large orders with low urgency -> TWAP/VWAP
        if signal.position_size_currency > 100000 and signal.order_type != OrderType.MARKET:
            if microstructure['volatility'] < 0.02:
                return 'vwap'
            else:
                return 'twap'
                
        # Illiquid markets -> Iceberg
        elif microstructure['liquidity_score'] < 0.3:
            return 'iceberg'
            
        # Default to smart routing
        else:
            return 'smart'
            
    def _calculate_execution_parameters(self, signal: TradingSignal,
                                      microstructure: Dict[str, Any],
                                      algorithm: str) -> Dict[str, Any]:
        """Calculate algorithm-specific parameters"""
        
        if algorithm == 'twap':
            return {}
                'duration': 3600,  # 1 hour
                'intervals': 20,
                'randomization': 0.1
            }
        elif algorithm == 'vwap':
            return {}
                'start_time': '09:30',
                'end_time': '16:00',
                'participation_rate': 0.1
            }
        elif algorithm == 'iceberg':
            return {}
                'visible_size': microstructure['avg_trade_size'],
                'refresh_rate': 30,  # seconds
                'price_improvement': 0.0001
            }
        else:  # smart
            return {}
                'urgency': 'normal',
                'venue_selection': 'best_execution',
                'dark_pool_enabled': True
            }
            
    def _estimate_slippage(self, signal: TradingSignal,
                         microstructure: Dict[str, Any]) -> float:
        """Estimate execution slippage"""
        
        # Base slippage from spread
        spread_cost = microstructure['spread'] / 2
        
        # Market impact
        size_ratio = signal.position_size_currency / microstructure['depth']
        market_impact = size_ratio * microstructure['price_impact']
        
        # Volatility component
        volatility_cost = microstructure['volatility'] * np.sqrt()
            self._estimate_execution_duration(signal, microstructure) / 86400
        )
        
        # Total estimated slippage
        total_slippage = spread_cost + market_impact + volatility_cost
        
        return total_slippage
        
    def _estimate_execution_duration(self, signal: TradingSignal,
                                   microstructure: Dict[str, Any]) -> float:
        """Estimate time to complete execution in seconds"""
        
        if signal.order_type == OrderType.MARKET:
            return 1.0
            
        # Based on order size and market liquidity
        size_factor = signal.position_size_currency / microstructure['avg_trade_size']
        liquidity_factor = 1 / microstructure['liquidity_score']
        
        # Base duration
        duration = size_factor * liquidity_factor * 60  # Base unit: minutes
        
        return min(duration * 60, 7200)  # Max 2 hours, convert to seconds
        
    def _generate_child_orders(self, signal: TradingSignal,
                             execution_params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate child orders for execution"""
        
        child_orders = []
        
        if execution_params.get('intervals'):
            # Split order into intervals
            interval_size = signal.position_size / execution_params['intervals']
            
            for i in range(execution_params['intervals']):
                child_orders.append({)
                    'order_id': f"{signal.signal_id}_child_{i}",
                    'size': interval_size,
                    'type': signal.order_type,
                    'time_offset': i * (execution_params.get('duration', 3600) / execution_params['intervals'])
                })
                
        else:
            # Single order
            child_orders.append({)
                'order_id': f"{signal.signal_id}_child_0",
                'size': signal.position_size,
                'type': signal.order_type,
                'time_offset': 0
            })
            
        return child_orders
        
    def _calculate_urgency(self, signal: TradingSignal,
                         market_data: Dict[str, Any]) -> float:
        """Calculate execution urgency score"""
        
        urgency_factors = []
        
        # Signal strength
        urgency_factors.append(signal.strength / 100)
        
        # Price momentum
        momentum = market_data.get('price_momentum', 0)
        if (signal.direction == 'long' and momentum > 0) or \
           (signal.direction == 'short' and momentum < 0):
            urgency_factors.append(0.8)
        else:
            urgency_factors.append(0.2)
            
        # Volatility
        if market_data.get('volatility', 0.02) > 0.03:
            urgency_factors.append(0.7)
        else:
            urgency_factors.append(0.3)
            
        return np.mean(urgency_factors)
        
    def _assess_execution_risk(self, signal: TradingSignal,
                             microstructure: Dict[str, Any]) -> Dict[str, Any]:
        """Assess execution risk"""
        
        risks = {}
            'slippage_risk': 'high' if microstructure['spread'] > 0.001 else 'low',
            'liquidity_risk': 'high' if microstructure['liquidity_score'] < 0.3 else 'low',
            'timing_risk': 'high' if microstructure['volatility'] > 0.03 else 'low',
            'market_impact_risk': 'high' if signal.position_size_currency > microstructure['depth'] * 0.1 else 'low'
        }
        
        return risks
        
    def _calculate_liquidity_score(self, market_data: Dict[str, Any]) -> float:
        """Calculate market liquidity score"""
        
        # Factors: spread, depth, volume
        spread_score = 1 - min(market_data.get('spread', 0.001) / 0.01, 1)
        depth_score = min(market_data.get('depth', 1000000) / 10000000, 1)
        volume_score = min(market_data.get('volume', 1000000) / 10000000, 1)
        
        return (spread_score + depth_score + volume_score) / 3
        
    def _estimate_price_impact(self, market_data: Dict[str, Any]) -> float:
        """Estimate price impact coefficient"""
        
        # Simplified square-root model
        return 0.1 * market_data.get('volatility', 0.02) / np.sqrt(market_data.get('volume', 1000000))
        
    def _execute_twap(self, signal: TradingSignal, params: Dict[str, Any]) -> None:
        """Execute TWAP algorithm"""
        pass
        
    def _execute_vwap(self, signal: TradingSignal, params: Dict[str, Any]) -> None:
        """Execute VWAP algorithm"""
        pass
        
    def _execute_iceberg(self, signal: TradingSignal, params: Dict[str, Any]) -> None:
        """Execute Iceberg algorithm"""
        pass
        
    def _execute_smart(self, signal: TradingSignal, params: Dict[str, Any]) -> None:
        """Execute smart routing algorithm"""
        pass


class PerformanceTracker:
    """Track and analyze signal performance"""
    
    def __init__(self):
        self.signal_history = []
        self.performance_metrics = defaultdict(dict)
        self.model_contributions = defaultdict(list)
        
    def track_signal(self, signal: TradingSignal, execution_result: Dict[str, Any]):
        """Track signal and execution results"""
        
        performance_record = {}
            'signal': signal,
            'execution': execution_result,
            'entry_time': datetime.now(),
            'entry_price': execution_result.get('fill_price', signal.entry_price),
            'status': 'open'
        }
        
        self.signal_history.append(performance_record)
        
    def update_performance(self, signal_id: str, update: Dict[str, Any]):
        """Update signal performance"""
        
        for record in self.signal_history:
            if record['signal'].signal_id == signal_id:
                record.update(update)
                
                if update.get('status') == 'closed':
                    self._calculate_signal_metrics(record)
                    
                break
                
    def _calculate_signal_metrics(self, record: Dict[str, Any]):
        """Calculate performance metrics for closed signal"""
        
        signal = record['signal']
        
        # Calculate P&L
        entry_price = record['entry_price']
        exit_price = record.get('exit_price', entry_price)
        
        if signal.direction == 'long':
            pnl_percent = (exit_price - entry_price) / entry_price
        else:
            pnl_percent = (entry_price - exit_price) / entry_price
            
        pnl_currency = pnl_percent * signal.position_size_currency
        
        # Update metrics
        signal_type = signal.signal_type.value
        
        if signal_type not in self.performance_metrics:
            self.performance_metrics[signal_type] = {}
                'count': 0,
                'wins': 0,
                'total_pnl': 0,
                'avg_pnl': 0,
                'win_rate': 0,
                'avg_win': 0,
                'avg_loss': 0,
                'profit_factor': 0
            }
            
        metrics = self.performance_metrics[signal_type]
        metrics['count'] += 1
        metrics['total_pnl'] += pnl_currency
        
        if pnl_currency > 0:
            metrics['wins'] += 1
            
        # Update model contributions
        for model, score in signal.model_scores.items():
            self.model_contributions[model].append({)
                'signal_id': signal.signal_id,
                'contribution': score,
                'pnl': pnl_currency * score  # Weighted by model contribution
            })
            
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary"""
        
        # Calculate aggregate metrics
        total_signals = len(self.signal_history)
        closed_signals = [r for r in self.signal_history if r.get('status') == 'closed']
        
        if not closed_signals:
            return {'status': 'no_closed_signals'}
            
        # Overall metrics
        total_pnl = sum(r.get('pnl_currency', 0) for r in closed_signals)
        win_count = sum(1 for r in closed_signals if r.get('pnl_currency', 0) > 0)
        win_rate = win_count / len(closed_signals)
        
        # Signal type breakdown
        signal_type_performance = {}
        for signal_type, metrics in self.performance_metrics.items():
            if metrics['count'] > 0:
                metrics['avg_pnl'] = metrics['total_pnl'] / metrics['count']
                metrics['win_rate'] = metrics['wins'] / metrics['count']
                signal_type_performance[signal_type] = metrics
                
        # Model performance
        model_performance = {}
        for model, contributions in self.model_contributions.items():
            if contributions:
                model_performance[model] = {}
                    'total_contribution': sum(c['pnl'] for c in contributions),
                    'avg_contribution': np.mean([c['pnl'] for c in contributions]),
                    'signal_count': len(contributions)
                }
                
        return {}
            'overall': {}
                'total_signals': total_signals,
                'closed_signals': len(closed_signals),
                'total_pnl': total_pnl,
                'win_rate': win_rate,
                'sharpe_ratio': self._calculate_sharpe_ratio(closed_signals),
                'max_drawdown': self._calculate_max_drawdown(closed_signals)
            },
            'by_signal_type': signal_type_performance,
            'by_model': model_performance,
            'recent_performance': self._get_recent_performance()
        }
        
    def _calculate_sharpe_ratio(self, closed_signals: List[Dict[str, Any]]) -> float:
        """Calculate Sharpe ratio from closed signals"""
        
        if len(closed_signals) < 2:
            return 0.0
            
        returns = [r.get('pnl_percent', 0) for r in closed_signals]
        
        if np.std(returns) == 0:
            return 0.0
            
        return np.mean(returns) / np.std(returns) * np.sqrt(252)  # Annualized
        
    def _calculate_max_drawdown(self, closed_signals: List[Dict[str, Any]]) -> float:
        """Calculate maximum drawdown"""
        
        if not closed_signals:
            return 0.0
            
        # Calculate cumulative returns
        cumulative_pnl = []
        current_pnl = 0
        
        for signal in sorted(closed_signals, key=lambda x: x['entry_time']):
            current_pnl += signal.get('pnl_currency', 0)
            cumulative_pnl.append(current_pnl)
            
        # Calculate drawdown
        peak = cumulative_pnl[0]
        max_drawdown = 0
        
        for pnl in cumulative_pnl:
            if pnl > peak:
                peak = pnl
            drawdown = (peak - pnl) / peak if peak > 0 else 0
            max_drawdown = max(max_drawdown, drawdown)
            
        return max_drawdown
        
    def _get_recent_performance(self, days: int = 7) -> Dict[str, Any]:
        """Get recent performance metrics"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_signals = []
            r for r in self.signal_history
            if r['entry_time'] > cutoff_date and r.get('status') == 'closed'
        ]
        
        if not recent_signals:
            return {'status': 'no_recent_signals'}
            
        return {}
            'signal_count': len(recent_signals),
            'total_pnl': sum(r.get('pnl_currency', 0) for r in recent_signals),
            'win_rate': sum(1 for r in recent_signals if r.get('pnl_currency', 0) > 0) / len(recent_signals),
            'avg_holding_time': np.mean([)
                (r.get('exit_time', r['entry_time']) - r['entry_time']).total_seconds() / 3600
                for r in recent_signals
            ])
        }


class SignalStreamManager:
    """Manage real-time signal streaming and persistence"""
    
    def __init__(self):
        self.active_signals = {}
        self.signal_queue = asyncio.Queue()
        self.subscribers = []
        self.persistence_enabled = True
        self.recovery_mode = False
        
    async def stream_signals(self, market_data_stream):
        """Stream signals in real-time"""
        
        async for market_data in market_data_stream:
            try:
                # Generate signal
                signal = await self._generate_signal_async(market_data)
                
                if signal:
                    # Add to queue
                    await self.signal_queue.put(signal)
                    
                    # Notify subscribers
                    await self._notify_subscribers(signal)
                    
                    # Persist signal
                    if self.persistence_enabled:
                        await self._persist_signal(signal)
                        
                    # Track active signal
                    self.active_signals[signal.signal_id] = signal
                    
            except Exception as e:
                logger.error(f"Error in signal streaming: {e}")
                
    async def _generate_signal_async(self, market_data: Dict[str, Any]) -> Optional[TradingSignal]:
        """Generate signal asynchronously"""
        # This would integrate with the main signal generation logic
        pass
        
    async def _notify_subscribers(self, signal: TradingSignal):
        """Notify all subscribers of new signal"""
        
        for subscriber in self.subscribers:
            try:
                await subscriber.on_signal(signal)
            except Exception as e:
                logger.error(f"Error notifying subscriber: {e}")
                
    async def _persist_signal(self, signal: TradingSignal):
        """Persist signal to storage"""
        
        signal_data = {}
            'signal_id': signal.signal_id,
            'timestamp': signal.timestamp.isoformat(),
            'signal_data': signal.__dict__
        }
        
        # Save to database/file
        with open(f"signals/{signal.signal_id}.json", 'w') as f:
            json.dump(signal_data, f)
            
    def subscribe(self, subscriber):
        """Subscribe to signal stream"""
        self.subscribers.append(subscriber)
        
    def unsubscribe(self, subscriber):
        """Unsubscribe from signal stream"""
        self.subscribers.remove(subscriber)


class TradingSignalModel:
    """Main trading signal generation model"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._get_default_config()
        
        # Initialize components
        self.ensemble = ModelEnsemble()
        self.regime_detector = MarketRegimeDetector()
        self.signal_processor = SignalProcessor()
        self.risk_manager = RiskManager()
        self.execution_engine = ExecutionEngine()
        self.performance_tracker = PerformanceTracker()
        self.stream_manager = SignalStreamManager()
        
        # Feature engineering
        self.feature_pipeline = self._create_feature_pipeline()
        
        # Alert system
        self.alert_system = self._create_alert_system()
        
        # A/B testing framework
        self.ab_testing = self._create_ab_testing_framework()
        
        logger.info("Trading Signal Model initialized successfully")
        
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {}
            'min_confidence': 0.6,
            'min_strength': 30,
            'max_positions': 20,
            'max_correlation': 0.7,
            'latency_target_ms': 100,
            'backtesting_enabled': True,
            'paper_trading_enabled': True,
            'production_mode': False
        }
        
    def _create_feature_pipeline(self):
        """Create feature engineering pipeline"""
        # This would include all feature transformations
        pass
        
    def _create_alert_system(self):
        """Create alert system for high-confidence signals"""
        # This would handle alerts and notifications
        pass
        
    def _create_ab_testing_framework(self):
        """Create A/B testing framework"""
        # This would handle model comparison and testing
        pass
        
    def generate_signal(self, market_data: pd.DataFrame,
                       portfolio: Dict[str, Any],
                       options_data: Optional[pd.DataFrame] = None) -> Optional[TradingSignal]:
        """Generate trading signal with <100ms latency"""
        
        start_time = time.time()
        
        try:
            # Extract features
            features = self._extract_features(market_data, options_data)
            
            # Detect market regime
            regime = self.regime_detector.detect_regime(market_data)
            
            # Get ensemble predictions
            predictions = self.ensemble.predict_ensemble(features, market_data)
            
            # Create market context
            market_context = self._create_market_context(market_data, regime, portfolio)
            
            # Process signal
            signal = self.signal_processor.process_signal(predictions, market_context)
            
            if signal:
                # Risk validation
                is_valid, violations = self.risk_manager.validate_signal(signal, portfolio)
                
                if not is_valid:
                    logger.warning(f"Signal rejected due to risk violations: {violations}")
                    return None
                    
                # Adjust position size
                signal.position_size = self.risk_manager.calculate_dynamic_position_size(signal, portfolio)
                
                # Generate execution plan
                execution_plan = self.execution_engine.optimize_execution(signal, market_context)
                
                # Add execution details to signal
                signal.execution_plan = execution_plan
                
                # Generate hedging recommendations
                signal.hedging_recommendations = self.risk_manager.generate_hedging_recommendations(signal, portfolio)
                
                # Track performance
                self.performance_tracker.track_signal(signal, {'status': 'generated'})
                
                # Check latency
                latency_ms = (time.time() - start_time) * 1000
                if latency_ms > self.config['latency_target_ms']:
                    logger.warning(f"Signal generation latency {latency_ms:.1f}ms exceeds target")
                    
                logger.info(f"Generated signal {signal.signal_id} in {latency_ms:.1f}ms")
                
                return signal
                
        except Exception as e:
            logger.error(f"Error generating signal: {e}")
            return None
            
    def _extract_features(self, market_data: pd.DataFrame,
                         options_data: Optional[pd.DataFrame]) -> np.ndarray:
        """Extract features for model input"""
        
        features = []
        
        # Price features
        features.extend(self._calculate_price_features(market_data))
        
        # Technical indicators
        features.extend(self._calculate_technical_indicators(market_data))
        
        # Market microstructure
        features.extend(self._calculate_microstructure_features(market_data))
        
        # Options features (if available)
        if options_data is not None:
            features.extend(self._calculate_options_features(options_data))
            
        # Convert to numpy array and reshape
        feature_array = np.array(features)
        
        # Reshape for model input (sequence_length, num_features)
        sequence_length = 50
        num_features = len(features) // sequence_length
        
        return feature_array.reshape(sequence_length, num_features)
        
    def _calculate_price_features(self, market_data: pd.DataFrame) -> List[float]:
        """Calculate price-based features"""
        
        features = []
        
        # Returns at different intervals
        for interval in [1, 5, 10, 20, 50]:
            returns = market_data['close'].pct_change(interval)
            features.append(returns.iloc[-1])
            features.append(returns.mean())
            features.append(returns.std())
            
        # Price relative to moving averages
        for period in [10, 20, 50, 200]:
            ma = market_data['close'].rolling(period).mean()
            features.append((market_data['close'].iloc[-1] - ma.iloc[-1]) / ma.iloc[-1])
            
        # High/Low features
        for period in [5, 10, 20]:
            high = market_data['high'].rolling(period).max()
            low = market_data['low'].rolling(period).min()
            features.append((market_data['close'].iloc[-1] - low.iloc[-1]) / (high.iloc[-1] - low.iloc[-1]))
            
        return features
        
    def _calculate_technical_indicators(self, market_data: pd.DataFrame) -> List[float]:
        """Calculate technical indicators"""
        
        features = []
        
        # RSI
        for period in [14, 21, 28]:
            rsi = talib.RSI(market_data['close'].values, timeperiod=period)
            features.append(rsi[-1])
            
        # MACD
        macd, signal, hist = talib.MACD(market_data['close'].values)
        features.extend([macd[-1], signal[-1], hist[-1]])
        
        # Bollinger Bands
        upper, middle, lower = talib.BBANDS(market_data['close'].values)
        features.append((market_data['close'].iloc[-1] - lower[-1]) / (upper[-1] - lower[-1]))
        
        # ATR
        atr = talib.ATR(market_data['high'].values, market_data['low'].values, market_data['close'].values)
        features.append(atr[-1] / market_data['close'].iloc[-1])
        
        # Volume indicators
        features.append(market_data['volume'].iloc[-1] / market_data['volume'].rolling(20).mean().iloc[-1])
        
        return features
        
    def _calculate_microstructure_features(self, market_data: pd.DataFrame) -> List[float]:
        """Calculate market microstructure features"""
        
        features = []
        
        # Spread (if available)
        if 'bid' in market_data.columns and 'ask' in market_data.columns:
            spread = market_data['ask'] - market_data['bid']
            features.append(spread.iloc[-1] / market_data['close'].iloc[-1])
            features.append(spread.mean() / market_data['close'].mean())
            
        # Volume profile
        volume_profile = market_data.groupby(pd.cut(market_data['close'], bins=10))['volume'].sum()
        features.extend(volume_profile.values / volume_profile.sum())
        
        # Trade imbalance (if available)
        if 'buy_volume' in market_data.columns and 'sell_volume' in market_data.columns:
            imbalance = (market_data['buy_volume'] - market_data['sell_volume']) / market_data['volume']
            features.append(imbalance.iloc[-1])
            features.append(imbalance.rolling(10).mean().iloc[-1])
            
        return features
        
    def _calculate_options_features(self, options_data: pd.DataFrame) -> List[float]:
        """Calculate options-based features"""
        
        features = []
        
        # Put/Call ratio
        if 'put_volume' in options_data.columns and 'call_volume' in options_data.columns:
            pc_ratio = options_data['put_volume'] / options_data['call_volume']
            features.append(pc_ratio.iloc[-1])
            
        # Implied volatility skew
        if 'iv_call' in options_data.columns and 'iv_put' in options_data.columns:
            iv_skew = options_data['iv_put'] - options_data['iv_call']
            features.append(iv_skew.iloc[-1])
            
        # Term structure
        if 'iv_1m' in options_data.columns and 'iv_3m' in options_data.columns:
            term_structure = options_data['iv_3m'] - options_data['iv_1m']
            features.append(term_structure.iloc[-1])
            
        return features
        
    def _create_market_context(self, market_data: pd.DataFrame,
                             regime: MarketRegime,
                             portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive market context"""
        
        returns = market_data['close'].pct_change()
        
        context = {}
            'asset': portfolio.get('primary_asset', 'SPY'),
            'current_price': market_data['close'].iloc[-1],
            'regime': regime,
            'volatility': returns.rolling(20).std().iloc[-1] * np.sqrt(252),
            'volume_ratio': market_data['volume'].iloc[-1] / market_data['volume'].rolling(20).mean().iloc[-1],
            'rsi': talib.RSI(market_data['close'].values)[-1],
            'spread': market_data.get('spread', pd.Series([0.0001])).iloc[-1],
            'liquidity': 'high',  # Would be calculated based on order book
            'portfolio_value': portfolio.get('total_value', 100000),
            'correlation_risk': self._calculate_portfolio_correlation(portfolio),
            'trend_alignment': self._check_trend_alignment(market_data, regime),
            'price_momentum': returns.rolling(10).mean().iloc[-1] * 252
        }
        
        return context
        
    def _calculate_portfolio_correlation(self, portfolio: Dict[str, Any]) -> float:
        """Calculate portfolio correlation risk"""
        # Simplified version
        return len(portfolio.get('positions', [])) * 0.05
        
    def _check_trend_alignment(self, market_data: pd.DataFrame,
                              regime: MarketRegime) -> bool:
        """Check if current price action aligns with regime"""
        
        if regime == MarketRegime.TRENDING_UP:
            return market_data['close'].iloc[-1] > market_data['close'].iloc[-20]
        elif regime == MarketRegime.TRENDING_DOWN:
            return market_data['close'].iloc[-1] < market_data['close'].iloc[-20]
        else:
            return True
            
    def backtest(self, historical_data: pd.DataFrame,
                initial_portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """Backtest the signal generation model"""
        
        if not self.config['backtesting_enabled']:
            return {'error': 'Backtesting not enabled'}
            
        results = {}
            'signals': [],
            'trades': [],
            'performance': {},
            'statistics': {}
        }
        
        portfolio = initial_portfolio.copy()
        
        # Rolling window backtest
        window_size = 1000
        step_size = 1
        
        for i in range(window_size, len(historical_data), step_size):
            # Get data window
            window_data = historical_data.iloc[i-window_size:i]
            
            # Generate signal
            signal = self.generate_signal(window_data, portfolio)
            
            if signal:
                results['signals'].append(signal)
                
                # Simulate execution
                execution_result = self._simulate_execution(signal, window_data)
                results['trades'].append(execution_result)
                
                # Update portfolio
                self._update_portfolio(portfolio, signal, execution_result)
                
        # Calculate performance metrics
        results['performance'] = self._calculate_backtest_performance(results['trades'])
        results['statistics'] = self._calculate_backtest_statistics(results)
        
        return results
        
    def _simulate_execution(self, signal: TradingSignal,
                          market_data: pd.DataFrame) -> Dict[str, Any]:
        """Simulate trade execution for backtesting"""
        
        # Simulate slippage
        slippage = np.random.normal(0.0001, 0.00005)
        
        if signal.direction == 'long':
            fill_price = signal.entry_price * (1 + slippage)
        else:
            fill_price = signal.entry_price * (1 - slippage)
            
        return {}
            'signal_id': signal.signal_id,
            'fill_price': fill_price,
            'fill_time': signal.timestamp,
            'status': 'filled'
        }
        
    def _update_portfolio(self, portfolio: Dict[str, Any],
                        signal: TradingSignal,
                        execution_result: Dict[str, Any]):
        """Update portfolio after trade execution"""
        
        # Add position
        position = {}
            'signal_id': signal.signal_id,
            'asset': signal.asset,
            'size': signal.position_size,
            'entry_price': execution_result['fill_price'],
            'direction': signal.direction,
            'stop_loss': signal.stop_loss,
            'take_profit': signal.take_profit
        }
        
        if 'positions' not in portfolio:
            portfolio['positions'] = []
            
        portfolio['positions'].append(position)
        
    def _calculate_backtest_performance(self, trades: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate backtest performance metrics"""
        
        if not trades:
            return {'status': 'no_trades'}
            
        # Calculate returns
        returns = []
        for i, trade in enumerate(trades):
            if i > 0 and 'exit_price' in trade:
                if trade['direction'] == 'long':
                    ret = (trade['exit_price'] - trade['fill_price']) / trade['fill_price']
                else:
                    ret = (trade['fill_price'] - trade['exit_price']) / trade['fill_price']
                returns.append(ret)
                
        if not returns:
            return {'status': 'no_closed_trades'}
            
        returns = np.array(returns)
        
        return {}
            'total_return': np.prod(1 + returns) - 1,
            'annual_return': (np.prod(1 + returns) ** (252 / len(returns))) - 1,
            'sharpe_ratio': np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else 0,
            'max_drawdown': self._calculate_max_drawdown_from_returns(returns),
            'win_rate': np.sum(returns > 0) / len(returns),
            'avg_win': np.mean(returns[returns > 0]) if np.any(returns > 0) else 0,
            'avg_loss': np.mean(returns[returns < 0]) if np.any(returns < 0) else 0,
            'profit_factor': -np.sum(returns[returns > 0]) / np.sum(returns[returns < 0]) if np.any(returns < 0) else np.inf
        }
        
    def _calculate_max_drawdown_from_returns(self, returns: np.ndarray) -> float:
        """Calculate maximum drawdown from returns series"""
        
        cumulative = np.cumprod(1 + returns)
        running_max = np.maximum.accumulate(cumulative)
        drawdown = (cumulative - running_max) / running_max
        
        return np.min(drawdown)
        
    def _calculate_backtest_statistics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate additional backtest statistics"""
        
        signals = results['signals']
        
        if not signals:
            return {'status': 'no_signals'}
            
        # Signal statistics
        signal_types = [s.signal_type.value for s in signals]
        signal_type_counts = pd.Series(signal_types).value_counts().to_dict()
        
        # Timing statistics
        signal_times = [s.timestamp.hour for s in signals]
        signal_hour_distribution = pd.Series(signal_times).value_counts().sort_index().to_dict()
        
        # Strength statistics
        signal_strengths = [s.strength for s in signals]
        
        return {}
            'total_signals': len(signals),
            'signals_per_day': len(signals) / ((signals[-1].timestamp - signals[0].timestamp).days + 1),
            'signal_types': signal_type_counts,
            'hour_distribution': signal_hour_distribution,
            'avg_strength': np.mean(signal_strengths),
            'avg_confidence': np.mean([s.confidence for s in signals])
        }
        
    def integrate_with_production(self) -> Dict[str, Any]:
        """Integration function for MASTER_PRODUCTION_INTEGRATION.py"""
        
        return {}
            'model_name': 'TradingSignalModel',
            'version': '1.0.0',
            'api': {}
                'generate_signal': self.generate_signal,
                'backtest': self.backtest,
                'get_performance': self.performance_tracker.get_performance_summary,
                'stream_signals': self.stream_manager.stream_signals
            },
            'config': self.config,
            'dependencies': {}
                'ensemble': self.ensemble,
                'regime_detector': self.regime_detector,
                'signal_processor': self.signal_processor,
                'risk_manager': self.risk_manager,
                'execution_engine': self.execution_engine,
                'performance_tracker': self.performance_tracker
            },
            'monitoring': {}
                'latency_target_ms': self.config['latency_target_ms'],
                'health_check': self._health_check,
                'metrics': self._get_metrics
            }
        }
        
    def _health_check(self) -> Dict[str, Any]:
        """Perform health check"""
        
        return {}
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'components': {}
                'ensemble': 'ok',
                'risk_manager': 'ok',
                'execution_engine': 'ok',
                'performance_tracker': 'ok'
            }
        }
        
    def _get_metrics(self) -> Dict[str, Any]:
        """Get current metrics"""
        
        return {}
            'active_signals': len(self.stream_manager.active_signals),
            'performance': self.performance_tracker.get_performance_summary(),
            'model_weights': self.ensemble.model_weights
        }


# Example usage and testing
if __name__ == "__main__":
    # Initialize the model
    config = {}
        'min_confidence': 0.6,
        'min_strength': 30,
        'max_positions': 20,
        'latency_target_ms': 100,
        'production_mode': True
    }
    
    model = TradingSignalModel(config)
    
    # Example: Generate a signal
    # Create sample market data
    dates = pd.date_range(end=datetime.now(), periods=1000, freq='5min')
    market_data = pd.DataFrame({)
        'timestamp': dates,
        'open': np.random.randn(1000).cumsum() + 100,
        'high': np.random.randn(1000).cumsum() + 101,
        'low': np.random.randn(1000).cumsum() + 99,
        'close': np.random.randn(1000).cumsum() + 100,
        'volume': np.random.randint(1000000, 5000000, 1000),
        'bid': np.random.randn(1000).cumsum() + 99.99,
        'ask': np.random.randn(1000).cumsum() + 100.01
    })
    
    # Sample portfolio
    portfolio = {}
        'total_value': 100000,
        'positions': [],
        'primary_asset': 'SPY'
    }
    
    # Generate signal
    signal = model.generate_signal(market_data, portfolio)
    
    if signal:
        print(f"Generated Signal: {signal.signal_id}")
        print(f"Direction: {signal.direction}")
        print(f"Strength: {signal.strength}")
        print(f"Confidence: {signal.confidence:.1%}")
        print(f"Position Size: ${signal.position_size_currency:,.2f}")
        print(f"Stop Loss: ${signal.stop_loss:.2f}")
        print(f"Take Profit: ${signal.take_profit:.2f}")
        print(f"Explanation: {signal.explanation}")
        
    # Get integration details
    integration = model.integrate_with_production()
    print(f"\nIntegration ready: {integration['model_name']} v{integration['version']}")