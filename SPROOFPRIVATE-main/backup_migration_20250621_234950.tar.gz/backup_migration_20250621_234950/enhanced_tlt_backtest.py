#!/usr/bin/env python3
"""
Enhanced TLT Covered Call Backtest with IV Modeling
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from scipy import stats

print("Running Enhanced TLT Covered Call Strategy Backtest...")
print("=" * 80)

# Generate realistic TLT data with volatility clustering
np.random.seed(42)
dates = pd.date_range(start='2022-01-01', end='2024-12-31', freq='B')

# GARCH-like volatility model for more realistic vol clustering
n_days = len(dates)
vol = np.zeros(n_days)
returns = np.zeros(n_days)
prices = np.zeros(n_days)

# Initial values
vol[0] = 0.12 / np.sqrt(252)  # 12% annual vol
returns[0] = 0
prices[0] = 120.0

# Parameters for GARCH-like process
alpha = 0.1  # Impact of recent shocks
beta = 0.85  # Persistence
omega = 0.01  # Base variance

# Simulate prices with volatility clustering
for t in range(1, n_days):
    # Update volatility (simplified GARCH)
    vol[t] = np.sqrt(omega + alpha * returns[t-1]**2 + beta * vol[t-1]**2)
    vol[t] = min(vol[t], 0.03)  # Cap daily vol at 3%
    
    # Generate return
    returns[t] = np.random.normal(0.0001, vol[t])  # Small positive drift
    
    # Calculate price
    prices[t] = prices[t-1] * (1 + returns[t])

# Create DataFrame
data = pd.DataFrame({
    'Date': dates,
    'Close': prices,
    'Returns': returns,
    'Volatility': vol * np.sqrt(252)  # Annualized
})

# Calculate historical volatility metrics
data['HV_20'] = data['Returns'].rolling(20).std() * np.sqrt(252)
data['HV_30'] = data['Returns'].rolling(30).std() * np.sqrt(252)
data['HV_60'] = data['Returns'].rolling(60).std() * np.sqrt(252)

# Calculate IV proxy (HV with forward-looking adjustments)
data['IV_Proxy'] = data['HV_20'].shift(-10).rolling(10).mean()  # Forward-looking component
data['IV_Proxy'] = data['IV_Proxy'].bfill().fillna(data['HV_20'])

# Calculate IV percentile
data['IV_Percentile'] = data['IV_Proxy'].rolling(252).rank(pct=True) * 100

# Backtest parameters
initial_shares = 10000
contracts = initial_shares // 100  # 100 contracts
initial_value = initial_shares * data['Close'].iloc[0]
cash = 0
trades = []
active_position = None

print(f"Initial Position: {initial_shares} shares @ ${data['Close'].iloc[0]:.2f}")
print(f"Initial Value: ${initial_value:,.2f}")
print(f"Contracts Available: {contracts}")
print("-" * 80)

# Track portfolio value over time
portfolio_values = []

# Run backtest
for i in range(60, len(data) - 45):  # Need history for IV calc, stop before end
    current_date = data['Date'].iloc[i]
    current_price = data['Close'].iloc[i]
    iv_proxy = data['IV_Proxy'].iloc[i]
    iv_percentile = data['IV_Percentile'].iloc[i]
    
    # Record portfolio value
    stock_value = current_price * initial_shares
    total_value = stock_value + cash
    portfolio_values.append({
        'date': current_date,
        'stock_value': stock_value,
        'cash': cash,
        'total_value': total_value
    })
    
    # Check if active position expired
    if active_position and current_date >= active_position['expiry_date']:
        expiry_price = current_price
        if expiry_price >= active_position['strike']:
            # Assigned - shares called away
            cash += active_position['strike'] * initial_shares
            cash -= expiry_price * initial_shares  # Buy back immediately
            active_position['assigned'] = True
            active_position['pnl'] = active_position['premium']
            
            print(f"{current_date.date()} - Call ASSIGNED at ${active_position['strike']:.2f}, "
                  f"bought back at ${expiry_price:.2f}")
        else:
            # Expired worthless
            active_position['assigned'] = False
            active_position['pnl'] = active_position['premium']
            
        trades.append(active_position)
        active_position = None
    
    # Sell new calls if conditions met
    if (active_position is None and 
        pd.notna(iv_percentile) and 
        iv_percentile >= 75):  # Sell when IV in top quartile
        
        # Find optimal strike (delta ~0.30, about 3-5% OTM)
        dte = 30  # Days to expiration
        time_to_exp = dte / 365
        
        # Calculate strikes
        otm_pcts = [0.02, 0.03, 0.04, 0.05]  # 2-5% OTM
        best_strike = None
        best_premium = 0
        
        for otm_pct in otm_pcts:
            strike = current_price * (1 + otm_pct)
            
            # Black-Scholes approximation for call premium
            d1 = (np.log(current_price/strike) + (0.04 + iv_proxy**2/2)*time_to_exp) / (iv_proxy*np.sqrt(time_to_exp))
            d2 = d1 - iv_proxy*np.sqrt(time_to_exp)
            
            call_delta = stats.norm.cdf(d1)
            call_premium = current_price * stats.norm.cdf(d1) - strike * np.exp(-0.04*time_to_exp) * stats.norm.cdf(d2)
            
            # Target delta around 0.30
            if 0.25 <= call_delta <= 0.35 and call_premium > best_premium:
                best_strike = strike
                best_premium = call_premium
        
        if best_strike:
            # Execute trade
            total_premium = best_premium * contracts * 100
            cash += total_premium
            
            expiry_date = current_date + pd.Timedelta(days=dte)
            # Adjust to next Friday
            days_to_friday = (4 - expiry_date.weekday()) % 7
            if days_to_friday == 0:
                days_to_friday = 7
            expiry_date += pd.Timedelta(days=days_to_friday)
            
            active_position = {
                'entry_date': current_date,
                'expiry_date': expiry_date,
                'current_price': current_price,
                'strike': best_strike,
                'premium': total_premium,
                'contracts': contracts,
                'iv': iv_proxy,
                'iv_percentile': iv_percentile,
                'assigned': False
            }
            
            print(f"{current_date.date()} - SOLD {contracts} calls @ ${best_strike:.2f} strike, "
                  f"premium ${total_premium:,.2f}, IV {iv_proxy*100:.1f}% ({iv_percentile:.0f}%ile)")

# Final portfolio value
final_price = data['Close'].iloc[-1]
final_stock_value = initial_shares * final_price
total_value = final_stock_value + cash

# Record final value
portfolio_values.append({
    'date': data['Date'].iloc[-1],
    'stock_value': final_stock_value,
    'cash': cash,
    'total_value': total_value
})

# Convert to DataFrame for analysis
portfolio_df = pd.DataFrame(portfolio_values)
portfolio_df['returns'] = portfolio_df['total_value'].pct_change()

# Buy and hold comparison
buy_hold_value = initial_shares * final_price

# Calculate metrics
strategy_return = (total_value - initial_value) / initial_value * 100
buy_hold_return = (buy_hold_value - initial_value) / initial_value * 100
excess_return = strategy_return - buy_hold_return

# Risk metrics
sharpe_ratio = (portfolio_df['returns'].mean() * 252) / (portfolio_df['returns'].std() * np.sqrt(252))
max_dd = (portfolio_df['total_value'] / portfolio_df['total_value'].cummax() - 1).min() * 100

# Annualized returns
years = 3
annualized_strategy = (pow(total_value / initial_value, 1/years) - 1) * 100
annualized_buy_hold = (pow(buy_hold_value / initial_value, 1/years) - 1) * 100

# Trade statistics
num_trades = len(trades)
assigned_trades = sum(1 for t in trades if t['assigned'])
win_rate = sum(1 for t in trades if t['pnl'] > 0) / max(1, num_trades) * 100
avg_premium = sum(t['premium'] for t in trades) / max(1, num_trades)

# Print results
print("\n" + "=" * 80)
print("ENHANCED BACKTEST RESULTS")
print("=" * 80)
print(f"\nPERFORMANCE METRICS:")
print(f"  Strategy Total Return: {strategy_return:.2f}%")
print(f"  Buy & Hold Return: {buy_hold_return:.2f}%")
print(f"  Excess Return: {excess_return:.2f}%")
print(f"  Annualized Return: {annualized_strategy:.2f}%")
print(f"  Sharpe Ratio: {sharpe_ratio:.2f}")
print(f"  Max Drawdown: {max_dd:.2f}%")

print(f"\nTRADE STATISTICS:")
print(f"  Total Trades: {num_trades}")
print(f"  Assigned Trades: {assigned_trades} ({assigned_trades/max(1,num_trades)*100:.1f}%)")
print(f"  Win Rate: {win_rate:.1f}%")
print(f"  Average Premium: ${avg_premium:,.2f}")
print(f"  Total Premium: ${cash:,.2f}")

print(f"\nFINAL VALUES:")
print(f"  Initial Investment: ${initial_value:,.2f}")
print(f"  Final Portfolio Value: ${total_value:,.2f}")
print(f"  Stock Value: ${final_stock_value:,.2f}")
print(f"  Cash Balance: ${cash:,.2f}")

# Create visualization
fig, axes = plt.subplots(3, 1, figsize=(12, 10))

# Portfolio value over time
ax1 = axes[0]
ax1.plot(portfolio_df['date'], portfolio_df['total_value'], label='Covered Call Strategy', linewidth=2)
ax1.plot(data['Date'], data['Close'] * initial_shares, label='Buy & Hold', alpha=0.7, linestyle='--')
ax1.set_ylabel('Portfolio Value ($)')
ax1.set_title('TLT Covered Call Strategy Performance')
ax1.legend()
ax1.grid(True, alpha=0.3)

# IV percentile and trades
ax2 = axes[1]
ax2.plot(data['Date'], data['IV_Percentile'], label='IV Percentile', alpha=0.7)
ax2.axhline(y=75, color='red', linestyle='--', label='Sell Threshold (75%)')

# Mark trades
for trade in trades:
    ax2.scatter(trade['entry_date'], trade['iv_percentile'], 
               color='green' if not trade['assigned'] else 'red', 
               s=100, zorder=5)

ax2.set_ylabel('IV Percentile')
ax2.set_title('Implied Volatility and Trade Timing')
ax2.legend()
ax2.grid(True, alpha=0.3)

# Monthly returns comparison
ax3 = axes[2]
monthly_returns = portfolio_df.set_index('date')['returns'].resample('M').apply(lambda x: (1 + x).prod() - 1)
monthly_returns.plot(kind='bar', ax=ax3, color=['green' if r > 0 else 'red' for r in monthly_returns])
ax3.set_ylabel('Monthly Return (%)')
ax3.set_title('Monthly Returns Distribution')
ax3.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('enhanced_tlt_backtest_results.png', dpi=150, bbox_inches='tight')
print(f"\nChart saved to: enhanced_tlt_backtest_results.png")

# Save results
results = {
    'strategy': 'TLT Covered Call (Enhanced)',
    'period': '2022-01-01 to 2024-12-31',
    'parameters': {
        'shares': initial_shares,
        'contracts': contracts,
        'iv_threshold': 75
    },
    'performance': {
        'initial_value': initial_value,
        'final_value': total_value,
        'strategy_return': strategy_return,
        'buy_hold_return': buy_hold_return,
        'excess_return': excess_return,
        'annualized_return': annualized_strategy,
        'sharpe_ratio': sharpe_ratio,
        'max_drawdown': max_dd
    },
    'trade_stats': {
        'total_trades': num_trades,
        'assigned_trades': assigned_trades,
        'assignment_rate': assigned_trades/max(1,num_trades)*100,
        'win_rate': win_rate,
        'avg_premium': avg_premium,
        'total_premium': cash
    }
}

with open('enhanced_tlt_backtest_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print(f"Results saved to: enhanced_tlt_backtest_results.json")
print("=" * 80)