#!/usr/bin/env python3
"""
Production Market Data Provider with Realistic Prices
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, List, Tuple
import pandas as pd
import numpy as np
import json
import time
from functools import lru_cache

from universal_market_data import get_current_market_data, get_realistic_price

logger = logging.getLogger(__name__)

class ProductionMarketDataProvider:
    """Provides realistic market data with multiple fallback options"""
    
    # Realistic price ranges as of 2024-2025
    PRICE_RANGES = {}  # Removed - use get_current_market_data() instead
    
    def __init__(self):
        self.cache = {}
        self.cache_duration = 60  # seconds
        self.last_update = {}
        self.market_state = self._initialize_market_state()
        
        # Try to load Alpaca client
        self.alpaca_client = None
        self._init_alpaca_client()
        
        # Initialize with base prices
        self.base_prices = self._initialize_base_prices()
        
    def _init_alpaca_client(self):
        """Try to initialize Alpaca client"""
        try:
            from alpaca.data.historical import StockHistoricalDataClient
            
            api_key = os.getenv("ALPACA_API_KEY")
            secret_key = os.getenv("ALPACA_SECRET_KEY")
            
            if api_key and secret_key:
                self.alpaca_client = StockHistoricalDataClient(api_key, secret_key)
                logger.info("Alpaca client initialized")
        except Exception as e:
            logger.debug(f"Alpaca client not available: {e}")
    
    def _initialize_market_state(self) -> Dict:
        """Initialize market state variables"""
        return {}
            'volatility': 0.15,  # Current market volatility
            'trend': 0.0,       # Market trend (-1 to 1)
            'volume_multiplier': 1.0,
            'last_update': datetime.now()
        }
    
    def _initialize_base_prices(self) -> Dict[str, float]:
        """Initialize base prices in the middle of ranges"""
        prices = {}
        for symbol, (low, high) in self.PRICE_RANGES.items():
            prices[symbol] = (low + high) / 2
        return prices
    
    def get_latest_price(self, symbol: str) -> Optional[float]:
        """Get latest price with multiple fallbacks"""
        # Check cache
        if self._is_cache_valid(symbol):
            return self.cache[symbol]
        
        price = None
        
        # Try Alpaca first
        if self.alpaca_client:
            price = self._get_alpaca_price(symbol)
        
        # Try YFinance as fallback
        if price is None:
            price = self._get_yfinance_price(symbol)
        
        # Use realistic simulation as final fallback
        if price is None:
            price = self._generate_realistic_price(symbol)
        
        # Validate and cache
        if price and self._validate_price(symbol, price):
            self.cache[symbol] = price
            self.last_update[symbol] = time.time()
            return price
        
        # Return base price if all else fails
        return self.base_prices.get(symbol, 100.0)
    
    def _is_cache_valid(self, symbol: str) -> bool:
        """Check if cached price is still valid"""
        if symbol not in self.cache:
            return False
        
        age = time.time() - self.last_update.get(symbol, 0)
        return age < self.cache_duration
    
    def _get_alpaca_price(self, symbol: str) -> Optional[float]:
        """Try to get price from Alpaca"""
        if not self.alpaca_client:
            return None
            
        try:
            from alpaca.data.requests import StockLatestQuoteRequest
            
            request = StockLatestQuoteRequest(symbol_or_symbols=[symbol])
            quotes = self.alpaca_client.get_stock_latest_quote(request)
            
            if symbol in quotes:
                quote = quotes[symbol]
                if quote.ask_price and quote.ask_price > 0:
                    return float(quote.ask_price)
                elif quote.bid_price and quote.bid_price > 0:
                    return float(quote.bid_price)
        except Exception as e:
            logger.debug(f"Alpaca price fetch failed for {symbol}: {e}")
        
        return None
    
    def _get_yfinance_price(self, symbol: str) -> Optional[float]:
        """Try to get price from Yahoo Finance"""
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            
            # Try fast_info first (more reliable)
            try:
                fast_info = ticker.fast_info
                if hasattr(fast_info, 'last_price') and fast_info.last_price:
                    return float(fast_info.last_price)
            except:
                pass
            
            # Try regular info
            info = ticker.info
            for field in ['currentPrice', 'regularMarketPrice', 'previousClose']:
                if field in info and info[field]:
                    return float(info[field])
                    
        except Exception as e:
            logger.debug(f"YFinance price fetch failed for {symbol}: {e}")
        
        return None
    
    def _generate_realistic_price(self, symbol: str) -> float:
        """Generate realistic price based on market conditions"""
        # Get base price and range
        if symbol not in self.PRICE_RANGES:
            # For unknown symbols, use a generic range
            low, high = 50, 150
        else:
            low, high = self.PRICE_RANGES[symbol]
        
        # Get or initialize current price
        current_price = self.base_prices.get(symbol, (low + high) / 2)
        
        # Update market state
        self._update_market_state()
        
        # Apply market dynamics
        # 1. Trend component
        trend_impact = self.market_state['trend'] * 0.001
        
        # 2. Random walk with mean reversion
        volatility = self.market_state['volatility']
        random_walk = np.random.normal(0, volatility / 100)
        
        # 3. Mean reversion force
        mid_price = (low + high) / 2
        reversion_force = (mid_price - current_price) / mid_price * 0.01
        
        # 4. Intraday pattern (U-shaped volume/volatility)
        now = datetime.now()
        minutes_since_open = (now.hour - 9) * 60 + now.minute - 30
        if 0 <= minutes_since_open <= 390:  # Market hours
            # Higher volatility at open and close
            time_factor = 1 + 0.5 * (np.exp(-minutes_since_open/60) +)
                                    np.exp(-(390-minutes_since_open)/60))
        else:
            time_factor = 0.5  # After hours - lower volatility
        
        # Combine all factors
        price_change = (trend_impact + random_walk + reversion_force) * time_factor
        new_price = current_price * (1 + price_change)
        
        # Ensure price stays in reasonable range
        new_price = max(low * 0.9, min(high * 1.1, new_price))
        
        # Update base price for next iteration
        self.base_prices[symbol] = new_price
        
        return round(new_price, 2)
    
    def _update_market_state(self):
        """Update overall market state"""
        # Simple market regime model
        now = datetime.now()
        
        # Market trend follows a slow sine wave with noise
        days_elapsed = (now - datetime(2024, 1, 1)).days
        self.market_state['trend'] = 0.3 * np.sin(days_elapsed / 50) + \
                                   0.1 * np.random.randn()
        
        # Volatility clusters
        if np.random.random() < 0.05:  # 5% chance of volatility spike
            self.market_state['volatility'] = min(0.5, 
                self.market_state['volatility'] * 1.5)
        else:
            # Mean revert volatility
            self.market_state['volatility'] = 0.15 + \
                0.85 * self.market_state['volatility']
        
        self.market_state['last_update'] = now
    
    def _validate_price(self, symbol: str, price: float) -> bool:
        """Validate if price is reasonable"""
        if price <= 0:
            return False
        
        # Check against known ranges
        if symbol in self.PRICE_RANGES:
            low, high = self.PRICE_RANGES[symbol]
            # Allow 20% outside of normal range
            if price < low * 0.8 or price > high * 1.2:
                logger.warning(f"Price {price} for {symbol} outside expected range [{low}, {high}]")
                return False
        
        return True
    
    def get_bulk_prices(self, symbols: List[str]) -> Dict[str, float]:
        """Get prices for multiple symbols"""
        prices = {}
        
        for symbol in symbols:
            price = self.get_latest_price(symbol)
            if price:
                prices[symbol] = price
        
        return prices
    
    def get_historical_bars(self, symbol: str, days: int = 30) -> pd.DataFrame:
        """Generate historical data"""
        # Try to get real data first
        if self.alpaca_client:
            try:
                from alpaca.data.requests import StockBarsRequest
                from alpaca.data.timeframe import TimeFrame
                
                request = StockBarsRequest()
                    symbol_or_symbols=[symbol],
                    timeframe=TimeFrame.Day,
                    start=datetime.now() - timedelta(days=days)
                )
                bars = self.alpaca_client.get_stock_bars(request)
                
                if symbol in bars and len(bars[symbol]) > 0:
                    data = []
                    for bar in bars[symbol]:
                        data.append({)
                            'timestamp': bar.timestamp,
                            'open': bar.open,
                            'high': bar.high,
                            'low': bar.low,
                            'close': bar.close,
                            'volume': bar.volume
                        })
                    df = pd.DataFrame(data)
                    df.set_index('timestamp', inplace=True)
                    return df
            except:
                pass
        
        # Generate realistic historical data
        return self._generate_historical_data(symbol, days)
    
    def _generate_historical_data(self, symbol: str, days: int) -> pd.DataFrame:
        """Generate realistic historical data"""
        # Get price range
        if symbol in self.PRICE_RANGES:
            low, high = self.PRICE_RANGES[symbol]
        else:
            low, high = 50, 150
        
        # Generate daily data
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        
        # Start from middle of range
        prices = []
        current_price = (low + high) / 2
        
        for i in range(days):
            # Daily return with momentum
            daily_return = np.random.normal(0.0005, 0.02)  # 0.05% mean, 2% std
            
            # Add trend
            trend = 0.0002 * np.sin(i / 20)  # Cyclical trend
            
            # Update price
            current_price *= (1 + daily_return + trend)
            current_price = max(low * 0.9, min(high * 1.1, current_price))
            
            # Generate OHLC
            daily_volatility = abs(np.random.normal(0, 0.01))
            open_price = current_price * (1 + np.random.normal(0, daily_volatility))
            high_price = max(open_price, current_price) * (1 + abs(np.random.normal(0, daily_volatility)))
            low_price = min(open_price, current_price) * (1 - abs(np.random.normal(0, daily_volatility)))
            
            # Volume (log-normal distribution)
            base_volume = 10_000_000 if symbol in ['AAPL', 'MSFT', 'AMZN'] else 5_000_000
            volume = int(base_volume * np.random.lognormal(0, 0.3))
            
            prices.append({)
                'open': round(open_price, 2),
                'high': round(high_price, 2),
                'low': round(low_price, 2),
                'close': round(current_price, 2),
                'volume': volume
            })
        
        df = pd.DataFrame(prices, index=dates)
        return df


# Test the provider
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    provider = ProductionMarketDataProvider()
    
    print("Production Market Data Provider Test")
    print("=" * 50)
    
    # Test symbols including AMZN
    test_symbols = ['AAPL', 'AMZN', 'GOOGL', 'MSFT', 'TSLA', 'META', 'NVDA', 'SPY']
    
    print("\nCurrent Prices:")
    prices = provider.get_bulk_prices(test_symbols)
    for symbol, price in prices.items():
        expected_range = provider.PRICE_RANGES.get(symbol, (0, 0))
        in_range = expected_range[0] <= price <= expected_range[1]
        print(f"{symbol}: ${price:.2f} (Expected: ${expected_range[0]}-${expected_range[1]}) {'✓' if in_range else '⚠️'}")
    
    print("\nHistorical Data Sample (AMZN last 5 days):")
    hist = provider.get_historical_bars('AMZN', days=5)
    print(hist)