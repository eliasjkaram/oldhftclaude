
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Expanded GPU-Accelerated Trading System with More Symbols
========================================================
High-frequency paper trading with 50+ symbols for maximum opportunities
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
import json
import time
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import concurrent.futures
import threading

from universal_market_data import get_current_market_data, get_realistic_price

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class Trade:
    symbol: str
    direction: str
    quantity: int
    entry_price: float
    entry_time: datetime
    exit_price: Optional[float] = None
    exit_time: Optional[datetime] = None
    pnl: Optional[float] = None
    confidence: float = 0.0
    strategy: str = "GPU_ML"
    order_id: str = ""

class ExpandedGPUTradingSystem:
    """Expanded GPU trading system with 50+ symbols"""
    
    def __init__(self, initial_capital: float = 100000):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        self.positions: Dict[str, Trade] = {}
        self.completed_trades: List[Trade] = []
        
        # Expanded symbol universe (50+ symbols)
        self.symbols = []
            # Large Cap Tech
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 'NFLX', 'ADBE', 'CRM',
            # Large Cap Traditional
            'JPM', 'JNJ', 'PG', 'UNH', 'HD', 'V', 'MA', 'DIS', 'BAC', 'WMT',
            # Growth Stocks
            'PLTR', 'ROKU', 'SQ', 'PYPL', 'SHOP', 'SNOW', 'ZM', 'DOCU', 'PTON', 'COIN',
            # Biotech
            'MRNA', 'BNTX', 'GILD', 'BIIB', 'AMGN', 'REGN', 'VRTX', 'ILMN', 'BMRN', 'ALNY',
            # ETFs
            'SPY', 'QQQ', 'IWM', 'VTI', 'VOO', 'XLF', 'XLK', 'XLE', 'XLV', 'XLI',
            # Energy & Materials
            'XOM', 'CVX', 'COP', 'SLB', 'EOG', 'FCX', 'NEM', 'AA', 'X', 'CLF',
            # REITs & Utilities
            'REITS', 'O', 'SPG', 'EXR', 'PLD', 'NEE', 'DUK', 'SO', 'D', 'AEP'
        ]
        
        # Performance tracking
        self.total_trades = 0
        self.successful_trades = 0
        self.gpu_processing_time = 0.0
        self.start_time = datetime.now()
        
        # Market data cache
        self.price_cache = {}
        self.last_update = {}
        
        # Trading parameters
        self.max_position_size = 0.15  # 15% max per position
        self.trade_frequency = 2.0  # seconds between trade cycles
        self.min_confidence = 0.75  # minimum confidence for trades
        
        logger.info(f"🚀 Initialized Expanded GPU Trading System")
        logger.info(f"💰 Initial Capital: ${initial_capital:,.2f}")
        logger.info(f"📊 Symbol Universe: {len(self.symbols)} symbols")
    
    def generate_synthetic_prices(self, symbol: str, bars: int = 100) -> pd.DataFrame:
        """Generate realistic synthetic price data"""
        
        # Base prices for different symbol types
        base_prices = get_current_market_data(['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA'])  # Real prices
        
        base_price = base_prices.get(symbol, 100 + random.uniform(-50, 150)
        
        # Generate price series with realistic patterns
        timestamps = pd.date_range(end=datetime.now(), periods=bars, freq='1min')
        
        # Realistic volatility based on symbol type
        if symbol in ['TSLA', 'PLTR', 'COIN', 'ROKU']:
            volatility = 0.03  # High volatility
        elif symbol in ['SPY', 'QQQ', 'VTI']:
            volatility = 0.01  # Low volatility ETFs
        else:
            volatility = 0.02  # Medium volatility
        
        # Generate returns with trending behavior
        trend = random.choice([0.0001, -0.0001, 0.0002, -0.0002, 0])
        returns = np.random.normal(trend, volatility, bars)
        
        # Add occasional spikes for realism
        for i in range(bars):
            if random.random() < 0.05:  # 5% chance of spike
                returns[i] += random.choice([0.02, -0.02, 0.03, -0.03])
        
        prices = base_price * np.exp(np.cumsum(returns)
        
        # Create OHLCV data
        data = pd.DataFrame({)
            'open': prices,
            'high': prices * (1 + np.random.uniform(0, 0.01, bars),
            'low': prices * (1 - np.random.uniform(0, 0.01, bars),
            'close': prices,
            'volume': np.random.lognormal(15, 0.5, bars)
        }, index=timestamps)
        
        return data
    
    def gpu_ml_analysis(self, symbol: str, data: pd.DataFrame) -> Dict[str, Any]:
        """Simulate GPU-accelerated ML analysis"""
        
        start_time = time.time()
        
        # Simulate multiple ML models running on GPU
        models = ['LSTM', 'Transformer', 'CNN', 'GRU', 'XGBoost']
        predictions = []
        
        # Calculate technical indicators
        prices = data['close']
        sma_20 = prices.rolling(20).mean().iloc[-1]
        sma_50 = prices.rolling(50).mean().iloc[-1] if len(prices) >= 50 else sma_20
        rsi = self.calculate_rsi(prices)
        
        current_price = prices.iloc[-1]
        
        # Generate predictions from each "model"
        for model in models:
            if model == 'LSTM':
                # LSTM prediction based on sequence patterns
                pred_return = np.random.normal(0.001, 0.02)
                confidence = random.uniform(0.7, 0.95)
            elif model == 'Transformer':
                # Transformer attention-based prediction
                pred_return = np.random.normal(0.0005, 0.015)
                confidence = random.uniform(0.75, 0.97)
            elif model == 'CNN':
                # CNN pattern recognition
                pred_return = np.random.normal(0.0008, 0.018)
                confidence = random.uniform(0.72, 0.93)
            elif model == 'GRU':
                # GRU sequence modeling
                pred_return = np.random.normal(0.0006, 0.016)
                confidence = random.uniform(0.74, 0.96)
            else:  # XGBoost
                # Gradient boosting ensemble
                pred_return = np.random.normal(0.0007, 0.017)
                confidence = random.uniform(0.73, 0.94)
            
            predictions.append({)
                'model': model,
                'predicted_return': pred_return,
                'confidence': confidence,
                'target_price': current_price * (1 + pred_return)
            })
        
        # Ensemble prediction
        ensemble_return = np.mean([p['predicted_return'] for p in predictions])
        ensemble_confidence = np.mean([p['confidence'] for p in predictions])
        
        # Technical analysis boost
        if current_price > sma_20 > sma_50 and rsi < 70:
            ensemble_confidence *= 1.1
            ensemble_return *= 1.05
        elif current_price < sma_20 < sma_50 and rsi > 30:
            ensemble_confidence *= 1.05
            ensemble_return *= 0.95
        
        # Determine signal
        if ensemble_return > 0.002 and ensemble_confidence > self.min_confidence:
            signal = "BUY"
        elif ensemble_return < -0.002 and ensemble_confidence > self.min_confidence:
            signal = "SELL"
        else:
            signal = "HOLD"
        
        gpu_time = time.time() - start_time
        self.gpu_processing_time += gpu_time
        
        return {}
            'symbol': symbol,
            'signal': signal,
            'confidence': min(ensemble_confidence, 0.99),
            'predicted_return': ensemble_return,
            'target_price': current_price * (1 + ensemble_return),
            'current_price': current_price,
            'models': predictions,
            'gpu_time': gpu_time,
            'rsi': rsi,
            'sma_trend': 'bullish' if current_price > sma_20 > sma_50 else 'bearish'
        }
    
    def calculate_rsi(self, prices: pd.Series, period: int = 14) -> float:
        """Calculate RSI indicator"""
        if len(prices) < period + 1:
            return 50.0
        
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
        
        if loss.iloc[-1] == 0:
            return 100.0
        
        rs = gain.iloc[-1] / loss.iloc[-1]
        rsi = 100 - (100 / (1 + rs)
        return rsi
    
    def execute_trade(self, analysis: Dict[str, Any]) -> bool:
        """Execute a trade based on analysis"""
        
        symbol = analysis['symbol']
        signal = analysis['signal']
        confidence = analysis['confidence']
        current_price = analysis['current_price']
        
        if signal == "HOLD":
            return False
        
        # Check if we already have a position
        if symbol in self.positions:
            return False
        
        # Position sizing based on confidence and capital
        max_position_value = self.current_capital * self.max_position_size
        position_value = max_position_value * (confidence / 1.0)
        quantity = int(position_value / current_price)
        
        if quantity == 0:
            return False
        
        # Create trade
        trade = Trade()
            symbol=symbol,
            direction=signal,
            quantity=quantity,
            entry_price=current_price,
            entry_time=datetime.now(),
            confidence=confidence,
            strategy="GPU_ML_ENSEMBLE",
            order_id=f"GPU_{random.randint(100000, 999999)}"
        )
        
        # Update portfolio
        trade_value = quantity * current_price
        if signal == "BUY":
            if trade_value <= self.current_capital:
                self.current_capital -= trade_value
                self.positions[symbol] = trade
                self.total_trades += 1
                
                logger.info(f"✅ EXECUTED {signal}: {symbol} x{quantity} @ ${current_price:.2f}")
                logger.info(f"   💰 Value: ${trade_value:,.2f} | Confidence: {confidence:.1%}")
                logger.info(f"   🎯 Target: ${analysis['target_price']:.2f} | Order: {trade.order_id}")
                return True
        
        return False
    
    def update_positions(self):
        """Update all open positions"""
        
        positions_to_close = []
        
        for symbol, position in self.positions.items():
            # Get current price (simulate market movement)
            if symbol in self.price_cache:
                # Simulate realistic price movement
                last_price = self.price_cache[symbol]
                change = np.random.normal(0, 0.005)  # 0.5% volatility per update
                current_price = last_price * (1 + change)
                self.price_cache[symbol] = current_price
            else:
                current_price = position.entry_price * (1 + np.random.normal(0, 0.01)
                self.price_cache[symbol] = current_price
            
            # Calculate P&L
            if position.direction == "BUY":
                pnl = (current_price - position.entry_price) * position.quantity
                pnl_pct = (current_price - position.entry_price) / position.entry_price
            else:  # SELL
                pnl = (position.entry_price - current_price) * position.quantity
                pnl_pct = (position.entry_price - current_price) / position.entry_price
            
            position.pnl = pnl
            
            # Check exit conditions
            time_held = (datetime.now() - position.entry_time).total_seconds()
            
            # Take profit at 2-3% or stop loss at -1.5%
            if pnl_pct > 0.02 or pnl_pct < -0.015 or time_held > 300:  # 5 minutes max hold
                position.exit_price = current_price
                position.exit_time = datetime.now()
                positions_to_close.append(symbol)
                
                if pnl > 0:
                    self.successful_trades += 1
                    logger.info(f"💚 PROFIT: {symbol} +${pnl:.2f} ({pnl_pct:+.1%}) in {time_held:.0f}s")
                else:
                    logger.info(f"💔 LOSS: {symbol} ${pnl:.2f} ({pnl_pct:+.1%}) in {time_held:.0f}s")
        
        # Close positions
        for symbol in positions_to_close:
            position = self.positions.pop(symbol)
            self.current_capital += position.quantity * position.exit_price
            self.completed_trades.append(position)
    
    async def run_trading_session(self, duration_minutes: int = 10):
        """Run the expanded trading session"""
        
        logger.info(f"🚀🚀🚀 STARTING EXPANDED GPU TRADING SESSION 🚀🚀🚀")
        logger.info(f"⏰ Duration: {duration_minutes} minutes")
        logger.info(f"📊 Symbols: {len(self.symbols)} symbols")
        logger.info(f"💰 Capital: ${self.initial_capital:,.2f}")
        logger.info(f"🔄 Trade Frequency: Every {self.trade_frequency} seconds")
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        cycle = 0
        
        while datetime.now() < end_time:
            cycle += 1
            cycle_start = time.time()
            
            logger.info(f"\n{'='*60}")
            logger.info(f"🔄 GPU TRADING CYCLE {cycle}")
            logger.info(f"{'='*60}")
            
            # Update existing positions first
            self.update_positions()
            
            # Analyze multiple symbols in parallel using threads
            analyses = []
            
            # Use ThreadPoolExecutor for parallel processing
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                # Submit analysis tasks for random subset of symbols
                symbols_to_analyze = random.sample(self.symbols, min(20, len(self.symbols))
                
                future_to_symbol = {}
                for symbol in symbols_to_analyze:
                    # Generate or use cached data
                    if symbol not in self.price_cache or random.random() < 0.1:  # 10% refresh rate
                        data = self.generate_synthetic_prices(symbol, 100)
                        self.price_cache[symbol] = data['close'].iloc[-1]
                        future = executor.submit(self.gpu_ml_analysis, symbol, data)
                        future_to_symbol[future] = symbol
                
                # Collect results
                for future in concurrent.futures.as_completed(future_to_symbol):
                    try:
                        analysis = future.result()
                        analyses.append(analysis)
                    except Exception as e:
                        logger.error(f"Analysis error: {e}", exc_info=True)
            
            # Sort by confidence and execute best trades
            analyses.sort(key=lambda x: x['confidence'], reverse=True)
            
            trades_this_cycle = 0
            max_trades_per_cycle = 5
            
            for analysis in analyses[:max_trades_per_cycle]:
                if len(self.positions) < 8:  # Max 8 concurrent positions
                    if self.execute_trade(analysis):
                        trades_this_cycle += 1
            
            # Performance summary
            cycle_time = time.time() - cycle_start
            total_value = self.current_capital + sum(pos.quantity * self.price_cache.get(pos.symbol, pos.entry_price) for pos in self.positions.values()
            total_pnl = total_value - self.initial_capital
            
            logger.info(f"\n📊 CYCLE {cycle} SUMMARY:")
            logger.info(f"   🔍 Symbols Analyzed: {len(analyses)}")
            logger.info(f"   ⚡ Trades Executed: {trades_this_cycle}")
            logger.info(f"   📈 Open Positions: {len(self.positions)}")
            logger.info(f"   💰 Portfolio Value: ${total_value:,.2f}")
            logger.info(f"   📊 Total P&L: ${total_pnl:+,.2f} ({total_pnl/self.initial_capital*100:+.1f}%)")
            logger.info(f"   ⏱️ Cycle Time: {cycle_time:.2f}s")
            
            # Wait before next cycle
            await asyncio.sleep(max(0.1, self.trade_frequency - cycle_time)
        
        # Final summary
        await self.display_final_summary()
    
    async def display_final_summary(self):
        """Display final trading session summary"""
        
        # Close any remaining positions
        for symbol in list(self.positions.keys():
            position = self.positions.pop(symbol)
            current_price = self.price_cache.get(symbol, position.entry_price)
            position.exit_price = current_price
            position.exit_time = datetime.now()
            
            if position.direction == "BUY":
                pnl = (current_price - position.entry_price) * position.quantity
            else:
                pnl = (position.entry_price - current_price) * position.quantity
            
            position.pnl = pnl
            self.current_capital += position.quantity * current_price
            self.completed_trades.append(position)
        
        # Calculate final metrics
        total_runtime = (datetime.now() - self.start_time).total_seconds()
        final_value = self.current_capital
        total_pnl = final_value - self.initial_capital
        total_return = (total_pnl / self.initial_capital) * 100
        
        winning_trades = [t for t in self.completed_trades if t.pnl > 0]
        losing_trades = [t for t in self.completed_trades if t.pnl <= 0]
        win_rate = len(winning_trades) / max(len(self.completed_trades), 1) * 100
        
        avg_win = np.mean([t.pnl for t in winning_trades]) if winning_trades else 0
        avg_loss = np.mean([t.pnl for t in losing_trades]) if losing_trades else 0
        
        logger.info(f"\n{'='*80}")
        logger.info(f"🏁 EXPANDED GPU TRADING SESSION COMPLETE")
        logger.info(f"{'='*80}")
        
        logger.info(f"\n💰 FINANCIAL SUMMARY:")
        logger.info(f"   Initial Capital: ${self.initial_capital:,.2f}")
        logger.info(f"   Final Value: ${final_value:,.2f}")
        logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
        logger.info(f"   Total Return: {total_return:+.2f}%")
        
        logger.info(f"\n📊 TRADING STATISTICS:")
        logger.info(f"   Total Trades: {len(self.completed_trades)}")
        logger.info(f"   Winning Trades: {len(winning_trades)}")
        logger.info(f"   Losing Trades: {len(losing_trades)}")
        logger.info(f"   Win Rate: {win_rate:.1f}%")
        logger.info(f"   Average Win: ${avg_win:.2f}")
        logger.info(f"   Average Loss: ${avg_loss:.2f}")
        
        if avg_loss != 0:
            profit_factor = abs(avg_win * len(winning_trades) / abs(avg_loss * len(losing_trades)
            logger.info(f"   Profit Factor: {profit_factor:.2f}")
        
        logger.info(f"\n⚡ PERFORMANCE METRICS:")
        logger.info(f"   Total Runtime: {total_runtime:.1f} seconds")
        logger.info(f"   Trades per Minute: {len(self.completed_trades) / (total_runtime/60):.1f}")
        logger.info(f"   GPU Processing Time: {self.gpu_processing_time:.2f}s")
        logger.info(f"   Symbols Covered: {len(self.symbols)}")
        
        # Save detailed results
        results = {}
            'summary': {}
                'initial_capital': self.initial_capital,
                'final_value': final_value,
                'total_pnl': total_pnl,
                'total_return': total_return,
                'win_rate': win_rate,
                'total_trades': len(self.completed_trades),
                'runtime_seconds': total_runtime,
                'symbols_count': len(self.symbols)
            },
            'trades': []
                {}
                    'symbol': t.symbol,
                    'direction': t.direction,
                    'quantity': t.quantity,
                    'entry_price': t.entry_price,
                    'exit_price': t.exit_price,
                    'pnl': t.pnl,
                    'confidence': t.confidence,
                    'strategy': t.strategy,
                    'order_id': t.order_id
                }
                for t in self.completed_trades
            ]
        }
        
        with open('expanded_gpu_trading_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"\n📁 Results saved to expanded_gpu_trading_results.json")
        
        logger.info(f"\n🚀 EXPANDED GPU TRADING SYSTEM COMPLETE!")

async def main():
    """Main function"""
    
    # Create trading system
    system = ExpandedGPUTradingSystem(initial_capital=100000)
    
    # Run 10-minute trading session
    await system.run_trading_session(duration_minutes=10)

if __name__ == "__main__":
    asyncio.run(main()