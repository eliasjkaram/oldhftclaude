#!/usr/bin/env python3
"""
Live Monitoring Demo with Simulated Activity
"""

import os
import time
import random
import threading
from datetime import datetime

def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')

def simulate_trading_activity():
    """Simulate trading activity by writing to log files"""
    symbols = ['AAPL', 'GOOGL', 'TSLA', 'AMZN', 'META', 'NVDA']
    
    # Create log files
    with open('production_trading.log', 'a') as f:
        f.write(f"\n[{datetime.now()}] Trading system started\n")
    
    for i in range(10):
        time.sleep(2)
        
        # Simulate trade
        symbol = random.choice(symbols)
        action = random.choice(['BUY', 'SELL'])
        quantity = random.randint(10, 100)
        price = round(random.uniform(100, 500), 2)
        pnl = round(random.uniform(-500, 2000), 2)
        
        # Write to trading log
        with open('production_trading.log', 'a') as f:
            f.write(f"[{datetime.now()}] EXECUTED: {action} {quantity} {symbol} @ ${price} - P&L: ${pnl}\n")
        
        # Simulate AI discovery
        if random.random() > 0.5:
            strategy = random.choice(['Cross-Exchange', 'Delta-Neutral', 'Volatility Arbitrage'])
            confidence = round(random.uniform(0.75, 0.95), 2)
            profit = round(random.uniform(1000, 5000), 2)
            
            with open('ai_arbitrage.log', 'a') as f:
                f.write(f"[{datetime.now()}] AI DISCOVERY: {symbol} {strategy} - Expected: ${profit} (Confidence: {confidence})\n")

def display_live_monitor():
    """Display live monitoring dashboard"""
    start_time = time.time()
    
    while time.time() - start_time < 30:  # Run for 30 seconds
        clear_screen()
        
        print("╔" + "═" * 98 + "╗")
        print("║" + " " * 30 + "LIVE MONITORING DASHBOARD" + " " * 43 + "║")
        print("╠" + "═" * 98 + "╣")
        print(f"║ 🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}" + " " * 76 + "║")
        print("╠" + "═" * 98 + "╣")
        
        # Show recent trades
        print("║ RECENT TRADES" + " " * 84 + "║")
        print("║" + " " * 98 + "║")
        
        try:
            with open('production_trading.log', 'r') as f:
                lines = f.readlines()
                recent_trades = [l.strip() for l in lines[-5:] if 'EXECUTED' in l]
                
                for trade in recent_trades:
                    # Extract key info
                    if 'P&L: $' in trade:
                        parts = trade.split('] ', 1)[1] if '] ' in trade else trade
                        display = parts[:90] if len(parts) > 90 else parts
                        print(f"║   {display:<93} ║")
                
                if not recent_trades:
                    print("║   Waiting for trades..." + " " * 74 + "║")
        except:
            print("║   No trading activity yet..." + " " * 69 + "║")
        
        print("╠" + "═" * 98 + "╣")
        
        # Show AI discoveries
        print("║ AI DISCOVERIES" + " " * 83 + "║")
        print("║" + " " * 98 + "║")
        
        try:
            with open('ai_arbitrage.log', 'r') as f:
                lines = f.readlines()
                discoveries = [l.strip() for l in lines[-3:] if 'DISCOVERY' in l]
                
                for discovery in discoveries:
                    if 'AI DISCOVERY' in discovery:
                        parts = discovery.split('] ', 1)[1] if '] ' in discovery else discovery
                        display = parts[:90] if len(parts) > 90 else parts
                        print(f"║   {display:<93} ║")
                
                if not discoveries:
                    print("║   Scanning for opportunities..." + " " * 66 + "║")
        except:
            print("║   No AI discoveries yet..." + " " * 71 + "║")
        
        print("╠" + "═" * 98 + "╣")
        
        # Show statistics
        print("║ LIVE STATISTICS" + " " * 82 + "║")
        print("║" + " " * 98 + "║")
        
        # Count trades and calculate P&L
        total_trades = 0
        total_pnl = 0.0
        
        try:
            with open('production_trading.log', 'r') as f:
                for line in f:
                    if 'EXECUTED' in line and 'P&L: $' in line:
                        total_trades += 1
                        try:
                            pnl = float(line.split('P&L: $')[1].split()[0])
                            total_pnl += pnl
                        except:
                            pass
        except:
            pass
        
        print(f"║   Total Trades: {total_trades:<20} Total P&L: ${total_pnl:,.2f}" + " " * (98 - 45 - len(f"{total_pnl:,.2f}")) + "║")
        print(f"║   Average P&L: ${total_pnl/max(total_trades, 1):,.2f}" + " " * (98 - 20 - len(f"{total_pnl/max(total_trades, 1):,.2f}")) + "║")
        print("║" + " " * 98 + "║")
        
        print("╚" + "═" * 98 + "╝")
        
        print("\n🔄 Monitoring live trading activity... (Press Ctrl+C to stop)")
        print("📊 Trades and AI discoveries appear here as they happen!")
        
        time.sleep(1)  # Update every second

def main():
    """Run live monitoring demo"""
    print("Starting live monitoring demonstration...")
    print("This will simulate trading activity and show real-time monitoring.")
    print("")
    
    # Start background thread to simulate activity
    activity_thread = threading.Thread(target=simulate_trading_activity)
    activity_thread.daemon = True
    activity_thread.start()
    
    # Give it a moment to start
    time.sleep(1)
    
    # Run the monitor
    try:
        display_live_monitor()
    except KeyboardInterrupt:
        print("\n\nMonitoring stopped.")
    
    print("\n✅ Monitoring demonstration complete!")
    print("📝 Check these files for the activity logs:")
    print("   - production_trading.log")
    print("   - ai_arbitrage.log")

if __name__ == "__main__":
    main()