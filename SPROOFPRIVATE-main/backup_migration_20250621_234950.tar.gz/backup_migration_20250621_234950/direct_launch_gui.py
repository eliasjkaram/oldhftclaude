#!/usr/bin/env python3
"""
Direct Launch GUI - No Interactive Prompts
==========================================

Launches the complete trading GUI directly without interactive prompts.
"""

import sys
import os

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))

def main():
    """Direct launch without prompts"""
    print("🚀 Launching AI-Enhanced Trading System - Fully Integrated GUI")
    print("=" * 70)
    
    try:
        from fully_integrated_gui import FullyIntegratedTradingGUI
        import tkinter as tk
        
        # Create root window
        root = tk.Tk()
        
        # Set window properties
        root.title("AI-Enhanced Trading System - Fully Integrated")
        root.geometry("1400x900")
        
        # Center window on screen
        root.update_idletasks()
        x = (root.winfo_screenwidth() // 2) - (1400 // 2)
        y = (root.winfo_screenheight() // 2) - (900 // 2)
        root.geometry(f"1400x900+{x}+{y}")
        
        # Create application
        print("✓ Initializing trading system...")
        app = FullyIntegratedTradingGUI(root)
        
        # Configure style
        try:
            style = tk.ttk.Style()
            available_themes = style.theme_names()
            if 'clam' in available_themes:
                style.theme_use('clam')
            elif 'alt' in available_themes:
                style.theme_use('alt')
        except Exception:
            pass
        
        print("✅ GUI LAUNCHED SUCCESSFULLY!")
        print("\n🎉 ALL PLACEHOLDER FUNCTIONS HAVE BEEN IMPLEMENTED!")
        print("\nFeatures Now Available:")
        print("• Portfolio optimization with Modern Portfolio Theory")
        print("• Options trading with real spread execution")
        print("• Risk management with VaR and stress testing")  
        print("• Machine learning predictions with GPU acceleration")
        print("• Advanced backtesting with Monte Carlo simulation")
        print("• Sentiment analysis from URLs and text")
        print("• Real-time market data with Alpaca integration")
        print("• Comprehensive system monitoring and reporting")
        print("• Current options chains (not hardcoded 2024 dates)")
        print("• Symbol autosuggestion with 50+ popular symbols")
        print("\n🔥 EVERY BUTTON NOW PERFORMS REAL OPERATIONS!")
        print("=" * 70)
        
        # Start GUI
        root.mainloop()
        
        return True
        
    except ImportError as e:
        print(f"❌ Import Error: {e}")
        print("\nMissing components. Please ensure all files are present:")
        print("  - fully_integrated_gui.py")
        print("  - complete_gui_backend.py")
        print("  - All enhanced trading system components")
        return False
    except Exception as e:
        print(f"❌ Launch Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    main()