
#!/usr/bin/env python3
"""
Enhanced AI Arbitrage Demo
Comprehensive testing and demonstration of enhanced AI capabilities without external dependencies
"""

# Alpaca imports
from typing import Dict, List, Optional, Tuple
import sys
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import json
import numpy as np
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum
import logging
from collections import defaultdict, deque
import traceback
import re

from universal_market_data import get_current_market_data, validate_price


# Configure enhanced logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Enhanced configuration
CONFIG = {}
    "max_retries": 3,
    "retry_delay": 1.0,
    "timeout_seconds": 30,
    "max_concurrent_requests": 5,
    "rate_limit_delay": 0.1,
    "fallback_enabled": True,
    "validation_threshold": 0.75,
    "confidence_threshold": 0.7,
    "circuit_breaker_threshold": 5,
    "circuit_breaker_timeout": 300
}


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class LLMModel(Enum):
    """Enhanced LLM models with metadata"""
    # Tier 1: High-performance models
    DEEPSEEK_R1 = ("deepseek/deepseek-r1:free", 1, "complex_reasoning", 0.95)
    DEEPSEEK_V3 = ("deepseek/deepseek-chat:free", 1, "general_analysis", 0.90) 
    GEMINI_2_0_FLASH = ("google/gemini-2.0-flash-exp:free", 1, "fast_inference", 0.85)
    
    # Tier 2: Specialized models  
    LLAMA_3_3_70B = ("meta-llama/llama-3.3-70b-instruct:free", 2, "strategy_optimization", 0.80)
    LLAMA_4_MAVERICK = ("meta-llama/llama-4-maverick:free", 2, "innovation", 0.85)
    LLAMA_4_SCOUT = ("meta-llama/llama-4-scout:free", 2, "exploration", 0.80)
    
    # Tier 3: Backup models
    DEEPSEEK_R1_ZERO = ("deepseek/deepseek-r1-zero:free", 3, "fast_reasoning", 0.75)
    DEEPSEEK_PROVER = ("deepseek/deepseek-prover-v2:free", 3, "mathematical_proof", 0.90)
    QWEN_VL_72B = ("qwen/qwen2.5-vl-72b-instruct:free", 3, "data_analysis", 0.80)
    
    @property
    def model_id(self) -> str:
        return self.value[0]
    
    @property
    def priority(self) -> int:
        return self.value[1]
    
    @property
    def specialty(self) -> str:
        return self.value[2]
    
    @property
    def reliability(self) -> float:
        return self.value[3]

class ArbitrageType(Enum):
    """Extended arbitrage types with enhanced categorization"""
    # Traditional arbitrage
    CONVERSION = "conversion"
    REVERSAL = "reversal"
    BOX_SPREAD = "box_spread"
    SYNTHETIC_INSTRUMENTS = "synthetic_instruments"
    
    # Cross-market arbitrage
    CROSS_EXCHANGE = "cross_exchange"
    CURRENCY_ARBITRAGE = "currency_arbitrage"
    INTEREST_RATE_ARBITRAGE = "interest_rate_arbitrage"
    ETF_CONSTITUENT = "etf_constituent"
    
    # Volatility arbitrage
    VOLATILITY_SURFACE = "volatility_surface"
    SKEW_ARBITRAGE = "skew_arbitrage"
    CALENDAR_ARBITRAGE = "calendar_arbitrage"
    TERM_STRUCTURE = "term_structure"
    
    # Statistical arbitrage
    PAIRS_TRADING = "pairs_trading"
    MOMENTUM_ARBITRAGE = "momentum_arbitrage"
    MEAN_REVERSION = "mean_reversion"
    COINTEGRATION = "cointegration"
    
    # Advanced strategies
    DELTA_NEUTRAL = "delta_neutral"
    GAMMA_SCALPING = "gamma_scalping"
    THETA_DECAY = "theta_decay"
    VEGA_NEUTRAL = "vega_neutral"
    
    # AI-discovered patterns
    PATTERN_RECOGNITION = "pattern_recognition"
    ANOMALY_DETECTION = "anomaly_detection"
    CORRELATION_BREAKDOWN = "correlation_breakdown"
    REGIME_CHANGE = "regime_change"
    MARKET_MICROSTRUCTURE = "market_microstructure"
    BEHAVIORAL_ARBITRAGE = "behavioral_arbitrage"

@dataclass
class ValidationMetrics:
    """Enhanced validation metrics"""
    consensus_score: float = 0.0
    agreement_score: float = 0.0
    confidence_interval: Tuple[float, float] = (0.0, 0.0)
    validation_models: List[str] = field(default_factory=list)
    risk_score: float = 0.0
    feasibility_score: float = 0.0
    mathematical_validity: float = 0.0

@dataclass
class EnhancedArbitrageOpportunity:
    """Enhanced arbitrage opportunity with comprehensive validation"""
    arbitrage_type: ArbitrageType
    underlying_assets: List[str]
    strategy_description: str
    expected_profit: float
    confidence_score: float
    risk_assessment: str
    execution_complexity: str
    time_horizon: str
    market_conditions: str
    ai_reasoning: str
    discovered_by_model: str
    
    # Enhanced validation
    validation_metrics: ValidationMetrics = field(default_factory=ValidationMetrics)
    
    # Financial metrics
    sharpe_ratio: float = 0.0
    max_drawdown: float = 0.0
    probability_success: float = 0.0
    capital_required: float = 0.0
    liquidity_requirements: str = "Medium"
    
    # Execution details
    entry_signals: List[str] = field(default_factory=list)
    exit_signals: List[str] = field(default_factory=list)
    risk_management: List[str] = field(default_factory=list)
    monitoring_parameters: Dict[str, Any] = field(default_factory=dict)
    
    # Metadata
    discovery_timestamp: datetime = field(default_factory=datetime.now)
    validation_timestamp: Optional[datetime] = None
    error_flags: List[str] = field(default_factory=list)
    enhancement_suggestions: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Enhanced validation on creation"""
        self._validate_comprehensive()
    
    def _validate_comprehensive(self):
        """Comprehensive validation with detailed checks"""
        errors = []
        warnings = []
        
        # Data validation
        if not self.underlying_assets:
            errors.append("underlying_assets cannot be empty")
        if not self.strategy_description or len(self.strategy_description) < 10:
            errors.append("strategy_description must be meaningful")
        if self.expected_profit <= 0:
            errors.append("expected_profit must be positive")
        if not 0 <= self.confidence_score <= 1:
            errors.append("confidence_score must be between 0 and 1")
        
        # Business logic validation
        if self.expected_profit > 500000:  # $500K threshold
            warnings.append("expected_profit seems very high")
        if self.capital_required < 0:
            errors.append("capital_required cannot be negative")
        if self.confidence_score < CONFIG["confidence_threshold"]:
            warnings.append("confidence_score below system threshold")
        
        # Risk assessment validation
        risk_levels = ["Very Low", "Low", "Medium", "High", "Very High"]
        if self.risk_assessment not in risk_levels:
            warnings.append(f"risk_assessment should be one of: {risk_levels}")
        
        # Complexity validation
        complexity_levels = ["Easy", "Medium", "Hard", "Very Hard"]
        if self.execution_complexity not in complexity_levels:
            warnings.append(f"execution_complexity should be one of: {complexity_levels}")
        
        self.error_flags = errors
        if warnings:
            self.error_flags.extend([f"warning: {w}" for w in warnings])
        
        if errors:
            logging.warning(f"Validation errors: {errors}")
        if warnings:
            logging.info(f"Validation warnings: {warnings}")

class PerformanceTracker:
    """Enhanced performance tracking and monitoring"""
    
    def __init__(self):
        self.model_performance = defaultdict(lambda: {)
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "avg_response_time": 0.0,
            "avg_confidence": 0.0,
            "last_success": None,
            "circuit_breaker_triggered": False,
            "specialty_score": 0.0
        })
        
        self.system_metrics = {}
            "total_opportunities": 0,
            "validated_opportunities": 0,
            "high_confidence_opportunities": 0,
            "total_profit_potential": 0.0,
            "avg_validation_score": 0.0,
            "discovery_rate": 0.0,
            "error_rate": 0.0
        }
        
        self.error_log = deque(maxlen=1000)
        self.performance_history = deque(maxlen=100)
        
    def record_model_request(self, model: LLMModel, success: bool, 
                           response_time: float = 0.0, confidence: float = 0.0):
        """Record model request metrics"""
        perf = self.model_performance[model]
        perf["total_requests"] += 1
        
        if success:
            perf["successful_requests"] += 1
            perf["last_success"] = datetime.now()
            
            # Update rolling averages
            if perf["avg_response_time"] == 0:
                perf["avg_response_time"] = response_time
            else:
                perf["avg_response_time"] = (perf["avg_response_time"] + response_time) / 2
                
            if confidence > 0:
                if perf["avg_confidence"] == 0:
                    perf["avg_confidence"] = confidence
                else:
                    perf["avg_confidence"] = (perf["avg_confidence"] + confidence) / 2
        else:
            perf["failed_requests"] += 1
    
    def record_opportunity(self, opportunity: EnhancedArbitrageOpportunity):
        """Record opportunity metrics"""
        self.system_metrics["total_opportunities"] += 1
        self.system_metrics["total_profit_potential"] += opportunity.expected_profit
        
        if opportunity.validation_metrics.consensus_score >= CONFIG["validation_threshold"]:
            self.system_metrics["validated_opportunities"] += 1
            
        if opportunity.confidence_score >= 0.8:
            self.system_metrics["high_confidence_opportunities"] += 1
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary"""
        summary = {}
            "model_performance": {},
            "system_metrics": self.system_metrics.copy(),
            "top_performing_models": [],
            "recommendations": []
        }
        
        # Model performance analysis
        for model, perf in self.model_performance.items():
            if perf["total_requests"] > 0:
                success_rate = perf["successful_requests"] / perf["total_requests"]
                summary["model_performance"][model.name] = {}
                    "success_rate": success_rate,
                    "avg_response_time": perf["avg_response_time"],
                    "avg_confidence": perf["avg_confidence"],
                    "specialty": model.specialty,
                    "total_requests": perf["total_requests"]
                }
        
        # Top performing models
        sorted_models = sorted()
            self.model_performance.items(),
            key=lambda x: x[1]["successful_requests"] / max(1, x[1]["total_requests"]),
            reverse=True
        )
        summary["top_performing_models"] = [(model.name, perf) for model, perf in sorted_models[:3]]
        
        # Generate recommendations
        summary["recommendations"] = self._generate_recommendations()
        
        return summary
    
    def _generate_recommendations(self) -> List[str]:
        """Generate performance improvement recommendations"""
        recommendations = []
        
        total_requests = sum(perf["total_requests"] for perf in self.model_performance.values()
        if total_requests == 0:
            return ["No requests recorded yet"]
        
        # Success rate analysis
        avg_success_rate = sum()
            perf["successful_requests"] / max(1, perf["total_requests"]) 
            for perf in self.model_performance.values()
        ) / len(self.model_performance)
        
        if avg_success_rate < 0.8:
            recommendations.append("Consider implementing additional error handling")
        
        # Validation analysis
        if self.system_metrics["total_opportunities"] > 0:
            validation_rate = (self.system_metrics["validated_opportunities"] /)
                             self.system_metrics["total_opportunities"])
            if validation_rate < 0.6:
                recommendations.append("Review validation criteria - validation rate is low")
        
        # Model specialization
        recommendations.append("Consider routing requests based on model specialties")
        
        return recommendations

class EnhancedAIAgent:
    """Enhanced AI agent with comprehensive testing and validation"""
    
    def __init__(self):
        self.performance_tracker = PerformanceTracker()
        self.discovered_opportunities = deque(maxlen=1000)
        self.validation_cache = {}
        self.circuit_breakers = defaultdict(lambda: {)
            "failures": 0, "last_failure": None, "is_open": False
        })
        
        # Enhanced AI simulation
        self.ai_models = {}
            model: {}
                "specialty_performance": np.self.get_price_in_range(0.7, 0.95),
                "general_performance": np.self.get_price_in_range(0.6, 0.8),
                "reliability": model.reliability,
                "response_patterns": self._generate_response_patterns(model)
            }
            for model in LLMModel
        }
        
        self.logger = logging.getLogger(__name__)
        self.logger.info("Enhanced AI Agent initialized with comprehensive monitoring")
    
    def _generate_response_patterns(self, model: LLMModel) -> Dict[str, Any]:
        """Generate realistic response patterns for each model"""
        patterns = {}
            "response_quality": np.self.get_price_in_range(0.7, 0.95),
            "creativity_level": np.self.get_price_in_range(0.5, 1.0),
            "mathematical_accuracy": np.self.get_price_in_range(0.6, 0.95),
            "market_insight": np.self.get_price_in_range(0.6, 0.9),
            "typical_response_time": np.self.get_price_in_range(0.5, 3.0)
        }
        
        # Adjust based on model specialty
        if "reasoning" in model.specialty:
            patterns["mathematical_accuracy"] += 0.1
        elif "innovation" in model.specialty:
            patterns["creativity_level"] += 0.15
        elif "analysis" in model.specialty:
            patterns["market_insight"] += 0.1
        
        return patterns
    
    async def initialize(self):
        """Initialize with comprehensive health checks"""
        self.logger.info("🚀 Initializing Enhanced AI Agent...")
        
        # Simulate health checks
        for model in list(LLMModel)[:3]:  # Test first 3 models
            await self._simulate_health_check(model)
        
        self.logger.info("✅ Enhanced AI Agent initialized successfully")
    
    async def _simulate_health_check(self, model: LLMModel):
        """Simulate health check for model"""
        self.logger.info(f"🔍 Health check: {model.name}")
        
        # Simulate API call
        await asyncio.sleep(0.1)  # Simulate network delay
        
        # Simulate success/failure based on model reliability
        success = np.self.get_market_data() < model.reliability
        response_time = np.self.get_price_in_range(0.2, 1.0)
        
        self.performance_tracker.record_model_request(model, success, response_time)
        
        if success:
            self.logger.info(f"  ✅ {model.name} health check passed")
        else:
            self.logger.warning(f"  ⚠️  {model.name} health check failed")
    
    async def discover_arbitrage_opportunities(self, market_data: Dict[str, Any]) -> List[EnhancedArbitrageOpportunity]:
        """Enhanced arbitrage discovery with comprehensive analysis"""
        
        self.logger.info("🔍 Starting enhanced arbitrage discovery...")
        start_time = time.time()
        
        opportunities = []
        
        # Enhanced analysis tasks with model specialization
        analysis_tasks = []
            ("cross_market", ArbitrageType.CROSS_EXCHANGE, LLMModel.GEMINI_2_0_FLASH),
            ("volatility", ArbitrageType.VOLATILITY_SURFACE, LLMModel.DEEPSEEK_R1),
            ("statistical", ArbitrageType.PAIRS_TRADING, LLMModel.LLAMA_3_3_70B),
            ("options", ArbitrageType.DELTA_NEUTRAL, LLMModel.DEEPSEEK_PROVER),
            ("novel", ArbitrageType.PATTERN_RECOGNITION, LLMModel.LLAMA_4_MAVERICK),
            ("correlation", ArbitrageType.CORRELATION_BREAKDOWN, LLMModel.QWEN_VL_72B),
            ("behavioral", ArbitrageType.BEHAVIORAL_ARBITRAGE, LLMModel.LLAMA_4_SCOUT),
            ("microstructure", ArbitrageType.MARKET_MICROSTRUCTURE, LLMModel.DEEPSEEK_V3)
        ]
        
        # Execute analysis tasks
        for task_name, arb_type, model in analysis_tasks:
            try:
                self.logger.info(f"  🔬 Analyzing {task_name} with {model.name}")
                
                task_opportunities = await self._simulate_analysis()
                    task_name, arb_type, model, market_data
                )
                
                if task_opportunities:
                    opportunities.extend(task_opportunities)
                    self.logger.info(f"    ✅ Found {len(task_opportunities)} opportunities")
                else:
                    self.logger.info(f"    📊 No opportunities in {task_name}")
                
            except Exception as e:
                self.logger.error(f"    ❌ {task_name} analysis failed: {e}")
        
        # Enhanced validation
        if opportunities:
            validated_opportunities = await self._enhanced_validation(opportunities)
            
            discovery_time = time.time() - start_time
            self.logger.info(f"🎯 Discovery complete: {len(validated_opportunities)}/{len(opportunities)} ")
                           f"validated in {discovery_time:.2f}s")
            
            # Update system metrics
            self.performance_tracker.system_metrics["discovery_rate"] = len(validated_opportunities) / discovery_time
            
            return validated_opportunities
        
        return []
    
    async def _simulate_analysis(self, task_name: str, arb_type: ArbitrageType, 
                               model: LLMModel, market_data: Dict[str, Any]) -> List[EnhancedArbitrageOpportunity]:
        """Simulate AI analysis with realistic patterns"""
        
        # Check circuit breaker
        if self._is_circuit_breaker_open(model):
            self.logger.warning(f"Circuit breaker open for {model.name}")
            return []
        
        # Simulate analysis time
        analysis_time = self.ai_models[model]["response_patterns"]["typical_response_time"]
        await asyncio.sleep(analysis_time * 0.1)  # Scaled for demo
        
        # Simulate success/failure
        success_probability = ()
            self.ai_models[model]["specialty_performance"] 
            if task_name in model.specialty 
            else self.ai_models[model]["general_performance"]
        )
        
        success = np.self.get_market_data() < success_probability
        self.performance_tracker.record_model_request(model, success, analysis_time)
        
        if not success:
            self._record_circuit_breaker_failure(model)
            return []
        
        # Generate opportunities based on market conditions and model capabilities
        num_opportunities = self._calculate_opportunity_count(task_name, market_data, model)
        opportunities = []
        
        for i in range(num_opportunities):
            opportunity = self._generate_enhanced_opportunity()
                task_name, arb_type, model, market_data, i
            )
            opportunities.append(opportunity)
            self.performance_tracker.record_opportunity(opportunity)
        
        return opportunities
    
    def _calculate_opportunity_count(self, task_name: str, market_data: Dict[str, Any], 
                                   model: LLMModel) -> int:
        """Calculate realistic number of opportunities based on conditions"""
        
        base_count = {}
            "cross_market": 2,
            "volatility": 1,
            "statistical": 3,
            "options": 1,
            "novel": 1,
            "correlation": 2,
            "behavioral": 1,
            "microstructure": 1
        }.get(task_name, 1)
        
        # Adjust based on market conditions
        market_conditions = market_data.get('_market_conditions', {})
        volatility = market_conditions.get('volatility', 'medium')
        
        if volatility == 'high':
            base_count = int(base_count * 1.5)
        elif volatility == 'low':
            base_count = max(1, int(base_count * 0.7)
        
        # Adjust based on model performance
        model_multiplier = self.ai_models[model]["specialty_performance"]
        final_count = max(0, int(base_count * model_multiplier)
        
        # Add randomness
        if np.self.get_market_data() < 0.3:  # 30% chance of no opportunities
            return 0
        
        return final_count
    
    def _generate_enhanced_opportunity(self, task_name: str, arb_type: ArbitrageType,
                                     model: LLMModel, market_data: Dict[str, Any], 
                                     index: int) -> EnhancedArbitrageOpportunity:
        """Generate realistic enhanced opportunity"""
        
        # Get available symbols
        symbols = [k for k in market_data.keys() if k != '_market_conditions']
        selected_assets = np.random.choice(symbols, size=min(3, len(symbols), replace=False).tolist()
        
        # Generate realistic metrics based on arbitrage type
        profit_ranges = {}
            ArbitrageType.CROSS_EXCHANGE: (500, 5000),
            ArbitrageType.VOLATILITY_SURFACE: (800, 3000),
            ArbitrageType.PAIRS_TRADING: (1200, 4000),
            ArbitrageType.DELTA_NEUTRAL: (600, 2500),
            ArbitrageType.PATTERN_RECOGNITION: (2000, 8000),
            ArbitrageType.CORRELATION_BREAKDOWN: (1500, 6000)
        }
        
        profit_range = profit_ranges.get(arb_type, (300, 2000)
        expected_profit = self.get_uniform_prices(*profit_range)
        
        # Model-specific confidence adjustment
        base_confidence = np.self.get_price_in_range(0.6, 0.9)
        model_quality = self.ai_models[model]["response_patterns"]["response_quality"]
        confidence_score = min(0.95, base_confidence * model_quality)
        
        # Generate comprehensive opportunity
        opportunity = EnhancedArbitrageOpportunity()
            arbitrage_type=arb_type,
            underlying_assets=selected_assets,
            strategy_description=self._generate_strategy_description(task_name, arb_type, selected_assets),
            expected_profit=expected_profit,
            confidence_score=confidence_score,
            risk_assessment=self._assess_risk_level(arb_type, expected_profit),
            execution_complexity=self._assess_complexity(arb_type),
            time_horizon=self._determine_time_horizon(arb_type),
            market_conditions=self._summarize_market_conditions(market_data),
            ai_reasoning=self._generate_ai_reasoning(task_name, arb_type, model),
            discovered_by_model=model.name,
            sharpe_ratio=np.self.get_price_in_range(1.5, 3.5),
            max_drawdown=np.self.get_price_in_range(0.02, 0.12),
            probability_success=confidence_score * np.self.get_price_in_range(0.8, 1.0),
            capital_required=expected_profit * np.self.get_price_in_range(10, 50),
            liquidity_requirements=self._assess_liquidity_requirements(arb_type),
            entry_signals=self._generate_entry_signals(arb_type),
            exit_signals=self._generate_exit_signals(arb_type),
            risk_management=self._generate_risk_management(arb_type),
            monitoring_parameters=self._generate_monitoring_parameters(arb_type)
        )
        
        return opportunity
    
    def _generate_strategy_description(self, task_name: str, arb_type: ArbitrageType, 
                                     assets: List[str]) -> str:
        """Generate realistic strategy description"""
        descriptions = {}
            "cross_market": f"Cross-market arbitrage opportunity between {'/'.join(assets)} exploiting price discrepancies across exchanges",
            "volatility": f"Volatility arbitrage in {assets[0]} using options surface inefficiencies",
            "statistical": f"Statistical arbitrage pair trade between {assets[0]} and {assets[1] if len(assets) > 1 else 'market'}",
            "options": f"Options mispricing arbitrage in {assets[0]} exploiting theoretical vs market price divergence",
            "novel": f"Novel pattern recognition arbitrage using AI-detected market inefficiencies in {'/'.join(assets[:2])}",
            "correlation": f"Correlation breakdown arbitrage between {assets[0]} and sector ETF",
            "behavioral": f"Behavioral arbitrage exploiting sentiment vs price action divergence in {assets[0]}",
            "microstructure": f"Market microstructure arbitrage using liquidity provision inefficiencies in {assets[0]}"
        }
        
        return descriptions.get(task_name, f"Advanced arbitrage strategy in {'/'.join(assets)}")
    
    def _assess_risk_level(self, arb_type: ArbitrageType, profit: float) -> str:
        """Assess risk level based on arbitrage type and profit"""
        risk_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: "Low",
            ArbitrageType.DELTA_NEUTRAL: "Low",
            ArbitrageType.VOLATILITY_SURFACE: "Medium",
            ArbitrageType.PAIRS_TRADING: "Medium",
            ArbitrageType.PATTERN_RECOGNITION: "High",
            ArbitrageType.BEHAVIORAL_ARBITRAGE: "High"
        }
        
        base_risk = risk_mapping.get(arb_type, "Medium")
        
        # Adjust for profit level
        if profit > 5000:
            risk_levels = ["Low", "Medium", "High", "Very High"]
            current_index = risk_levels.index(base_risk)
            return risk_levels[min(len(risk_levels) - 1, current_index + 1)]
        
        return base_risk
    
    def _assess_complexity(self, arb_type: ArbitrageType) -> str:
        """Assess execution complexity"""
        complexity_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: "Medium",
            ArbitrageType.DELTA_NEUTRAL: "Hard",
            ArbitrageType.VOLATILITY_SURFACE: "Hard",
            ArbitrageType.PAIRS_TRADING: "Medium",
            ArbitrageType.PATTERN_RECOGNITION: "Very Hard",
            ArbitrageType.BEHAVIORAL_ARBITRAGE: "Hard"
        }
        
        return complexity_mapping.get(arb_type, "Medium")
    
    def _determine_time_horizon(self, arb_type: ArbitrageType) -> str:
        """Determine optimal time horizon"""
        horizon_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: "Intraday",
            ArbitrageType.DELTA_NEUTRAL: "Short-term",
            ArbitrageType.VOLATILITY_SURFACE: "Medium-term",
            ArbitrageType.PAIRS_TRADING: "Medium-term",
            ArbitrageType.PATTERN_RECOGNITION: "Variable",
            ArbitrageType.BEHAVIORAL_ARBITRAGE: "Short-term"
        }
        
        return horizon_mapping.get(arb_type, "Short-term")
    
    def _generate_ai_reasoning(self, task_name: str, arb_type: ArbitrageType, 
                             model: LLMModel) -> str:
        """Generate AI reasoning explanation"""
        reasoning_templates = {}
            "cross_market": f"AI model {model.name} detected price inefficiencies across multiple exchanges. Mathematical analysis indicates profit opportunity with high probability.",
            "volatility": f"Advanced volatility modeling by {model.name} identified surface distortions. Options pricing models show significant mispricing.",
            "statistical": f"Statistical analysis by {model.name} detected correlation breakdown. Mean reversion patterns suggest high-probability opportunity.",
            "options": f"Mathematical validation by {model.name} confirmed options mispricing. Greeks analysis supports arbitrage viability.",
            "novel": f"Creative pattern recognition by {model.name} discovered unprecedented market inefficiency. Innovation engine identified exploitable pattern.",
            "correlation": f"Correlation analysis by {model.name} detected significant relationship breakdown. Historical patterns suggest reversion opportunity."
        }
        
        return reasoning_templates.get(task_name, f"AI analysis by {model.name} identified arbitrage opportunity through advanced pattern recognition.")
    
    def _assess_liquidity_requirements(self, arb_type: ArbitrageType) -> str:
        """Assess liquidity requirements"""
        liquidity_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: "High",
            ArbitrageType.DELTA_NEUTRAL: "High",
            ArbitrageType.VOLATILITY_SURFACE: "Medium",
            ArbitrageType.PAIRS_TRADING: "Medium",
            ArbitrageType.PATTERN_RECOGNITION: "Variable",
            ArbitrageType.BEHAVIORAL_ARBITRAGE: "Medium"
        }
        
        return liquidity_mapping.get(arb_type, "Medium")
    
    def _generate_entry_signals(self, arb_type: ArbitrageType) -> List[str]:
        """Generate entry signals"""
        signals_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: ["Price divergence > 0.1%", "Volume confirmation", "Liquidity check"],
            ArbitrageType.VOLATILITY_SURFACE: ["IV rank > 80%", "Skew anomaly detected", "Calendar spread setup"],
            ArbitrageType.PAIRS_TRADING: ["Z-score > 2.0", "Correlation < 0.5", "Volume spike"],
            ArbitrageType.DELTA_NEUTRAL: ["Pricing discrepancy > 5%", "Greeks imbalance", "Volatility edge"],
            ArbitrageType.PATTERN_RECOGNITION: ["Pattern confirmation", "ML confidence > 80%", "Backtest validation"],
            ArbitrageType.CORRELATION_BREAKDOWN: ["Correlation < 0.6", "Sector divergence", "Statistical significance"]
        }
        
        return signals_mapping.get(arb_type, ["AI signal confirmed", "Risk parameters met"])
    
    def _generate_exit_signals(self, arb_type: ArbitrageType) -> List[str]:
        """Generate exit signals"""
        signals_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: ["Convergence < 0.02%", "Time stop 4 hours", "Volume decline"],
            ArbitrageType.VOLATILITY_SURFACE: ["IV reversion", "Profit target 200%", "Greeks rebalance"],
            ArbitrageType.PAIRS_TRADING: ["Z-score < 0.5", "Time stop 14 days", "Correlation recovery"],
            ArbitrageType.DELTA_NEUTRAL: ["Convergence achieved", "Greeks neutral", "Profit target hit"],
            ArbitrageType.PATTERN_RECOGNITION: ["Pattern breakdown", "ML exit signal", "Risk limit hit"],
            ArbitrageType.CORRELATION_BREAKDOWN: ["Correlation > 0.8", "Time stop", "Sector convergence"]
        }
        
        return signals_mapping.get(arb_type, ["Profit target", "Time stop", "Risk limit"])
    
    def _generate_risk_management(self, arb_type: ArbitrageType) -> List[str]:
        """Generate risk management rules"""
        risk_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: ["Position size limit", "Correlation monitoring", "Liquidity check"],
            ArbitrageType.VOLATILITY_SURFACE: ["Greeks hedging", "Volatility stop", "Gamma monitoring"],
            ArbitrageType.PAIRS_TRADING: ["Correlation monitoring", "Beta hedge", "Sector exposure limit"],
            ArbitrageType.DELTA_NEUTRAL: ["Delta hedging", "Gamma monitoring", "Vega control"],
            ArbitrageType.PATTERN_RECOGNITION: ["Dynamic hedging", "Pattern monitoring", "ML confidence tracking"],
            ArbitrageType.CORRELATION_BREAKDOWN: ["Sector hedging", "Market beta control", "Exposure limits"]
        }
        
        return risk_mapping.get(arb_type, ["Stop loss", "Position sizing", "Risk monitoring"])
    
    def _generate_monitoring_parameters(self, arb_type: ArbitrageType) -> Dict[str, str]:
        """Generate monitoring parameters"""
        monitoring_mapping = {}
            ArbitrageType.CROSS_EXCHANGE: {"spread_width": "real_time", "volume": "continuous", "liquidity": "hourly"},
            ArbitrageType.VOLATILITY_SURFACE: {"iv_rank": "hourly", "skew": "real_time", "gamma": "continuous"},
            ArbitrageType.PAIRS_TRADING: {"correlation": "daily", "z_score": "hourly", "beta": "daily"},
            ArbitrageType.DELTA_NEUTRAL: {"greeks": "real_time", "pricing_model": "continuous", "volatility": "hourly"},
            ArbitrageType.PATTERN_RECOGNITION: {"pattern_strength": "real_time", "ml_confidence": "continuous", "market_regime": "hourly"},
            ArbitrageType.CORRELATION_BREAKDOWN: {"correlation": "daily", "sector_performance": "real_time", "market_beta": "hourly"}
        }
        
        return monitoring_mapping.get(arb_type, {"general_monitoring": "hourly"})
    
    def _summarize_market_conditions(self, market_data: Dict[str, Any]) -> str:
        """Summarize current market conditions"""
        conditions = market_data.get('_market_conditions', {})
        return (f"Volatility: {conditions.get('volatility', 'unknown')}, ")
                f"Trend: {conditions.get('trend', 'unknown')}, "
                f"Liquidity: {conditions.get('liquidity', 'unknown')}, "
                f"Regime: {conditions.get('regime', 'unknown')}")
    
    async def _enhanced_validation(self, opportunities: List[EnhancedArbitrageOpportunity]) -> List[EnhancedArbitrageOpportunity]:
        """Enhanced multi-model validation with consensus scoring"""
        
        validated = []
        validation_models = [LLMModel.DEEPSEEK_R1, LLMModel.LLAMA_3_3_70B, LLMModel.GEMINI_2_0_FLASH]
        
        self.logger.info(f"🔍 Validating {len(opportunities)} opportunities with {len(validation_models)} models")
        
        for i, opp in enumerate(opportunities):
            try:
                self.logger.info(f"  Validating opportunity {i+1}/{len(opportunities)}: {opp.arbitrage_type.value}")
                
                # Multi-model validation
                validation_scores = []
                models_used = []
                
                for model in validation_models:
                    if not self._is_circuit_breaker_open(model):
                        score = await self._simulate_validation(opp, model)
                        if score is not None:
                            validation_scores.append(score)
                            models_used.append(model.name)
                
                if validation_scores:
                    # Enhanced consensus calculation
                    consensus_score = np.mean(validation_scores)
                    agreement_score = 1.0 - (np.std(validation_scores) if len(validation_scores) > 1 else 0)
                    confidence_interval = (min(validation_scores), max(validation_scores)
                    
                    # Update validation metrics
                    opp.validation_metrics = ValidationMetrics()
                        consensus_score=consensus_score,
                        agreement_score=agreement_score,
                        confidence_interval=confidence_interval,
                        validation_models=models_used,
                        mathematical_validity=consensus_score * agreement_score,
                        feasibility_score=consensus_score,
                        risk_score=self._calculate_risk_score(opp)
                    )
                    
                    opp.validation_timestamp = datetime.now()
                    
                    # Enhanced validation threshold with agreement requirement
                    if (consensus_score >= CONFIG["validation_threshold"] and)
                        agreement_score >= 0.7 and 
                        len(validation_scores) >= 2):
                        
                        validated.append(opp)
                        self.logger.info(f"    ✅ Validated (consensus: {consensus_score:.2f}, agreement: {agreement_score:.2f})")
                    else:
                        self.logger.info(f"    ❌ Failed validation (consensus: {consensus_score:.2f}, agreement: {agreement_score:.2f})")
                else:
                    self.logger.warning(f"    ⚠️  No validation scores obtained")
                    
            except Exception as e:
                self.logger.error(f"    💥 Validation error: {e}")
                opp.error_flags.append(f"validation_error: {str(e)}")
        
        # Sort by validation quality
        validated.sort(key=lambda x: x.validation_metrics.consensus_score * x.validation_metrics.agreement_score, reverse=True)
        
        return validated
    
    async def _simulate_validation(self, opportunity: EnhancedArbitrageOpportunity, 
                                 model: LLMModel) -> Optional[float]:
        """Simulate validation with realistic scoring"""
        
        # Simulate validation time
        await asyncio.sleep(0.05)  # Scaled for demo
        
        # Model-specific validation quality
        model_quality = self.ai_models[model]["response_patterns"]["mathematical_accuracy"]
        success_probability = model_quality * 0.9  # High probability for validation
        
        if np.self.get_market_data() > success_probability:
            self._record_circuit_breaker_failure(model)
            return None
        
        # Generate realistic validation score
        base_score = opportunity.confidence_score * 0.8  # Conservative validation
        
        # Adjust based on opportunity characteristics
        if opportunity.expected_profit > 10000:  # High profit = more scrutiny
            base_score *= 0.9
        if opportunity.risk_assessment in ["High", "Very High"]:
            base_score *= 0.85
        if opportunity.execution_complexity in ["Hard", "Very Hard"]:
            base_score *= 0.9
        
        # Add model-specific variation
        model_variation = self.get_price_distribution(0, 0.05)  # Small random variation
        final_score = np.clip(base_score + model_variation, 0.0, 1.0)
        
        # Record performance
        self.performance_tracker.record_model_request(model, True, 0.5, final_score)
        
        return final_score
    
    def _calculate_risk_score(self, opportunity: EnhancedArbitrageOpportunity) -> float:
        """Calculate comprehensive risk score"""
        risk_factors = {}
            "Very Low": 0.1,
            "Low": 0.3,
            "Medium": 0.5,
            "High": 0.7,
            "Very High": 0.9
        }
        
        base_risk = risk_factors.get(opportunity.risk_assessment, 0.5)
        
        # Adjust for other factors
        if opportunity.expected_profit > 5000:
            base_risk += 0.1
        if opportunity.execution_complexity in ["Hard", "Very Hard"]:
            base_risk += 0.1
        
        return min(1.0, base_risk)
    
    def _is_circuit_breaker_open(self, model: LLMModel) -> bool:
        """Check if circuit breaker is open"""
        breaker = self.circuit_breakers[model]
        
        if breaker["failures"] >= CONFIG["circuit_breaker_threshold"]:
            if breaker["last_failure"]:
                time_since = (datetime.now() - breaker["last_failure"]).seconds
                if time_since < CONFIG["circuit_breaker_timeout"]:
                    return True
                else:
                    # Reset circuit breaker
                    breaker["failures"] = 0
                    breaker["last_failure"] = None
                    breaker["is_open"] = False
        
        return False
    
    def _record_circuit_breaker_failure(self, model: LLMModel):
        """Record circuit breaker failure"""
        breaker = self.circuit_breakers[model]
        breaker["failures"] += 1
        breaker["last_failure"] = datetime.now()
        
        if breaker["failures"] >= CONFIG["circuit_breaker_threshold"]:
            breaker["is_open"] = True
            self.logger.warning(f"🔥 Circuit breaker opened for {model.name}")
    
    async def shutdown(self):
        """Enhanced shutdown with comprehensive reporting"""
        self.logger.info("🛑 Shutting down Enhanced AI Agent...")
        
        # Generate final performance report
        performance_summary = self.performance_tracker.get_performance_summary()
        
        self.logger.info("📊 Final Performance Summary:")
        self.logger.info(f"  Total opportunities: {self.performance_tracker.system_metrics['total_opportunities']}")
        self.logger.info(f"  Validated opportunities: {self.performance_tracker.system_metrics['validated_opportunities']}")
        self.logger.info(f"  Total profit potential: ${self.performance_tracker.system_metrics['total_profit_potential']:,.0f}")
        
        self.logger.info("✅ Enhanced AI Agent shutdown complete")

# Comprehensive testing framework
async 
    def get_market_data(self):
        """Get real market data from Alpaca or simulate if not available"""
        try:
            if hasattr(self, 'data_client'):
                symbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA']
                request = StockLatestQuoteRequest(symbol_or_symbols=symbols)
                quotes = self.data_client.get_stock_latest_quote(request)
                
                market_data = {}
                for symbol, quote in quotes.items():
                    market_data[symbol] = {}
                        'price': float((quote.ask_price + quote.bid_price) / 2),
                        'bid': float(quote.bid_price),
                        'ask': float(quote.ask_price),
                        'spread': float(quote.ask_price - quote.bid_price)
                    }
                return market_data
        except:
            # Fallback to simulated data
            return {}
                'AAPL': {'price': 197.65, 'spread': 0.02},
                'GOOGL': {'price': 177.10, 'spread': 0.02},
                'MSFT': {'price': 478.32, 'spread': 0.04},
                'TSLA': {'price': 320.50, 'spread': 0.06},
                'NVDA': {'price': 1085.80, 'spread': 0.10}
            }

def run_comprehensive_tests():
    """Run comprehensive tests of enhanced AI system"""
    
    logger.info("🧪 COMPREHENSIVE ENHANCED AI TESTING FRAMEWORK")
    logger.info("=" * 100)
    
    agent = EnhancedAIAgent()
    
    try:
        await agent.initialize()
        
        # Generate comprehensive test market data
        test_market_data = {}
            # Major indices
            'SPY': {'current_price': 450, 'volume': 50000000, 'iv_rank': 0.3, 'correlation_spy': 1.0},
            'QQQ': {'current_price': 380, 'volume': 30000000, 'iv_rank': 0.7, 'correlation_spy': 0.85},
            'IWM': {'current_price': 220, 'volume': 20000000, 'iv_rank': 0.8, 'correlation_spy': 0.75},
            
            # Tech stocks
            'AAPL': {'current_price': 175, 'volume': 40000000, 'iv_rank': 0.5, 'correlation_spy': 0.8},
            'MSFT': {'current_price': 420, 'volume': 25000000, 'iv_rank': 0.4, 'correlation_spy': 0.85},
            'GOOGL': {'current_price': 175, 'volume': 15000000, 'iv_rank': 0.6, 'correlation_spy': 0.75},
            
            # Financials
            'JPM': {'current_price': 180, 'volume': 12000000, 'iv_rank': 0.4, 'correlation_spy': 0.9},
            'BAC': {'current_price': 45, 'volume': 35000000, 'iv_rank': 0.5, 'correlation_spy': 0.85},
            
            # Commodities
            'GLD': {'current_price': 180, 'volume': 8000000, 'iv_rank': 0.3, 'correlation_spy': -0.1},
            'TLT': {'current_price': 90, 'volume': 10000000, 'iv_rank': 0.6, 'correlation_spy': -0.3},
            
            # Market conditions
            '_market_conditions': {}
                'volatility': 'medium',
                'trend': 'bullish', 
                'liquidity': 'normal',
                'regime': 'normal',
                'correlation_environment': 'moderate_breakdown'
            }
        }
        
        logger.info(f"📊 Test Market Data: {len(test_market_data)-1} symbols")
        logger.info(f"🌍 Market Conditions: {test_market_data['_market_conditions']}")
        
        # Run multiple discovery cycles for comprehensive testing
        logger.info(f"\n🔄 RUNNING MULTIPLE DISCOVERY CYCLES")
        logger.info("-" * 80)
        
        all_opportunities = []
        cycle_results = []
        
        for cycle in range(3):  # 3 cycles for comprehensive testing
            logger.info(f"\n🔄 Discovery Cycle {cycle + 1}/3")
            
            start_time = time.time()
            opportunities = await agent.discover_arbitrage_opportunities(test_market_data)
            cycle_time = time.time() - start_time
            
            cycle_result = {}
                "cycle": cycle + 1,
                "opportunities": len(opportunities),
                "time": cycle_time,
                "avg_confidence": np.mean([opp.confidence_score for opp in opportunities]) if opportunities else 0,
                "total_profit": sum(opp.expected_profit for opp in opportunities)
            }
            
            cycle_results.append(cycle_result)
            all_opportunities.extend(opportunities)
            
            logger.info(f"  ✅ Cycle {cycle + 1}: {len(opportunities)} opportunities in {cycle_time:.2f}s")
            
            if opportunities:
                logger.info(f"     💰 Profit Potential: ${cycle_result['total_profit']:,.0f}")
                logger.info(f"     📊 Avg Confidence: {cycle_result['avg_confidence']:.2f}")
                
                # Show top opportunity
                top_opp = max(opportunities, key=lambda x: x.expected_profit)
                logger.info(f"     🏆 Top: {top_opp.arbitrage_type.value} - ${top_opp.expected_profit:.0f}")
        
        # Comprehensive analysis
        logger.info(f"\n🏆 COMPREHENSIVE TEST RESULTS")
        logger.info("=" * 80)
        
        if all_opportunities:
            # Overall metrics
            total_profit = sum(opp.expected_profit for opp in all_opportunities)
            avg_confidence = np.mean([opp.confidence_score for opp in all_opportunities])
            total_time = sum(cycle["time"] for cycle in cycle_results)
            
            logger.info(f"📊 OVERALL PERFORMANCE:")
            logger.info(f"   🔄 Total Cycles: {len(cycle_results)}")
            logger.info(f"   💡 Total Opportunities: {len(all_opportunities)}")
            logger.info(f"   💰 Total Profit Potential: ${total_profit:,.0f}")
            logger.info(f"   📊 Average Confidence: {avg_confidence:.2f}")
            logger.info(f"   ⏱️  Total Time: {total_time:.2f}s")
            logger.info(f"   🚀 Discovery Rate: {len(all_opportunities)/total_time:.1f} opps/sec")
            
            # Arbitrage type analysis
            type_counts = defaultdict(int)
            type_profits = defaultdict(float)
            for opp in all_opportunities:
                type_counts[opp.arbitrage_type] += 1
                type_profits[opp.arbitrage_type] += opp.expected_profit
            
            logger.info(f"\n📈 ARBITRAGE TYPE BREAKDOWN:")
            for arb_type in sorted(type_counts.keys(), key=lambda x: type_counts[x], reverse=True):
                count = type_counts[arb_type]
                profit = type_profits[arb_type]
                logger.info(f"   {arb_type.value.replace('_', ' ').title()}: {count} opportunities, ${profit:,.0f}")
            
            # Validation analysis
            high_validation = [opp for opp in all_opportunities if opp.validation_metrics.consensus_score > 0.8]
            logger.info(f"\n🎯 VALIDATION ANALYSIS:")
            logger.info(f"   ✅ High Validation (>0.8): {len(high_validation)}/{len(all_opportunities)} ({len(high_validation)/len(all_opportunities)*100:.1f}%)")
            
            if high_validation:
                avg_consensus = np.mean([opp.validation_metrics.consensus_score for opp in high_validation])
                avg_agreement = np.mean([opp.validation_metrics.agreement_score for opp in high_validation])
                logger.info(f"   📊 Avg Consensus Score: {avg_consensus:.2f}")
                logger.info(f"   🤝 Avg Agreement Score: {avg_agreement:.2f}")
            
            # Model performance analysis
            model_discoveries = defaultdict(int)
            for opp in all_opportunities:
                model_discoveries[opp.discovered_by_model] += 1
            
            logger.info(f"\n🧠 MODEL PERFORMANCE:")
            for model, count in sorted(model_discoveries.items(), key=lambda x: x[1], reverse=True):
                logger.info(f"   {model}: {count} discoveries")
            
            # Top opportunities showcase
            logger.info(f"\n🏆 TOP 5 OPPORTUNITIES:")
            logger.info("-" * 70)
            top_opportunities = sorted(all_opportunities, 
                                     key=lambda x: x.expected_profit * x.confidence_score * x.validation_metrics.consensus_score,
                                     reverse=True)[:5]
            
            for i, opp in enumerate(top_opportunities, 1):
                logger.info(f"{i}. {opp.arbitrage_type.value.replace('_', ' ').title()}")
                logger.info(f"   💰 Expected Profit: ${opp.expected_profit:,.0f}")
                logger.info(f"   🎯 Confidence: {opp.confidence_score:.2f}")
                logger.info(f"   ✅ Validation: {opp.validation_metrics.consensus_score:.2f}")
                logger.info(f"   🤖 Model: {opp.discovered_by_model}")
                logger.info(f"   ⚖️  Risk: {opp.risk_assessment}")
                logger.info(f"   🔧 Complexity: {opp.execution_complexity}")
                logger.info()
            
            # Performance metrics
            performance_summary = agent.performance_tracker.get_performance_summary()
            
            logger.info(f"🔧 SYSTEM PERFORMANCE METRICS:")
            logger.info(f"   📞 Total Model Requests: {sum(perf['total_requests'] for perf in performance_summary['model_performance'].values()}")
            
            if performance_summary['model_performance']:
                avg_success_rate = np.mean([perf['success_rate'] for perf in performance_summary['model_performance'].values()])
                logger.info(f"   ✅ Average Success Rate: {avg_success_rate:.2f}")
                
                logger.info(f"\n🧠 TOP PERFORMING MODELS:")
                for model_name, perf in performance_summary['top_performing_models']:
                    logger.info(f"   {model_name}: {perf['success_rate']:.2f} success rate, {perf['specialty']}")
            
            # Recommendations
            if performance_summary['recommendations']:
                logger.info(f"\n💡 SYSTEM RECOMMENDATIONS:")
                for rec in performance_summary['recommendations']:
                    logger.info(f"   • {rec}")
        
        else:
            logger.info("❌ No opportunities discovered across all cycles")
        
        logger.info(f"\n🎊 COMPREHENSIVE TESTING COMPLETE!")
        logger.info(f"✅ Enhanced AI arbitrage system successfully tested")
        logger.info(f"✅ Multi-model validation implemented")
        logger.info(f"✅ Circuit breaker protection active")
        logger.info(f"✅ Performance monitoring operational")
        logger.info(f"✅ Comprehensive error handling verified")
        
        return True
        
    except Exception as e:
        logger.info(f"❌ Testing failed: {e}")
        traceback.print_exc()
        return False
        
    finally:
        await agent.shutdown()

if __name__ == "__main__":
    asyncio.run(run_comprehensive_tests()