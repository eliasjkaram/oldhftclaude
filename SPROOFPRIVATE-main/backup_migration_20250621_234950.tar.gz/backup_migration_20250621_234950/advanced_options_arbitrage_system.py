
#!/usr/bin/env python3
"""
Advanced Options Arbitrage System for Longer-Dated Spreads
GPU-accelerated system for finding arbitrage opportunities in LEAPS and longer-dated options
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
import asyncio
import aiohttp
from datetime import datetime, timedelta
import logging
from collections import defaultdict
import scipy.stats as stats
from scipy.optimize import minimize
import cupy as cp  # GPU-accelerated numpy
import json
from pathlib import Path
import sqlite3
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import warnings

from universal_market_data import get_current_market_data, get_realistic_price
warnings.filterwarnings('ignore')

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class OptionsContract:
    """Options contract data structure"""
    symbol: str
    underlying: str
    strike: float
    expiration: datetime
    option_type: str  # 'call' or 'put'
    bid: float
    ask: float
    mid: float
    volume: int
    open_interest: int
    implied_volatility: float
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float
    
    @property
    def days_to_expiration(self) -> int:
        return (self.expiration - datetime.now().days
    
    @property
opportunities = []
        return self.days_to_expiration / 365.25
    
    @property
    def bid_ask_spread(self) -> float:
        return self.ask - self.bid
    
    @property
    def spread_percentage(self) -> float:
        return self.bid_ask_spread / self.mid if self.mid > 0 else float('inf')

@dataclass
class ArbitrageOpportunity:
    """Arbitrage opportunity structure"""
    strategy_type: str
    legs: List[Tuple[OptionsContract, int]]  # (contract, quantity)
    theoretical_profit: float
    execution_profit: float  # After bid-ask spreads
    probability: float
    risk_score: float
    required_capital: float
    max_loss: float
    breakeven_points: List[float]
    edge_percentage: float
    model_confidence: float
    execution_complexity: int  # 1-10 scale
    
    def to_dict(self) -> Dict:
        return {}
            'strategy_type': self.strategy_type,
            'theoretical_profit': self.theoretical_profit,
            'execution_profit': self.execution_profit,
            'probability': self.probability,
            'risk_score': self.risk_score,
            'required_capital': self.required_capital,
            'legs': [(leg[0].symbol, leg[1]) for leg in self.legs]
        }

class GPUPricingEngine:
    """GPU-accelerated options pricing engine"""
    
    def __init__(self, device='cuda'):
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        logger.info(f"Pricing engine initialized on {self.device}")
        
        # Pre-allocate GPU memory for efficiency
        if self.device.type == 'cuda':
            torch.cuda.empty_cache()
            self.gpu_memory_pool = torch.cuda.memory_reserved(0)
    
    def black_scholes_gpu(self, S: torch.Tensor, K: torch.Tensor, T: torch.Tensor,
                         r: torch.Tensor, sigma: torch.Tensor, 
                         option_type: str = 'call') -> torch.Tensor:
        """Vectorized Black-Scholes on GPU"""
        d1 = (torch.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * torch.sqrt(T)
        d2 = d1 - sigma * torch.sqrt(T)
        
        if option_type == 'call':
            price = S * self._norm_cdf_gpu(d1) - K * torch.exp(-r * T) * self._norm_cdf_gpu(d2)
        else:
            price = K * torch.exp(-r * T) * self._norm_cdf_gpu(-d2) - S * self._norm_cdf_gpu(-d1)
        
        return price
    
    def _norm_cdf_gpu(self, x: torch.Tensor) -> torch.Tensor:
        """GPU-accelerated normal CDF"""
        return 0.5 * (1 + torch.erf(x / torch.sqrt(torch.tensor(2.0))
    
    def binomial_tree_gpu(self, S: float, K: float, T: float, r: float, 
                         sigma: float, steps: int = 1000, 
                         option_type: str = 'call', american: bool = True) -> float:
        """GPU-accelerated binomial tree pricing"""
        dt = T / steps
        u = cp.exp(sigma * cp.sqrt(dt)
        d = 1 / u
        p = (cp.exp(r * dt) - d) / (u - d)
        
        # Initialize price tree
        price_tree = cp.zeros((steps + 1, steps + 1)
        
        # Calculate terminal payoffs
        for i in range(steps + 1):
            price_tree[steps, i] = max(0, S * (u ** (steps - i) * (d ** i) - K) \
                                   if option_type == 'call' else \
                                   max(0, K - S * (u ** (steps - i) * (d ** i)
        
        # Backward induction
        for t in range(steps - 1, -1, -1):
            for i in range(t + 1):
                hold_value = cp.exp(-r * dt) * (p * price_tree[t + 1, i] +)
                                               (1 - p) * price_tree[t + 1, i + 1])
                
                if american:
                    exercise_value = max(0, S * (u ** (t - i) * (d ** i) - K) \
                                    if option_type == 'call' else \
                                    max(0, K - S * (u ** (t - i) * (d ** i)
                    price_tree[t, i] = max(hold_value, exercise_value)
                else:
                    price_tree[t, i] = hold_value
        
        return float(price_tree[0, 0])
    
    def monte_carlo_gpu(self, S: float, K: float, T: float, r: float,
                       sigma: float, num_sims: int = 100000,
                       option_type: str = 'call') -> Tuple[float, float]:
        """GPU-accelerated Monte Carlo pricing"""
        # Generate random paths on GPU
        dt = T / 252  # Daily steps
        num_steps = int(T * 252)
        
        # Random number generation on GPU
        randn = torch.randn(num_sims, num_steps, device=self.device)
        
        # Simulate price paths
        drift = (r - 0.5 * sigma ** 2) * dt
        diffusion = sigma * torch.sqrt(torch.tensor(dt)
        
        log_returns = drift + diffusion * randn
        log_prices = torch.cumsum(log_returns, dim=1)
        prices = S * torch.exp(log_prices)
        
        # Calculate payoffs
        if option_type == 'call':
            payoffs = torch.maximum(prices[:, -1] - K, torch.tensor(0.0)
        else:
            payoffs = torch.maximum(K - prices[:, -1], torch.tensor(0.0)
        
        # Discount to present value
        option_price = torch.exp(-r * T) * torch.mean(payoffs)
        std_error = torch.std(payoffs) / torch.sqrt(torch.tensor(float(num_sims))
        
        return float(option_price), float(std_error)
    
    def heston_model_gpu(self, S: float, K: float, T: float, r: float,
                        v0: float, theta: float, kappa: float, xi: float,
                        rho: float, num_sims: int = 50000) -> float:
        """GPU-accelerated Heston stochastic volatility model"""
        dt = T / 252
        num_steps = int(T * 252)
        
        # Initialize arrays on GPU
        S_paths = torch.zeros(num_sims, num_steps + 1, device=self.device)
        v_paths = torch.zeros(num_sims, num_steps + 1, device=self.device)
        
        S_paths[:, 0] = S
        v_paths[:, 0] = v0
        
        # Generate correlated random numbers
        Z1 = torch.randn(num_sims, num_steps, device=self.device)
        Z2 = torch.randn(num_sims, num_steps, device=self.device)
        W1 = Z1
        W2 = rho * Z1 + torch.sqrt(1 - rho**2) * Z2
        
        # Simulate paths
        for t in range(num_steps):
            v_paths[:, t + 1] = v_paths[:, t] + kappa * (theta - v_paths[:, t]) * dt + \
                                xi * torch.sqrt(v_paths[:, t] * dt) * W2[:, t]
            v_paths[:, t + 1] = torch.maximum(v_paths[:, t + 1], torch.tensor(0.0)
            
            S_paths[:, t + 1] = S_paths[:, t] * torch.exp()
                (r - 0.5 * v_paths[:, t]) * dt + 
                torch.sqrt(v_paths[:, t] * dt) * W1[:, t]
            )
        
        # Calculate option payoff
        payoffs = torch.maximum(S_paths[:, -1] - K, torch.tensor(0.0)
        option_price = torch.exp(-r * T) * torch.mean(payoffs)
        
        return float(option_price)

class VolatilitySurfaceAnalyzer:
    """Analyze and model the volatility surface"""
    
    def __init__(self, pricing_engine: GPUPricingEngine):
        self.pricing_engine = pricing_engine
        self.surface_cache = {}
    
    def build_surface(self, options: List[OptionsContract]) -> Dict[str, Any]:
        """Build volatility surface from options chain"""
        # Group by expiration
        by_expiration = defaultdict(list)
        for opt in options:
            by_expiration[opt.expiration].append(opt)
        
        surface_data = {}
            'expirations': [],
            'strikes': [],
            'ivs': [],
            'surface_tensor': None
        }
        
        # Create regular grid
        all_strikes = sorted(set(opt.strike for opt in options)
        all_expirations = sorted(by_expiration.keys()
        
        # Build surface tensor
        surface = torch.zeros(len(all_expirations), len(all_strikes)
        
        for i, exp in enumerate(all_expirations):
            for j, strike in enumerate(all_strikes):
                # Find matching option
                matching = [opt for opt in by_expiration[exp] if opt.strike == strike]
                if matching:
                    surface[i, j] = matching[0].implied_volatility
                else:
                    # Interpolate
                    surface[i, j] = self._interpolate_iv(by_expiration[exp], strike)
        
        surface_data['surface_tensor'] = surface
        surface_data['expirations'] = all_expirations
        surface_data['strikes'] = all_strikes
        
        return surface_data
    
    def _interpolate_iv(self, options: List[OptionsContract], strike: float) -> float:
        """Interpolate implied volatility for missing strikes"""
        strikes = [opt.strike for opt in options]
        ivs = [opt.implied_volatility for opt in options]
        
        if not strikes:
            return 0.3  # Default volatility
        
        # Simple linear interpolation
        if strike <= min(strikes):
            return ivs[strikes.index(min(strikes))]
        elif strike >= max(strikes):
            return ivs[strikes.index(max(strikes))]
        else:
            # Linear interpolation
            for i in range(len(strikes) - 1):
                if strikes[i] <= strike <= strikes[i + 1]:
                    weight = (strike - strikes[i]) / (strikes[i + 1] - strikes[i])
                    return ivs[i] * (1 - weight) + ivs[i + 1] * weight
        
        return 0.3
    
    def find_surface_arbitrage(self, surface: Dict[str, Any], 
                             underlying_price: float) -> List[Dict[str, Any]]:
        """Find arbitrage opportunities in the volatility surface"""
        opportunities = []
        surface_tensor = surface['surface_tensor']
        
        # Check for calendar spread opportunities
        for strike_idx, strike in enumerate(surface['strikes']):
            ivs_by_expiry = surface_tensor[:, strike_idx]
            
            # Look for volatility term structure anomalies
            for i in range(len(ivs_by_expiry) - 1):
                near_iv = ivs_by_expiry[i]
                far_iv = ivs_by_expiry[i + 1]
                
                # Significant inversion in term structure
                if near_iv > far_iv * 1.1:  # 10% threshold
                    opportunities.append({)
                        'type': 'calendar_spread',
                        'strike': strike,
                        'near_expiry': surface['expirations'][i],
                        'far_expiry': surface['expirations'][i + 1],
                        'near_iv': float(near_iv),
                        'far_iv': float(far_iv),
                        'edge': float(near_iv - far_iv)
                    })
        
        # Check for butterfly arbitrage
        for exp_idx, expiry in enumerate(surface['expirations']):
            strikes = surface['strikes']
            ivs = surface_tensor[exp_idx, :]
            
            for i in range(1, len(strikes) - 1):
                # Butterfly: Buy K1, Buy K3, Sell 2*K2
                k1, k2, k3 = strikes[i-1], strikes[i], strikes[i+1]
                iv1, iv2, iv3 = ivs[i-1], ivs[i], ivs[i+1]
                
                # Check convexity violation
                expected_iv2 = (iv1 + iv3) / 2
                if iv2 < expected_iv2 * 0.95:  # 5% threshold
                    opportunities.append({)
                        'type': 'butterfly',
                        'expiry': expiry,
                        'strikes': [k1, k2, k3],
                        'ivs': [float(iv1), float(iv2), float(iv3)],
                        'edge': float(expected_iv2 - iv2)
                    })
        
        return opportunities

class OptionsArbitrageScanner:
    """Main arbitrage scanning engine"""
    
    def __init__(self, pricing_engine: GPUPricingEngine):
        self.pricing_engine = pricing_engine
        self.vol_analyzer = VolatilitySurfaceAnalyzer(pricing_engine)
        self.risk_free_rate = 0.05  # Current risk-free rate
        self.min_profit_threshold = 0.50  # Minimum profit in dollars
        self.max_spread_threshold = 0.10  # Maximum bid-ask spread as % of mid
        
    def scan_put_call_parity(self, options: List[OptionsContract], 
                           underlying_price: float) -> List[ArbitrageOpportunity]:
        """Scan for put-call parity violations"""
        opportunities = []
        
        # Group by strike and expiration
        grouped = defaultdict(lambda: {'call': None, 'put': None})
        for opt in options:
            key = (opt.strike, opt.expiration)
            grouped[key][opt.option_type] = opt
        
        for (strike, expiration), pair in grouped.items():
            if pair['call'] and pair['put']:
                call = pair['call']
                put = pair['put']
                
                # Calculate theoretical relationship
                # C - P = S - K * e^(-r*T)
                T = call.years_to_expiration
                theoretical_diff = underlying_price - strike * np.exp(-self.risk_free_rate * T)
                actual_diff = call.mid - put.mid
                
                mispricing = abs(theoretical_diff - actual_diff)
                
                # Check if mispricing exceeds transaction costs
                total_spread_cost = call.bid_ask_spread + put.bid_ask_spread
                
                if mispricing > total_spread_cost + self.min_profit_threshold:
                    # Determine which side to trade
                    if actual_diff > theoretical_diff:
                        # Calls overpriced relative to puts
                        legs = []
                            (call, -1),  # Sell call
                            (put, 1),    # Buy put
                        ]
                        # Also need to buy stock and borrow at risk-free rate
                    else:
                        # Puts overpriced relative to calls
                        legs = []
                            (call, 1),   # Buy call
                            (put, -1),   # Sell put
                        ]
                    
                    opportunity = ArbitrageOpportunity()
                        strategy_type='put_call_parity',
                        legs=legs,
                        theoretical_profit=mispricing,
                        execution_profit=mispricing - total_spread_cost,
                        probability=0.95,  # High probability for parity arbitrage
                        risk_score=0.1,
                        required_capital=abs(strike * 100),  # Per contract
                        max_loss=total_spread_cost,
                        breakeven_points=[strike],
                        edge_percentage=(mispricing / strike) * 100,
                        model_confidence=0.9,
                        execution_complexity=3
                    )
                    
                    opportunities.append(opportunity)
        
        return opportunities
    
    def scan_box_spreads(self, options: List[OptionsContract]) -> List[ArbitrageOpportunity]:
        """Scan for box spread arbitrage opportunities"""
        opportunities = []
        
        # Group by expiration
        by_expiration = defaultdict(list)
        for opt in options:
            by_expiration[opt.expiration].append(opt)
        
        for expiration, exp_options in by_expiration.items():
            # Get unique strikes
            strikes = sorted(set(opt.strike for opt in exp_options)
            
            # Need at least 2 strikes for a box
            for i in range(len(strikes) - 1):
                k1, k2 = strikes[i], strikes[i + 1]
                
                # Find the 4 options needed
                c1 = next((opt for opt in exp_options if opt.strike == k1 and opt.option_type == 'call'), None)
                c2 = next((opt for opt in exp_options if opt.strike == k2 and opt.option_type == 'call'), None)
                p1 = next((opt for opt in exp_options if opt.strike == k1 and opt.option_type == 'put'), None)
                p2 = next((opt for opt in exp_options if opt.strike == k2 and opt.option_type == 'put'), None)
                
                if all([c1, c2, p1, p2]):
                    # Box spread payoff is always K2 - K1
                    box_value = k2 - k1
                    T = c1.years_to_expiration
                    present_value = box_value * np.exp(-self.risk_free_rate * T)
                    
                    # Cost to create box: Buy C1, Sell C2, Sell P1, Buy P2
                    box_cost = c1.ask - c2.bid - p1.bid + p2.ask
                    
                    profit = present_value - box_cost
                    
                    if profit > self.min_profit_threshold:
                        opportunity = ArbitrageOpportunity()
                            strategy_type='box_spread',
                            legs=[]
                                (c1, 1),   # Buy lower call
                                (c2, -1),  # Sell higher call
                                (p1, -1),  # Sell lower put
                                (p2, 1)    # Buy higher put
                            ],
                            theoretical_profit=profit * 100,  # Per contract
                            execution_profit=(profit - 0.04) * 100,  # Assume $0.04 commission
                            probability=0.99,  # Very high probability
                            risk_score=0.05,
                            required_capital=box_cost * 100,
                            max_loss=0.04 * 100,  # Just commissions
                            breakeven_points=[k1, k2],
                            edge_percentage=(profit / box_cost) * 100,
                            model_confidence=0.95,
                            execution_complexity=5
                        )
                        
                        opportunities.append(opportunity)
        
        return opportunities
    
    def scan_volatility_arbitrage(self, options: List[OptionsContract],
                                underlying_price: float) -> List[ArbitrageOpportunity]:
        """Scan for volatility-based arbitrage opportunities"""
        opportunities = []
        
        # Build volatility surface
        surface = self.vol_analyzer.build_surface(options)
        surface_arbs = self.vol_analyzer.find_surface_arbitrage(surface, underlying_price)
        
        for arb in surface_arbs:
            if arb['type'] == 'calendar_spread':
                # Find the actual options
                near_opt = next((opt for opt in options))
                               if opt.strike == arb['strike'] and 
                               opt.expiration == arb['near_expiry']), None)
                far_opt = next((opt for opt in options))
                              if opt.strike == arb['strike'] and 
                              opt.expiration == arb['far_expiry']), None)
                
                if near_opt and far_opt:
                    # Calendar spread: Sell near, buy far
                    spread_cost = far_opt.ask - near_opt.bid
                    
                    # Estimate profit from vol convergence
                    vol_diff = arb['near_iv'] - arb['far_iv']
                    vega_profit = (near_opt.vega + far_opt.vega) * vol_diff * 100
                    
                    if vega_profit > spread_cost + self.min_profit_threshold:
                        opportunity = ArbitrageOpportunity()
                            strategy_type='calendar_spread',
                            legs=[]
                                (near_opt, -1),  # Sell near
                                (far_opt, 1)     # Buy far
                            ],
                            theoretical_profit=vega_profit,
                            execution_profit=vega_profit - spread_cost,
                            probability=0.7,  # Moderate probability
                            risk_score=0.3,
                            required_capital=abs(spread_cost * 100),
                            max_loss=spread_cost * 100,
                            breakeven_points=[arb['strike']],
                            edge_percentage=(vega_profit / spread_cost - 1) * 100,
                            model_confidence=0.75,
                            execution_complexity=3
                        )
                        
                        opportunities.append(opportunity)
        
        return opportunities
    
    def scan_all_strategies(self, options: List[OptionsContract],
                          underlying_price: float) -> List[ArbitrageOpportunity]:
        """Run all arbitrage scans"""
        all_opportunities = []
        
        # Filter for longer-dated options (30+ days)
        long_dated_options = [opt for opt in options if opt.days_to_expiration >= 30]
        
        logger.info(f"Scanning {len(long_dated_options)} longer-dated options...")
        
        # Run different scans
        all_opportunities.extend(self.scan_put_call_parity(long_dated_options, underlying_price)
        all_opportunities.extend(self.scan_box_spreads(long_dated_options)
        all_opportunities.extend(self.scan_volatility_arbitrage(long_dated_options, underlying_price)
        
        # Sort by execution profit
        all_opportunities.sort(key=lambda x: x.execution_profit, reverse=True)
        
        return all_opportunities

class RiskManager:
    """Risk management for arbitrage trades"""
    
    def __init__(self):
        self.max_position_size = 100000
        self.max_portfolio_risk = 0.02  # 2% of capital
        self.correlation_threshold = 0.7
        
    def evaluate_opportunity(self, opportunity: ArbitrageOpportunity,
                           existing_positions: List[ArbitrageOpportunity]) -> Dict[str, Any]:
        """Evaluate if we should take this opportunity"""
        evaluation = {}
            'approved': True,
            'reasons': [],
            'position_size': 1,
            'risk_metrics': {}
        }
        
        # Check profitability threshold
        if opportunity.execution_profit < 50:  # $50 minimum
            evaluation['approved'] = False
            evaluation['reasons'].append('Profit too low')
        
        # Check execution complexity
        if opportunity.execution_complexity > 7:
            evaluation['approved'] = False
            evaluation['reasons'].append('Too complex to execute reliably')
        
        # Check bid-ask spreads
        total_spread_cost = sum(leg[0].bid_ask_spread for leg in opportunity.legs)
        if total_spread_cost > opportunity.theoretical_profit * 0.5:
            evaluation['approved'] = False
            evaluation['reasons'].append('Bid-ask spreads too wide')
        
        # Calculate position size based on Kelly Criterion
        if opportunity.probability > 0:
            kelly_fraction = (opportunity.probability * opportunity.execution_profit -)
                            (1 - opportunity.probability) * opportunity.max_loss) / \
                           opportunity.execution_profit
            
            # Conservative Kelly (quarter Kelly)
            position_size = min()
                int(kelly_fraction * 0.25 * self.max_position_size / opportunity.required_capital),
                10  # Max 10 contracts
            )
            
            evaluation['position_size'] = max(1, position_size)
        
        # Risk metrics
        evaluation['risk_metrics'] = {}
            'var_95': opportunity.max_loss * 1.65,  # Simplified VaR
            'expected_return': opportunity.probability * opportunity.execution_profit,
            'sharpe_ratio': (opportunity.execution_profit / opportunity.max_loss) if opportunity.max_loss > 0 else float('inf'),
            'win_rate': opportunity.probability
        }
        
        return evaluation

class MarketDataFeed:
    """Simulated market data feed for demonstration"""
    
    def __init__(self):
        self.symbols = ['SPY', 'QQQ', 'IWM', 'DIA', 'AAPL', 'MSFT', 'GOOGL', 'AMZN']
        
    async def get_options_chain(self, symbol: str) -> List[OptionsContract]:
        """Get options chain for a symbol"""
        # Simulated data for demonstration
        options = []
        underlying_price = 100 + np.random.randn() * 20
        
        # Generate options for multiple expirations
        expirations = []
            datetime.now() + timedelta(days=30),
            datetime.now() + timedelta(days=60),
            datetime.now() + timedelta(days=90),
            datetime.now() + timedelta(days=180),
            datetime.now() + timedelta(days=365),
        ]
        
        for expiration in expirations:
            T = (expiration - datetime.now().days / 365.25)
            
            # Generate strikes around the money
            strikes = np.linspace(underlying_price * 0.8, underlying_price * 1.2, 21)
            
            for strike in strikes:
                for option_type in ['call', 'put']:
                    # Calculate theoretical values
                    moneyness = underlying_price / strike
                    base_iv = 0.2 + 0.1 * abs(1 - moneyness) + np.random.randn() * 0.02
                    
                    # Simulate bid-ask spread (wider for longer-dated)
                    spread_width = 0.02 + 0.01 * T + 0.02 * abs(1 - moneyness)
                    
                    theoretical_price = self._black_scholes()
                        underlying_price, strike, T, 0.05, base_iv, option_type
                    )
                    
                    bid = theoretical_price * (1 - spread_width/2)
                    ask = theoretical_price * (1 + spread_width/2)
                    mid = (bid + ask) / 2
                    
                    # Greeks
                    delta = self._calculate_delta(underlying_price, strike, T, 0.05, base_iv, option_type)
                    
                    contract = OptionsContract()
                        symbol=f"{symbol}_{expiration.strftime('%Y%m%d')}_{option_type[0]}{int(strike)}",
                        underlying=symbol,
                        strike=strike,
                        expiration=expiration,
                        option_type=option_type,
                        bid=max(0.01, bid),
                        ask=ask,
                        mid=mid,
                        volume=np.random.randint(0, 1000),
                        open_interest=np.random.randint(100, 10000),
                        implied_volatility=base_iv,
                        delta=delta,
                        gamma=0.01,
                        theta=-0.05,
                        vega=0.10,
                        rho=0.05
                    )
                    
                    options.append(contract)
        
        return options, underlying_price
    
    def _black_scholes(self, S, K, T, r, sigma, option_type):
        """Simple Black-Scholes calculation"""
        from scipy.stats import norm
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        d2 = d1 - sigma * np.sqrt(T)
        
        if option_type == 'call':
            return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        else:
            return K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
    
    def _calculate_delta(self, S, K, T, r, sigma, option_type):
        """Calculate option delta"""
        from scipy.stats import norm
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        
        if option_type == 'call':
            return norm.cdf(d1)
        else:
            return -norm.cdf(-d1)

class ArbitrageExecutor:
    """Execute arbitrage trades"""
    
    def __init__(self):
        self.execution_log = []
        
    async def execute_opportunity(self, opportunity: ArbitrageOpportunity,
                                position_size: int) -> Dict[str, Any]:
        """Execute an arbitrage opportunity"""
        execution_result = {}
            'success': True,
            'filled_legs': [],
            'total_cost': 0,
            'expected_profit': opportunity.execution_profit * position_size,
            'timestamp': datetime.now()
        }
        
        # Simulate execution of each leg
        for contract, quantity in opportunity.legs:
            # Determine execution price (simulate slippage)
            if quantity > 0:  # Buying
                exec_price = contract.ask * (1 + np.random.uniform(0, 0.001)
            else:  # Selling
                exec_price = contract.bid * (1 - np.random.uniform(0, 0.001)
            
            leg_cost = exec_price * abs(quantity) * position_size * 100  # Options multiplier
            
            execution_result['filled_legs'].append({)
                'contract': contract.symbol,
                'quantity': quantity * position_size,
                'price': exec_price,
                'cost': leg_cost * (1 if quantity > 0 else -1)
            })
            
            execution_result['total_cost'] += leg_cost * (1 if quantity > 0 else -1)
        
        self.execution_log.append(execution_result)
        return execution_result

async def main():
    """Run the advanced options arbitrage system"""
    logger.info("🚀 Starting Advanced Options Arbitrage System")
    logger.info("🎯 Focus: Longer-dated spread arbitrage opportunities")
    
    # Initialize components
    pricing_engine = GPUPricingEngine()
    scanner = OptionsArbitrageScanner(pricing_engine)
    risk_manager = RiskManager()
    data_feed = MarketDataFeed()
    executor = ArbitrageExecutor()
    
    # Track opportunities
    all_opportunities = []
    approved_trades = []
    
    # Scan multiple symbols
    for symbol in data_feed.symbols:
        logger.info(f"\n📊 Scanning {symbol}...")
        
        # Get options chain
        options, underlying_price = await data_feed.get_options_chain(symbol)
        logger.info(f"  Underlying price: ${underlying_price:.2f}")
        logger.info(f"  Options contracts: {len(options)}")
        
        # Find arbitrage opportunities
        opportunities = scanner.scan_all_strategies(options, underlying_price)
        
        if opportunities:
            logger.info(f"  Found {len(opportunities)} potential opportunities")
            
            for opp in opportunities[:3]:  # Top 3
                # Risk evaluation
                evaluation = risk_manager.evaluate_opportunity(opp, approved_trades)
                
                if evaluation['approved']:
                    logger.info(f"\n  ✅ APPROVED: {opp.strategy_type}")
                    logger.info(f"     Profit: ${opp.execution_profit:.2f}")
                    logger.info(f"     Probability: {opp.probability:.1%}")
                    logger.info(f"     Position size: {evaluation['position_size']} contracts")
                    logger.info(f"     Sharpe ratio: {evaluation['risk_metrics']['sharpe_ratio']:.2f}")
                    
                    # Execute the trade
                    execution = await executor.execute_opportunity(opp, evaluation['position_size'])
                    logger.info(f"     Executed! Total cost: ${execution['total_cost']:.2f}")
                    
                    approved_trades.append(opp)
                else:
                    logger.info(f"\n  ❌ REJECTED: {opp.strategy_type}")
                    logger.info(f"     Reasons: {', '.join(evaluation['reasons'])}")
        
        all_opportunities.extend(opportunities)
    
    # Summary statistics
    logger.info("\n" + "="*60)
    logger.info("📈 ARBITRAGE SCAN SUMMARY")
    logger.info("="*60)
    logger.info(f"Total opportunities found: {len(all_opportunities)}")
    logger.info(f"Approved trades: {len(approved_trades)}")
    
    if approved_trades:
        total_profit = sum(opp.execution_profit for opp in approved_trades)
        avg_probability = np.mean([opp.probability for opp in approved_trades])
        
        logger.info(f"Expected profit: ${total_profit:.2f}")
        logger.info(f"Average win probability: {avg_probability:.1%}")
        
        # Strategy breakdown
        strategy_counts = defaultdict(int)
        for opp in approved_trades:
            strategy_counts[opp.strategy_type] += 1
        
        logger.info("\nStrategy breakdown:")
        for strategy, count in strategy_counts.items():
            logger.info(f"  {strategy}: {count} trades")
    
    logger.info("\n💡 Key Insights:")
    logger.info("• Longer-dated options have wider bid-ask spreads, reducing arbitrage profits")
    logger.info("• Put-call parity violations are rare but offer high probability when found")
    logger.info("• Calendar spreads based on volatility term structure show promise")
    logger.info("• Execution complexity increases with more legs, affecting fill probability")
    logger.info("• GPU acceleration enables scanning thousands of combinations in milliseconds")
    
    logger.info("\n🔧 System Capabilities:")
    logger.info("✅ GPU-accelerated Black-Scholes, Binomial, and Monte Carlo pricing")
    logger.info("✅ Heston stochastic volatility model for better accuracy")
    logger.info("✅ Real-time volatility surface analysis")
    logger.info("✅ Multiple arbitrage strategy detection")
    logger.info("✅ Risk-adjusted position sizing")
    logger.info("✅ Execution cost modeling")
    
    return all_opportunities, approved_trades

if __name__ == "__main__":
    asyncio.run(main()