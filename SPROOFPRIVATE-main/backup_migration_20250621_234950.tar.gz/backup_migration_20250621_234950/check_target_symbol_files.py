#!/usr/bin/env python3
"""
Check Target Symbol Files
This script specifically checks for AAPL.csv, MSFT.csv, and GOOGL.csv files in the stocks-2010-2025 directory
and analyzes their content for 2023-01-03 data.
"""

import pandas as pd
import json
import requests
from datetime import datetime, timedelta
import logging
import re
import os
from typing import Dict, List, Any
import warnings
warnings.filterwarnings('ignore')

# Set up logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('target_symbol_files.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TargetSymbolFileChecker:
    def __init__(self):
        """Initialize the target symbol file checker."""
        self.base_url = "https://uschristmas.us"
        self.bucket = "stockdb"
        self.target_symbols = ["AAPL", "MSFT", "GOOGL"]
        self.target_date = "2023-01-03"
        
        self.results = {}
            "check_timestamp": datetime.now().isoformat(),
            "target_date": self.target_date,
            "symbol_files": {},
            "data_availability": {},
            "recommendations": []
        }

    def check_symbol_file_exists(self, symbol: str) -> Dict[str, Any]:
        """Check if a symbol file exists and get its metadata."""
        logger.info(f"Checking for {symbol}.csv file...")
        
        file_info = {}
            "symbol": symbol,
            "filename": f"stocks-2010-2025/{symbol}.csv",
            "exists": False,
            "size": None,
            "last_modified": None,
            "content_type": None,
            "error": None
        }
        
        try:
            url = f"{self.base_url}/{self.bucket}/stocks-2010-2025/{symbol}.csv"
            response = requests.head(url)
            
            if response.status_code == 200:
                file_info.update({)
                    "exists": True,
                    "size": response.headers.get('Content-Length', 'unknown'),
                    "last_modified": response.headers.get('Last-Modified', 'unknown'),
                    "content_type": response.headers.get('Content-Type', 'unknown')
                })
                logger.info(f"✅ {symbol}.csv exists (size: {file_info['size']} bytes)")
            else:
                file_info["error"] = f"HTTP {response.status_code}"
                logger.info(f"❌ {symbol}.csv not found (HTTP {response.status_code})")
                
        except Exception as e:
            file_info["error"] = str(e)
            logger.error(f"Error checking {symbol}.csv: {str(e)}")
        
        return file_info

    def download_and_analyze_symbol_file(self, symbol: str) -> Dict[str, Any]:
        """Download and analyze a symbol file for the target date."""
        logger.info(f"Downloading and analyzing {symbol}.csv...")
        
        analysis = {}
            "symbol": symbol,
            "downloadable": False,
            "contains_target_date": False,
            "date_range": {},
            "target_date_data": None,
            "total_records": 0,
            "sample_records": [],
            "data_quality": {},
            "error": None
        }
        
        try:
            url = f"{self.base_url}/{self.bucket}/stocks-2010-2025/{symbol}.csv"
            response = requests.get(url)
            
            if response.status_code == 200:
                analysis["downloadable"] = True
                
                # Parse CSV content
                lines = response.text.strip().split('\n')
                if lines:
                    # Analyze header
                    header = lines[0]
                    columns = header.split(',')
                    analysis["columns"] = columns
                    
                    # Analyze data
                    data_lines = lines[1:] if len(lines) > 1 else []
                    analysis["total_records"] = len(data_lines)
                    
                    # Sample first few records
                    analysis["sample_records"] = data_lines[:5]
                    
                    # Look for target date and analyze date range
                    all_dates = []
                    target_date_record = None
                    
                    for line in data_lines:
                        fields = line.split(',')
                        if len(fields) >= len(columns):
                            # Assume first column with date pattern is the date column
                            for field in fields:
                                if re.match(r'\d{4}-\d{2}-\d{2}', field.strip()):
                                    date_value = field.strip()
                                    all_dates.append(date_value)
                                    
                                    # Check if this is our target date
                                    if date_value == self.target_date:
                                        analysis["contains_target_date"] = True
                                        target_date_record = line
                                        logger.info(f"🎯 Found {self.target_date} data for {symbol}!")
                                    break
                    
                    # Analyze date range
                    if all_dates:
                        unique_dates = sorted(set(all_dates))
                        analysis["date_range"] = {}
                            "earliest": unique_dates[0],
                            "latest": unique_dates[-1],
                            "total_unique_dates": len(unique_dates),
                            "sample_dates": unique_dates[:10]
                        }
                        
                        # Check if 2023 data exists
                        dates_2023 = [d for d in unique_dates if d.startswith('2023')]
                        analysis["contains_2023_data"] = len(dates_2023) > 0
                        analysis["2023_date_count"] = len(dates_2023)
                        
                        if dates_2023:
                            analysis["2023_date_range"] = {}
                                "earliest": dates_2023[0],
                                "latest": dates_2023[-1],
                                "sample_2023_dates": dates_2023[:10]
                            }
                    
                    # Store target date record if found
                    if target_date_record:
                        analysis["target_date_data"] = {}
                            "raw_record": target_date_record,
                            "parsed_data": dict(zip(columns, target_date_record.split(',')))
                        }
                    
                    # Data quality assessment
                    analysis["data_quality"] = {}
                        "has_header": len(columns) > 1,
                        "consistent_fields": len(set(len(line.split(',')) for line in data_lines[:10])) == 1,
                        "appears_valid": len(columns) >= 5,  # Expect at least symbol, date, open, high, low, close, volume
                        "date_format_consistent": len(all_dates) > 0
                    }
                    
                    logger.info(f"✅ {symbol}: {analysis['total_records']} records, date range {analysis['date_range'].get('earliest', 'N/A')} to {analysis['date_range'].get('latest', 'N/A')}")
                    
                else:
                    analysis["error"] = "File appears to be empty"
            else:
                analysis["error"] = f"HTTP {response.status_code}"
                
        except Exception as e:
            analysis["error"] = str(e)
            logger.error(f"Error analyzing {symbol}.csv: {str(e)}")
        
        return analysis

    def check_all_target_symbols(self) -> Dict[str, Any]:
        """Check all target symbol files."""
        logger.info("Checking all target symbol files...")
        
        for symbol in self.target_symbols:
            # Check if file exists
            file_info = self.check_symbol_file_exists(symbol)
            self.results["symbol_files"][symbol] = file_info
            
            # If file exists, analyze its content
            if file_info["exists"]:
                analysis = self.download_and_analyze_symbol_file(symbol)
                self.results["data_availability"][symbol] = analysis
        
        # Generate summary and recommendations
        self.generate_summary()
        
        return self.results

    def generate_summary(self):
        """Generate summary and recommendations."""
        logger.info("Generating summary and recommendations...")
        
        # Count symbols found
        symbols_exist = sum(1 for info in self.results["symbol_files"].values() if info["exists"])
        symbols_with_target_date = sum(1 for analysis in self.results["data_availability"].values() 
                                     if analysis.get("contains_target_date", False))
        symbols_with_2023 = sum(1 for analysis in self.results["data_availability"].values() 
                              if analysis.get("contains_2023_data", False))
        
        recommendations = []
        
        if symbols_exist > 0:
            recommendations.append(f"✅ SYMBOL FILES: {symbols_exist}/3 target symbol files found")
            
            if symbols_with_target_date > 0:
                recommendations.append(f"🎯 TARGET DATE SUCCESS: {symbols_with_target_date}/3 symbols have {self.target_date} data")
                
                # List symbols with target date
                symbols_with_data = [symbol for symbol, analysis in self.results["data_availability"].items()]
                                   if analysis.get("contains_target_date", False)]
                recommendations.append(f"   • Symbols with {self.target_date}: {', '.join(symbols_with_data)}")
                
                recommendations.extend([)
                    "🚀 READY FOR INTEGRATION: Same-day algorithm can access this data",
                    "📊 DATA PATH: stocks-2010-2025/{SYMBOL}.csv format",
                    "⚡ PERFORMANCE: Consider caching these files locally"
                ])
            
            elif symbols_with_2023 > 0:
                recommendations.append(f"📅 2023 DATA: {symbols_with_2023}/3 symbols have 2023 data (but not {self.target_date})")
                recommendations.append("🔍 CHECK: Verify if 2023-01-03 was a trading day or holiday")
            
            else:
                recommendations.append(f"⚠️ LIMITED: Symbol files exist but may not contain 2023 data")
                
                # Show date ranges
                for symbol, analysis in self.results["data_availability"].items():
                    if analysis.get("date_range"):
                        date_range = analysis["date_range"]
                        recommendations.append(f"   • {symbol}: {date_range['earliest']} to {date_range['latest']}")
        
        else:
            recommendations.extend([)
                "❌ No target symbol files found in stocks-2010-2025/",
                "🔍 ALTERNATIVE: Check other directories or file naming patterns",
                "📞 VERIFY: Confirm symbol file availability and naming conventions"
            ])
        
        self.results["recommendations"] = recommendations

    def save_results(self, filename: str = None):
        """Save results to file."""
        if filename is None:
            filename = f"target_symbol_check_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        logger.info(f"Results saved to {filename}")
        return filename

def main():
    """Main execution function."""
    logger.info("Starting target symbol file check...")
    
    try:
        checker = TargetSymbolFileChecker()
        results = checker.check_all_target_symbols()
        
        # Save results
        results_file = checker.save_results()
        
        # Print comprehensive report
        print("\n" + "="*80)
        print("TARGET SYMBOL FILE CHECK RESULTS")
        print("="*80)
        
        print(f"\nCheck completed at: {results['check_timestamp']}")
        print(f"Target date: {results['target_date']}")
        
        # Symbol file availability
        print(f"\n📁 SYMBOL FILE AVAILABILITY:")
        for symbol, file_info in results["symbol_files"].items():
            if file_info["exists"]:
                size_mb = round(int(file_info["size"]) / (1024 * 1024), 2) if file_info["size"] != "unknown" else "unknown"
                print(f"  • {symbol}.csv: EXISTS ✅ (size: {size_mb} MB)")
            else:
                print(f"  • {symbol}.csv: NOT FOUND ❌ ({file_info.get('error', 'unknown error')})")
        
        # Data availability analysis
        if results["data_availability"]:
            print(f"\n📊 DATA AVAILABILITY ANALYSIS:")
            for symbol, analysis in results["data_availability"].items():
                if analysis["downloadable"]:
                    print(f"\n  {symbol}:")
                    print(f"    - Total records: {analysis['total_records']:,}")
                    
                    if analysis["date_range"]:
                        date_range = analysis["date_range"]
                        print(f"    - Date range: {date_range['earliest']} to {date_range['latest']}")
                        print(f"    - Unique dates: {date_range['total_unique_dates']:,}")
                    
                    print(f"    - Contains 2023 data: {analysis.get('contains_2023_data', False)}")
                    if analysis.get("2023_date_count", 0) > 0:
                        print(f"    - 2023 dates: {analysis['2023_date_count']}")
                        if analysis.get("2023_date_range"):
                            range_2023 = analysis["2023_date_range"]
                            print(f"    - 2023 range: {range_2023['earliest']} to {range_2023['latest']}")
                    
                    print(f"    - Contains target date ({results['target_date']}): {analysis['contains_target_date']} {'✅' if analysis['contains_target_date'] else '❌'}")
                    
                    if analysis["target_date_data"]:
                        target_data = analysis["target_date_data"]["parsed_data"]
                        print(f"    - Target date data:")
                        for key, value in target_data.items():
                            if key.lower() in ['trade_date', 'date', 'open', 'high', 'low', 'close', 'volume']:
                                print(f"      • {key}: {value}")
                else:
                    print(f"\n  {symbol}: NOT DOWNLOADABLE ❌ ({analysis.get('error', 'unknown error')})")
        
        # Recommendations
        print(f"\n💡 RECOMMENDATIONS:")
        for i, rec in enumerate(results["recommendations"], 1):
            print(f"  {i}. {rec}")
        
        print(f"\n📄 Full results saved to: {results_file}")
        print("="*80)
        
        return results
        
    except Exception as e:
        logger.error(f"Check failed: {str(e)}")
        raise

if __name__ == "__main__":
    main()