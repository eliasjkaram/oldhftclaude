
#!/usr/bin/env python3
"""
Data API Integration Example
============================

Shows how to integrate the UnifiedDataAPI into existing trading systems
with minimal code changes.
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import pandas as pd
from datetime import datetime, timedelta
import logging

# Import the unified data API
from data_api_fixer import UnifiedDataAPI

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TradingSystemWithUnifiedData:
    """Example trading system using the unified data API"""
    
    def __init__(self):
        # Initialize the unified data API
        self.data_api = UnifiedDataAPI()
        
        # Trading parameters
        self.symbols = ['AAPL', 'MSFT', 'GOOGL', 'SPY', 'QQQ']
        self.lookback_days = 30
        
    def get_historical_data(self, symbol: str, days: int = 30) -> pd.DataFrame:
        """
        Get historical data with automatic fallback
        
        This replaces the old method that might have used:
        - yfinance directly (with potential errors)
        - Alpaca API (with potential rate limits)
        - Manual error handling
        """
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # The UnifiedDataAPI handles all error cases automatically
        return self.data_api.fetch_data()
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            interval='1d'
        )
        
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators"""
        if df.empty or 'close' not in df.columns:
            return df
            
        # Simple Moving Averages
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0).rolling(window=14).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=14).mean())
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs)
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(window=20).mean()
        bb_std = df['close'].rolling(window=20).std()
        df['bb_upper'] = df['bb_middle'] + (bb_std * 2)
        df['bb_lower'] = df['bb_middle'] - (bb_std * 2)
        
        return df
        
    def scan_for_opportunities(self):
        """Scan multiple symbols for trading opportunities"""
        print("\n🔍 Scanning for Trading Opportunities")
        print("=" * 50)
        
        opportunities = []
        
        # Fetch data for all symbols in parallel
        all_data = self.data_api.fetch_multiple_symbols()
            self.symbols,
            interval='1d',
            parallel=True
        )
        
        for symbol, df in all_data.items():
            if df.empty:
                logger.warning(f"No data available for {symbol}")
                continue
                
            # Calculate indicators
            df = self.calculate_indicators(df)
            
            # Skip if not enough data
            if len(df) < 50:
                continue
                
            # Get latest values
            latest = df.iloc[-1]
            prev = df.iloc[-2]
            
            # Check for opportunities
            opportunity = None
            
            # Bullish signals
            if (latest['close'] > latest['sma_20'] > latest['sma_50'] and)
                prev['close'] <= prev['sma_20']):
                opportunity = 'Bullish Crossover'
                
            # Oversold bounce
            elif latest['rsi'] < 30 and latest['close'] > prev['close']:
                opportunity = 'Oversold Bounce'
                
            # Bollinger Band squeeze
            elif (latest['close'] < latest['bb_lower'] and)
                  latest['close'] > prev['close']):
                opportunity = 'BB Reversal'
                
            if opportunity:
                opportunities.append({)
                    'symbol': symbol,
                    'signal': opportunity,
                    'price': latest['close'],
                    'rsi': latest['rsi'],
                    'volume': latest['volume']
                })
                
        return opportunities
        
    def get_options_opportunities(self, symbol: str):
        """Find options trading opportunities"""
        print(f"\n📊 Analyzing Options for {symbol}")
        print("-" * 40)
        
        # Get current stock price
        latest_price = self.data_api.get_latest_price(symbol)
        if not latest_price:
            print(f"Could not get current price for {symbol}")
            return
            
        print(f"Current price: ${latest_price:.2f}")
        
        # Get options chain
        options = self.data_api.get_options_chain(symbol)
        if options.empty:
            print("No options data available")
            return
            
        # Filter for interesting options
        # ATM calls and puts
        atm_strike = round(latest_price / 5) * 5  # Round to nearest $5
        
        atm_options = options[]
            (options['strike'] >= atm_strike - 10) & 
            (options['strike'] <= atm_strike + 10)
        ]
        
        if not atm_options.empty:
            print(f"\nNear-the-money options (Strike: ${atm_strike})")
            print("-" * 40)
            
            for _, opt in atm_options.iterrows():
                if opt['volume'] > 100:  # Filter for liquid options
                    print(f"{opt['type'].upper()} Strike: ${opt['strike']:.0f}")
                    print(f"  Bid: ${opt['bid']:.2f}, Ask: ${opt['ask']:.2f}")
                    print(f"  Volume: {opt['volume']:,}, OI: {opt['openInterest']:,}")
                    print(f"  IV: {opt.get('impliedVolatility', 0)*100:.1f}%")
                    print()
                    
    def monitor_realtime(self):
        """Monitor real-time market conditions"""
        print("\n📈 Real-Time Market Monitor")
        print("=" * 50)
        
        # Check market status
        status = self.data_api.get_market_status()
        print(f"\nMarket Status: {'OPEN' if status['is_open'] else 'CLOSED'}")
        print(f"Extended Hours: {'YES' if status['is_extended_hours'] else 'NO'}")
        
        if not status['is_open'] and not status['is_extended_hours']:
            print(f"Next market open: {status['next_open']}")
            return
            
        # Get latest prices for watchlist
        print("\nCurrent Prices:")
        print("-" * 40)
        
        for symbol in self.symbols:
            price = self.data_api.get_latest_price(symbol)
            if price:
                # Get 1-day change
                try:
                    df = self.data_api.fetch_data(symbol, interval='1d')
                    if len(df) >= 2:
                        prev_close = df['close'].iloc[-2]
                        change = ((price - prev_close) / prev_close) * 100
                        emoji = "🟢" if change > 0 else "🔴"
                        print(f"{emoji} {symbol}: ${price:.2f} ({change:+.2f}%)")
                    else:
                        print(f"⚪ {symbol}: ${price:.2f}")
                except:
                    print(f"⚪ {symbol}: ${price:.2f}")
            else:
                print(f"❌ {symbol}: No data")
                
    def backtest_strategy(self, symbol: str):
        """Simple backtest example using the unified data API"""
        print(f"\n📊 Backtesting Strategy for {symbol}")
        print("=" * 50)
        
        # Get historical data
        df = self.data_api.fetch_data()
            symbol=symbol,
            start_date=datetime.now() - timedelta(days=365),
            end_date=datetime.now(),
            interval='1d'
        )
        
        if df.empty:
            print("No data available for backtesting")
            return
            
        # Calculate indicators
        df = self.calculate_indicators(df)
        
        # Simple strategy: Buy when price crosses above SMA20, sell when below
        df['signal'] = 0
        df.loc[df['close'] > df['sma_20'], 'signal'] = 1
        df.loc[df['close'] < df['sma_20'], 'signal'] = -1
        
        # Calculate returns
        df['returns'] = df['close'].pct_change()
        df['strategy_returns'] = df['signal'].shift(1) * df['returns']
        
        # Calculate performance
        total_return = (df['strategy_returns'] + 1).prod() - 1
        sharpe_ratio = df['strategy_returns'].mean() / df['strategy_returns'].std() * (252**0.5)
        max_drawdown = (df['close'] / df['close'].cummax() - 1).min()
        
        print(f"Backtest Results ({len(df)} days):")
        print(f"  Total Return: {total_return*100:.2f}%")
        print(f"  Sharpe Ratio: {sharpe_ratio:.2f}")
        print(f"  Max Drawdown: {max_drawdown*100:.2f}%")
        print(f"  Win Rate: {(df['strategy_returns'] > 0).sum() / (df['strategy_returns'] != 0).sum()*100:.1f}%")


def main():
    """Demonstrate the integration"""
    print("\n" + "="*80)
    print("🚀 DATA API INTEGRATION DEMONSTRATION")
    print("="*80)
    print("\nThis example shows how to integrate the UnifiedDataAPI")
    print("into existing trading systems with minimal changes.")
    
    # Initialize trading system
    system = TradingSystemWithUnifiedData()
    
    # Run various trading system functions
    
    # 1. Scan for opportunities
    opportunities = system.scan_for_opportunities()
    if opportunities:
        print("\n✅ Found Trading Opportunities:")
        for opp in opportunities:
            print(f"  {opp['symbol']}: {opp['signal']} @ ${opp['price']:.2f} (RSI: {opp['rsi']:.1f})")
    else:
        print("\n❌ No trading opportunities found at this time")
        
    # 2. Monitor real-time prices
    system.monitor_realtime()
    
    # 3. Analyze options
    system.get_options_opportunities('SPY')
    
    # 4. Run backtest
    system.backtest_strategy('AAPL')
    
    # 5. Check system health
    print("\n🏥 System Health Check")
    print("=" * 50)
    health = system.data_api.health_check()
    print(f"Overall Status: {health['overall_status'].upper()}")
    for source, info in health['sources'].items():
        print(f"  {source}: {info.get('status', 'unknown')}")
        
    print("\n" + "="*80)
    print("✅ INTEGRATION DEMONSTRATION COMPLETE!")
    print("="*80)
    print("\nThe UnifiedDataAPI seamlessly replaces direct API calls")
    print("and provides automatic fallback, caching, and error handling.")
    print("\nSimply replace your data fetching calls with:")
    print("  data = api.fetch_data(symbol, start_date, end_date, interval)")
    print("\nThe API handles everything else automatically! 🎯")


if __name__ == "__main__":
    main()