#!/usr/bin/env python3
"""
Test script to verify all system fixes
"""

import sys
import traceback
from datetime import datetime

def test_imports():
    """Test all critical imports"""
    print("\n🔍 TESTING IMPORTS...")
    print("-" * 80)
    
    imports_status = {}
    
    # Test core imports
    core_imports = []
        ('pandas', 'pd'),
        ('numpy', 'np'),
        ('yfinance', 'yf'),
        ('alpaca_trade_api', 'REST'),
        ('zmq', 'zmq')  # pyzmq
    ]
    
    for module_name, alias in core_imports:
        try:
            if alias:
                exec(f"import {module_name} as {alias}")
            else:
                exec(f"import {module_name}")
            imports_status[module_name] = "✅ Success"
        except ImportError as e:
            imports_status[module_name] = f"❌ Failed: {e}"
    
    # Test local modules
    local_modules = []
        'robust_data_fetcher',
        'monte_carlo_backtesting',
        'portfolio_optimization_mpt'
    ]
    
    for module in local_modules:
        try:
            exec(f"import {module}")
            imports_status[module] = "✅ Success"
        except Exception as e:
            imports_status[module] = f"❌ Failed: {e}"
    
    # Print results
    for module, status in imports_status.items():
        print(f"  {module}: {status}")
    
    return all("Success" in status for status in imports_status.values())

def test_data_fetcher():
    """Test the robust data fetcher with fallbacks"""
    print("\n📊 TESTING DATA FETCHER...")
    print("-" * 80)
    
    try:
        from robust_data_fetcher import RobustDataFetcher
        
        # Test config
        config = {}
            'cache_duration_minutes': 30,
            'alpaca_api_key': 'test_key',
            'alpaca_secret': 'test_secret'
        }
        
        fetcher = RobustDataFetcher(config)
        print("  ✅ Data fetcher initialized")
        
        # Test fetching with yfinance (should work)
        try:
            data = fetcher.fetch_data('AAPL', '1d', '5d', source='yfinance')
            if not data.empty:
                print(f"  ✅ YFinance fetch successful: {len(data)} bars")
            else:
                print("  ⚠️ YFinance returned empty data")
        except Exception as e:
            print(f"  ❌ YFinance fetch failed: {e}")
        
        # Test synthetic data generation
        try:
            data = fetcher.fetch_data('TEST', '1h', '30d', source='synthetic')
            if not data.empty:
                print(f"  ✅ Synthetic data generation successful: {len(data)} bars")
            else:
                print("  ❌ Synthetic data generation failed")
        except Exception as e:
            print(f"  ❌ Synthetic data error: {e}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Data fetcher test failed: {e}")
        traceback.print_exc()
        return False

def test_monte_carlo():
    """Test Monte Carlo backtesting with array alignment fixes"""
    print("\n🎲 TESTING MONTE CARLO BACKTESTING...")
    print("-" * 80)
    
    try:
        from monte_carlo_backtesting import MonteCarloBacktester
        import numpy as np
        import pandas as pd
        
        backtester = MonteCarloBacktester()
        print("  ✅ Monte Carlo backtester initialized")
        
        # Generate test data
        returns = np.random.normal(0.001, 0.02, 100)
        prices = 100 * np.exp(np.cumsum(returns))
        # Ensure both arrays have same length
        historical_data = pd.DataFrame({)
            'close': prices,
            'returns': returns  # Same length as prices
        })
        
        # Test scenario generation
        scenarios = backtester.generate_scenarios()
            historical_data,
            n_scenarios=10,
            horizon_days=30,
            method='bootstrap'
        )
        print(f"  ✅ Generated {len(scenarios)} scenarios")
        
        # Test strategy simulation with proper signal alignment
        def test_strategy(prices):
            if len(prices) <= 1:
                return np.zeros(0)
            # Ensure signals are one less than prices for alignment
            signals = np.zeros(len(prices) - 1)
            mean_price = np.mean(prices)
            for i in range(len(signals)):
                signals[i] = 1 if prices[i] > mean_price else -1
            return signals
        
        # Run simulation
        results = backtester.run_strategy_simulation()
            test_strategy,
            scenarios[:5],
            transaction_cost=0.001
        )
        
        print("  ✅ Strategy simulation completed")
        
        # Test risk metrics
        metrics = backtester.calculate_risk_metrics()
        print(f"  ✅ Risk metrics calculated: Expected return = {metrics['mean_return']:.2%}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Monte Carlo test failed: {e}")
        traceback.print_exc()
        return False

def test_portfolio_optimization():
    """Test portfolio optimization with data fallback"""
    print("\n💼 TESTING PORTFOLIO OPTIMIZATION...")
    print("-" * 80)
    
    try:
        from portfolio_optimization_mpt import ModernPortfolioTheory
        import pandas as pd
        
        # Test with Alpaca config
        alpaca_config = {}
            'alpaca_api_key': 'test_key',
            'alpaca_secret': 'test_secret'
        }
        
        optimizer = ModernPortfolioTheory(alpaca_config=alpaca_config)
        print("  ✅ Portfolio optimizer initialized with Alpaca config")
        
        # Test data fetching with fallback
        symbols = ['AAPL', 'MSFT', 'GOOGL']
        
        # Fetch data using the new method
        if hasattr(optimizer, 'fetch_historical_data'):
            returns_data = optimizer.fetch_historical_data(symbols, period='1mo')
            if not returns_data.empty:
                print(f"  ✅ Fetched data for {len(returns_data.columns)} symbols")
            else:
                print("  ⚠️ No data fetched, using synthetic data")
                # Create synthetic returns
                returns_data = pd.DataFrame()
                    np.random.normal(0.001, 0.02, (100, len(symbols))),
                    columns=symbols
                )
        
        # Test optimization
        result = optimizer.optimize_portfolio(returns_data, objective='sharpe')
        print(f"  ✅ Optimization completed: Sharpe = {result['metrics']['sharpe_ratio']:.2f}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Portfolio optimization test failed: {e}")
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("=" * 80)
    print("🔧 SYSTEM FIXES VERIFICATION")
    print("=" * 80)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Run tests
    tests = []
        ("Import Tests", test_imports),
        ("Data Fetcher", test_data_fetcher),
        ("Monte Carlo Backtesting", test_monte_carlo),
        ("Portfolio Optimization", test_portfolio_optimization)
    ]
    
    results = {}
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"\n❌ {test_name} crashed: {e}")
            results[test_name] = False
    
    # Summary
    print("\n" + "=" * 80)
    print("📋 TEST SUMMARY")
    print("=" * 80)
    
    total_tests = len(results)
    passed_tests = sum(1 for v in results.values() if v)
    
    print(f"\nTotal Tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {total_tests - passed_tests}")
    print(f"Success Rate: {(passed_tests/total_tests)*100:.0f}%")
    
    print("\nDetailed Results:")
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status} - {test_name}")
    
    if passed_tests == total_tests:
        print("\n🎉 ALL FIXES VERIFIED - SYSTEM READY!")
    else:
        print("\n⚠️ Some tests failed - please review the output")
    
    print(f"\nCompleted at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

if __name__ == "__main__":
    main()