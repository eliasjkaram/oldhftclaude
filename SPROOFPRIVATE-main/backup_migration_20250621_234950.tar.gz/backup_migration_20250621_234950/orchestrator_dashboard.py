
#!/usr/bin/env python3
"""
Orchestrator Dashboard
Real-time monitoring dashboard for the Master Orchestrator V2
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import sqlite3
import os
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
import argparse

class OrchestratorDashboard:
    """Dashboard for monitoring orchestrator status"""
    
    def __init__(self, db_path: str = '/home/harry/alpaca-mcp/orchestration_v2.db'):
        self.db_path = db_path
        
    def get_process_status(self) -> List[Dict]:
        """Get current status of all processes"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get latest status for each process
        query = '''
        WITH latest_status AS ()
            SELECT process_name, MAX(timestamp) as latest_time
            FROM process_status
            WHERE timestamp > datetime('now', '-5 minutes')
            GROUP BY process_name
        )
        SELECT ps.process_name, ps.pid, ps.status, ps.cpu_percent, 
               ps.memory_mb, ps.restart_count, ps.health_score, ps.timestamp
        FROM process_status ps
        INNER JOIN latest_status ls 
            ON ps.process_name = ls.process_name 
            AND ps.timestamp = ls.latest_time
        ORDER BY ps.process_name
        '''
        
        cursor.execute(query)
        columns = [desc[0] for desc in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row))
            
        conn.close()
        return results
        
    def get_recent_events(self, severity: str = None, limit: int = 20) -> List[Dict]:
        """Get recent orchestration events"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if severity:
            query = '''
            SELECT timestamp, event_type, process_name, description, severity
            FROM orchestration_events
            WHERE severity = ?
            ORDER BY timestamp DESC
            LIMIT ?
            '''
            cursor.execute(query, (severity, limit)
        else:
            query = '''
            SELECT timestamp, event_type, process_name, description, severity
            FROM orchestration_events
            ORDER BY timestamp DESC
            LIMIT ?
            '''
            cursor.execute(query, (limit,)
            
        columns = [desc[0] for desc in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row))
            
        conn.close()
        return results
        
    def get_resource_usage(self, hours: int = 1) -> List[Dict]:
        """Get system resource usage history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
        SELECT timestamp, system_cpu_percent, system_memory_percent,
               total_processes, healthy_processes
        FROM resource_usage
        WHERE timestamp > datetime('now', '-{} hours')
        ORDER BY timestamp DESC
        '''.format(hours)
        
        cursor.execute(query)
        columns = [desc[0] for desc in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row))
            
        conn.close()
        return results
        
    def get_process_errors(self, process_name: str = None, limit: int = 10) -> List[Dict]:
        """Get recent process errors"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if process_name:
            query = '''
            SELECT timestamp, process_name, error_type, error_message
            FROM process_errors
            WHERE process_name = ?
            ORDER BY timestamp DESC
            LIMIT ?
            '''
            cursor.execute(query, (process_name, limit)
        else:
            query = '''
            SELECT timestamp, process_name, error_type, error_message
            FROM process_errors
            ORDER BY timestamp DESC
            LIMIT ?
            '''
            cursor.execute(query, (limit,)
            
        columns = [desc[0] for desc in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row))
            
        conn.close()
        return results
        
    def get_health_summary(self) -> Dict:
        """Get overall system health summary"""
        processes = self.get_process_status()
        resources = self.get_resource_usage(hours=1)
        recent_errors = self.get_process_errors(limit=50)
        recent_warnings = self.get_recent_events(severity='WARNING', limit=50)
        
        # Calculate metrics
        total_processes = len(processes)
        running_processes = sum(1 for p in processes if p['status'] == 'running')
        healthy_processes = sum(1 for p in processes if p.get('health_score', 0) >= 50)
        
        avg_health = sum(p.get('health_score', 0) for p in processes) / total_processes if total_processes > 0 else 0
        
        # Resource averages
        if resources:
            avg_cpu = sum(r['system_cpu_percent'] for r in resources) / len(resources)
            avg_memory = sum(r['system_memory_percent'] for r in resources) / len(resources)
        else:
            avg_cpu = avg_memory = 0
            
        # Error rates
        error_count_1h = len([e for e in recent_errors if datetime.fromisoformat(e['timestamp']) > datetime.now() - timedelta(hours=1)])
        warning_count_1h = len([w for w in recent_warnings if datetime.fromisoformat(w['timestamp']) > datetime.now() - timedelta(hours=1)])
        
        return {}
            'timestamp': datetime.now().isoformat(),
            'total_processes': total_processes,
            'running_processes': running_processes,
            'healthy_processes': healthy_processes,
            'average_health_score': avg_health,
            'average_cpu_percent': avg_cpu,
            'average_memory_percent': avg_memory,
            'errors_last_hour': error_count_1h,
            'warnings_last_hour': warning_count_1h
        }
        
    def print_dashboard(self):
        """Print formatted dashboard"""
        os.system('clear' if os.name == 'posix' else 'cls')
        
        print("="*80)
        print("ORCHESTRATOR DASHBOARD V2".center(80)
        print("="*80)
        print(f"Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # Health Summary
        summary = self.get_health_summary()
        print("SYSTEM HEALTH SUMMARY:")
        print(f"  Overall Health: {summary['average_health_score']:.1f}/100")
        print(f"  Processes: {summary['running_processes']}/{summary['total_processes']} running, {summary['healthy_processes']} healthy")
        print(f"  CPU Usage: {summary['average_cpu_percent']:.1f}%")
        print(f"  Memory Usage: {summary['average_memory_percent']:.1f}%")
        print(f"  Errors (1h): {summary['errors_last_hour']}")
        print(f"  Warnings (1h): {summary['warnings_last_hour']}")
        print()
        
        # Process Status
        print("PROCESS STATUS:")
        print("-"*80)
        print(f"{'Process':<25} {'PID':<8} {'Status':<12} {'Health':<8} {'CPU%':<8} {'Mem(MB)':<10} {'Restarts':<10}")
        print("-"*80)
        
        processes = self.get_process_status()
        for proc in processes:
            health_indicator = self._get_health_indicator(proc.get('health_score', 0)
            print(f"{proc['process_name']:<25} ")
                  f"{proc['pid']:<8} "
                  f"{proc['status']:<12} "
                  f"{health_indicator} {proc.get('health_score', 0):>5.1f} "
                  f"{proc.get('cpu_percent', 0):>7.1f} "
                  f"{proc.get('memory_mb', 0):>9.1f} "
                  f"{proc.get('restart_count', 0):>9}")
                  
        print()
        
        # Recent Events
        print("RECENT EVENTS:")
        print("-"*80)
        
        events = self.get_recent_events(limit=10)
        for event in events[:5]:
            severity_indicator = self._get_severity_indicator(event['severity'])
            timestamp = datetime.fromisoformat(event['timestamp']).strftime('%H:%M:%S')
            print(f"{timestamp} {severity_indicator} [{event['process_name']}] {event['event_type']}: {event['description'][:50]}")
            
    def _get_health_indicator(self, health_score: float) -> str:
        """Get visual indicator for health score"""
        if health_score >= 80:
            return "🟢"
        elif health_score >= 50:
            return "🟡"
        else:
            return "🔴"
            
    def _get_severity_indicator(self, severity: str) -> str:
        """Get visual indicator for severity"""
        indicators = {}
            'INFO': 'ℹ️ ',
            'WARNING': '⚠️ ',
            'ERROR': '❌',
            'CRITICAL': '🚨'
        }
        return indicators.get(severity, '  ')
        
    def generate_report(self, output_file: str = None):
        """Generate detailed report"""
        report = []
        report.append("ORCHESTRATOR DETAILED REPORT")
        report.append("="*80)
        report.append(f"Generated: {datetime.now()}")
        report.append("")
        
        # Summary
        summary = self.get_health_summary()
        report.append("EXECUTIVE SUMMARY:")
        report.append(f"  System Health Score: {summary['average_health_score']:.1f}/100")
        report.append(f"  Total Processes: {summary['total_processes']}")
        report.append(f"  Running Processes: {summary['running_processes']}")
        report.append(f"  Healthy Processes: {summary['healthy_processes']}")
        report.append("")
        
        # Process Details
        report.append("PROCESS DETAILS:")
        processes = self.get_process_status()
        for proc in processes:
            report.append(f"\n{proc['process_name']}:")
            report.append(f"  Status: {proc['status']}")
            report.append(f"  Health Score: {proc.get('health_score', 0):.1f}")
            report.append(f"  CPU Usage: {proc.get('cpu_percent', 0):.1f}%")
            report.append(f"  Memory Usage: {proc.get('memory_mb', 0):.1f} MB")
            report.append(f"  Restart Count: {proc.get('restart_count', 0)}")
            
            # Recent errors for this process
            errors = self.get_process_errors(process_name=proc['process_name'], limit=3)
            if errors:
                report.append("  Recent Errors:")
                for error in errors:
                    report.append(f"    - {error['error_type']}: {error['error_message'][:100]}")
                    
        # System Events
        report.append("\n\nSYSTEM EVENTS (Last 24 Hours):")
        events = self.get_recent_events(limit=100)
        
        # Group by severity
        by_severity = {'CRITICAL': [], 'ERROR': [], 'WARNING': [], 'INFO': []}
        for event in events:
            if datetime.fromisoformat(event['timestamp']) > datetime.now() - timedelta(hours=24):
                by_severity[event['severity']].append(event)
                
        for severity in ['CRITICAL', 'ERROR', 'WARNING']:
            if by_severity[severity]:
                report.append(f"\n{severity} Events ({len(by_severity[severity])}):")
                for event in by_severity[severity][:10]:
                    report.append(f"  {event['timestamp']} - {event['process_name']}: {event['description']}")
                    
        # Resource Usage Trends
        report.append("\n\nRESOURCE USAGE TRENDS (Last Hour):")
        resources = self.get_resource_usage(hours=1)
        if resources:
            cpu_values = [r['system_cpu_percent'] for r in resources]
            mem_values = [r['system_memory_percent'] for r in resources]
            
            report.append(f"  CPU - Min: {min(cpu_values):.1f}%, Max: {max(cpu_values):.1f}%, Avg: {sum(cpu_values)/len(cpu_values):.1f}%")
            report.append(f"  Memory - Min: {min(mem_values):.1f}%, Max: {max(mem_values):.1f}%, Avg: {sum(mem_values)/len(mem_values):.1f}%")
            
        # Output
        report_text = '\n'.join(report)
        
        if output_file:
            with open(output_file, 'w') as f:
                f.write(report_text)
            print(f"Report saved to: {output_file}")
        else:
            print(report_text)
            
def main():
    """Main dashboard function"""
    parser = argparse.ArgumentParser(description='Orchestrator Dashboard')
    parser.add_argument('--report', action='store_true',
                       help='Generate detailed report')
    parser.add_argument('--output', type=str,
                       help='Output file for report')
    parser.add_argument('--watch', action='store_true',
                       help='Continuously update dashboard')
    parser.add_argument('--interval', type=int, default=30,
                       help='Update interval in seconds (default: 30)')
    args = parser.parse_args()
    
    dashboard = OrchestratorDashboard()
    
    if args.report:
        dashboard.generate_report(args.output)
    elif args.watch:
        import time
        try:
            while True:
                dashboard.print_dashboard()
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\nDashboard stopped")
    else:
        dashboard.print_dashboard()

if __name__ == "__main__":
    main()