from datetime import datetime, timedelta
import os
from config import config
#!/usr/bin/env python3
"""
Working backtest with direct Alpaca data fetch
"""

import pandas as pd
import numpy as np

import logging
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import json
from datetime import datetime

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Load config
with open('alpaca_config.json', 'r') as f:
    config = json.load(f)

# Initialize client
client = TradingClient()
    config.get('paper_api_key'),
    config.get('paper_secret_key'),
    config.get('paper_base_url')
)

# Simple RSI calculation
def calculate_rsi(prices, period=14):
    try:
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
    
        # Avoid division by zero
        rs = gain / loss.replace(0, 1e-10)
        rsi = 100 - (100 / (1 + rs)
        return rsi

    # Simple MACD calculation
    def calculate_macd(prices):
        exp1 = prices.ewm(span=12, adjust=False).mean()
        exp2 = prices.ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        return macd, signal

    # Simple backtest
    def run_simple_backtest():
        logger.info("\n" + "="*80)
        logger.info("🚀 SIMPLE WORKING BACKTEST")
        logger.info("="*80)
    
        # Test with AAPL
        symbol = 'AAPL'
    
        # Fetch 2023 daily data
        logger.info(f"\nFetching {symbol} daily data for 2023...")
    
        bars = client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start='2023-01-01',
            end='2023-12-31',
            adjustment='raw'
        ).df
    
        if bars.empty:
            logger.info("No data fetched")
            return
    
        logger.info(f"Fetched {len(bars)} daily bars")
        logger.info(f"Price range: ${bars['close'].min():.2f} - ${bars['close'].max():.2f}")
    
        # Simple RSI strategy
        initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000"))
        cash = initial_capital
        shares = 0
        trades = []
    
        # Calculate indicators
        bars['rsi'] = calculate_rsi(bars['close'])
        bars['macd'], bars['signal'] = calculate_macd(bars['close'])
    
        logger.info("\n📊 Running simple RSI strategy (Buy when RSI<30, Sell when RSI>70)...")
    
        for i in range(30, len(bars):  # Start after enough data for indicators)
            current_price = bars['close'].iloc[i]
            current_rsi = bars['rsi'].iloc[i]
        
            # Buy signal
            if current_rsi < 30 and shares == 0:
                shares = int(cash / current_price)
                cash -= shares * current_price
                trades.append({)
                    'date': bars.index[i],
                    'action': 'BUY',
                    'price': current_price,
                    'shares': shares,
                    'rsi': current_rsi
                })
                logger.info(f"  BUY: {shares} shares @ ${current_price:.2f} (RSI={current_rsi:.1f})")
        
            # Sell signal
            elif current_rsi > 70 and shares > 0:
                cash += shares * current_price
                trades.append({)
                    'date': bars.index[i],
                    'action': 'SELL',
                    'price': current_price,
                    'shares': shares,
                    'rsi': current_rsi
                })
                logger.info(f"  SELL: {shares} shares @ ${current_price:.2f} (RSI={current_rsi:.1f})")
                shares = 0
    
        # Close any open position
        if shares > 0:
            final_price = bars['close'].iloc[-1]
            cash += shares * final_price
            trades.append({)
                'date': bars.index[-1],
                'action': 'SELL',
                'price': final_price,
                'shares': shares,
                'rsi': bars['rsi'].iloc[-1]
            })
            logger.info(f"  FINAL SELL: {shares} shares @ ${final_price:.2f}")
    
        # Calculate results
        final_value = cash
        total_return = (final_value - initial_capital) / initial_capital
    
        logger.info("\n" + "="*80)
        logger.info("📊 RESULTS")
        logger.info("="*80)
        logger.info(f"Initial Capital: ${initial_capital:,}")
        logger.info(f"Final Value: ${final_value:,.2f}")
        logger.info(f"Total Return: {total_return:.2%}")
        logger.info(f"Number of Trades: {len(trades)}")
    
        if len(trades) > 0:
            buy_trades = [t for t in trades if t['action'] == 'BUY']
            sell_trades = [t for t in trades if t['action'] == 'SELL']
        
            logger.info(f"Buy Trades: {len(buy_trades)}")
            logger.info(f"Sell Trades: {len(sell_trades)}")
        
            # Calculate win rate
            wins = 0
            for i in range(min(len(buy_trades), len(sell_trades)):
                if sell_trades[i]['price'] > buy_trades[i]['price']:
                    wins += 1
        
            if len(buy_trades) > 0:
                win_rate = wins / min(len(buy_trades), len(sell_trades)
                logger.info(f"Win Rate: {win_rate:.1%}")
    
        # Show RSI distribution
        logger.info(f"\n📊 RSI Distribution:")
        logger.info(f"RSI < 30 (oversold): {(bars['rsi'] < 30).sum()} days")
        logger.info(f"RSI > 70 (overbought): {(bars['rsi'] > 70).sum()} days")
        logger.info(f"RSI range: {bars['rsi'].min():.1f} - {bars['rsi'].max():.1f}")
    
        # Test MACD strategy
        logger.info("\n\n📊 Running simple MACD strategy...")
    
        cash = initial_capital
        shares = 0
        macd_trades = 0
    
        for i in range(30, len(bars):
            current_price = bars['close'].iloc[i]
            macd_val = bars['macd'].iloc[i]
            signal_val = bars['signal'].iloc[i]
            prev_macd = bars['macd'].iloc[i-1]
            prev_signal = bars['signal'].iloc[i-1]
        
            # Buy on MACD crossover (MACD crosses above signal)
            if prev_macd <= prev_signal and macd_val > signal_val and shares == 0:
                shares = int(cash / current_price)
                cash -= shares * current_price
                macd_trades += 1
        
            # Sell on MACD crossunder (MACD crosses below signal)
            elif prev_macd >= prev_signal and macd_val < signal_val and shares > 0:
                cash += shares * current_price
                shares = 0
                macd_trades += 1
    
        # Close position
        if shares > 0:
            cash += shares * bars['close'].iloc[-1]
    
        macd_return = (cash - initial_capital) / initial_capital
        logger.info(f"MACD Strategy Return: {macd_return:.2%}")
        logger.info(f"MACD Trades: {macd_trades}")

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in calculate_rsi: {str(e)}")
        raise
    run_simple_backtest()