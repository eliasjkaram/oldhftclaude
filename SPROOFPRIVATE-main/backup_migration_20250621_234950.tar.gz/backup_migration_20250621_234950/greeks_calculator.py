#!/usr/bin/env python3
"""
Greeks Calculator Module
========================
Advanced options Greeks calculation with support for various models
"""

import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq, minimize_scalar
from typing import Dict, Optional, Tuple, Union, List, Any
import pandas as pd
from dataclasses import dataclass
from datetime import datetime, timedelta
import warnings

from unified_logging import get_logger
from unified_error_handling import retry, ErrorCategory, ErrorSeverity, handle_errors
from options_data_pipeline import OptionContract

logger = get_logger(__name__)

@dataclass
class Greeks:
    """Container for option Greeks"""
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float
    
    # Additional Greeks
    lambda_: float = 0.0  # Elasticity
    vanna: float = 0.0    # dDelta/dVol
    charm: float = 0.0    # dDelta/dTime
    vomma: float = 0.0    # dVega/dVol
    speed: float = 0.0    # dGamma/dSpot
    zomma: float = 0.0    # dGamma/dVol
    color: float = 0.0    # dGamma/dTime
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary"""
        return {}
            'delta': self.delta,
            'gamma': self.gamma,
            'theta': self.theta,
            'vega': self.vega,
            'rho': self.rho,
            'lambda': self.lambda_,
            'vanna': self.vanna,
            'charm': self.charm,
            'vomma': self.vomma,
            'speed': self.speed,
            'zomma': self.zomma,
            'color': self.color
        }

class GreeksCalculator:
    """Advanced Greeks calculator with multiple pricing models"""
    
    def __init__(self, model: str = 'black_scholes'):
        self.model = model
        self.cache = {}
        
        # Numerical differentiation parameters
        self.spot_bump = 0.01     # 1% bump for delta/gamma
        self.vol_bump = 0.01      # 1% absolute bump for vega
        self.time_bump = 1/365    # 1 day for theta
        self.rate_bump = 0.0001   # 1 basis point for rho
        
    @handle_errors("greeks", ErrorCategory.SYSTEM, ErrorSeverity.MEDIUM)
    def calculate_greeks(self,
                        spot: float,
                        strike: float,
                        time_to_expiry: float,
                        volatility: float,
                        risk_free_rate: float,
                        dividend_yield: float = 0.0,
                        option_type: str = 'call',
                        calculate_higher_order: bool = False) -> Greeks:
        """
        Calculate all Greeks for an option
        
        Args:
            spot: Current price of underlying
            strike: Strike price
            time_to_expiry: Time to expiration in years
            volatility: Implied volatility (annualized)
            risk_free_rate: Risk-free interest rate
            dividend_yield: Dividend yield (for stocks)
            option_type: 'call' or 'put'
            calculate_higher_order: Whether to calculate second/third order Greeks
        
        Returns:
            Greeks object containing all calculated Greeks
        """
        
        # Input validation
        if time_to_expiry <= 0:
            return Greeks(delta=0, gamma=0, theta=0, vega=0, rho=0)
        
        if volatility <= 0:
            volatility = 0.001  # Small positive value
        
        # Calculate based on model
        if self.model == 'black_scholes':
            greeks = self._black_scholes_greeks()
                spot, strike, time_to_expiry, volatility, 
                risk_free_rate, dividend_yield, option_type
            )
        elif self.model == 'binomial':
            greeks = self._binomial_greeks()
                spot, strike, time_to_expiry, volatility,
                risk_free_rate, dividend_yield, option_type
            )
        else:
            greeks = self._numerical_greeks()
                spot, strike, time_to_expiry, volatility,
                risk_free_rate, dividend_yield, option_type
            )
        
        # Calculate higher-order Greeks if requested
        if calculate_higher_order:
            self._calculate_higher_order_greeks()
                greeks, spot, strike, time_to_expiry, volatility,
                risk_free_rate, dividend_yield, option_type
            )
        
        return greeks
    
    def _black_scholes_greeks(self,
                            S: float,  # Spot
                            K: float,  # Strike
                            T: float,  # Time to expiry
                            σ: float,  # Volatility
                            r: float,  # Risk-free rate
                            q: float,  # Dividend yield
                            option_type: str) -> Greeks:
        """Calculate Greeks using Black-Scholes formulas"""
        
        # Calculate d1 and d2
        d1 = (np.log(S / K) + (r - q + 0.5 * σ**2) * T) / (σ * np.sqrt(T))
        d2 = d1 - σ * np.sqrt(T)
        
        # Standard normal CDF and PDF
        N_d1 = norm.cdf(d1)
        N_d2 = norm.cdf(d2)
        n_d1 = norm.pdf(d1)
        
        # Discount factors
        discount = np.exp(-r * T)
        div_discount = np.exp(-q * T)
        
        if option_type.lower() == 'call':
            # Call option Greeks
            delta = div_discount * N_d1
            
            # Price needed for lambda
            price = S * div_discount * N_d1 - K * discount * N_d2
            
        else:  # Put option
            delta = div_discount * (N_d1 - 1)
            
            # Price needed for lambda
            price = K * discount * (1 - N_d2) - S * div_discount * (1 - N_d1)
        
        # Greeks that are same for calls and puts
        gamma = div_discount * n_d1 / (S * σ * np.sqrt(T))
        
        vega = S * div_discount * n_d1 * np.sqrt(T) / 100  # Divided by 100 for 1% change
        
        # Theta (per day, not per year)
        if option_type.lower() == 'call':
            theta = (-S * div_discount * n_d1 * σ / (2 * np.sqrt(T))
                    - r * K * discount * N_d2
                    + q * S * div_discount * N_d1) / 365
        else:
            theta = (-S * div_discount * n_d1 * σ / (2 * np.sqrt(T))
                    + r * K * discount * (1 - N_d2)
                    - q * S * div_discount * (1 - N_d1)) / 365
        
        # Rho (per basis point)
        if option_type.lower() == 'call':
            rho = K * T * discount * N_d2 / 10000
        else:
            rho = -K * T * discount * (1 - N_d2) / 10000
        
        # Lambda (elasticity)
        lambda_ = delta * S / price if price != 0 else 0
        
        return Greeks()
            delta=delta,
            gamma=gamma,
            theta=theta,
            vega=vega,
            rho=rho,
            lambda_=lambda_
        )
    
    def _binomial_greeks(self,
                        S: float,
                        K: float,
                        T: float,
                        σ: float,
                        r: float,
                        q: float,
                        option_type: str,
                        steps: int = 100) -> Greeks:
        """Calculate Greeks using binomial tree"""
        
        # This is a simplified version - full implementation would build the tree
        # For now, use numerical differentiation
        return self._numerical_greeks(S, K, T, σ, r, q, option_type)
    
    def _numerical_greeks(self,
                         S: float,
                         K: float,
                         T: float,
                         σ: float,
                         r: float,
                         q: float,
                         option_type: str) -> Greeks:
        """Calculate Greeks using numerical differentiation"""
        
        # Base price
        base_price = self._option_price(S, K, T, σ, r, q, option_type)
        
        # Delta: dV/dS
        price_up = self._option_price(S * (1 + self.spot_bump), K, T, σ, r, q, option_type)
        price_down = self._option_price(S * (1 - self.spot_bump), K, T, σ, r, q, option_type)
        delta = (price_up - price_down) / (2 * S * self.spot_bump)
        
        # Gamma: d²V/dS²
        gamma = (price_up - 2 * base_price + price_down) / (S * self.spot_bump)**2
        
        # Theta: dV/dt (negative because we decrease time)
        if T > self.time_bump:
            price_later = self._option_price(S, K, T - self.time_bump, σ, r, q, option_type)
            theta = (price_later - base_price) / self.time_bump / 365  # Daily theta
        else:
            theta = 0
        
        # Vega: dV/dσ
        price_vol_up = self._option_price(S, K, T, σ + self.vol_bump, r, q, option_type)
        vega = (price_vol_up - base_price) / self.vol_bump / 100  # Per 1% change
        
        # Rho: dV/dr
        price_rate_up = self._option_price(S, K, T, σ, r + self.rate_bump, q, option_type)
        rho = (price_rate_up - base_price) / self.rate_bump / 10000  # Per basis point
        
        # Lambda
        lambda_ = delta * S / base_price if base_price != 0 else 0
        
        return Greeks()
            delta=delta,
            gamma=gamma,
            theta=theta,
            vega=vega,
            rho=rho,
            lambda_=lambda_
        )
    
    def _option_price(self,
                     S: float,
                     K: float,
                     T: float,
                     σ: float,
                     r: float,
                     q: float,
                     option_type: str) -> float:
        """Calculate option price using Black-Scholes"""
        
        if T <= 0:
            # Option expired
            if option_type.lower() == 'call':
                return max(S - K, 0)
            else:
                return max(K - S, 0)
        
        # Black-Scholes formula
        d1 = (np.log(S / K) + (r - q + 0.5 * σ**2) * T) / (σ * np.sqrt(T))
        d2 = d1 - σ * np.sqrt(T)
        
        if option_type.lower() == 'call':
            price = S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        else:
            price = K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)
        
        return price
    
    def _calculate_higher_order_greeks(self,
                                     greeks: Greeks,
                                     S: float,
                                     K: float,
                                     T: float,
                                     σ: float,
                                     r: float,
                                     q: float,
                                     option_type: str):
        """Calculate second and third-order Greeks"""
        
        # These require more complex calculations or numerical methods
        
        # Vanna: ∂²V/∂S∂σ (how delta changes with volatility)
        delta_base = greeks.delta
        
        # Calculate delta with higher volatility
        greeks_vol_up = self._black_scholes_greeks()
            S, K, T, σ + self.vol_bump, r, q, option_type
        )
        greeks.vanna = (greeks_vol_up.delta - delta_base) / self.vol_bump
        
        # Charm: ∂²V/∂S∂t (how delta changes with time)
        if T > self.time_bump:
            greeks_time_down = self._black_scholes_greeks()
                S, K, T - self.time_bump, r, q, option_type
            )
            greeks.charm = -(greeks_time_down.delta - delta_base) / self.time_bump / 365
        
        # Vomma: ∂²V/∂σ² (how vega changes with volatility)
        vega_base = greeks.vega
        greeks.vomma = (greeks_vol_up.vega - vega_base) / self.vol_bump
        
        # Speed: ∂³V/∂S³ (how gamma changes with spot)
        gamma_base = greeks.gamma
        greeks_spot_up = self._black_scholes_greeks()
            S * (1 + self.spot_bump), K, T, σ, r, q, option_type
        )
        greeks.speed = (greeks_spot_up.gamma - gamma_base) / (S * self.spot_bump)
        
        # Zomma: ∂³V/∂S²∂σ (how gamma changes with volatility)
        greeks.zomma = (greeks_vol_up.gamma - gamma_base) / self.vol_bump
        
        # Color: ∂³V/∂S²∂t (how gamma changes with time)
        if T > self.time_bump:
            greeks.color = -(greeks_time_down.gamma - gamma_base) / self.time_bump / 365
    
    def calculate_implied_volatility(self,
                                   option_price: float,
                                   spot: float,
                                   strike: float,
                                   time_to_expiry: float,
                                   risk_free_rate: float,
                                   option_type: str = 'call',
                                   dividend_yield: float = 0.0) -> Optional[float]:
        """
        Calculate implied volatility using Newton-Raphson method
        
        Returns:
            Implied volatility or None if cannot be calculated
        """
        
        # Bounds for volatility search
        min_vol = 0.001
        max_vol = 5.0
        
        # Check if option price is within theoretical bounds
        intrinsic_value = max(spot - strike, 0) if option_type == 'call' else max(strike - spot, 0)
        
        if option_price < intrinsic_value:
            logger.warning(f"Option price {option_price} below intrinsic value {intrinsic_value}")
            return None
        
        # Maximum theoretical value
        if option_type == 'call':
            max_value = spot * np.exp(-dividend_yield * time_to_expiry)
        else:
            max_value = strike * np.exp(-risk_free_rate * time_to_expiry)
        
        if option_price > max_value:
            logger.warning(f"Option price {option_price} above maximum theoretical value {max_value}")
            return None
        
        try:
            # Define objective function
            def objective(vol):
                theoretical_price = self._option_price()
                    spot, strike, time_to_expiry, vol, 
                    risk_free_rate, dividend_yield, option_type
                )
                return theoretical_price - option_price
            
            # Use Brent's method
            implied_vol = brentq(objective, min_vol, max_vol, xtol=1e-6)
            
            return implied_vol
            
        except ValueError:
            # Brent's method failed, try minimize_scalar
            try:
                def objective_squared(vol):
                    return objective(vol)**2
                
                result = minimize_scalar()
                    objective_squared,
                    bounds=(min_vol, max_vol),
                    method='bounded'
                )
                
                if result.fun < 1e-10:  # Close enough to zero
                    return result.x
                
            except Exception as e:
                logger.error(f"Failed to calculate implied volatility: {e}")
        
        return None
    
    def calculate_portfolio_greeks(self,
                                 positions: List[Dict[str, Any]]) -> Dict[str, float]:
        """
        Calculate aggregate Greeks for a portfolio of options
        
        Args:
            positions: List of position dictionaries containing:
                - contract: OptionContract
                - quantity: Number of contracts (negative for short)
                - spot: Current underlying price
                - volatility: Implied volatility
                - risk_free_rate: Risk-free rate
        
        Returns:
            Dictionary of aggregate Greeks
        """
        
        total_greeks = {}
            'delta': 0.0,
            'gamma': 0.0,
            'theta': 0.0,
            'vega': 0.0,
            'rho': 0.0,
            'dollar_delta': 0.0,
            'dollar_gamma': 0.0
        }
        
        for position in positions:
            contract = position['contract']
            quantity = position['quantity']
            spot = position['spot']
            
            # Calculate time to expiry
            time_to_expiry = (contract.expiration - datetime.now()).days / 365
            
            if time_to_expiry <= 0:
                continue
            
            # Calculate Greeks for this position
            greeks = self.calculate_greeks()
                spot=spot,
                strike=contract.strike,
                time_to_expiry=time_to_expiry,
                volatility=position['volatility'],
                risk_free_rate=position['risk_free_rate'],
                option_type=contract.option_type
            )
            
            # Aggregate Greeks
            contract_multiplier = 100  # Standard equity option
            total_greeks['delta'] += greeks.delta * quantity * contract_multiplier
            total_greeks['gamma'] += greeks.gamma * quantity * contract_multiplier
            total_greeks['theta'] += greeks.theta * quantity * contract_multiplier
            total_greeks['vega'] += greeks.vega * quantity * contract_multiplier
            total_greeks['rho'] += greeks.rho * quantity * contract_multiplier
            
            # Dollar Greeks
            total_greeks['dollar_delta'] += greeks.delta * quantity * contract_multiplier * spot
            total_greeks['dollar_gamma'] += greeks.gamma * quantity * contract_multiplier * spot**2 / 100
        
        return total_greeks
    
    def calculate_greeks_surface(self,
                               strikes: np.ndarray,
                               expirations: List[datetime],
                               spot: float,
                               volatility_surface: pd.DataFrame,
                               risk_free_rate: float,
                               greek_type: str = 'delta') -> pd.DataFrame:
        """
        Calculate a surface of Greeks across strikes and expirations
        
        Args:
            strikes: Array of strike prices
            expirations: List of expiration dates
            spot: Current spot price
            volatility_surface: DataFrame with volatilities (strikes x expirations)
            risk_free_rate: Risk-free rate
            greek_type: Which Greek to calculate ('delta', 'gamma', 'vega', etc.)
        
        Returns:
            DataFrame containing the Greek surface
        """
        
        greek_surface = pd.DataFrame(index=strikes, columns=[exp.strftime('%Y-%m-%d') for exp in expirations])
        
        for i, strike in enumerate(strikes):
            for j, expiration in enumerate(expirations):
                time_to_expiry = (expiration - datetime.now()).days / 365
                
                if time_to_expiry <= 0:
                    greek_surface.iloc[i, j] = 0
                    continue
                
                # Get implied volatility from surface
                vol = volatility_surface.iloc[i, j]
                
                # Calculate Greeks
                greeks = self.calculate_greeks()
                    spot=spot,
                    strike=strike,
                    time_to_expiry=time_to_expiry,
                    volatility=vol,
                    risk_free_rate=risk_free_rate,
                    option_type='call'
                )
                
                # Extract requested Greek
                greek_value = getattr(greeks, greek_type.lower())
                greek_surface.iloc[i, j] = greek_value
        
        return greek_surface.astype(float)
    
    def delta_hedge_ratio(self,
                         option_delta: float,
                         option_quantity: int,
                         contract_multiplier: int = 100) -> int:
        """
        Calculate number of shares needed to delta hedge
        
        Args:
            option_delta: Delta of the option
            option_quantity: Number of option contracts
            contract_multiplier: Shares per contract (usually 100)
        
        Returns:
            Number of shares to buy/sell (negative means sell)
        """
        return -int(option_delta * option_quantity * contract_multiplier)
    
    def gamma_scalping_pnl(self,
                          initial_spot: float,
                          final_spot: float,
                          gamma: float,
                          shares_rehedged: int) -> float:
        """
        Calculate P&L from gamma scalping
        
        Args:
            initial_spot: Spot price at last rehedge
            final_spot: Current spot price
            gamma: Portfolio gamma
            shares_rehedged: Number of shares used in rehedge
        
        Returns:
            P&L from gamma scalping
        """
        spot_change = final_spot - initial_spot
        
        # P&L from gamma (option value change due to gamma)
        gamma_pnl = 0.5 * gamma * spot_change**2 * 100  # 100 for contract multiplier
        
        # P&L from delta hedge
        hedge_pnl = -shares_rehedged * spot_change
        
        return gamma_pnl + hedge_pnl


# Integration function
def integrate_greeks_calculator(master_system):
    """
    Integrate Greeks calculator with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from greeks_calculator import integrate_greeks_calculator
    integrate_greeks_calculator(self)
    """
    
    # Create calculator instance
    master_system.greeks_calculator = GreeksCalculator()
    
    # Add methods to master system
    def calculate_option_greeks(self, contract: OptionContract, 
                              market_data: Dict[str, float]) -> Dict[str, float]:
        """Calculate Greeks for an option contract"""
        
        time_to_expiry = (contract.expiration - datetime.now()).days / 365
        
        greeks = self.greeks_calculator.calculate_greeks()
            spot=market_data['spot'],
            strike=contract.strike,
            time_to_expiry=time_to_expiry,
            volatility=market_data.get('implied_volatility', 0.2),
            risk_free_rate=market_data.get('risk_free_rate', 0.05),
            option_type=contract.option_type,
            calculate_higher_order=True
        )
        
        return greeks.to_dict()
    
    def calculate_portfolio_risk(self, positions: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate aggregate portfolio Greeks"""
        return self.greeks_calculator.calculate_portfolio_greeks(positions)
    
    def get_implied_volatility(self, 
                             option_price: float,
                             contract: OptionContract,
                             spot: float) -> Optional[float]:
        """Calculate implied volatility from option price"""
        
        time_to_expiry = (contract.expiration - datetime.now()).days / 365
        
        return self.greeks_calculator.calculate_implied_volatility()
            option_price=option_price,
            spot=spot,
            strike=contract.strike,
            time_to_expiry=time_to_expiry,
            risk_free_rate=0.05,  # Could get from config
            option_type=contract.option_type
        )
    
    # Bind methods
    master_system.calculate_option_greeks = calculate_option_greeks.__get__(master_system)
    master_system.calculate_portfolio_risk = calculate_portfolio_risk.__get__(master_system)
    master_system.get_implied_volatility = get_implied_volatility.__get__(master_system)
    
    logger.info("Greeks calculator integrated with master system")


if __name__ == "__main__":
    # Test Greeks calculator
    calculator = GreeksCalculator()
    
    # Test parameters
    spot = 100
    strike = 105
    time_to_expiry = 0.25  # 3 months
    volatility = 0.2      # 20%
    risk_free_rate = 0.05  # 5%
    
    # Calculate Greeks
    print("Calculating Greeks for ATM call option:")
    print(f"Spot: ${spot}, Strike: ${strike}, Time: {time_to_expiry} years, Vol: {volatility*100}%")
    
    greeks = calculator.calculate_greeks()
        spot=spot,
        strike=strike,
        time_to_expiry=time_to_expiry,
        volatility=volatility,
        risk_free_rate=risk_free_rate,
        option_type='call',
        calculate_higher_order=True
    )
    
    print("\nFirst-order Greeks:")
    print(f"Delta: {greeks.delta:.4f}")
    print(f"Gamma: {greeks.gamma:.4f}")
    print(f"Theta: {greeks.theta:.4f} (per day)")
    print(f"Vega: {greeks.vega:.4f} (per 1% vol)")
    print(f"Rho: {greeks.rho:.4f} (per bp)")
    
    print("\nHigher-order Greeks:")
    print(f"Vanna: {greeks.vanna:.4f}")
    print(f"Charm: {greeks.charm:.4f}")
    print(f"Vomma: {greeks.vomma:.4f}")
    
    # Test implied volatility calculation
    option_price = calculator._option_price(spot, strike, time_to_expiry, volatility, risk_free_rate, 0, 'call')
    print(f"\nOption price: ${option_price:.2f}")
    
    implied_vol = calculator.calculate_implied_volatility()
        option_price=option_price,
        spot=spot,
        strike=strike,
        time_to_expiry=time_to_expiry,
        risk_free_rate=risk_free_rate,
        option_type='call'
    )
    
    print(f"Implied volatility: {implied_vol*100:.2f}% (should match input: {volatility*100}%)")