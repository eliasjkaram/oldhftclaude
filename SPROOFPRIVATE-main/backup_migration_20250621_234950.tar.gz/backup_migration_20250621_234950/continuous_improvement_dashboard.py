
#!/usr/bin/env python3
"""
Continuous Improvement Dashboard
================================
Real-time monitoring of backtesting and optimization progress
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
import json
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.express as px
from pathlib import Path
import time

# Page config
st.set_page_config()
    page_title="Continuous Trading System Improvement",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown(""")
<style>
    .metric-card {}
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        margin: 10px 0;
    }
    .success {}
        color: #28a745;
    }
    .warning {}
        color: #ffc107;
    }
    .danger {}
        color: #dc3545;
    }
</style>
""", unsafe_allow_html=True)

class DashboardData:
    """Load and process dashboard data"""
    
    def __init__(self, db_path: str = "continuous_training.db"):
        self.db_path = db_path
        
    def get_recent_backtests(self, hours: int = 24) -> pd.DataFrame:
        """Get recent backtest results"""
        try:
            conn = sqlite3.connect(self.db_path)
            query = """
                SELECT * FROM backtest_results
                WHERE timestamp > datetime('now', '-{} hours')
                ORDER BY timestamp DESC
            """.format(hours)
            df = pd.read_sql_query(query, conn)
            conn.close()
            return df
        except:
            return pd.DataFrame()
            
    def get_optimization_history(self, days: int = 7) -> pd.DataFrame:
        """Get optimization history"""
        try:
            conn = sqlite3.connect(self.db_path)
            query = """
                SELECT * FROM optimization_history
                WHERE timestamp > datetime('now', '-{} days')
                ORDER BY timestamp DESC
            """.format(days)
            df = pd.read_sql_query(query, conn)
            conn.close()
            return df
        except:
            return pd.DataFrame()
            
    def get_strategy_performance(self) -> pd.DataFrame:
        """Get strategy performance summary"""
        try:
            conn = sqlite3.connect(self.db_path)
            query = """
                SELECT 
                    strategy_name,
                    COUNT(*) as total_backtests,
                    AVG(sharpe_ratio) as avg_sharpe,
                    AVG(total_return) as avg_return,
                    AVG(max_drawdown) as avg_drawdown,
                    AVG(win_rate) as avg_win_rate,
                    MAX(sharpe_ratio) as best_sharpe,
                    MAX(total_return) as best_return
                FROM backtest_results
                WHERE timestamp > datetime('now', '-7 days')
                GROUP BY strategy_name
                ORDER BY avg_sharpe DESC
            """
            df = pd.read_sql_query(query, conn)
            conn.close()
            return df
        except:
            return pd.DataFrame()
            
    def get_latest_report(self) -> dict:
        """Get latest report data"""
        report_dir = Path("backtest_reports")
        if not report_dir.exists():
            return {}
            
        json_files = list(report_dir.glob("continuous_training_report_*.json")
        if not json_files:
            return {}
            
        latest_file = max(json_files, key=lambda x: x.stat().st_mtime)
        
        try:
            with open(latest_file) as f:
                return json.load(f)
        except:
            return {}

def main():
    """Main dashboard function"""
    
    st.title("🚀 Continuous Trading System Improvement Dashboard")
    st.markdown("### Real-time monitoring of strategy optimization progress")
    
    # Initialize data loader
    data_loader = DashboardData()
    
    # Sidebar controls
    st.sidebar.header("Dashboard Controls")
    
    # Time range selector
    time_range = st.sidebar.selectbox()
        "Time Range",
        ["Last 1 Hour", "Last 6 Hours", "Last 24 Hours", "Last 7 Days", "Last 30 Days"],
        index=2
    )
    
    # Auto-refresh
    auto_refresh = st.sidebar.checkbox("Auto Refresh (30s)", value=True)
    
    # Strategy filter
    all_strategies = data_loader.get_strategy_performance()
    if not all_strategies.empty:
        selected_strategies = st.sidebar.multiselect()
            "Filter Strategies",
            options=all_strategies['strategy_name'].tolist(),
            default=all_strategies['strategy_name'].tolist()[:5]
        )
    else:
        selected_strategies = []
    
    # Main content
    col1, col2, col3, col4 = st.columns(4)
    
    # Get data
    recent_backtests = data_loader.get_recent_backtests(24)
    optimization_history = data_loader.get_optimization_history(7)
    latest_report = data_loader.get_latest_report()
    
    # Key Metrics
    with col1:
        st.metric()
            "Total Backtests (24h)",
            len(recent_backtests),
            delta=f"+{len(recent_backtests)}" if len(recent_backtests) > 0 else "0"
        )
        
    with col2:
        if not recent_backtests.empty:
            avg_sharpe = recent_backtests['sharpe_ratio'].mean()
            st.metric()
                "Avg Sharpe Ratio",
                f"{avg_sharpe:.3f}",
                delta=f"{avg_sharpe - 1:.3f}"
            )
        else:
            st.metric("Avg Sharpe Ratio", "N/A")
            
    with col3:
        optimized_count = len(optimization_history)
        st.metric()
            "Strategies Optimized",
            optimized_count,
            delta=f"+{optimized_count}" if optimized_count > 0 else "0"
        )
        
    with col4:
        if not optimization_history.empty:
            avg_improvement = optimization_history['performance_improvement'].mean()
            st.metric()
                "Avg Improvement",
                f"{avg_improvement:.1%}",
                delta=f"{avg_improvement:.1%}"
            )
        else:
            st.metric("Avg Improvement", "N/A")
    
    # Performance Charts
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Strategy Performance Leaderboard")
        
        if not all_strategies.empty:
            # Create performance table
            perf_df = all_strategies[all_strategies['strategy_name'].isin(selected_strategies)]
            
            # Style the dataframe
            styled_df = perf_df[['strategy_name', 'avg_sharpe', 'avg_return', 'avg_win_rate']].round(3)
            styled_df.columns = ['Strategy', 'Avg Sharpe', 'Avg Return', 'Win Rate']
            
            st.dataframe()
                styled_df,
                use_container_width=True,
                hide_index=True
            )
            
            # Performance chart
            fig = go.Figure()
            
            fig.add_trace(go.Bar())
                x=perf_df['strategy_name'],
                y=perf_df['avg_sharpe'],
                name='Sharpe Ratio',
                marker_color='lightblue'
            )
            
            fig.update_layout()
                title="Average Sharpe Ratio by Strategy",
                xaxis_title="Strategy",
                yaxis_title="Sharpe Ratio",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No strategy performance data available")
            
    with col2:
        st.subheader("🔄 Optimization Impact")
        
        if not optimization_history.empty:
            # Parse parameters
            improvements = []
            for _, row in optimization_history.iterrows():
                improvements.append({)
                    'strategy': row['strategy_name'],
                    'improvement': row['performance_improvement'],
                    'timestamp': pd.to_datetime(row['timestamp'])
                })
                
            imp_df = pd.DataFrame(improvements)
            
            # Create improvement chart
            fig = px.scatter()
                imp_df,
                x='timestamp',
                y='improvement',
                color='strategy',
                size=abs(imp_df['improvement']),
                title="Performance Improvements Over Time",
                labels={'improvement': 'Improvement %', 'timestamp': 'Date'}
            )
            
            fig.update_yaxis(tickformat='.1%')
            fig.update_layout(height=400)
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Best improvements
            st.markdown("#### 🏆 Top Improvements")
            top_improvements = imp_df.nlargest(5, 'improvement')[['strategy', 'improvement']]
            for _, row in top_improvements.iterrows():
                st.success(f"**{row['strategy']}**: +{row['improvement']:.1%}")
        else:
            st.info("No optimization data available")
    
    # Market Scenario Analysis
    st.markdown("---")
    st.subheader("🌍 Market Scenario Analysis")
    
    if not recent_backtests.empty:
        col1, col2, col3 = st.columns(3)
        
        # Group by scenario
        scenario_perf = recent_backtests.groupby('market_scenario').agg({)
            'sharpe_ratio': 'mean',
            'total_return': 'mean',
            'max_drawdown': 'mean',
            'win_rate': 'mean'
        }).round(3)
        
        with col1:
            # Best performing scenarios
            st.markdown("#### Best Scenarios")
            best_scenarios = scenario_perf.nlargest(3, 'sharpe_ratio')
            for scenario, row in best_scenarios.iterrows():
                st.metric()
                    scenario.replace('_', ' ').title(),
                    f"Sharpe: {row['sharpe_ratio']:.3f}",
                    f"Return: {row['total_return']:.1%}"
                )
                
        with col2:
            # Worst performing scenarios
            st.markdown("#### Challenging Scenarios")
            worst_scenarios = scenario_perf.nsmallest(3, 'sharpe_ratio')
            for scenario, row in worst_scenarios.iterrows():
                st.metric()
                    scenario.replace('_', ' ').title(),
                    f"Sharpe: {row['sharpe_ratio']:.3f}",
                    f"Return: {row['total_return']:.1%}",
                    delta_color="inverse"
                )
                
        with col3:
            # Scenario distribution pie chart
            scenario_counts = recent_backtests['market_scenario'].value_counts()
            
            fig = go.Figure(data=[go.Pie())
                labels=scenario_counts.index,
                values=scenario_counts.values,
                hole=0.3
            )])
            
            fig.update_layout()
                title="Backtest Distribution",
                height=300,
                showlegend=False
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    # Real-time Activity Feed
    st.markdown("---")
    st.subheader("📡 Real-time Activity")
    
    activity_container = st.container()
    
    with activity_container:
        if not recent_backtests.empty:
            # Get last 10 activities
            recent_activities = recent_backtests.nlargest(10, 'timestamp')
            
            for _, activity in recent_activities.iterrows():
                timestamp = pd.to_datetime(activity['timestamp'])
                time_ago = (datetime.now() - timestamp).total_seconds() / 60
                
                if time_ago < 60:
                    time_str = f"{int(time_ago)} minutes ago"
                else:
                    time_str = f"{int(time_ago/60)} hours ago"
                    
                # Format activity message
                if activity['sharpe_ratio'] > 1:
                    emoji = "✅"
                    color = "success"
                elif activity['sharpe_ratio'] > 0.5:
                    emoji = "⚠️"
                    color = "warning"
                else:
                    emoji = "❌"
                    color = "danger"
                    
                st.markdown()
                    f"{emoji} **{activity['strategy_name']}** - "
                    f"Sharpe: {activity['sharpe_ratio']:.3f}, "
                    f"Return: {activity['total_return']:.1%} "
                    f"<span class='{color}'>({time_str})</span>",
                    unsafe_allow_html=True
                )
        else:
            st.info("No recent activity. The system may be starting up...")
    
    # System Status
    st.markdown("---")
    st.subheader("🔧 System Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Check if system is running
        if recent_backtests.empty or len(recent_backtests[recent_backtests['timestamp'] > (datetime.now() - timedelta(hours=1).isoformat()]) == 0:
            st.error("⚠️ System appears to be offline")
        else:
            st.success("✅ System is running")
            
    with col2:
        # Database size
        try:
            db_size = Path("continuous_training.db").stat().st_size / 1024 / 1024
            st.info(f"📊 Database Size: {db_size:.1f} MB")
        except:
            st.info("📊 Database Size: N/A")
            
    with col3:
        # Last report
        if latest_report:
            report_time = latest_report.get('timestamp', 'Unknown')
            st.info(f"📄 Last Report: {report_time}")
        else:
            st.info("📄 No reports generated yet")
    
    # Auto-refresh
    if auto_refresh:
        time.sleep(30)
        st.rerun()

if __name__ == "__main__":
    main()