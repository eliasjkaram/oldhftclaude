#!/usr/bin/env python3
"""
Production Real-Time PnL Attribution Engine
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timezone
import logging
from collections import defaultdict
import asyncio
import json

logger = logging.getLogger(__name__)

@dataclass
class Position:
    """Trading position"""
    symbol: str
    quantity: float
    entry_price: float
    entry_time: datetime
    current_price: float = 0.0
    realized_pnl: float = 0.0
    unrealized_pnl: float = 0.0
    
@dataclass
class PnLAttribution:
    """PnL attribution result"""
    timestamp: datetime
    total_pnl: float
    realized_pnl: float
    unrealized_pnl: float
    price_pnl: float
    quantity_pnl: float
    fees_impact: float
    slippage_impact: float
    attribution_by_factor: Dict[str, float] = field(default_factory=dict)
    attribution_by_symbol: Dict[str, float] = field(default_factory=dict)

class RealTimePnLAttribution:
    """Real-time PnL attribution engine"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.positions: Dict[str, Position] = {}
        self.pnl_history = []
        self.attribution_cache = {}
        self.metrics = {}
            'calculations_performed': 0,
            'total_pnl': 0.0,
            'attribution_latency_ms': []
        }
        logger.info("RealTimePnLAttribution initialized")
        
    def update_position(self, symbol: str, quantity: float, price: float, 
                       action: str = "BUY") -> Position:
        """Update position with new trade"""
        if action == "BUY":
            if symbol in self.positions:
                pos = self.positions[symbol]
                # Average price calculation
                total_cost = pos.quantity * pos.entry_price + quantity * price
                pos.quantity += quantity
                pos.entry_price = total_cost / pos.quantity if pos.quantity > 0 else 0
            else:
                pos = Position()
                    symbol=symbol,
                    quantity=quantity,
                    entry_price=price,
                    entry_time=datetime.now(timezone.utc),
                    current_price=price
                )
                self.positions[symbol] = pos
        else:  # SELL
            if symbol in self.positions:
                pos = self.positions[symbol]
                sell_pnl = quantity * (price - pos.entry_price)
                pos.realized_pnl += sell_pnl
                pos.quantity -= quantity
                
                if pos.quantity <= 0:
                    del self.positions[symbol]
                    
        return self.positions.get(symbol)
        
    def update_prices(self, price_updates: Dict[str, float]):
        """Update current prices for positions"""
        for symbol, price in price_updates.items():
            if symbol in self.positions:
                self.positions[symbol].current_price = price
                
    def calculate_attribution(self) -> PnLAttribution:
        """Calculate PnL attribution"""
        start_time = datetime.now()
        
        total_realized = sum(pos.realized_pnl for pos in self.positions.values())
        total_unrealized = sum()
            pos.quantity * (pos.current_price - pos.entry_price)
            for pos in self.positions.values()
            if pos.quantity > 0
        )
        
        # Attribution by symbol
        attribution_by_symbol = {}
        for symbol, pos in self.positions.items():
            if pos.quantity > 0:
                symbol_pnl = pos.realized_pnl + pos.quantity * (pos.current_price - pos.entry_price)
                attribution_by_symbol[symbol] = symbol_pnl
                
        # Simple factor attribution
        attribution_by_factor = {}
            'market_movement': total_unrealized * 0.6,
            'timing': total_unrealized * 0.3,
            'selection': total_unrealized * 0.1
        }
        
        attribution = PnLAttribution()
            timestamp=datetime.now(timezone.utc),
            total_pnl=total_realized + total_unrealized,
            realized_pnl=total_realized,
            unrealized_pnl=total_unrealized,
            price_pnl=total_unrealized,
            quantity_pnl=0,
            fees_impact=0,
            slippage_impact=0,
            attribution_by_factor=attribution_by_factor,
            attribution_by_symbol=attribution_by_symbol
        )
        
        # Update metrics
        self.metrics['calculations_performed'] += 1
        self.metrics['total_pnl'] = attribution.total_pnl
        latency_ms = (datetime.now() - start_time).total_seconds() * 1000
        self.metrics['attribution_latency_ms'].append(latency_ms)
        
        self.pnl_history.append(attribution)
        return attribution
        
    def get_real_time_pnl(self) -> Dict[str, Any]:
        """Get real-time PnL summary"""
        attribution = self.calculate_attribution()
        
        return {}
            'timestamp': attribution.timestamp.isoformat(),
            'total_pnl': attribution.total_pnl,
            'realized_pnl': attribution.realized_pnl,
            'unrealized_pnl': attribution.unrealized_pnl,
            'positions': len(self.positions),
            'top_contributors': sorted()
                attribution.attribution_by_symbol.items(),
                key=lambda x: abs(x[1]),
                reverse=True
            )[:5]
        }
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        avg_latency = ()
            np.mean(self.metrics['attribution_latency_ms'][-100:])
            if self.metrics['attribution_latency_ms'] else 0
        )
        
        return {}
            'calculations_performed': self.metrics['calculations_performed'],
            'total_pnl': self.metrics['total_pnl'],
            'avg_latency_ms': avg_latency,
            'positions_tracked': len(self.positions)
        }
        
    async def start_real_time_updates(self, update_interval: float = 0.1):
        """Start real-time PnL updates"""
        logger.info(f"Starting real-time PnL updates every {update_interval}s")
        
        while True:
            try:
                pnl_data = self.get_real_time_pnl()
                logger.debug(f"PnL Update: ${pnl_data['total_pnl']:.2f}")
                await asyncio.sleep(update_interval)
            except Exception as e:
                logger.error(f"Error in real-time updates: {e}")
                await asyncio.sleep(1)

# Example usage
async def example_usage():
    engine = RealTimePnLAttribution()
    
    # Simulate trades
    engine.update_position("AAPL", 100, 150.0, "BUY")
    engine.update_position("GOOGL", 50, 2800.0, "BUY")
    
    # Update prices
    engine.update_prices({"AAPL": 155.0, "GOOGL": 2850.0})
    
    # Get PnL
    pnl_data = engine.get_real_time_pnl()
    print(f"Real-time PnL: {json.dumps(pnl_data, indent=2)}")
    
    # Get metrics
    metrics = engine.get_metrics()
    print(f"Metrics: {json.dumps(metrics, indent=2)}")

if __name__ == "__main__":
    asyncio.run(example_usage())