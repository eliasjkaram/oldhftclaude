#!/usr/bin/env python3
"""
Test if algorithms generate signals with daily data
"""

import pandas as pd
import numpy as np
from v21_alpaca_backtest_system import TradingAlgorithms

# Load some cached daily data
try:
    aapl_data = pd.read_pickle('daily_2024_cache/AAPL_1D_2024-01-01_2024-12-31.pkl')
    print(f"Loaded AAPL data: {len(aapl_data)} days")
    print(f"Date range: {aapl_data.index[0]} to {aapl_data.index[-1]}")
    print(f"Price range: ${aapl_data['close'].min():.2f} - ${aapl_data['close'].max():.2f}")
    
    # Initialize algorithms
    algos = TradingAlgorithms()
    
    # Test a few algorithms
    test_algos = ['RSI_Oversold', 'MACD_Crossover', 'Mean_Reversion', 'Volume_Breakout']
    
    print("\nTesting algorithm signals:\n")
    
    for algo_name in test_algos:
        if hasattr(algos, algo_name):
            algo_func = getattr(algos, algo_name)
            try:
                signals = algo_func(aapl_data)
                
                # Count signals
                buy_signals = (signals == 1).sum()
                sell_signals = (signals == -1).sum()
                hold_signals = (signals == 0).sum()
                
                print(f"{algo_name}:")
                print(f"  Buy signals: {buy_signals}")
                print(f"  Sell signals: {sell_signals}")
                print(f"  Hold signals: {hold_signals}")
                
                # Show first few non-zero signals
                non_zero = signals[signals != 0]
                if len(non_zero) > 0:
                    print(f"  First signal at: {non_zero.index[0]}")
                    print(f"  Signal dates: {len(non_zero)} total")
                print()
                
            except Exception as e:
                print(f"{algo_name}: Error - {e}\n")
    
    # Check data columns
    print("\nData columns:", list(aapl_data.columns))
    print("\nFirst 5 rows:")
    print(aapl_data.head())
    
except Exception as e:
    print(f"Error loading data: {e}")