#!/usr/bin/env python3
"""
V27 Lightweight ML Trading Models
Simplified ML models using only scikit-learn and pandas
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV, cross_val_score
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

class LightweightFeatureEngineering:
    """Lightweight feature engineering using pandas only"""
    
    def __init__(self):
        self.feature_columns = []
        
    def calculate_sma(self, series, window):
        """Simple Moving Average"""
        return series.rolling(window=window).mean()
    
    def calculate_ema(self, series, window):
        """Exponential Moving Average"""
        return series.ewm(span=window, adjust=False).mean()
    
    def calculate_rsi(self, series, window=14):
        """Relative Strength Index"""
        delta = series.diff()
        gain = (delta.where(delta > 0, 0).rolling(window=window).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=window).mean())
        rs = gain / (loss + 1e-10)
        rsi = 100 - (100 / (1 + rs)
        return rsi
    
    def calculate_bollinger_bands(self, series, window=20, num_std=2):
        """Bollinger Bands"""
        sma = self.calculate_sma(series, window)
        std = series.rolling(window=window).std()
        upper = sma + (std * num_std)
        lower = sma - (std * num_std)
        return upper, sma, lower
    
    def calculate_macd(self, series, fast=12, slow=26, signal=9):
        """MACD indicator"""
        ema_fast = self.calculate_ema(series, fast)
        ema_slow = self.calculate_ema(series, slow)
        macd_line = ema_fast - ema_slow
        signal_line = self.calculate_ema(macd_line, signal)
        histogram = macd_line - signal_line
        return macd_line, signal_line, histogram
    
    def calculate_stochastic(self, high, low, close, k_window=14, d_window=3):
        """Stochastic Oscillator"""
        lowest_low = low.rolling(window=k_window).min()
        highest_high = high.rolling(window=k_window).max()
        k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low)
        d_percent = k_percent.rolling(window=d_window).mean()
        return k_percent, d_percent
    
    def engineer_features(self, data):
        """Create comprehensive features"""
        df = data.copy()
        
        # Price-based features
        df['returns'] = df['close'].pct_change()
        df['log_returns'] = np.log(df['close'] / df['close'].shift(1)
        df['high_low_ratio'] = df['high'] / df['low']
        df['close_open_ratio'] = df['close'] / df['open']
        df['price_range'] = (df['high'] - df['low']) / df['close']
        
        # Volume features
        df['volume_sma'] = self.calculate_sma(df['volume'], 20)
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        df['price_volume'] = df['close'] * df['volume']
        
        # Technical indicators
        df['rsi_14'] = self.calculate_rsi(df['close'], 14)
        df['rsi_7'] = self.calculate_rsi(df['close'], 7)
        df['rsi_21'] = self.calculate_rsi(df['close'], 21)
        
        # Moving averages
        for period in [5, 10, 20, 50]:
            df[f'sma_{period}'] = self.calculate_sma(df['close'], period)
            df[f'ema_{period}'] = self.calculate_ema(df['close'], period)
            df[f'price_sma_{period}_ratio'] = df['close'] / df[f'sma_{period}']
            df[f'returns_{period}d'] = df['close'].pct_change(period)
            df[f'volatility_{period}d'] = df['returns'].rolling(period).std()
        
        # MACD
        macd, signal, hist = self.calculate_macd(df['close'])
        df['macd'] = macd
        df['macd_signal'] = signal
        df['macd_histogram'] = hist
        
        # Bollinger Bands
        bb_upper, bb_middle, bb_lower = self.calculate_bollinger_bands(df['close'])
        df['bb_upper'] = bb_upper
        df['bb_middle'] = bb_middle
        df['bb_lower'] = bb_lower
        df['bb_width'] = (bb_upper - bb_lower) / bb_middle
        df['bb_position'] = (df['close'] - bb_lower) / (bb_upper - bb_lower)
        
        # Stochastic
        stoch_k, stoch_d = self.calculate_stochastic(df['high'], df['low'], df['close'])
        df['stoch_k'] = stoch_k
        df['stoch_d'] = stoch_d
        
        # Momentum indicators
        for period in [5, 10, 20]:
            df[f'momentum_{period}'] = df['close'] / df['close'].shift(period) - 1
            df[f'roc_{period}'] = (df['close'] - df['close'].shift(period) / df['close'].shift(period) * 100)
        
        # Support/Resistance
        for period in [20, 50]:
            df[f'resistance_{period}'] = df['high'].rolling(period).max()
            df[f'support_{period}'] = df['low'].rolling(period).min()
            df[f'resistance_distance_{period}'] = (df[f'resistance_{period}'] - df['close']) / df['close']
            df[f'support_distance_{period}'] = (df['close'] - df[f'support_{period}']) / df['close']
        
        # Volatility features
        df['volatility_20'] = df['returns'].rolling(20).std()
        df['volatility_ratio'] = df['volatility_20'] / df['volatility_20'].rolling(50).mean()
        
        # Trend features
        df['trend_5'] = np.where(df['sma_5'] > df['sma_5'].shift(1), 1, -1)
        df['trend_20'] = np.where(df['sma_20'] > df['sma_20'].shift(1), 1, -1)
        df['trend_50'] = np.where(df['sma_50'] > df['sma_50'].shift(1), 1, -1)
        
        # Pattern features
        df['doji'] = np.where(abs(df['close'] - df['open']) / (df['high'] - df['low'] + 1e-10) < 0.1, 1, 0)
        df['hammer'] = np.where()
            ((df['high'] - df['low']) > 3 * abs(df['close'] - df['open']) &)
            (df['close'] > df['open']), 1, 0
        )
        
        # Get feature columns
        feature_cols = [col for col in df.columns if col not in ['open', 'high', 'low', 'close', 'volume']]
        self.feature_columns = feature_cols
        
        # Fill NaN values
        features = df[feature_cols].fillna(method='ffill').fillna(0)
        
        return features

class RandomForestTradingModel:
    """Random Forest model for trading signals"""
    
    def __init__(self, n_estimators=100, max_depth=10, random_state=42):
        self.model = RandomForestClassifier()
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state
        )
        self.scaler = StandardScaler()
        self.feature_importance = None
        
    def train(self, features, targets):
        """Train the Random Forest model"""
        # Scale features
        features_scaled = self.scaler.fit_transform(features)
        
        # Convert targets to 0, 1, 2 (from -1, 0, 1)
        targets_shifted = targets + 1
        
        # Train model
        self.model.fit(features_scaled, targets_shifted)
        
        # Store feature importance
        if hasattr(features, 'columns'):
            self.feature_importance = pd.DataFrame({)
                'feature': features.columns,
                'importance': self.model.feature_importances_
            }).sort_values('importance', ascending=False)
        
        return self.model
    
    def predict(self, features):
        """Make predictions"""
        features_scaled = self.scaler.transform(features)
        predictions = self.model.predict(features_scaled)
        
        # Convert back to -1, 0, 1
        return predictions - 1
    
    def predict_proba(self, features):
        """Get prediction probabilities"""
        features_scaled = self.scaler.transform(features)
        return self.model.predict_proba(features_scaled)

class GradientBoostingTradingModel:
    """Gradient Boosting model for trading"""
    
    def __init__(self, n_estimators=100, learning_rate=0.1, max_depth=5, random_state=42):
        self.model = GradientBoostingClassifier()
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            max_depth=max_depth,
            random_state=random_state
        )
        self.scaler = RobustScaler()
        
    def train(self, features, targets):
        """Train the Gradient Boosting model"""
        features_scaled = self.scaler.fit_transform(features)
        targets_shifted = targets + 1
        
        self.model.fit(features_scaled, targets_shifted)
        return self.model
    
    def predict(self, features):
        """Make predictions"""
        features_scaled = self.scaler.transform(features)
        predictions = self.model.predict(features_scaled)
        return predictions - 1

class LogisticRegressionTradingModel:
    """Logistic Regression model for trading"""
    
    def __init__(self, C=1.0, random_state=42):
        self.model = LogisticRegression()
            C=C,
            random_state=random_state,
            multi_class='ovr',
            max_iter=1000
        )
        self.scaler = StandardScaler()
        
    def train(self, features, targets):
        """Train the Logistic Regression model"""
        features_scaled = self.scaler.fit_transform(features)
        targets_shifted = targets + 1
        
        self.model.fit(features_scaled, targets_shifted)
        return self.model
    
    def predict(self, features):
        """Make predictions"""
        features_scaled = self.scaler.transform(features)
        predictions = self.model.predict(features_scaled)
        return predictions - 1

class LightweightEnsemble:
    """Ensemble of lightweight models"""
    
    def __init__(self):
        self.models = {}
            'random_forest': RandomForestTradingModel(n_estimators=50),
            'gradient_boost': GradientBoostingTradingModel(n_estimators=50),
            'logistic': LogisticRegressionTradingModel()
        }
        self.feature_engineer = LightweightFeatureEngineering()
        self.weights = None
        
    def create_targets(self, data, lookahead=5, threshold=0.02):
        """Create trading targets"""
        returns = data['close'].pct_change(lookahead).shift(-lookahead)
        
        targets = pd.Series(0, index=data.index)
        targets[returns > threshold] = 1  # Buy
        targets[returns < -threshold] = -1  # Sell
        
        return targets
    
    def train_all_models(self, data):
        """Train all models in the ensemble"""
        # Feature engineering
        features = self.feature_engineer.engineer_features(data)
        targets = self.create_targets(data)
        
        # Remove NaN values
        valid_mask = ~(features.isna().any(axis=1) | targets.isna()
        features_clean = features[valid_mask]
        targets_clean = targets[valid_mask]
        
        if len(features_clean) < 100:
            raise ValueError("Not enough valid data points")
        
        print(f"Training on {len(features_clean)} samples with {len(features_clean.columns)} features")
        
        # Train each model
        model_scores = {}
        
        # Time series cross-validation
        tscv = TimeSeriesSplit(n_splits=5)
        
        for name, model in self.models.items():
            print(f"Training {name}...")
            
            # Cross-validation scores
            cv_scores = []
            
            for train_idx, val_idx in tscv.split(features_clean):
                X_train, X_val = features_clean.iloc[train_idx], features_clean.iloc[val_idx]
                y_train, y_val = targets_clean.iloc[train_idx], targets_clean.iloc[val_idx]
                
                # Train model
                model.train(X_train, y_train)
                
                # Validate
                y_pred = model.predict(X_val)
                accuracy = accuracy_score(y_val, y_pred)
                cv_scores.append(accuracy)
            
            avg_score = np.mean(cv_scores)
            model_scores[name] = avg_score
            print(f"  {name} CV Accuracy: {avg_score:.3f}")
            
            # Final training on all data
            model.train(features_clean, targets_clean)
        
        # Calculate ensemble weights based on performance
        total_score = sum(model_scores.values()
        self.weights = {name: score / total_score for name, score in model_scores.items()}
        
        print(f"\nEnsemble weights: {self.weights}")
        
        return model_scores
    
    def predict(self, data):
        """Make ensemble predictions"""
        features = self.feature_engineer.engineer_features(data)
        
        # Get predictions from all models
        predictions = {}
        
        for name, model in self.models.items():
            try:
                pred = model.predict(features)
                predictions[name] = pred
            except Exception as e:
                print(f"Error in {name} prediction: {e}")
                predictions[name] = np.zeros(len(features)
        
        # Weighted ensemble
        if self.weights is None:
            # Equal weights if not trained
            self.weights = {name: 1/len(self.models) for name in self.models.keys()}
        
        ensemble_pred = np.zeros(len(features)
        for name, pred in predictions.items():
            ensemble_pred += self.weights[name] * pred
        
        # Convert to discrete signals
        signals = np.where(ensemble_pred > 0.3, 1, np.where(ensemble_pred < -0.3, -1, 0)
        
        return signals, predictions

# Performance evaluation utilities
class ModelEvaluator:
    """Evaluate model performance"""
    
    @staticmethod
    def evaluate_model(model, X_test, y_test):
        """Comprehensive model evaluation"""
        y_pred = model.predict(X_test)
        
        accuracy = accuracy_score(y_test, y_pred)
        
        results = {}
            'accuracy': accuracy,
            'classification_report': classification_report(y_test, y_pred),
            'confusion_matrix': confusion_matrix(y_test, y_pred)
        }
        
        return results
    
    @staticmethod
    def feature_importance_analysis(model, feature_names):
        """Analyze feature importance"""
        if hasattr(model, 'feature_importance') and model.feature_importance is not None:
            return model.feature_importance.head(20)
        elif hasattr(model.model, 'feature_importances_'):
            importance_df = pd.DataFrame({)
                'feature': feature_names,
                'importance': model.model.feature_importances_
            }).sort_values('importance', ascending=False)
            return importance_df.head(20)
        else:
            return None

if __name__ == "__main__":
    print("V27 Lightweight ML Trading Models")
    print("="*50)
    print("Models available:")
    print("✓ Random Forest")
    print("✓ Gradient Boosting")
    print("✓ Logistic Regression")
    print("✓ Lightweight Ensemble")
    print("\nAll models use only scikit-learn and pandas")
    print("Run v27_lightweight_training.py to train models")