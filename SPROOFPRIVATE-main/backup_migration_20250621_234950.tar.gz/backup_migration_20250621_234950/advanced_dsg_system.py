
#!/usr/bin/env python3
"""
Advanced DSG (Deep Self-Generating) System with OpenRouter AI
=============================================================

Revolutionary system that uses OpenRouter AI models to write, analyze, and evolve
trading code autonomously. The AI literally writes its own trading strategies,
indicators, and arbitrage algorithms, then evolves them for maximum performance.

Features:
- AI-generated trading strategies using multiple LLMs
- Self-improving code that rewrites itself
- Meta-learning across all components
- Recursive enhancement and evolution
- Real-time code optimization
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import aiohttp
import json
import ast
import textwrap
import tempfile
import os
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import pandas as pd
from dataclasses import dataclass
import sqlite3
import hashlib

from universal_market_data import get_current_market_data, validate_price


# OpenRouter Configuration
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY')
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1/chat/completions"

# Available free models from OpenRouter
FREE_MODELS = {}
    # DeepSeek models - excellent for reasoning and code generation
    "DEEPSEEK_R1_0528_QWEN3": "deepseek/deepseek-r1-0528-qwen3-8b:free",
    "DEEPSEEK_R1_0528": "deepseek/deepseek-r1-0528:free", 
    "DEEPSEEK_PROVER_V2": "deepseek/deepseek-prover-v2:free",
    "DEEPSEEK_R1": "deepseek/deepseek-r1:free",
    "DEEPSEEK_V3": "deepseek/deepseek-chat:free",
    "DEEPSEEK_R1_ZERO": "deepseek/deepseek-r1-zero:free",
    
    # Meta Llama models - great for strategy generation
    "LLAMA_3_3_8B": "meta-llama/llama-3.3-8b-instruct:free",
    "LLAMA_3_3_70B": "meta-llama/llama-3.3-70b-instruct:free", 
    "LLAMA_4_MAVERICK": "meta-llama/llama-4-maverick:free",
    "LLAMA_4_SCOUT": "meta-llama/llama-4-scout:free",
    "LLAMA_3_1_8B": "meta-llama/llama-3.1-8b-instruct:free",
    
    # NVIDIA models - powerful for complex analysis
    "NVIDIA_NEMOTRON_49B": "nvidia/llama-3.3-nemotron-super-49b-v1:free",
    "NVIDIA_NEMOTRON_253B": "nvidia/llama-3.1-nemotron-ultra-253b-v1:free",
    
    # Google models - excellent for pattern recognition
    "GEMINI_2_5_PRO": "google/gemini-2.5-pro-exp-03-25",
    "GEMINI_2_0_FLASH": "google/gemini-2.0-flash-exp:free",
    
    # Specialized models
    "MISTRAL_DEVSTRAL": "mistralai/devstral-small:free",
    "QWEN_VL_72B": "qwen/qwen2.5-vl-72b-instruct:free",
    "KIMI_VL_A3B": "moonshotai/kimi-vl-a3b-thinking:free"
}

@dataclass
class AIGeneratedCode:
    """AI-generated trading code with full metadata"""
    code_id: str
    code_type: str  # 'strategy', 'indicator', 'arbitrage', 'model'
    source_code: str
    ai_model_used: str
    ai_reasoning: str
    performance_score: float
    generation: int
    parent_codes: List[str]
    created_at: datetime
    last_modified: datetime
    execution_count: int
    success_rate: float
    avg_profit: float
    risk_metrics: Dict[str, float]
    code_complexity: float
    readability_score: float
    
    def __post_init__(self):
        if not self.code_id:
            self.code_id = self._generate_code_id()
    
    def _generate_code_id(self) -> str:
        content_hash = hashlib.md5(self.source_code.encode().hexdigest()[:8]
        return f"{self.code_type}_{self.generation:03d}_{content_hash}"

class AICodeGenerator:
    """AI-powered code generator using OpenRouter models"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.session = None
        self.model_specializations = {}
            # Code generation specialists
            FREE_MODELS["DEEPSEEK_R1"]: "strategy_creation",
            FREE_MODELS["LLAMA_4_MAVERICK"]: "creative_strategies", 
            FREE_MODELS["MISTRAL_DEVSTRAL"]: "clean_code_generation",
            
            # Analysis specialists
            FREE_MODELS["DEEPSEEK_PROVER_V2"]: "mathematical_analysis",
            FREE_MODELS["NVIDIA_NEMOTRON_253B"]: "complex_reasoning",
            FREE_MODELS["GEMINI_2_5_PRO"]: "pattern_recognition",
            
            # Optimization specialists
            FREE_MODELS["QWEN_VL_72B"]: "data_analysis",
            FREE_MODELS["LLAMA_3_3_70B"]: "performance_optimization"
        }
        
        self.generated_codes = {}
        self.model_performance = {}
        self.setup_logging()
    
    def setup_logging(self):
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    async def initialize(self):
        """Initialize the AI code generator"""
        self.session = aiohttp.ClientSession()
        self.logger.info("🤖 AI Code Generator initialized with OpenRouter")
    
    async def shutdown(self):
        """Shutdown the AI code generator"""
        if self.session:
            await self.session.close()
    
    async def call_ai_model(self, model_id: str, prompt: str, system_prompt: str = None) -> Dict[str, Any]:
        """Call OpenRouter AI model for code generation"""
        try:
            headers = {}
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json"
            }
            
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            
            payload = {}
                "model": model_id,
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 4000
            }
            
            async with self.session.post(OPENROUTER_BASE_URL, headers=headers, json=payload) as response:
                if response.status == 200:
                    result = await response.json()
                    content = result["choices"][0]["message"]["content"]
                    
                    return {}
                        "success": True,
                        "content": content,
                        "model": model_id,
                        "usage": result.get("usage", {})
                    }
                else:
                    error_text = await response.text()
                    self.logger.error(f"AI API error: {response.status} - {error_text}")
                    return {"success": False, "error": f"API error: {response.status}"}
                    
        except Exception as e:
            self.logger.error(f"AI model call failed: {e}")
            return {"success": False, "error": str(e)}
    
    async def generate_trading_strategy(self, requirements: str, market_data_summary: str) -> AIGeneratedCode:
        """Use AI to generate a complete trading strategy"""
        
        # Select best model for strategy creation
        model_id = FREE_MODELS["DEEPSEEK_R1"]  # Best for reasoning
        
        system_prompt = """You are an expert quantitative trading system developer. You write Python trading strategies that are:
1. Profitable and risk-managed
2. Based on sound technical analysis
3. Well-documented and readable
4. Executable with pandas DataFrame input

Generate ONLY the Python function code with proper error handling."""
        
        user_prompt = f"""
Create a Python trading strategy function with these requirements:
{requirements}

Market conditions to consider:
{market_data_summary}

Generate a function called 'ai_generated_strategy' that:
- Takes data: pd.DataFrame with OHLCV columns
- Returns dict with: signal, confidence, stop_loss, take_profit, reasoning
- Uses proper technical indicators
- Includes risk management
- Has clear buy/sell logic

Return ONLY the Python code, no explanations."""
        
        result = await self.call_ai_model(model_id, user_prompt, system_prompt)
        
        if result['success']:
            # Clean and validate the generated code
            code = self._extract_python_code(result['content'])
            
            return AIGeneratedCode()
                code_id="",
                code_type="strategy",
                source_code=code,
                ai_model_used=model_id,
                ai_reasoning=f"Generated strategy based on: {requirements}",
                performance_score=0.0,
                generation=0,
                parent_codes=[],
                created_at=datetime.now(),
                last_modified=datetime.now(),
                execution_count=0,
                success_rate=0.0,
                avg_profit=0.0,
                risk_metrics={},
                code_complexity=self._calculate_complexity(code),
                readability_score=self._calculate_readability(code)
            )
        else:
            raise Exception(f"Failed to generate strategy: {result.get('error', 'Unknown error')}")
    
    async def generate_technical_indicator(self, indicator_description: str) -> AIGeneratedCode:
        """Use AI to generate a custom technical indicator"""
        
        model_id = FREE_MODELS["DEEPSEEK_PROVER_V2"]  # Best for mathematical analysis
        
        system_prompt = """You are a technical analysis expert. Create custom technical indicators using pandas.
Focus on mathematical accuracy and numerical stability. Generate clean, efficient Python code."""
        
        user_prompt = f"""
Create a Python function for this technical indicator:
{indicator_description}

Requirements:
- Function name: 'ai_generated_indicator'
- Input: data (pd.DataFrame with OHLCV), period (int) 
- Output: pd.Series with indicator values
- Handle edge cases and NaN values
- Use vectorized pandas operations
- Include proper mathematical formulation

Return ONLY the Python code."""
        
        result = await self.call_ai_model(model_id, user_prompt, system_prompt)
        
        if result['success']:
            code = self._extract_python_code(result['content'])
            
            return AIGeneratedCode()
                code_id="",
                code_type="indicator", 
                source_code=code,
                ai_model_used=model_id,
                ai_reasoning=f"Generated indicator: {indicator_description}",
                performance_score=0.0,
                generation=0,
                parent_codes=[],
                created_at=datetime.now(),
                last_modified=datetime.now(),
                execution_count=0,
                success_rate=0.0,
                avg_profit=0.0,
                risk_metrics={},
                code_complexity=self._calculate_complexity(code),
                readability_score=self._calculate_readability(code)
            )
        else:
            raise Exception(f"Failed to generate indicator: {result.get('error', 'Unknown error')}")
    
    async def generate_arbitrage_strategy(self, market_context: str) -> AIGeneratedCode:
        """Use AI to generate arbitrage detection code"""
        
        model_id = FREE_MODELS["NVIDIA_NEMOTRON_253B"]  # Best for complex analysis
        
        system_prompt = """You are an arbitrage trading expert. Generate Python code that identifies and evaluates arbitrage opportunities.
Focus on market inefficiencies, pricing discrepancies, and risk-free profit opportunities."""
        
        user_prompt = f"""
Create a Python function to detect arbitrage opportunities:

Market context:
{market_context}

Requirements:
- Function name: 'ai_generated_arbitrage'
- Input: market_data (dict with symbol->price data)
- Output: list of arbitrage opportunities with profit estimates
- Identify price discrepancies
- Calculate expected profits
- Assess execution risks
- Include opportunity ranking

Return ONLY the Python code."""
        
        result = await self.call_ai_model(model_id, user_prompt, system_prompt)
        
        if result['success']:
            code = self._extract_python_code(result['content'])
            
            return AIGeneratedCode()
                code_id="",
                code_type="arbitrage",
                source_code=code,
                ai_model_used=model_id, 
                ai_reasoning=f"Generated arbitrage strategy for: {market_context}",
                performance_score=0.0,
                generation=0,
                parent_codes=[],
                created_at=datetime.now(),
                last_modified=datetime.now(),
                execution_count=0,
                success_rate=0.0,
                avg_profit=0.0,
                risk_metrics={},
                code_complexity=self._calculate_complexity(code),
                readability_score=self._calculate_readability(code)
            )
        else:
            raise Exception(f"Failed to generate arbitrage code: {result.get('error', 'Unknown error')}")
    
    async def improve_existing_code(self, existing_code: AIGeneratedCode, 
                                   performance_feedback: str) -> AIGeneratedCode:
        """Use AI to improve existing code based on performance feedback"""
        
        model_id = FREE_MODELS["LLAMA_3_3_70B"]  # Best for optimization
        
        system_prompt = """You are a code optimization expert. Improve existing trading code based on performance feedback.
Focus on enhancing profitability, reducing risk, and improving code quality."""
        
        user_prompt = f"""
Improve this trading code based on performance feedback:

Current Code:
```python
{existing_code.source_code}
```

Performance Feedback:
{performance_feedback}

Current Performance: {existing_code.performance_score:.3f}
Success Rate: {existing_code.success_rate:.1%}
Average Profit: {existing_code.avg_profit:.4f}

Enhance the code to:
1. Improve profitability
2. Reduce risk
3. Better handle edge cases
4. Optimize performance

Return ONLY the improved Python code."""
        
        result = await self.call_ai_model(model_id, user_prompt, system_prompt)
        
        if result['success']:
            improved_code = self._extract_python_code(result['content'])
            
            return AIGeneratedCode()
                code_id="",
                code_type=existing_code.code_type,
                source_code=improved_code,
                ai_model_used=model_id,
                ai_reasoning=f"Improved version based on: {performance_feedback}",
                performance_score=0.0,
                generation=existing_code.generation + 1,
                parent_codes=[existing_code.code_id],
                created_at=datetime.now(),
                last_modified=datetime.now(),
                execution_count=0,
                success_rate=0.0,
                avg_profit=0.0,
                risk_metrics={},
                code_complexity=self._calculate_complexity(improved_code),
                readability_score=self._calculate_readability(improved_code)
            )
        else:
            # If improvement fails, return mutation of original
            return self._mutate_code(existing_code)
    
    def _extract_python_code(self, ai_response: str) -> str:
        """Extract clean Python code from AI response"""
        # Look for code blocks
        if "```python" in ai_response:
            start = ai_response.find("```python") + 9
            end = ai_response.find("```", start)
            if end != -1:
                return ai_response[start:end].strip()
        elif "```" in ai_response:
            start = ai_response.find("```") + 3
            end = ai_response.find("```", start)
            if end != -1:
                return ai_response[start:end].strip()
        
        # If no code blocks, try to find function definitions
        lines = ai_response.split('\n')
        code_lines = []
        in_function = False
        
        for line in lines:
            if line.strip().startswith('def ') or line.strip().startswith('import '):
                in_function = True
            
            if in_function:
                code_lines.append(line)
        
        if code_lines:
            return '\n'.join(code_lines)
        
        # Last resort: return the whole response cleaned up
        return ai_response.strip()
    
    def _calculate_complexity(self, code: str) -> float:
        """Calculate code complexity score"""
        try:
            tree = ast.parse(code)
            complexity = 0
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.If, ast.For, ast.While, ast.With):)
                    complexity += 1
                elif isinstance(node, ast.FunctionDef):
                    complexity += len(node.args.args)
            
            return min(complexity / 10.0, 1.0)  # Normalize to 0-1
        except:
            return 0.5  # Default complexity
    
    def _calculate_readability(self, code: str) -> float:
        """Calculate code readability score"""
        try:
            lines = code.split('\n')
            comment_lines = sum(1 for line in lines if line.strip().startswith('#')
            total_lines = len([line for line in lines if line.strip()])
            
            if total_lines == 0:
                return 0.0
            
            # Basic readability metrics
            comment_ratio = comment_lines / total_lines
            avg_line_length = np.mean([len(line) for line in lines if line.strip()])
            
            # Score based on comments and reasonable line length
            readability = comment_ratio * 0.5 + (1.0 if avg_line_length < 80 else 0.5) * 0.5
            
            return min(readability, 1.0)
        except:
            return 0.5
    
    def _mutate_code(self, code: AIGeneratedCode) -> AIGeneratedCode:
        """Simple code mutation as fallback"""
        # Basic parameter mutation
        source = code.source_code
        
        # Change numerical constants
        import re
        def mutate_number(match):
            value = float(match.group(1)
            mutation = np.random.uniform(0.8, 1.2)
            return str(round(value * mutation, 3)
        
        mutated_source = re.sub(r'(\d+\.\d+)', mutate_number, source)
        
        return AIGeneratedCode()
            code_id="",
            code_type=code.code_type,
            source_code=mutated_source,
            ai_model_used="mutation",
            ai_reasoning="Mutated version of parent code",
            performance_score=0.0,
            generation=code.generation + 1,
            parent_codes=[code.code_id],
            created_at=datetime.now(),
            last_modified=datetime.now(),
            execution_count=0,
            success_rate=0.0,
            avg_profit=0.0,
            risk_metrics={},
            code_complexity=code.code_complexity,
            readability_score=code.readability_score
        )

class AdvancedDSGSystem:
    """Advanced DSG system with AI-generated code evolution"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.ai_generator = AICodeGenerator(config.get('ai_generator', {})
        
        # Code populations
        self.strategy_population = []
        self.indicator_population = []
        self.arbitrage_population = []
        
        # Evolution tracking
        self.generation = 0
        self.evolution_history = []
        
        # Database
        self.db_path = 'advanced_dsg_system.db'
        self.setup_database()
        self.setup_logging()
    
    def setup_logging(self):
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def setup_database(self):
        """Setup database for AI-generated code tracking"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(''')
        CREATE TABLE IF NOT EXISTS ai_generated_codes ()
            code_id TEXT PRIMARY KEY,
            code_type TEXT NOT NULL,
            source_code TEXT NOT NULL,
            ai_model_used TEXT NOT NULL,
            ai_reasoning TEXT NOT NULL,
            performance_score REAL NOT NULL,
            generation INTEGER NOT NULL,
            parent_codes TEXT,
            created_at TEXT NOT NULL,
            execution_count INTEGER DEFAULT 0,
            success_rate REAL DEFAULT 0,
            avg_profit REAL DEFAULT 0,
            code_complexity REAL DEFAULT 0,
            readability_score REAL DEFAULT 0
        )
        ''')
        
        conn.commit()
        conn.close()
    
    async def initialize(self):
        """Initialize the advanced DSG system"""
        await self.ai_generator.initialize()
        self.logger.info("🚀 Advanced DSG System initialized with AI code generation")
    
    async def shutdown(self):
        """Shutdown the system"""
        await self.ai_generator.shutdown()
    
    async def generate_initial_population(self):
        """Generate initial population using AI"""
        self.logger.info("🤖 Generating initial AI code population")
        
        # Strategy requirements for diversity
        strategy_requirements = []
            "Momentum-based strategy using moving averages and RSI",
            "Mean reversion strategy with Bollinger Bands",
            "Breakout strategy using volume confirmation", 
            "Volatility-based strategy with ATR and VIX",
            "Multi-timeframe strategy combining different signals"
        ]
        
        # Generate strategies
        for req in strategy_requirements:
            try:
                strategy = await self.ai_generator.generate_trading_strategy()
                    req, "Current market: moderate volatility, trending phase"
                )
                self.strategy_population.append(strategy)
                self._store_code(strategy)
                self.logger.info(f"Generated strategy: {strategy.code_id}")
            except Exception as e:
                self.logger.error(f"Failed to generate strategy for '{req}': {e}")
        
        # Indicator descriptions for diversity
        indicator_descriptions = []
            "Enhanced RSI with volume weighting",
            "Adaptive moving average that adjusts to volatility",
            "Custom momentum oscillator combining price and volume"
        ]
        
        # Generate indicators
        for desc in indicator_descriptions:
            try:
                indicator = await self.ai_generator.generate_technical_indicator(desc)
                self.indicator_population.append(indicator)
                self._store_code(indicator)
                self.logger.info(f"Generated indicator: {indicator.code_id}")
            except Exception as e:
                self.logger.error(f"Failed to generate indicator for '{desc}': {e}")
        
        # Generate arbitrage strategies
        arbitrage_contexts = []
            "Cross-market ETF arbitrage opportunities",
            "Options volatility arbitrage detection"
        ]
        
        for context in arbitrage_contexts:
            try:
                arbitrage = await self.ai_generator.generate_arbitrage_strategy(context)
                self.arbitrage_population.append(arbitrage)
                self._store_code(arbitrage)
                self.logger.info(f"Generated arbitrage: {arbitrage.code_id}")
            except Exception as e:
                self.logger.error(f"Failed to generate arbitrage for '{context}': {e}")
        
        self.logger.info(f"Initial population: {len(self.strategy_population)} strategies, ")
                        f"{len(self.indicator_population)} indicators, "
                        f"{len(self.arbitrage_population)} arbitrage")
    
    def _store_code(self, code: AIGeneratedCode):
        """Store AI-generated code in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(''')
        INSERT OR REPLACE INTO ai_generated_codes 
        (code_id, code_type, source_code, ai_model_used, ai_reasoning,
         performance_score, generation, parent_codes, created_at,
         execution_count, success_rate, avg_profit, code_complexity, readability_score)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', ()
            code.code_id, code.code_type, code.source_code, code.ai_model_used,
            code.ai_reasoning, code.performance_score, code.generation,
            json.dumps(code.parent_codes), code.created_at.isoformat(),
            code.execution_count, code.success_rate, code.avg_profit,
            code.code_complexity, code.readability_score
        )
        
        conn.commit()
        conn.close()
    
    async def evolve_population(self, performance_data: Dict[str, Any]):
        """Evolve the AI-generated code population"""
        self.generation += 1
        self.logger.info(f"🧬 Evolving AI code population - Generation {self.generation}")
        
        # Evolve strategies
        await self._evolve_strategies(performance_data)
        
        # Evolve indicators
        await self._evolve_indicators(performance_data)
        
        # Evolve arbitrage strategies
        await self._evolve_arbitrage(performance_data)
        
        # Track evolution metrics
        self._track_evolution_metrics()
    
    async def _evolve_strategies(self, performance_data: Dict[str, Any]):
        """Evolve trading strategies using AI improvement"""
        if not self.strategy_population:
            return
        
        # Sort by performance
        self.strategy_population.sort(key=lambda x: x.performance_score, reverse=True)
        
        # Keep top 50% (elitism)
        elite_count = max(1, len(self.strategy_population) // 2)
        new_population = self.strategy_population[:elite_count]
        
        # Generate improved versions of best strategies
        for strategy in self.strategy_population[:3]:  # Top 3
            try:
                feedback = f"Current performance: {strategy.performance_score:.3f}. "
                feedback += performance_data.get('feedback', 'Improve profitability and risk management.')
                
                improved = await self.ai_generator.improve_existing_code(strategy, feedback)
                new_population.append(improved)
                self._store_code(improved)
                
                self.logger.info(f"Improved strategy {strategy.code_id} -> {improved.code_id}")
                
            except Exception as e:
                self.logger.error(f"Failed to improve strategy {strategy.code_id}: {e}")
        
        # Fill remaining spots with new AI-generated strategies
        while len(new_population) < len(self.strategy_population):
            try:
                new_req = f"Advanced strategy for generation {self.generation}"
                new_strategy = await self.ai_generator.generate_trading_strategy()
                    new_req, "Market: evolving conditions, optimize for current performance"
                )
                new_population.append(new_strategy)
                self._store_code(new_strategy)
            except Exception as e:
                self.logger.error(f"Failed to generate new strategy: {e}")
                break
        
        self.strategy_population = new_population
    
    async def _evolve_indicators(self, performance_data: Dict[str, Any]):
        """Evolve technical indicators"""
        if not self.indicator_population:
            return
        
        # Simple evolution for indicators
        self.indicator_population.sort(key=lambda x: x.performance_score, reverse=True)
        
        best_indicator = self.indicator_population[0]
        try:
            feedback = f"Enhance mathematical accuracy and signal quality. "
            feedback += f"Current score: {best_indicator.performance_score:.3f}"
            
            improved = await self.ai_generator.improve_existing_code(best_indicator, feedback)
            self.indicator_population.append(improved)
            self._store_code(improved)
            
            self.logger.info(f"Improved indicator {best_indicator.code_id} -> {improved.code_id}")
            
        except Exception as e:
            self.logger.error(f"Failed to improve indicator: {e}")
    
    async def _evolve_arbitrage(self, performance_data: Dict[str, Any]):
        """Evolve arbitrage strategies"""
        if not self.arbitrage_population:
            return
        
        # Simple evolution for arbitrage
        self.arbitrage_population.sort(key=lambda x: x.performance_score, reverse=True)
        
        if self.arbitrage_population:
            best_arb = self.arbitrage_population[0]
            try:
                feedback = f"Enhance opportunity detection accuracy and profit estimation. "
                feedback += f"Current score: {best_arb.performance_score:.3f}"
                
                improved = await self.ai_generator.improve_existing_code(best_arb, feedback)
                self.arbitrage_population.append(improved)
                self._store_code(improved)
                
                self.logger.info(f"Improved arbitrage {best_arb.code_id} -> {improved.code_id}")
                
            except Exception as e:
                self.logger.error(f"Failed to improve arbitrage: {e}")
    
    def _track_evolution_metrics(self):
        """Track evolution progress"""
        all_codes = self.strategy_population + self.indicator_population + self.arbitrage_population
        
        if all_codes:
            performances = [code.performance_score for code in all_codes]
            complexities = [code.code_complexity for code in all_codes]
            readabilities = [code.readability_score for code in all_codes]
            
            metrics = {}
                'generation': self.generation,
                'total_codes': len(all_codes),
                'avg_performance': np.mean(performances),
                'best_performance': max(performances),
                'avg_complexity': np.mean(complexities),
                'avg_readability': np.mean(readabilities),
                'improvement_rate': 0.0
            }
            
            if len(self.evolution_history) > 0:
                prev_best = self.evolution_history[-1]['best_performance']
                current_best = metrics['best_performance']
                metrics['improvement_rate'] = (current_best - prev_best) / (prev_best + 1e-8)
            
            self.evolution_history.append(metrics)
    
    def get_best_codes(self) -> Dict[str, AIGeneratedCode]:
        """Get best performing AI-generated codes"""
        best_codes = {}
        
        if self.strategy_population:
            best_codes['strategy'] = max(self.strategy_population, key=lambda x: x.performance_score)
        
        if self.indicator_population:
            best_codes['indicator'] = max(self.indicator_population, key=lambda x: x.performance_score)
            
        if self.arbitrage_population:
            best_codes['arbitrage'] = max(self.arbitrage_population, key=lambda x: x.performance_score)
        
        return best_codes
    
    async def run_ai_evolution(self, generations: int = 5) -> Dict[str, Any]:
        """Run complete AI-driven code evolution"""
        self.logger.info(f"🚀 Starting AI code evolution for {generations} generations")
        
        # Generate initial population
        await self.generate_initial_population()
        
        # Simulate performance data (in production, use real market results)
        performance_data = {}
            'feedback': 'Focus on higher Sharpe ratios and lower drawdowns',
            'market_conditions': 'trending market with moderate volatility'
        }
        
        # Assign random performance scores for demo
        for population in [self.strategy_population, self.indicator_population, self.arbitrage_population]:
            for code in population:
                code.performance_score = np.random.uniform(0.3, 0.8)
                code.success_rate = np.random.uniform(0.4, 0.9)
                code.avg_profit = np.random.uniform(0.001, 0.05)
        
        start_time = time.time()
        
        # Evolution loop
        for gen in range(generations):
            await self.evolve_population(performance_data)
            
            if self.evolution_history:
                metrics = self.evolution_history[-1]
                self.logger.info(f"Generation {gen+1}: Best={metrics['best_performance']:.3f}, ")
                               f"Avg={metrics['avg_performance']:.3f}, "
                               f"Improvement={metrics['improvement_rate']:+.1%}")
        
        evolution_time = time.time() - start_time
        
        # Return results
        best_codes = self.get_best_codes()
        
        return {}
            'evolution_time': evolution_time,
            'generations_completed': generations,
            'total_codes_generated': len(self.strategy_population + self.indicator_population + self.arbitrage_population),
            'best_codes': best_codes,
            'evolution_history': self.evolution_history,
            'final_populations': {}
                'strategies': len(self.strategy_population),
                'indicators': len(self.indicator_population), 
                'arbitrage': len(self.arbitrage_population)
            }
        }

async def run_advanced_dsg_demo():
    """Run advanced DSG system demonstration"""
    print("🤖 Advanced DSG (Deep Self-Generating) System with AI")
    print("=" * 70)
    print("Revolutionary AI that WRITES and EVOLVES trading code autonomously")
    print("Using OpenRouter AI models for true code generation")
    print()
    
    # Configuration
    config = {}
        'ai_generator': {}
            'max_concurrent_requests': 3,
            'timeout_seconds': 30
        }
    }
    
    # Create advanced DSG system
    dsg_system = AdvancedDSGSystem(config)
    
    print("🔧 Advanced DSG Components:")
    print("  🤖 AI-Powered Code Generation (OpenRouter)")
    print("  🧠 Multi-Model Strategy Creation")
    print("  📈 Autonomous Code Improvement")
    print("  🔄 Recursive Self-Enhancement")
    print("  ⚡ Real-time Code Evolution")
    print()
    
    print("🌐 AI Models Available:")
    for name, model_id in list(FREE_MODELS.items()[:5]:
        print(f"  ✅ {name}: {model_id}")
    print(f"  ... and {len(FREE_MODELS)-5} more models")
    print()
    
    try:
        # Initialize system
        await dsg_system.initialize()
        
        # Run AI evolution
        print("🚀 Starting AI-driven code evolution...")
        results = await dsg_system.run_ai_evolution(generations=3)  # Shorter for demo
        
        # Display results
        print(f"\n📊 AI Evolution Results:")
        print(f"  Evolution Time: {results['evolution_time']:.1f} seconds")
        print(f"  Generations: {results['generations_completed']}")
        print(f"  Total AI-Generated Codes: {results['total_codes_generated']}")
        
        populations = results['final_populations']
        print(f"\n📈 Final Populations:")
        print(f"  AI Strategies: {populations['strategies']}")
        print(f"  AI Indicators: {populations['indicators']}")
        print(f"  AI Arbitrage: {populations['arbitrage']}")
        
        # Show best generated codes
        best_codes = results['best_codes']
        
        if 'strategy' in best_codes:
            strategy = best_codes['strategy']
            print(f"\n🏆 Best AI-Generated Strategy:")
            print(f"  Code ID: {strategy.code_id}")
            print(f"  AI Model: {strategy.ai_model_used.split('/')[-1]}")
            print(f"  Generation: {strategy.generation}")
            print(f"  Performance: {strategy.performance_score:.3f}")
            print(f"  Complexity: {strategy.code_complexity:.2f}")
            print(f"  Readability: {strategy.readability_score:.2f}")
            print(f"  AI Reasoning: {strategy.ai_reasoning[:80]}...")
            
            # Show code snippet
            lines = strategy.source_code.split('\n')[:8]
            print(f"\n📝 AI-Generated Code Snippet:")
            for i, line in enumerate(lines, 1):
                if line.strip():
                    print(f"  {i:2d}: {line}")
            print("     ... (truncated)")
        
        # Show evolution progress
        if results['evolution_history']:
            print(f"\n📊 Evolution Progress:")
            print("Gen | Best Score | Avg Score | Improvement")
            print("-" * 40)
            
            for i, metrics in enumerate(results['evolution_history']):
                print(f"{i+1:3d} |   {metrics['best_performance']:.3f}    |  {metrics['avg_performance']:.3f}   | {metrics['improvement_rate']:+6.1%}")
        
        print(f"\n✅ Advanced DSG demonstration completed!")
        print(f"🤖 AI successfully generated and evolved trading algorithms!")
        print(f"🚀 Ready for production deployment with continuous AI enhancement!")
        
    except Exception as e:
        print(f"❌ Demo error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        await dsg_system.shutdown()

if __name__ == "__main__":
    asyncio.run(run_advanced_dsg_demo()