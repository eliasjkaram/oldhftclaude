#!/usr/bin/env python3
"""
Monitor Trading with REAL Prices
================================
"""

import time
import os
from datetime import datetime
from universal_market_data import get_current_market_data

def monitor_real_trading():
    """Monitor trading with real market prices"""
    
    print("=" * 80)
    print("📊 MONITORING REAL-TIME TRADING WITH ACTUAL MARKET DATA")
    print("=" * 80)
    
    # Clear any old log entries by marking current position
    log_file = "production_trading.log"
    if os.path.exists(log_file):
        with open(log_file, 'a') as f:
            f.write(f"\n[{datetime.now()}] === REAL MARKET DATA MONITORING STARTED ===\n")
    
    last_size = 0
    trade_count = 0
    
    while True:
        try:
            os.system('clear')
            
            # Get current real prices
            symbols = ['AAPL', 'AMZN', 'GOOGL', 'TSLA', 'META', 'NVDA', 'SPY']
            real_prices = get_current_market_data(symbols)
            
            print("=" * 80)
            print("📊 REAL-TIME MARKET PRICES (from Alpaca API)")
            print("=" * 80)
            
            for symbol, data in real_prices.items():
                print(f"{symbol}: ${data['price']:.2f} | Bid: ${data['bid']:.2f} | Ask: ${data['ask']:.2f}")
            
            print("\n" + "=" * 80)
            print("📈 RECENT TRADING ACTIVITY")
            print("=" * 80)
            
            # Monitor new trades
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    content = f.read()
                    
                # Find marker for real data
                marker_pos = content.find("=== REAL MARKET DATA MONITORING STARTED ===")
                if marker_pos > 0:
                    new_content = content[marker_pos:]
                    trades = [line for line in new_content.split('\n') if 'EXECUTED:' in line]
                    
                    if trades:
                        print("\nRecent Trades with REAL prices:")
                        for trade in trades[-10:]:  # Last 10 trades
                            print(trade)
                            
                            # Validate prices
                            for symbol in symbols:
                                if f" {symbol} @" in trade:
                                    # Extract price from trade
                                    price_str = trade.split('@')[1].split(' ')[1].replace('$', '')
                                    try:
                                        trade_price = float(price_str)
                                        real_price = real_prices[symbol]['price']
                                        diff_pct = abs(trade_price - real_price) / real_price * 100
                                        
                                        if diff_pct > 10:
                                            print(f"  ⚠️ Price variance: Trade ${trade_price:.2f} vs Real ${real_price:.2f} ({diff_pct:.1f}% diff)")
                                        else:
                                            print(f"  ✅ Price validated: Trade ${trade_price:.2f} vs Real ${real_price:.2f} ({diff_pct:.1f}% diff)")
                                    except:
                                        pass
                    else:
                        print("\nWaiting for new trades with real prices...")
            
            print("\n" + "=" * 80)
            print("AI DISCOVERY STATUS")
            print("=" * 80)
            
            # Check AI discovery log
            ai_log = "ai_arbitrage.log"
            if os.path.exists(ai_log):
                with open(ai_log, 'r') as f:
                    ai_content = f.read()
                    discoveries = [line for line in ai_content.split('\n') if 'AI DISCOVERY:' in line]
                    
                    if discoveries:
                        print(f"Total Discoveries: {len(discoveries)}")
                        print("\nRecent AI Discoveries:")
                        for disc in discoveries[-5:]:
                            print(disc)
            
            print("\n🔄 Refreshing every 5 seconds...")
            print("Press Ctrl+C to stop")
            
            time.sleep(5)
            
        except KeyboardInterrupt:
            print("\n\nMonitoring stopped.")
            break
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(5)

if __name__ == "__main__":
    monitor_real_trading()