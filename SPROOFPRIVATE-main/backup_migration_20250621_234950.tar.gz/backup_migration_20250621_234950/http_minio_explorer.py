#!/usr/bin/env python3
"""
MinIO S3-compatible bucket explorer using HTTP requests
Explores the stockdb bucket at https://uschristmas.us/minio
"""

import requests
import xml.etree.ElementTree as ET
from datetime import datetime
import hashlib
import hmac
import urllib.parse
from collections import defaultdict
import json
import os
from typing import Dict, List, Tuple, Optional
import re

class MinIOExplorer:
    def __init__(self, endpoint: str, access_key: str, secret_key: str, secure: bool = True):
        """Initialize MinIO explorer with credentials."""
        self.endpoint = endpoint.rstrip('/')
        self.access_key = access_key
        self.secret_key = secret_key
        self.secure = secure
        self.protocol = 'https' if secure else 'http'
        self.base_url = f"{self.protocol}://{self.endpoint}"
        
    def _calculate_signature_v4(self, method: str, path: str, headers: Dict[str, str], 
                               params: Dict[str, str] = None) -> Dict[str, str]:
        """Calculate AWS Signature Version 4 for request authentication."""
        # AWS4-HMAC-SHA256 implementation
        service = 's3'
        region = 'us-east-1'  # Default region for MinIO
        
        # Create canonical request
        canonical_uri = path
        canonical_querystring = ''
        if params:
            canonical_querystring = '&'.join([f"{k}={urllib.parse.quote(str(v), safe='')}")
                                            for k, v in sorted(params.items())])
        
        # Sort headers
        canonical_headers = []
        signed_headers = []
        for k, v in sorted(headers.items(), key=lambda x: x[0].lower()):
            if k.lower() in ['host', 'x-amz-date', 'x-amz-content-sha256']:
                canonical_headers.append(f"{k.lower()}:{v.strip()}")
                signed_headers.append(k.lower())
        
        canonical_headers_str = '\n'.join(canonical_headers) + '\n'
        signed_headers_str = ';'.join(signed_headers)
        
        # Payload hash
        payload_hash = headers.get('x-amz-content-sha256', 'UNSIGNED-PAYLOAD')
        
        # Create canonical request
        canonical_request = f"{method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers_str}\n{signed_headers_str}\n{payload_hash}"
        
        # Create string to sign
        algorithm = 'AWS4-HMAC-SHA256'
        amz_date = headers['x-amz-date']
        date_stamp = amz_date[:8]
        credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
        
        string_to_sign = f"{algorithm}\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
        
        # Calculate signature
        def sign(key, msg):
            return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()
        
        k_date = sign(f"AWS4{self.secret_key}".encode('utf-8'), date_stamp)
        k_region = sign(k_date, region)
        k_service = sign(k_region, service)
        k_signing = sign(k_service, 'aws4_request')
        signature = hmac.new(k_signing, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()
        
        # Create authorization header
        authorization_header = f"{algorithm} Credential={self.access_key}/{credential_scope}, SignedHeaders={signed_headers_str}, Signature={signature}"
        
        headers['Authorization'] = authorization_header
        return headers
    
    def _make_request(self, method: str, path: str, params: Dict[str, str] = None) -> requests.Response:
        """Make authenticated request to MinIO."""
        # Prepare headers
        headers = {}
            'Host': self.endpoint,
            'x-amz-date': datetime.utcnow().strftime('%Y%m%dT%H%M%SZ'),
            'x-amz-content-sha256': 'UNSIGNED-PAYLOAD'
        }
        
        # Add signature
        headers = self._calculate_signature_v4(method, path, headers, params)
        
        # Make request
        url = f"{self.base_url}{path}"
        if params:
            url += '?' + '&'.join([f"{k}={v}" for k, v in params.items()])
            
        response = requests.request(method, url, headers=headers)
        return response
    
    def list_buckets(self) -> List[Dict[str, any]]:
        """List all buckets."""
        response = self._make_request('GET', '/')
        
        if response.status_code != 200:
            print(f"Error listing buckets: {response.status_code}")
            print(f"Response: {response.text}")
            return []
        
        # Parse XML response
        root = ET.fromstring(response.text)
        
        # Handle namespace
        ns = {'s3': 'http://s3.amazonaws.com/doc/2006-03-01/'}
        
        buckets = []
        for bucket in root.findall('.//s3:Bucket', ns):
            name = bucket.find('s3:Name', ns)
            creation_date = bucket.find('s3:CreationDate', ns)
            
            buckets.append({)
                'name': name.text if name is not None else '',
                'creation_date': creation_date.text if creation_date is not None else ''
            })
        
        return buckets
    
    def list_objects(self, bucket: str, prefix: str = '', delimiter: str = '', 
                    max_keys: int = 1000, continuation_token: str = None) -> Dict[str, any]:
        """List objects in a bucket with pagination support."""
        params = {}
            'list-type': '2',  # Use ListObjectsV2
            'max-keys': str(max_keys)
        }
        
        if prefix:
            params['prefix'] = prefix
        if delimiter:
            params['delimiter'] = delimiter
        if continuation_token:
            params['continuation-token'] = continuation_token
        
        response = self._make_request('GET', f"/{bucket}", params)
        
        if response.status_code != 200:
            print(f"Error listing objects: {response.status_code}")
            print(f"Response: {response.text}")
            return {'objects': [], 'common_prefixes': [], 'is_truncated': False}
        
        # Parse XML response
        root = ET.fromstring(response.text)
        
        # Handle namespace
        ns = {'s3': 'http://s3.amazonaws.com/doc/2006-03-01/'}
        
        result = {}
            'objects': [],
            'common_prefixes': [],
            'is_truncated': root.find('s3:IsTruncated', ns).text == 'true' if root.find('s3:IsTruncated', ns) is not None else False,
            'next_continuation_token': None,
            'key_count': 0
        }
        
        # Get next continuation token if available
        next_token = root.find('s3:NextContinuationToken', ns)
        if next_token is not None:
            result['next_continuation_token'] = next_token.text
        
        # Get key count
        key_count = root.find('s3:KeyCount', ns)
        if key_count is not None:
            result['key_count'] = int(key_count.text)
        
        # Parse objects
        for obj in root.findall('.//s3:Contents', ns):
            key = obj.find('s3:Key', ns)
            size = obj.find('s3:Size', ns)
            last_modified = obj.find('s3:LastModified', ns)
            etag = obj.find('s3:ETag', ns)
            
            result['objects'].append({)
                'key': key.text if key is not None else '',
                'size': int(size.text) if size is not None else 0,
                'last_modified': last_modified.text if last_modified is not None else '',
                'etag': etag.text.strip('"') if etag is not None else ''
            })
        
        # Parse common prefixes (directories)
        for prefix in root.findall('.//s3:CommonPrefixes', ns):
            prefix_elem = prefix.find('s3:Prefix', ns)
            if prefix_elem is not None:
                result['common_prefixes'].append(prefix_elem.text)
        
        return result
    
    def explore_bucket(self, bucket_name: str) -> Dict[str, any]:
        """Comprehensively explore a bucket and create an inventory."""
        print(f"\nExploring bucket: {bucket_name}")
        print("=" * 50)
        
        inventory = {}
            'bucket_name': bucket_name,
            'total_objects': 0,
            'total_size': 0,
            'file_types': defaultdict(int),
            'file_extensions': defaultdict(int),
            'directories': set(),
            'datasets': [],
            'data_formats': defaultdict(list),
            'size_distribution': {}
                'under_1MB': 0,
                '1MB_to_10MB': 0,
                '10MB_to_100MB': 0,
                '100MB_to_1GB': 0,
                'over_1GB': 0
            }
        }
        
        # List all objects with pagination
        continuation_token = None
        page = 0
        
        while True:
            page += 1
            print(f"\nFetching page {page}...")
            
            result = self.list_objects(bucket_name, continuation_token=continuation_token)
            
            if not result['objects'] and not result['common_prefixes']:
                break
            
            # Process objects
            for obj in result['objects']:
                inventory['total_objects'] += 1
                inventory['total_size'] += obj['size']
                
                # Extract file information
                key = obj['key']
                parts = key.split('/')
                
                # Track directories
                for i in range(1, len(parts)):
                    inventory['directories'].add('/'.join(parts[:i]))
                
                # Track file extensions
                if '.' in parts[-1]:
                    ext = parts[-1].split('.')[-1].lower()
                    inventory['file_extensions'][ext] += 1
                    
                    # Categorize data types
                    data_type = self._categorize_file_type(ext)
                    inventory['file_types'][data_type] += 1
                    inventory['data_formats'][data_type].append(key)
                
                # Track size distribution
                size_mb = obj['size'] / (1024 * 1024)
                if size_mb < 1:
                    inventory['size_distribution']['under_1MB'] += 1
                elif size_mb < 10:
                    inventory['size_distribution']['1MB_to_10MB'] += 1
                elif size_mb < 100:
                    inventory['size_distribution']['10MB_to_100MB'] += 1
                elif size_mb < 1024:
                    inventory['size_distribution']['100MB_to_1GB'] += 1
                else:
                    inventory['size_distribution']['over_1GB'] += 1
                
                # Identify potential datasets
                if self._is_dataset(key, ext):
                    inventory['datasets'].append({)
                        'path': key,
                        'size': obj['size'],
                        'last_modified': obj['last_modified'],
                        'type': data_type,
                        'extension': ext
                    })
            
            # Check if there are more pages
            if not result['is_truncated']:
                break
            
            continuation_token = result['next_continuation_token']
        
        # Convert sets to lists for JSON serialization
        inventory['directories'] = sorted(list(inventory['directories']))
        
        # Limit data format examples to 10 per type
        for data_type in inventory['data_formats']:
            inventory['data_formats'][data_type] = inventory['data_formats'][data_type][:10]
        
        return inventory
    
    def _categorize_file_type(self, extension: str) -> str:
        """Categorize file based on extension."""
        categories = {}
            'tabular': ['csv', 'tsv', 'xlsx', 'xls', 'parquet', 'feather', 'arrow'],
            'json': ['json', 'jsonl', 'ndjson'],
            'database': ['db', 'sqlite', 'sqlite3', 'mdb'],
            'compressed': ['zip', 'gz', 'bz2', 'xz', 'tar', '7z', 'rar'],
            'text': ['txt', 'log', 'md', 'rst'],
            'binary': ['bin', 'dat', 'pickle', 'pkl'],
            'config': ['yml', 'yaml', 'toml', 'ini', 'conf', 'cfg'],
            'script': ['py', 'r', 'sql', 'sh', 'bat'],
            'document': ['pdf', 'doc', 'docx', 'odt'],
            'image': ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'tiff'],
            'video': ['mp4', 'avi', 'mov', 'mkv', 'webm'],
            'audio': ['mp3', 'wav', 'flac', 'ogg', 'm4a']
        }
        
        for category, extensions in categories.items():
            if extension in extensions:
                return category
        
        return 'other'
    
    def _is_dataset(self, key: str, extension: str) -> bool:
        """Determine if a file is likely a dataset."""
        dataset_extensions = ['csv', 'tsv', 'parquet', 'json', 'jsonl', 'xlsx', 'xls', 
                            'db', 'sqlite', 'feather', 'arrow', 'hdf5', 'h5']
        
        # Check extension
        if extension in dataset_extensions:
            return True
        
        # Check for compressed datasets
        if extension in ['gz', 'zip', 'bz2'] and any(ext in key.lower() for ext in dataset_extensions):
            return True
        
        # Check for common dataset keywords in path
        dataset_keywords = ['data', 'dataset', 'corpus', 'sample', 'train', 'test', 'validation']
        return any(keyword in key.lower() for keyword in dataset_keywords)
    
    def print_inventory_summary(self, inventory: Dict[str, any]):
        """Print a formatted summary of the inventory."""
        print("\n" + "=" * 60)
        print(f"BUCKET INVENTORY SUMMARY: {inventory['bucket_name']}")
        print("=" * 60)
        
        print(f"\nTotal Objects: {inventory['total_objects']:,}")
        print(f"Total Size: {self._format_size(inventory['total_size'])}")
        
        print("\nFile Types Distribution:")
        for file_type, count in sorted(inventory['file_types'].items(), key=lambda x: x[1], reverse=True):
            print(f"  {file_type}: {count:,} files")
        
        print("\nTop File Extensions:")
        for ext, count in sorted(inventory['file_extensions'].items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"  .{ext}: {count:,} files")
        
        print("\nSize Distribution:")
        for size_range, count in inventory['size_distribution'].items():
            print(f"  {size_range}: {count:,} files")
        
        print(f"\nTotal Directories: {len(inventory['directories']):,}")
        
        print(f"\nIdentified Datasets: {len(inventory['datasets']):,}")
        if inventory['datasets']:
            print("\nTop 10 Datasets by Size:")
            sorted_datasets = sorted(inventory['datasets'], key=lambda x: x['size'], reverse=True)[:10]
            for ds in sorted_datasets:
                print(f"  {ds['path']}")
                print(f"    Size: {self._format_size(ds['size'])}, Type: {ds['type']}, Modified: {ds['last_modified']}")
    
    def _format_size(self, size_bytes: int) -> str:
        """Format size in human-readable format."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} PB"
    
    def save_inventory(self, inventory: Dict[str, any], filename: str):
        """Save inventory to JSON file."""
        with open(filename, 'w') as f:
            json.dump(inventory, f, indent=2, default=str)
        print(f"\nInventory saved to: {filename}")


def main():
    """Main function to explore MinIO bucket."""
    # Configuration
    MINIO_ENDPOINT = "uschristmas.us/minio"
    BUCKET_NAME = "stockdb"
    
    # Get credentials from environment or use defaults
    ACCESS_KEY = os.environ.get('MINIO_ACCESS_KEY', 'minioadmin')
    SECRET_KEY = os.environ.get('MINIO_SECRET_KEY', 'minioadmin')
    
    print("MinIO Bucket Explorer")
    print("=" * 60)
    print(f"Endpoint: {MINIO_ENDPOINT}")
    print(f"Target Bucket: {BUCKET_NAME}")
    
    # Initialize explorer
    explorer = MinIOExplorer(MINIO_ENDPOINT, ACCESS_KEY, SECRET_KEY)
    
    try:
        # List all buckets
        print("\nListing all buckets...")
        buckets = explorer.list_buckets()
        
        if buckets:
            print(f"\nFound {len(buckets)} bucket(s):")
            for bucket in buckets:
                print(f"  - {bucket['name']} (created: {bucket['creation_date']})")
        else:
            print("No buckets found or unable to list buckets.")
        
        # Explore the stockdb bucket
        inventory = explorer.explore_bucket(BUCKET_NAME)
        
        # Print summary
        explorer.print_inventory_summary(inventory)
        
        # Save detailed inventory
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        inventory_file = f"minio_inventory_{BUCKET_NAME}_{timestamp}.json"
        explorer.save_inventory(inventory, inventory_file)
        
        # Print sample data formats
        print("\nSample Files by Data Format:")
        for data_type, files in inventory['data_formats'].items():
            if files:
                print(f"\n{data_type.upper()}:")
                for file in files[:5]:  # Show up to 5 examples
                    print(f"  - {file}")
        
    except Exception as e:
        print(f"\nError during exploration: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()