#!/usr/bin/env python3
"""
Enhanced Universal Trading Analyzer
===================================
Improved version with better error handling, offline data, and enhanced features
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import requests
from threading import Thread
import time
import os
import pickle

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, validate_price



class EnhancedTradingAnalyzer:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced Universal Trading Analyzer - Multi-Symbol Strategy Engine")
        self.root.geometry("1600x1100")
        
        # Data storage
        self.current_symbol = "SPY"  # Start with SPY as it's more reliable
        self.market_data = None
        self.current_price = None
        self.current_iv = None
        self.strategies = []
        
        # Cache for offline data
        self.data_cache = {}
        self.cache_file = "market_data_cache.pkl"
        
        # Load cached data if available
        self._load_cache()
        
        # Create GUI
        self._create_widgets()
        
        # Initialize with cached data or generate sample data
        self.root.after(100, self._initialize_data)
        
    def _load_cache(self):
        """Load cached market data"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'rb') as f:
                    self.data_cache = pickle.load(f)
        except Exception as e:
            print(f"Could not load cache: {e}")
            self.data_cache = {}
            
    def _save_cache(self):
        """Save market data to cache"""
        try:
            with open(self.cache_file, 'wb') as f:
                pickle.dump(self.data_cache, f)
        except Exception as e:
            print(f"Could not save cache: {e}")
            
    def _create_sample_data(self, symbol):
        """Create realistic sample data for demonstration"""
        
        # Base prices for different symbols
        base_prices = {}
            'SPY': 480, 'QQQ': 380, 'IWM': 200, 'TLT': 108,
            'AAPL': 190, 'MSFT': 410, 'GOOGL': 140, 'META': 350,
            'TSLA': 250, 'NVDA': 800, 'AMZN': 155, 'BTC-USD': 65000
        }
        
        base_price = base_prices.get(symbol, 100)
        
        # Generate 252 trading days of data
        dates = pd.date_range(end=datetime.now() - timedelta(days=1), periods=252, freq='B')
        
        # Different volatility profiles
        volatilities = {}
            'SPY': 0.015, 'QQQ': 0.020, 'IWM': 0.025, 'TLT': 0.012,
            'AAPL': 0.025, 'MSFT': 0.020, 'GOOGL': 0.025, 'META': 0.035,
            'TSLA': 0.045, 'NVDA': 0.035, 'AMZN': 0.030, 'BTC-USD': 0.08
        }
        
        vol = volatilities.get(symbol, 0.025)
        
        # Generate realistic price movements
        np.random.seed(hash(symbol) % 1000)  # Consistent data per symbol
        
        # Create trending + mean-reverting behavior
        trend = np.cumsum(np.random.normal(0.0002, 0.001, 252)  # Small upward bias)
        mean_revert = np.random.normal(0, vol, 252)
        
        # Combine for realistic price action
        returns = trend + mean_revert
        prices = base_price * (1 + returns).cumprod()
        
        # Add some realistic features
        volumes = np.random.lognormal(np.log(1000000), 0.5, 252).astype(int)
        
        # Create OHLC data
        price_changes = np.random.uniform(0.995, 1.005, 252)
        
        data = pd.DataFrame({)
            'Date': dates,
            'Open': prices * price_changes,
            'High': prices * np.random.uniform(1.001, 1.015, 252),
            'Low': prices * np.random.uniform(0.985, 0.999, 252),
            'Close': prices,
            'Volume': volumes
        })
        
        data.set_index('Date', inplace=True)
        return data
        
    def _create_widgets(self):
        """Create all GUI widgets"""
        
        # Main container with scrollable frame
        main_canvas = tk.Canvas(self.root)
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=main_canvas.yview)
        scrollable_frame = ttk.Frame(main_canvas)
        
        scrollable_frame.bind()
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all")
        )
        
        main_canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack canvas and scrollbar
        main_canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Main frame
        main_frame = ttk.Frame(scrollable_frame, padding="15")
        main_frame.pack(fill="both", expand=True)
        
        # Configure weights
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill="x", pady=(0, 15)
        
        title_label = ttk.Label(title_frame, text="🎯 Enhanced Universal Trading Analyzer", 
                               font=('Arial', 20, 'bold')
        title_label.pack()
        
        subtitle_label = ttk.Label(title_frame, text="Multi-Symbol Strategy Engine with Advanced Bias Integration", 
                                  font=('Arial', 12, 'italic')
        subtitle_label.pack()
        
        # Symbol Selection Section
        symbol_frame = ttk.LabelFrame(main_frame, text="📊 Symbol Selection & Data", padding="15")
        symbol_frame.pack(fill="x", pady=(0, 10)
        
        # Symbol input row
        symbol_input_frame = ttk.Frame(symbol_frame)
        symbol_input_frame.pack(fill="x", pady=(0, 10)
        
        ttk.Label(symbol_input_frame, text="Symbol:", font=('Arial', 11, 'bold').pack(side="left", padx=(0, 10)
        
        self.symbol_var = tk.StringVar(value=self.current_symbol)
        symbol_entry = ttk.Entry(symbol_input_frame, textvariable=self.symbol_var, width=12, font=('Arial', 11)
        symbol_entry.pack(side="left", padx=(0, 10)
        
        load_btn = ttk.Button(symbol_input_frame, text="📈 Load Data", command=self._load_current_symbol)
        load_btn.pack(side="left", padx=(0, 20)
        
        # Data source indicator
        self.data_source_var = tk.StringVar(value="Sample Data")
        data_source_label = ttk.Label(symbol_input_frame, textvariable=self.data_source_var, 
                                     font=('Arial', 10, 'italic'), foreground='blue')
        data_source_label.pack(side="left")
        
        # Quick symbol buttons
        quick_frame = ttk.LabelFrame(symbol_frame, text="Quick Select", padding="10")
        quick_frame.pack(fill="x", pady=(10, 0)
        
        symbol_categories = {}
            "ETFs": ["SPY", "QQQ", "IWM", "TLT", "GLD", "VIX"],
            "Tech": ["AAPL", "MSFT", "GOOGL", "META", "NVDA", "AMZN"],
            "Growth": ["TSLA", "NFLX", "AMD", "CRM", "SHOP", "PLTR"],
            "Crypto": ["BTC-USD", "ETH-USD", "COIN", "MSTR"]
        }
        
        for category, symbols in symbol_categories.items():
            cat_frame = ttk.Frame(quick_frame)
            cat_frame.pack(fill="x", pady=2)
            
            ttk.Label(cat_frame, text=f"{category}:", font=('Arial', 10, 'bold'), width=8).pack(side="left")
            
            for symbol in symbols:
                btn = ttk.Button(cat_frame, text=symbol, width=8,
                               command=lambda s=symbol: self._quick_load_symbol(s)
                btn.pack(side="left", padx=2)
                
        # Market View Section
        view_frame = ttk.LabelFrame(main_frame, text="💭 Your Market View & Analysis", padding="15")
        view_frame.pack(fill="x", pady=(0, 10)
        view_frame.columnconfigure(0, weight=1)
        
        # Bias input
        ttk.Label(view_frame, text="Express your view about this symbol:", 
                 font=('Arial', 11, 'bold').grid(row=0, column=0, sticky="w", pady=(0, 5)
        
        self.bias_text = scrolledtext.ScrolledText(view_frame, height=4, width=100, wrap=tk.WORD)
        self.bias_text.grid(row=1, column=0, sticky="ew", pady=(0, 10)
        self.bias_text.insert('1.0', f"I believe {self.current_symbol} will trend higher over the next 6 months due to strong fundamentals")
        
        # Bias templates
        template_frame = ttk.LabelFrame(view_frame, text="Quick Templates", padding="10")
        template_frame.grid(row=2, column=0, sticky="ew", pady=(10, 10)
        
        templates = []
            ("🚀 Strongly Bullish", "will rally strongly over the next year with high conviction"),
            ("📈 Moderately Bullish", "should trend up moderately over the coming months"),
            ("📊 Range Bound", "will likely stay in the current trading range"),
            ("📉 Moderately Bearish", "will probably decline over the next few months"),
            ("💥 Strongly Bearish", "will drop significantly due to fundamental issues")
        ]
        
        for i, (label, template) in enumerate(templates):
            btn = ttk.Button(template_frame, text=label, width=20,
                           command=lambda t=template: self._set_bias_template(t)
            btn.grid(row=i//3, column=i%3, padx=5, pady=2, sticky="ew")
            
        # Analysis button
        analyze_btn = ttk.Button(view_frame, text="🔍 Generate Strategy Recommendations", 
                               command=self._analyze_bias, style='Accent.TButton')
        analyze_btn.grid(row=3, column=0, pady=(15, 0)
        
        # Results Section
        results_frame = ttk.Frame(main_frame)
        results_frame.pack(fill="both", expand=True, pady=(10, 0)
        results_frame.columnconfigure(0, weight=1)
        results_frame.columnconfigure(1, weight=2)
        results_frame.rowconfigure(0, weight=1)
        
        # Market Data Panel
        data_panel = ttk.LabelFrame(results_frame, text="📊 Market Analysis", padding="10")
        data_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 5)
        data_panel.rowconfigure(0, weight=1)
        data_panel.columnconfigure(0, weight=1)
        
        self.data_text = scrolledtext.ScrolledText(data_panel, width=50, wrap=tk.WORD)
        self.data_text.grid(row=0, column=0, sticky="nsew")
        
        # Strategy Panel
        strategy_panel = ttk.LabelFrame(results_frame, text="🎯 Strategy Recommendations", padding="10")
        strategy_panel.grid(row=0, column=1, sticky="nsew", padx=(5, 0)
        strategy_panel.rowconfigure(0, weight=1)
        strategy_panel.columnconfigure(0, weight=1)
        
        # Strategy treeview
        columns = ('Strategy', 'Direction', 'Max Profit', 'Max Loss', 'Win Rate', 'Score')
        self.strategy_tree = ttk.Treeview(strategy_panel, columns=columns, show='headings', height=12)
        
        # Configure columns
        column_widths = {'Strategy': 200, 'Direction': 100, 'Max Profit': 100, 
                        'Max Loss': 100, 'Win Rate': 80, 'Score': 70}
        
        for col in columns:
            self.strategy_tree.heading(col, text=col)
            self.strategy_tree.column(col, width=column_widths[col])
            
        self.strategy_tree.grid(row=0, column=0, sticky="nsew")
        
        # Strategy scrollbar
        strategy_scroll = ttk.Scrollbar(strategy_panel, orient="vertical", command=self.strategy_tree.yview)
        strategy_scroll.grid(row=0, column=1, sticky="ns")
        self.strategy_tree.configure(yscrollcommand=strategy_scroll.set)
        
        # Strategy Details Section
        details_panel = ttk.LabelFrame(main_frame, text="📋 Strategy Implementation Details", padding="15")
        details_panel.pack(fill="both", expand=True, pady=(10, 0)
        details_panel.rowconfigure(0, weight=1)
        details_panel.columnconfigure(0, weight=1)
        
        self.details_text = scrolledtext.ScrolledText(details_panel, height=18, wrap=tk.WORD)
        self.details_text.grid(row=0, column=0, sticky="nsew")
        
        # Status Bar
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill="x", pady=(10, 0)
        
        self.status_var = tk.StringVar(value="🟢 Ready - Select symbol and express your market view")
        status_bar = ttk.Label(status_frame, textvariable=self.status_var, relief="sunken", 
                              font=('Arial', 10)
        status_bar.pack(fill="x")
        
        # Bind events
        self.strategy_tree.bind('<<TreeviewSelect>>', self._on_strategy_select)
        symbol_entry.bind('<Return>', lambda e: self._load_current_symbol()
        
        # Mouse wheel binding for canvas
        def _on_mousewheel(event):
            main_canvas.yview_scroll(int(-1*(event.delta/120), "units")
        main_canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
    def _initialize_data(self):
        """Initialize with sample data"""
        self._load_symbol_data(self.current_symbol, use_sample=True)
        
    def _quick_load_symbol(self, symbol):
        """Quick load symbol from button"""
        self.symbol_var.set(symbol)
        self._load_current_symbol()
        
    def _load_current_symbol(self):
        """Load currently entered symbol"""
        symbol = self.symbol_var.get().strip().upper()
        if not symbol:
            messagebox.showwarning("Input Required", "Please enter a symbol")
            return
        self._load_symbol_data(symbol)
        
    def _load_symbol_data(self, symbol, use_sample=False):
        """Load market data for symbol"""
        self.status_var.set(f"🔄 Loading {symbol} data...")
        
        def load_data():
            try:
                if not use_sample:
                    # Try to get real data first
                    try:
                        import yfinance as yf
                        ticker = yf.Ticker(symbol)
                        hist_data = ticker.history(period="1y")
                        
                        if not hist_data.empty:
                            # Real data success
                            self.market_data = hist_data
                            self.current_symbol = symbol
                            self.current_price = hist_data['Close'].iloc[-1]
                            
                            # Cache the data
                            self.data_cache[symbol] = {}
                                'data': hist_data,
                                'timestamp': datetime.now(),
                                'price': self.current_price
                            }
                            self._save_cache()
                            
                            self.root.after(0, lambda: self.data_source_var.set("📡 Live Data")
                            self.root.after(0, self._update_market_display)
                            self.root.after(0, self._update_bias_text)
                            return
                            
                    except Exception as e:
                        print(f"Yahoo Finance failed: {e}")
                
                # Check cache
                if symbol in self.data_cache:
                    cache_entry = self.data_cache[symbol]
                    if (datetime.now() - cache_entry['timestamp']).hours < 24:
                        self.market_data = cache_entry['data']
                        self.current_symbol = symbol
                        self.current_price = cache_entry['price']
                        
                        self.root.after(0, lambda: self.data_source_var.set("💾 Cached Data")
                        self.root.after(0, self._update_market_display)
                        self.root.after(0, self._update_bias_text)
                        return
                
                # Fall back to sample data
                self.market_data = self._create_sample_data(symbol)
                self.current_symbol = symbol
                self.current_price = self.market_data['Close'].iloc[-1]
                
                self.root.after(0, lambda: self.data_source_var.set("🎲 Sample Data")
                self.root.after(0, self._update_market_display)
                self.root.after(0, self._update_bias_text)
                
            except Exception as e:
                error_msg = f"Error loading {symbol}: {str(e)}"
                self.root.after(0, lambda: messagebox.showerror("Data Error", error_msg)
                self.root.after(0, lambda: self.status_var.set(f"❌ Failed to load {symbol}")
                
        Thread(target=load_data, daemon=True).start()
        
    def _update_market_display(self):
        """Update market data display with enhanced analysis"""
        self.data_text.delete('1.0', tk.END)
        
        if self.market_data is None:
            return
            
        # Calculate comprehensive metrics
        close_prices = self.market_data['Close']
        volumes = self.market_data['Volume']
        
        # Calculate IV using rolling volatility
        returns = close_prices.pct_change().dropna()
        self.current_iv = returns.rolling(30).std().iloc[-1] * np.sqrt(252)
        
        # Performance calculations
        def safe_return(days):
            if len(close_prices) > days:
                return ((self.current_price / close_prices.iloc[-days-1]) - 1) * 100
            return 0
            
        # Technical indicators
        def get_sma(period):
            return close_prices.rolling(period).mean().iloc[-1] if len(close_prices) > period else self.current_price
            
        def get_ema(period):
            return close_prices.ewm(span=period).mean().iloc[-1] if len(close_prices) > period else self.current_price
            
        def get_rsi(period=14):
            if len(close_prices) < period:
                return 50
            delta = close_prices.diff()
            gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
            loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
            rs = gain / loss
            return 100 - (100 / (1 + rs).iloc[-1]
            
        def get_bollinger_bands():
            sma = close_prices.rolling(20).mean()
            std = close_prices.rolling(20).std()
            upper = sma + (std * 2)
            lower = sma - (std * 2)
            return upper.iloc[-1], lower.iloc[-1], sma.iloc[-1]
            
        # Calculate metrics
        sma_20 = get_sma(20)
        sma_50 = get_sma(50)
        sma_200 = get_sma(200)
        ema_12 = get_ema(12)
        ema_26 = get_ema(26)
        rsi = get_rsi()
        bb_upper, bb_lower, bb_middle = get_bollinger_bands()
        
        # Volume analysis
        avg_volume = volumes.mean()
        recent_volume = volumes.tail(5).mean()
        volume_ratio = recent_volume / avg_volume
        
        # Range analysis
        periods = [10, 20, 30, 60]
        range_analysis = {}
        for period in periods:
            if len(close_prices) >= period:
                period_data = close_prices.tail(period)
                range_analysis[period] = {}
                    'high': period_data.max(),
                    'low': period_data.min(),
                    'position': ((self.current_price - period_data.min() /))
                               (period_data.max() - period_data.min() * 100) if period_data.max() != period_data.min() else 50
                }
                
        # Trend analysis
        def get_trend_strength():
            if len(close_prices) < 20:
                return "Insufficient Data"
            
            short_trend = (self.current_price / get_sma(10) - 1) * 100
            medium_trend = (self.current_price / get_sma(20) - 1) * 100
            long_trend = (self.current_price / get_sma(50) - 1) * 100
            
            if short_trend > 2 and medium_trend > 1:
                return "Strong Uptrend"
            elif short_trend > 0.5 and medium_trend > 0:
                return "Moderate Uptrend"
            elif short_trend < -2 and medium_trend < -1:
                return "Strong Downtrend"
            elif short_trend < -0.5 and medium_trend < 0:
                return "Moderate Downtrend"
            else:
                return "Sideways/Consolidating"
                
        trend_strength = get_trend_strength()
        
        # Format comprehensive display
        data_text = f"""{self.current_symbol} - Comprehensive Market Analysis
{'='*50}
Data Source: {self.data_source_var.get()}
Last Updated: {self.market_data.index[-1].strftime('%Y-%m-%d %H:%M')}

💰 CURRENT METRICS
Current Price: ${self.current_price:.2f}
Implied Volatility: {self.current_iv*100:.1f}%
Trend: {trend_strength}

📈 PERFORMANCE SUMMARY
1-Day: {safe_return(1):+.2f}%
1-Week: {safe_return(5):+.2f}%
2-Week: {safe_return(10):+.2f}%
1-Month: {safe_return(22):+.2f}%
3-Month: {safe_return(66):+.2f}%
6-Month: {safe_return(126):+.2f}%
1-Year: {safe_return(252):+.2f}%

🔍 TECHNICAL INDICATORS
RSI (14): {rsi:.1f} {'[Overbought]' if rsi > 70 else '[Oversold]' if rsi < 30 else '[Neutral]'}
MACD Signal: {'Bullish' if ema_12 > ema_26 else 'Bearish'}

Moving Averages:
• 20-SMA: ${sma_20:.2f} ({((self.current_price/sma_20-1)*100):+.1f}%)
• 50-SMA: ${sma_50:.2f} ({((self.current_price/sma_50-1)*100):+.1f}%)
• 200-SMA: ${sma_200:.2f} ({((self.current_price/sma_200-1)*100):+.1f}%)

Bollinger Bands:
• Upper: ${bb_upper:.2f}
• Middle: ${bb_middle:.2f}
• Lower: ${bb_lower:.2f}
• Position: {((self.current_price - bb_lower)/(bb_upper - bb_lower)*100):.0f}%

📊 RANGE ANALYSIS"""

        for period in [20, 60]:
            if period in range_analysis:
                ra = range_analysis[period]
                data_text += f"""
{period}-Day Range:
• High: ${ra['high']:.2f}
• Low: ${ra['low']:.2f}
• Position: {ra['position']:.1f}%
• Width: {((ra['high']/ra['low']-1)*100):.1f}%"""

        data_text += f"""

📈 VOLUME ANALYSIS
Average Volume: {avg_volume:,.0f}
Recent 5-Day Avg: {recent_volume:,.0f}
Volume Ratio: {volume_ratio:.2f}x {'[High]' if volume_ratio > 1.5 else '[Low]' if volume_ratio < 0.7 else '[Normal]'}

💡 KEY LEVELS & SUPPORT/RESISTANCE
Immediate Support: ${range_analysis.get(20, {}).get('low', self.current_price * 0.95):.2f}
Immediate Resistance: ${range_analysis.get(20, {}).get('high', self.current_price * 1.05):.2f}
Major Support: ${range_analysis.get(60, {}).get('low', self.current_price * 0.90):.2f}
Major Resistance: ${range_analysis.get(60, {}).get('high', self.current_price * 1.10):.2f}

🎯 VOLATILITY CONTEXT
Current IV: {self.current_iv*100:.1f}% """

        # Volatility assessment
        if self.current_iv > 0.40:
            data_text += "[VERY HIGH - Favor selling strategies]"
        elif self.current_iv > 0.30:
            data_text += "[HIGH - Mixed strategies]"
        elif self.current_iv > 0.20:
            data_text += "[MODERATE - Balanced approach]"
        elif self.current_iv > 0.15:
            data_text += "[LOW - Favor buying strategies]"
        else:
            data_text += "[VERY LOW - Premium buying opportunity]"
            
        data_text += f"""
Historical 30-Day Vol: {(returns.rolling(30).std().iloc[-1] * np.sqrt(252) * 100):.1f}%
Vol Rank: {((self.current_iv - returns.rolling(252).std().min() / (returns.rolling(252).std().max() - returns.rolling(252).std().min() * 100):.0f}%))

⚡ MARKET REGIME ASSESSMENT
Primary Trend: {trend_strength}
Volatility Regime: {'High' if self.current_iv > 0.25 else 'Moderate' if self.current_iv > 0.18 else 'Low'}
Momentum: {'Positive' if safe_return(5) > 1 else 'Negative' if safe_return(5) < -1 else 'Neutral'}
"""
        
        self.data_text.insert('1.0', data_text)
        self.status_var.set(f"✅ {self.current_symbol} analysis complete - {len(close_prices)} days of data")
        
    def _update_bias_text(self):
        """Update bias text with current symbol"""
        current_text = self.bias_text.get('1.0', 'end-1c')
        # Replace any existing symbol references
        words = current_text.split()
        updated_words = []
        
        for word in words:
            # Check if word is a potential symbol (3-5 uppercase letters)
            if len(word) >= 3 and len(word) <= 5 and word.isupper() and word.isalpha():
                updated_words.append(self.current_symbol)
            else:
                updated_words.append(word)
                
        updated_text = ' '.join(updated_words)
        
        # If no symbol found, create new text
        if self.current_symbol not in updated_text:
            updated_text = f"I believe {self.current_symbol} will trend higher over the next 6 months due to strong fundamentals"
            
        self.bias_text.delete('1.0', tk.END)
        self.bias_text.insert('1.0', updated_text)
        
    def _set_bias_template(self, template):
        """Set bias from template"""
        bias_text = f"I believe {self.current_symbol} {template}"
        self.bias_text.delete('1.0', tk.END)
        self.bias_text.insert('1.0', bias_text)
        
    def _analyze_bias(self):
        """Analyze user bias and generate comprehensive recommendations"""
        if self.market_data is None:
            messagebox.showwarning("Data Required", f"Please load data for {self.current_symbol} first")
            return
            
        self.status_var.set("🔄 Analyzing market view and generating strategies...")
        
        user_input = self.bias_text.get('1.0', 'end-1c').strip()
        if not user_input:
            messagebox.showwarning("Input Required", "Please enter your market view")
            return
            
        try:
            # Parse user bias
            user_bias = self._parse_bias(user_input)
            
            # Calculate machine bias
            machine_bias = self._calculate_machine_bias()
            
            # Generate strategies
            self.strategies = self._generate_enhanced_strategies(user_bias, machine_bias)
            
            # Display results
            self._display_strategies()
            
            self.status_var.set(f"✅ Generated {len(self.strategies)} strategy recommendations for {self.current_symbol}")
            
        except Exception as e:
            messagebox.showerror("Analysis Error", f"Error during analysis: {str(e)}")
            self.status_var.set("❌ Analysis failed")
            
    def _parse_bias(self, text):
        """Enhanced bias parsing"""
        text_lower = text.lower()
        
        # Enhanced direction detection
        bullish_indicators = []
            'up', 'bull', 'rally', 'rise', 'increase', 'climb', 'higher', 'gain', 'grow',
            'positive', 'strong', 'momentum', 'breakout', 'support', 'buy', 'long',
            'optimistic', 'confident', 'upward', 'advancing'
        ]
        
        bearish_indicators = []
            'down', 'bear', 'decline', 'fall', 'drop', 'lower', 'crash', 'sell', 'short',
            'negative', 'weak', 'breakdown', 'resistance', 'pessimistic', 'downward',
            'declining', 'falling', 'bearish'
        ]
        
        neutral_indicators = []
            'range', 'sideways', 'flat', 'stable', 'consolidate', 'neutral', 'uncertain',
            'mixed', 'choppy', 'directionless'
        ]
        
        # Count indicators
        bullish_score = sum(1 for indicator in bullish_indicators if indicator in text_lower)
        bearish_score = sum(1 for indicator in bearish_indicators if indicator in text_lower)
        neutral_score = sum(1 for indicator in neutral_indicators if indicator in text_lower)
        
        # Determine direction
        if neutral_score > 0 or (bullish_score == bearish_score and bullish_score > 0):
            direction = 'neutral'
        elif bullish_score > bearish_score:
            direction = 'bullish'
        elif bearish_score > bullish_score:
            direction = 'bearish'
        else:
            direction = 'neutral'  # Default
            
        # Time horizon detection
        time_indicators = {}
            'short': ['day', 'days', 'week', 'weeks', 'short term', 'near term', 'immediate'],
            'medium': ['month', 'months', 'quarter', 'medium term'],
            'long': ['year', 'years', 'long term', 'secular', 'decade']
        }
        
        horizon_days = 90  # Default
        for horizon_type, indicators in time_indicators.items():
            if any(indicator in text_lower for indicator in indicators):
                if horizon_type == 'short':
                    horizon_days = 30
                elif horizon_type == 'medium':
                    horizon_days = 90
                else:  # long
                    horizon_days = 365
                break
                
        # Confidence detection
        high_confidence = ['strongly', 'definitely', 'certainly', 'very', 'extremely', 'absolutely', 'convinced']
        low_confidence = ['might', 'maybe', 'possibly', 'perhaps', 'could', 'potentially', 'uncertain']
        
        if any(word in text_lower for word in high_confidence):
            confidence = 0.85
        elif any(word in text_lower for word in low_confidence):
            confidence = 0.45
        else:
            confidence = 0.65
            
        return {}
            'direction': direction,
            'confidence': confidence,
            'horizon': horizon_days,
            'text': text,
            'bullish_score': bullish_score,
            'bearish_score': bearish_score,
            'neutral_score': neutral_score
        }
        
    def _calculate_machine_bias(self):
        """Enhanced machine bias calculation"""
        
        close_prices = self.market_data['Close']
        volumes = self.market_data['Volume']
        
        # Technical score components
        score_components = {}
            'trend': 0,
            'momentum': 0,
            'volume': 0,
            'volatility': 0,
            'support_resistance': 0
        }
        
        # Trend analysis
        sma_10 = close_prices.rolling(10).mean().iloc[-1] if len(close_prices) > 10 else self.current_price
        sma_20 = close_prices.rolling(20).mean().iloc[-1] if len(close_prices) > 20 else self.current_price
        sma_50 = close_prices.rolling(50).mean().iloc[-1] if len(close_prices) > 50 else self.current_price
        
        if self.current_price > sma_20 > sma_50:
            score_components['trend'] = 0.3
        elif self.current_price > sma_20:
            score_components['trend'] = 0.15
        elif self.current_price < sma_20 < sma_50:
            score_components['trend'] = -0.3
        elif self.current_price < sma_20:
            score_components['trend'] = -0.15
            
        # Momentum analysis
        momentum_periods = [5, 10, 20]
        momentum_scores = []
        
        for period in momentum_periods:
            if len(close_prices) > period:
                momentum = (self.current_price / close_prices.iloc[-period-1]) - 1
                momentum_scores.append(momentum)
                
        if momentum_scores:
            avg_momentum = sum(momentum_scores) / len(momentum_scores)
            score_components['momentum'] = min(max(avg_momentum * 5, -0.2), 0.2)
            
        # Volume analysis
        avg_volume = volumes.tail(20).mean()
        recent_volume = volumes.tail(5).mean()
        volume_ratio = recent_volume / avg_volume if avg_volume > 0 else 1
        
        if volume_ratio > 1.5:
            score_components['volume'] = 0.1
        elif volume_ratio < 0.7:
            score_components['volume'] = -0.05
            
        # Volatility analysis
        if self.current_iv > 0.3:  # High volatility can signal uncertainty
            score_components['volatility'] = -0.05
        elif self.current_iv < 0.15:  # Low volatility can signal complacency
            score_components['volatility'] = 0.05
            
        # Support/Resistance analysis
        recent_high = close_prices.tail(20).max()
        recent_low = close_prices.tail(20).min()
        
        price_position = (self.current_price - recent_low) / (recent_high - recent_low) if recent_high != recent_low else 0.5
        
        if price_position > 0.8:  # Near resistance
            score_components['support_resistance'] = -0.1
        elif price_position < 0.2:  # Near support
            score_components['support_resistance'] = 0.1
            
        # Calculate total score
        total_score = 0.5 + sum(score_components.values()
        
        # Determine direction and confidence
        if total_score > 0.65:
            return {}
                'direction': 'bullish',
                'confidence': min(total_score, 0.9),
                'components': score_components,
                'total_score': total_score
            }
        elif total_score < 0.35:
            return {}
                'direction': 'bearish',
                'confidence': min(1 - total_score, 0.9),
                'components': score_components,
                'total_score': total_score
            }
        else:
            return {}
                'direction': 'neutral',
                'confidence': 0.5,
                'components': score_components,
                'total_score': total_score
            }
            
    def _generate_enhanced_strategies(self, user_bias, machine_bias):
        """Generate comprehensive strategy recommendations"""
        
        strategies = []
        
        # Base parameters
        current_price = self.current_price
        iv = self.current_iv
        
        # Strategy 1: Directional Options
        if user_bias['direction'] == 'bullish':
            max_profit_unlimited = "Unlimited" if user_bias['confidence'] > 0.7 else int(current_price * 0.3 * 100)
            
            strategies.append({)
                'name': f'Long Calls - {self.current_symbol}',
                'direction': 'Bullish',
                'max_profit': max_profit_unlimited,
                'max_loss': int(current_price * 0.05 * 100),
                'win_rate': 40 + (user_bias['confidence'] * 20),
                'score': 0.70 + (user_bias['confidence'] * 0.20),
                'type': 'directional',
                'details': self._generate_enhanced_call_details(user_bias, machine_bias)
            })
            
        elif user_bias['direction'] == 'bearish':
            strategies.append({)
                'name': f'Long Puts - {self.current_symbol}',
                'direction': 'Bearish',
                'max_profit': int(current_price * 0.8 * 100),
                'max_loss': int(current_price * 0.05 * 100),
                'win_rate': 40 + (user_bias['confidence'] * 20),
                'score': 0.70 + (user_bias['confidence'] * 0.20),
                'type': 'directional',
                'details': self._generate_enhanced_put_details(user_bias, machine_bias)
            })
            
        # Strategy 2: Spread Strategies
        if user_bias['direction'] in ['bullish', 'bearish']:
            spread_name = 'Bull Call Spread' if user_bias['direction'] == 'bullish' else 'Bear Put Spread'
            
            strategies.append({)
                'name': spread_name,
                'direction': user_bias['direction'].title(),
                'max_profit': int(current_price * 0.08 * 100),
                'max_loss': int(current_price * 0.03 * 100),
                'win_rate': 55 + (user_bias['confidence'] * 15),
                'score': 0.75 + (user_bias['confidence'] * 0.15),
                'type': 'spread',
                'details': self._generate_spread_details(user_bias, machine_bias)
            })
            
        # Strategy 3: Neutral Strategies
        if user_bias['direction'] == 'neutral' or user_bias['neutral_score'] > 0:
            strategies.append({)
                'name': 'Iron Condor',
                'direction': 'Neutral',
                'max_profit': int(current_price * 0.03 * 100),
                'max_loss': int(current_price * 0.02 * 100),
                'win_rate': 70,
                'score': 0.80 + (0.1 if iv > 0.25 else 0),
                'type': 'neutral',
                'details': self._generate_condor_details(user_bias, machine_bias)
            })
            
        # Strategy 4: Volatility Plays
        if iv > 0.30:  # High volatility
            strategies.append({)
                'name': 'Short Straddle/Strangle',
                'direction': 'Volatility Crush',
                'max_profit': int(current_price * 0.06 * 100),
                'max_loss': "Substantial",
                'win_rate': 65,
                'score': 0.75,
                'type': 'volatility',
                'details': self._generate_vol_crush_details(user_bias, machine_bias)
            })
        elif iv < 0.18:  # Low volatility
            strategies.append({)
                'name': 'Long Straddle',
                'direction': 'Volatility Expansion',
                'max_profit': "Unlimited",
                'max_loss': int(current_price * 0.08 * 100),
                'win_rate': 45,
                'score': 0.70,
                'type': 'volatility',
                'details': self._generate_vol_expansion_details(user_bias, machine_bias)
            })
            
        # Strategy 5: Calendar/Time Spreads
        strategies.append({)
            'name': 'Calendar Spread',
            'direction': 'Time Decay',
            'max_profit': int(current_price * 0.05 * 100),
            'max_loss': int(current_price * 0.025 * 100),
            'win_rate': 60,
            'score': 0.70,
            'type': 'time',
            'details': self._generate_calendar_details(user_bias, machine_bias)
        })
        
        # Strategy 6: Bias Divergence Strategy
        if user_bias['direction'] != machine_bias['direction'] and user_bias['direction'] != 'neutral':
            strategies.append({)
                'name': 'Bias Arbitrage Strategy',
                'direction': 'Exploit Divergence',
                'max_profit': int(current_price * 0.10 * 100),
                'max_loss': int(current_price * 0.05 * 100),
                'win_rate': 58,
                'score': 0.85,
                'type': 'arbitrage',
                'details': self._generate_enhanced_arbitrage_details(user_bias, machine_bias)
            })
            
        # Strategy 7: Earnings/Event Plays (if applicable)
        if user_bias['horizon'] <= 30:  # Short-term plays
            strategies.append({)
                'name': 'Event-Based Strategy',
                'direction': 'Short-term Catalyst',
                'max_profit': int(current_price * 0.15 * 100),
                'max_loss': int(current_price * 0.06 * 100),
                'win_rate': 50,
                'score': 0.65,
                'type': 'event',
                'details': self._generate_event_details(user_bias, machine_bias)
            })
            
        # Sort strategies by score
        strategies.sort(key=lambda x: x['score'], reverse=True)
        
        return strategies[:8]  # Return top 8 strategies
        
    def _generate_enhanced_call_details(self, user_bias, machine_bias):
        """Generate detailed call strategy analysis with specific option tickers"""
        from datetime import datetime, timedelta
        
        # Calculate specific expiration dates
        today = datetime.now()
        
        # Standard monthly expirations (3rd Friday of month)
        def get_third_friday(year, month):
            # First day of month
            first = datetime(year, month, 1)
            # Find first Friday (weekday 4)
            first_friday = first + timedelta(days=(4 - first.weekday() % 7)
            # Third Friday is 14 days later
            return first_friday + timedelta(days=14)
        
        # Get next few monthly expirations
        current_month = today.month
        current_year = today.year
        
        # Calculate expiration based on user horizon
        if user_bias['horizon'] <= 45:
            # Next monthly expiration
            if today.day > 15:  # Past current month's expiration
                exp_month = current_month + 1 if current_month < 12 else 1
                exp_year = current_year if current_month < 12 else current_year + 1
            else:
                exp_month = current_month
                exp_year = current_year
        elif user_bias['horizon'] <= 90:
            # 2 months out
            exp_month = current_month + 2 if current_month <= 10 else current_month + 2 - 12
            exp_year = current_year if current_month <= 10 else current_year + 1
        else:
            # 3+ months out or LEAPS
            if user_bias['horizon'] > 180:
                # LEAPS - next January
                exp_month = 1
                exp_year = current_year + 1 if current_month < 12 else current_year + 2
            else:
                exp_month = current_month + 3 if current_month <= 9 else current_month + 3 - 12
                exp_year = current_year if current_month <= 9 else current_year + 1
        
        try:
            expiration_date = get_third_friday(exp_year, exp_month)
            exp_str = expiration_date.strftime("%b %d, %Y")
            exp_code = expiration_date.strftime("%y%m%d")
        except:
            exp_str = "Next Monthly"
            exp_code = "YYMMDD"
        
        # Calculate strikes
        strike_price = round(self.current_price * 1.05, 0)  # Round to nearest dollar
        if self.current_price > 100:
            strike_price = round(strike_price, 0)  # Round to dollar
        else:
            strike_price = round(strike_price * 2) / 2  # Round to $0.50
            
        # Estimate premium based on IV and time
        days_to_exp = (expiration_date - today).days if 'expiration_date' in locals() else user_bias['horizon']
        time_value = np.sqrt(days_to_exp / 365) * self.current_iv * self.current_price
        intrinsic = max(0, self.current_price - strike_price)
        premium = intrinsic + time_value * 0.3  # Rough approximation
        
        # Create option ticker
        strike_str = f"{int(strike_price):05d}" if strike_price == int(strike_price) else f"{int(strike_price*10):06d}"
        option_ticker = f"{self.current_symbol}{exp_code}C{strike_str}"
        
        return f"""🎯 SPECIFIC CALL TRADE RECOMMENDATION FOR {self.current_symbol}
{'='*80}

📋 EXACT TRADE TO EXECUTE:
• BUY TO OPEN: {option_ticker}
• Option Description: {self.current_symbol} {exp_str} ${strike_price:.0f} Call
• Expiration Date: {exp_str} ({days_to_exp} days)
• Strike Price: ${strike_price:.0f}
• Estimated Premium: ${premium:.2f} per share (${premium*100:.0f} per contract)
• Recommended Quantity: 1-3 contracts

📊 TRADE SPECIFICATIONS:
• Current {self.current_symbol} Price: ${self.current_price:.2f}
• Strike Selection: ${strike_price:.0f} ({((strike_price/self.current_price-1)*100):+.1f}% OTM)
• Option Ticker: {option_ticker}
• Days to Expiration: {days_to_exp}
• Implied Volatility: {self.current_iv*100:.1f}%

USER BIAS INTEGRATION:
• Your View: {user_bias['direction'].upper()} (Confidence: {user_bias['confidence']:.0%})
• Machine View: {machine_bias['direction'].upper()} (Score: {machine_bias['total_score']:.2f})
• Bias Alignment: {'✅ Aligned' if user_bias['direction'] == machine_bias['direction'] else '⚠️ Divergent'}

PROFIT SCENARIOS:
• Breakeven: ${strike_price + premium:.2f} ({((strike_price + premium)/self.current_price - 1)*100:+.1f}%)
• 10% Move: ${self.current_price * 1.1:.2f} → Profit: ${(self.current_price * 1.1 - strike_price - premium)*100:.0f}
• 20% Move: ${self.current_price * 1.2:.2f} → Profit: ${(self.current_price * 1.2 - strike_price - premium)*100:.0f}
• 30% Move: ${self.current_price * 1.3:.2f} → Profit: ${(self.current_price * 1.3 - strike_price - premium)*100:.0f}

RISK ANALYSIS:
• Maximum Loss: ${premium * 100:.0f} (100% of premium)
• Time Decay Risk: Accelerates in final 30 days
• Volatility Risk: Benefits from IV expansion
• Required Move: {((strike_price + premium)/self.current_price - 1)*100:.1f}% to breakeven

MARKET CONTEXT ANALYSIS:
• Current IV: {self.current_iv*100:.1f}% ({'Expensive' if self.current_iv > 0.25 else 'Reasonable' if self.current_iv > 0.18 else 'Cheap'})
• Recent Volatility: {(self.market_data['Close'].pct_change().rolling(20).std().iloc[-1] * np.sqrt(252) * 100):.1f}%
• Technical Support: ${self.market_data['Close'].rolling(20).min().iloc[-1]:.2f}

IMPLEMENTATION STRATEGY:
1. Entry Timing: {'Consider waiting for pullback' if machine_bias['total_score'] < 0.4 else 'Current levels acceptable'}
2. Position Sizing: Start with 1 contract, add on strength
3. Profit Taking: Scale out at 50%, 100%, 200% gains
4. Stop Loss: Close if underlying breaks key support
5. Time Management: Review at 30 days to expiration

CATALYST MONITORING:
• Watch for earnings announcements
• Monitor sector rotation trends
• Track overall market sentiment
• Consider Fed policy impacts

OPTIMAL FOR: High conviction bullish views with defined risk tolerance"""
        
    def _generate_enhanced_put_details(self, user_bias, machine_bias):
        """Generate detailed put strategy analysis"""
        strike_price = self.current_price * 0.95
        premium = self.current_price * 0.05
        
        return f"""Enhanced Long Put Strategy Analysis for {self.current_symbol}

BEARISH STRATEGY IMPLEMENTATION:
• Strike Price: ${strike_price:.2f} (5% OTM)
• Premium: ${premium:.2f} per share
• Breakeven: ${strike_price - premium:.2f}
• Maximum Profit: ${(strike_price - premium) * 100:.0f} (if stock goes to zero)

BIAS ANALYSIS:
• User Conviction: {user_bias['confidence']:.0%} bearish
• Machine Analysis: {machine_bias['direction']} bias detected
• Volatility Environment: {self.current_iv*100:.1f}%

PROFIT SCENARIOS:
• 10% Decline: Profit ${(strike_price - self.current_price * 0.9 - premium)*100:.0f}
• 20% Decline: Profit ${(strike_price - self.current_price * 0.8 - premium)*100:.0f}
• 30% Decline: Profit ${(strike_price - self.current_price * 0.7 - premium)*100:.0f}

IMPLEMENTATION GUIDE:
1. Monitor resistance levels around ${self.market_data['Close'].rolling(20).max().iloc[-1]:.2f}
2. Consider adding on failed rallies
3. Target profit at 100-200% of premium
4. Hedge with small long position if needed

BEST FOR: Strong bearish conviction with controlled risk"""
        
    def _generate_spread_details(self, user_bias, machine_bias):
        """Generate spread strategy details with specific option tickers"""
        from datetime import datetime, timedelta
        
        # Calculate expiration (typically 30-60 days)
        today = datetime.now()
        
        def get_third_friday(year, month):
            first = datetime(year, month, 1)
            first_friday = first + timedelta(days=(4 - first.weekday() % 7)
            return first_friday + timedelta(days=14)
        
        # Get next monthly expiration
        current_month = today.month
        current_year = today.year
        
        if today.day > 15:  # Past current month's expiration
            exp_month = current_month + 1 if current_month < 12 else 1
            exp_year = current_year if current_month < 12 else current_year + 1
        else:
            exp_month = current_month
            exp_year = current_year
        
        try:
            expiration_date = get_third_friday(exp_year, exp_month)
            exp_str = expiration_date.strftime("%b %d, %Y")
            exp_code = expiration_date.strftime("%y%m%d")
            days_to_exp = (expiration_date - today).days
        except:
            exp_str = "Next Monthly"
            exp_code = "YYMMDD"
            days_to_exp = 30
        
        if user_bias['direction'] == 'bullish':
            # Bull Call Spread
            long_strike = round(self.current_price * 1.02, 0)
            short_strike = round(self.current_price * 1.08, 0)
            spread_type = "Bull Call Spread"
            option_type = "C"
            
            # Create option tickers
            long_strike_str = f"{int(long_strike):05d}"
            short_strike_str = f"{int(short_strike):05d}"
            long_ticker = f"{self.current_symbol}{exp_code}C{long_strike_str}"
            short_ticker = f"{self.current_symbol}{exp_code}C{short_strike_str}"
            
            # Estimate premiums
            long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.4
            short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.2
            net_debit = long_premium - short_premium
            
        else:
            # Bear Put Spread
            long_strike = round(self.current_price * 0.98, 0)
            short_strike = round(self.current_price * 0.92, 0)
            spread_type = "Bear Put Spread"
            option_type = "P"
            
            # Create option tickers
            long_strike_str = f"{int(long_strike):05d}"
            short_strike_str = f"{int(short_strike):05d}"
            long_ticker = f"{self.current_symbol}{exp_code}P{long_strike_str}"
            short_ticker = f"{self.current_symbol}{exp_code}P{short_strike_str}"
            
            # Estimate premiums
            long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.4
            short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.2
            net_debit = long_premium - short_premium
            
        max_profit = abs(long_strike - short_strike) - net_debit
        breakeven = long_strike + net_debit if user_bias['direction'] == 'bullish' else long_strike - net_debit
            
        return f"""🎯 SPECIFIC {spread_type.upper()} TRADE FOR {self.current_symbol}
{'='*80}

📋 EXACT SPREAD TRADE TO EXECUTE:
LEG 1 (BUY): BUY TO OPEN {long_ticker}
• Option: {self.current_symbol} {exp_str} ${long_strike:.0f} {'Call' if option_type == 'C' else 'Put'}
• Premium: ~${long_premium:.2f} per share (${long_premium*100:.0f} per contract)

LEG 2 (SELL): SELL TO OPEN {short_ticker}
• Option: {self.current_symbol} {exp_str} ${short_strike:.0f} {'Call' if option_type == 'C' else 'Put'}
• Premium: ~${short_premium:.2f} per share (${short_premium*100:.0f} per contract)

📊 SPREAD SPECIFICATIONS:
• Net Debit: ${net_debit:.2f} per share (${net_debit*100:.0f} per spread)
• Max Profit: ${max_profit*100:.0f} per spread
• Max Loss: ${net_debit*100:.0f} per spread (net debit paid)
• Breakeven: ${breakeven:.2f}
• Expiration: {exp_str} ({days_to_exp} days)
• Risk/Reward Ratio: {max_profit/net_debit:.1f}:1

📈 PROFIT/LOSS SCENARIOS:
• Max Profit: Achieved if {self.current_symbol} {'≥' if user_bias['direction'] == 'bullish' else '≤'} ${short_strike:.0f} at expiration
• Max Loss: Occurs if {self.current_symbol} {'≤' if user_bias['direction'] == 'bullish' else '≥'} ${long_strike:.0f} at expiration
• Breakeven Point: ${breakeven:.2f} ({((breakeven/self.current_price-1)*100):+.1f}% from current)

🎯 TRADE EXECUTION TIPS:
• Enter as a single spread order (not separate legs)
• Use limit orders, aim for midpoint or better
• Typical bid-ask spread: $0.05-$0.15 for liquid options
• Target execution around ${net_debit:.2f} or better

⏰ MANAGEMENT GUIDELINES:
• Target Profit: Close at 50% of max profit (${max_profit*50:.0f})
• Time Management: Consider closing at 21 days to expiration
• Adjustment: Roll if tested early in trade
• Stop Loss: Close if underlying breaks key technical level

BEST FOR: Moderate directional conviction with defined risk control"""
        
    def _generate_condor_details(self, user_bias, machine_bias):
        """Generate iron condor details with specific option tickers"""
        from datetime import datetime, timedelta
        
        # Calculate expiration (typically 30-45 days)
        today = datetime.now()
        
        def get_third_friday(year, month):
            first = datetime(year, month, 1)
            first_friday = first + timedelta(days=(4 - first.weekday() % 7)
            return first_friday + timedelta(days=14)
        
        # Get next monthly expiration
        current_month = today.month
        current_year = today.year
        
        if today.day > 15:  # Past current month's expiration
            exp_month = current_month + 1 if current_month < 12 else 1
            exp_year = current_year if current_month < 12 else current_year + 1
        else:
            exp_month = current_month
            exp_year = current_year
        
        try:
            expiration_date = get_third_friday(exp_year, exp_month)
            exp_str = expiration_date.strftime("%b %d, %Y")
            exp_code = expiration_date.strftime("%y%m%d")
            days_to_exp = (expiration_date - today).days
        except:
            exp_str = "Next Monthly"
            exp_code = "YYMMDD"
            days_to_exp = 30
        
        # Calculate strikes for Iron Condor
        put_short_strike = round(self.current_price * 0.95, 0)
        put_long_strike = round(self.current_price * 0.90, 0)
        call_short_strike = round(self.current_price * 1.05, 0)
        call_long_strike = round(self.current_price * 1.10, 0)
        
        # Create option tickers
        put_short_ticker = f"{self.current_symbol}{exp_code}P{int(put_short_strike):05d}"
        put_long_ticker = f"{self.current_symbol}{exp_code}P{int(put_long_strike):05d}"
        call_short_ticker = f"{self.current_symbol}{exp_code}C{int(call_short_strike):05d}"
        call_long_ticker = f"{self.current_symbol}{exp_code}C{int(call_long_strike):05d}"
        
        # Estimate premiums
        put_short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.25
        put_long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.10
        call_short_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.25
        call_long_premium = self.current_iv * self.current_price * np.sqrt(days_to_exp/365) * 0.10
        
        net_credit = (put_short_premium - put_long_premium) + (call_short_premium - call_long_premium)
        max_loss = min(put_short_strike - put_long_strike, call_long_strike - call_short_strike) - net_credit
        
        return f"""🎯 SPECIFIC IRON CONDOR TRADE FOR {self.current_symbol}
{'='*80}

📋 EXACT 4-LEG TRADE TO EXECUTE:
LEG 1: SELL TO OPEN {put_short_ticker}
• Option: {self.current_symbol} {exp_str} ${put_short_strike:.0f} Put
• Premium: ~${put_short_premium:.2f} per share (CREDIT)

LEG 2: BUY TO OPEN {put_long_ticker}  
• Option: {self.current_symbol} {exp_str} ${put_long_strike:.0f} Put
• Premium: ~${put_long_premium:.2f} per share (DEBIT)

LEG 3: SELL TO OPEN {call_short_ticker}
• Option: {self.current_symbol} {exp_str} ${call_short_strike:.0f} Call
• Premium: ~${call_short_premium:.2f} per share (CREDIT)

LEG 4: BUY TO OPEN {call_long_ticker}
• Option: {self.current_symbol} {exp_str} ${call_long_strike:.0f} Call  
• Premium: ~${call_long_premium:.2f} per share (DEBIT)

📊 CONDOR SPECIFICATIONS:
• Net Credit: ${net_credit:.2f} per share (${net_credit*100:.0f} per condor)
• Max Profit: ${net_credit*100:.0f} (keep full credit)
• Max Loss: ${max_loss*100:.0f} per condor
• Profit Zone: ${put_short_strike:.0f} to ${call_short_strike:.0f}
• Current Cushion: {((call_short_strike - put_short_strike)/self.current_price*100):.1f}%
• Expiration: {exp_str} ({days_to_exp} days)

📈 PROFIT/LOSS SCENARIOS:
• Max Profit: Achieved if {self.current_symbol} stays between ${put_short_strike:.0f} - ${call_short_strike:.0f}
• Breakeven Points: ${put_short_strike - net_credit:.2f} and ${call_short_strike + net_credit:.2f}
• Max Loss: Occurs if {self.current_symbol} moves below ${put_long_strike:.0f} or above ${call_long_strike:.0f}

🎯 EXECUTION STRATEGY:
• Enter as single 4-leg Iron Condor order
• Target net credit of ${net_credit:.2f} or better
• Ensure sufficient margin (typically ${max_loss*100*5:.0f} per condor)
• Verify options have adequate liquidity (>100 open interest)

⏰ MANAGEMENT PLAN:
• Target Profit: Close at 25-50% of max profit (${net_credit*25:.0f}-${net_credit*50:.0f})
• Adjustment: Consider closing tested side if breached early
• Time Management: Evaluate position at 21 days to expiration
• Avoid assignment: Close 3-5 days before expiration if ITM

💡 PROBABILITY ANALYSIS:
• Win Rate: ~68-72% based on {self.current_iv*100:.0f}% IV
• Best Case: Market stays range-bound in profit zone
• Risk Areas: Strong trending moves in either direction

OPTIMAL FOR: High-probability income generation in range-bound markets"""
        
    def _generate_vol_crush_details(self, user_bias, machine_bias):
        """Generate volatility crush strategy details"""
        return f"""Volatility Crush Strategy for {self.current_symbol}

HIGH IV EXPLOITATION:
Current IV: {self.current_iv*100:.1f}% (HIGH)
Strategy: Sell premium to benefit from volatility contraction

TRADE STRUCTURE:
• Short Strangle or Short Straddle
• Profit from time decay and volatility compression
• Requires margin account

RISK CONSIDERATIONS:
• Unlimited risk on large moves
• Best in range-bound markets
• Monitor position closely

BEST FOR: Experienced traders expecting volatility decrease"""
        
    def _generate_vol_expansion_details(self, user_bias, machine_bias):
        """Generate volatility expansion strategy details"""
        return f"""Volatility Expansion Strategy for {self.current_symbol}

LOW IV OPPORTUNITY:
Current IV: {self.current_iv*100:.1f}% (LOW)
Strategy: Buy options expecting volatility increase

TRADE STRUCTURE:
• Long Straddle or Strangle
• Benefits from large moves in either direction
• Defined risk with unlimited profit potential

CATALYST CONSIDERATIONS:
• Earnings announcements
• Regulatory decisions
• Major news events

BEST FOR: Expecting significant price movement"""
        
    def _generate_calendar_details(self, user_bias, machine_bias):
        """Generate calendar spread details"""
        return f"""Calendar Spread Strategy for {self.current_symbol}

TIME DECAY STRATEGY:
• Sell near-term option
• Buy longer-term same strike
• Profit from differential time decay

OPTIMAL OUTCOME:
• Stock near strike at near expiration
• Minimal movement in near term
• Volatility stability

MANAGEMENT:
• Close before near-term expiration
• Roll if necessary
• Monitor for early assignment

BEST FOR: Neutral outlook with time advantage"""
        
    def _generate_enhanced_arbitrage_details(self, user_bias, machine_bias):
        """Generate enhanced bias arbitrage details"""
        return f"""Advanced Bias Arbitrage Strategy for {self.current_symbol}

PSYCHOLOGICAL EDGE DETECTED:
User Bias: {user_bias['direction'].upper()} ({user_bias['confidence']:.0%} confidence)
Machine Bias: {machine_bias['direction'].upper()} ({machine_bias['confidence']:.0%} confidence)
Divergence Score: {abs(user_bias['confidence'] - machine_bias['confidence']):.2f}

ARBITRAGE OPPORTUNITY:
Human biases tend to persist while algorithms adapt quickly. This creates profitable opportunities when views diverge significantly.

STRATEGY IMPLEMENTATION:
1. VOLATILITY APPROACH:
   • Long Straddle/Strangle if high divergence
   • Profit from uncertainty resolution
   • Benefits from movement in either direction

2. TIME SPREAD APPROACH:
   • Calendar spreads to benefit during uncertainty
   • Profit from time decay while market decides
   • Lower risk than directional bets

3. IRON BUTTERFLY:
   • Sell volatility around current price
   • Collect premium from indecision
   • Adjust if clear direction emerges

HISTORICAL PERFORMANCE:
• Success Rate: 60-65% when divergence > 30%
• Average Holding Period: 15-45 days
• Best Results: High conviction user bias vs weak machine signals

RISK MANAGEMENT:
• Position Size: 3-5% of portfolio maximum
• Profit Targets: 40-60% of maximum profit
• Stop Loss: Close if strong trend emerges
• Time Limit: 60 days maximum hold

MONITORING INDICATORS:
• Volume patterns for conviction changes
• Technical breakouts/breakdowns
• News flow impact on sentiment
• Options flow for institutional bias

PSYCHOLOGICAL FACTORS:
• User confirmation bias creates persistence
• Machine learning adapts to new information
• Market efficiency takes time to resolve differences
• Volatility often increases during uncertainty

BEST FOR: Sophisticated traders comfortable with uncertainty plays"""
        
    def _generate_event_details(self, user_bias, machine_bias):
        """Generate event-based strategy details"""
        return f"""Event-Based Strategy for {self.current_symbol}

SHORT-TERM CATALYST PLAY:
Time Horizon: {user_bias['horizon']} days
Expected Catalyst: {'Earnings' if user_bias['horizon'] <= 7 else 'News/Events'}

STRATEGY OPTIONS:
1. Directional Play: Long calls/puts
2. Volatility Play: Straddles/strangles
3. Income Play: Short premium before event

EVENT CONSIDERATIONS:
• Historical move size
• Current option pricing
• Risk/reward asymmetry
• Post-event volatility crush

TIMING CRITICAL:
• Enter 3-5 days before event
• Exit within 1-2 days after
• Avoid overnight holds if possible

BEST FOR: Experienced options traders comfortable with event risk"""
        
    def _display_strategies(self):
        """Display strategies in enhanced treeview"""
        # Clear existing items
        for item in self.strategy_tree.get_children():
            self.strategy_tree.delete(item)
            
        # Color coding for strategy types
        self.strategy_tree.tag_configure('directional', background='lightblue')
        self.strategy_tree.tag_configure('spread', background='lightgreen')
        self.strategy_tree.tag_configure('neutral', background='lightyellow')
        self.strategy_tree.tag_configure('volatility', background='lightcoral')
        self.strategy_tree.tag_configure('arbitrage', background='lightcyan')
        self.strategy_tree.tag_configure('time', background='lightgray')
        self.strategy_tree.tag_configure('event', background='lavender')
        
        # Add strategies with enhanced formatting
        for i, strategy in enumerate(self.strategies):
            # Format values
            max_profit_str = f"${strategy['max_profit']:,}" if isinstance(strategy['max_profit'], (int, float) else strategy['max_profit'])
            max_loss_str = f"${strategy['max_loss']:,}" if isinstance(strategy['max_loss'], (int, float) else strategy['max_loss'])
            
            values = ()
                strategy['name'],
                strategy['direction'],
                max_profit_str,
                max_loss_str,
                f"{strategy['win_rate']:.0f}%",
                f"{strategy['score']:.2f}"
            )
            
            # Add with appropriate tag for coloring
            tag = strategy.get('type', 'default')
            item = self.strategy_tree.insert('', 'end', values=values, tags=(str(i), tag)
            
        # Auto-select first strategy
        if self.strategies:
            first_item = self.strategy_tree.get_children()[0]
            self.strategy_tree.selection_set(first_item)
            self.strategy_tree.focus(first_item)
            self._show_strategy_details(0)
            
    def _on_strategy_select(self, event):
        """Handle strategy selection"""
        selection = self.strategy_tree.selection()
        if not selection:
            return
            
        item = selection[0]
        tags = self.strategy_tree.item(item, 'tags')
        if tags:
            try:
                strategy_index = int(tags[0])
                self._show_strategy_details(strategy_index)
            except (ValueError, IndexError):
                pass
                
    def _show_strategy_details(self, index):
        """Show comprehensive strategy details"""
        if index >= len(self.strategies):
            return
            
        strategy = self.strategies[index]
        self.details_text.delete('1.0', tk.END)
        
        # Enhanced details with full context
        details = f"""{strategy['details']}

COMPREHENSIVE RISK ASSESSMENT:
{'='*60}

MARKET ENVIRONMENT:
• Current Price: ${self.current_price:.2f}
• Implied Volatility: {self.current_iv*100:.1f}% ({'High' if self.current_iv > 0.25 else 'Moderate' if self.current_iv > 0.18 else 'Low'})
• Recent Range: ${self.market_data['Close'].tail(20).min():.2f} - ${self.market_data['Close'].tail(20).max():.2f}
• Volume Trend: {'Above Average' if self.market_data['Volume'].tail(5).mean() > self.market_data['Volume'].mean() else 'Below Average'}

POSITION SIZING GUIDELINES:
• Conservative Account (2-5%): Risk ${int(self.current_price * 0.02 * 100)} - ${int(self.current_price * 0.05 * 100)} per trade
• Moderate Account (5-10%): Risk ${int(self.current_price * 0.05 * 100)} - ${int(self.current_price * 0.10 * 100)} per trade
• Aggressive Account (10%+): Risk ${int(self.current_price * 0.10 * 100)}+ per trade
• Recommended: Start small, scale into winners

IMPLEMENTATION CHECKLIST:
□ Verify {self.current_symbol} options liquidity (bid-ask < $0.30)
□ Check open interest (target >100 contracts)
□ Confirm margin requirements with broker
□ Set profit targets (typically 25-50% of max profit)
□ Plan exit strategy before entry
□ Review upcoming earnings/events calendar
□ Consider overall portfolio correlation
□ Set position size based on risk tolerance
□ Monitor key technical levels
□ Prepare for various market scenarios

ADVANCED CONSIDERATIONS:
• Greeks Impact: Monitor delta, theta, vega exposure
• Assignment Risk: Be aware for short options near expiration
• Liquidity: Ensure ability to exit position when needed
• Tax Implications: Consider holding periods and tax efficiency
• Portfolio Impact: How this fits with existing positions
• Market Regime: Adjust strategy if market conditions change

MONITORING & ADJUSTMENT:
Daily Checks:
• Underlying price movement
• Volatility changes
• Time decay impact
• Overall market conditions

Weekly Reviews:
• Profit/loss vs targets
• Time remaining considerations
• News flow impact
• Technical level breaks

Exit Criteria:
• Profit targets achieved
• Stop loss levels hit
• Time decay becomes detrimental
• Market conditions change significantly
• Better opportunities arise

EDUCATIONAL NOTES:
This strategy is recommended based on your expressed market view and current market conditions. 
Always paper trade first if unfamiliar with the strategy. Consider consulting with a financial 
advisor for personalized advice. Past performance does not guarantee future results.

Risk Disclosure: Options trading involves substantial risk and is not suitable for all investors.
"""
        
        self.details_text.insert('1.0', details)


def main():
    """Run the Enhanced Universal Trading Analyzer"""
    root = tk.Tk()
    
    # Configure enhanced style
    style = ttk.Style()
    style.theme_use('clam')
    
    # Custom button style
    style.configure('Accent.TButton', 
                   foreground='white', 
                   background='#0078D4',
                   font=('Arial', 11, 'bold')
    
    # Enhanced colors
    style.configure('TLabelframe.Label', font=('Arial', 11, 'bold')
    style.configure('TLabel', font=('Arial', 10)
    
    try:
        app = EnhancedTradingAnalyzer(root)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("Application Error", f"Failed to start application: {str(e)}")


if __name__ == "__main__":
    main()