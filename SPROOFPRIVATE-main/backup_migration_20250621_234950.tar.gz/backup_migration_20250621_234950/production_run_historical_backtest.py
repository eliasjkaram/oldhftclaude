from datetime import datetime, timedelta
import json
import sys
from config import config
#!/usr/bin/env python3
"""
Run historical backtest with reasonable date range
"""

import asyncio

import logging
from datetime import datetime
from v21_alpaca_backtest_system import BacktestConfig, AlpacaBacktester
import os

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


async def run_historical_backtest():
    try:
        """Run backtest on historical data"""
    
        # Use historical date range (2023)
        config = BacktestConfig()
            start_date = config.get("start_date", datetime.now() - timedelta(days=365)),
            end_date='2023-12-31',
            initial_capital = float(os.getenv("INITIAL_CAPITAL", "100000")),
            commission=0.001,
            slippage=0.0005,
            data_cache_dir='historical_data_cache',
            use_minio=False
        )
    
        # Create cache directory
        os.makedirs(config.data_cache_dir, exist_ok=True)
    
        # Selected symbols across different sectors
        symbols = []
            # Tech giants
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA',
            # Financial
            'JPM', 'BAC', 'GS',
            # ETFs
            'SPY', 'QQQ', 'IWM',
            # Commodities
            'GLD', 'SLV', 'USO',
            # Other sectors
            'TSLA', 'AMD', 'DIS', 'WMT', 'JNJ'
        ]
    
        # Test with subset of algorithms first
        algorithms = []
            # Technical
            'RSI_Oversold', 'MACD_Crossover', 'Bollinger_Squeeze', 'Volume_Breakout',
            'Support_Resistance', 'Trend_Following',
            # Statistical
            'Mean_Reversion', 'Momentum_Alpha', 'Pairs_Trading',
            # ML
            'Neural_Network', 'XGBoost', 'LSTM_Prediction',
            # Options
            'Vega_Trading', 'Greeks_Optimization',
            # HFT
            'Order_Flow', 'Market_Making',
            # Advanced
            'Fractal_Analysis', 'Hidden_Markov', 'Adaptive_Strategy'
        ]
    
        logger.info("\n" + "="*80)
        logger.info("🚀 HISTORICAL BACKTEST - 2023 FULL YEAR")
        logger.info("="*80)
        logger.info(f"📅 Period: {config.start_date} to {config.end_date}")
        logger.info(f"💰 Initial Capital: ${config.initial_capital:,}")
        logger.info(f"📊 Symbols: {len(symbols)}")
        logger.info(f"🤖 Algorithms: {len(algorithms)}")
        logger.info(f"💾 Cache: {config.data_cache_dir}")
        logger.info("="*80 + "\n")
    
        # Initialize backtester
        backtester = AlpacaBacktester(config)
    
        if not backtester.data_fetcher.alpaca_client:
            logger.info("❌ Alpaca client not initialized. Check credentials.")
            return
    
        # Run backtest
        logger.info("Starting backtest...\n")
        await backtester.run_backtest(symbols, algorithms)
    
        # Generate report
        report = backtester.generate_report()
    
        # Generate plots
        backtester.plot_results()
    
        # Print results
        if report and 'summary' in report:
            logger.info("\n" + "="*80)
            logger.info("📊 BACKTEST RESULTS")
            logger.info("="*80)
        
            summary = report['summary']
            logger.info(f"\n📈 Best Algorithm: {summary.get('best_algorithm', 'N/A')}")
            logger.info(f"   Return: {summary.get('best_return', 0):.2%}")
            logger.info(f"\n📊 Average Performance:")
            logger.info(f"   Return: {summary.get('average_return', 0):.2%}")
            logger.info(f"   Sharpe: {summary.get('average_sharpe', 0):.2f}")
        
            logger.info("\n🏆 TOP 10 ALGORITHMS:")
            logger.info(f"{'Rank':<5} {'Algorithm':<25} {'Return':<12} {'Sharpe':<10} {'Win Rate':<10} {'Trades':<10}")
            logger.info("-" * 75)
        
            for i, algo in enumerate(report.get('top_performers', [])[:10], 1):
                print(f"{i:<5} {algo['algorithm']:<25} {algo['return']:>10.2%} ")
                      f"{algo['sharpe']:>8.2f} {algo['win_rate']:>8.1%} {algo['trades']:>8}")
        
            # Category analysis
            logger.info("\n📊 PERFORMANCE BY CATEGORY:")
            category_data = report.get('category_analysis', {})
            logger.info(f"{'Category':<15} {'Avg Return':<12} {'Best':<12} {'# Algos':<10}")
            logger.info("-" * 50)
        
            for cat, data in sorted(category_data.items(), 
                                   key=lambda x: x[1].get('avg_return', 0), 
                                   reverse=True):
                logger.info(f"{cat:<15} {data.get('avg_return', 0):>10.2%} ")
                      f"{data.get('best_return', 0):>10.2%} {data.get('n_algorithms', 0):>8}")
        
            logger.info("\n✅ Backtest complete!")
            logger.info("\n📁 Results saved to:")
            logger.info("  • v21_backtest_report.json")
            logger.info("  • v21_backtest_results.png")
        else:
            logger.info("\n❌ No results generated")

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in run_historical_backtest: {str(e)}")
        raise
    asyncio.run(run_historical_backtest()