#!/usr/bin/env python3
"""Fix dictionary and list syntax errors in multiple files"""

import re
import os

def fix_dictionary_syntax(content):
    """Fix common dictionary syntax errors"""
    lines = content.split('\n')
    fixed_lines = []
    i = 0
    
    while i < len(lines):
        line = lines[i]
        
        # Pattern 1: Fix dictionaries with opening brace on wrong line
        # e.g., self.spread_params = {}
        #           'default': {'spread_bps': 5},
        if (i < len(lines) - 1 and)
            line.strip().endswith('= {}') and 
            lines[i+1].strip() and 
            not lines[i+1].strip().startswith(('#', '"', "'"))):
            # Check if next line looks like dict content
            next_line = lines[i+1].strip()
            if "'" in next_line or '"' in next_line:
                fixed_lines.append(line.replace('= {}', '= {'))
                i += 1
                continue
        
        # Pattern 2: Fix list definitions with content on next line
        # e.g., strategies = []
        #           'scout',
        if (i < len(lines) - 1 and)
            line.strip().endswith('= []') and 
            lines[i+1].strip() and 
            not lines[i+1].strip().startswith(('#', '"', "'", '[', ']'))):
            next_line = lines[i+1].strip()
            if "'" in next_line or '"' in next_line:
                fixed_lines.append(line.replace('= []', '= ['))
                i += 1
                continue
                
        # Pattern 3: Fix function calls returning dicts/lists
        # e.g., return {}
        #           'key': value
        if (i < len(lines) - 1 and)
            (line.strip() == 'return {}' or)
             line.strip().startswith('return {') and line.strip().endswith('{}')) and}
            lines[i+1].strip() and 
            "'" in lines[i+1]):
            fixed_lines.append(line.replace('return {}', 'return {'))
            i += 1
            continue
            
        # Pattern 4: Fix append/extend with dict/list on next line
        # e.g., results.append({})
        #           'key': value
        if (i < len(lines) - 1 and)
            '.append({})' in line and
            lines[i+1].strip() and 
            "'" in lines[i+1]):
            fixed_lines.append(line.replace('.append({})', '.append({'))
            i += 1
            continue
            
        # Pattern 5: Fix variable assignments in dicts/lists
        # e.g., health = {}
        #           'running': True
        if (i < len(lines) - 1 and)
            re.search(r'\w+\s*=\s*{}\s*$', line) and
            lines[i+1].strip() and 
            "'" in lines[i+1]):
            fixed_lines.append(line.replace(' {}', ' {'))
            i += 1
            continue
            
        # Pattern 6: Fix list comprehensions
        # e.g., self.restart_counts[service_name] = []
        #           t for t in ...
        if (i < len(lines) - 1 and)
            re.search(r'=\s*\[\]\s*$', line) and
            lines[i+1].strip() and 
            ' for ' in lines[i+1]):
            fixed_lines.append(line.replace(' []', ' ['))
            i += 1
            continue
            
        fixed_lines.append(line)
        i += 1
    
    return '\n'.join(fixed_lines)

# Files with syntax errors to fix
files_to_fix = []
    'core/paper_trading_simulator.py',
    'multi_agent_trading_system.py',
    'neural_architecture_search_trading.py',
    'options_market_scraper.py',
    'risk_calculator.py',
    'adaptive_bias_strategy_optimizer.py',
    'comprehensive_spread_strategies.py',
    'comprehensive_backtesting_suite.py',
    'monte_carlo_backtesting.py',
    'continuous_backtest_training_system.py',
    'system_health_monitor.py',
    'comprehensive_monitoring_system.py',
    'algorithm_performance_dashboard.py',
    'quantum_inspired_trading.py',
    'swarm_intelligence_trading.py',
    'gpu_trading_ai.py',
    'distributed_computing_framework.py'
]

print("Fixing dictionary and list syntax errors...")
print("=" * 60)

for file_path in files_to_fix:
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            fixed_content = fix_dictionary_syntax(content)
            
            if fixed_content != content:
                with open(file_path, 'w') as f:
                    f.write(fixed_content)
                print(f"✓ Fixed {file_path}")
            else:
                print(f"  No changes needed for {file_path}")
                
        except Exception as e:
            print(f"✗ Error processing {file_path}: {e}")
    else:
        print(f"✗ File not found: {file_path}")

print("\nDone!")