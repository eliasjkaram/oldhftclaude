#!/usr/bin/env python3
"""
MINIO INTEGRATED PREDICTION SYSTEM
==================================
Integrates MinIO historical data for backtesting, ML training, and price prediction
for stocks, options, and spreads using deep learning algorithms
"""

import os
import sys
import asyncio
import logging
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import pandas as pd
from io import BytesIO
import warnings
warnings.filterwarnings('ignore')

# MinIO imports
from minio import Minio
from minio.error import S3Error

# ML/DL imports
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error
import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout, BatchNormalization, Input, MultiHeadAttention
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

# Technical indicators
import ta

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

class MinIOIntegratedPredictionSystem:
    def __init__(self):
        # MinIO configuration
        self.minio_client = Minio()
            "uschristmas.us:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
            secure=False
        )
        
        # Alpaca configuration
        self.api_key = 'PKEP9PIBDKOSUGHHY44Z'
        self.api_secret = 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ'
        self.trading_client = TradingClient(self.api_key, self.api_secret, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        # ML models storage
        self.models = {}
            'lstm': None,
            'gru': None,
            'transformer': None,
            'random_forest': None,
            'gradient_boost': None,
            'ensemble': None
        }
        
        # Scalers for normalization
        self.scalers = {}
        
        # Trading universe
        self.symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 
                       'JPM', 'SPY', 'QQQ', 'IWM', 'AMD', 'NFLX']
        
        # Device for PyTorch
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        logger.info("🚀 MinIO Integrated Prediction System Initialized")
        logger.info(f"📊 Using device: {self.device}")
        
    def list_minio_buckets(self):
        """List all available buckets in MinIO"""
        try:
            buckets = self.minio_client.list_buckets()
            logger.info(f"Found {len(buckets)} buckets in MinIO:")
            for bucket in buckets:
                logger.info(f"  - {bucket.name}")
            return [bucket.name for bucket in buckets]
        except Exception as e:
            logger.error(f"Error listing buckets: {e}")
            return []
    
    def get_historical_data_from_minio(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Fetch historical data from MinIO"""
        try:
            # Try different bucket naming conventions
            bucket_names = []
                'stockdb',
                'stock-data',
                'historical-data',
                'market-data',
                'options-data'
            ]
            
            for bucket in bucket_names:
                try:
                    # Try different object path formats
                    object_paths = []
                        f"{symbol}/daily/{start_date}_{end_date}.parquet",
                        f"stocks/{symbol}/{start_date}_{end_date}.csv",
                        f"{symbol}/1d/data.parquet",
                        f"daily/{symbol}.parquet"
                    ]
                    
                    for obj_path in object_paths:
                        try:
                            # Get object from MinIO
                            response = self.minio_client.get_object(bucket, obj_path)
                            data = response.read()
                            response.close()
                            response.release_conn()
                            
                            # Parse data based on file type
                            if obj_path.endswith('.parquet'):
                                df = pd.read_parquet(BytesIO(data))
                            else:
                                df = pd.read_csv(BytesIO(data))
                            
                            logger.info(f"✓ Found data for {symbol} in {bucket}/{obj_path}")
                            return df
                            
                        except:
                            continue
                except:
                    continue
            
            # If MinIO fails, use Alpaca as fallback
            logger.warning(f"MinIO data not found for {symbol}, using Alpaca API")
            return self.get_historical_data_from_alpaca(symbol, start_date, end_date)
            
        except Exception as e:
            logger.error(f"Error fetching from MinIO: {e}")
            return self.get_historical_data_from_alpaca(symbol, start_date, end_date)
    
    def get_historical_data_from_alpaca(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Fallback to Alpaca for historical data"""
        try:
            request = StockBarsRequest()
                symbol_or_symbols=symbol,
                timeframe=TimeFrame.Day,
                start=datetime.strptime(start_date, '%Y-%m-%d'),
                end=datetime.strptime(end_date, '%Y-%m-%d')
            )
            
            bars = self.data_client.get_stock_bars(request)
            df = bars.df.reset_index()
            
            # Rename columns to standard format
            df.columns = ['timestamp', 'symbol', 'open', 'high', 'low', 'close', 'volume', 'trade_count', 'vwap']
            df.set_index('timestamp', inplace=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching from Alpaca: {e}")
            return pd.DataFrame()
    
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Engineer features for ML models"""
        try:
            # Price features
            df['returns'] = df['close'].pct_change()
            df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
            df['price_range'] = df['high'] - df['low']
            df['price_position'] = (df['close'] - df['low']) / (df['high'] - df['low'])
            
            # Volume features
            df['volume_ratio'] = df['volume'] / df['volume'].rolling(20).mean()
            df['dollar_volume'] = df['close'] * df['volume']
            
            # Technical indicators
            df['sma_5'] = ta.trend.sma_indicator(df['close'], window=5)
            df['sma_20'] = ta.trend.sma_indicator(df['close'], window=20)
            df['sma_50'] = ta.trend.sma_indicator(df['close'], window=50)
            df['ema_12'] = ta.trend.ema_indicator(df['close'], window=12)
            df['ema_26'] = ta.trend.ema_indicator(df['close'], window=26)
            
            # MACD
            macd = ta.trend.MACD(df['close'])
            df['macd'] = macd.macd()
            df['macd_signal'] = macd.macd_signal()
            df['macd_diff'] = macd.macd_diff()
            
            # RSI
            df['rsi'] = ta.momentum.RSIIndicator(df['close']).rsi()
            
            # Bollinger Bands
            bb = ta.volatility.BollingerBands(df['close'])
            df['bb_upper'] = bb.bollinger_hband()
            df['bb_middle'] = bb.bollinger_mavg()
            df['bb_lower'] = bb.bollinger_lband()
            df['bb_width'] = df['bb_upper'] - df['bb_lower']
            df['bb_position'] = (df['close'] - df['bb_lower']) / df['bb_width']
            
            # ATR (volatility)
            df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close']).average_true_range()
            
            # Stochastic
            stoch = ta.momentum.StochasticOscillator(df['high'], df['low'], df['close'])
            df['stoch_k'] = stoch.stoch()
            df['stoch_d'] = stoch.stoch_signal()
            
            # Options-specific features (implied volatility proxy)
            df['volatility_20'] = df['returns'].rolling(20).std() * np.sqrt(252)
            df['volatility_60'] = df['returns'].rolling(60).std() * np.sqrt(252)
            
            # Time features
            df['day_of_week'] = df.index.dayofweek
            df['month'] = df.index.month
            df['quarter'] = df.index.quarter
            
            # Forward fill NaN values
            df.fillna(method='ffill', inplace=True)
            df.dropna(inplace=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Error engineering features: {e}")
            return df
    
    def prepare_sequences(self, data: np.ndarray, lookback: int = 30, forecast_horizon: int = 5) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare sequences for time series models"""
        X, y = [], []
        
        for i in range(lookback, len(data) - forecast_horizon):
            X.append(data[i-lookback:i])
            y.append(data[i:i+forecast_horizon, 0])  # Predict closing prices
            
        return np.array(X), np.array(y)
    
    def build_lstm_model(self, input_shape: Tuple, output_shape: int) -> tf.keras.Model:
        """Build LSTM model for price prediction"""
        model = Sequential([)
            LSTM(128, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            LSTM(64, return_sequences=True),
            Dropout(0.2),
            LSTM(32),
            Dropout(0.2),
            Dense(output_shape)
        ])
        
        model.compile(optimizer=Adam(learning_rate=0.001), 
                     loss='mse', 
                     metrics=['mae'])
        
        return model
    
    def build_transformer_model(self, input_shape: Tuple, output_shape: int) -> tf.keras.Model:
        """Build Transformer model for price prediction"""
        inputs = Input(shape=input_shape)
        
        # Multi-head attention
        attention = MultiHeadAttention(num_heads=4, key_dim=64)(inputs, inputs)
        attention = Dropout(0.1)(attention)
        attention = tf.keras.layers.LayerNormalization(epsilon=1e-6)(attention + inputs)
        
        # Feed forward
        ffn = Dense(128, activation='relu')(attention)
        ffn = Dense(input_shape[-1])(ffn)
        ffn = Dropout(0.1)(ffn)
        ffn = tf.keras.layers.LayerNormalization(epsilon=1e-6)(ffn + attention)
        
        # Output
        output = tf.keras.layers.GlobalAveragePooling1D()(ffn)
        output = Dense(64, activation='relu')(output)
        output = Dropout(0.1)(output)
        output = Dense(output_shape)(output)
        
        model = Model(inputs=inputs, outputs=output)
        model.compile(optimizer=Adam(learning_rate=0.001), 
                     loss='mse', 
                     metrics=['mae'])
        
        return model
    
    async def train_models(self, symbol: str):
        """Train all models on historical data"""
        logger.info(f"🔧 Training models for {symbol}...")
        
        # Fetch historical data (2 years)
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=730)).strftime('%Y-%m-%d')
        
        # Get data from MinIO or Alpaca
        df = self.get_historical_data_from_minio(symbol, start_date, end_date)
        
        if df.empty:
            logger.error(f"No data available for {symbol}")
            return
        
        # Engineer features
        df = self.engineer_features(df)
        
        # Select features for modeling
        feature_cols = ['open', 'high', 'low', 'close', 'volume', 'returns', 
                       'sma_20', 'ema_12', 'rsi', 'macd', 'atr', 'volatility_20']
        
        # Prepare data
        data = df[feature_cols].values
        
        # Normalize data
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data)
        self.scalers[symbol] = scaler
        
        # Prepare sequences
        X, y = self.prepare_sequences(data_scaled, lookback=30, forecast_horizon=5)
        
        # Split data
        split_idx = int(0.8 * len(X))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Train LSTM
        logger.info("Training LSTM model...")
        lstm_model = self.build_lstm_model((X.shape[1], X.shape[2]), y.shape[1])
        
        early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
        reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5)
        
        lstm_model.fit()
            X_train, y_train,
            epochs=50,
            batch_size=32,
            validation_split=0.2,
            callbacks=[early_stop, reduce_lr],
            verbose=0
        )
        
        self.models['lstm'] = lstm_model
        
        # Train Transformer
        logger.info("Training Transformer model...")
        transformer_model = self.build_transformer_model((X.shape[1], X.shape[2]), y.shape[1])
        
        transformer_model.fit()
            X_train, y_train,
            epochs=50,
            batch_size=32,
            validation_split=0.2,
            callbacks=[early_stop, reduce_lr],
            verbose=0
        )
        
        self.models['transformer'] = transformer_model
        
        # Train Random Forest on flattened data
        logger.info("Training Random Forest model...")
        X_train_flat = X_train.reshape(X_train.shape[0], -1)
        X_test_flat = X_test.reshape(X_test.shape[0], -1)
        
        rf_model = RandomForestRegressor(n_estimators=100, max_depth=10, n_jobs=-1)
        rf_model.fit(X_train_flat, y_train)
        
        self.models['random_forest'] = rf_model
        
        # Evaluate models
        lstm_pred = lstm_model.predict(X_test)
        transformer_pred = transformer_model.predict(X_test)
        rf_pred = rf_model.predict(X_test_flat)
        
        # Calculate metrics
        lstm_mae = mean_absolute_error(y_test, lstm_pred)
        transformer_mae = mean_absolute_error(y_test, transformer_pred)
        rf_mae = mean_absolute_error(y_test, rf_pred)
        
        logger.info(f"✅ Model Training Complete for {symbol}")
        logger.info(f"   LSTM MAE: {lstm_mae:.4f}")
        logger.info(f"   Transformer MAE: {transformer_mae:.4f}")
        logger.info(f"   Random Forest MAE: {rf_mae:.4f}")
    
    def predict_prices(self, symbol: str, days_ahead: int = 5) -> Dict[str, Any]:
        """Predict future prices using ensemble of models"""
        try:
            # Get recent data
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=60)).strftime('%Y-%m-%d')
            
            df = self.get_historical_data_from_minio(symbol, start_date, end_date)
            
            if df.empty:
                return {}
            
            # Engineer features
            df = self.engineer_features(df)
            
            # Prepare data
            feature_cols = ['open', 'high', 'low', 'close', 'volume', 'returns', 
                           'sma_20', 'ema_12', 'rsi', 'macd', 'atr', 'volatility_20']
            
            data = df[feature_cols].values[-30:]  # Last 30 days
            
            # Scale data
            if symbol in self.scalers:
                data_scaled = self.scalers[symbol].transform(data)
            else:
                return {}
            
            # Prepare input
            X = data_scaled.reshape(1, data_scaled.shape[0], data_scaled.shape[1])
            X_flat = X.reshape(1, -1)
            
            predictions = {}
            
            # Get predictions from each model
            if self.models['lstm']:
                lstm_pred = self.models['lstm'].predict(X)[0]
                # Inverse transform (only close price column)
                lstm_pred_prices = self.scalers[symbol].inverse_transform()
                    np.column_stack([lstm_pred, np.zeros((len(lstm_pred), len(feature_cols)-1))])
                )[:, 0]
                predictions['lstm'] = lstm_pred_prices
            
            if self.models['transformer']:
                trans_pred = self.models['transformer'].predict(X)[0]
                trans_pred_prices = self.scalers[symbol].inverse_transform()
                    np.column_stack([trans_pred, np.zeros((len(trans_pred), len(feature_cols)-1))])
                )[:, 0]
                predictions['transformer'] = trans_pred_prices
            
            if self.models['random_forest']:
                rf_pred = self.models['random_forest'].predict(X_flat)[0]
                rf_pred_prices = self.scalers[symbol].inverse_transform()
                    np.column_stack([rf_pred, np.zeros((len(rf_pred), len(feature_cols)-1))])
                )[:, 0]
                predictions['random_forest'] = rf_pred_prices
            
            # Ensemble prediction (average)
            if predictions:
                ensemble_pred = np.mean(list(predictions.values()), axis=0)
                predictions['ensemble'] = ensemble_pred
                
                # Calculate confidence based on model agreement
                std_dev = np.std(list(predictions.values()), axis=0)
                confidence = 1 - (std_dev / ensemble_pred)
                
                return {}
                    'symbol': symbol,
                    'current_price': df['close'].iloc[-1],
                    'predictions': predictions,
                    'ensemble_forecast': ensemble_pred.tolist(),
                    'confidence': confidence.mean(),
                    'dates': [(datetime.now() + timedelta(days=i+1)).strftime('%Y-%m-%d') 
                             for i in range(days_ahead)]
                }
            
            return {}
            
        except Exception as e:
            logger.error(f"Error predicting prices: {e}")
            return {}
    
    def predict_option_prices(self, symbol: str, strike: float, expiry_days: int, option_type: str = 'call') -> Dict[str, float]:
        """Predict option prices using Black-Scholes with ML-predicted volatility"""
        try:
            # Get stock price prediction
            stock_prediction = self.predict_prices(symbol, days_ahead=expiry_days)
            
            if not stock_prediction:
                return {}
            
            # Current price and predicted price at expiry
            S = stock_prediction['current_price']
            K = strike
            T = expiry_days / 365.0
            r = 0.05  # Risk-free rate (current Fed funds rate approximation)
            
            # Get predicted volatility from historical data
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=60)).strftime('%Y-%m-%d')
            df = self.get_historical_data_from_minio(symbol, start_date, end_date)
            
            if not df.empty:
                df = self.engineer_features(df)
                sigma = df['volatility_20'].iloc[-1]
            else:
                sigma = 0.3  # Default volatility
            
            # Black-Scholes formula components
            from scipy.stats import norm
            
            d1 = (np.log(S/K) + (r + sigma**2/2)*T) / (sigma*np.sqrt(T))
            d2 = d1 - sigma*np.sqrt(T)
            
            if option_type == 'call':
                price = S*norm.cdf(d1) - K*np.exp(-r*T)*norm.cdf(d2)
                delta = norm.cdf(d1)
            else:  # put
                price = K*np.exp(-r*T)*norm.cdf(-d2) - S*norm.cdf(-d1)
                delta = -norm.cdf(-d1)
            
            # Greeks
            gamma = norm.pdf(d1)/(S*sigma*np.sqrt(T))
            theta = -(S*norm.pdf(d1)*sigma)/(2*np.sqrt(T)) - r*K*np.exp(-r*T)*norm.cdf(d2)
            vega = S*norm.pdf(d1)*np.sqrt(T)
            
            # ML adjustment based on predicted price movement
            predicted_price = stock_prediction['ensemble_forecast'][-1]
            price_change_pct = (predicted_price - S) / S
            
            # Adjust option price based on ML prediction
            if option_type == 'call':
                ml_adjustment = max(0, (predicted_price - K) * np.exp(-r*T)) if predicted_price > K else 0
            else:
                ml_adjustment = max(0, (K - predicted_price) * np.exp(-r*T)) if K > predicted_price else 0
            
            # Weighted average of BS price and ML adjustment
            final_price = 0.7 * price + 0.3 * ml_adjustment
            
            return {}
                'option_type': option_type,
                'symbol': symbol,
                'strike': strike,
                'expiry_days': expiry_days,
                'current_stock_price': S,
                'predicted_stock_price': predicted_price,
                'black_scholes_price': price,
                'ml_adjusted_price': final_price,
                'implied_volatility': sigma,
                'delta': delta,
                'gamma': gamma,
                'theta': theta / 365,  # Per day
                'vega': vega / 100,  # Per 1% volatility
                'confidence': stock_prediction['confidence']
            }
            
        except Exception as e:
            logger.error(f"Error predicting option price: {e}")
            return {}
    
    def predict_spread_prices(self, symbol: str, spread_type: str, strikes: Dict, expiry_days: int) -> Dict[str, Any]:
        """Predict multi-leg spread prices"""
        try:
            predictions = {}
            
            if spread_type == 'bull_call_spread':
                # Long lower strike call, short higher strike call
                long_call = self.predict_option_prices(symbol, strikes['long_strike'], expiry_days, 'call')
                short_call = self.predict_option_prices(symbol, strikes['short_strike'], expiry_days, 'call')
                
                if long_call and short_call:
                    net_debit = long_call['ml_adjusted_price'] - short_call['ml_adjusted_price']
                    max_profit = (strikes['short_strike'] - strikes['long_strike'] - net_debit) * 100
                    max_loss = net_debit * 100
                    
                    predictions = {}
                        'spread_type': 'bull_call_spread',
                        'symbol': symbol,
                        'long_strike': strikes['long_strike'],
                        'short_strike': strikes['short_strike'],
                        'expiry_days': expiry_days,
                        'net_debit': net_debit,
                        'max_profit': max_profit,
                        'max_loss': max_loss,
                        'breakeven': strikes['long_strike'] + net_debit,
                        'long_call_price': long_call['ml_adjusted_price'],
                        'short_call_price': short_call['ml_adjusted_price'],
                        'profit_probability': self._calculate_profit_probability()
                            long_call['current_stock_price'],
                            strikes['long_strike'] + net_debit,
                            long_call['implied_volatility'],
                            expiry_days
                        )
                    }
                    
            elif spread_type == 'iron_condor':
                # 4-leg strategy
                put_short = self.predict_option_prices(symbol, strikes['put_short'], expiry_days, 'put')
                put_long = self.predict_option_prices(symbol, strikes['put_long'], expiry_days, 'put')
                call_short = self.predict_option_prices(symbol, strikes['call_short'], expiry_days, 'call')
                call_long = self.predict_option_prices(symbol, strikes['call_long'], expiry_days, 'call')
                
                if all([put_short, put_long, call_short, call_long]):
                    net_credit = (put_short['ml_adjusted_price'] - put_long['ml_adjusted_price'] +)
                                 call_short['ml_adjusted_price'] - call_long['ml_adjusted_price'])
                    
                    max_profit = net_credit * 100
                    max_loss = ((strikes['put_short'] - strikes['put_long']) - net_credit) * 100
                    
                    predictions = {}
                        'spread_type': 'iron_condor',
                        'symbol': symbol,
                        'strikes': strikes,
                        'expiry_days': expiry_days,
                        'net_credit': net_credit,
                        'max_profit': max_profit,
                        'max_loss': max_loss,
                        'upper_breakeven': strikes['call_short'] + net_credit,
                        'lower_breakeven': strikes['put_short'] - net_credit,
                        'profit_probability': self._calculate_ic_profit_probability()
                            put_short['current_stock_price'],
                            strikes['put_short'] - net_credit,
                            strikes['call_short'] + net_credit,
                            put_short['implied_volatility'],
                            expiry_days
                        )
                    }
            
            return predictions
            
        except Exception as e:
            logger.error(f"Error predicting spread price: {e}")
            return {}
    
    def _calculate_profit_probability(self, current_price: float, breakeven: float, 
                                    volatility: float, days: int) -> float:
        """Calculate probability of profit for directional trades"""
        from scipy.stats import norm
        
        # Calculate probability of stock being above breakeven at expiry
        drift = 0  # Assuming no drift
        std_dev = volatility * np.sqrt(days / 365)
        z_score = (np.log(breakeven / current_price) - drift) / std_dev
        
        return 1 - norm.cdf(z_score)
    
    def _calculate_ic_profit_probability(self, current_price: float, lower_be: float, 
                                       upper_be: float, volatility: float, days: int) -> float:
        """Calculate probability of profit for iron condor"""
        from scipy.stats import norm
        
        # Probability of staying between breakeven points
        std_dev = volatility * np.sqrt(days / 365)
        
        z_lower = (np.log(lower_be / current_price)) / std_dev
        z_upper = (np.log(upper_be / current_price)) / std_dev
        
        return norm.cdf(z_upper) - norm.cdf(z_lower)
    
    async def backtest_strategy(self, symbol: str, strategy: str, start_date: str, end_date: str) -> Dict[str, Any]:
        """Backtest trading strategy using historical data"""
        logger.info(f"📊 Backtesting {strategy} on {symbol} from {start_date} to {end_date}")
        
        # Get historical data
        df = self.get_historical_data_from_minio(symbol, start_date, end_date)
        
        if df.empty:
            return {}
        
        # Engineer features
        df = self.engineer_features(df)
        
        # Initialize backtest metrics
        trades = []
        portfolio_value = [100000]  # Starting capital
        position = 0
        entry_price = 0
        
        # Simple momentum strategy for demonstration
        for i in range(20, len(df)):
            current_price = df['close'].iloc[i]
            
            # Entry signal
            if position == 0:
                if df['sma_5'].iloc[i] > df['sma_20'].iloc[i] and df['rsi'].iloc[i] < 70:
                    # Buy signal
                    position = portfolio_value[-1] * 0.95 / current_price  # 95% of capital
                    entry_price = current_price
                    trades.append({)
                        'date': df.index[i],
                        'type': 'BUY',
                        'price': current_price,
                        'quantity': position
                    })
            
            # Exit signal
            elif position > 0:
                if df['sma_5'].iloc[i] < df['sma_20'].iloc[i] or df['rsi'].iloc[i] > 80:
                    # Sell signal
                    exit_price = current_price
                    pnl = (exit_price - entry_price) * position
                    portfolio_value.append(portfolio_value[-1] + pnl)
                    
                    trades.append({)
                        'date': df.index[i],
                        'type': 'SELL',
                        'price': current_price,
                        'quantity': position,
                        'pnl': pnl
                    })
                    
                    position = 0
        
        # Calculate metrics
        total_trades = len([t for t in trades if t['type'] == 'SELL'])
        winning_trades = len([t for t in trades if t.get('pnl', 0) > 0])
        
        if total_trades > 0:
            win_rate = winning_trades / total_trades
            avg_win = np.mean([t['pnl'] for t in trades if t.get('pnl', 0) > 0])
            avg_loss = np.mean([t['pnl'] for t in trades if t.get('pnl', 0) < 0])
            profit_factor = abs(avg_win / avg_loss) if avg_loss != 0 else 0
        else:
            win_rate = avg_win = avg_loss = profit_factor = 0
        
        final_value = portfolio_value[-1]
        total_return = (final_value - 100000) / 100000
        
        # Calculate Sharpe ratio
        returns = pd.Series(portfolio_value).pct_change().dropna()
        sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0
        
        return {}
            'symbol': symbol,
            'strategy': strategy,
            'start_date': start_date,
            'end_date': end_date,
            'initial_capital': 100000,
            'final_value': final_value,
            'total_return': total_return,
            'total_trades': total_trades,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': self._calculate_max_drawdown(portfolio_value),
            'trades': trades[:10]  # First 10 trades
        }
    
    def _calculate_max_drawdown(self, portfolio_values: List[float]) -> float:
        """Calculate maximum drawdown"""
        peak = portfolio_values[0]
        max_dd = 0
        
        for value in portfolio_values:
            if value > peak:
                peak = value
            dd = (peak - value) / peak
            if dd > max_dd:
                max_dd = dd
                
        return max_dd
    
    async def run_demo(self):
        """Run comprehensive demo of the system"""
        logger.info("🚀 Starting MinIO Integrated Prediction System Demo")
        logger.info("="*80)
        
        # 1. List MinIO buckets
        logger.info("\n📦 Checking MinIO connectivity...")
        buckets = self.list_minio_buckets()
        
        # 2. Train models on a symbol
        symbol = 'AAPL'
        logger.info(f"\n🔧 Training ML models for {symbol}...")
        await self.train_models(symbol)
        
        # 3. Predict stock prices
        logger.info(f"\n📈 Predicting stock prices for {symbol}...")
        stock_prediction = self.predict_prices(symbol, days_ahead=5)
        
        if stock_prediction:
            logger.info(f"Current Price: ${stock_prediction['current_price']:.2f}")
            logger.info(f"5-Day Forecast: {[f'${p:.2f}' for p in stock_prediction['ensemble_forecast']]}")
            logger.info(f"Confidence: {stock_prediction['confidence']:.2%}")
        
        # 4. Predict option prices
        logger.info(f"\n📊 Predicting option prices...")
        current_price = stock_prediction['current_price'] if stock_prediction else 150
        
        # ATM Call
        call_prediction = self.predict_option_prices(symbol, current_price, 30, 'call')
        if call_prediction:
            logger.info(f"\n30-Day ATM Call Option:")
            logger.info(f"  Strike: ${call_prediction['strike']:.2f}")
            logger.info(f"  Black-Scholes Price: ${call_prediction['black_scholes_price']:.2f}")
            logger.info(f"  ML-Adjusted Price: ${call_prediction['ml_adjusted_price']:.2f}")
            logger.info(f"  Delta: {call_prediction['delta']:.3f}")
            logger.info(f"  Implied Volatility: {call_prediction['implied_volatility']:.2%}")
        
        # 5. Predict spread prices
        logger.info(f"\n🎯 Predicting spread prices...")
        
        # Bull Call Spread
        bull_spread = self.predict_spread_prices()
            symbol, 
            'bull_call_spread',
            {'long_strike': current_price * 0.98, 'short_strike': current_price * 1.02},
            30
        )
        
        if bull_spread:
            logger.info(f"\nBull Call Spread:")
            logger.info(f"  Long Strike: ${bull_spread['long_strike']:.2f}")
            logger.info(f"  Short Strike: ${bull_spread['short_strike']:.2f}")
            logger.info(f"  Net Debit: ${bull_spread['net_debit']:.2f}")
            logger.info(f"  Max Profit: ${bull_spread['max_profit']:.2f}")
            logger.info(f"  Probability of Profit: {bull_spread['profit_probability']:.2%}")
        
        # 6. Backtest a strategy
        logger.info(f"\n⏮️ Backtesting momentum strategy...")
        backtest_results = await self.backtest_strategy()
            symbol,
            'momentum_crossover',
            '2023-01-01',
            '2024-12-31'
        )
        
        if backtest_results:
            logger.info(f"\nBacktest Results:")
            logger.info(f"  Total Return: {backtest_results['total_return']:.2%}")
            logger.info(f"  Win Rate: {backtest_results['win_rate']:.2%}")
            logger.info(f"  Sharpe Ratio: {backtest_results['sharpe_ratio']:.2f}")
            logger.info(f"  Max Drawdown: {backtest_results['max_drawdown']:.2%}")
        
        logger.info("\n" + "="*80)
        logger.info("✅ Demo Complete! System ready for production trading")

async def main():
    system = MinIOIntegratedPredictionSystem()
    await system.run_demo()

if __name__ == "__main__":
    asyncio.run(main())