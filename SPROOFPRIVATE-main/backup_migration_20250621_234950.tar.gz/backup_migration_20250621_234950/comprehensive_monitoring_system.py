#!/usr/bin/env python3
"""
COMPREHENSIVE MONITORING AND LOGGING SYSTEM
==========================================

This module implements comprehensive structured logging and monitoring throughout
the trading system, including:
- Structured logging with the StructuredLogger from PRODUCTION_FIXES.py
- Correlation IDs for request tracking
- Audit logs for compliance
- Performance metrics collection
- Prometheus integration for monitoring
- Real-time dashboards and alerts
"""

import os
import json
import logging
import asyncio
import time
import uuid
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from contextlib import contextmanager
from functools import wraps
from collections import defaultdict
import traceback

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Import StructuredLogger from PRODUCTION_FIXES
from PRODUCTION_FIXES import StructuredLogger

from universal_market_data import get_current_market_data, validate_price


# Try to import Prometheus client
try:
    from prometheus_client import ()
        Counter, Histogram, Gauge, Summary,
        CollectorRegistry, generate_latest,
        start_http_server
    )
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    print("Warning: prometheus_client not installed. Metrics will be logged only.")

# Configure base logging
logging.basicConfig()
    level=logging.INFO,
    format='%(message)s',  # JSON format from StructuredLogger
    handlers=[]
        logging.FileHandler('monitoring.log'),
        logging.StreamHandler()
    ]
)

class CorrelationContext:
    """Thread-local storage for correlation IDs"""
    _thread_local = threading.local()
    
    @classmethod
    def set_correlation_id(cls, correlation_id: str):
        """Set correlation ID for current thread"""
        cls._thread_local.correlation_id = correlation_id
    
    @classmethod
    def get_correlation_id(cls) -> Optional[str]:
        """Get correlation ID for current thread"""
        return getattr(cls._thread_local, 'correlation_id', None)
    
    @classmethod
    def clear_correlation_id(cls):
        """Clear correlation ID for current thread"""
        if hasattr(cls._thread_local, 'correlation_id'):
            del cls._thread_local.correlation_id

class MonitoredLogger(StructuredLogger):
    """Enhanced structured logger with correlation ID support"""
    
    def __init__(self, name: str):
        super().__init__(name)
        self.audit_logger = logging.getLogger(f"{name}.audit")
        self.performance_logger = logging.getLogger(f"{name}.performance")
    
    def _format_message(self, level: str, message: str, **kwargs) -> Dict:
        """Format structured log message with correlation ID"""
        # Get correlation ID from context
        correlation_id = CorrelationContext.get_correlation_id() or self.correlation_id
        
        log_entry = {}
            'timestamp': datetime.utcnow().isoformat(),
            'level': level,
            'message': message,
            'correlation_id': correlation_id,
            'logger': self.logger.name,
            'thread_id': threading.current_thread().ident,
            'process_id': os.getpid(),
            **kwargs
        }
        return log_entry
    
    def audit(self, action: str, details: Dict, user: str = None, ip_address: str = None):
        """Enhanced audit log for compliance with additional metadata"""
        audit_entry = self._format_message('AUDIT', action,)
    def start_monitoring(self):
            user=user,
            ip_address=ip_address,
            audit_timestamp=datetime.utcnow().isoformat(),
            audit_action=action
        )]
        self.audit_logger.info(json.dumps(audit_entry))
    
    def performance(self, operation: str, duration_ms: float, **metrics):
        """Log performance metrics"""
        perf_entry = self._format_message('PERFORMANCE', f"Operation: {operation}",)
            operation=operation,
            duration_ms=duration_ms,
            **metrics
        )
        self.performance_logger.info(json.dumps(perf_entry))

class MetricsCollector:
    """Collects and exports metrics for monitoring systems"""
    
    def __init__(self, namespace: str = "trading_system"):
        self.namespace = namespace
        self.registry = CollectorRegistry()
        
        if PROMETHEUS_AVAILABLE:
            # Trading metrics
            self.orders_total = Counter()
                'orders_total',
                'Total number of orders placed',
                ['order_type', 'side', 'status'],
                namespace=namespace,
                registry=self.registry
            )
            
            self.order_execution_time = Histogram()
                'order_execution_duration_seconds',
                'Time taken to execute orders',
                ['order_type'],
                namespace=namespace,
                registry=self.registry
            )
            
            self.portfolio_value = Gauge()
                'portfolio_value_usd',
                'Current portfolio value in USD',
                namespace=namespace,
                registry=self.registry
            )
            
            self.active_positions = Gauge()
                'active_positions_count',
                'Number of active positions',
                ['asset_type'],
                namespace=namespace,
                registry=self.registry
            )
            
            # System metrics
            self.api_requests_total = Counter()
                'api_requests_total',
                'Total API requests',
                ['endpoint', 'method', 'status'],
                namespace=namespace,
                registry=self.registry
            )
            
            self.api_request_duration = Histogram()
                'api_request_duration_seconds',
                'API request duration',
                ['endpoint', 'method'],
                namespace=namespace,
                registry=self.registry
            )
            
            self.error_count = Counter()
                'errors_total',
                'Total number of errors',
                ['error_type', 'component'],
                namespace=namespace,
                registry=self.registry
            )
            
            # AI/ML metrics
            self.model_predictions = Counter()
                'model_predictions_total',
                'Total model predictions',
                ['model_name', 'prediction_type'],
                namespace=namespace,
                registry=self.registry
            )
            
            self.model_accuracy = Gauge()
                'model_accuracy_percent',
                'Model accuracy percentage',
                ['model_name'],
                namespace=namespace,
                registry=self.registry
            )
            
            self.backtest_performance = Summary()
                'backtest_performance',
                'Backtest performance metrics',
                ['strategy'],
                namespace=namespace,
                registry=self.registry
            )
        
        # Local metrics storage for when Prometheus is not available
        self.local_metrics = defaultdict(lambda: defaultdict(float))
    
    def record_order(self, order_type: str, side: str, status: str):
        """Record order metrics"""
        if PROMETHEUS_AVAILABLE:
            self.orders_total.labels()
                order_type=order_type,
                side=side,
                status=status
            ).inc()
        else:
            self.local_metrics['orders'][f"{order_type}_{side}_{status}"] += 1
    
    def record_order_execution_time(self, order_type: str, duration_seconds: float):
        """Record order execution time"""
        if PROMETHEUS_AVAILABLE:
            self.order_execution_time.labels(order_type=order_type).observe(duration_seconds)
        else:
            self.local_metrics['order_execution_times'][order_type].append(duration_seconds)
    
    def update_portfolio_value(self, value: float):
        """Update portfolio value metric"""
        if PROMETHEUS_AVAILABLE:
            self.portfolio_value.set(value)
        else:
            self.local_metrics['portfolio']['value'] = value
    
    def update_active_positions(self, asset_type: str, count: int):
        """Update active positions count"""
        if PROMETHEUS_AVAILABLE:
            self.active_positions.labels(asset_type=asset_type).set(count)
        else:
            self.local_metrics['positions'][asset_type] = count
    
    def record_api_request(self, endpoint: str, method: str, status: int, duration: float):
        """Record API request metrics"""
        if PROMETHEUS_AVAILABLE:
            self.api_requests_total.labels()
                endpoint=endpoint,
                method=method,
                status=str(status)
            ).inc()
            self.api_request_duration.labels()
                endpoint=endpoint,
                method=method
            ).observe(duration)
        else:
            self.local_metrics['api_requests'][f"{endpoint}_{method}_{status}"] += 1
            self.local_metrics['api_durations'][f"{endpoint}_{method}"].append(duration)
    
    def record_error(self, error_type: str, component: str):
        """Record error metrics"""
        if PROMETHEUS_AVAILABLE:
            self.error_count.labels()
                error_type=error_type,
                component=component
            ).inc()
        else:
            self.local_metrics['errors'][f"{error_type}_{component}"] += 1
    
    def record_model_prediction(self, model_name: str, prediction_type: str):
        """Record model prediction"""
        if PROMETHEUS_AVAILABLE:
            self.model_predictions.labels()
                model_name=model_name,
                prediction_type=prediction_type
            ).inc()
        else:
            self.local_metrics['predictions'][f"{model_name}_{prediction_type}"] += 1
    
    def update_model_accuracy(self, model_name: str, accuracy: float):
        """Update model accuracy"""
        if PROMETHEUS_AVAILABLE:
            self.model_accuracy.labels(model_name=model_name).set(accuracy * 100)
        else:
            self.local_metrics['model_accuracy'][model_name] = accuracy
    
    def record_backtest_performance(self, strategy: str, metrics: Dict[str, float]):
        """Record backtest performance metrics"""
        if PROMETHEUS_AVAILABLE:
            summary = self.backtest_performance.labels(strategy=strategy)
            for value in metrics.values():
                summary.observe(value)
        else:
            self.local_metrics['backtest'][strategy].update(metrics)
    
    def get_metrics(self) -> str:
        """Get metrics in Prometheus format or JSON"""
        if PROMETHEUS_AVAILABLE:
            return generate_latest(self.registry).decode('utf-8')
        else:
            return json.dumps(dict(self.local_metrics), indent=2)

class MonitoringSystem:
    """Main monitoring system that integrates all monitoring components"""
    
    def __init__(self, app_name: str = "alpaca_trading"):
        self.app_name = app_name
        self.logger = MonitoredLogger(app_name)
        self.metrics = MetricsCollector(namespace=app_name)
        self.health_checks = {}
        self.monitoring_tasks = []
        self._running = False
        
        # Start Prometheus metrics server if available
        if PROMETHEUS_AVAILABLE:
            try:
                start_http_server(9090)  # Prometheus metrics on port 9090
                self.logger.info("Prometheus metrics server started on port 9090")
            except Exception as e:
                self.logger.error(f"Failed to start Prometheus server: {e}")
    
    @contextmanager
    def track_request(self, operation_name: str, **tags):
        """Context manager to track a request with correlation ID"""
        correlation_id = str(uuid.uuid4()
        CorrelationContext.set_correlation_id(correlation_id)
        
        start_time = time.time()
        self.logger.info(f"Starting {operation_name}",)
                        operation=operation_name,
                        tags=tags)
        
        try:
            yield correlation_id
        except Exception as e:
            duration = (time.time() - start_time) * 1000
            self.logger.error(f"Failed {operation_name}",)
                            operation=operation_name,
                            duration_ms=duration,
                            error=str(e),
                            error_type=type(e).__name__,
                            traceback=traceback.format_exc(),
                            tags=tags)
            self.metrics.record_error(type(e).__name__, operation_name)
            raise
        else:
            duration = (time.time() - start_time) * 1000
            self.logger.info(f"Completed {operation_name}",)
                           operation=operation_name,
                           duration_ms=duration,
                           tags=tags)
            self.logger.performance(operation_name, duration, **tags)
        finally:
            CorrelationContext.clear_correlation_id()
    
    def monitor_function(self, func: Callable) -> Callable:
        """Decorator to monitor function execution"""
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            with self.track_request(f"function.{func.__name__}"):
                return func(*args, **kwargs)
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            with self.track_request(f"function.{func.__name__}"):
                return await func(*args, **kwargs)
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    
    def audit_trading_action(self, action: str, order_details: Dict, user: str = "system"):
        """Audit log for trading actions"""
        self.logger.audit()
            action=f"TRADING_{action.upper()}",
            details=order_details,
            user=user,
            ip_address="127.0.0.1"  # In production, get real IP
        )
    
    def register_health_check(self, name: str, check_func: Callable[[], Dict]):
        """Register a health check function"""
        self.health_checks[name] = check_func
    
    async def run_health_checks(self) -> Dict[str, Any]:
        """Run all registered health checks"""
        results = {}
            'timestamp': datetime.utcnow().isoformat(),
            'status': 'healthy',
            'checks': {}
        }
        
        for name, check_func in self.health_checks.items():
            try:
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                
                results['checks'][name] = {}
                    'status': 'healthy',
                    'details': result
                }
            except Exception as e:
                results['checks'][name] = {}
                    'status': 'unhealthy',
                    'error': str(e)
                }
                results['status'] = 'unhealthy'
                self.metrics.record_error('health_check_failed', name)
        
        return results
    
    async def continuous_monitoring(self):
        """Run continuous monitoring tasks"""
        self._running = True
        
        while self._running:
            try:
                # Run health checks every 60 seconds
                health_results = await self.run_health_checks()
                self.logger.info("Health check completed",)
                               status=health_results['status'],
                               checks=len(health_results['checks'])
                
                # Export metrics periodically
                if not PROMETHEUS_AVAILABLE:
                    metrics_data = self.metrics.get_metrics()
                    self.logger.info("Metrics snapshot", metrics=json.loads(metrics_data)
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(10)  # Retry after 10 seconds
    
    def start_monitoring(self):
        """Start the monitoring system"""
        self.logger.info("Starting monitoring system")
        
        # Create monitoring task
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        monitoring_task = loop.create_task(self.continuous_monitoring()
        self.monitoring_tasks.append(monitoring_task)
        
        # Run in background thread
        monitor_thread = threading.Thread(target=loop.run_forever, daemon=True)
        monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop the monitoring system"""
        self._running = False
        self.logger.info("Stopping monitoring system")

class TradingSystemMonitor:
    """Specialized monitor for trading system integration"""
    
    def __init__(self, monitoring_system: MonitoringSystem):
        self.monitoring = monitoring_system
        self.logger = monitoring_system.logger
        
        # Register trading-specific health checks
        self.monitoring.register_health_check('alpaca_connection', self.check_alpaca_connection)
        self.monitoring.register_health_check('database', self.check_database_connection)
        self.monitoring.register_health_check('market_data', self.check_market_data_feed)
    
    def check_alpaca_connection(self) -> Dict:
        """Check Alpaca API connection"""
        try:
            # Import here to avoid circular dependencies
            from alpaca.trading.client import TradingClient
            
            # Try to get account info
            client = TradingClient()
                api_key=os.getenv('ALPACA_PAPER_KEY', ''),
                secret_key=os.getenv('ALPACA_PAPER_SECRET', ''),
                paper=True
            )
            
            account = client.get_account()
            
            return {}
                'connected': True,
                'account_status': account.status,
                'buying_power': float(account.buying_power)
            }
        except Exception as e:
            raise Exception(f"Alpaca connection failed: {e}")
    
    def check_database_connection(self) -> Dict:
        """Check database connection"""
        try:
            import sqlite3
            
            # Test connection to main database
            conn = sqlite3.connect('orchestration.db')
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
            table_count = cursor.fetchone()[0]
            conn.close()
            
            return {}
                'connected': True,
                'tables': table_count
            }
        except Exception as e:
            raise Exception(f"Database connection failed: {e}")
    
    def check_market_data_feed(self) -> Dict:
        """Check market data feed status"""
        # This would check real market data connections
        # For now, return a mock healthy status
        return {}
            'status': 'active',
            'last_update': datetime.utcnow().isoformat()
        }
    
    @contextmanager
    def monitor_order_execution(self, order_type: str, symbol: str, side: str, quantity: float):
        """Monitor order execution with metrics and audit logging"""
        order_id = str(uuid.uuid4()
        
        with self.monitoring.track_request('order_execution',)
                                         order_id=order_id,
                                         symbol=symbol,
                                         order_type=order_type,
                                         side=side,
                                         quantity=quantity) as correlation_id:
            
            start_time = time.time()
            
            # Audit log the order attempt
            self.monitoring.audit_trading_action('ORDER_PLACED', {}
                'order_id': order_id,
                'correlation_id': correlation_id,
                'symbol': symbol,
                'order_type': order_type,
                'side': side,
                'quantity': quantity,
                'timestamp': datetime.utcnow().isoformat()
            })
            
            try:
                yield order_id
                
                # Record successful order
                duration = time.time() - start_time
                self.monitoring.metrics.record_order(order_type, side, 'success')
                self.monitoring.metrics.record_order_execution_time(order_type, duration)
                
                # Audit log successful execution
                self.monitoring.audit_trading_action('ORDER_EXECUTED', {}
                    'order_id': order_id,
                    'correlation_id': correlation_id,
                    'execution_time': duration,
                    'status': 'success'
                })
                
            except Exception as e:
                # Record failed order
                self.monitoring.metrics.record_order(order_type, side, 'failed')
                
                # Audit log failure
                self.monitoring.audit_trading_action('ORDER_FAILED', {}
                    'order_id': order_id,
                    'correlation_id': correlation_id,
                    'error': str(e),
                    'error_type': type(e).__name__
                })
                raise
    
    def monitor_portfolio_update(self, portfolio_value: float, positions: Dict[str, int]):
        """Monitor portfolio updates"""
        with self.monitoring.track_request('portfolio_update'):
            # Update portfolio metrics
            self.monitoring.metrics.update_portfolio_value(portfolio_value)
            
            # Update position counts by asset type
            stock_count = sum(1 for symbol in positions.keys() if not symbol.endswith('_OPTION')
            option_count = sum(1 for symbol in positions.keys() if symbol.endswith('_OPTION')
            
            self.monitoring.metrics.update_active_positions('stock', stock_count)
            self.monitoring.metrics.update_active_positions('option', option_count)
            
            # Log portfolio state
            self.logger.info("Portfolio updated",)
                           portfolio_value=portfolio_value,
                           total_positions=len(positions),
                           stock_positions=stock_count,
                           option_positions=option_count)
    
    def monitor_model_prediction(self, model_name: str, prediction_type: str,)
                               confidence: float, features: Dict):
        """Monitor ML model predictions"""
        with self.monitoring.track_request('model_prediction',)
                                         model=model_name,
                                         prediction_type=prediction_type):
            # Record prediction
            self.monitoring.metrics.record_model_prediction(model_name, prediction_type)
            
            # Log prediction details
            self.logger.info("Model prediction made",)
                           model=model_name,
                           prediction_type=prediction_type,
                           confidence=confidence,
                           feature_count=len(features)
    
    def monitor_backtest(self, strategy: str, start_date: str, end_date: str,)
                        results: Dict[str, float]):
        """Monitor backtest execution"""
        with self.monitoring.track_request('backtest',)
                                         strategy=strategy,
                                         start_date=start_date,
                                         end_date=end_date):
            # Record backtest metrics
            self.monitoring.metrics.record_backtest_performance(strategy, results)
            
            # Audit log backtest results
            self.monitoring.audit_trading_action('BACKTEST_COMPLETED', {}
                'strategy': strategy,
                'date_range': f"{start_date} to {end_date}",
                'results': results
            })

# Singleton instance for easy access
_monitoring_instance = None

def get_monitoring_system() -> MonitoringSystem:
    """Get or create the monitoring system singleton"""
    global _monitoring_instance
    if _monitoring_instance is None:
        _monitoring_instance = MonitoringSystem()
        _monitoring_instance.start_monitoring()
    return _monitoring_instance

def get_trading_monitor() -> TradingSystemMonitor:
    """Get or create the trading system monitor"""
    monitoring = get_monitoring_system()
    return TradingSystemMonitor(monitoring)

# Example usage and integration points
if __name__ == "__main__":
    # Initialize monitoring
    monitoring = get_monitoring_system()
    trading_monitor = get_trading_monitor()
    
    # Example: Monitor an order execution
    try:
        with trading_monitor.monitor_order_execution('market', 'AAPL', 'buy', 100) as order_id:
            print(f"Executing order {order_id}")
            # Simulate order execution
            time.sleep(0.5)
            print("Order executed successfully")
    except Exception as e:
        print(f"Order failed: {e}")
    
    # Example: Update portfolio
    trading_monitor.monitor_portfolio_update(150000.50, {'AAPL': 100, 'GOOGL': 50})
    
    # Example: Model prediction
    trading_monitor.monitor_model_prediction()
        'momentum_predictor',
        'buy_signal',
        confidence=0.85,
        features={'rsi': 65, 'macd': 0.5}
    )
    
    # Example: Backtest results
    trading_monitor.monitor_backtest()
        'mean_reversion',
        '2023-01-01',
        '2023-12-31',
        {'total_return': 0.15, 'sharpe_ratio': 1.2, 'max_drawdown': -0.08}
    )
    
    # Keep running for monitoring
    print("\nMonitoring system is running. Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        monitoring.stop_monitoring()
        print("\nMonitoring stopped.")