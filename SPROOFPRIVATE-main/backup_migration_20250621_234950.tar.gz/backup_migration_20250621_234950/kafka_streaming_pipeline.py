#!/usr/bin/env python3
from error_handler import ErrorCategory
"""
Kafka Streaming Pipeline for Real-Time Options Data
==================================================
High-performance streaming data pipeline using Kafka for ingesting,
processing, and distributing options market data at scale.
"""

import asyncio
import json
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Union, Set
from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque
import logging
import msgpack
import pickle
import zlib
import struct
from enum import Enum, auto

from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
from aiokafka.admin import AIOKafkaAdminClient, NewTopic
from kafka.errors import KafkaError
import confluent_kafka
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.serialization import StringSerializer, StringDeserializer
from confluent_kafka.schema_registry.avro import AvroSerializer, AvroDeserializer
import avro.schema

# Internal imports
from unified_logging import get_logger
from unified_error_handling import handle_errors, ErrorCategory, ErrorSeverity
from event_driven_architecture import Event, EventType

logger = get_logger(__name__)


class StreamType(Enum):
    """Types of data streams"""
    MARKET_DATA = "market_data"
    OPTIONS_CHAIN = "options_chain"
    ORDER_BOOK = "order_book"
    TRADES = "trades"
    SIGNALS = "signals"
    FEATURES = "features"
    PREDICTIONS = "predictions"
    EXECUTIONS = "executions"
    RISK_METRICS = "risk_metrics"
    ALERTS = "alerts"


class CompressionType(Enum):
    """Compression algorithms for data"""
    NONE = "none"
    GZIP = "gzip"
    SNAPPY = "snappy"
    LZ4 = "lz4"
    ZSTD = "zstd"


@dataclass
class StreamMessage:
    """Generic stream message wrapper"""
    message_id: str
    stream_type: StreamType
    timestamp: datetime
    key: Optional[str] = None
    
    # Payload
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Delivery
    partition_key: Optional[str] = None
    compression: CompressionType = CompressionType.SNAPPY
    priority: int = 0
    
    def to_bytes(self) -> bytes:
        """Serialize message to bytes"""
        # Convert to dict
        msg_dict = {}
            'message_id': self.message_id,
            'stream_type': self.stream_type.value,
            'timestamp': self.timestamp.isoformat(),
            'key': self.key,
            'data': self.data,
            'metadata': self.metadata,
            'partition_key': self.partition_key,
            'compression': self.compression.value,
            'priority': self.priority
        }
        
        # Serialize
        serialized = msgpack.packb(msg_dict)
        
        # Compress if needed
        if self.compression == CompressionType.GZIP:
            serialized = zlib.compress(serialized)
        elif self.compression == CompressionType.ZSTD:
            import zstandard
            cctx = zstandard.ZstdCompressor()
            serialized = cctx.compress(serialized)
        
        return serialized
    
    @classmethod
    def from_bytes(cls, data: bytes, compression: CompressionType = CompressionType.SNAPPY) -> 'StreamMessage':
        """Deserialize message from bytes"""
        # Decompress if needed
        if compression == CompressionType.GZIP:
            data = zlib.decompress(data)
        elif compression == CompressionType.ZSTD:
            import zstandard
            dctx = zstandard.ZstdDecompressor()
            data = dctx.decompress(data)
        
        # Deserialize
        msg_dict = msgpack.unpackb(data)
        
        # Convert back to StreamMessage
        return cls()
            message_id=msg_dict['message_id'],
            stream_type=StreamType(msg_dict['stream_type']),
            timestamp=datetime.fromisoformat(msg_dict['timestamp']),
            key=msg_dict.get('key'),
            data=msg_dict.get('data', {}),
            metadata=msg_dict.get('metadata', {}),
            partition_key=msg_dict.get('partition_key'),
            compression=CompressionType(msg_dict.get('compression', 'snappy')),
            priority=msg_dict.get('priority', 0)
        )


@dataclass
class KafkaConfig:
    """Kafka cluster configuration"""
    bootstrap_servers: str = "localhost:9092"
    
    # Topics
    topic_prefix: str = "trading"
    num_partitions: int = 12
    replication_factor: int = 3
    
    # Producer settings
    producer_batch_size: int = 16384
    producer_linger_ms: int = 5
    producer_compression: str = "snappy"
    producer_acks: str = "1"  # 0=none, 1=leader, all=all replicas
    
    # Consumer settings
    consumer_group_prefix: str = "options-trading"
    consumer_auto_offset_reset: str = "latest"
    consumer_max_poll_records: int = 500
    consumer_fetch_min_bytes: int = 1024
    
    # Schema Registry
    schema_registry_url: Optional[str] = None
    use_avro: bool = False
    
    # Security
    security_protocol: str = "PLAINTEXT"  # PLAINTEXT, SSL, SASL_PLAINTEXT, SASL_SSL
    sasl_mechanism: Optional[str] = None
    sasl_username: Optional[str] = None
    sasl_password: Optional[str] = None


class KafkaStreamingPipeline:
    """Main Kafka streaming pipeline for options data"""
    
    def __init__(self, config: KafkaConfig):
        self.config = config
        
        # Producers and consumers
        self.producers: Dict[StreamType, AIOKafkaProducer] = {}
        self.consumers: Dict[str, AIOKafkaConsumer] = {}
        
        # Admin client
        self.admin_client: Optional[AIOKafkaAdminClient] = None
        
        # Schema registry (if using Avro)
        self.schema_registry: Optional[SchemaRegistryClient] = None
        self.schemas: Dict[StreamType, Any] = {}
        
        # Stream processors
        self.stream_processors: Dict[StreamType, List[Callable]] = defaultdict(list)
        
        # Metrics
        self.metrics = StreamMetrics()
        
        # State
        self._running = False
        self._tasks = []
        
        logger.info(f"Kafka Streaming Pipeline initialized with {config.bootstrap_servers}")
    
    async def start(self):
        """Start the streaming pipeline"""
        try:
            self._running = True
            
            # Initialize admin client
            await self._init_admin_client()
            
            # Create topics
            await self._create_topics()
            
            # Initialize schema registry if needed
            if self.config.use_avro and self.config.schema_registry_url:
                self._init_schema_registry()
            
            # Start metrics reporter
            self._tasks.append()
                asyncio.create_task(self._report_metrics())
            )
            
            logger.info("Kafka Streaming Pipeline started")
            
        except Exception as e:
            logger.error(f"Failed to start Kafka pipeline: {e}")
            raise
    
    async def stop(self):
        """Stop the streaming pipeline"""
        self._running = False
        
        # Stop all producers
        for producer in self.producers.values():
            await producer.stop()
        
        # Stop all consumers
        for consumer in self.consumers.values():
            await consumer.stop()
        
        # Close admin client
        if self.admin_client:
            await self.admin_client.close()
        
        # Cancel tasks
        for task in self._tasks:
            task.cancel()
        
        await asyncio.gather(*self._tasks, return_exceptions=True)
        
        logger.info("Kafka Streaming Pipeline stopped")
    
    async def _init_admin_client(self):
        """Initialize Kafka admin client"""
        self.admin_client = AIOKafkaAdminClient()
            bootstrap_servers=self.config.bootstrap_servers,
            security_protocol=self.config.security_protocol,
            sasl_mechanism=self.config.sasl_mechanism,
            sasl_plain_username=self.config.sasl_username,
            sasl_plain_password=self.config.sasl_password
        )
        await self.admin_client.start()
    
    async def _create_topics(self):
        """Create required Kafka topics"""
        topics_to_create = []
        
        for stream_type in StreamType:
            topic_name = f"{self.config.topic_prefix}.{stream_type.value}"
            
            # Check if topic exists
            existing_topics = await self.admin_client.list_topics()
            
            if topic_name not in existing_topics:
                topic = NewTopic()
                    name=topic_name,
                    num_partitions=self.config.num_partitions,
                    replication_factor=self.config.replication_factor,
                    topic_configs={}
                        'compression.type': self.config.producer_compression,
                        'retention.ms': str(7 * 24 * 60 * 60 * 1000),  # 7 days
                        'segment.ms': str(60 * 60 * 1000),  # 1 hour
                        'min.insync.replicas': '2'
                    }
                )
                topics_to_create.append(topic)
        
        if topics_to_create:
            try:
                await self.admin_client.create_topics(topics_to_create)
                logger.info(f"Created {len(topics_to_create)} Kafka topics")
            except Exception as e:
                logger.warning(f"Some topics may already exist: {e}")
    
    def _init_schema_registry(self):
        """Initialize Avro schema registry"""
        self.schema_registry = SchemaRegistryClient({)
            'url': self.config.schema_registry_url
        })
        
        # Register schemas for each stream type
        self._register_schemas()
    
    def _register_schemas(self):
        """Register Avro schemas for different stream types"""
        # Market data schema
        market_data_schema = {}
            "type": "record",
            "name": "MarketData",
            "fields": []
                {"name": "symbol", "type": "string"},
                {"name": "timestamp", "type": "long"},
                {"name": "price", "type": "double"},
                {"name": "volume", "type": "long"},
                {"name": "bid", "type": "double"},
                {"name": "ask", "type": "double"},
                {"name": "bid_size", "type": "long"},
                {"name": "ask_size", "type": "long"}
            ]
        }
        self.schemas[StreamType.MARKET_DATA] = avro.schema.parse(json.dumps(market_data_schema))
        
        # Options chain schema
        options_chain_schema = {}
            "type": "record",
            "name": "OptionsChain",
            "fields": []
                {"name": "underlying_symbol", "type": "string"},
                {"name": "timestamp", "type": "long"},
                {"name": "expiration", "type": "string"},
                {"name": "strikes", "type": {"type": "array", "items": "double"}},
                {"name": "call_prices", "type": {"type": "array", "items": "double"}},
                {"name": "put_prices", "type": {"type": "array", "items": "double"}},
                {"name": "call_volumes", "type": {"type": "array", "items": "long"}},
                {"name": "put_volumes", "type": {"type": "array", "items": "long"}},
                {"name": "implied_volatilities", "type": {"type": "array", "items": "double"}}
            ]
        }
        self.schemas[StreamType.OPTIONS_CHAIN] = avro.schema.parse(json.dumps(options_chain_schema))
    
    async def create_producer(self, stream_type: StreamType) -> AIOKafkaProducer:
        """Create a producer for a specific stream type"""
        if stream_type in self.producers:
            return self.producers[stream_type]
        
        producer = AIOKafkaProducer()
            bootstrap_servers=self.config.bootstrap_servers,
            compression_type=self.config.producer_compression,
            batch_size=self.config.producer_batch_size,
            linger_ms=self.config.producer_linger_ms,
            acks=self.config.producer_acks,
            value_serializer=lambda v: v.to_bytes() if isinstance(v, StreamMessage) else v,
            key_serializer=lambda k: k.encode() if k else None,
            security_protocol=self.config.security_protocol,
            sasl_mechanism=self.config.sasl_mechanism,
            sasl_plain_username=self.config.sasl_username,
            sasl_plain_password=self.config.sasl_password
        )
        
        await producer.start()
        self.producers[stream_type] = producer
        
        return producer
    
    async def create_consumer()
        self,
        stream_types: List[StreamType],
        group_id: str,
        process_func: Callable
    ) -> AIOKafkaConsumer:
        """Create a consumer for specific stream types"""
        topics = [f"{self.config.topic_prefix}.{st.value}" for st in stream_types]
        
        consumer = AIOKafkaConsumer()
            *topics,
            bootstrap_servers=self.config.bootstrap_servers,
            group_id=f"{self.config.consumer_group_prefix}-{group_id}",
            auto_offset_reset=self.config.consumer_auto_offset_reset,
            max_poll_records=self.config.consumer_max_poll_records,
            fetch_min_bytes=self.config.consumer_fetch_min_bytes,
            value_deserializer=lambda v: StreamMessage.from_bytes(v) if v else None,
            key_deserializer=lambda k: k.decode() if k else None,
            security_protocol=self.config.security_protocol,
            sasl_mechanism=self.config.sasl_mechanism,
            sasl_plain_username=self.config.sasl_username,
            sasl_plain_password=self.config.sasl_password
        )
        
        await consumer.start()
        self.consumers[group_id] = consumer
        
        # Start processing task
        task = asyncio.create_task()
            self._process_consumer(consumer, process_func)
        )
        self._tasks.append(task)
        
        return consumer
    
    async def _process_consumer(self, consumer: AIOKafkaConsumer, process_func: Callable):
        """Process messages from consumer"""
        try:
            async for msg in consumer:
                if not self._running:
                    break
                
                try:
                    # Deserialize message
                    message = msg.value
                    
                    # Track metrics
                    self.metrics.record_message_received()
                        msg.topic,
                        msg.partition,
                        msg.offset
                    )
                    
                    # Process message
                    start_time = time.time()
                    await process_func(message)
                    
                    # Track processing time
                    processing_time = (time.time() - start_time) * 1000
                    self.metrics.record_processing_time(msg.topic, processing_time)
                    
                except Exception as e:
                    logger.error(f"Error processing message: {e}")
                    self.metrics.record_error(msg.topic)
                    
        except Exception as e:
            logger.error(f"Consumer error: {e}")
    
    @handle_errors("publish", ErrorCategory.DATA, ErrorSeverity.MEDIUM)
    async def publish()
        self,
        stream_type: StreamType,
        data: Dict[str, Any],
        key: Optional[str] = None,
        partition_key: Optional[str] = None
    ):
        """Publish data to a stream"""
        # Get or create producer
        producer = await self.create_producer(stream_type)
        
        # Create message
        message = StreamMessage()
            message_id=f"{stream_type.value}_{int(time.time() * 1000000)}",
            stream_type=stream_type,
            timestamp=datetime.now(),
            key=key,
            data=data,
            partition_key=partition_key or key
        )
        
        # Determine topic
        topic = f"{self.config.topic_prefix}.{stream_type.value}"
        
        # Send message
        try:
            start_time = time.time()
            
            # Calculate partition if key provided
            partition = None
            if partition_key:
                partition = hash(partition_key) % self.config.num_partitions
            
            # Send to Kafka
            result = await producer.send()
                topic,
                value=message,
                key=key,
                partition=partition
            )
            
            # Track metrics
            send_time = (time.time() - start_time) * 1000
            self.metrics.record_message_sent(topic, result.partition, result.offset)
            self.metrics.record_send_time(topic, send_time)
            
            return result
            
        except KafkaError as e:
            logger.error(f"Kafka publish error: {e}")
            self.metrics.record_error(topic)
            raise
    
    def register_processor(self, stream_type: StreamType, processor: Callable):
        """Register a stream processor"""
        self.stream_processors[stream_type].append(processor)
    
    async def _report_metrics(self):
        """Report pipeline metrics"""
        while self._running:
            try:
                metrics = self.metrics.get_summary()
                logger.info(f"Kafka Pipeline Metrics: {json.dumps(metrics)}")
                
                # Check for issues
                if metrics['total_errors'] > 100:
                    logger.warning(f"High error rate detected: {metrics['total_errors']} errors")
                
                if metrics['avg_processing_time_ms'] > 100:
                    logger.warning(f"High processing latency: {metrics['avg_processing_time_ms']:.2f}ms")
                
                await asyncio.sleep(60)  # Report every minute
                
            except Exception as e:
                logger.error(f"Metrics reporting error: {e}")
                await asyncio.sleep(300)


class StreamMetrics:
    """Track streaming pipeline metrics"""
    
    def __init__(self):
        self.messages_sent: Dict[str, int] = defaultdict(int)
        self.messages_received: Dict[str, int] = defaultdict(int)
        self.errors: Dict[str, int] = defaultdict(int)
        self.processing_times: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.send_times: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.last_offsets: Dict[str, Dict[int, int]] = defaultdict(dict)
    
    def record_message_sent(self, topic: str, partition: int, offset: int):
        """Record sent message"""
        self.messages_sent[topic] += 1
        self.last_offsets[topic][partition] = offset
    
    def record_message_received(self, topic: str, partition: int, offset: int):
        """Record received message"""
        self.messages_received[topic] += 1
        self.last_offsets[topic][partition] = offset
    
    def record_error(self, topic: str):
        """Record error"""
        self.errors[topic] += 1
    
    def record_processing_time(self, topic: str, time_ms: float):
        """Record message processing time"""
        self.processing_times[topic].append(time_ms)
    
    def record_send_time(self, topic: str, time_ms: float):
        """Record message send time"""
        self.send_times[topic].append(time_ms)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get metrics summary"""
        total_sent = sum(self.messages_sent.values())
        total_received = sum(self.messages_received.values())
        total_errors = sum(self.errors.values())
        
        # Calculate average times
        all_processing_times = []
        for times in self.processing_times.values():
            all_processing_times.extend(times)
        
        all_send_times = []
        for times in self.send_times.values():
            all_send_times.extend(times)
        
        return {}
            'total_sent': total_sent,
            'total_received': total_received,
            'total_errors': total_errors,
            'error_rate': total_errors / max(total_received, 1),
            'avg_processing_time_ms': np.mean(all_processing_times) if all_processing_times else 0,
            'max_processing_time_ms': max(all_processing_times) if all_processing_times else 0,
            'avg_send_time_ms': np.mean(all_send_times) if all_send_times else 0,
            'topics': {}
                topic: {}
                    'sent': self.messages_sent[topic],
                    'received': self.messages_received[topic],
                    'errors': self.errors[topic],
                    'partitions': len(self.last_offsets[topic])
                }
                for topic in set(list(self.messages_sent.keys()) + list(self.messages_received.keys()))
            }
        }


class StreamProcessor:
    """Base class for stream processors"""
    
    async def process(self, message: StreamMessage) -> Optional[StreamMessage]:
        """Process a stream message"""
        raise NotImplementedError


class MarketDataEnricher(StreamProcessor):
    """Enrich market data with additional features"""
    
    def __init__(self, feature_calculator):
        self.feature_calculator = feature_calculator
        self.cache = {}
    
    async def process(self, message: StreamMessage) -> Optional[StreamMessage]:
        """Enrich market data message"""
        if message.stream_type != StreamType.MARKET_DATA:
            return None
        
        data = message.data
        symbol = data.get('symbol')
        
        # Calculate technical indicators
        if symbol in self.cache:
            self.cache[symbol].append(data)
        else:
            self.cache[symbol] = deque([data], maxlen=100)
        
        # Calculate features if enough data
        if len(self.cache[symbol]) >= 20:
            features = self.feature_calculator.calculate()
                list(self.cache[symbol])
            )
            
            # Create enriched message
            return StreamMessage()
                message_id=f"enriched_{message.message_id}",
                stream_type=StreamType.FEATURES,
                timestamp=datetime.now(),
                key=symbol,
                data={}
                    'symbol': symbol,
                    'original_data': data,
                    'features': features
                },
                partition_key=symbol
            )
        
        return None


class OptionsChainAggregator(StreamProcessor):
    """Aggregate options chain updates"""
    
    def __init__(self, window_seconds: int = 60):
        self.window_seconds = window_seconds
        self.buffers: Dict[str, List[StreamMessage]] = defaultdict(list)
        self.last_aggregate: Dict[str, datetime] = {}
    
    async def process(self, message: StreamMessage) -> Optional[StreamMessage]:
        """Aggregate options chain data"""
        if message.stream_type != StreamType.OPTIONS_CHAIN:
            return None
        
        symbol = message.data.get('underlying_symbol')
        self.buffers[symbol].append(message)
        
        # Check if we should aggregate
        now = datetime.now()
        last_agg = self.last_aggregate.get(symbol, datetime.min)
        
        if (now - last_agg).total_seconds() >= self.window_seconds:
            # Aggregate data
            aggregated = self._aggregate_chains(self.buffers[symbol])
            
            # Clear buffer
            self.buffers[symbol] = []
            self.last_aggregate[symbol] = now
            
            # Create aggregated message
            return StreamMessage()
                message_id=f"agg_{symbol}_{int(time.time() * 1000)}",
                stream_type=StreamType.OPTIONS_CHAIN,
                timestamp=now,
                key=symbol,
                data=aggregated,
                partition_key=symbol
            )
        
        return None
    
    def _aggregate_chains(self, messages: List[StreamMessage]) -> Dict[str, Any]:
        """Aggregate multiple options chain messages"""
        if not messages:
            return {}
        
        # Get latest message as base
        latest = messages[-1].data
        
        # Calculate average implied volatilities
        all_ivs = []
        for msg in messages:
            if 'implied_volatilities' in msg.data:
                all_ivs.extend(msg.data['implied_volatilities'])
        
        avg_iv = np.mean(all_ivs) if all_ivs else 0
        
        # Add aggregated fields
        latest['avg_implied_volatility'] = avg_iv
        latest['update_count'] = len(messages)
        latest['aggregation_window'] = self.window_seconds
        
        return latest


class AlertGenerator(StreamProcessor):
    """Generate alerts from various streams"""
    
    def __init__(self, alert_rules: Dict[str, Callable]):
        self.alert_rules = alert_rules
    
    async def process(self, message: StreamMessage) -> Optional[StreamMessage]:
        """Check message against alert rules"""
        alerts = []
        
        for rule_name, rule_func in self.alert_rules.items():
            try:
                if rule_func(message):
                    alerts.append({)
                        'rule': rule_name,
                        'triggered_by': message.message_id,
                        'data': message.data
                    })
            except Exception as e:
                logger.error(f"Alert rule {rule_name} error: {e}")
        
        if alerts:
            return StreamMessage()
                message_id=f"alert_{int(time.time() * 1000)}",
                stream_type=StreamType.ALERTS,
                timestamp=datetime.now(),
                data={'alerts': alerts},
                priority=1  # High priority
            )
        
        return None


# Stream processing functions
async def process_market_data_stream(pipeline: KafkaStreamingPipeline):
    """Process market data stream"""
    enricher = MarketDataEnricher(None)  # Would pass real feature calculator
    
    async def process_message(message: StreamMessage):
        # Enrich the message
        enriched = await enricher.process(message)
        
        if enriched:
            # Publish enriched data
            await pipeline.publish()
                StreamType.FEATURES,
                enriched.data,
                key=enriched.key
            )
    
    # Create consumer
    await pipeline.create_consumer()
        [StreamType.MARKET_DATA],
        "market-enricher",
        process_message
    )


async def process_options_chain_stream(pipeline: KafkaStreamingPipeline):
    """Process options chain stream"""
    aggregator = OptionsChainAggregator(window_seconds=60)
    
    async def process_message(message: StreamMessage):
        # Aggregate chains
        aggregated = await aggregator.process(message)
        
        if aggregated:
            # Publish aggregated data
            await pipeline.publish()
                StreamType.OPTIONS_CHAIN,
                aggregated.data,
                key=aggregated.key
            )
    
    # Create consumer
    await pipeline.create_consumer()
        [StreamType.OPTIONS_CHAIN],
        "chain-aggregator",
        process_message
    )


async def process_alert_stream(pipeline: KafkaStreamingPipeline):
    """Process multiple streams for alerts"""
    
    # Define alert rules
    alert_rules = {}
        'high_volatility': lambda msg: ()
            msg.stream_type == StreamType.OPTIONS_CHAIN and
            msg.data.get('avg_implied_volatility', 0) > 0.5
        ),
        'large_trade': lambda msg: ()
            msg.stream_type == StreamType.TRADES and
            msg.data.get('volume', 0) > 10000
        ),
        'risk_breach': lambda msg: ()
            msg.stream_type == StreamType.RISK_METRICS and
            msg.data.get('var_utilization', 0) > 0.9
        )
    }
    
    alert_generator = AlertGenerator(alert_rules)
    
    async def process_message(message: StreamMessage):
        # Check for alerts
        alert = await alert_generator.process(message)
        
        if alert:
            # Publish alert
            await pipeline.publish()
                StreamType.ALERTS,
                alert.data,
                key='alert'
            )
            
            # Log alert
            logger.warning(f"Alert generated: {alert.data}")
    
    # Create consumer for multiple streams
    await pipeline.create_consumer()
        [StreamType.OPTIONS_CHAIN, StreamType.TRADES, StreamType.RISK_METRICS],
        "alert-monitor",
        process_message
    )


# Integration with Event-Driven Architecture
class EventToKafkaBridge:
    """Bridge between Event Bus and Kafka Pipeline"""
    
    def __init__(self, event_bus, kafka_pipeline: KafkaStreamingPipeline):
        self.event_bus = event_bus
        self.kafka_pipeline = kafka_pipeline
        
        # Event to stream type mapping
        self.event_mapping = {}
            EventType.MARKET_DATA_UPDATE: StreamType.MARKET_DATA,
            EventType.OPTIONS_CHAIN_UPDATE: StreamType.OPTIONS_CHAIN,
            EventType.ORDER_BOOK_UPDATE: StreamType.ORDER_BOOK,
            EventType.TRADE_EXECUTED: StreamType.TRADES,
            EventType.SIGNAL_GENERATED: StreamType.SIGNALS,
            EventType.FEATURES_COMPUTED: StreamType.FEATURES,
            EventType.MODEL_PREDICTION: StreamType.PREDICTIONS,
            EventType.ORDER_FILLED: StreamType.EXECUTIONS,
            EventType.VAR_UPDATE: StreamType.RISK_METRICS,
            EventType.ALERT_TRIGGERED: StreamType.ALERTS
        }
    
    async def start(self):
        """Start the bridge"""
        # Subscribe to all mapped events
        for event_type in self.event_mapping:
            self.event_bus.subscribe_async()
                event_type,
                self._handle_event
            )
        
        # Create Kafka consumer for external events
        await self.kafka_pipeline.create_consumer()
            list(StreamType),
            "event-bridge",
            self._handle_kafka_message
        )
    
    async def _handle_event(self, event: Event):
        """Forward event to Kafka"""
        if event.event_type in self.event_mapping:
            stream_type = self.event_mapping[event.event_type]
            
            # Publish to Kafka
            await self.kafka_pipeline.publish()
                stream_type,
                event.data,
                key=event.data.get('symbol')
            )
    
    async def _handle_kafka_message(self, message: StreamMessage):
        """Forward Kafka message to Event Bus"""
        # Map stream type back to event type
        reverse_mapping = {v: k for k, v in self.event_mapping.items()}
        
        if message.stream_type in reverse_mapping:
            event_type = reverse_mapping[message.stream_type]
            
            # Create event
            event = Event()
                event_type=event_type,
                source='kafka',
                data=message.data,
                metadata={'kafka_message_id': message.message_id}
            )
            
            # Publish to event bus
            await self.event_bus.publish(event)


# Example usage and demonstration
if __name__ == "__main__":
    import asyncio
    
    async def demo_kafka_pipeline():
        """Demonstrate Kafka streaming pipeline"""
        
        # Configuration
        config = KafkaConfig()
            bootstrap_servers="localhost:9092",
            topic_prefix="options-trading",
            num_partitions=12,
            replication_factor=1,  # For local testing
            producer_compression="snappy",
            consumer_group_prefix="demo"
        )
        
        # Create pipeline
        pipeline = KafkaStreamingPipeline(config)
        
        try:
            # Start pipeline
            await pipeline.start()
            
            print("Kafka Streaming Pipeline Demo")
            print("=" * 50)
            
            # Start stream processors
            asyncio.create_task(process_market_data_stream(pipeline))
            asyncio.create_task(process_options_chain_stream(pipeline))
            asyncio.create_task(process_alert_stream(pipeline))
            
            # Simulate market data
            symbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'SPY']
            
            print("\nPublishing market data...")
            for i in range(10):
                symbol = np.random.choice(symbols)
                
                # Market data
                await pipeline.publish()
                    StreamType.MARKET_DATA,
                    {}
                        'symbol': symbol,
                        'price': 100 + np.random.randn() * 5,
                        'volume': int(np.random.exponential(1000)),
                        'bid': 99.5 + np.random.randn() * 0.5,
                        'ask': 100.5 + np.random.randn() * 0.5,
                        'bid_size': int(np.random.exponential(100)),
                        'ask_size': int(np.random.exponential(100))
                    },
                    key=symbol
                )
                
                # Options chain
                if i % 3 == 0:
                    strikes = np.arange(90, 110, 2.5)
                    await pipeline.publish()
                        StreamType.OPTIONS_CHAIN,
                        {}
                            'underlying_symbol': symbol,
                            'expiration': '2024-02-16',
                            'strikes': strikes.tolist(),
                            'call_prices': (strikes * 0.1 + np.random.randn(len(strikes)) * 0.5).tolist(),
                            'put_prices': ((110 - strikes) * 0.1 + np.random.randn(len(strikes)) * 0.5).tolist(),
                            'implied_volatilities': (0.2 + np.random.randn(len(strikes)) * 0.05).tolist()
                        },
                        key=symbol
                    )
                
                # Trade
                if i % 2 == 0:
                    await pipeline.publish()
                        StreamType.TRADES,
                        {}
                            'symbol': symbol,
                            'price': 100 + np.random.randn() * 2,
                            'volume': int(np.random.exponential(500)),
                            'side': np.random.choice(['buy', 'sell']),
                            'timestamp': datetime.now().isoformat()
                        },
                        key=symbol
                    )
                
                await asyncio.sleep(0.1)
            
            # Simulate risk metrics
            print("\nPublishing risk metrics...")
            await pipeline.publish()
                StreamType.RISK_METRICS,
                {}
                    'portfolio_var': 50000,
                    'var_limit': 100000,
                    'var_utilization': 0.5,
                    'positions': 10,
                    'total_exposure': 1000000
                },
                key='portfolio'
            )
            
            # High risk scenario
            await pipeline.publish()
                StreamType.RISK_METRICS,
                {}
                    'portfolio_var': 95000,
                    'var_limit': 100000,
                    'var_utilization': 0.95,
                    'positions': 15,
                    'total_exposure': 1500000
                },
                key='portfolio'
            )
            
            # Wait for processing
            await asyncio.sleep(3)
            
            # Get metrics
            print("\nPipeline Metrics:")
            metrics = pipeline.metrics.get_summary()
            print(f"  Total Sent: {metrics['total_sent']}")
            print(f"  Total Received: {metrics['total_received']}")
            print(f"  Total Errors: {metrics['total_errors']}")
            print(f"  Avg Processing Time: {metrics['avg_processing_time_ms']:.2f}ms")
            
            print("\nTopic Statistics:")
            for topic, stats in metrics['topics'].items():
                print(f"  {topic}:")
                print(f"    Sent: {stats['sent']}")
                print(f"    Received: {stats['received']}")
                print(f"    Errors: {stats['errors']}")
            
            # Demonstrate message consumption
            print("\nConsuming messages...")
            
            # Create a simple consumer
            async def print_messages(message: StreamMessage):
                print(f"Received {message.stream_type.value}: {message.key} - {list(message.data.keys())}")
            
            await pipeline.create_consumer()
                [StreamType.FEATURES, StreamType.ALERTS],
                "demo-printer",
                print_messages
            )
            
            # Wait for more messages
            await asyncio.sleep(2)
            
        except Exception as e:
            print(f"\nError: {e}")
            import traceback
            traceback.print_exc()
            
        finally:
            # Stop pipeline
            await pipeline.stop()
            print("\nPipeline stopped")
    
    # Note: This demo requires a running Kafka instance
    print("Note: This demo requires Kafka to be running on localhost:9092")
    print("You can start Kafka with:")
    print("  docker run -p 9092:9092 apache/kafka:latest")
    print()
    
    # Uncomment to run if Kafka is available
    # asyncio.run(demo_kafka_pipeline())
    
    # Alternative: Show configuration and structure
    print("Kafka Streaming Pipeline Structure:")
    print("\nStream Types:")
    for stream_type in StreamType:
        print(f"  - {stream_type.value}")
    
    print("\nKey Features:")
    print("  - High-throughput message streaming")
    print("  - Automatic topic creation and management")
    print("  - Built-in compression (Snappy, GZIP, LZ4, ZSTD)")
    print("  - Stream processing with aggregation")
    print("  - Alert generation from multiple streams")
    print("  - Integration with Event-Driven Architecture")
    print("  - Comprehensive metrics and monitoring")
    print("  - Schema registry support (Avro)")
    print("  - Security support (SSL, SASL)")
    
    print("\nExample Usage:")
    print("""\n# Initialize pipeline)
config = KafkaConfig()
    bootstrap_servers="kafka-broker1:9092,kafka-broker2:9092",
    topic_prefix="prod-options",
    num_partitions=24,
    replication_factor=3
)
pipeline = KafkaStreamingPipeline(config)
await pipeline.start()

# Publish market data
await pipeline.publish()
    StreamType.MARKET_DATA,
    {'symbol': 'AAPL', 'price': 150.25, 'volume': 1000000},
    key='AAPL'
)

# Create consumer
async def process_data(message):
    print(f"Processing {message.stream_type}: {message.data}")
    
await pipeline.create_consumer()
    [StreamType.MARKET_DATA],
    "my-processor",
    process_data
)
    """)