#!/usr/bin/env python3
"""
Verify Post-2009 Data Content
Downloads and examines the actual content of files that claim to contain data from 2010+
"""

import os
import sys
import pandas as pd
from datetime import datetime
import logging
from minio import Minio

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# MinIO Configuration
MINIO_CONFIG = {}
    'endpoint': 'uschristmas.us',
    'access_key': os.getenv('MINIO_ACCESS_KEY'),
    'secret_key': os.getenv('MINIO_SECRET_KEY'),
    'bucket_name': 'stockdb',
    'secure': True
}

class DataVerifier:
    """Verify the actual content of files claiming to have post-2009 data"""
    
    def __init__(self):
        self.client = Minio()
            MINIO_CONFIG['endpoint'],
            access_key=MINIO_CONFIG['access_key'],
            secret_key=MINIO_CONFIG['secret_key'],
            secure=MINIO_CONFIG['secure']
        )
        self.bucket_name = MINIO_CONFIG['bucket_name']
    
    def download_and_examine_file(self, object_name: str) -> dict:
        """Download and examine a specific file"""
        local_filename = f"/tmp/{os.path.basename(object_name)}"
        
        try:
            # Download file
            self.client.fget_object(self.bucket_name, object_name, local_filename)
            logger.info(f"Downloaded {object_name}")
            
            # Examine content based on file type
            if object_name.endswith('.csv'):
                return self._examine_csv(local_filename, object_name)
            elif object_name.endswith('.md'):
                return self._examine_text(local_filename, object_name)
            else:
                return {'filename': object_name, 'type': 'unknown', 'error': 'Unsupported file type'}
                
        except Exception as e:
            logger.error(f"Error examining {object_name}: {e}")
            return {'filename': object_name, 'type': 'error', 'error': str(e)}
        finally:
            # Cleanup
            if os.path.exists(local_filename):
                os.remove(local_filename)
    
    def _examine_csv(self, filename: str, object_name: str) -> dict:
        """Examine CSV file content"""
        try:
            df = pd.read_csv(filename)
            
            # Look for date columns
            date_columns = []
            for col in df.columns:
                if 'date' in col.lower() or 'time' in col.lower():
                    date_columns.append(col)
            
            # Try to parse dates from various columns
            date_ranges = {}
            
            for col in date_columns:
                try:
                    dates = pd.to_datetime(df[col], errors='coerce').dropna()
                    if len(dates) > 0:
                        date_ranges[col] = {}
                            'min_date': dates.min().strftime('%Y-%m-%d'),
                            'max_date': dates.max().strftime('%Y-%m-%d'),
                            'unique_dates': len(dates.unique()
                        }
                except:
                    continue
            
            # Check for year patterns in data
            year_patterns = set()
            for col in df.columns:
                for value in df[col].astype(str).head(100):  # Sample first 100 rows
                    for year in range(2010, 2025):
                        if str(year) in str(value):
                            year_patterns.add(year)
            
            return {}
                'filename': object_name,
                'type': 'csv',
                'shape': df.shape,
                'columns': list(df.columns),
                'date_columns': date_columns,
                'date_ranges': date_ranges,
                'years_found_in_data': sorted(list(year_patterns),
                'sample_data': df.head(3).to_dict() if len(df) > 0 else {},
                'data_summary': {}
                    'has_post_2009_dates': any()
                        any(year >= 2010 for year in year_patterns) 
                        for year_patterns in [year_patterns]
                    ),
                    'actual_date_range': date_ranges
                }
            }
            
        except Exception as e:
            return {}
                'filename': object_name,
                'type': 'csv_error',
                'error': str(e)
            }
    
    def _examine_text(self, filename: str, object_name: str) -> dict:
        """Examine text/markdown file content"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Look for year patterns
            year_patterns = set()
            for year in range(2010, 2025):
                if str(year) in content:
                    year_patterns.add(year)
            
            return {}
                'filename': object_name,
                'type': 'text',
                'size': len(content),
                'years_mentioned': sorted(list(year_patterns),
                'content_preview': content[:500] if content else "Empty file",
                'has_post_2009_mentions': len(year_patterns) > 0
            }
            
        except Exception as e:
            return {}
                'filename': object_name,
                'type': 'text_error',
                'error': str(e)
            }

def main():
    """Main execution function"""
    print("Verifying Post-2009 Data Content")
    print("=" * 40)
    
    verifier = DataVerifier()
    
    # Files to examine based on our previous search
    files_to_examine = []
        # Financial data files
        'financials/2010_to_2014/financial_data_2010_to_2014.csv',
        'financials/2015_to_2019/financial_data_2015_to_2019.csv',
        'financials/2020_to_2024/financial_data_2020_to_2024.csv',
        
        # Sample files from 2022
        'samples/2022-08-24/2022-08-24options(Partial).csv',
        'samples/2022-08-24/2022-08-24stocks.csv',
        
        # Documentation files
        'financials/2010_to_2014/data_processing_documentation.md',
        'financials/2015_to_2019/data_processing_documentation.md',
        'financials/2020_to_2024/data_processing_documentation.md'
    ]
    
    results = []
    
    for file_path in files_to_examine:
        print(f"\nExamining: {file_path}")
        result = verifier.download_and_examine_file(file_path)
        results.append(result)
        
        # Print summary
        if result['type'] == 'csv':
            print(f"  Type: CSV")
            print(f"  Shape: {result['shape']}")
            print(f"  Date ranges: {result['date_ranges']}")
            print(f"  Years in data: {result['years_found_in_data']}")
            print(f"  Has post-2009 data: {result['data_summary']['has_post_2009_dates']}")
        elif result['type'] == 'text':
            print(f"  Type: Text/Markdown")
            print(f"  Years mentioned: {result['years_mentioned']}")
            print(f"  Has post-2009 mentions: {result['has_post_2009_mentions']}")
        elif 'error' in result:
            print(f"  Error: {result['error']}")
    
    # Generate summary
    print("\n" + "=" * 60)
    print("VERIFICATION SUMMARY")
    print("=" * 60)
    
    csv_files_with_data = []
    csv_files_without_data = []
    
    for result in results:
        if result['type'] == 'csv':
            if result['data_summary']['has_post_2009_dates'] or result['years_found_in_data']:
                csv_files_with_data.append(result)
            else:
                csv_files_without_data.append(result)
    
    print(f"\nCSV files with actual post-2009 data: {len(csv_files_with_data)}")
    for result in csv_files_with_data:
        print(f"  - {result['filename']}")
        print(f"    Years found: {result['years_found_in_data']}")
        if result['date_ranges']:
            for col, date_info in result['date_ranges'].items():
                print(f"    Date range in {col}: {date_info['min_date']} to {date_info['max_date']}")
    
    print(f"\nCSV files without actual post-2009 data: {len(csv_files_without_data)}")
    for result in csv_files_without_data:
        print(f"  - {result['filename']}")
    
    # Overall conclusion
    has_actual_post_2009_options_data = any()
        'options' in result['filename'].lower() and result['type'] == 'csv' and 
        (result['data_summary']['has_post_2009_dates'] or result['years_found_in_data'])
        for result in results
    )
    
    has_actual_post_2009_stock_data = any()
        'stock' in result['filename'].lower() and result['type'] == 'csv' and 
        (result['data_summary']['has_post_2009_dates'] or result['years_found_in_data'])
        for result in results
    )
    
    print(f"\n" + "=" * 60)
    print("FINAL CONCLUSION:")
    print("=" * 60)
    print(f"Actual options data beyond 2009: {'YES' if has_actual_post_2009_options_data else 'NO'}")
    print(f"Actual stock data beyond 2009: {'YES' if has_actual_post_2009_stock_data else 'NO'}")
    print(f"Financial reports data beyond 2009: {'YES' if csv_files_with_data else 'NO'}")

if __name__ == "__main__":
    main()