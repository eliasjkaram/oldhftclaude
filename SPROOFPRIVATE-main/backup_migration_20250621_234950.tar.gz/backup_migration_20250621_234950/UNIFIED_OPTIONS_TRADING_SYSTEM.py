#!/usr/bin/env python3
"""
UNIFIED OPTIONS TRADING SYSTEM
==============================
Combines working stock trading with options and spreads execution.
This system integrates both stock and options trading capabilities.
"""

import os
import sys
import time
import json
import logging
from datetime import datetime, timedelta
import pytz
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np
from dataclasses import dataclass
import asyncio
import threading

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import ()
    MarketOrderRequest, LimitOrderRequest, GetOrdersRequest,
    GetOptionContractsRequest, GetPositionsRequest
)
from alpaca.trading.enums import ()
    OrderSide, TimeInForce, AssetClass, OrderType, OrderClass,
    ContractType, QueryOrderStatus
)
from alpaca.data.historical import StockHistoricalDataClient, OptionHistoricalDataClient
from alpaca.data.requests import ()
    StockLatestQuoteRequest, OptionChainRequest, 
    OptionLatestQuoteRequest, StockBarsRequest
)
from alpaca.data.timeframe import TimeFrame
from alpaca.common.exceptions import APIError

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('unified_trading_system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class OptionContract:
    """Represents an option contract"""
    symbol: str
    underlying: str
    strike: float
    expiration: datetime
    contract_type: str  # 'call' or 'put'
    contract_id: str
    bid: float = 0
    ask: float = 0
    last: float = 0
    volume: int = 0
    open_interest: int = 0

class UnifiedTradingSystem:
    """Unified system for stocks and options trading"""
    
    def __init__(self):
        # API credentials
        self.api_key = os.getenv('ALPACA_API_KEY', 'PKEP9PIBDKOSUGHHY44Z')
        self.api_secret = os.getenv('ALPACA_API_SECRET', 'VtNWykIafQe7VfjPWKUVRu8RXOnpgBYgndyFCwTZ')
        
        # Initialize clients
        self.trading_client = TradingClient(self.api_key, self.api_secret, paper=True)
        self.stock_data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        
        # Try to initialize options client
        try:
            self.options_data_client = OptionHistoricalDataClient(self.api_key, self.api_secret)
            self.options_enabled = True
            logger.info("✅ Options data client initialized")
        except Exception as e:
            logger.warning(f"⚠️  Options data client failed: {e}")
            self.options_enabled = False
        
        # Test connection
        try:
            account = self.trading_client.get_account()
            logger.info(f"✅ Connected to Alpaca Paper Trading")
            logger.info(f"   Account: {account.account_number}")
            logger.info(f"   Cash: ${float(account.cash):,.2f}")
            
            # Check options eligibility
            if hasattr(account, 'options_trading_level'):
                if account.options_trading_level and account.options_trading_level > 0:
                    logger.info(f"✅ Options trading level: {account.options_trading_level}")
                    self.options_approved = True
                else:
                    logger.warning("⚠️  Account not approved for options trading")
                    self.options_approved = False
            else:
                logger.warning("⚠️  Cannot determine options trading level")
                self.options_approved = False
                
        except Exception as e:
            logger.error(f"❌ Connection failed: {e}")
            sys.exit(1)
        
        # Trading settings
        self.stock_trade_amount = 1000  # $1000 per stock trade
        self.options_trade_amount = 500  # $500 per options trade
        self.max_positions = 20
        self.max_spreads = 5
        
        # Track trades
        self.stock_trades = []
        self.options_trades = []
        self.active_spreads = {}
        
        # Symbols for different asset classes
        self.stock_symbols = []
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA',
            'JPM', 'BAC', 'WMT', 'DIS', 'V', 'MA', 'PG', 'JNJ'
        ]
        
        # Options symbols (high liquidity)
        self.option_symbols = []
            'SPY', 'QQQ', 'AAPL', 'MSFT', 'TSLA', 'NVDA', 'META'
        ]
        
        # Timezone for market hours
        self.et_tz = pytz.timezone('US/Eastern')
    
    def is_market_open(self) -> bool:
        """Check if US market is open"""
        try:
            clock = self.trading_client.get_clock()
            return clock.is_open
        except:
            # Fallback to manual check
            now_et = datetime.now(self.et_tz)
            is_weekday = now_et.weekday() < 5
            market_open = now_et.replace(hour=9, minute=30, second=0, microsecond=0)
            market_close = now_et.replace(hour=16, minute=0, second=0, microsecond=0)
            return is_weekday and market_open <= now_et <= market_close
    
    def get_stock_quote(self, symbol: str) -> Optional[Dict]:
        """Get current stock quote"""
        try:
            request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            quotes = self.stock_data_client.get_stock_latest_quote(request)
            
            if symbol in quotes:
                quote = quotes[symbol]
                return {}
                    'symbol': symbol,
                    'bid': float(quote.bid_price) if quote.bid_price else 0,
                    'ask': float(quote.ask_price) if quote.ask_price else 0,
                    'price': (float(quote.bid_price) + float(quote.ask_price)) / 2 
                            if quote.bid_price and quote.ask_price else 0
                }
        except Exception as e:
            logger.error(f"Failed to get quote for {symbol}: {e}")
        return None
    
    def execute_stock_trade(self, symbol: str, side: str = 'buy') -> bool:
        """Execute a simple stock trade"""
        try:
            # Get current price
            quote = self.get_stock_quote(symbol)
            if not quote or quote['price'] <= 0:
                return False
            
            price = quote['price']
            
            # Calculate quantity
            quantity = int(self.stock_trade_amount / price)
            if quantity < 1:
                return False
            
            # Create order
            order_data = MarketOrderRequest()
                symbol=symbol,
                qty=quantity,
                side=OrderSide.BUY if side == 'buy' else OrderSide.SELL,
                time_in_force=TimeInForce.DAY
            )
            
            # Submit order
            order = self.trading_client.submit_order(order_data)
            
            logger.info(f"✅ STOCK ORDER: {side.upper()} {quantity} {symbol} @ ~${price:.2f}")
            
            # Track trade
            self.stock_trades.append({)
                'timestamp': datetime.now(),
                'symbol': symbol,
                'side': side,
                'quantity': quantity,
                'price': price,
                'order_id': order.id
            })
            
            return True
            
        except APIError as e:
            logger.error(f"API Error: {e}")
        except Exception as e:
            logger.error(f"Stock trade failed: {e}")
        
        return False
    
    async def get_option_contracts(self, symbol: str, expiration_days: int = 30) -> List[OptionContract]:
        """Get option contracts for a symbol"""
        if not self.options_enabled:
            return []
            
        try:
            # Get target expiration date
            target_date = datetime.now() + timedelta(days=expiration_days)
            
            # Get current stock price
            stock_quote = self.get_stock_quote(symbol)
            if not stock_quote:
                return []
            
            current_price = stock_quote['price']
            
            # Request option contracts
            request = GetOptionContractsRequest()
                underlying_symbol=symbol,
                expiration_date_gte=target_date.date(),
                expiration_date_lte=(target_date + timedelta(days=10)).date(),
                strike_price_gte=current_price * 0.90,  # 10% OTM
                strike_price_lte=current_price * 1.10   # 10% OTM
            )
            
            contracts = self.trading_client.get_option_contracts(request)
            
            option_contracts = []
            for contract in contracts[:20]:  # Limit to 20 contracts
                try:
                    # Get quote for this contract
                    quote_request = OptionLatestQuoteRequest()
                        symbol_or_symbols=contract.symbol
                    )
                    quotes = self.options_data_client.get_option_latest_quote(quote_request)
                    
                    if contract.symbol in quotes:
                        quote = quotes[contract.symbol]
                        
                        option_contract = OptionContract()
                            symbol=contract.symbol,
                            underlying=symbol,
                            strike=float(contract.strike_price),
                            expiration=contract.expiration_date,
                            contract_type='call' if contract.contract_type == ContractType.CALL else 'put',
                            contract_id=contract.id,
                            bid=float(quote.bid_price) if quote.bid_price else 0,
                            ask=float(quote.ask_price) if quote.ask_price else 0
                        )
                        
                        option_contracts.append(option_contract)
                        
                except Exception as e:
                    logger.debug(f"Could not get quote for {contract.symbol}: {e}")
            
            return option_contracts
            
        except Exception as e:
            logger.error(f"Error getting option contracts for {symbol}: {e}")
            return []
    
    async def execute_option_trade(self, symbol: str, option_type: str = 'call') -> bool:
        """Execute a simple option trade"""
        if not self.options_approved:
            logger.warning("Options trading not approved")
            return False
            
        try:
            logger.info(f"Attempting to execute {option_type} option for {symbol}")
            
            # Get option contracts
            contracts = await self.get_option_contracts(symbol)
            if not contracts:
                logger.warning(f"No option contracts found for {symbol}")
                return False
            
            # Filter by type
            filtered_contracts = [c for c in contracts if c.contract_type == option_type]
            if not filtered_contracts:
                return False
            
            # Find ATM option with good liquidity
            stock_price = self.get_stock_quote(symbol)['price']
            
            # Sort by distance from current price
            filtered_contracts.sort(key=lambda x: abs(x.strike - stock_price))
            
            # Find suitable contract
            selected_contract = None
            for contract in filtered_contracts[:5]:  # Check top 5
                if contract.bid > 0 and contract.ask > 0:
                    spread = contract.ask - contract.bid
                    if spread < contract.ask * 0.1:  # Less than 10% spread
                        selected_contract = contract
                        break
            
            if not selected_contract:
                logger.warning(f"No suitable {option_type} contract found for {symbol}")
                return False
            
            # Calculate quantity (1 contract = 100 shares)
            contract_cost = selected_contract.ask * 100
            quantity = max(1, int(self.options_trade_amount / contract_cost))
            
            # Place order
            order_data = LimitOrderRequest()
                symbol=selected_contract.symbol,
                qty=quantity,
                side=OrderSide.BUY,
                time_in_force=TimeInForce.DAY,
                limit_price=round(selected_contract.ask * 1.02, 2),  # 2% above ask
                asset_class=AssetClass.OPTION
            )
            
            order = self.trading_client.submit_order(order_data)
            
            logger.info(f"✅ OPTION ORDER: BUY {quantity} {selected_contract.symbol}")
            logger.info(f"   Strike: ${selected_contract.strike}, Exp: {selected_contract.expiration.date()}")
            logger.info(f"   Limit: ${order_data.limit_price}")
            
            # Track trade
            self.options_trades.append({)
                'timestamp': datetime.now(),
                'symbol': selected_contract.symbol,
                'underlying': symbol,
                'type': option_type,
                'strike': selected_contract.strike,
                'expiration': selected_contract.expiration,
                'quantity': quantity,
                'price': order_data.limit_price,
                'order_id': order.id
            })
            
            return True
            
        except Exception as e:
            logger.error(f"Option trade failed: {e}")
            return False
    
    async def execute_spread_trade(self, symbol: str, spread_type: str = 'bull_call') -> bool:
        """Execute a spread trade"""
        if not self.options_approved:
            return False
            
        try:
            logger.info(f"Attempting {spread_type} spread for {symbol}")
            
            # Get option contracts
            contracts = await self.get_option_contracts(symbol)
            if not contracts:
                return False
            
            stock_price = self.get_stock_quote(symbol)['price']
            
            # Find suitable contracts for spread
            if spread_type == 'bull_call':
                calls = [c for c in contracts if c.contract_type == 'call']
                calls.sort(key=lambda x: x.strike)
                
                # Find two strikes about $5 apart
                long_contract = None
                short_contract = None
                
                for i in range(len(calls) - 1):
                    if calls[i].bid > 0 and calls[i+1].bid > 0:
                        strike_diff = calls[i+1].strike - calls[i].strike
                        if 2 <= strike_diff <= 10:
                            long_contract = calls[i]
                            short_contract = calls[i+1]
                            break
                
                if not long_contract or not short_contract:
                    logger.warning("Could not find suitable strikes for spread")
                    return False
                
                # Place orders
                # Buy lower strike
                buy_order = LimitOrderRequest()
                    symbol=long_contract.symbol,
                    qty=1,
                    side=OrderSide.BUY,
                    time_in_force=TimeInForce.DAY,
                    limit_price=round(long_contract.ask * 1.02, 2),
                    asset_class=AssetClass.OPTION
                )
                
                # Sell higher strike
                sell_order = LimitOrderRequest()
                    symbol=short_contract.symbol,
                    qty=1,
                    side=OrderSide.SELL,
                    time_in_force=TimeInForce.DAY,
                    limit_price=round(short_contract.bid * 0.98, 2),
                    asset_class=AssetClass.OPTION
                )
                
                # Submit orders
                buy_result = self.trading_client.submit_order(buy_order)
                sell_result = self.trading_client.submit_order(sell_order)
                
                logger.info(f"✅ SPREAD ORDERS PLACED:")
                logger.info(f"   BUY: {long_contract.symbol} @ ${buy_order.limit_price}")
                logger.info(f"   SELL: {short_contract.symbol} @ ${sell_order.limit_price}")
                
                # Track spread
                self.active_spreads[f"{symbol}_{spread_type}_{datetime.now().timestamp()}"] = {}
                    'type': spread_type,
                    'underlying': symbol,
                    'long_leg': long_contract.symbol,
                    'short_leg': short_contract.symbol,
                    'timestamp': datetime.now()
                }
                
                return True
                
        except Exception as e:
            logger.error(f"Spread trade failed: {e}")
            return False
    
    async def run_trading_loop(self):
        """Main trading loop"""
        logger.info("Starting Unified Trading System")
        
        iteration = 0
        
        while True:
            try:
                iteration += 1
                
                # Clear screen
                os.system('clear' if os.name != 'nt' else 'cls')
                
                print("=" * 100)
                print("🚀 UNIFIED TRADING SYSTEM - STOCKS & OPTIONS")
                print("=" * 100)
                print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"Iteration: {iteration}")
                print("=" * 100)
                
                # Check market status
                if not self.is_market_open():
                    print("❌ Market is CLOSED")
                    await asyncio.sleep(60)
                    continue
                
                print("✅ Market is OPEN")
                
                # Get account info
                account = self.trading_client.get_account()
                positions = self.trading_client.get_all_positions()
                
                print(f"\n💰 Account Status:")
                print(f"   Cash: ${float(account.cash):,.2f}")
                print(f"   Portfolio Value: ${float(account.portfolio_value):,.2f}")
                print(f"   Positions: {len(positions)}")
                print(f"   Options Approved: {'✅ Yes' if self.options_approved else '❌ No'}")
                
                # Execute stock trades
                print(f"\n📊 Stock Trading:")
                stock_traded = False
                for symbol in self.stock_symbols[:5]:  # Trade first 5 symbols
                    # Simple momentum check
                    quote = self.get_stock_quote(symbol)
                    if quote and quote['price'] > 0:
                        # Random trading decision for demo
                        if iteration % 3 == 0:  # Trade every 3rd iteration
                            if self.execute_stock_trade(symbol, 'buy'):
                                print(f"   ✅ Bought {symbol}")
                                stock_traded = True
                                break
                
                if not stock_traded:
                    print("   No stock trades this round")
                
                # Execute options trades if approved
                if self.options_approved and self.options_enabled:
                    print(f"\n📊 Options Trading:")
                    
                    # Try different strategies
                    strategy = iteration % 3
                    
                    for symbol in self.option_symbols[:3]:
                        if strategy == 0:
                            # Long call
                            if await self.execute_option_trade(symbol, 'call'):
                                print(f"   ✅ Bought CALL option on {symbol}")
                                break
                        elif strategy == 1:
                            # Long put
                            if await self.execute_option_trade(symbol, 'put'):
                                print(f"   ✅ Bought PUT option on {symbol}")
                                break
                        else:
                            # Spread
                            if await self.execute_spread_trade(symbol, 'bull_call'):
                                print(f"   ✅ Executed BULL CALL spread on {symbol}")
                                break
                else:
                    print(f"\n⚠️  Options trading not available")
                
                # Show recent orders
                print(f"\n📋 Recent Orders:")
                request = GetOrdersRequest()
                    status=QueryOrderStatus.ALL,
                    limit=10
                )
                
                recent_orders = self.trading_client.get_orders(request)
                for order in recent_orders[:5]:
                    asset_type = "OPTION" if hasattr(order, 'asset_class') and order.asset_class == AssetClass.OPTION else "STOCK"
                    status_emoji = '✅' if order.status.value == 'filled' else '⏳'
                    print(f"   {status_emoji} {order.created_at.strftime('%H:%M')} - ")
                          f"{asset_type} {order.side.value.upper()} {order.qty} {order.symbol} - "
                          f"{order.status.value}")
                
                # Show positions
                if positions:
                    print(f"\n💼 Current Positions:")
                    stock_positions = []
                    option_positions = []
                    
                    for pos in positions:
                        # Check if it's an option
                        if any(char.isdigit() for char in pos.symbol) and len(pos.symbol) > 10:
                            option_positions.append(pos)
                        else:
                            stock_positions.append(pos)
                    
                    if stock_positions:
                        print("   Stocks:")
                        for pos in stock_positions[:5]:
                            print(f"     {pos.symbol}: {pos.qty} shares @ ${float(pos.avg_entry_price):.2f}")
                    
                    if option_positions:
                        print("   Options:")
                        for pos in option_positions[:5]:
                            print(f"     {pos.symbol}: {pos.qty} contracts")
                
                # Show trade summary
                print(f"\n📊 Trade Summary:")
                print(f"   Stock Trades: {len(self.stock_trades)}")
                print(f"   Option Trades: {len(self.options_trades)}")
                print(f"   Active Spreads: {len(self.active_spreads)}")
                
                print(f"\n⏳ Next scan in 30 seconds... (Press Ctrl+C to stop)")
                await asyncio.sleep(30)
                
            except KeyboardInterrupt:
                print("\n\n🛑 Stopping system...")
                break
            except Exception as e:
                logger.error(f"Main loop error: {e}")
                await asyncio.sleep(60)
        
        # Summary
        print(f"\n{'=' * 100}")
        print("📊 FINAL TRADING SUMMARY")
        print("=" * 100)
        print(f"Stock Trades Executed: {len(self.stock_trades)}")
        print(f"Option Trades Executed: {len(self.options_trades)}")
        print(f"Spreads Executed: {len(self.active_spreads)}")

async def main():
    """Main entry point"""
    print("=" * 100)
    print("🎯 UNIFIED TRADING SYSTEM - STOCKS & OPTIONS")
    print("=" * 100)
    print("\nThis system will:")
    print("  ✅ Trade stocks with real market orders")
    print("  ✅ Trade options if your account is approved")
    print("  ✅ Execute spreads and multi-leg strategies")
    print("  ✅ Work during market hours")
    print("\n⚠️  Using Alpaca PAPER trading account")
    
    system = UnifiedTradingSystem()
    await system.run_trading_loop()

if __name__ == "__main__":
    asyncio.run(main())