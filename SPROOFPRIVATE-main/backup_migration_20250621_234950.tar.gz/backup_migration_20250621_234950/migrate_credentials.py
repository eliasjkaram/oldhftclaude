#!/usr/bin/env python3
"""
CREDENTIAL MIGRATION HELPER
==========================

This script helps migrate from hardcoded credentials to secure credential management.
It will guide you through setting up environment variables or encrypted storage.
"""

import os
import sys
import json
from getpass import getpass
from cryptography.fernet import Fernet
from PRODUCTION_FIXES import SecureConfigManager

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


def setup_credentials():
    """Interactive setup for credentials"""
    print("🔐 CREDENTIAL MIGRATION HELPER")
    print("=" * 50)
    print("\nThis script will help you securely set up your API credentials.")
    print("Your credentials will be stored either as environment variables")
    print("or in an encrypted file.\n")
    
    # Check if credentials are already set
    config_manager = SecureConfigManager()
    validation = config_manager.validate_credentials()
    
    if all(validation.values():
        print("✅ All credentials are already configured!")
        print("\nCurrent status:")
        for key, is_valid in validation.items():
            status = "✅ Set" if is_valid else "❌ Missing"
            print(f"  {key}: {status}")
        return
    
    print("Current credential status:")
    for key, is_valid in validation.items():
        status = "✅ Set" if is_valid else "❌ Missing"
        print(f"  {key}: {status}")
    
    print("\nChoose storage method:")
    print("1. Environment variables (recommended for development)")
    print("2. Encrypted file (recommended for production)")
    
    choice = input("\nEnter your choice (1 or 2): ").strip()
    
    if choice == "1":
        setup_environment_variables()
    elif choice == "2":
        setup_encrypted_storage()
    else:
        print("Invalid choice. Exiting.")
        sys.exit(1)

def setup_environment_variables():
    """Set up credentials as environment variables"""
    print("\n📝 Setting up environment variables...")
    print("You can add these to your shell profile (.bashrc, .zshrc, etc.)")
    print("or create a .env file.\n")
    
    credentials = collect_credentials()
    
    print("\n" + "=" * 50)
    print("Add these lines to your shell profile or .env file:")
    print("=" * 50)
    
    for key, value in credentials.items():
        print(f"export {key}='{value}'")
    
    print("\n" + "=" * 50)
    print("\n✅ After adding these, reload your shell or run:")
    print("   source ~/.bashrc  (or your shell profile)")
    
    # Optionally create .env file
    create_env = input("\nWould you like to create a .env file? (y/n): ").strip().lower()
    if create_env == 'y':
        with open('/home/harry/alpaca-mcp/.env', 'w') as f:
            for key, value in credentials.items():
                f.write(f"{key}={value}\n")
        print("\n✅ Created .env file at /home/harry/alpaca-mcp/.env")
        print("⚠️  Remember to add .env to your .gitignore!")

def setup_encrypted_storage():
    """Set up credentials in encrypted storage"""
    print("\n🔒 Setting up encrypted storage...")
    
    credentials = collect_credentials()
    
    # Create encryption key if not exists
    key_file = os.path.expanduser("~/.alpaca_mcp/encryption.key")
    os.makedirs(os.path.dirname(key_file), exist_ok=True)
    
    if os.path.exists(key_file):
        with open(key_file, 'rb') as f:
            encryption_key = f.read()
    else:
        encryption_key = Fernet.generate_key()
        with open(key_file, 'wb') as f:
            f.write(encryption_key)
        os.chmod(key_file, 0o600)
        print(f"\n✅ Created encryption key at {key_file}")
    
    # Encrypt and save credentials
    cipher = Fernet(encryption_key)
    encrypted_data = cipher.encrypt(json.dumps(credentials).encode()
    
    encrypted_file = os.path.expanduser("~/.alpaca_mcp/credentials.enc")
    with open(encrypted_file, 'wb') as f:
        f.write(encrypted_data)
    os.chmod(encrypted_file, 0o600)
    
    print(f"\n✅ Saved encrypted credentials to {encrypted_file}")
    print("✅ Your credentials are now securely stored!")

def collect_credentials():
    """Collect credentials from user"""
    print("\nPlease enter your API credentials:")
    print("(Leave blank to skip optional credentials)\n")
    
    credentials = {}
    
    # Alpaca credentials
    print("ALPACA TRADING API (from https://app.alpaca.markets/)")
    credentials['ALPACA_PAPER_KEY'] = getpass("Alpaca Paper Trading API Key: ").strip()
    credentials['ALPACA_PAPER_SECRET'] = getpass("Alpaca Paper Trading Secret: ").strip()
    
    live_key = getpass("Alpaca Live Trading API Key (optional): ").strip()
    live_secret = getpass("Alpaca Live Trading Secret (optional): ").strip()
    
    credentials['ALPACA_LIVE_KEY'] = live_key or credentials['ALPACA_PAPER_KEY']
    credentials['ALPACA_LIVE_SECRET'] = live_secret or credentials['ALPACA_PAPER_SECRET']
    
    # OpenRouter credentials
    print("\nOPENROUTER AI API (from https://openrouter.ai/)")
    credentials['OPENROUTER_API_KEY'] = getpass("OpenRouter API Key: ").strip()
    
    # Alpha Vantage (optional)
    print("\nALPHA VANTAGE API (optional, from https://www.alphavantage.co/)")
    av_key = getpass("Alpha Vantage API Key (optional): ").strip()
    if av_key:
        credentials['ALPHA_VANTAGE_API_KEY'] = av_key
    
    # Validate required fields
    required = ['ALPACA_PAPER_KEY', 'ALPACA_PAPER_SECRET', 'OPENROUTER_API_KEY']
    missing = [k for k in required if not credentials.get(k)]
    
    if missing:
        print(f"\n❌ Error: Missing required credentials: {', '.join(missing)}")
        sys.exit(1)
    
    return credentials

def main():
    """Main entry point"""
    try:
        setup_credentials()
        
        print("\n" + "=" * 50)
        print("🎉 CREDENTIAL SETUP COMPLETE!")
        print("=" * 50)
        print("\n⚠️  IMPORTANT SECURITY NOTES:")
        print("1. Never commit credentials to version control")
        print("2. Add .env to your .gitignore if using .env files")
        print("3. Keep your encryption key secure")
        print("4. Rotate your API keys regularly")
        print("\n✅ You can now run your trading system securely!")
        
    except KeyboardInterrupt:
        print("\n\nSetup cancelled.")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()