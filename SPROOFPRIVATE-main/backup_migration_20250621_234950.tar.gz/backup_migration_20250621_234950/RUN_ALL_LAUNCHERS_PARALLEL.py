#!/usr/bin/env python3
"""
Run All Launchers in Parallel
=============================
Launches all system components simultaneously
"""

import subprocess
import os
import sys
import time
import signal
from datetime import datetime

def run_launcher_background(launcher_name, log_file):
    """Run a launcher in the background with logging."""
    print(f"🚀 Starting {launcher_name}...")
    
    # Create log directory
    os.makedirs("logs", exist_ok=True)
    
    # Open log file
    with open(f"logs/{log_file}", "w") as f:
        # Start process
        process = subprocess.Popen()
            [sys.executable, launcher_name],
            stdout=f,
            stderr=subprocess.STDOUT,
            preexec_fn=os.setsid  # Create new process group
        )
        
    return process

def main():
    print(""")
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║               RUNNING ALL LAUNCHERS IN PARALLEL                       ║
    ╠═══════════════════════════════════════════════════════════════════════╣
    ║                                                                       ║
    ║  Starting all trading system launchers simultaneously:                ║
    ║  • LIVE_TRADING_SYSTEM_LAUNCHER.py (16 components)                   ║
    ║  • COMPREHENSIVE_SYSTEM_LAUNCHER.py (72 components)                  ║
    ║  • ULTRA_COMPREHENSIVE_SYSTEM_LAUNCHER.py (200+ components)          ║
    ║  • ULTIMATE_COMPLETE_SYSTEM_LAUNCHER.py (250+ components)            ║
    ║                                                                       ║
    ╚═══════════════════════════════════════════════════════════════════════╝
    """)
    
    # Set demo environment
    os.environ['TRADING_MODE'] = 'demo'
    os.environ['ALPACA_API_KEY'] = 'demo_key'
    os.environ['ALPACA_SECRET_KEY'] = 'demo_secret'
    
    # List of launchers
    launchers = []
        ("LIVE_TRADING_SYSTEM_LAUNCHER.py", "live_system.log"),
        ("COMPREHENSIVE_SYSTEM_LAUNCHER.py", "comprehensive_system.log"),
        ("ULTRA_COMPREHENSIVE_SYSTEM_LAUNCHER.py", "ultra_system.log"),
        ("ULTIMATE_COMPLETE_SYSTEM_LAUNCHER.py", "ultimate_system.log"),
    ]
    
    processes = []
    
    # Start all launchers
    print(f"\n📅 Launch Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    for launcher, log_file in launchers:
        if os.path.exists(launcher):
            process = run_launcher_background(launcher, log_file)
            processes.append((launcher, process, log_file))
            time.sleep(2)  # Small delay between launches
        else:
            print(f"⚠️  {launcher} not found")
    
    print(f"\n✅ Started {len(processes)} launchers")
    print("\n📊 Monitoring launcher status...")
    print("   Logs are being written to the 'logs' directory")
    print("\n   Press Ctrl+C to stop all launchers\n")
    
    # Monitor processes
    try:
        while True:
            time.sleep(10)  # Check every 10 seconds
            
            # Check process status
            running = 0
            for name, proc, log_file in processes:
                if proc.poll() is None:
                    running += 1
                else:
                    print(f"⚠️  {name} has stopped (exit code: {proc.returncode})")
            
            if running > 0:
                print(f"💚 {running}/{len(processes)} launchers running... [{datetime.now().strftime('%H:%M:%S')}]")
            else:
                print("❌ All launchers have stopped")
                break
                
    except KeyboardInterrupt:
        print("\n\n⚠️  Shutdown requested...")
        
        # Terminate all processes
        for name, proc, _ in processes:
            if proc.poll() is None:
                print(f"   Stopping {name}...")
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                proc.wait()
        
        print("\n✅ All launchers stopped")
    
    # Show log summary
    print("\n📋 Log files created:")
    for _, _, log_file in processes:
        log_path = f"logs/{log_file}"
        if os.path.exists(log_path):
            size = os.path.getsize(log_path)
            print(f"   • {log_file} ({size:,} bytes)")

if __name__ == "__main__":
    main()