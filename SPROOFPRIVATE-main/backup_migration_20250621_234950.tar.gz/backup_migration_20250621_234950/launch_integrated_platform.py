
#!/usr/bin/env python3
"""
Launch Integrated Trading Platform
==================================
Launches all trading components in the correct order with proper monitoring
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
import time
import subprocess
import signal
import threading
from datetime import datetime
import logging

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class IntegratedTradingPlatform:
    def __init__(self):
        self.processes = []
        self.running = True
        
        # Define all trading components in priority order
        self.components = {}
            "Data Collection": []
                ("Market Data Collector", "market_data_collector.py"),
                ("Data Validator", "cross_platform_validator.py"),
            ],
            "AI Analysis": []
                ("Options Scanner", "options_scanner.py"),
                ("Enhanced Options Bot", "enhanced_options_bot.py"),
                ("Multi-Agent System", "multi_agent_trading_system.py"),
            ],
            "Trading Execution": []
                ("Simple Paper Trader", "simple_paper_trader.py"),
                ("Comprehensive Trading", "comprehensive_trading_system.py"),
            ],
            "Monitoring": []
                ("Trading Monitor", "monitor_trading.py"),
                ("System Dashboard", "ai_systems_dashboard.py"),
            ]
        }
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info("Shutdown signal received...")
        self.running = False
        self.shutdown_all()
        sys.exit(0)
    
    def start_process(self, name, script):
        """Start a trading component process"""
        try:
            # Check if script exists
            script_path = os.path.join("/home/harry/alpaca-mcp", script)
            if not os.path.exists(script_path):
                logger.warning(f"Script not found: {script}")
                return None
            
            # Start the process
            process = subprocess.Popen()
                [sys.executable, script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.processes.append((name, process)
            logger.info(f"✅ Started: {name} (PID: {process.pid})")
            return process
            
        except Exception as e:
            logger.error(f"❌ Failed to start {name}: {e}")
            return None
    
    def check_processes(self):
        """Check status of all running processes"""
        active = []
        for name, proc in self.processes:
            if proc.poll() is None:
                active.append((name, proc)
            else:
                logger.warning(f"⚠️ Process terminated: {name}")
        
        self.processes = active
        return len(active)
    
    def display_status(self):
        """Display current platform status"""
        print("\n" + "="*80)
        print(f"🚀 INTEGRATED TRADING PLATFORM - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*80)
        
        print("\n📊 Active Components:")
        for name, proc in self.processes:
            if proc.poll() is None:
                print(f"  🟢 {name} (PID: {proc.pid})")
            else:
                print(f"  🔴 {name} (Stopped)")
        
        print(f"\nTotal Active: {len([p for n, p in self.processes if p.poll() is None])}")
        print("="*80)
    
    def shutdown_all(self):
        """Shutdown all processes gracefully"""
        logger.info("Shutting down all processes...")
        
        for name, proc in self.processes:
            if proc.poll() is None:
                logger.info(f"Terminating {name}...")
                proc.terminate()
                
                # Give it time to shutdown gracefully
                time.sleep(2)
                
                # Force kill if still running
                if proc.poll() is None:
                    proc.kill()
                    logger.warning(f"Force killed {name}")
    
    def run(self):
        """Run the integrated platform"""
        # Setup signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        print("\n" + "="*80)
        print("🚀 LAUNCHING INTEGRATED TRADING PLATFORM")
        print("="*80)
        print("Press Ctrl+C to shutdown\n")
        
        # Start components in order
        for category, components in self.components.items():
            print(f"\n🔧 Starting {category}...")
            for name, script in components:
                self.start_process(name, script)
                time.sleep(2)  # Small delay between starts
        
        # Main monitoring loop
        while self.running:
            try:
                # Display status
                self.display_status()
                
                # Check for failed processes
                active_count = self.check_processes()
                
                if active_count == 0:
                    logger.warning("All processes have stopped!")
                    break
                
                # Wait before next check
                time.sleep(30)
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
        
        # Cleanup
        self.shutdown_all()
        print("\n✅ Platform shutdown complete")

# Quick launcher functions for specific systems
def launch_options_trading():
    """Launch only options trading components"""
    logger.info("Launching Options Trading System...")
    processes = []
    
    # Start options-specific components
    scripts = []
        ("Options Scanner", "options_scanner.py"),
        ("Enhanced Options Bot", "enhanced_options_bot.py"),
        ("Options Executor", "comprehensive_options_executor.py"),
        ("Spread Strategies", "comprehensive_spread_strategies.py"),
    ]
    
    for name, script in scripts:
        try:
            proc = subprocess.Popen([sys.executable, script])
            processes.append((name, proc)
            logger.info(f"Started {name}")
            time.sleep(2)
        except Exception as e:
            logger.error(f"Failed to start {name}: {e}")
    
    return processes

def launch_ai_systems():
    """Launch AI/ML trading systems"""
    logger.info("Launching AI Trading Systems...")
    processes = []
    
    # Start AI components
    scripts = []
        ("DGM Deep Learning", "dgm_deep_learning_system.py"),
        ("Multi-Agent System", "multi_agent_trading_system.py"),
        ("Mamba Model", "mamba_trading_model.py"),
        ("Production AI", "production_ai_system.py"),
    ]
    
    for name, script in scripts:
        try:
            proc = subprocess.Popen([sys.executable, script])
            processes.append((name, proc)
            logger.info(f"Started {name}")
            time.sleep(2)
        except Exception as e:
            logger.error(f"Failed to start {name}: {e}")
    
    return processes

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Integrated Trading Platform Launcher')
    parser.add_argument('--mode', choices=['full', 'options', 'ai', 'simple'], 
                       default='simple',
                       help='Launch mode: full (all systems), options (options only), ai (AI only), simple (basic trading)')
    
    args = parser.parse_args()
    
    if args.mode == 'full':
        # Launch full platform
        platform = IntegratedTradingPlatform()
        platform.run()
    
    elif args.mode == 'options':
        # Launch options trading only
        processes = launch_options_trading()
        print("\n✅ Options Trading System launched")
        print("Press Ctrl+C to stop")
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            for name, proc in processes:
                proc.terminate()
    
    elif args.mode == 'ai':
        # Launch AI systems only
        processes = launch_ai_systems()
        print("\n✅ AI Trading Systems launched")
        print("Press Ctrl+C to stop")
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            for name, proc in processes:
                proc.terminate()
    
    else:  # simple mode
        # Just run the simple paper trader and monitor
        print("\n🚀 Launching Simple Trading Mode...")
        trader = subprocess.Popen([sys.executable, "simple_paper_trader.py"])
        monitor = subprocess.Popen([sys.executable, "monitor_trading.py"])
        
        print("✅ Simple trading system launched")
        print("Press Ctrl+C to stop")
        try:
            trader.wait()
        except KeyboardInterrupt:
            trader.terminate()
            monitor.terminate()

if __name__ == "__main__":
    main()