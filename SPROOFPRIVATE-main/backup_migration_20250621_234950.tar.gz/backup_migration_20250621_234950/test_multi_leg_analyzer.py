#!/usr/bin/env python3
"""
Test script for Multi-Leg Options Strategy Analyzer
"""

import sys
import os
from datetime import datetime, timedelta
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from multi_leg_strategy_analyzer import ()
    MultiLegStrategyAnalyzer, StrategyType, MarketOutlook,
    StrategyPosition, OptionLeg, OptionContract
)

def create_sample_market_data(underlying_price: float = 100.0) -> dict:
    """Create sample market data for testing"""
    market_data = {'underlying_price': underlying_price, 'iv_rank': 50}
    
    # Generate sample option data
    strikes = np.arange(85, 116, 5)
    expiration = datetime.now() + timedelta(days=45)
    
    for strike in strikes:
        # Calculate rough option prices using simplified Black-Scholes approximation
        moneyness = underlying_price / strike
        time_value = 0.2 * np.sqrt(45/365) * underlying_price * 0.1
        
        # Calls
        call_intrinsic = max(underlying_price - strike, 0)
        call_price = call_intrinsic + time_value * (1 if moneyness > 1 else moneyness)
        
        call_key = f"TEST_call_{strike}_{expiration}"
        market_data[call_key] = type('obj', (object,), {)
            'bid': call_price * 0.98,
            'ask': call_price * 1.02,
            'mid': call_price,
            'implied_volatility': 0.20 + 0.05 * abs(1 - moneyness),
            'volume': int(1000 * np.random.random()),
            'open_interest': int(10000 * np.random.random()),
            'liquidity_score': 0.7 + 0.3 * np.random.random()
        })
        
        # Puts
        put_intrinsic = max(strike - underlying_price, 0)
        put_price = put_intrinsic + time_value * (1 if moneyness < 1 else 1/moneyness)
        
        put_key = f"TEST_put_{strike}_{expiration}"
        market_data[put_key] = type('obj', (object,), {)
            'bid': put_price * 0.98,
            'ask': put_price * 1.02,
            'mid': put_price,
            'implied_volatility': 0.20 + 0.05 * abs(1 - moneyness),
            'volume': int(1000 * np.random.random()),
            'open_interest': int(10000 * np.random.random()),
            'liquidity_score': 0.7 + 0.3 * np.random.random()
        })
    
    return market_data

def test_iron_condor():
    """Test Iron Condor analysis"""
    print("="*60)
    print("Testing Iron Condor Strategy")
    print("="*60)
    
    analyzer = MultiLegStrategyAnalyzer()
    expiration = datetime.now() + timedelta(days=45)
    
    # Create Iron Condor position
    iron_condor = StrategyPosition()
        strategy_type=StrategyType.IRON_CONDOR,
        legs=[]
            # Bull Put Spread
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 90, expiration, 'put'),
                quantity=-1,
                price=1.50,
                current_bid=1.40, current_ask=1.60, current_mid=1.50,
                implied_volatility=0.22
            ),
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 85, expiration, 'put'),
                quantity=1,
                price=0.75,
                current_bid=0.70, current_ask=0.80, current_mid=0.75,
                implied_volatility=0.24
            ),
            # Bear Call Spread
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 110, expiration, 'call'),
                quantity=-1,
                price=1.75,
                current_bid=1.65, current_ask=1.85, current_mid=1.75,
                implied_volatility=0.21
            ),
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 115, expiration, 'call'),
                quantity=1,
                price=0.85,
                current_bid=0.80, current_ask=0.90, current_mid=0.85,
                implied_volatility=0.23
            )
        ],
        entry_date=datetime.now(),
        underlying_symbol="TEST",
        entry_underlying_price=100.0,
        current_underlying_price=100.0,
        entry_iv_rank=75
    )
    
    # Create market data
    market_data = create_sample_market_data(100.0)
    
    # Analyze the strategy
    analysis = analyzer.analyze_strategy(iron_condor, market_data)
    
    # Print results
    print(f"\nStrategy Score: {analysis['strategy_score']['total_score']:.1f}/100")
    print(f"Rating: {analysis['strategy_score']['rating']}")
    
    print("\nPosition Details:")
    print(f"Total Credit: ${-iron_condor.total_cost:.2f}")
    print(f"Days to Expiry: {analysis['position_details']['days_to_expiry']}")
    
    print("\nP&L Analysis:")
    pnl = analysis['pnl_analysis']
    print(f"Max Profit: ${pnl['max_profit']:.2f}")
    print(f"Max Loss: ${pnl['max_loss']:.2f}")
    print(f"Profit Probability: {pnl['profit_probability']*100:.1f}%")
    print(f"Expected Value: ${pnl['expected_value']:.2f}")
    print(f"Breakeven Points: {[f'${be:.2f}' for be in pnl['breakeven_points']]}")
    
    print("\nGreeks Analysis:")
    greeks = analysis['greeks_analysis']['aggregate_greeks']
    print(f"Delta: {greeks['delta']:.2f}")
    print(f"Theta: ${greeks['theta']:.2f}/day")
    print(f"Vega: ${greeks['vega']:.2f}")
    
    print("\nRisk Metrics:")
    risk = analysis['risk_metrics']
    print(f"1-Day VaR (95%): ${risk['var_1day_95']:.2f}")
    print(f"Capital Efficiency: {risk['capital_efficiency']:.2%}")
    
    # Create payoff diagram
    fig = analyzer.create_payoff_diagram(iron_condor)
    plt.savefig('iron_condor_payoff.png', dpi=150, bbox_inches='tight')
    print("\nPayoff diagram saved as 'iron_condor_payoff.png'")
    plt.close()

def test_bull_call_spread():
    """Test Bull Call Spread analysis"""
    print("\n" + "="*60)
    print("Testing Bull Call Spread")
    print("="*60)
    
    analyzer = MultiLegStrategyAnalyzer()
    expiration = datetime.now() + timedelta(days=30)
    
    # Create Bull Call Spread
    bull_spread = StrategyPosition()
        strategy_type=StrategyType.BULL_CALL_SPREAD,
        legs=[]
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 100, expiration, 'call'),
                quantity=1,
                price=3.00,
                current_bid=2.90, current_ask=3.10, current_mid=3.00,
                implied_volatility=0.20
            ),
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 105, expiration, 'call'),
                quantity=-1,
                price=1.50,
                current_bid=1.40, current_ask=1.60, current_mid=1.50,
                implied_volatility=0.19
            )
        ],
        entry_date=datetime.now(),
        underlying_symbol="TEST",
        entry_underlying_price=100.0,
        current_underlying_price=100.0
    )
    
    market_data = create_sample_market_data(100.0)
    analysis = analyzer.analyze_strategy(bull_spread, market_data)
    
    print(f"\nStrategy Score: {analysis['strategy_score']['total_score']:.1f}/100")
    print(f"Net Debit: ${bull_spread.total_cost:.2f}")
    print(f"Max Profit: ${analysis['pnl_analysis']['max_profit']:.2f}")
    print(f"Max Loss: ${analysis['pnl_analysis']['max_loss']:.2f}")
    print(f"Breakeven: ${analysis['pnl_analysis']['breakeven_points'][0]:.2f}")
    print(f"Profit Probability: {analysis['pnl_analysis']['profit_probability']*100:.1f}%")

def test_strategy_optimization():
    """Test strategy optimization"""
    print("\n" + "="*60)
    print("Testing Strategy Optimization")
    print("="*60)
    
    analyzer = MultiLegStrategyAnalyzer()
    
    # Create sample option chain
    option_chain = {}
    for days in [30, 45, 60]:
        expiration = datetime.now() + timedelta(days=days)
        contracts = []
        
        for strike in range(85, 116, 5):
            contracts.append(OptionContract("TEST", "TEST", strike, expiration, 'call'))
            contracts.append(OptionContract("TEST", "TEST", strike, expiration, 'put'))
        
        option_chain[expiration] = contracts
    
    # Create market data
    market_data = create_sample_market_data(100.0)
    
    # Optimize Iron Condor
    print("\nOptimizing Iron Condor for neutral market outlook...")
    result = analyzer.optimize_strategy()
        StrategyType.IRON_CONDOR,
        "TEST",
        MarketOutlook.NEUTRAL,
        option_chain,
        market_data,
        constraints={'max_capital': 5000}
    )
    
    if result.get('success'):
        params = result['optimal_parameters']
        print(f"Optimal Parameters:")
        print(f"  Expiration: {params['expiration'].strftime('%Y-%m-%d')}")
        print(f"  Put Spread: ${params['put_long_strike']:.0f}/${params['put_short_strike']:.0f}")
        print(f"  Call Spread: ${params['call_short_strike']:.0f}/${params['call_long_strike']:.0f}")
        print(f"  Optimization Score: {result['optimization_score']:.3f}")
        
        analysis = result['analysis']
        print(f"\nExpected Results:")
        print(f"  Max Profit: ${analysis['pnl_analysis']['max_profit']:.2f}")
        print(f"  Max Loss: ${analysis['pnl_analysis']['max_loss']:.2f}")
        print(f"  Profit Probability: {analysis['pnl_analysis']['profit_probability']*100:.1f}%")
        print(f"  Strategy Score: {analysis['strategy_score']['total_score']:.1f}/100")

def test_strategy_suggestions():
    """Test strategy suggestions based on market outlook"""
    print("\n" + "="*60)
    print("Testing Strategy Suggestions")
    print("="*60)
    
    analyzer = MultiLegStrategyAnalyzer()
    
    # Test different market outlooks
    outlooks = []
        (MarketOutlook.BULLISH, "high", 10000),
        (MarketOutlook.NEUTRAL, "low", 10000),
        (MarketOutlook.HIGH_VOLATILITY, "high", 10000)
    ]
    
    for outlook, vol_regime, capital in outlooks:
        print(f"\nMarket Outlook: {outlook.value}, Volatility: {vol_regime}")
        suggestions = analyzer.suggest_strategies_for_outlook(outlook, vol_regime, capital)
        
        for i, suggestion in enumerate(suggestions[:3], 1):
            print(f"\n{i}. {suggestion['strategy_type']}")
            print(f"   Rationale: {suggestion['rationale']}")
            print(f"   Capital Required: ${suggestion['capital_requirement']:,.0f}")
            print(f"   Complexity: {suggestion['complexity']}")
            print(f"   Best Conditions: {suggestion['best_market_conditions']}")

def test_volatility_analysis():
    """Test volatility sensitivity analysis"""
    print("\n" + "="*60)
    print("Testing Volatility Sensitivity Analysis")
    print("="*60)
    
    analyzer = MultiLegStrategyAnalyzer()
    expiration = datetime.now() + timedelta(days=45)
    
    # Create a Long Straddle (volatility play)
    straddle = StrategyPosition()
        strategy_type=StrategyType.LONG_STRADDLE,
        legs=[]
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 100, expiration, 'call'),
                quantity=1,
                price=3.50,
                current_bid=3.40, current_ask=3.60, current_mid=3.50,
                implied_volatility=0.25
            ),
            OptionLeg()
                contract=OptionContract("TEST", "TEST", 100, expiration, 'put'),
                quantity=1,
                price=3.50,
                current_bid=3.40, current_ask=3.60, current_mid=3.50,
                implied_volatility=0.25
            )
        ],
        entry_date=datetime.now(),
        underlying_symbol="TEST",
        entry_underlying_price=100.0,
        current_underlying_price=100.0,
        entry_iv_rank=30  # Low IV rank good for long volatility
    )
    
    market_data = create_sample_market_data(100.0)
    analysis = analyzer.analyze_strategy(straddle, market_data)
    
    vol_analysis = analysis['volatility_analysis']
    print(f"\nAggregate Vega: ${vol_analysis['aggregate_vega']:.2f}")
    print(f"Position Type: {vol_analysis['vega_sign']}")
    print(f"Current Average IV: {vol_analysis['current_average_iv']*100:.1f}%")
    print(f"Recommendation: {vol_analysis['vol_regime_recommendation']}")
    
    print("\nVolatility Scenarios (P&L Impact):")
    for scenario in vol_analysis['volatility_scenarios']:
        vol_change_pct = scenario['vol_change'] * 100
        pnl_impact = scenario['pnl_impact']
        print(f"  IV Change: {vol_change_pct:+.0f}% → P&L Impact: ${pnl_impact:+,.0f}")

def main():
    """Run all tests"""
    print("Multi-Leg Options Strategy Analyzer Test Suite")
    print("=" * 60)
    
    # Run tests
    test_iron_condor()
    test_bull_call_spread()
    test_strategy_optimization()
    test_strategy_suggestions()
    test_volatility_analysis()
    
    print("\n" + "="*60)
    print("All tests completed successfully!")
    print("="*60)

if __name__ == "__main__":
    main()