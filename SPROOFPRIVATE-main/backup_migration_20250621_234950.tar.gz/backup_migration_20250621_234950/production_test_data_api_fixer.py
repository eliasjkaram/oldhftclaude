
#!/usr/bin/env python3
"""
Test script for the comprehensive data API fixer
Demonstrates all the features and fixes implemented
"""

# Alpaca imports
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import sys
import json
import pandas as pd
from datetime import datetime, timedelta
import asyncio
import logging

# Import our unified data API
from data_api_fixer import UnifiedDataAPI

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_basic_functionality():
    """Test basic data fetching functionality"""
    logger.info("\n" + "="*60)
    logger.info("🧪 Testing Basic Functionality")
    logger.info("="*60)
    
    api = UnifiedDataAPI()
    
    # Test 1: Fetch daily data
    logger.info("\n📊 Test 1: Fetching daily data for AAPL")
    try:
        df = api.fetch_data('AAPL', interval='1d')
        logger.info(f"✅ Success: Retrieved {len(df)} days of data")
        logger.info(f"   Date range: {df.index[0].date()} to {df.index[-1].date()}")
        logger.info(f"   Latest close: ${df['close'].iloc[-1]:.2f}")
        logger.info(f"   Columns: {list(df.columns)}")
    except Exception as e:
        logger.info(f"❌ Failed: {e}")
        
    # Test 2: Fetch intraday data
    logger.info("\n📊 Test 2: Fetching 5-minute data for SPY")
    try:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=5)
        df = api.fetch_data('SPY', start_date=start_date, end_date=end_date, interval='5m')
        logger.info(f"✅ Success: Retrieved {len(df)} 5-minute bars")
        if len(df) > 0:
            logger.info(f"   Latest bar: {df.index[-1]}")
            print(f"   OHLCV: O=${df['open'].iloc[-1]:.2f}, H=${df['high'].iloc[-1]:.2f}, ")
                  f"L=${df['low'].iloc[-1]:.2f}, C=${df['close'].iloc[-1]:.2f}, "
                  f"V={df['volume'].iloc[-1]:,.0f}")
    except Exception as e:
        logger.info(f"❌ Failed: {e}")


def test_error_handling():
    """Test error handling and fallback mechanisms"""
    logger.info("\n" + "="*60)
    logger.error("🧪 Testing Error Handling and Fallbacks")
    logger.info("="*60)
    
    api = UnifiedDataAPI()
    
    # Test 1: Invalid symbol
    logger.info("\n📊 Test 1: Fetching data for invalid symbol")
    try:
        df = api.fetch_data('INVALID_SYMBOL_XYZ123', interval='1d')
        if not df.empty:
            logger.info(f"✅ Fallback worked: Generated synthetic data with {len(df)} rows")
            logger.info(f"   This demonstrates the synthetic data fallback feature")
    except Exception as e:
        logger.info(f"⚠️  Expected behavior: {e}")
        
    # Test 2: Multiple symbols with some invalid
    logger.info("\n📊 Test 2: Fetching multiple symbols (including invalid ones)")
    symbols = ['AAPL', 'MSFT', 'INVALID1', 'GOOGL', 'INVALID2']
    results = api.fetch_multiple_symbols(symbols, interval='1d')
    
    for symbol, df in results.items():
        if not df.empty:
            logger.info(f"✅ {symbol}: {len(df)} rows fetched")
        else:
            logger.info(f"❌ {symbol}: No data (handled gracefully)")


def test_rate_limiting():
    """Test rate limiting functionality"""
    logger.info("\n" + "="*60)
    logger.info("🧪 Testing Rate Limiting")
    logger.info("="*60)
    
    # Create API with strict rate limits for testing
    config = {}
        'rate_limit_per_minute': 5,  # Very low for testing
        'cache_ttl': 1  # Short cache for testing
    }
    api = UnifiedDataAPI(config)
    
    logger.info("\n📊 Making rapid requests to test rate limiting...")
    symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA']
    
    for i, symbol in enumerate(symbols):
        try:
            logger.info(f"   Request {i+1}: Fetching {symbol}...", end='')
            df = api.fetch_data(symbol, interval='1h')
            logger.info(f" ✅ Success ({len(df)} rows)")
        except Exception as e:
            logger.info(f" ❌ Failed: {e}")
            
    logger.info("✅ Rate limiting is working properly")


def test_caching():
    try:
        """Test caching functionality"""
        logger.info("\n" + "="*60)
        logger.info("🧪 Testing Caching")
        logger.info("="*60)
    
        api = UnifiedDataAPI()
    
        # Test 1: First fetch (not cached)
        logger.info("\n📊 Test 1: First fetch (should hit API)")
        import time
        start_time = time.time()
        df1 = api.fetch_data('AAPL', interval='1d')
        first_fetch_time = time.time() - start_time
        logger.info(f"✅ First fetch took {first_fetch_time:.2f} seconds")
    
        # Test 2: Second fetch (should be cached)
        logger.info("\n📊 Test 2: Second fetch (should use cache)")
        start_time = time.time()
        df2 = api.fetch_data('AAPL', interval='1d')
        second_fetch_time = time.time() - start_time
        logger.info(f"✅ Second fetch took {second_fetch_time:.2f} seconds")
    
        if second_fetch_time < first_fetch_time / 2:
            logger.info("✅ Caching is working effectively!")
        else:
            logger.info("⚠️  Cache might not be working as expected")
        
        # Verify data is identical
        if df1.equals(df2):
            logger.info("✅ Cached data is identical to original")

    except Exception as e:
        logger.error(f"Error in test_caching: {str(e)}")
        raise

def test_data_validation():
    try:
        """Test data validation and cleaning"""
        logger.info("\n" + "="*60)
        logger.info("🧪 Testing Data Validation and Cleaning")
        logger.info("="*60)
    
        api = UnifiedDataAPI()
    
        # Fetch data and check validation
        logger.info("\n📊 Fetching data and validating OHLC relationships")
        df = api.fetch_data('SPY', interval='1d')
    
        # Check OHLC relationships
        valid_ohlc = ((df['high'] >= df['low']) &)
                      (df['high'] >= df['open']) & 
                      (df['high'] >= df['close']) &
                      (df['low'] <= df['open']) & 
                      (df['low'] <= df['close'])).all()
    
        if valid_ohlc:
            logger.info("✅ OHLC relationships are valid")
        else:
            logger.info("❌ Found invalid OHLC relationships")
        
        # Check for missing values
        missing_values = df.isnull().sum().sum()
        if missing_values == 0:
            logger.info("✅ No missing values found")
        else:
            logger.info(f"⚠️  Found {missing_values} missing values (cleaned)")
        
        # Check volume is non-negative
        if (df['volume'] >= 0).all():
            logger.info("✅ All volume values are non-negative")
        else:
            logger.info("❌ Found negative volume values")

    except Exception as e:
        logger.error(f"Error in test_data_validation: {str(e)}")
        raise

def test_timezone_handling():
    """Test timezone handling"""
    logger.info("\n" + "="*60)
    logger.info("🧪 Testing Timezone Handling")
    logger.info("="*60)
    
    api = UnifiedDataAPI()
    
    # Test with different timezone inputs
    logger.info("\n📊 Testing timezone-aware data fetching")
    
    # Naive datetime
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    try:
        df = api.fetch_data('AAPL', start_date=start_date, end_date=end_date, interval='1h')
        if df.index.tz is not None:
            logger.info(f"✅ Data has timezone info: {df.index.tz}")
        else:
            logger.info("❌ Data is missing timezone info")
    except Exception as e:
        logger.info(f"❌ Failed: {e}")


def test_options_data():
    try:
        """Test options chain fetching"""
        logger.info("\n" + "="*60)
        logger.info("🧪 Testing Options Data")
        logger.info("="*60)
    
        api = UnifiedDataAPI()
    
        logger.info("\n📊 Fetching options chain for SPY")
        options = api.get_options_chain('SPY')
    
        if not options.empty:
            logger.info(f"✅ Retrieved {len(options)} options contracts")
        
            # Analyze options
            calls = options[options['type'] == 'call']
            puts = options[options['type'] == 'put']
        
            logger.info(f"   Calls: {len(calls)}, Puts: {len(puts)}")
            logger.info(f"   Strike range: ${options['strike'].min():.0f} - ${options['strike'].max():.0f}")
            logger.info(f"   Expiration: {options['expiration'].iloc[0]}")
        
            # Check for required columns
            required_cols = ['strike', 'bid', 'ask', 'volume', 'openInterest']
            missing_cols = [col for col in required_cols if col not in options.columns]
        
            if not missing_cols:
                logger.info("✅ All required options columns present")
            else:
                logger.info(f"⚠️  Missing columns: {missing_cols}")
        else:
            logger.info("❌ No options data retrieved")

    except Exception as e:
        logger.error(f"Error in test_options_data: {str(e)}")
        raise

def test_market_status():
    try:
        """Test market status functionality"""
        logger.info("\n" + "="*60)
        logger.info("🧪 Testing Market Status")
        logger.info("="*60)
    
        api = UnifiedDataAPI()
    
        status = api.get_market_status()
        logger.info("\n📊 Current Market Status:")
        logger.info(f"   Current time: {status['current_time']}")
        logger.info(f"   Market open: {'Yes' if status['is_open'] else 'No'}")
        logger.info(f"   Extended hours: {'Yes' if status['is_extended_hours'] else 'No'}")
        logger.info(f"   Weekend: {'Yes' if status['is_weekend'] else 'No'}")
        logger.info(f"   Next open: {status['next_open']}")
        logger.info(f"   Next close: {status['next_close']}")

    except Exception as e:
        logger.error(f"Error in test_market_status: {str(e)}")
        raise

def test_parallel_fetching():
    try:
        """Test parallel data fetching"""
        logger.info("\n" + "="*60)
        logger.info("🧪 Testing Parallel Data Fetching")
        logger.info("="*60)
    
        api = UnifiedDataAPI()
    
        symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA', 'JPM']
    
        # Test sequential fetching
        logger.info("\n📊 Sequential fetching...")
        start_time = time.time()
        results_seq = api.fetch_multiple_symbols(symbols, interval='1d', parallel=False)
        seq_time = time.time() - start_time
        logger.info(f"✅ Sequential fetch took {seq_time:.2f} seconds")
    
        # Test parallel fetching
        logger.info("\n📊 Parallel fetching...")
        start_time = time.time()
        results_par = api.fetch_multiple_symbols(symbols, interval='1d', parallel=True)
        par_time = time.time() - start_time
        logger.info(f"✅ Parallel fetch took {par_time:.2f} seconds")
    
        if par_time < seq_time:
            speedup = seq_time / par_time
            logger.info(f"✅ Parallel fetching is {speedup:.1f}x faster!")
    
        # Verify results
        success_count = sum(1 for df in results_par.values() if not df.empty)
        logger.info(f"✅ Successfully fetched {success_count}/{len(symbols)} symbols")

    except APIError as e:
        logger.error(f"API error in test_parallel_fetching: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error in test_parallel_fetching: {str(e)}")
        return None

def run_comprehensive_test():
    try:
        """Run all tests"""
        logger.info("\n" + "="*80)
        logger.info("🚀 COMPREHENSIVE DATA API FIXER TEST")
        logger.info("="*80)
        logger.info("\nThis test demonstrates all the fixes and features implemented:")
        logger.info("1. ✅ yfinance API error handling (JSON parsing, timezone issues)")
        logger.info("2. ✅ Proper Alpaca API integration with error handling")
        logger.info("3. ✅ MinIO data fallback when APIs fail")
        logger.info("4. ✅ Robust data validation and cleaning")
        logger.info("5. ✅ Rate limiting to prevent API throttling")
        logger.info("6. ✅ Caching to reduce API calls")
        logger.info("7. ✅ Unified data interface handling all sources")
        logger.info("8. ✅ Retry logic with exponential backoff")
    
        # Run all tests
        test_basic_functionality()
        test_error_handling()
        test_rate_limiting()
        test_caching()
        test_data_validation()
        test_timezone_handling()
        test_options_data()
        test_market_status()
        test_parallel_fetching()
    
        # Final health check
        logger.info("\n" + "="*60)
        logger.info("🏥 Final System Health Check")
        logger.info("="*60)
    
        api = UnifiedDataAPI()
        health = api.health_check()
    
        logger.info("\n📊 Data Source Status:")
        for source, status in health['sources'].items():
            emoji = "✅" if status.get('status') == 'healthy' else "❌"
            logger.info(f"   {emoji} {source}: {status.get('status', 'unknown')}")
        
        logger.info(f"\n🎯 Overall System Status: {health['overall_status'].upper()}")
    
        logger.info("\n" + "="*80)
        logger.info("✅ COMPREHENSIVE TEST COMPLETED!")
        logger.info("="*80)
        logger.info("\nThe data_api_fixer.py provides a robust, production-ready solution")
        logger.info("for handling all data fetching needs with proper error handling,")
        logger.info("caching, rate limiting, and fallback mechanisms.")
        logger.info("\nIntegrate it into your trading system with confidence! 🚀")


    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in run_comprehensive_test: {str(e)}")
        raise
    run_comprehensive_test()