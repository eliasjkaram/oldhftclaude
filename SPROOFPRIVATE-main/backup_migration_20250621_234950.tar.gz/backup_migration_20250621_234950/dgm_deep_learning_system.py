
#!/usr/bin/env python3
"""
DGM Deep Learning Trading System
===============================

Darwin Gödel Machine enhanced with deep learning for candlestick pattern recognition,
profit optimization, and continuous retraining. Uses minute-by-minute or hourly data
feeds for maximum profitability.

Features:
- Real-time candlestick data processing
- Deep learning models for pattern recognition
- Profit-focused loss functions
- Continuous model retraining
- DGM evolution of neural architectures
- Multi-timeframe analysis
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import numpy as np
import pandas as pd
import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, asdict
import json
import logging
import threading
import time
import warnings
warnings.filterwarnings('ignore')

# Deep Learning imports (using numpy-based implementation for compatibility)
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score
from scipy import signal
import sqlite3

from universal_market_data import get_current_market_data, validate_price


# Technical Analysis
def calculate_technical_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate comprehensive technical indicators"""
    data = df.copy()
    
    # Price-based indicators
    data['SMA_5'] = data['Close'].rolling(window=5).mean()
    data['SMA_10'] = data['Close'].rolling(window=10).mean()
    data['SMA_20'] = data['Close'].rolling(window=20).mean()
    data['EMA_12'] = data['Close'].ewm(span=12).mean()
    data['EMA_26'] = data['Close'].ewm(span=26).mean()
    
    # MACD
    data['MACD'] = data['EMA_12'] - data['EMA_26']
    data['MACD_Signal'] = data['MACD'].ewm(span=9).mean()
    data['MACD_Histogram'] = data['MACD'] - data['MACD_Signal']
    
    # RSI
    delta = data['Close'].diff()
    gain = delta.where(delta > 0, 0).rolling(window=14).mean()
    loss = -delta.where(delta < 0, 0).rolling(window=14).mean()
    rs = gain / loss
    data['RSI'] = 100 - (100 / (1 + rs))
    
    # Bollinger Bands
    data['BB_Middle'] = data['Close'].rolling(window=20).mean()
    bb_std = data['Close'].rolling(window=20).std()
    data['BB_Upper'] = data['BB_Middle'] + (bb_std * 2)
    data['BB_Lower'] = data['BB_Middle'] - (bb_std * 2)
    data['BB_Width'] = (data['BB_Upper'] - data['BB_Lower']) / data['BB_Middle']
    data['BB_Position'] = (data['Close'] - data['BB_Lower']) / (data['BB_Upper'] - data['BB_Lower'])
    
    # Stochastic
    low_min = data['Low'].rolling(window=14).min()
    high_max = data['High'].rolling(window=14).max()
    data['Stoch_K'] = 100 * (data['Close'] - low_min) / (high_max - low_min)
    data['Stoch_D'] = data['Stoch_K'].rolling(window=3).mean()
    
    # Volume indicators
    data['Volume_SMA'] = data['Volume'].rolling(window=20).mean()
    data['Volume_Ratio'] = data['Volume'] / data['Volume_SMA']
    
    # Price momentum
    data['ROC_5'] = data['Close'].pct_change(periods=5) * 100
    data['ROC_10'] = data['Close'].pct_change(periods=10) * 100
    
    # Volatility
    data['ATR'] = calculate_atr(data)
    data['Volatility'] = data['Close'].rolling(window=20).std() / data['Close'].rolling(window=20).mean()
    
    # Support/Resistance levels
    data['Support'] = data['Low'].rolling(window=20).min()
    data['Resistance'] = data['High'].rolling(window=20).max()
    data['Support_Distance'] = (data['Close'] - data['Support']) / data['Close']
    data['Resistance_Distance'] = (data['Resistance'] - data['Close']) / data['Close']
    
    return data

def calculate_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Calculate Average True Range"""
    high_low = df['High'] - df['Low']
high_close = np.abs(df["High"] - df["Close"].shift())
low_close = np.abs(df["Low"] - df["Close"].shift())
    
true_range = np.maximum(high_low, np.maximum(high_close, low_close))
    return true_range.rolling(window=period).mean()

def identify_candlestick_patterns(df: pd.DataFrame) -> pd.DataFrame:
    """Identify candlestick patterns"""
    data = df.copy()
    
    # Basic candle properties
    data['Body_Size'] = abs(data['Close'] - data['Open'])
    data['Upper_Shadow'] = data['High'] - np.maximum(data['Close'], data['Open'])
    data['Lower_Shadow'] = np.minimum(data['Close'], data['Open']) - data['Low']
    data['Total_Range'] = data['High'] - data['Low']
    
    # Relative sizes
    data['Body_Ratio'] = data['Body_Size'] / data['Total_Range']
    data['Upper_Shadow_Ratio'] = data['Upper_Shadow'] / data['Total_Range']
    data['Lower_Shadow_Ratio'] = data['Lower_Shadow'] / data['Total_Range']
    
    # Candle direction
    data['Bullish'] = (data['Close'] > data['Open']).astype(int)
    data['Bearish'] = (data['Close'] < data['Open']).astype(int)
    data['Doji'] = (abs(data['Close'] - data['Open']) < data['Total_Range'] * 0.1).astype(int)
    
    # Pattern identification
    data['Hammer'] = ((data['Lower_Shadow'] > data['Body_Size'] * 2) &)
                     (data['Upper_Shadow'] < data['Body_Size'] * 0.5).astype(int)
    
    data['Shooting_Star'] = ((data['Upper_Shadow'] > data['Body_Size'] * 2) &)
                            (data['Lower_Shadow'] < data['Body_Size'] * 0.5).astype(int)
    
    data['Engulfing_Bull'] = ((data['Bullish'] == 1) &)
                             (data['Bearish'].shift(1) == 1) &
                             (data['Open'] < data['Close'].shift(1) &)
                             (data['Close'] > data['Open'].shift(1)).astype(int)
    
    data['Engulfing_Bear'] = ((data['Bearish'] == 1) &)
                             (data['Bullish'].shift(1) == 1) &
                             (data['Open'] > data['Close'].shift(1) &)
                             (data['Close'] < data['Open'].shift(1)).astype(int)
    
    return data

@dataclass
class TradingSignal:
    """Trading signal with profit focus"""
    timestamp: datetime
    signal_type: str  # 'BUY', 'SELL', 'HOLD'
    confidence: float
    predicted_profit: float
    risk_reward_ratio: float
    stop_loss: float
    take_profit: float
    features: Dict[str, float]
    model_prediction: float

@dataclass
class ModelPerformance:
    """Model performance metrics focused on profitability"""
    total_trades: int
    profitable_trades: int
    total_profit: float
    max_profit: float
    max_loss: float
    win_rate: float
    profit_factor: float
    sharpe_ratio: float
    max_drawdown: float
    average_profit_per_trade: float
    
    def to_score(self) -> float:
        """Convert to single profitability score"""
        return ()
            self.win_rate * 0.25 +
            min(self.profit_factor / 3.0, 1.0) * 0.25 +
            min(self.total_profit / 1000, 1.0) * 0.30 +
            min(self.sharpe_ratio / 3.0, 1.0) * 0.20
        )

class SimpleNeuralNetwork:
    """Simplified neural network implementation focused on profit prediction"""
    
    def __init__(self, input_size: int, hidden_sizes: List[int], output_size: int):
        self.layers = []
        layer_sizes = [input_size] + hidden_sizes + [output_size]
        
        # Initialize weights and biases
        for i in range(len(layer_sizes) - 1):
            weight = np.random.randn(layer_sizes[i], layer_sizes[i + 1]) * 0.1
            bias = np.zeros((1, layer_sizes[i + 1])
            self.layers.append({'weights': weight, 'bias': bias})
        
        self.scaler = StandardScaler()
        self.is_fitted = False
    
    def relu(self, x):
        """ReLU activation function"""
        return np.maximum(0, x)
    
    def relu_derivative(self, x):
        """ReLU derivative"""
        return (x > 0).astype(float)
    
    def sigmoid(self, x):
        """Sigmoid activation function"""
        return 1 / (1 + np.exp(-np.clip(x, -500, 500))
    
    def sigmoid_derivative(self, x):
        """Sigmoid derivative"""
        s = self.sigmoid(x)
        return s * (1 - s)
    
    def forward(self, X):
        """Forward propagation"""
        if not self.is_fitted:
            X = self.scaler.fit_transform(X)
            self.is_fitted = True
        else:
            X = self.scaler.transform(X)
        
        activations = [X]
        
        for i, layer in enumerate(self.layers):
            z = np.dot(activations[-1], layer['weights']) + layer['bias']
            
            # Use ReLU for hidden layers, sigmoid for output
            if i < len(self.layers) - 1:
                a = self.relu(z)
            else:
                a = self.sigmoid(z)
            
            activations.append(a)
        
        return activations
    
    def predict(self, X):
        """Make predictions"""
        activations = self.forward(X)
        return activations[-1]
    
    def profit_focused_loss(self, y_true, y_pred, profits):
        """Custom loss function that prioritizes profitable predictions"""
        # Standard binary cross-entropy
        base_loss = -np.mean(y_true * np.log(y_pred + 1e-15) +)
                           (1 - y_true) * np.log(1 - y_pred + 1e-15)
        
        # Profit penalty: heavily penalize wrong predictions on profitable trades
        profit_penalty = 0
        for i in range(len(y_true):
            if profits[i] > 0 and y_pred[i] < 0.5:  # Missed profitable opportunity
                profit_penalty += abs(profits[i]) * 2
            elif profits[i] < 0 and y_pred[i] > 0.5:  # False positive on losing trade
                profit_penalty += abs(profits[i]) * 1
        
        return base_loss + profit_penalty / len(y_true)
    
    def train(self, X, y, profits, epochs=100, learning_rate=0.01):
        """Train the network with profit-focused loss"""
        losses = []
        
        for epoch in range(epochs):
            # Forward propagation
            activations = self.forward(X)
            
            # Calculate loss
            loss = self.profit_focused_loss(y, activations[-1], profits)
            losses.append(loss)
            
            # Backward propagation
            self.backward(activations, y, profits, learning_rate)
            
            if epoch % 20 == 0:
                print(f"Epoch {epoch}, Loss: {loss:.4f}")
        
        return losses
    
    def backward(self, activations, y, profits, learning_rate):
        """Backward propagation with profit weighting"""
        m = y.shape[0]
        
        # Calculate output layer error with profit weighting
        output_error = activations[-1] - y
        
        # Weight errors by profit magnitude
        profit_weights = np.abs(profits).reshape(-1, 1) / (np.max(np.abs(profits) + 1e-8)
        profit_weights = np.clip(profit_weights, 0.5, 3.0)  # Limit weight range
        output_error *= profit_weights
        
        # Backpropagate errors
        errors = [output_error]
        
        for i in range(len(self.layers) - 1, 0, -1):
            error = np.dot(errors[0], self.layers[i]['weights'].T)
            
            # Apply activation derivative
            if i > 0:  # Hidden layers use ReLU
                z = np.dot(activations[i-1], self.layers[i-1]['weights']) + self.layers[i-1]['bias']
                error *= self.relu_derivative(z)
            
            errors.insert(0, error)
        
        # Update weights and biases
        for i in range(len(self.layers):
            dW = np.dot(activations[i].T, errors[i]) / m
            db = np.sum(errors[i], axis=0, keepdims=True) / m
            
            self.layers[i]['weights'] -= learning_rate * dW
            self.layers[i]['bias'] -= learning_rate * db

class DeepLearningTradingModel:
    """Deep learning model for profitable trading signal generation"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.models = {}
        self.scalers = {}
        self.performance_history = []
        
        # Model architectures for different timeframes
        self.architectures = {}
            'minute': [50, 30, 20, 1],
            'hourly': [40, 25, 15, 1],
            'daily': [30, 20, 10, 1]
        }
        
        # Feature configuration
        self.feature_columns = []
        self.target_column = 'future_profit'
        
        # Training configuration
        self.sequence_length = config.get('sequence_length', 20)
        self.prediction_horizon = config.get('prediction_horizon', 5)
        self.min_profit_threshold = config.get('min_profit_threshold', 0.02)
        
        self.setup_logging()
    
    def setup_logging(self):
        """Setup logging"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def prepare_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare comprehensive feature set for deep learning"""
        data = df.copy()
        
        # Add technical indicators
        data = calculate_technical_indicators(data)
        
        # Add candlestick patterns
        data = identify_candlestick_patterns(data)
        
        # Add time-based features
        data['Hour'] = data.index.hour if hasattr(data.index, 'hour') else 0
        data['DayOfWeek'] = data.index.dayofweek if hasattr(data.index, 'dayofweek') else 0
        data['Month'] = data.index.month if hasattr(data.index, 'month') else 1
        
        # Add price action features
        data['Price_Change'] = data['Close'].pct_change()
        data['Volume_Price_Trend'] = data['Volume'] * data['Price_Change']
        data['High_Low_Ratio'] = data['High'] / data['Low']
        data['Open_Close_Ratio'] = data['Open'] / data['Close']
        
        # Add momentum features
        for period in [3, 5, 10, 20]:
            data[f'Momentum_{period}'] = data['Close'] / data['Close'].shift(period) - 1
            data[f'Volume_Momentum_{period}'] = data['Volume'] / data['Volume'].shift(period) - 1
        
        # Add volatility features
        for period in [5, 10, 20]:
            data[f'Volatility_{period}'] = data['Close'].rolling(period).std() / data['Close'].rolling(period).mean()
        
        return data
    
    def calculate_future_profits(self, df: pd.DataFrame, horizon: int = 5) -> pd.Series:
        """Calculate future profits for supervised learning"""
        future_prices = df['Close'].shift(-horizon)
        current_prices = df['Close']
        
        # Calculate profit percentage
        profits = (future_prices - current_prices) / current_prices
        
        return profits.fillna(0)
    
    def create_sequences(self, data: np.ndarray, sequence_length: int) -> np.ndarray:
        """Create sequences for time series prediction"""
        sequences = []
        for i in range(len(data) - sequence_length + 1):
            sequences.append(data[i:i + sequence_length])
        return np.array(sequences)
    
    def prepare_training_data(self, df: pd.DataFrame, timeframe: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Prepare training data with profit targets"""
        # Prepare features
        featured_data = self.prepare_features(df)
        
        # Calculate future profits
        future_profits = self.calculate_future_profits(featured_data, self.prediction_horizon)
        
        # Select feature columns (exclude non-numeric and target columns)
        exclude_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
        feature_cols = [col for col in featured_data.columns]
                       if col not in exclude_cols and 
                       featured_data[col].dtype in ['float64', 'int64']]
        
        self.feature_columns = feature_cols
        
        # Prepare feature matrix
        features = featured_data[feature_cols].fillna(0)
        
        # Create binary targets (profitable vs non-profitable)
        binary_targets = (future_profits > self.min_profit_threshold).astype(int)
        
        # Remove rows with NaN targets
        valid_mask = ~(np.isnan(future_profits) | np.isnan(binary_targets)
        features = features[valid_mask]
        binary_targets = binary_targets[valid_mask]
        future_profits = future_profits[valid_mask]
        
        self.logger.info(f"Prepared {len(features)} training samples with {len(feature_cols)} features")
        self.logger.info(f"Profitable trades: {np.sum(binary_targets)} ({np.mean(binary_targets):.1%})")
        
        return features.values, binary_targets.values, future_profits.values
    
    def train_model(self, df: pd.DataFrame, timeframe: str) -> ModelPerformance:
        """Train deep learning model for specific timeframe"""
        self.logger.info(f"Training model for {timeframe} timeframe")
        
        # Prepare training data
        X, y, profits = self.prepare_training_data(df, timeframe)
        
        if len(X) < 100:
            self.logger.warning(f"Insufficient data for training ({len(X)} samples)")
            return ModelPerformance(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        
        # Split data (80% train, 20% test)
        split_idx = int(len(X) * 0.8)
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        profits_train, profits_test = profits[:split_idx], profits[split_idx:]
        
        # Create and train model
        input_size = X.shape[1]
        hidden_sizes = self.architectures[timeframe][:-1]
        output_size = self.architectures[timeframe][-1]
        
        model = SimpleNeuralNetwork(input_size, hidden_sizes, output_size)
        
        # Train with profit-focused approach
        self.logger.info("Starting training...")
        losses = model.train(X_train, y_train.reshape(-1, 1), profits_train, 
                           epochs=200, learning_rate=0.01)
        
        # Evaluate model
        predictions = model.predict(X_test)
        binary_predictions = (predictions > 0.5).astype(int).flatten()
        
        # Calculate performance metrics
        performance = self.calculate_performance_metrics()
            y_test, binary_predictions, profits_test
        )
        
        # Store model
        self.models[timeframe] = model
        
        self.logger.info(f"Model training completed. Performance score: {performance.to_score():.3f}")
        return performance
    
    def calculate_performance_metrics(self, y_true: np.ndarray, y_pred: np.ndarray, 
                                    profits: np.ndarray) -> ModelPerformance:
        """Calculate comprehensive performance metrics"""
        # Basic metrics
        total_trades = len(y_true)
        profitable_trades = np.sum(y_true)
        
        # Profit calculation based on predictions
        predicted_profits = []
        for i in range(len(y_pred):
            if y_pred[i] == 1:  # Model predicted profitable
                predicted_profits.append(profits[i])
        
        if len(predicted_profits) == 0:
            return ModelPerformance(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        
        total_profit = sum(predicted_profits)
        max_profit = max(predicted_profits) if predicted_profits else 0
        max_loss = min(predicted_profits) if predicted_profits else 0
        
        # Win rate on predictions
        correct_predictions = np.sum(y_true == y_pred)
        accuracy = correct_predictions / total_trades if total_trades > 0 else 0
        
        # Trading-specific metrics
        profitable_predictions = [p for p in predicted_profits if p > 0]
        losing_predictions = [p for p in predicted_profits if p < 0]
        
        win_rate = len(profitable_predictions) / len(predicted_profits) if predicted_profits else 0
        
        total_gains = sum(profitable_predictions) if profitable_predictions else 0
        total_losses = abs(sum(losing_predictions) if losing_predictions else 1)
        profit_factor = total_gains / total_losses if total_losses > 0 else 0
        
        # Risk metrics
        if len(predicted_profits) > 1:
            returns_array = np.array(predicted_profits)
            sharpe_ratio = np.mean(returns_array) / (np.std(returns_array) + 1e-8) * np.sqrt(252)
            
            # Calculate drawdown
            cumulative = np.cumsum(returns_array)
            running_max = np.maximum.accumulate(cumulative)
            drawdown = cumulative - running_max
            max_drawdown = abs(np.min(drawdown) if len(drawdown) > 0 else 0)
        else:
            sharpe_ratio = 0
            max_drawdown = 0
        
        avg_profit_per_trade = total_profit / len(predicted_profits) if predicted_profits else 0
        
        return ModelPerformance()
            total_trades=len(predicted_profits),
            profitable_trades=len(profitable_predictions),
            total_profit=total_profit,
            max_profit=max_profit,
            max_loss=max_loss,
            win_rate=win_rate,
            profit_factor=profit_factor,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            average_profit_per_trade=avg_profit_per_trade
        )
    
    def generate_signal(self, df: pd.DataFrame, timeframe: str) -> TradingSignal:
        """Generate trading signal using trained model"""
        if timeframe not in self.models:
            return TradingSignal()
                timestamp=datetime.now(),
                signal_type='HOLD',
                confidence=0.0,
                predicted_profit=0.0,
                risk_reward_ratio=0.0,
                stop_loss=0.0,
                take_profit=0.0,
                features={},
                model_prediction=0.0
            )
        
        model = self.models[timeframe]
        
        # Prepare current features
        featured_data = self.prepare_features(df)
        
        if len(featured_data) < self.sequence_length:
            return TradingSignal()
                timestamp=datetime.now(),
                signal_type='HOLD',
                confidence=0.0,
                predicted_profit=0.0,
                risk_reward_ratio=0.0,
                stop_loss=0.0,
                take_profit=0.0,
                features={},
                model_prediction=0.0
            )
        
        # Get latest features
        latest_features = featured_data[self.feature_columns].fillna(0).iloc[-1:].values
        
        # Make prediction
        prediction = model.predict(latest_features)[0][0]
        
        # Determine signal
        confidence = prediction
        if prediction > 0.7:
            signal_type = 'BUY'
        elif prediction < 0.3:
            signal_type = 'SELL'
        else:
            signal_type = 'HOLD'
        
        # Calculate risk management levels
        current_price = df['Close'].iloc[-1]
        atr = calculate_atr(df).iloc[-1]
        
        if signal_type == 'BUY':
            stop_loss = current_price - (2 * atr)
            take_profit = current_price + (3 * atr)
            predicted_profit = (take_profit - current_price) / current_price * confidence
        elif signal_type == 'SELL':
            stop_loss = current_price + (2 * atr)
            take_profit = current_price - (3 * atr)
            predicted_profit = (current_price - take_profit) / current_price * confidence
        else:
            stop_loss = current_price
            take_profit = current_price
            predicted_profit = 0.0
        
        risk_reward_ratio = abs(take_profit - current_price) / abs(stop_loss - current_price) if abs(stop_loss - current_price) > 0 else 0
        
        # Collect feature values for analysis
        feature_dict = {}
        for i, col in enumerate(self.feature_columns):
            if i < len(latest_features[0]):
                feature_dict[col] = float(latest_features[0][i])
        
        return TradingSignal()
            timestamp=datetime.now(),
            signal_type=signal_type,
            confidence=confidence,
            predicted_profit=predicted_profit,
            risk_reward_ratio=risk_reward_ratio,
            stop_loss=stop_loss,
            take_profit=take_profit,
            features=feature_dict,
            model_prediction=prediction
        )

class DGMDeepLearningEvolution:
    """DGM system for evolving deep learning trading models"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.population_size = config.get('population_size', 8)
        self.generations = config.get('generations', 20)
        self.mutation_rate = config.get('mutation_rate', 0.3)
        
        # Model population
        self.model_population = []
        self.best_model = None
        self.generation = 0
        
        # Data management
        self.historical_data = {}
        self.current_data = {}
        
        # Performance tracking
        self.evolution_history = []
        
        self.setup_logging()
        self.initialize_population()
    
    def setup_logging(self):
        """Setup logging"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def initialize_population(self):
        """Initialize population of deep learning models"""
        self.logger.info("Initializing DGM deep learning population")
        
        for i in range(self.population_size):
            # Create model with random configuration
            config = {}
                'sequence_length': np.random.randint(10, 30),
                'prediction_horizon': np.random.randint(3, 10),
                'min_profit_threshold': np.random.uniform(0.01, 0.05),
                'learning_rate': np.random.uniform(0.005, 0.02),
                'hidden_layers': np.random.randint(2, 5)
            }
            
            model = DeepLearningTradingModel(config)
            model.name = f"DL_Model_{i}"
            model.generation = 0
            
            self.model_population.append(model)
        
        self.logger.info(f"Initialized {len(self.model_population)} deep learning models")
    
    def download_market_data(self, symbols: List[str], timeframe: str = '1h') -> Dict[str, pd.DataFrame]:
        """Download real-time market data"""
        self.logger.info(f"Downloading {timeframe} data for {len(symbols)} symbols")
        
        data = {}
        
        # Determine period based on timeframe
        if timeframe == '1m':
            period = '7d'  # 7 days of minute data
        elif timeframe == '1h':
            period = '60d'  # 60 days of hourly data
        else:
            period = '2y'   # 2 years of daily data
        
        for symbol in symbols:
            try:
                ticker = YFinanceWrapper().get_ticker(symbol)
                df = ticker.history(period=period, interval=timeframe)
                
                if len(df) > 100:  # Minimum data requirement
                    data[symbol] = df
                    self.logger.info(f"Downloaded {len(df)} {timeframe} bars for {symbol}")
                else:
                    self.logger.warning(f"Insufficient data for {symbol}")
                    
            except Exception as e:
                self.logger.error(f"Failed to download {symbol}: {e}")
        
        return data
    
    def evaluate_model_performance(self, model: DeepLearningTradingModel, 
                                 data: Dict[str, pd.DataFrame], timeframe: str) -> float:
        """Evaluate model performance across multiple symbols"""
        total_score = 0
        symbol_count = 0
        
        for symbol, df in data.items():
            try:
                # Train model on this symbol
                performance = model.train_model(df, timeframe)
                
                # Add performance to model history
                model.performance_history.append({)
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'performance': performance,
                    'timestamp': datetime.now()
                })
                
                total_score += performance.to_score()
                symbol_count += 1
                
                self.logger.debug(f"Model {model.name} on {symbol}: {performance.to_score():.3f}")
                
            except Exception as e:
                self.logger.error(f"Error evaluating {model.name} on {symbol}: {e}")
        
        average_score = total_score / symbol_count if symbol_count > 0 else 0
        self.logger.info(f"Model {model.name} average score: {average_score:.3f}")
        
        return average_score
    
    def mutate_model(self, parent_model: DeepLearningTradingModel) -> DeepLearningTradingModel:
        """Create mutated version of a model"""
        new_config = parent_model.config.copy()
        
        # Mutate configuration parameters
        if np.random.random() < 0.3:
            new_config['sequence_length'] = max(5, min(50, 
                int(new_config['sequence_length'] * np.random.uniform(0.7, 1.3))
        
        if np.random.random() < 0.3:
            new_config['prediction_horizon'] = max(1, min(20,
                int(new_config['prediction_horizon'] * np.random.uniform(0.7, 1.3))
        
        if np.random.random() < 0.3:
            new_config['min_profit_threshold'] = max(0.005, min(0.1,
                new_config['min_profit_threshold'] * np.random.uniform(0.7, 1.3))
        
        # Create new model
        mutated_model = DeepLearningTradingModel(new_config)
        mutated_model.name = f"{parent_model.name}_mut_gen{self.generation}"
        mutated_model.generation = self.generation
        
        return mutated_model
    
    def crossover_models(self, parent1: DeepLearningTradingModel, 
                        parent2: DeepLearningTradingModel) -> DeepLearningTradingModel:
        """Create offspring by crossing over two parent models"""
        new_config = {}
        
        # Blend configurations
        for key in parent1.config:
            if key in parent2.config:
                if isinstance(parent1.config[key], (int, float):)
                    alpha = np.random.uniform(0.3, 0.7)
                    new_config[key] = alpha * parent1.config[key] + (1 - alpha) * parent2.config[key]
                    
                    # Ensure integer values remain integers
                    if isinstance(parent1.config[key], int):
                        new_config[key] = int(new_config[key])
                else:
                    new_config[key] = np.random.choice([parent1.config[key], parent2.config[key]])
            else:
                new_config[key] = parent1.config[key]
        
        # Create offspring
        offspring = DeepLearningTradingModel(new_config)
        offspring.name = f"cross_{parent1.name.split('_')[0]}_{parent2.name.split('_')[0]}_gen{self.generation}"
        offspring.generation = self.generation
        
        return offspring
    
    def tournament_selection(self, tournament_size: int = 3) -> DeepLearningTradingModel:
        """Tournament selection for parent selection"""
        contestants = np.random.choice(self.model_population, tournament_size, replace=False)
        
        best_model = None
        best_score = -float('inf')
        
        for model in contestants:
            if model.performance_history:
                # Calculate average performance across all evaluations
                scores = [perf['performance'].to_score() for perf in model.performance_history]
                avg_score = np.mean(scores)
                
                if avg_score > best_score:
                    best_score = avg_score
                    best_model = model
        
        return best_model or np.random.choice(contestants)
    
    def evolve_generation(self, market_data: Dict[str, pd.DataFrame], timeframe: str):
        """Evolve one generation of deep learning models"""
        self.logger.info(f"Evolving generation {self.generation}")
        
        # Evaluate current population
        model_scores = []
        for model in self.model_population:
            score = self.evaluate_model_performance(model, market_data, timeframe)
            model_scores.append((model, score)
        
        # Sort by performance
        model_scores.sort(key=lambda x: x[1], reverse=True)
        self.model_population = [model for model, score in model_scores]
        
        # Update best model
        if model_scores:
            self.best_model = model_scores[0][0]
            best_score = model_scores[0][1]
            self.logger.info(f"Best model: {self.best_model.name} (score: {best_score:.3f})")
        
        # Record evolution metrics
        scores = [score for model, score in model_scores]
        self.evolution_history.append({)
            'generation': self.generation,
            'best_score': max(scores) if scores else 0,
            'average_score': np.mean(scores) if scores else 0,
            'std_score': np.std(scores) if scores else 0,
            'population_size': len(self.model_population)
        })
        
        # Create next generation
        new_population = []
        
        # Elitism - keep top 25%
        elite_count = max(1, self.population_size // 4)
        new_population.extend(self.model_population[:elite_count])
        
        # Generate offspring
        while len(new_population) < self.population_size:
            if np.random.random() < 0.7:  # 70% mutation
                parent = self.tournament_selection()
                offspring = self.mutate_model(parent)
                new_population.append(offspring)
            else:  # 30% crossover
                parent1 = self.tournament_selection()
                parent2 = self.tournament_selection()
                if parent1 != parent2:
                    offspring = self.crossover_models(parent1, parent2)
                    new_population.append(offspring)
        
        self.model_population = new_population[:self.population_size]
        self.generation += 1
    
    def run_evolution(self, symbols: List[str], timeframe: str = '1h'):
        """Run complete DGM evolution process"""
        self.logger.info(f"Starting DGM deep learning evolution for {self.generations} generations")
        
        # Download market data
        market_data = self.download_market_data(symbols, timeframe)
        
        if not market_data:
            self.logger.error("No market data available")
            return
        
        self.logger.info(f"Downloaded data for {len(market_data)} symbols")
        
        # Run evolution
        for gen in range(self.generations):
            start_time = time.time()
            
            self.evolve_generation(market_data, timeframe)
            
            generation_time = time.time() - start_time
            self.logger.info(f"Generation {gen} completed in {generation_time:.1f} seconds")
            
            # Print progress
            if len(self.evolution_history) > 0:
                current_metrics = self.evolution_history[-1]
                self.logger.info(f"Generation {gen} - Best: {current_metrics['best_score']:.3f}, ")
                               f"Average: {current_metrics['average_score']:.3f}")
        
        self.print_final_results()
    
    def print_final_results(self):
        """Print final evolution results"""
        self.logger.info("\n" + "="*60)
        self.logger.info("DGM DEEP LEARNING EVOLUTION RESULTS")
        self.logger.info("="*60)
        
        if self.best_model:
            self.logger.info(f"Best Model: {self.best_model.name}")
            self.logger.info(f"Configuration: {self.best_model.config}")
            
            if self.best_model.performance_history:
                recent_perf = self.best_model.performance_history[-1]['performance']
                self.logger.info(f"Performance:")
                self.logger.info(f"  Total Profit: {recent_perf.total_profit:.4f}")
                self.logger.info(f"  Win Rate: {recent_perf.win_rate:.1%}")
                self.logger.info(f"  Profit Factor: {recent_perf.profit_factor:.2f}")
                self.logger.info(f"  Sharpe Ratio: {recent_perf.sharpe_ratio:.2f}")
                self.logger.info(f"  Max Drawdown: {recent_perf.max_drawdown:.1%}")
        
        # Evolution progress
        if self.evolution_history:
            self.logger.info(f"\nEvolution Progress:")
            self.logger.info("Gen | Best Score | Avg Score | Improvement")
            self.logger.info("-" * 45)
            
            for i, record in enumerate(self.evolution_history):
                improvement = ""
                if i > 0:
                    prev_best = self.evolution_history[i-1]['best_score']
                    current_best = record['best_score']
                    if prev_best > 0:
                        improvement = f"{((current_best - prev_best) / prev_best * 100):+.1f}%"
                
                self.logger.info(f"{record['generation']:3d} |   {record['best_score']:.3f}    |  {record['average_score']:.3f}   | {improvement}")

def run_dgm_deep_learning_demo():
    """Run DGM deep learning demonstration"""
    print("🧠 DGM Deep Learning Trading System")
    print("=" * 45)
    print("Self-Improving AI with Neural Networks and Real-Time Data")
    print()
    
    # Configuration
    config = {}
        'population_size': 6,
        'generations': 10,
        'mutation_rate': 0.3,
        'timeframe': '1h',  # hourly data for faster demo
        'symbols': ['SPY', 'QQQ', 'AAPL', 'MSFT', 'TSLA']
    }
    
    # Create DGM system
    dgm_dl = DGMDeepLearningEvolution(config)
    
    print(f"🔬 Population Size: {config['population_size']}")
    print(f"🧬 Generations: {config['generations']}")
    print(f"📊 Timeframe: {config['timeframe']}")
    print(f"📈 Symbols: {', '.join(config['symbols'])}")
    print()
    
    # Run evolution
    try:
        dgm_dl.run_evolution(config['symbols'], config['timeframe'])
        
        print("\n🏆 DEEP LEARNING EVOLUTION COMPLETE!")
        print("=" * 50)
        
        if dgm_dl.best_model and dgm_dl.best_model.performance_history:
            best_perf = dgm_dl.best_model.performance_history[-1]['performance']
            print(f"🥇 Best Model: {dgm_dl.best_model.name}")
            print(f"💰 Total Profit: {best_perf.total_profit:.4f}")
            print(f"🎯 Win Rate: {best_perf.win_rate:.1%}")
            print(f"⚡ Profit Factor: {best_perf.profit_factor:.2f}")
            print(f"📊 Performance Score: {best_perf.to_score():.3f}")
        
        if dgm_dl.evolution_history:
            final_metrics = dgm_dl.evolution_history[-1]
            initial_metrics = dgm_dl.evolution_history[0]
            total_improvement = ((final_metrics['best_score'] - initial_metrics['best_score']) /)
                               initial_metrics['best_score'] * 100) if initial_metrics['best_score'] > 0 else 0
            
            print(f"📈 Total Improvement: {total_improvement:+.1f}%")
            print(f"🔬 Final Best Score: {final_metrics['best_score']:.3f}")
        
    except Exception as e:
        print(f"❌ Error during evolution: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_dgm_deep_learning_demo()