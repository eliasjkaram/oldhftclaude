#!/usr/bin/env python3
"""
START PAPER TRADING WITH ALPACA
================================
Use Alpaca's paper trading API for real testing with virtual money.
No demo mode needed - this IS the real system with paper money!
"""

import os
import sys
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def check_paper_credentials():
    """Check if paper trading credentials are set"""
    api_key = os.getenv('ALPACA_API_KEY')
    api_secret = os.getenv('ALPACA_API_SECRET')
    
    if not api_key or not api_secret or api_key == 'your_api_key_here':
        print("❌ Alpaca paper trading credentials not found!")
        print("\n📝 To set up paper trading:")
        print("1. Go to https://alpaca.markets/")
        print("2. Sign up for a free account")
        print("3. Get your PAPER trading API keys")
        print("4. Create a .env file with:")
        print("\nALPACA_API_KEY=your_paper_api_key")
        print("ALPACA_API_SECRET=your_paper_api_secret")
        print("ALPACA_PAPER_TRADING=true")
        return False
    
    # Ensure paper trading is enabled
    if os.getenv('ALPACA_PAPER_TRADING', 'true').lower() != 'true':
        print("⚠️  WARNING: ALPACA_PAPER_TRADING is not set to true!")
        print("This would use REAL money. Setting to paper mode for safety.")
        os.environ['ALPACA_PAPER_TRADING'] = 'true'
    
    return True

def test_paper_connection():
    """Test connection to Alpaca paper trading"""
    try:
        from alpaca.trading.client import TradingClient
        
        api_key = os.getenv('ALPACA_API_KEY')
        api_secret = os.getenv('ALPACA_API_SECRET')
        
        # Connect to paper trading
        trading_client = TradingClient(api_key, api_secret, paper=True)
        account = trading_client.get_account()
        
        print("✅ Connected to Alpaca Paper Trading!")
        print(f"\n💰 Paper Account Status:")
        print(f"   Account Value: ${float(account.portfolio_value):,.2f}")
        print(f"   Buying Power: ${float(account.buying_power):,.2f}")
        print(f"   Cash: ${float(account.cash):,.2f}")
        print(f"   Pattern Day Trader: {'Yes' if account.pattern_day_trader else 'No'}")
        
        # Test market data
        from universal_market_data import get_current_market_data
        data = get_current_market_data(['AAPL'])
        print(f"\n📊 Market Data Test:")
        print(f"   AAPL: ${data['AAPL']['price']:.2f} ✅")
        
        return True
        
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

def start_ai_trading_system():
    """Start the AI trading system with paper money"""
    print("\n🚀 Starting AI Trading System with Paper Money...")
    print("=" * 60)
    
    # Import and run the AI discovery system
    try:
        from fix_ai_discovery_system import main as run_ai_system
        print("✅ AI Discovery System loaded")
        print("✅ Using REAL market data from Alpaca")
        print("✅ Trading with PAPER money (virtual)")
        print("✅ All strategies active")
        print("\n🤖 AI Models:")
        print("   • DeepSeek R1 - Active")
        print("   • Gemini 2.5 - Active")
        print("   • NVIDIA Nemotron - Active")
        print("   • Risk Manager - Active")
        
        print("\n📈 Starting trading...")
        print("=" * 60)
        
        # Run the actual AI trading system
        run_ai_system()
        
    except ImportError:
        print("❌ Could not import AI trading system")
        print("Running standalone paper trading monitor instead...")
        
        # Fallback: Run a simple paper trading monitor
        import time
        from alpaca.trading.client import TradingClient
        from alpaca.trading.requests import MarketOrderRequest
        from alpaca.trading.enums import OrderSide, TimeInForce
        
        api_key = os.getenv('ALPACA_API_KEY')
        api_secret = os.getenv('ALPACA_API_SECRET')
        trading_client = TradingClient(api_key, api_secret, paper=True)
        
        print("\n📊 Paper Trading Active - Monitoring Account...")
        
        while True:
            try:
                account = trading_client.get_account()
                positions = trading_client.get_all_positions()
                
                os.system('clear' if os.name == 'posix' else 'cls')
                print("=" * 60)
                print("📊 ALPACA PAPER TRADING - LIVE MONITOR")
                print("=" * 60)
                print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"\nAccount Value: ${float(account.portfolio_value):,.2f}")
                print(f"Positions: {len(positions)}")
                
                if positions:
                    print("\nCurrent Positions:")
                    for pos in positions:
                        print(f"  {pos.symbol}: {pos.qty} shares @ ${float(pos.avg_entry_price):.2f}")
                
                print("\nPress Ctrl+C to stop")
                time.sleep(5)
                
            except KeyboardInterrupt:
                print("\n\n✅ Paper trading monitor stopped")
                break
            except Exception as e:
                print(f"Error: {e}")
                time.sleep(10)

def main():
    print("=" * 80)
    print("🏦 ALPACA PAPER TRADING SYSTEM")
    print("=" * 80)
    print("Real market data + Virtual money = Perfect testing environment!")
    print("=" * 80)
    
    # Step 1: Check credentials
    if not check_paper_credentials():
        return
    
    # Step 2: Test connection
    print("\n🔌 Testing Alpaca paper trading connection...")
    if not test_paper_connection():
        return
    
    # Step 3: Start trading
    print("\n" + "=" * 80)
    print("✅ READY TO START PAPER TRADING!")
    print("=" * 80)
    print("\nThis will:")
    print("  • Use REAL market data")
    print("  • Execute trades with VIRTUAL money")
    print("  • Run the same AI strategies as production")
    print("  • Show real-time performance")
    
    response = input("\n🚀 Start paper trading now? (y/n): ")
    if response.lower() == 'y':
        start_ai_trading_system()
    else:
        print("\n📝 To start later, run: python start_paper_trading.py")

if __name__ == "__main__":
    main()