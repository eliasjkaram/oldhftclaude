#!/usr/bin/env python3
"""
V27 ML Model Training Pipeline
Comprehensive training, validation, and evaluation pipeline for ML trading models
"""

import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, get_realistic_price

warnings.filterwarnings('ignore')

from v27_advanced_ml_models import ()
    MetaLearningEnsemble, 
    LSTMTradingModel,
    TransformerTradingModel,
    CNNTradingModel,
    XGBoostTradingModel,
    AdvancedFeatureEngineering
)

class MLTrainingPipeline:
    """Complete ML training and evaluation pipeline"""
    
    def __init__(self):
        # Load configuration
        with open('alpaca_config.json', 'r') as f:
            config = json.load(f)
        
        self.client = TradingClient()
            config.get('paper_api_key'),
            config.get('paper_secret_key'),
            config.get('paper_base_url')
        )
        
        self.feature_engineer = AdvancedFeatureEngineering()
        self.trained_models = {}
        self.results = {}
        
    def fetch_extended_data(self, symbol, start_date='2020-01-01', end_date='2024-01-01'):
        """Fetch extended historical data for training"""
        print(f"Fetching extended data for {symbol}...")
        
        bars = self.client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=start_date,
            end=end_date,
            adjustment='raw'
        ).df
        
        if bars.empty:
            print(f"No data found for {symbol}")
            return None
        
        print(f"✅ Fetched {len(bars)} days of data from {bars.index[0]} to {bars.index[-1]}")
        return bars
    
    def create_time_splits(self, data, train_ratio=0.7, val_ratio=0.15, test_ratio=0.15):
        """Create time-based train/validation/test splits"""
        n = len(data)
        train_end = int(n * train_ratio)
        val_end = int(n * (train_ratio + val_ratio)
        
        train_data = data.iloc[:train_end]
        val_data = data.iloc[train_end:val_end]
        test_data = data.iloc[val_end:]
        
        print(f"Data splits:")
        print(f"  Train: {len(train_data)} samples ({train_data.index[0]} to {train_data.index[-1]})")
        print(f"  Val:   {len(val_data)} samples ({val_data.index[0]} to {val_data.index[-1]})")
        print(f"  Test:  {len(test_data)} samples ({test_data.index[0]} to {test_data.index[-1]})")
        
        return train_data, val_data, test_data
    
    def train_individual_models(self, symbol='AAPL'):
        """Train individual ML models"""
        print(f"\n{'='*80}")
        print(f"🚀 TRAINING INDIVIDUAL ML MODELS FOR {symbol}")
        print(f"{'='*80}")
        
        # Fetch data
        data = self.fetch_extended_data(symbol)
        if data is None:
            return
        
        # Create splits
        train_data, val_data, test_data = self.create_time_splits(data)
        
        # Feature engineering
        print("\n📊 Feature Engineering...")
        train_features = self.feature_engineer.engineer_all_features(train_data)
        val_features = self.feature_engineer.engineer_all_features(val_data)
        test_features = self.feature_engineer.engineer_all_features(test_data)
        
        # Create targets
        ensemble = MetaLearningEnsemble()
        train_targets = ensemble.create_targets(train_data)
        val_targets = ensemble.create_targets(val_data)
        test_targets = ensemble.create_targets(test_data)
        
        print(f"Features shape: {train_features.shape}")
        print(f"Target distribution in training:")
        print(f"  Buy signals: {(train_targets == 1).sum()}")
        print(f"  Hold signals: {(train_targets == 0).sum()}")
        print(f"  Sell signals: {(train_targets == -1).sum()}")
        
        # Clean data
        train_mask = ~(train_features.isna().any(axis=1) | train_targets.isna()
        val_mask = ~(val_features.isna().any(axis=1) | val_targets.isna()
        test_mask = ~(test_features.isna().any(axis=1) | test_targets.isna()
        
        train_features = train_features[train_mask]
        train_targets = train_targets[train_mask]
        val_features = val_features[val_mask]
        val_targets = val_targets[val_mask]
        test_features = test_features[test_mask]
        test_targets = test_targets[test_mask]
        
        # Store data for later use
        self.train_data = {}
            'features': train_features,
            'targets': train_targets,
            'val_features': val_features,
            'val_targets': val_targets,
            'test_features': test_features,
            'test_targets': test_targets
        }
        
        models_to_train = {}
            'xgboost': XGBoostTradingModel(),
            # Skip neural networks for now due to memory constraints
        }
        
        # Train each model
        for name, model in models_to_train.items():
            print(f"\n🔧 Training {name.upper()} model...")
            try:
                model.train(train_features, train_targets)
                
                # Evaluate on validation set
                val_pred = model.predict(val_features)
                val_accuracy = (val_pred == val_targets).mean()
                
                # Evaluate on test set
                test_pred = model.predict(test_features)
                test_accuracy = (test_pred == test_targets).mean()
                
                print(f"✅ {name} - Val Accuracy: {val_accuracy:.3f}, Test Accuracy: {test_accuracy:.3f}")
                
                # Store results
                self.trained_models[name] = model
                self.results[name] = {}
                    'val_accuracy': val_accuracy,
                    'test_accuracy': test_accuracy,
                    'val_predictions': val_pred,
                    'test_predictions': test_pred
                }
                
            except Exception as e:
                print(f"❌ Error training {name}: {e}")
        
        return self.trained_models
    
    def train_ensemble_model(self, symbol='AAPL'):
        """Train the meta-learning ensemble"""
        print(f"\n{'='*80}")
        print(f"🎯 TRAINING META-LEARNING ENSEMBLE FOR {symbol}")
        print(f"{'='*80}")
        
        # Fetch fresh data for ensemble training
        data = self.fetch_extended_data(symbol)
        if data is None:
            return
        
        # Use recent data for ensemble (last 2 years)
        recent_data = data.iloc[-500:]  # Last ~2 years
        
        try:
            ensemble = MetaLearningEnsemble()
            
            print("\n🔄 Training ensemble models...")
            model_predictions = ensemble.train_all_models(recent_data, epochs=20)  # Reduced epochs
            
            # Evaluate ensemble
            features = ensemble.feature_engineer.engineer_all_features(recent_data)
            targets = ensemble.create_targets(recent_data)
            
            # Clean data
            valid_mask = ~(features.isna().any(axis=1) | targets.isna()
            
            if valid_mask.sum() > 50:
                ensemble_pred, individual_pred = ensemble.predict(recent_data)
                ensemble_accuracy = (ensemble_pred[valid_mask] == targets[valid_mask]).mean()
                
                print(f"\n🎯 Ensemble Results:")
                print(f"✅ Ensemble Accuracy: {ensemble_accuracy:.3f}")
                
                # Individual model accuracies
                for model_name in individual_pred.columns:
                    model_acc = (individual_pred[model_name][valid_mask] == targets[valid_mask]).mean()
                    print(f"  {model_name}: {model_acc:.3f}")
                
                self.trained_models['ensemble'] = ensemble
                self.results['ensemble'] = {}
                    'accuracy': ensemble_accuracy,
                    'predictions': ensemble_pred,
                    'individual_predictions': individual_pred
                }
            
        except Exception as e:
            print(f"❌ Error training ensemble: {e}")
            return None
        
        return ensemble
    
    def walk_forward_analysis(self, symbol='AAPL', window_size=252, step_size=63):
        """Perform walk-forward analysis"""
        print(f"\n{'='*80}")
        print(f"📈 WALK-FORWARD ANALYSIS FOR {symbol}")
        print(f"{'='*80}")
        
        # Fetch data
        data = self.fetch_extended_data(symbol, start_date='2020-01-01')
        if data is None:
            return
        
        # Walk-forward parameters
        results = []
        
        for i in range(window_size, len(data) - step_size, step_size):
            print(f"\nWindow {len(results)+1}: Training on data up to index {i}")
            
            # Create train/test windows
            train_data = data.iloc[i-window_size:i]
            test_data = data.iloc[i:i+step_size]
            
            try:
                # Quick XGBoost model for walk-forward
                model = XGBoostTradingModel()
                
                # Feature engineering
                train_features = self.feature_engineer.engineer_all_features(train_data)
                test_features = self.feature_engineer.engineer_all_features(test_data)
                
                # Create targets
                ensemble = MetaLearningEnsemble()
                train_targets = ensemble.create_targets(train_data)
                test_targets = ensemble.create_targets(test_data)
                
                # Clean data
                train_mask = ~(train_features.isna().any(axis=1) | train_targets.isna()
                test_mask = ~(test_features.isna().any(axis=1) | test_targets.isna()
                
                if train_mask.sum() < 50 or test_mask.sum() < 10:
                    continue
                
                # Train model
                model.train(train_features[train_mask], train_targets[train_mask])
                
                # Test predictions
                test_pred = model.predict(test_features[test_mask])
                test_acc = (test_pred == test_targets[test_mask]).mean()
                
                # Calculate returns
                test_returns = test_data['close'].pct_change().iloc[1:]
                strategy_returns = test_returns * pd.Series(test_pred, index=test_features[test_mask].index).shift(1)
                strategy_return = strategy_returns.sum()
                
                results.append({)
                    'window': len(results) + 1,
                    'train_start': train_data.index[0],
                    'train_end': train_data.index[-1],
                    'test_start': test_data.index[0],
                    'test_end': test_data.index[-1],
                    'accuracy': test_acc,
                    'strategy_return': strategy_return,
                    'buy_hold_return': test_returns.sum()
                })
                
                print(f"  Accuracy: {test_acc:.3f}, Strategy Return: {strategy_return:.3%}")
                
            except Exception as e:
                print(f"  Error in window {len(results)+1}: {e}")
                continue
        
        # Summary results
        if results:
            df_results = pd.DataFrame(results)
            
            print(f"\n📊 Walk-Forward Analysis Summary:")
            print(f"✅ Average Accuracy: {df_results['accuracy'].mean():.3f}")
            print(f"✅ Average Strategy Return: {df_results['strategy_return'].mean():.3%}")
            print(f"✅ Average Buy & Hold Return: {df_results['buy_hold_return'].mean():.3%}")
            print(f"✅ Win Rate (Strategy > B&H): {(df_results['strategy_return'] > df_results['buy_hold_return']).mean():.1%}")
            
            self.results['walk_forward'] = df_results
            
        return results
    
    def generate_performance_report(self):
        """Generate comprehensive performance report"""
        print(f"\n{'='*80}")
        print(f"📊 COMPREHENSIVE ML MODEL PERFORMANCE REPORT")
        print(f"{'='*80}")
        print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        if not self.results:
            print("❌ No results to report. Please train models first.")
            return
        
        # Individual Model Performance
        print(f"\n🎯 INDIVIDUAL MODEL PERFORMANCE")
        print(f"-" * 60)
        
        for model_name, result in self.results.items():
            if model_name == 'walk_forward':
                continue
                
            print(f"\n{model_name.upper()}:")
            
            if 'test_accuracy' in result:
                print(f"  Test Accuracy: {result['test_accuracy']:.3f}")
                print(f"  Validation Accuracy: {result['val_accuracy']:.3f}")
            elif 'accuracy' in result:
                print(f"  Overall Accuracy: {result['accuracy']:.3f}")
        
        # Walk-Forward Analysis
        if 'walk_forward' in self.results:
            wf_results = self.results['walk_forward']
            print(f"\n📈 WALK-FORWARD ANALYSIS")
            print(f"-" * 60)
            print(f"Number of Windows: {len(wf_results)}")
            print(f"Average Accuracy: {wf_results['accuracy'].mean():.3f}")
            print(f"Accuracy Std Dev: {wf_results['accuracy'].std():.3f}")
            print(f"Best Window Accuracy: {wf_results['accuracy'].max():.3f}")
            print(f"Worst Window Accuracy: {wf_results['accuracy'].min():.3f}")
            
            print(f"\nStrategy vs Buy & Hold:")
            print(f"Average Strategy Return: {wf_results['strategy_return'].mean():.3%}")
            print(f"Average B&H Return: {wf_results['buy_hold_return'].mean():.3%}")
            outperform_rate = (wf_results['strategy_return'] > wf_results['buy_hold_return']).mean()
            print(f"Outperformance Rate: {outperform_rate:.1%}")
        
        # Model Comparison
        print(f"\n🏆 MODEL RANKING")
        print(f"-" * 60)
        
        model_scores = []
        for model_name, result in self.results.items():
            if model_name == 'walk_forward':
                continue
                
            score = result.get('test_accuracy', result.get('accuracy', 0)
            model_scores.append((model_name, score)
        
        model_scores.sort(key=lambda x: x[1], reverse=True)
        
        for i, (model_name, score) in enumerate(model_scores, 1):
            print(f"  {i}. {model_name.upper()}: {score:.3f}")
        
        # Save results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        results_file = f'ml_training_results_{timestamp}.json'
        
        # Convert results to JSON-serializable format
        json_results = {}
        for key, value in self.results.items():
            if isinstance(value, pd.DataFrame):
                json_results[key] = value.to_dict()
            elif isinstance(value, dict):
                json_dict = {}
                for k, v in value.items():
                    if isinstance(v, (pd.Series, np.ndarray):)
                        json_dict[k] = v.tolist() if hasattr(v, 'tolist') else list(v)
                    else:
                        json_dict[k] = v
                json_results[key] = json_dict
            else:
                json_results[key] = value
        
        with open(results_file, 'w') as f:
            json.dump(json_results, f, indent=2, default=str)
        
        print(f"\n📁 Results saved to: {results_file}")
    
    def run_full_pipeline(self, symbols=['AAPL']):
        """Run the complete ML training pipeline"""
        print(f"{'='*80}")
        print(f"🚀 ML TRADING MODEL TRAINING PIPELINE")
        print(f"{'='*80}")
        print(f"Training on symbols: {symbols}")
        print(f"Pipeline includes:")
        print(f"  • Individual model training")
        print(f"  • Ensemble meta-learning")
        print(f"  • Walk-forward analysis")
        print(f"  • Comprehensive evaluation")
        
        for symbol in symbols:
            print(f"\n🎯 Processing {symbol}...")
            
            # Train individual models
            self.train_individual_models(symbol)
            
            # Train ensemble (skip for now due to complexity)
            # self.train_ensemble_model(symbol)
            
            # Walk-forward analysis
            self.walk_forward_analysis(symbol)
        
        # Generate final report
        self.generate_performance_report()
        
        print(f"\n✅ ML Training Pipeline Complete!")

def main():
    """Run the ML training pipeline"""
    pipeline = MLTrainingPipeline()
    
    # Run on a single symbol first
    pipeline.run_full_pipeline(['AAPL'])

if __name__ == "__main__":
    main()