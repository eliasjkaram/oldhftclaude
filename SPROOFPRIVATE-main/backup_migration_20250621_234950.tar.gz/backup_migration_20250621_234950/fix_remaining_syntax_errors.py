#!/usr/bin/env python3
"""
Fix remaining syntax errors in validation implementation
"""

import os
import re

def fix_comprehensive_data_validation():
    """Fix comprehensive_data_validation.py syntax"""
    file_path = "/home/harry/alpaca-mcp/comprehensive_data_validation.py"
    
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Fix line 81 - missing closing parenthesis
    content = content.replace()
        "notional_value = Decimal(str(order['quantity'])) * Decimal(str(order['price'])",
        "notional_value = Decimal(str(order['quantity'])) * Decimal(str(order['price']))"
    )
    
    # Fix line 330 - missing closing parenthesis
    content = content.replace()
        "'quantity': validator.sanitize_quantity(request['quantity'], request.get('asset_type', 'stock'),",
        "'quantity': validator.sanitize_quantity(request['quantity'], request.get('asset_type', 'stock')),"
    )
    
    with open(file_path, 'w') as f:
        f.write(content)
    
    print(f"Fixed {file_path}")

def fix_server_py():
    """Fix src/server.py"""
    file_path = "/home/harry/alpaca-mcp/src/server.py"
    
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    fixed_lines = []
    skip_lines = False
    in_function = False
    function_name = ""
    
    for i, line in enumerate(lines):
        # Skip malformed sections
        if "quantity: Number of shares to buy or sell (can be fractional)" in line and "def" not in line:
            skip_lines = True
            continue
        elif "Place a limit order to buy or sell a stock at a specified price." in line and "def" not in line:
            skip_lines = True
            continue
        elif skip_lines and ("@mcp.tool()" in line or "def " in line):
            skip_lines = False
        
        if skip_lines:
            continue
            
        # Track function definitions
        if line.strip().startswith("def "):
            in_function = True
            function_name = line.strip().split("(")[0].replace("def ", "")
            
        # Fix validation code placement
        if "# Comprehensive input validation" in line and in_function:
            # Make sure this is inside the function body
            indent = "    "  # Standard 4-space indent
            fixed_lines.append(f"{indent}# Comprehensive input validation\n")
            continue
        
        # Fix missing closing parentheses in OrderSide and TimeInForce calls
        if "AlpacaOrderSide(side.lower()" in line and not line.strip().endswith(")"):
            line = line.rstrip() + ")\n"
        if "AlpacaTimeInForce(time_in_force.lower()" in line and not line.strip().endswith(")"):
            line = line.rstrip() + ")\n"
            
        fixed_lines.append(line)
    
    with open(file_path, 'w') as f:
        f.writelines(fixed_lines)
    
    print(f"Fixed {file_path}")

def verify_imports():
    """Verify all files have proper imports"""
    files_to_check = []
        "/home/harry/alpaca-mcp/src/server.py",
        "/home/harry/alpaca-mcp/order_executor.py",
        "/home/harry/alpaca-mcp/ULTIMATE_PRODUCTION_TRADING_GUI.py"
    ]
    
    for file_path in files_to_check:
        if not os.path.exists(file_path):
            continue
            
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Check if comprehensive_data_validation is imported
        if "comprehensive_data_validation" not in content:
            print(f"⚠️  Missing import in {file_path}")

def main():
    """Main function"""
    print("Fixing remaining syntax errors...")
    
    fix_comprehensive_data_validation()
    fix_server_py()
    verify_imports()
    
    print("✅ Syntax fixes applied!")

if __name__ == "__main__":
    main()