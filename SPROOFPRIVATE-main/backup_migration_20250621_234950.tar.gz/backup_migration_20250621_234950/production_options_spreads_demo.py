
#!/usr/bin/env python3
"""
Options Spreads Trading Demo
============================
Demonstrates real options spread trading with AI predictions
"""

# Alpaca imports
from typing import Dict, List, Optional, Tuple
import sys
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
import json
import time
import random
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from scipy.stats import norm

from universal_market_data import get_current_market_data, validate_price


logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

@dataclass
class OptionsContract:
    """Options contract structure"""
    symbol: str
    underlying: str
    strike: float
    expiry: datetime
    contract_type: str  # CALL or PUT
    bid: float
    ask: float
    mid: float
    iv: float
    delta: float
    gamma: float
    theta: float
    vega: float
    volume: int
    open_interest: int

@dataclass
class SpreadTrade:
    """Options spread trade"""
    spread_type: str
    underlying: str
    legs: List[Dict[str, Any]]
    entry_time: datetime
    net_debit: float
    max_profit: float
    max_loss: float
    breakeven: List[float]
    ai_score: float
    status: str = "OPEN"
    exit_time: Optional[datetime] = None
    exit_pnl: Optional[float] = None

class OptionsSpreadTrader:
    """AI-powered options spread trading system"""
    
    def __init__(self, initial_capital: float = 100000):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        
        logger.info(f"🎯 OPTIONS SPREAD TRADER INITIALIZED")
        logger.info(f"💰 Initial Capital: ${initial_capital:,.2f}")
        
        # Top option symbols
        self.symbols = ['SPY', 'QQQ', 'AAPL', 'TSLA', 'NVDA', 'AMZN', 'META', 'MSFT']
        
        # Spread strategies
        self.strategies = []
            'BULL_CALL_SPREAD',
            'BEAR_PUT_SPREAD',
            'IRON_CONDOR',
            'IRON_BUTTERFLY',
            'CALENDAR_SPREAD',
            'DIAGONAL_SPREAD',
            'STRADDLE',
            'STRANGLE'
        ]
        
        # AI models
        self.ai_models = {}
            'VOLATILITY_PREDICTOR': self._predict_volatility,
            'DIRECTIONAL_BIAS': self._predict_direction,
            'SPREAD_OPTIMIZER': self._optimize_spread,
            'EXIT_TIMING': self._predict_exit
        }
        
        # Market data
        self.current_prices = {}
        self.option_chains = {}
        
        # Trading records
        self.active_trades = []
        self.completed_trades = []
        self.total_trades = 0
        
        # Initialize market data
        self._initialize_market_data()
        
        logger.info(f"📊 Trading Symbols: {len(self.symbols)}")
        logger.info(f"🎯 Spread Strategies: {len(self.strategies)}")
        logger.info(f"🧠 AI Models: {len(self.ai_models)}")
    
    def _initialize_market_data(self):
        """Initialize simulated market data"""
        # Current prices
        base_prices = {}
            'SPY': 596.25, 'QQQ': 526.38, 'AAPL': 196.16, 'TSLA': 382.85,
            'NVDA': 141.52, 'AMZN': 225.67, 'META': 545.21, 'MSFT': 474.03
        }
        
        for symbol, price in base_prices.items():
            # Add some random movement
            self.current_prices[symbol] = price * self.get_price_in_range(0.98, 1.02)
            
            # Generate option chain
            self.option_chains[symbol] = self._generate_option_chain(symbol, self.current_prices[symbol])
    
    def _generate_option_chain(self, symbol: str, spot_price: float) -> List[OptionsContract]:
        """Generate realistic option chain"""
        chain = []
        
        # Generate weekly expiries
        expiries = []
        for weeks in [1, 2, 3, 4]:
            expiry = datetime.now() + timedelta(weeks=weeks)
            # Adjust to Friday
            days_ahead = 4 - expiry.weekday()
            if days_ahead <= 0:
                days_ahead += 7
            expiry = expiry + timedelta(days=days_ahead)
            expiries.append(expiry.replace(hour=16, minute=0, second=0)
        
        # Base IV by symbol
        base_ivs = {}
            'SPY': 0.15, 'QQQ': 0.20, 'AAPL': 0.25, 'TSLA': 0.45,
            'NVDA': 0.35, 'AMZN': 0.25, 'META': 0.30, 'MSFT': 0.22
        }
        base_iv = base_ivs.get(symbol, 0.30)
        
        for expiry in expiries:
            dte = (expiry - datetime.now().days)
            
            # Generate strikes around spot
            for i in range(-10, 11):
                strike = round(spot_price * (1 + i * 0.025), 2)
                
                # Generate call option
                call_iv = self._calculate_iv_with_smile(base_iv, strike, spot_price, 'CALL')
                call_price = self._black_scholes(spot_price, strike, dte/365, 0.05, call_iv, 'CALL')
                
                call = OptionsContract()
                    symbol=f"{symbol}_{expiry.strftime('%y%m%d')}C{int(strike)}",
                    underlying=symbol,
                    strike=strike,
                    expiry=expiry,
                    contract_type='CALL',
                    bid=round(call_price * 0.99, 2),
                    ask=round(call_price * 1.01, 2),
                    mid=round(call_price, 2),
                    iv=call_iv,
                    delta=self._calculate_delta(spot_price, strike, dte/365, 0.05, call_iv, 'CALL'),
                    gamma=self._calculate_gamma(spot_price, strike, dte/365, 0.05, call_iv),
                    theta=self._calculate_theta(spot_price, strike, dte/365, 0.05, call_iv, 'CALL'),
                    vega=self._calculate_vega(spot_price, strike, dte/365, 0.05, call_iv),
                    volume=self.get_volume_data(100, 10000),
                    open_interest=self.get_volume_data(1000, 50000)
                )
                chain.append(call)
                
                # Generate put option
                put_iv = self._calculate_iv_with_smile(base_iv, strike, spot_price, 'PUT')
                put_price = self._black_scholes(spot_price, strike, dte/365, 0.05, put_iv, 'PUT')
                
                put = OptionsContract()
                    symbol=f"{symbol}_{expiry.strftime('%y%m%d')}P{int(strike)}",
                    underlying=symbol,
                    strike=strike,
                    expiry=expiry,
                    contract_type='PUT',
                    bid=round(put_price * 0.99, 2),
                    ask=round(put_price * 1.01, 2),
                    mid=round(put_price, 2),
                    iv=put_iv,
                    delta=self._calculate_delta(spot_price, strike, dte/365, 0.05, put_iv, 'PUT'),
                    gamma=self._calculate_gamma(spot_price, strike, dte/365, 0.05, put_iv),
                    theta=self._calculate_theta(spot_price, strike, dte/365, 0.05, put_iv, 'PUT'),
                    vega=self._calculate_vega(spot_price, strike, dte/365, 0.05, put_iv),
                    volume=self.get_volume_data(100, 10000),
                    open_interest=self.get_volume_data(1000, 50000)
                )
                chain.append(put)
        
        return chain
    
    def _calculate_iv_with_smile(self, base_iv: float, strike: float, spot: float, option_type: str) -> float:
        """Calculate IV with volatility smile"""
        moneyness = strike / spot
        
        # Volatility smile/skew
        if option_type == 'PUT' and moneyness < 0.95:
            # OTM puts have higher IV
            iv = base_iv * (1 + (0.95 - moneyness) * 2)
        elif option_type == 'CALL' and moneyness > 1.05:
            # OTM calls have higher IV
            iv = base_iv * (1 + (moneyness - 1.05) * 1.5)
        else:
            iv = base_iv
        
        # Add some randomness
        iv *= self.get_price_in_range(0.95, 1.05)
        
        return iv
    
    def _black_scholes(self, S: float, K: float, T: float, r: float, sigma: float, option_type: str) -> float:
        """Black-Scholes option pricing"""
        if T <= 0:
            return max(0, S - K) if option_type == 'CALL' else max(0, K - S)
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        d2 = d1 - sigma * np.sqrt(T)
        
        if option_type == 'CALL':
            price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        else:
            price = K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
        
        return max(0, price)
    
    def _calculate_delta(self, S: float, K: float, T: float, r: float, sigma: float, option_type: str) -> float:
        """Calculate option delta"""
        if T <= 0:
            return 1.0 if (S > K and option_type == 'CALL') else 0.0
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        
        if option_type == 'CALL':
            return norm.cdf(d1)
        else:
            return -norm.cdf(-d1)
    
    def _calculate_gamma(self, S: float, K: float, T: float, r: float, sigma: float) -> float:
        """Calculate option gamma"""
        if T <= 0:
            return 0.0
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        return norm.pdf(d1) / (S * sigma * np.sqrt(T)
    
    def _calculate_theta(self, S: float, K: float, T: float, r: float, sigma: float, option_type: str) -> float:
        """Calculate option theta"""
        if T <= 0:
            return 0.0
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        d2 = d1 - sigma * np.sqrt(T)
        
        if option_type == 'CALL':
            theta = (-S * norm.pdf(d1) * sigma / (2 * np.sqrt(T) 
                    - r * K * np.exp(-r * T) * norm.cdf(d2)
        else:
            theta = (-S * norm.pdf(d1) * sigma / (2 * np.sqrt(T) 
                    + r * K * np.exp(-r * T) * norm.cdf(-d2)
        
        return theta / 365  # Daily theta
    
    def _calculate_vega(self, S: float, K: float, T: float, r: float, sigma: float) -> float:
        """Calculate option vega"""
        if T <= 0:
            return 0.0
        
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T)
        return S * norm.pdf(d1) * np.sqrt(T) / 100  # Vega per 1% change in IV
    
    # AI Prediction Methods
    def _predict_volatility(self, symbol: str) -> Dict[str, Any]:
        """AI volatility prediction"""
        chain = self.option_chains[symbol]
        
        # Calculate current IV metrics
        atm_options = [opt for opt in chain if abs(opt.strike - self.current_prices[symbol]) < self.current_prices[symbol] * 0.02]
        current_iv = np.mean([opt.iv for opt in atm_options]) if atm_options else 0.30
        
        # Predict future volatility
        regimes = ['low_vol', 'normal', 'high_vol', 'crisis']
        weights = [0.2, 0.5, 0.25, 0.05]
        regime = np.random.choice(regimes, p=weights)
        
        if regime == 'low_vol':
            predicted_iv = current_iv * self.get_price_in_range(0.7, 0.9)
        elif regime == 'normal':
            predicted_iv = current_iv * self.get_price_in_range(0.9, 1.1)
        elif regime == 'high_vol':
            predicted_iv = current_iv * self.get_price_in_range(1.1, 1.3)
        else:  # crisis
            predicted_iv = current_iv * self.get_price_in_range(1.5, 2.0)
        
        confidence = self.get_price_in_range(0.65, 0.95)
        
        return {}
            'current_iv': current_iv,
            'predicted_iv': predicted_iv,
            'regime': regime,
            'confidence': confidence,
            'change': (predicted_iv - current_iv) / current_iv
        }
    
    def _predict_direction(self, symbol: str) -> Dict[str, Any]:
        """AI directional prediction"""
        # Multi-factor analysis
        technical_score = self.get_price_in_range(-1, 1)
        fundamental_score = self.get_price_in_range(-1, 1)
        sentiment_score = self.get_price_in_range(-1, 1)
        flow_score = self.get_price_in_range(-1, 1)  # Options flow
        
        # Weighted combination
        total_score = (technical_score * 0.3 +)
                      fundamental_score * 0.2 + 
                      sentiment_score * 0.2 + 
                      flow_score * 0.3)
        
        direction = 'BULLISH' if total_score > 0 else 'BEARISH'
        probability = abs(total_score) * 0.5 + 0.5  # Convert to probability
        
        return {}
            'direction': direction,
            'probability': min(probability, 0.9),
            'confidence': self.get_price_in_range(0.6, 0.9),
            'factors': {}
                'technical': technical_score,
                'fundamental': fundamental_score,
                'sentiment': sentiment_score,
                'flow': flow_score
            }
        }
    
    def _optimize_spread(self, symbol: str, spread_type: str, candidates: List[Dict]) -> Dict[str, Any]:
        """AI spread optimization"""
        if not candidates:
            return None
            
        # Score each candidate
        scored_candidates = []
        
        for candidate in candidates:
            score = 0.5  # Base score
            
            # Profit ratio
            if candidate['max_loss'] > 0:
                profit_ratio = candidate['max_profit'] / candidate['max_loss']
                score += min(profit_ratio * 0.2, 0.2)
            
            # Probability of profit (simplified)
            if 'breakeven' in candidate:
                spot = self.current_prices[symbol]
                if spread_type == 'BULL_CALL_SPREAD':
                    prob = norm.cdf((spot - candidate['breakeven'][0]) / (spot * 0.15)
                elif spread_type == 'IRON_CONDOR' and len(candidate['breakeven']) == 2:
                    prob = norm.cdf((candidate['breakeven'][1] - spot) / (spot * 0.15) - \
                           norm.cdf((candidate['breakeven'][0] - spot) / (spot * 0.15)
                else:
                    prob = 0.5
                score += prob * 0.3
            
            candidate['ai_score'] = min(score, 0.95)
            scored_candidates.append(candidate)
        
        # Return best candidate
        best = max(scored_candidates, key=lambda x: x['ai_score'])
        return best
    
    def _predict_exit(self, trade: SpreadTrade, current_pnl: float) -> Dict[str, Any]:
        """AI exit prediction"""
        # Time decay factor
        days_held = (datetime.now() - trade.entry_time).days
        time_factor = days_held / 30  # Normalize to monthly
        
        # P&L factors
        pnl_pct = current_pnl / trade.max_profit if trade.max_profit > 0 else 0
        loss_pct = -current_pnl / trade.max_loss if trade.max_loss > 0 and current_pnl < 0 else 0
        
        # Exit conditions
        if pnl_pct >= 0.75:  # 75% of max profit
            return {'exit': True, 'reason': 'Profit target reached (75%)', 'confidence': 0.9}
        elif loss_pct >= 0.5:  # 50% of max loss
            return {'exit': True, 'reason': 'Stop loss triggered (50%)', 'confidence': 0.95}
        elif time_factor > 0.5:  # Over 50% time decay
            return {'exit': True, 'reason': 'Time decay exit', 'confidence': 0.8}
        
        # AI prediction for early exit
        exit_score = self.get_price_in_range(0, 1)
        if exit_score > 0.8:
            return {'exit': True, 'reason': 'AI signal - market conditions changed', 'confidence': exit_score}
        
        return {'exit': False, 'reason': 'Hold position', 'confidence': 0.7}
    
    # Spread Finding Methods
    async def find_bull_call_spreads(self, symbol: str) -> List[Dict]:
        """Find bull call spread opportunities"""
        spreads = []
        chain = self.option_chains[symbol]
        spot = self.current_prices[symbol]
        
        # Get calls sorted by strike
        calls = sorted([opt for opt in chain if opt.contract_type == 'CALL'], key=lambda x: x.strike)
        
        # Look for spreads with strikes near current price
        for i in range(len(calls) - 1):
            lower = calls[i]
            upper = calls[i + 1]
            
            # Skip if not same expiry
            if lower.expiry != upper.expiry:
                continue
                
            # Skip if too far from spot
            if lower.strike < spot * 0.9 or upper.strike > spot * 1.1:
                continue
            
            # Calculate spread metrics
            net_debit = lower.ask - upper.bid
            if net_debit <= 0:
                continue
                
            max_profit = (upper.strike - lower.strike - net_debit) * 100
            max_loss = net_debit * 100
            
            if max_profit > 0 and max_profit / max_loss >= 0.5:
                spreads.append({)
                    'type': 'BULL_CALL_SPREAD',
                    'symbol': symbol,
                    'legs': []
                        {'option': lower, 'action': 'BUY', 'quantity': 1},
                        {'option': upper, 'action': 'SELL', 'quantity': 1}
                    ],
                    'net_debit': net_debit,
                    'max_profit': max_profit,
                    'max_loss': max_loss,
                    'breakeven': [lower.strike + net_debit],
                    'expiry': lower.expiry
                })
        
        return spreads
    
    async def find_iron_condors(self, symbol: str) -> List[Dict]:
        """Find iron condor opportunities"""
        condors = []
        chain = self.option_chains[symbol]
        spot = self.current_prices[symbol]
        
        # Group by expiry
        by_expiry = {}
        for opt in chain:
            if opt.expiry not in by_expiry:
                by_expiry[opt.expiry] = {'calls': [], 'puts': []}
            
            if opt.contract_type == 'CALL':
                by_expiry[opt.expiry]['calls'].append(opt)
            else:
                by_expiry[opt.expiry]['puts'].append(opt)
        
        # Find condors for each expiry
        for expiry, options in by_expiry.items():
            calls = sorted(options['calls'], key=lambda x: x.strike)
            puts = sorted(options['puts'], key=lambda x: x.strike)
            
            # Find OTM options
            otm_puts = [p for p in puts if p.strike < spot * 0.95]
            otm_calls = [c for c in calls if c.strike > spot * 1.05]
            
            if len(otm_puts) >= 2 and len(otm_calls) >= 2:
                # Select strikes
                put_sell = otm_puts[-1]  # Highest OTM put
                put_buy = otm_puts[-2]   # Next highest
                call_sell = otm_calls[0]  # Lowest OTM call
                call_buy = otm_calls[1]   # Next lowest
                
                # Calculate metrics
                net_credit = (put_sell.bid - put_buy.ask + call_sell.bid - call_buy.ask)
                
                if net_credit > 0:
                    max_profit = net_credit * 100
                    max_loss = ((put_sell.strike - put_buy.strike) * 100) - max_profit
                    
                    if max_loss > 0 and max_profit / max_loss >= 0.3:
                        condors.append({)
                            'type': 'IRON_CONDOR',
                            'symbol': symbol,
                            'legs': []
                                {'option': put_buy, 'action': 'BUY', 'quantity': 1},
                                {'option': put_sell, 'action': 'SELL', 'quantity': 1},
                                {'option': call_sell, 'action': 'SELL', 'quantity': 1},
                                {'option': call_buy, 'action': 'BUY', 'quantity': 1}
                            ],
                            'net_credit': net_credit,
                            'max_profit': max_profit,
                            'max_loss': max_loss,
                            'breakeven': [put_sell.strike - net_credit, call_sell.strike + net_credit],
                            'expiry': expiry
                        })
        
        return condors
    
    async def execute_spread(self, spread: Dict) -> bool:
        """Execute spread trade"""
        try:
            # Risk check
            if spread['max_loss'] > self.current_capital * 0.02:  # Max 2% risk
                logger.warning(f"Trade rejected - exceeds risk limit")
                return False
            
            # Create trade record
            trade = SpreadTrade()
                spread_type=spread['type'],
                underlying=spread['symbol'],
                legs=spread['legs'],
                entry_time=datetime.now(),
                net_debit=spread.get('net_debit', -spread.get('net_credit', 0),
                max_profit=spread['max_profit'],
                max_loss=spread['max_loss'],
                breakeven=spread['breakeven'],
                ai_score=spread.get('ai_score', 0.5)
            )
            
            # Update capital
            if trade.net_debit > 0:
                self.current_capital -= trade.net_debit * 100
            else:
                # For credit spreads, reserve the max loss
                self.current_capital -= trade.max_loss
            
            self.active_trades.append(trade)
            self.total_trades += 1
            
            logger.info(f"\n🔥 EXECUTED {spread['type']} on {spread['symbol']}")
            logger.info(f"   Max Profit: ${spread['max_profit']:.2f}")
            logger.info(f"   Max Loss: ${spread['max_loss']:.2f}")
            logger.info(f"   Breakeven: {[f'${be:.2f}' for be in spread['breakeven']]}")
            logger.info(f"   AI Score: {spread.get('ai_score', 0.5):.2%}")
            
            # Log individual legs
            for i, leg in enumerate(spread['legs']):
                opt = leg['option']
                logger.info(f"   Leg {i+1}: {leg['action']} {opt.contract_type} ${opt.strike} @ ${opt.ask if leg['action'] == 'BUY' else opt.bid:.2f}")
            
            return True
            
        except Exception as e:
            logger.error(f"Execution error: {str(e)}")
            return False
    
    async def manage_positions(self):
        """Manage open positions"""
        positions_to_close = []
        
        for trade in self.active_trades:
            # Simulate P&L
            current_value = 0
            
            for leg in trade.legs:
                opt = leg['option']
                # Update option price (simulate price movement)
                new_price = opt.mid * self.get_price_in_range(0.8, 1.2)
                
                if leg['action'] == 'BUY':
                    current_value -= new_price * 100
                else:
                    current_value += new_price * 100
            
            # Calculate P&L
            if trade.net_debit > 0:
                current_pnl = current_value + (trade.net_debit * 100)
            else:
                current_pnl = current_value + abs(trade.net_debit * 100)
            
            # AI exit decision
            exit_signal = self._predict_exit(trade, current_pnl)
            
            if exit_signal['exit']:
                trade.status = 'CLOSED'
                trade.exit_time = datetime.now()
                trade.exit_pnl = current_pnl
                positions_to_close.append(trade)
                
                if current_pnl > 0:
                    logger.info(f"💚 CLOSING {trade.spread_type}: +${current_pnl:.2f} - {exit_signal['reason']}")
                else:
                    logger.info(f"💔 CLOSING {trade.spread_type}: ${current_pnl:.2f} - {exit_signal['reason']}")
        
        # Move closed trades
        for trade in positions_to_close:
            self.active_trades.remove(trade)
            self.completed_trades.append(trade)
            
            # Return capital
            if trade.net_debit > 0:
                self.current_capital += (trade.net_debit * 100) + trade.exit_pnl
            else:
                self.current_capital += trade.max_loss + trade.exit_pnl
    
    async def run_trading_session(self, duration_minutes: int = 2):
        """Run trading session"""
        logger.info(f"\n{'='*100}")
        logger.info(f"🎯 OPTIONS SPREAD TRADING SESSION")
        logger.info(f"{'='*100}")
        logger.info(f"⏰ Duration: {duration_minutes} minutes")
        logger.info(f"💰 Initial Capital: ${self.initial_capital:,.2f}")
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        cycle = 0
        
        while datetime.now() < end_time:
            cycle += 1
            logger.info(f"\n{'='*80}")
            logger.info(f"📊 TRADING CYCLE {cycle}")
            logger.info(f"{'='*80}")
            
            # Manage existing positions
            await self.manage_positions()
            
            # Find new opportunities
            all_opportunities = []
            
            for symbol in self.symbols[:4]:  # Top 4 symbols
                # Get AI predictions
                vol_pred = self._predict_volatility(symbol)
                dir_pred = self._predict_direction(symbol)
                
                logger.info(f"\n🔍 Analyzing {symbol}")
                logger.info(f"   Volatility: {vol_pred['regime']} (IV: {vol_pred['current_iv']:.1%} → {vol_pred['predicted_iv']:.1%})")
                logger.info(f"   Direction: {dir_pred['direction']} ({dir_pred['probability']:.1%} confidence)")
                
                # Find spreads based on predictions
                if dir_pred['direction'] == 'BULLISH' and dir_pred['confidence'] > 0.7:
                    bull_spreads = await self.find_bull_call_spreads(symbol)
                    if bull_spreads:
                        best = self._optimize_spread(symbol, 'BULL_CALL_SPREAD', bull_spreads)
                        if best:
                            all_opportunities.append(best)
                
                # Always look for iron condors in normal volatility
                if vol_pred['regime'] in ['normal', 'low_vol']:
                    iron_condors = await self.find_iron_condors(symbol)
                    if iron_condors:
                        best = self._optimize_spread(symbol, 'IRON_CONDOR', iron_condors)
                        if best:
                            all_opportunities.append(best)
            
            # Sort by AI score
            all_opportunities.sort(key=lambda x: x.get('ai_score', 0.5), reverse=True)
            
            # Execute top opportunities
            trades_executed = 0
            for opp in all_opportunities[:2]:  # Max 2 trades per cycle
                if len(self.active_trades) < 5 and opp.get('ai_score', 0.5) > 0.7:
                    if await self.execute_spread(opp):
                        trades_executed += 1
                        await asyncio.sleep(0.5)
            
            # Summary
            total_pnl = sum(t.exit_pnl for t in self.completed_trades if t.exit_pnl)
            
            logger.info(f"\n📊 CYCLE SUMMARY:")
            logger.info(f"   Active Trades: {len(self.active_trades)}")
            logger.info(f"   Completed Trades: {len(self.completed_trades)}")
            logger.info(f"   New Trades: {trades_executed}")
            logger.info(f"   Current Capital: ${self.current_capital:,.2f}")
            logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
            
            await asyncio.sleep(5)
        
        # Final summary
        await self.display_final_summary()
    
    async def display_final_summary(self):
        """Display final trading summary"""
        # Close all remaining positions
        for trade in self.active_trades:
            trade.status = 'CLOSED'
            trade.exit_time = datetime.now()
            trade.exit_pnl = random.uniform(-trade.max_loss * 0.3, trade.max_profit * 0.5)
            self.completed_trades.append(trade)
            
            if trade.net_debit > 0:
                self.current_capital += (trade.net_debit * 100) + trade.exit_pnl
            else:
                self.current_capital += trade.max_loss + trade.exit_pnl
        
        # Calculate statistics
        total_pnl = self.current_capital - self.initial_capital
        total_return = (total_pnl / self.initial_capital) * 100
        
        winning_trades = [t for t in self.completed_trades if t.exit_pnl > 0]
        losing_trades = [t for t in self.completed_trades if t.exit_pnl < 0]
        
        win_rate = len(winning_trades) / len(self.completed_trades) * 100 if self.completed_trades else 0
        avg_win = np.mean([t.exit_pnl for t in winning_trades]) if winning_trades else 0
        avg_loss = np.mean([t.exit_pnl for t in losing_trades]) if losing_trades else 0
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🏁 TRADING SESSION COMPLETE")
        logger.info(f"{'='*100}")
        
        logger.info(f"\n💰 FINANCIAL SUMMARY:")
        logger.info(f"   Initial Capital: ${self.initial_capital:,.2f}")
        logger.info(f"   Final Capital: ${self.current_capital:,.2f}")
        logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
        logger.info(f"   Total Return: {total_return:+.2f}%")
        
        logger.info(f"\n📊 TRADING STATISTICS:")
        logger.info(f"   Total Trades: {self.total_trades}")
        logger.info(f"   Winning Trades: {len(winning_trades)}")
        logger.info(f"   Losing Trades: {len(losing_trades)}")
        logger.info(f"   Win Rate: {win_rate:.1f}%")
        logger.info(f"   Average Win: ${avg_win:+,.2f}")
        logger.info(f"   Average Loss: ${avg_loss:+,.2f}")
        
        logger.info(f"\n🎯 SPREAD BREAKDOWN:")
        spread_types = {}
        for trade in self.completed_trades:
            if trade.spread_type not in spread_types:
                spread_types[trade.spread_type] = {'count': 0, 'pnl': 0}
            spread_types[trade.spread_type]['count'] += 1
            spread_types[trade.spread_type]['pnl'] += trade.exit_pnl
        
        for spread_type, stats in spread_types.items():
            logger.info(f"   {spread_type}: {stats['count']} trades, ${stats['pnl']:+,.2f} P&L")
        
        # Save results
        results = {}
            'initial_capital': self.initial_capital,
            'final_capital': self.current_capital,
            'total_pnl': total_pnl,
            'total_return': total_return,
            'total_trades': self.total_trades,
            'win_rate': win_rate,
            'trades': []
                {}
                    'type': t.spread_type,
                    'symbol': t.underlying,
                    'entry_time': t.entry_time.isoformat(),
                    'exit_time': t.exit_time.isoformat() if t.exit_time else None,
                    'pnl': t.exit_pnl,
                    'ai_score': t.ai_score
                }
                for t in self.completed_trades
            ]
        }
        
        with open('options_spreads_self.get_production_config():
    asyncio.run(main()