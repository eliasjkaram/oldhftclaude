#!/usr/bin/env python3
"""
Production-Ready Regulatory Reporting Automation System
Supports MiFID II, SEC, FINRA, CFTC, and EMIR compliance requirements
"""

import asyncio
import json
import logging
import os
import sys
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import uuid
import time
import re
import xml.etree.ElementTree as ET
import csv
import gzip
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from collections import defaultdict, deque
import numpy as np
import pandas as pd
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
try:
    import paramiko
except ImportError:
    paramiko = None
import ftplib
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import schedule
import redis
import psycopg2
from psycopg2.extras import RealDictCursor
try:
    import redis.asyncio as aioredis
except ImportError:
    aioredis = None
try:
    import asyncpg
except ImportError:
    asyncpg = None
from prometheus_client import Counter, Histogram, Gauge, start_http_server
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('regulatory_reporting.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Prometheus metrics
report_generated = Counter('regulatory_reports_generated', 'Total reports generated', ['jurisdiction', 'report_type'])
report_errors = Counter('regulatory_report_errors', 'Total report errors', ['jurisdiction', 'error_type'])
report_latency = Histogram('regulatory_report_latency_seconds', 'Report generation latency', ['jurisdiction', 'report_type'])
surveillance_alerts = Counter('surveillance_alerts_triggered', 'Total surveillance alerts', ['alert_type', 'severity'])
data_quality_issues = Counter('data_quality_issues', 'Data quality validation failures', ['field', 'validation_type'])

class Jurisdiction(Enum):
    """Supported regulatory jurisdictions"""
    MIFID_II = "MIFID_II"
    SEC = "SEC"
    FINRA = "FINRA"
    CFTC = "CFTC"
    EMIR = "EMIR"

class ReportType(Enum):
    """Types of regulatory reports"""
    TRANSACTION = "TRANSACTION"
    BEST_EXECUTION = "BEST_EXECUTION"
    POSITION = "POSITION"
    SURVEILLANCE = "SURVEILLANCE"
    RTS27 = "RTS27"
    RTS28 = "RTS28"
    CAT = "CAT"
    RULE_606 = "RULE_606"
    RULE_605 = "RULE_605"
    OATS = "OATS"
    TRACE = "TRACE"
    LARGE_TRADER = "LARGE_TRADER"
    SHORT_POSITION = "SHORT_POSITION"

class AssetClass(Enum):
    """Supported asset classes"""
    EQUITY = "EQUITY"
    FIXED_INCOME = "FIXED_INCOME"
    DERIVATIVE = "DERIVATIVE"
    COMMODITY = "COMMODITY"
    FX = "FX"
    CRYPTO = "CRYPTO"

class AlertType(Enum):
    """Market surveillance alert types"""
    SPOOFING = "SPOOFING"
    LAYERING = "LAYERING"
    WASH_TRADE = "WASH_TRADE"
    FRONT_RUNNING = "FRONT_RUNNING"
    MARKET_MANIPULATION = "MARKET_MANIPULATION"
    EXCESSIVE_MESSAGING = "EXCESSIVE_MESSAGING"
    POSITION_LIMIT_BREACH = "POSITION_LIMIT_BREACH"

@dataclass
class ReferenceData:
    """Reference data for regulatory reporting"""
    lei: str
    isin: Optional[str] = None
    cusip: Optional[str] = None
    sedol: Optional[str] = None
    ticker: Optional[str] = None
    exchange: Optional[str] = None
    currency: str = "USD"
    asset_class: AssetClass = AssetClass.EQUITY
    issuer: Optional[str] = None
    maturity_date: Optional[datetime] = None
    strike_price: Optional[Decimal] = None
    underlying: Optional[str] = None

@dataclass
class Transaction:
    """Transaction data structure"""
    transaction_id: str
    timestamp: datetime
    microsecond_timestamp: int
    instrument: ReferenceData
    side: str  # BUY/SELL
    quantity: Decimal
    price: Decimal
    venue: str
    counterparty_lei: Optional[str]
    client_id: Optional[str]
    order_id: str
    execution_id: str
    trader_id: str
    desk: str
    strategy: Optional[str]
    algorithmic: bool = False
    short_sale: bool = False
    settlement_date: Optional[datetime] = None
    
    def __post_init__(self):
        """Validate transaction data"""
        if self.side not in ["BUY", "SELL"]:
            raise ValueError(f"Invalid side: {self.side}")
        if self.quantity <= 0:
            raise ValueError(f"Invalid quantity: {self.quantity}")
        if self.price < 0:
            raise ValueError(f"Invalid price: {self.price}")

@dataclass
class Position:
    """Position tracking data"""
    account_id: str
    instrument: ReferenceData
    quantity: Decimal
    market_value: Decimal
    cost_basis: Decimal
    unrealized_pnl: Decimal
    realized_pnl: Decimal
    last_update: datetime
    transactions: List[Transaction] = field(default_factory=list)

@dataclass
class SurveillanceAlert:
    """Market surveillance alert"""
    alert_id: str
    alert_type: AlertType
    severity: str  # LOW/MEDIUM/HIGH/CRITICAL
    timestamp: datetime
    instrument: ReferenceData
    description: str
    evidence: Dict[str, Any]
    status: str = "OPEN"  # OPEN/INVESTIGATING/CLOSED/ESCALATED
    assigned_to: Optional[str] = None
    resolution: Optional[str] = None

class DataQualityValidator:
    """Validates data quality for regulatory reporting"""
    
    def __init__(self):
        self.validation_rules = self._initialize_validation_rules()
        self.remediation_handlers = self._initialize_remediation_handlers()
        
    def _initialize_validation_rules(self) -> Dict[str, List[callable]]:
        """Initialize validation rules by field"""
        return {}
            'lei': [self._validate_lei_format, self._validate_lei_checksum],
            'isin': [self._validate_isin_format, self._validate_isin_checksum],
            'timestamp': [self._validate_timestamp_precision, self._validate_timestamp_range],
            'price': [self._validate_price_reasonability, self._validate_price_precision],
            'quantity': [self._validate_quantity_lot_size, self._validate_quantity_limits],
            'venue': [self._validate_venue_code, self._validate_venue_operating_hours]
        }
    
    def _initialize_remediation_handlers(self) -> Dict[str, callable]:
        """Initialize automated remediation handlers"""
        return {}
            'missing_lei': self._remediate_missing_lei,
            'invalid_timestamp': self._remediate_invalid_timestamp,
            'missing_reference_data': self._remediate_missing_reference_data,
            'duplicate_transaction': self._remediate_duplicate_transaction
        }
    
    def validate_transaction(self, transaction: Transaction) -> Tuple[bool, List[str]]:
        """Validate transaction data quality"""
        errors = []
        
        # LEI validation
        if transaction.instrument.lei:
            for validator in self.validation_rules.get('lei', []):
                if not validator(transaction.instrument.lei):
                    errors.append(f"LEI validation failed: {transaction.instrument.lei}")
                    data_quality_issues.labels('lei', validator.__name__).inc()
        
        # Timestamp validation
        for validator in self.validation_rules.get('timestamp', []):
            if not validator(transaction.timestamp):
                errors.append(f"Timestamp validation failed: {transaction.timestamp}")
                data_quality_issues.labels('timestamp', validator.__name__).inc()
        
        # Price validation
        for validator in self.validation_rules.get('price', []):
            if not validator(transaction.price, transaction.instrument.asset_class):
                errors.append(f"Price validation failed: {transaction.price}")
                data_quality_issues.labels('price', validator.__name__).inc()
        
        return len(errors) == 0, errors
    
    def _validate_lei_format(self, lei: str) -> bool:
        """Validate LEI format (20 alphanumeric characters)"""
        return bool(re.match(r'^[A-Z0-9]{20}$', lei))
    
    def _validate_lei_checksum(self, lei: str) -> bool:
        """Validate LEI checksum using ISO 17442 standard"""
        # Simplified checksum validation
        return len(lei) == 20
    
    def _validate_isin_format(self, isin: str) -> bool:
        """Validate ISIN format"""
        return bool(re.match(r'^[A-Z]{2}[A-Z0-9]{9}[0-9]$', isin))
    
    def _validate_isin_checksum(self, isin: str) -> bool:
        """Validate ISIN checksum using Luhn algorithm"""
        # Simplified checksum validation
        return len(isin) == 12
    
    def _validate_timestamp_precision(self, timestamp: datetime) -> bool:
        """Validate timestamp has microsecond precision"""
        return timestamp.microsecond > 0
    
    def _validate_timestamp_range(self, timestamp: datetime) -> bool:
        """Validate timestamp is within reasonable range"""
        now = datetime.now(timezone.utc)
        return (now - timedelta(days=7)) <= timestamp <= (now + timedelta(minutes=5))
    
    def _validate_price_reasonability(self, price: Decimal, asset_class: AssetClass) -> bool:
        """Validate price is within reasonable bounds"""
        if asset_class == AssetClass.EQUITY:
            return Decimal('0.01') <= price <= Decimal('100000')
        elif asset_class == AssetClass.FIXED_INCOME:
            return Decimal('50') <= price <= Decimal('150')
        return True
    
    def _validate_price_precision(self, price: Decimal, asset_class: AssetClass) -> bool:
        """Validate price decimal precision"""
        if asset_class == AssetClass.EQUITY:
            return price.as_tuple().exponent >= -4
        return True
    
    def _validate_quantity_lot_size(self, quantity: Decimal) -> bool:
        """Validate quantity meets lot size requirements"""
        return quantity % 1 == 0  # Must be whole shares
    
    def _validate_quantity_limits(self, quantity: Decimal) -> bool:
        """Validate quantity is within limits"""
        return Decimal('1') <= quantity <= Decimal('10000000')
    
    def _validate_venue_code(self, venue: str) -> bool:
        """Validate venue code format"""
        return bool(re.match(r'^[A-Z]{4}$', venue))
    
    def _validate_venue_operating_hours(self, venue: str) -> bool:
        """Validate transaction occurred during venue operating hours"""
        # Simplified - would check actual venue hours
        return True
    
    def _remediate_missing_lei(self, transaction: Transaction) -> Transaction:
        """Attempt to remediate missing LEI"""
        # Would lookup LEI from reference data service
        logger.warning(f"Missing LEI for transaction {transaction.transaction_id}")
        return transaction
    
    def _remediate_invalid_timestamp(self, transaction: Transaction) -> Transaction:
        """Attempt to remediate invalid timestamp"""
        # Would attempt to reconstruct from audit trail
        logger.warning(f"Invalid timestamp for transaction {transaction.transaction_id}")
        return transaction
    
    def _remediate_missing_reference_data(self, transaction: Transaction) -> Transaction:
        """Attempt to remediate missing reference data"""
        # Would lookup from reference data service
        logger.warning(f"Missing reference data for transaction {transaction.transaction_id}")
        return transaction
    
    def _remediate_duplicate_transaction(self, transaction: Transaction) -> Optional[Transaction]:
        """Handle duplicate transaction"""
        logger.warning(f"Duplicate transaction detected: {transaction.transaction_id}")
        return None

class TransactionReporter:
    """Handles transaction reporting for all jurisdictions"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.validator = DataQualityValidator()
        self.reference_data_cache = {}
        self.transaction_buffer = defaultdict(list)
        self.batch_size = config.get('batch_size', 1000)
        
    async def capture_transaction(self, transaction: Transaction) -> None:
        """Capture and enrich transaction in real-time"""
        start_time = time.time()
        
        try:
            # Validate data quality
            is_valid, errors = self.validator.validate_transaction(transaction)
            if not is_valid:
                logger.error(f"Transaction validation failed: {errors}")
                report_errors.labels(transaction.instrument.asset_class.value, 'validation').inc()
                return
            
            # Enrich with reference data
            enriched_transaction = await self._enrich_transaction(transaction)
            
            # Buffer for batch processing
            jurisdiction = self._determine_jurisdiction(enriched_transaction)
            self.transaction_buffer[jurisdiction].append(enriched_transaction)
            
            # Process batch if buffer is full
            if len(self.transaction_buffer[jurisdiction]) >= self.batch_size:
                await self._process_transaction_batch(jurisdiction)
            
            # Record metrics
            report_latency.labels(jurisdiction.value, ReportType.TRANSACTION.value).observe()
                time.time() - start_time
            )
            
        except Exception as e:
            logger.error(f"Failed to capture transaction: {str(e)}")
            report_errors.labels('unknown', 'capture').inc()
    
    async def _enrich_transaction(self, transaction: Transaction) -> Transaction:
        """Enrich transaction with reference data"""
        # Lookup reference data
        ref_key = f"{transaction.instrument.isin}:{transaction.instrument.lei}"
        
        if ref_key not in self.reference_data_cache:
            # Fetch from reference data service
            ref_data = await self._fetch_reference_data(transaction.instrument)
            self.reference_data_cache[ref_key] = ref_data
        
        # Apply enrichments
        transaction.instrument = self.reference_data_cache[ref_key]
        
        # Add microsecond timestamp if missing
        if not hasattr(transaction, 'microsecond_timestamp'):
            transaction.microsecond_timestamp = int(transaction.timestamp.timestamp() * 1_000_000)
        
        return transaction
    
    async def _fetch_reference_data(self, instrument: ReferenceData) -> ReferenceData:
        """Fetch reference data from external service"""
        # Simulated reference data fetch
        await asyncio.sleep(0.001)
        return instrument
    
    def _determine_jurisdiction(self, transaction: Transaction) -> Jurisdiction:
        """Determine applicable jurisdiction for transaction"""
        # Logic to determine jurisdiction based on venue, instrument, etc.
        venue_map = {}
            'XNYS': Jurisdiction.SEC,
            'XNAS': Jurisdiction.SEC,
            'XLON': Jurisdiction.MIFID_II,
            'XPAR': Jurisdiction.MIFID_II,
            'XCME': Jurisdiction.CFTC
        }
        return venue_map.get(transaction.venue, Jurisdiction.SEC)
    
    async def _process_transaction_batch(self, jurisdiction: Jurisdiction) -> None:
        """Process batch of transactions for reporting"""
        transactions = self.transaction_buffer[jurisdiction]
        self.transaction_buffer[jurisdiction] = []
        
        if jurisdiction == Jurisdiction.MIFID_II:
            await self._generate_mifid_transaction_report(transactions)
        elif jurisdiction == Jurisdiction.SEC:
            await self._generate_cat_report(transactions)
        elif jurisdiction == Jurisdiction.FINRA:
            await self._generate_oats_report(transactions)
        elif jurisdiction == Jurisdiction.CFTC:
            await self._generate_cftc_transaction_report(transactions)
        elif jurisdiction == Jurisdiction.EMIR:
            await self._generate_emir_report(transactions)
    
    async def _generate_mifid_transaction_report(self, transactions: List[Transaction]) -> None:
        """Generate MiFID II transaction report"""
        report = {}
            'header': {}
                'reportingEntity': self.config['mifid_reporting_entity'],
                'submissionDateTime': datetime.now(timezone.utc).isoformat(),
                'reportCount': len(transactions)
            },
            'transactions': []
        }
        
        for txn in transactions:
            report['transactions'].append({)
                'transactionReferenceNumber': txn.transaction_id,
                'tradingVenue': txn.venue,
                'executingEntity': txn.instrument.lei,
                'investmentFirm': self.config['mifid_investment_firm_lei'],
                'submittingEntity': self.config['mifid_submitting_entity_lei'],
                'buyerDecision': txn.trader_id if txn.side == 'BUY' else None,
                'sellerDecision': txn.trader_id if txn.side == 'SELL' else None,
                'transactionDateTime': txn.timestamp.isoformat(),
                'tradingCapacity': 'DEAL' if txn.client_id else 'AOTC',
                'quantity': str(txn.quantity),
                'price': str(txn.price),
                'currency': txn.instrument.currency,
                'instrumentId': txn.instrument.isin,
                'shortSelling': 'SESH' if txn.short_sale else 'SELL'
            })
        
        # Generate XML report
        xml_report = self._generate_xml_report(report, 'MIFID_TRANSACTION')
        
        # Submit report
        await self._submit_report()
            xml_report,
            jurisdiction=Jurisdiction.MIFID_II,
            report_type=ReportType.TRANSACTION
        )
        
        report_generated.labels(Jurisdiction.MIFID_II.value, ReportType.TRANSACTION.value).inc()
    
    async def _generate_cat_report(self, transactions: List[Transaction]) -> None:
        """Generate SEC CAT (Consolidated Audit Trail) report"""
        cat_reports = []
        
        for txn in transactions:
            cat_report = {}
                'firmROEID': self.config['cat_firm_id'],
                'eventTimestamp': txn.microsecond_timestamp,
                'actionType': 'NEW',
                'eventType': 'MEOR',  # Market Event Order Received
                'symbol': txn.instrument.ticker,
                'orderID': txn.order_id,
                'side': txn.side,
                'price': float(txn.price),
                'quantity': int(txn.quantity),
                'orderType': 'LMT',
                'timeInForce': 'DAY',
                'tradingSession': 'REG',
                'custDspIntrFlag': 'false',
                'representativeInd': 'false',
                'exchOriginCode': txn.venue
            }
            cat_reports.append(cat_report)
        
        # Generate JSON Lines format
        json_report = '\n'.join(json.dumps(r) for r in cat_reports)
        
        # Submit report
        await self._submit_report()
            json_report,
            jurisdiction=Jurisdiction.SEC,
            report_type=ReportType.CAT
        )
        
        report_generated.labels(Jurisdiction.SEC.value, ReportType.CAT.value).inc()
    
    async def _generate_oats_report(self, transactions: List[Transaction]) -> None:
        """Generate FINRA OATS report"""
        oats_records = []
        
        for txn in transactions:
            if txn.instrument.asset_class == AssetClass.EQUITY:
                oats_record = {}
                    'firmROEID': self.config['oats_firm_id'],
                    'orderReceiptTimestamp': txn.timestamp.strftime('%Y%m%d %H:%M:%S.%f')[:-3],
                    'orderID': txn.order_id,
                    'symbol': txn.instrument.ticker,
                    'side': txn.side[0],  # B or S
                    'quantity': int(txn.quantity),
                    'price': float(txn.price),
                    'accountType': 'P' if txn.client_id else 'A',
                    'orderType': 'LMT'
                }
                oats_records.append(oats_record)
        
        if oats_records:
            # Generate OATS format
            oats_report = self._format_oats_report(oats_records)
            
            # Submit report
            await self._submit_report()
                oats_report,
                jurisdiction=Jurisdiction.FINRA,
                report_type=ReportType.OATS
            )
            
            report_generated.labels(Jurisdiction.FINRA.value, ReportType.OATS.value).inc()
    
    async def _generate_cftc_transaction_report(self, transactions: List[Transaction]) -> None:
        """Generate CFTC transaction report for derivatives"""
        cftc_reports = []
        
        for txn in transactions:
            if txn.instrument.asset_class in [AssetClass.DERIVATIVE, AssetClass.COMMODITY]:
                cftc_report = {}
                    'reportingEntity': self.config['cftc_reporting_entity'],
                    'counterpartyID': txn.counterparty_lei,
                    'executionTimestamp': txn.microsecond_timestamp,
                    'uniqueTransactionID': txn.transaction_id,
                    'productID': txn.instrument.isin,
                    'quantity': str(txn.quantity),
                    'price': str(txn.price),
                    'buySellIndicator': txn.side,
                    'executionVenue': txn.venue
                }
                cftc_reports.append(cftc_report)
        
        if cftc_reports:
            # Generate XML report
            xml_report = self._generate_xml_report({'transactions': cftc_reports}, 'CFTC_TRANSACTION')
            
            # Submit report
            await self._submit_report()
                xml_report,
                jurisdiction=Jurisdiction.CFTC,
                report_type=ReportType.TRANSACTION
            )
            
            report_generated.labels(Jurisdiction.CFTC.value, ReportType.TRANSACTION.value).inc()
    
    async def _generate_emir_report(self, transactions: List[Transaction]) -> None:
        """Generate EMIR derivatives report"""
        emir_reports = []
        
        for txn in transactions:
            if txn.instrument.asset_class == AssetClass.DERIVATIVE:
                emir_report = {}
                    'reportingCounterparty': self.config['emir_reporting_counterparty'],
                    'otherCounterparty': txn.counterparty_lei,
                    'tradingVenue': txn.venue,
                    'executionTimestamp': txn.timestamp.isoformat(),
                    'uniqueTradeID': txn.transaction_id,
                    'productID': txn.instrument.isin,
                    'notionalAmount': str(txn.quantity * txn.price),
                    'price': str(txn.price),
                    'currency': txn.instrument.currency,
                    'settlementDate': txn.settlement_date.isoformat() if txn.settlement_date else None
                }
                emir_reports.append(emir_report)
        
        if emir_reports:
            # Generate XML report
            xml_report = self._generate_xml_report({'derivatives': emir_reports}, 'EMIR_DERIVATIVE')
            
            # Submit report
            await self._submit_report()
                xml_report,
                jurisdiction=Jurisdiction.EMIR,
                report_type=ReportType.TRANSACTION
            )
            
            report_generated.labels(Jurisdiction.EMIR.value, ReportType.TRANSACTION.value).inc()
    
    def _generate_xml_report(self, data: Dict[str, Any], root_element: str) -> str:
        """Generate XML format report"""
        root = ET.Element(root_element)
        
        def dict_to_xml(parent, data):
            if isinstance(data, dict):
                for key, value in data.items():
                    if value is not None:
                        child = ET.SubElement(parent, key)
                        dict_to_xml(child, value)
            elif isinstance(data, list):
                for item in data:
                    dict_to_xml(parent, item)
            else:
                parent.text = str(data)
        
        dict_to_xml(root, data)
        return ET.tostring(root, encoding='unicode')
    
    def _format_oats_report(self, records: List[Dict[str, Any]]) -> str:
        """Format OATS report in required format"""
        lines = []
        for record in records:
            line = '|'.join(str(record.get(field, '')) for field in [)
                'firmROEID', 'orderReceiptTimestamp', 'orderID', 'symbol',
                'side', 'quantity', 'price', 'accountType', 'orderType'
            ])
            lines.append(line)
        return '\n'.join(lines)
    
    async def _submit_report(self, report_content: str, jurisdiction: Jurisdiction, 
                           report_type: ReportType) -> None:
        """Submit report to regulatory authority"""
        try:
            # Compress report
            compressed_content = gzip.compress(report_content.encode('utf-8'))
            
            # Encrypt if required
            if self.config.get(f'{jurisdiction.value.lower()}_encryption_required', False):
                encrypted_content = self._encrypt_report(compressed_content)
            else:
                encrypted_content = compressed_content
            
            # Determine submission method
            submission_config = self.config[f'{jurisdiction.value.lower()}_submission']
            
            if submission_config['method'] == 'SFTP':
                await self._submit_via_sftp(encrypted_content, submission_config, 
                                          jurisdiction, report_type)
            elif submission_config['method'] == 'AS2':
                await self._submit_via_as2(encrypted_content, submission_config,
                                         jurisdiction, report_type)
            elif submission_config['method'] == 'API':
                await self._submit_via_api(encrypted_content, submission_config,
                                         jurisdiction, report_type)
            
            logger.info(f"Successfully submitted {report_type.value} report to {jurisdiction.value}")
            
        except Exception as e:
            logger.error(f"Failed to submit report: {str(e)}")
            report_errors.labels(jurisdiction.value, 'submission').inc()
            raise
    
    def _encrypt_report(self, content: bytes) -> bytes:
        """Encrypt report content"""
        key = self.config['encryption_key'].encode()
        fernet = Fernet(key)
        return fernet.encrypt(content)
    
    async def _submit_via_sftp(self, content: bytes, config: Dict[str, Any],
                             jurisdiction: Jurisdiction, report_type: ReportType) -> None:
        """Submit report via SFTP"""
        transport = None
        sftp = None
        
        try:
            transport = paramiko.Transport((config['host'], config['port']))
            transport.connect(username=config['username'], password=config['password'])
            sftp = paramiko.SFTPClient.from_transport(transport)
            
            # Generate filename
            filename = f"{jurisdiction.value}_{report_type.value}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.gz"
            remote_path = f"{config['remote_directory']}/{filename}"
            
            # Upload file
            with sftp.open(remote_path, 'wb') as f:
                f.write(content)
            
        finally:
            if sftp:
                sftp.close()
            if transport:
                transport.close()
    
    async def _submit_via_as2(self, content: bytes, config: Dict[str, Any],
                            jurisdiction: Jurisdiction, report_type: ReportType) -> None:
        """Submit report via AS2 protocol"""
        # AS2 implementation would go here
        logger.info(f"AS2 submission for {jurisdiction.value} {report_type.value}")
    
    async def _submit_via_api(self, content: bytes, config: Dict[str, Any],
                            jurisdiction: Jurisdiction, report_type: ReportType) -> None:
        """Submit report via REST API"""
        # API submission implementation would go here
        logger.info(f"API submission for {jurisdiction.value} {report_type.value}")

class BestExecutionReporter:
    """Handles best execution reporting (RTS 27/28, Rule 605/606)"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.execution_metrics = defaultdict(list)
        
    async def analyze_execution_quality(self, transactions: List[Transaction]) -> Dict[str, Any]:
        """Analyze execution quality metrics"""
        metrics = {}
            'total_transactions': len(transactions),
            'venues': defaultdict(lambda: {'count': 0, 'volume': Decimal('0'), 'value': Decimal('0')}),
            'slippage': [],
            'execution_speed': [],
            'price_improvement': [],
            'effective_spread': []
        }
        
        for txn in transactions:
            venue_stats = metrics['venues'][txn.venue]
            venue_stats['count'] += 1
            venue_stats['volume'] += txn.quantity
            venue_stats['value'] += txn.quantity * txn.price
            
            # Calculate execution metrics
            if hasattr(txn, 'benchmark_price'):
                slippage = float((txn.price - txn.benchmark_price) / txn.benchmark_price)
                metrics['slippage'].append(slippage)
            
            if hasattr(txn, 'order_timestamp'):
                execution_time = (txn.timestamp - txn.order_timestamp).total_seconds()
                metrics['execution_speed'].append(execution_time)
        
        # Calculate aggregate metrics
        if metrics['slippage']:
            metrics['avg_slippage'] = np.mean(metrics['slippage'])
            metrics['slippage_volatility'] = np.std(metrics['slippage'])
        
        if metrics['execution_speed']:
            metrics['avg_execution_speed'] = np.mean(metrics['execution_speed'])
            metrics['median_execution_speed'] = np.median(metrics['execution_speed'])
        
        return metrics
    
    async def generate_rts27_report(self, start_date: datetime, end_date: datetime) -> None:
        """Generate MiFID II RTS 27 execution quality report"""
        # Fetch transactions for period
        transactions = await self._fetch_transactions(start_date, end_date)
        
        # Group by venue and instrument class
        venue_metrics = defaultdict(lambda: defaultdict(list))
        
        for txn in transactions:
            venue = txn.venue
            asset_class = txn.instrument.asset_class.value
            venue_metrics[venue][asset_class].append(txn)
        
        # Generate report for each venue
        for venue, asset_classes in venue_metrics.items():
            report = {}
                'executionVenue': venue,
                'reportingPeriod': {}
                    'start': start_date.isoformat(),
                    'end': end_date.isoformat()
                },
                'assetClasses': []
            }
            
            for asset_class, txns in asset_classes.items():
                metrics = await self.analyze_execution_quality(txns)
                
                class_report = {}
                    'assetClass': asset_class,
                    'numberOfOrdersExecuted': len(txns),
                    'valueOfOrdersExecuted': sum(t.quantity * t.price for t in txns),
                    'percentageOfPassiveOrders': self._calculate_passive_percentage(txns),
                    'percentageOfAggressiveOrders': self._calculate_aggressive_percentage(txns),
                    'percentageOfDirectedOrders': self._calculate_directed_percentage(txns),
                    'priceImprovement': metrics.get('avg_price_improvement', 0),
                    'executionSpeed': metrics.get('avg_execution_speed', 0)
                }
                report['assetClasses'].append(class_report)
            
            # Generate and submit report
            xml_report = self._generate_xml_report(report, 'RTS27Report')
            await self._submit_report(xml_report, Jurisdiction.MIFID_II, ReportType.RTS27)
            
            report_generated.labels(Jurisdiction.MIFID_II.value, ReportType.RTS27.value).inc()
    
    async def generate_rts28_report(self, year: int) -> None:
        """Generate MiFID II RTS 28 top 5 execution venues report"""
        # Fetch annual transactions
        start_date = datetime(year, 1, 1, tzinfo=timezone.utc)
        end_date = datetime(year, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        transactions = await self._fetch_transactions(start_date, end_date)
        
        # Group by client type and asset class
        client_metrics = defaultdict(lambda: defaultdict(lambda: defaultdict(Decimal)))
        
        for txn in transactions:
            client_type = 'RETAIL' if txn.client_id and txn.client_id.startswith('R') else 'PROFESSIONAL'
            asset_class = txn.instrument.asset_class.value
            venue = txn.venue
            
            client_metrics[client_type][asset_class][venue] += txn.quantity * txn.price
        
        # Generate reports
        for client_type, asset_classes in client_metrics.items():
            for asset_class, venues in asset_classes.items():
                # Get top 5 venues by volume
                top_venues = sorted(venues.items(), key=lambda x: x[1], reverse=True)[:5]
                total_volume = sum(venues.values())
                
                report = {}
                    'clientType': client_type,
                    'assetClass': asset_class,
                    'year': year,
                    'topExecutionVenues': []
                }
                
                for venue, volume in top_venues:
                    venue_report = {}
                        'venue': venue,
                        'volumePercentage': float(volume / total_volume * 100),
                        'orderPercentage': self._calculate_order_percentage(venue, transactions),
                        'passiveOrderPercentage': self._calculate_venue_passive_percentage(venue, transactions),
                        'aggressiveOrderPercentage': self._calculate_venue_aggressive_percentage(venue, transactions),
                        'directedOrderPercentage': self._calculate_venue_directed_percentage(venue, transactions)
                    }
                    report['topExecutionVenues'].append(venue_report)
                
                # Generate and submit report
                csv_report = self._generate_csv_report(report, 'RTS28')
                await self._submit_report(csv_report, Jurisdiction.MIFID_II, ReportType.RTS28)
                
                report_generated.labels(Jurisdiction.MIFID_II.value, ReportType.RTS28.value).inc()
    
    async def generate_rule_605_report(self, month: int, year: int) -> None:
        """Generate SEC Rule 605 order execution report"""
        # Fetch monthly transactions
        start_date = datetime(year, month, 1, tzinfo=timezone.utc)
        if month == 12:
            end_date = datetime(year + 1, 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
        else:
            end_date = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
        
        transactions = await self._fetch_transactions(start_date, end_date)
        
        # Group by security and order type
        security_metrics = defaultdict(lambda: defaultdict(list))
        
        for txn in transactions:
            if txn.instrument.asset_class == AssetClass.EQUITY:
                security = txn.instrument.ticker
                order_type = self._determine_order_type(txn)
                security_metrics[security][order_type].append(txn)
        
        # Generate report
        report_data = []
        
        for security, order_types in security_metrics.items():
            for order_type, txns in order_types.items():
                metrics = await self.analyze_execution_quality(txns)
                
                report_row = {}
                    'security': security,
                    'orderType': order_type,
                    'orderCount': len(txns),
                    'shareVolume': sum(t.quantity for t in txns),
                    'avgExecutionSpeed': metrics.get('avg_execution_speed', 0),
                    'priceImprovement': metrics.get('avg_price_improvement', 0),
                    'effectiveSpread': metrics.get('avg_effective_spread', 0)
                }
                report_data.append(report_row)
        
        # Generate and submit report
        csv_report = self._generate_csv_report({'data': report_data}, 'RULE605')
        await self._submit_report(csv_report, Jurisdiction.SEC, ReportType.RULE_605)
        
        report_generated.labels(Jurisdiction.SEC.value, ReportType.RULE_605.value).inc()
    
    async def generate_rule_606_report(self, quarter: int, year: int) -> None:
        """Generate SEC Rule 606 order routing report"""
        # Determine quarter dates
        quarter_starts = []
            datetime(year, 1, 1, tzinfo=timezone.utc),
            datetime(year, 4, 1, tzinfo=timezone.utc),
            datetime(year, 7, 1, tzinfo=timezone.utc),
            datetime(year, 10, 1, tzinfo=timezone.utc)
        ]
        start_date = quarter_starts[quarter - 1]
        end_date = quarter_starts[quarter] if quarter < 4 else datetime(year + 1, 1, 1, tzinfo=timezone.utc)
        end_date -= timedelta(seconds=1)
        
        transactions = await self._fetch_transactions(start_date, end_date)
        
        # Analyze routing
        routing_metrics = defaultdict(lambda: {)
            'total_orders': 0,
            'market_orders': 0,
            'limit_orders': 0,
            'other_orders': 0,
            'payment_received': Decimal('0'),
            'payment_paid': Decimal('0')
        })
        
        for txn in transactions:
            venue = txn.venue
            routing_metrics[venue]['total_orders'] += 1
            
            order_type = self._determine_order_type(txn)
            if order_type == 'MARKET':
                routing_metrics[venue]['market_orders'] += 1
            elif order_type == 'LIMIT':
                routing_metrics[venue]['limit_orders'] += 1
            else:
                routing_metrics[venue]['other_orders'] += 1
        
        # Generate report
        report = {}
            'quarter': f"Q{quarter} {year}",
            'routingVenues': []
        }
        
        total_orders = sum(m['total_orders'] for m in routing_metrics.values())
        
        for venue, metrics in routing_metrics.items():
            venue_report = {}
                'venue': venue,
                'percentOfTotalOrders': float(metrics['total_orders'] / total_orders * 100),
                'percentOfMarketOrders': float(metrics['market_orders'] / max(metrics['total_orders'], 1) * 100),
                'percentOfLimitOrders': float(metrics['limit_orders'] / max(metrics['total_orders'], 1) * 100),
                'percentOfOtherOrders': float(metrics['other_orders'] / max(metrics['total_orders'], 1) * 100),
                'netPayment': float(metrics['payment_received'] - metrics['payment_paid'])
            }
            report['routingVenues'].append(venue_report)
        
        # Generate and submit report
        xml_report = self._generate_xml_report(report, 'Rule606Report')
        await self._submit_report(xml_report, Jurisdiction.SEC, ReportType.RULE_606)
        
        report_generated.labels(Jurisdiction.SEC.value, ReportType.RULE_606.value).inc()
    
    async def _fetch_transactions(self, start_date: datetime, end_date: datetime) -> List[Transaction]:
        """Fetch transactions for date range"""
        # Implementation would fetch from database
        return []
    
    def _calculate_passive_percentage(self, transactions: List[Transaction]) -> float:
        """Calculate percentage of passive orders"""
        passive_count = sum(1 for t in transactions if getattr(t, 'order_aggression', '') == 'PASSIVE')
        return float(passive_count / len(transactions) * 100) if transactions else 0
    
    def _calculate_aggressive_percentage(self, transactions: List[Transaction]) -> float:
        """Calculate percentage of aggressive orders"""
        aggressive_count = sum(1 for t in transactions if getattr(t, 'order_aggression', '') == 'AGGRESSIVE')
        return float(aggressive_count / len(transactions) * 100) if transactions else 0
    
    def _calculate_directed_percentage(self, transactions: List[Transaction]) -> float:
        """Calculate percentage of directed orders"""
        directed_count = sum(1 for t in transactions if getattr(t, 'directed_order', False))
        return float(directed_count / len(transactions) * 100) if transactions else 0
    
    def _calculate_order_percentage(self, venue: str, transactions: List[Transaction]) -> float:
        """Calculate percentage of orders for venue"""
        venue_count = sum(1 for t in transactions if t.venue == venue)
        return float(venue_count / len(transactions) * 100) if transactions else 0
    
    def _calculate_venue_passive_percentage(self, venue: str, transactions: List[Transaction]) -> float:
        """Calculate passive percentage for specific venue"""
        venue_txns = [t for t in transactions if t.venue == venue]
        return self._calculate_passive_percentage(venue_txns)
    
    def _calculate_venue_aggressive_percentage(self, venue: str, transactions: List[Transaction]) -> float:
        """Calculate aggressive percentage for specific venue"""
        venue_txns = [t for t in transactions if t.venue == venue]
        return self._calculate_aggressive_percentage(venue_txns)
    
    def _calculate_venue_directed_percentage(self, venue: str, transactions: List[Transaction]) -> float:
        """Calculate directed percentage for specific venue"""
        venue_txns = [t for t in transactions if t.venue == venue]
        return self._calculate_directed_percentage(venue_txns)
    
    def _determine_order_type(self, transaction: Transaction) -> str:
        """Determine order type from transaction"""
        return getattr(transaction, 'order_type', 'LIMIT')
    
    def _generate_xml_report(self, data: Dict[str, Any], root_element: str) -> str:
        """Generate XML report"""
        root = ET.Element(root_element)
        
        def dict_to_xml(parent, data):
            if isinstance(data, dict):
                for key, value in data.items():
                    if value is not None:
                        child = ET.SubElement(parent, key)
                        dict_to_xml(child, value)
            elif isinstance(data, list):
                for item in data:
                    dict_to_xml(parent, item)
            else:
                parent.text = str(data)
        
        dict_to_xml(root, data)
        return ET.tostring(root, encoding='unicode')
    
    def _generate_csv_report(self, data: Dict[str, Any], report_type: str) -> str:
        """Generate CSV report"""
        output = []
        
        if report_type == 'RTS28':
            headers = ['Venue', 'Volume %', 'Order %', 'Passive %', 'Aggressive %', 'Directed %']
            output.append(','.join(headers))
            
            for venue in data.get('topExecutionVenues', []):
                row = []
                    venue['venue'],
                    f"{venue['volumePercentage']:.2f}",
                    f"{venue['orderPercentage']:.2f}",
                    f"{venue['passiveOrderPercentage']:.2f}",
                    f"{venue['aggressiveOrderPercentage']:.2f}",
                    f"{venue['directedOrderPercentage']:.2f}"
                ]
                output.append(','.join(row))
        
        elif report_type == 'RULE605':
            headers = ['Security', 'Order Type', 'Count', 'Volume', 'Avg Speed', 'Price Improvement', 'Effective Spread']
            output.append(','.join(headers))
            
            for row in data.get('data', []):
                csv_row = []
                    row['security'],
                    row['orderType'],
                    str(row['orderCount']),
                    str(row['shareVolume']),
                    f"{row['avgExecutionSpeed']:.3f}",
                    f"{row['priceImprovement']:.4f}",
                    f"{row['effectiveSpread']:.4f}"
                ]
                output.append(','.join(csv_row))
        
        return '\n'.join(output)
    
    async def _submit_report(self, report: str, jurisdiction: Jurisdiction, report_type: ReportType) -> None:
        """Submit report to regulatory authority"""
        # Implementation would submit to actual regulatory systems
        logger.info(f"Submitted {report_type.value} report for {jurisdiction.value}")

class PositionReporter:
    """Handles position reporting for all jurisdictions"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.positions = defaultdict(lambda: defaultdict(Position))
        self.position_limits = self._load_position_limits()
        
    def _load_position_limits(self) -> Dict[str, Dict[str, Decimal]]:
        """Load position limits by instrument and jurisdiction"""
        return {}
            'COMMODITY': {}
                'spot_month': Decimal('1000'),
                'single_month': Decimal('5000'),
                'all_months': Decimal('10000')
            },
            'EQUITY_OPTION': {}
                'contract_limit': Decimal('25000'),
                'exercise_limit': Decimal('25000')
            }
        }
    
    async def update_position(self, transaction: Transaction) -> None:
        """Update position based on transaction"""
        account_key = f"{transaction.client_id}:{transaction.instrument.isin}"
        position = self.positions[transaction.client_id][transaction.instrument.isin]
        
        # Update position quantity
        if transaction.side == 'BUY':
            position.quantity += transaction.quantity
        else:
            position.quantity -= transaction.quantity
        
        # Update cost basis
        if transaction.side == 'BUY':
            position.cost_basis += transaction.quantity * transaction.price
        else:
            # Calculate realized P&L
            avg_cost = position.cost_basis / position.quantity if position.quantity > 0 else Decimal('0')
            realized_pnl = transaction.quantity * (transaction.price - avg_cost)
            position.realized_pnl += realized_pnl
            position.cost_basis -= transaction.quantity * avg_cost
        
        # Update market value
        position.market_value = position.quantity * transaction.price
        position.unrealized_pnl = position.market_value - position.cost_basis
        position.last_update = transaction.timestamp
        position.transactions.append(transaction)
        
        # Check position limits
        await self._check_position_limits(position, transaction)
        
        # Check reporting thresholds
        await self._check_reporting_thresholds(position, transaction)
    
    async def _check_position_limits(self, position: Position, transaction: Transaction) -> None:
        """Check if position exceeds regulatory limits"""
        if transaction.instrument.asset_class == AssetClass.COMMODITY:
            limits = self.position_limits.get('COMMODITY', {})
            
            if abs(position.quantity) > limits.get('spot_month', Decimal('inf')):
                alert = SurveillanceAlert()
                    alert_id=str(uuid.uuid4()),
                    alert_type=AlertType.POSITION_LIMIT_BREACH,
                    severity='HIGH',
                    timestamp=datetime.now(timezone.utc),
                    instrument=transaction.instrument,
                    description=f"Position limit breach: {position.quantity} exceeds spot month limit",
                    evidence={'position': position.quantity, 'limit': limits['spot_month']}
                )
                await self._raise_surveillance_alert(alert)
    
    async def _check_reporting_thresholds(self, position: Position, transaction: Transaction) -> None:
        """Check if position requires regulatory reporting"""
        # Large trader reporting threshold
        if transaction.instrument.asset_class in [AssetClass.COMMODITY, AssetClass.DERIVATIVE]:
            if abs(position.quantity) >= self.config.get('large_trader_threshold', 25):
                await self._generate_large_trader_report(position, transaction)
        
        # Short position reporting
        if position.quantity < 0 and transaction.instrument.asset_class == AssetClass.EQUITY:
            if abs(position.quantity * transaction.price) >= self.config.get('short_position_threshold', 1000000):
                await self._generate_short_position_report(position, transaction)
    
    async def _generate_large_trader_report(self, position: Position, transaction: Transaction) -> None:
        """Generate CFTC large trader report"""
        report = {}
            'reportDate': datetime.now(timezone.utc).date().isoformat(),
            'reportingEntity': self.config['cftc_reporting_entity'],
            'traderID': position.account_id,
            'positions': [{]
                'contractCode': transaction.instrument.isin,
                'contractMonth': self._determine_contract_month(transaction.instrument),
                'longPositions': int(max(position.quantity, 0)),
                'shortPositions': int(abs(min(position.quantity, 0))),
                'deliveryMonth': transaction.instrument.maturity_date.strftime('%Y%m') if transaction.instrument.maturity_date else None
            }]
        }
        
        # Generate and submit report
        xml_report = self._generate_xml_report(report, 'LargeTraderReport')
        await self._submit_report(xml_report, Jurisdiction.CFTC, ReportType.LARGE_TRADER)
        
        report_generated.labels(Jurisdiction.CFTC.value, ReportType.LARGE_TRADER.value).inc()
    
    async def _generate_short_position_report(self, position: Position, transaction: Transaction) -> None:
        """Generate short position report"""
        report = {}
            'reportDate': datetime.now(timezone.utc).date().isoformat(),
            'reportingEntity': self.config['short_position_reporting_entity'],
            'positions': [{]
                'isin': transaction.instrument.isin,
                'issuerName': transaction.instrument.issuer,
                'shortPosition': abs(position.quantity),
                'marketValue': abs(position.market_value),
                'percentOfIssuedShares': self._calculate_percent_of_issued(position, transaction.instrument)
            }]
        }
        
        # Determine jurisdiction
        if transaction.venue.startswith('X'):
            jurisdiction = Jurisdiction.MIFID_II
        else:
            jurisdiction = Jurisdiction.SEC
        
        # Generate and submit report
        csv_report = self._generate_csv_report(report, 'SHORT_POSITION')
        await self._submit_report(csv_report, jurisdiction, ReportType.SHORT_POSITION)
        
        report_generated.labels(jurisdiction.value, ReportType.SHORT_POSITION.value).inc()
    
    async def generate_position_report(self, report_date: datetime) -> None:
        """Generate daily position report"""
        all_positions = []
        
        for client_id, client_positions in self.positions.items():
            for isin, position in client_positions.items():
                if position.quantity != 0:
                    position_data = {}
                        'clientID': client_id,
                        'isin': isin,
                        'quantity': position.quantity,
                        'marketValue': position.market_value,
                        'costBasis': position.cost_basis,
                        'unrealizedPNL': position.unrealized_pnl,
                        'realizedPNL': position.realized_pnl,
                        'lastUpdate': position.last_update.isoformat()
                    }
                    all_positions.append(position_data)
        
        # Generate report by jurisdiction
        for jurisdiction in Jurisdiction:
            jurisdiction_positions = [p for p in all_positions]
                                    if self._is_jurisdiction_applicable(p, jurisdiction)]
            
            if jurisdiction_positions:
                report = {}
                    'reportDate': report_date.isoformat(),
                    'reportingEntity': self.config[f'{jurisdiction.value.lower()}_reporting_entity'],
                    'positions': jurisdiction_positions
                }
                
                # Generate and submit report
                format_type = self.config.get(f'{jurisdiction.value.lower()}_position_format', 'XML')
                
                if format_type == 'XML':
                    report_content = self._generate_xml_report(report, 'PositionReport')
                elif format_type == 'CSV':
                    report_content = self._generate_csv_report(report, 'POSITION')
                else:
                    report_content = json.dumps(report)
                
                await self._submit_report(report_content, jurisdiction, ReportType.POSITION)
                
                report_generated.labels(jurisdiction.value, ReportType.POSITION.value).inc()
    
    def _determine_contract_month(self, instrument: ReferenceData) -> str:
        """Determine contract month for derivatives"""
        if instrument.maturity_date:
            return instrument.maturity_date.strftime('%Y%m')
        return datetime.now().strftime('%Y%m')
    
    def _calculate_percent_of_issued(self, position: Position, instrument: ReferenceData) -> float:
        """Calculate percentage of issued shares"""
        # Would lookup total issued shares from reference data
        total_issued = Decimal('1000000000')  # Placeholder
        return float(abs(position.quantity) / total_issued * 100)
    
    def _is_jurisdiction_applicable(self, position_data: Dict[str, Any], jurisdiction: Jurisdiction) -> bool:
        """Determine if position falls under jurisdiction"""
        # Simplified logic - would check based on venue, instrument type, etc.
        return True
    
    def _generate_xml_report(self, data: Dict[str, Any], root_element: str) -> str:
        """Generate XML report"""
        root = ET.Element(root_element)
        
        def dict_to_xml(parent, data):
            if isinstance(data, dict):
                for key, value in data.items():
                    if value is not None:
                        child = ET.SubElement(parent, key)
                        dict_to_xml(child, value)
            elif isinstance(data, list):
                for item in data:
                    dict_to_xml(parent, item)
            else:
                parent.text = str(data)
        
        dict_to_xml(root, data)
        return ET.tostring(root, encoding='unicode')
    
    def _generate_csv_report(self, data: Dict[str, Any], report_type: str) -> str:
        """Generate CSV report"""
        output = []
        
        if report_type == 'SHORT_POSITION':
            headers = ['ISIN', 'Issuer', 'Short Position', 'Market Value', '% of Issued']
            output.append(','.join(headers))
            
            for position in data.get('positions', []):
                row = []
                    position['isin'],
                    position['issuerName'],
                    str(position['shortPosition']),
                    str(position['marketValue']),
                    f"{position['percentOfIssuedShares']:.2f}"
                ]
                output.append(','.join(row))
        
        elif report_type == 'POSITION':
            headers = ['Client ID', 'ISIN', 'Quantity', 'Market Value', 'Cost Basis', 'Unrealized PNL', 'Realized PNL']
            output.append(','.join(headers))
            
            for position in data.get('positions', []):
                row = []
                    position['clientID'],
                    position['isin'],
                    str(position['quantity']),
                    str(position['marketValue']),
                    str(position['costBasis']),
                    str(position['unrealizedPNL']),
                    str(position['realizedPNL'])
                ]
                output.append(','.join(row))
        
        return '\n'.join(output)
    
    async def _submit_report(self, report: str, jurisdiction: Jurisdiction, report_type: ReportType) -> None:
        """Submit report to regulatory authority"""
        logger.info(f"Submitted {report_type.value} report for {jurisdiction.value}")
    
    async def _raise_surveillance_alert(self, alert: SurveillanceAlert) -> None:
        """Raise surveillance alert"""
        logger.warning(f"Surveillance alert: {alert.alert_type.value} - {alert.description}")
        surveillance_alerts.labels(alert.alert_type.value, alert.severity).inc()

class MarketSurveillance:
    """Market surveillance and pattern detection"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.alert_history = deque(maxlen=10000)
        self.pattern_detectors = self._initialize_pattern_detectors()
        
    def _initialize_pattern_detectors(self) -> Dict[AlertType, callable]:
        """Initialize pattern detection algorithms"""
        return {}
            AlertType.SPOOFING: self._detect_spoofing,
            AlertType.LAYERING: self._detect_layering,
            AlertType.WASH_TRADE: self._detect_wash_trade,
            AlertType.FRONT_RUNNING: self._detect_front_running,
            AlertType.MARKET_MANIPULATION: self._detect_market_manipulation,
            AlertType.EXCESSIVE_MESSAGING: self._detect_excessive_messaging
        }
    
    async def analyze_transaction_stream(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Analyze transaction stream for suspicious patterns"""
        alerts = []
        
        # Run all pattern detectors
        for alert_type, detector in self.pattern_detectors.items():
            detected_alerts = await detector(transactions)
            alerts.extend(detected_alerts)
        
        # Store alerts in history
        for alert in alerts:
            self.alert_history.append(alert)
            surveillance_alerts.labels(alert.alert_type.value, alert.severity).inc()
        
        return alerts
    
    async def _detect_spoofing(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Detect spoofing patterns"""
        alerts = []
        
        # Group transactions by trader and time window
        trader_activity = defaultdict(list)
        
        for txn in transactions:
            trader_activity[txn.trader_id].append(txn)
        
        for trader_id, trader_txns in trader_activity.items():
            # Look for pattern of large orders followed by cancellations
            if len(trader_txns) >= 5:
                # Simplified spoofing detection
                order_sizes = [t.quantity for t in trader_txns]
                avg_size = np.mean(order_sizes)
                
                # Check for outlier orders
                for i, txn in enumerate(trader_txns):
                    if txn.quantity > avg_size * 3:
                        # Check if followed by opposite side trades
                        subsequent_txns = trader_txns[i+1:i+5]
                        opposite_trades = [t for t in subsequent_txns if t.side != txn.side]
                        
                        if len(opposite_trades) >= 2:
                            alert = SurveillanceAlert()
                                alert_id=str(uuid.uuid4()),
                                alert_type=AlertType.SPOOFING,
                                severity='HIGH',
                                timestamp=datetime.now(timezone.utc),
                                instrument=txn.instrument,
                                description=f"Potential spoofing detected for trader {trader_id}",
                                evidence={}
                                    'large_order': str(txn.quantity),
                                    'avg_order_size': str(avg_size),
                                    'subsequent_opposite_trades': len(opposite_trades)
                                }
                            )
                            alerts.append(alert)
        
        return alerts
    
    async def _detect_layering(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Detect layering patterns"""
        alerts = []
        
        # Group by instrument and time window
        instrument_activity = defaultdict(lambda: defaultdict(list))
        
        for txn in transactions:
            time_bucket = txn.timestamp.replace(second=0, microsecond=0)
            instrument_activity[txn.instrument.isin][time_bucket].append(txn)
        
        for isin, time_buckets in instrument_activity.items():
            for time_bucket, bucket_txns in time_buckets.items():
                # Check for multiple orders at different price levels
                buy_orders = [t for t in bucket_txns if t.side == 'BUY']
                sell_orders = [t for t in bucket_txns if t.side == 'SELL']
                
                if len(buy_orders) >= 5 or len(sell_orders) >= 5:
                    # Check for price ladder pattern
                    side_orders = buy_orders if len(buy_orders) >= 5 else sell_orders
                    prices = sorted([t.price for t in side_orders])
                    
                    if len(set(prices)) >= 4:  # Multiple price levels
                        alert = SurveillanceAlert()
                            alert_id=str(uuid.uuid4()),
                            alert_type=AlertType.LAYERING,
                            severity='MEDIUM',
                            timestamp=datetime.now(timezone.utc),
                            instrument=side_orders[0].instrument,
                            description=f"Potential layering detected for {isin}",
                            evidence={}
                                'order_count': len(side_orders),
                                'price_levels': len(set(prices)),
                                'time_window': time_bucket.isoformat()
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    async def _detect_wash_trade(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Detect wash trading patterns"""
        alerts = []
        
        # Group by instrument
        instrument_trades = defaultdict(list)
        
        for txn in transactions:
            instrument_trades[txn.instrument.isin].append(txn)
        
        for isin, trades in instrument_trades.items():
            # Look for trades with same beneficial owner
            for i, trade1 in enumerate(trades):
                for trade2 in trades[i+1:]:
                    # Check if opposite sides and close in time
                    time_diff = abs((trade2.timestamp - trade1.timestamp).total_seconds())
                    
                    if (trade1.side != trade2.side and)
                        time_diff < 60 and  # Within 1 minute
                        trade1.price == trade2.price and
                        trade1.quantity == trade2.quantity):
                        
                        # Check for same beneficial owner (simplified)
                        if (trade1.client_id == trade2.client_id or)
                            trade1.trader_id == trade2.trader_id):
                            
                            alert = SurveillanceAlert()
                                alert_id=str(uuid.uuid4()),
                                alert_type=AlertType.WASH_TRADE,
                                severity='HIGH',
                                timestamp=datetime.now(timezone.utc),
                                instrument=trade1.instrument,
                                description=f"Potential wash trade detected for {isin}",
                                evidence={}
                                    'trade1_id': trade1.transaction_id,
                                    'trade2_id': trade2.transaction_id,
                                    'price': str(trade1.price),
                                    'quantity': str(trade1.quantity),
                                    'time_diff_seconds': time_diff
                                }
                            )
                            alerts.append(alert)
        
        return alerts
    
    async def _detect_front_running(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Detect front running patterns"""
        alerts = []
        
        # Look for pattern of small trades before large client orders
        trader_client_activity = defaultdict(lambda: {'trader': [], 'client': []})
        
        for txn in transactions:
            key = f"{txn.trader_id}:{txn.instrument.isin}"
            if txn.client_id:
                trader_client_activity[key]['client'].append(txn)
            else:
                trader_client_activity[key]['trader'].append(txn)
        
        for key, activity in trader_client_activity.items():
            trader_trades = sorted(activity['trader'], key=lambda x: x.timestamp)
            client_trades = sorted(activity['client'], key=lambda x: x.timestamp)
            
            for client_trade in client_trades:
                # Look for trader trades just before client trade
                preceding_trades = []
                    t for t in trader_trades
                    if (client_trade.timestamp - t.timestamp).total_seconds() < 300  # 5 minutes
                    and t.timestamp < client_trade.timestamp
                    and t.side == client_trade.side
                ]
                
                if preceding_trades and client_trade.quantity > Decimal('10000'):
                    alert = SurveillanceAlert()
                        alert_id=str(uuid.uuid4()),
                        alert_type=AlertType.FRONT_RUNNING,
                        severity='CRITICAL',
                        timestamp=datetime.now(timezone.utc),
                        instrument=client_trade.instrument,
                        description=f"Potential front running detected",
                        evidence={}
                            'client_trade_id': client_trade.transaction_id,
                            'client_trade_size': str(client_trade.quantity),
                            'preceding_trader_trades': len(preceding_trades),
                            'trader_id': client_trade.trader_id
                        }
                    )
                    alerts.append(alert)
        
        return alerts
    
    async def _detect_market_manipulation(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Detect general market manipulation patterns"""
        alerts = []
        
        # Analyze price impact and volume patterns
        instrument_metrics = defaultdict(lambda: {)
            'prices': [],
            'volumes': [],
            'timestamps': []
        })
        
        for txn in transactions:
            metrics = instrument_metrics[txn.instrument.isin]
            metrics['prices'].append(float(txn.price))
            metrics['volumes'].append(float(txn.quantity))
            metrics['timestamps'].append(txn.timestamp)
        
        for isin, metrics in instrument_metrics.items():
            if len(metrics['prices']) >= 10:
                prices = np.array(metrics['prices'])
                volumes = np.array(metrics['volumes'])
                
                # Calculate price volatility
                price_returns = np.diff(prices) / prices[:-1]
                volatility = np.std(price_returns)
                
                # Check for abnormal price movements
                if volatility > 0.05:  # 5% volatility threshold
                    # Check for volume spikes
                    volume_mean = np.mean(volumes)
                    volume_spikes = np.sum(volumes > volume_mean * 3)
                    
                    if volume_spikes >= 3:
                        alert = SurveillanceAlert()
                            alert_id=str(uuid.uuid4()),
                            alert_type=AlertType.MARKET_MANIPULATION,
                            severity='HIGH',
                            timestamp=datetime.now(timezone.utc),
                            instrument=transactions[0].instrument,
                            description=f"Potential market manipulation detected for {isin}",
                            evidence={}
                                'price_volatility': f"{volatility:.4f}",
                                'volume_spikes': volume_spikes,
                                'transaction_count': len(metrics['prices'])
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    async def _detect_excessive_messaging(self, transactions: List[Transaction]) -> List[SurveillanceAlert]:
        """Detect excessive order messaging"""
        alerts = []
        
        # Count messages by trader
        trader_message_counts = defaultdict(int)
        
        for txn in transactions:
            trader_message_counts[txn.trader_id] += 1
        
        # Check against thresholds
        for trader_id, count in trader_message_counts.items():
            if count > self.config.get('excessive_messaging_threshold', 1000):
                alert = SurveillanceAlert()
                    alert_id=str(uuid.uuid4()),
                    alert_type=AlertType.EXCESSIVE_MESSAGING,
                    severity='LOW',
                    timestamp=datetime.now(timezone.utc),
                    instrument=transactions[0].instrument,  # Placeholder
                    description=f"Excessive messaging detected for trader {trader_id}",
                    evidence={}
                        'message_count': count,
                        'threshold': self.config.get('excessive_messaging_threshold', 1000)
                    }
                )
                alerts.append(alert)
        
        return alerts
    
    async def generate_surveillance_report(self, start_date: datetime, end_date: datetime) -> None:
        """Generate surveillance activity report"""
        # Filter alerts for date range
        period_alerts = []
            alert for alert in self.alert_history
            if start_date <= alert.timestamp <= end_date
        ]
        
        # Group by alert type and severity
        alert_summary = defaultdict(lambda: defaultdict(int))
        
        for alert in period_alerts:
            alert_summary[alert.alert_type.value][alert.severity] += 1
        
        # Generate report
        report = {}
            'reportPeriod': {}
                'start': start_date.isoformat(),
                'end': end_date.isoformat()
            },
            'totalAlerts': len(period_alerts),
            'alertsByType': dict(alert_summary),
            'criticalAlerts': []
                {}
                    'alertId': alert.alert_id,
                    'type': alert.alert_type.value,
                    'timestamp': alert.timestamp.isoformat(),
                    'description': alert.description,
                    'status': alert.status
                }
                for alert in period_alerts if alert.severity == 'CRITICAL'
            ]
        }
        
        # Generate and save report
        report_content = json.dumps(report, indent=2)
        
        # Submit to compliance system
        await self._submit_surveillance_report(report_content)
        
        report_generated.labels('SURVEILLANCE', ReportType.SURVEILLANCE.value).inc()
    
    async def _submit_surveillance_report(self, report: str) -> None:
        """Submit surveillance report to compliance system"""
        logger.info("Submitted surveillance report to compliance system")

class RegulatoryReportingAutomation:
    """Main regulatory reporting automation system"""
    
    def __init__(self, config_file: str):
        self.config = self._load_config(config_file)
        self.transaction_reporter = TransactionReporter(self.config)
        self.best_execution_reporter = BestExecutionReporter(self.config)
        self.position_reporter = PositionReporter(self.config)
        self.surveillance = MarketSurveillance(self.config)
        self.scheduler = self._initialize_scheduler()
        self.redis_client = None
        self.db_connection = None
        
    def _load_config(self, config_file: str) -> Dict[str, Any]:
        """Load configuration from file"""
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning(f"Config file {config_file} not found, using defaults")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {}
            'batch_size': 1000,
            'large_trader_threshold': 25,
            'short_position_threshold': 1000000,
            'excessive_messaging_threshold': 1000,
            'encryption_key': Fernet.generate_key().decode(),
            'mifid_reporting_entity': 'LEI1234567890123456',
            'mifid_investment_firm_lei': 'LEI1234567890123456',
            'mifid_submitting_entity_lei': 'LEI1234567890123456',
            'mifid_submission': {}
                'method': 'SFTP',
                'host': 'regulator.example.com',
                'port': 22,
                'username': 'reporter',
                'password': 'password',
                'remote_directory': '/reports'
            },
            'sec_submission': {}
                'method': 'API',
                'endpoint': 'https://api.sec.gov/submit',
                'api_key': 'your-api-key'
            },
            'cat_firm_id': 'FIRM12345',
            'oats_firm_id': 'OATS12345',
            'cftc_reporting_entity': 'CFTC12345',
            'emir_reporting_counterparty': 'EMIR12345',
            'redis_host': 'localhost',
            'redis_port': 6379,
            'db_host': 'localhost',
            'db_port': 5432,
            'db_name': 'regulatory_reporting',
            'db_user': 'reporter',
            'db_password': 'password'
        }
    
    def _initialize_scheduler(self) -> schedule.Scheduler:
        """Initialize report scheduling"""
        scheduler = schedule.Scheduler()
        
        # Daily reports
        scheduler.every().day.at("18:00").do()
            lambda: asyncio.create_task(self._run_daily_reports())
        )
        
        # Weekly reports
        scheduler.every().monday.at("06:00").do()
            lambda: asyncio.create_task(self._run_weekly_reports())
        )
        
        # Monthly reports
        scheduler.every().day.at("00:01").do()
            lambda: asyncio.create_task(self._check_monthly_reports())
        )
        
        # Quarterly reports
        scheduler.every().day.at("00:01").do()
            lambda: asyncio.create_task(self._check_quarterly_reports())
        )
        
        return scheduler
    
    async def initialize(self) -> None:
        """Initialize connections and resources"""
        # Initialize Redis connection
        self.redis_client = await aioredis.create_redis_pool()
            f"redis://{self.config['redis_host']}:{self.config['redis_port']}"
        )
        
        # Initialize database connection
        self.db_connection = await asyncpg.connect()
            host=self.config['db_host'],
            port=self.config['db_port'],
            database=self.config['db_name'],
            user=self.config['db_user'],
            password=self.config['db_password']
        )
        
        # Start Prometheus metrics server
        start_http_server(8000)
        
        logger.info("Regulatory reporting automation system initialized")
    
    async def process_transaction(self, transaction_data: Dict[str, Any]) -> None:
        """Process incoming transaction"""
        try:
            # Create transaction object
            instrument = ReferenceData()
                lei=transaction_data['instrument']['lei'],
                isin=transaction_data['instrument'].get('isin'),
                ticker=transaction_data['instrument'].get('ticker'),
                exchange=transaction_data['instrument'].get('exchange'),
                currency=transaction_data['instrument'].get('currency', 'USD'),
                asset_class=AssetClass[transaction_data['instrument']['asset_class']]
            )
            
            transaction = Transaction()
                transaction_id=transaction_data['transaction_id'],
                timestamp=datetime.fromisoformat(transaction_data['timestamp']),
                microsecond_timestamp=transaction_data.get('microsecond_timestamp', 
                    int(datetime.fromisoformat(transaction_data['timestamp']).timestamp() * 1_000_000)),
                instrument=instrument,
                side=transaction_data['side'],
                quantity=Decimal(transaction_data['quantity']),
                price=Decimal(transaction_data['price']),
                venue=transaction_data['venue'],
                counterparty_lei=transaction_data.get('counterparty_lei'),
                client_id=transaction_data.get('client_id'),
                order_id=transaction_data['order_id'],
                execution_id=transaction_data['execution_id'],
                trader_id=transaction_data['trader_id'],
                desk=transaction_data['desk'],
                strategy=transaction_data.get('strategy'),
                algorithmic=transaction_data.get('algorithmic', False),
                short_sale=transaction_data.get('short_sale', False),
                settlement_date=datetime.fromisoformat(transaction_data['settlement_date']) 
                    if transaction_data.get('settlement_date') else None
            )
            
            # Process transaction
            await self.transaction_reporter.capture_transaction(transaction)
            
            # Update positions
            await self.position_reporter.update_position(transaction)
            
            # Run surveillance
            alerts = await self.surveillance.analyze_transaction_stream([transaction])
            
            # Handle alerts
            for alert in alerts:
                await self._handle_surveillance_alert(alert)
            
        except Exception as e:
            logger.error(f"Failed to process transaction: {str(e)}")
            report_errors.labels('unknown', 'processing').inc()
    
    async def _handle_surveillance_alert(self, alert: SurveillanceAlert) -> None:
        """Handle surveillance alert"""
        # Store alert in database
        await self.db_connection.execute(""")
            INSERT INTO surveillance_alerts 
            (alert_id, alert_type, severity, timestamp, instrument_isin, description, evidence, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        """, alert.alert_id, alert.alert_type.value, alert.severity, alert.timestamp,
            alert.instrument.isin, alert.description, json.dumps(alert.evidence), alert.status)
        
        # Send notification for critical alerts
        if alert.severity == 'CRITICAL':
            await self._send_alert_notification(alert)
    
    async def _send_alert_notification(self, alert: SurveillanceAlert) -> None:
        """Send notification for critical alerts"""
        # Email notification
        msg = MIMEMultipart()
        msg['From'] = self.config.get('alert_from_email', 'alerts@example.com')
        msg['To'] = self.config.get('alert_to_email', 'compliance@example.com')
        msg['Subject'] = f"CRITICAL: {alert.alert_type.value} Alert"
        
        body = f"""
        Critical surveillance alert detected:
        
        Alert ID: {alert.alert_id}
        Type: {alert.alert_type.value}
        Timestamp: {alert.timestamp}
        Instrument: {alert.instrument.isin}
        Description: {alert.description}
        
        Evidence:
        {json.dumps(alert.evidence, indent=2)}
        
        Please investigate immediately.
        """
        
        msg.attach(MIMEText(body, 'plain'))
        
        # Send email (implementation would use actual SMTP)
        logger.info(f"Sent critical alert notification: {alert.alert_id}")
    
    async def _run_daily_reports(self) -> None:
        """Run daily regulatory reports"""
        report_date = datetime.now(timezone.utc).date()
        
        try:
            # Position reports
            await self.position_reporter.generate_position_report()
                datetime.combine(report_date, datetime.min.time(), timezone.utc)
            )
            
            # Process any pending transaction batches
            for jurisdiction in Jurisdiction:
                if self.transaction_reporter.transaction_buffer[jurisdiction]:
                    await self.transaction_reporter._process_transaction_batch(jurisdiction)
            
            logger.info(f"Completed daily reports for {report_date}")
            
        except Exception as e:
            logger.error(f"Failed to run daily reports: {str(e)}")
            report_errors.labels('daily', 'generation').inc()
    
    async def _run_weekly_reports(self) -> None:
        """Run weekly regulatory reports"""
        end_date = datetime.now(timezone.utc)
        start_date = end_date - timedelta(days=7)
        
        try:
            # Surveillance reports
            await self.surveillance.generate_surveillance_report(start_date, end_date)
            
            logger.info(f"Completed weekly reports for {start_date.date()} to {end_date.date()}")
            
        except Exception as e:
            logger.error(f"Failed to run weekly reports: {str(e)}")
            report_errors.labels('weekly', 'generation').inc()
    
    async def _check_monthly_reports(self) -> None:
        """Check and run monthly reports if needed"""
        today = datetime.now(timezone.utc).date()
        
        if today.day == 1:  # First day of month
            # Run previous month reports
            if today.month == 1:
                month = 12
                year = today.year - 1
            else:
                month = today.month - 1
                year = today.year
            
            try:
                # RTS 27 reports
                start_date = datetime(year, month, 1, tzinfo=timezone.utc)
                end_date = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1) if month < 12 else datetime(year + 1, 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
                
                await self.best_execution_reporter.generate_rts27_report(start_date, end_date)
                
                # Rule 605 reports
                await self.best_execution_reporter.generate_rule_605_report(month, year)
                
                logger.info(f"Completed monthly reports for {month}/{year}")
                
            except Exception as e:
                logger.error(f"Failed to run monthly reports: {str(e)}")
                report_errors.labels('monthly', 'generation').inc()
    
    async def _check_quarterly_reports(self) -> None:
        """Check and run quarterly reports if needed"""
        today = datetime.now(timezone.utc).date()
        
        # Check if first day of quarter
        if today.month in [1, 4, 7, 10] and today.day == 1:
            # Determine previous quarter
            if today.month == 1:
                quarter = 4
                year = today.year - 1
            else:
                quarter = (today.month - 1) // 3
                year = today.year
            
            try:
                # Rule 606 reports
                await self.best_execution_reporter.generate_rule_606_report(quarter, year)
                
                logger.info(f"Completed quarterly reports for Q{quarter} {year}")
                
            except Exception as e:
                logger.error(f"Failed to run quarterly reports: {str(e)}")
                report_errors.labels('quarterly', 'generation').inc()
    
    async def _check_annual_reports(self) -> None:
        """Check and run annual reports if needed"""
        today = datetime.now(timezone.utc).date()
        
        if today.month == 1 and today.day == 1:  # New Year's Day
            year = today.year - 1
            
            try:
                # RTS 28 reports
                await self.best_execution_reporter.generate_rts28_report(year)
                
                logger.info(f"Completed annual reports for {year}")
                
            except Exception as e:
                logger.error(f"Failed to run annual reports: {str(e)}")
                report_errors.labels('annual', 'generation').inc()
    
    async def run(self) -> None:
        """Run the regulatory reporting system"""
        await self.initialize()
        
        # Start scheduler in background
        async def run_scheduler():
            while True:
                self.scheduler.run_pending()
                await asyncio.sleep(60)  # Check every minute
        
        scheduler_task = asyncio.create_task(run_scheduler())
        
        try:
            # Main event loop
            while True:
                # Process incoming transactions from queue
                if self.redis_client:
                    transaction_data = await self.redis_client.blpop('transaction_queue', timeout=1)
                    if transaction_data:
                        await self.process_transaction(json.loads(transaction_data[1]))
                else:
                    await asyncio.sleep(1)
                    
        except KeyboardInterrupt:
            logger.info("Shutting down regulatory reporting system")
            scheduler_task.cancel()
            if self.redis_client:
                self.redis_client.close()
                await self.redis_client.wait_closed()
            if self.db_connection:
                await self.db_connection.close()

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Regulatory Reporting Automation System')
    parser.add_argument('--config', type=str, default='config.json', help='Configuration file path')
    parser.add_argument('--test', action='store_true', help='Run in test mode')
    args = parser.parse_args()
    
    if args.test:
        # Run test mode
        asyncio.run(test_system())
    else:
        # Run production system
        system = RegulatoryReportingAutomation(args.config)
        asyncio.run(system.run())

async def test_system():
    """Test the regulatory reporting system"""
    logger.info("Running regulatory reporting system in test mode")
    
    # Create test configuration
    config = {}
        'batch_size': 10,
        'large_trader_threshold': 5,
        'short_position_threshold': 100000,
        'excessive_messaging_threshold': 100,
        'encryption_key': Fernet.generate_key().decode(),
        'mifid_reporting_entity': 'TEST123456789012345',
        'mifid_investment_firm_lei': 'TEST123456789012345',
        'mifid_submitting_entity_lei': 'TEST123456789012345',
        'mifid_submission': {'method': 'API', 'endpoint': 'http://test.example.com'},
        'sec_submission': {'method': 'API', 'endpoint': 'http://test.example.com'},
        'cat_firm_id': 'TEST12345',
        'oats_firm_id': 'TEST12345',
        'cftc_reporting_entity': 'TEST12345',
        'emir_reporting_counterparty': 'TEST12345'
    }
    
    # Initialize system
    system = RegulatoryReportingAutomation.__new__(RegulatoryReportingAutomation)
    system.config = config
    system.transaction_reporter = TransactionReporter(config)
    system.best_execution_reporter = BestExecutionReporter(config)
    system.position_reporter = PositionReporter(config)
    system.surveillance = MarketSurveillance(config)
    
    # Generate test transactions
    test_transactions = []
    
    for i in range(20):
        instrument = ReferenceData()
            lei='TESTLEI12345678901' + str(i % 3),
            isin='US' + str(i).zfill(10),
            ticker='TEST' + str(i % 5),
            exchange='XNYS',
            currency='USD',
            asset_class=AssetClass.EQUITY
        )
        
        transaction = Transaction()
            transaction_id=f"TEST{i:06d}",
            timestamp=datetime.now(timezone.utc) - timedelta(minutes=i),
            microsecond_timestamp=int((datetime.now(timezone.utc) - timedelta(minutes=i)).timestamp() * 1_000_000),
            instrument=instrument,
            side='BUY' if i % 2 == 0 else 'SELL',
            quantity=Decimal(str(100 * (i + 1))),
            price=Decimal(str(100 + i * 0.5)),
            venue='XNYS',
            counterparty_lei='CTPY123456789012345',
            client_id=f"CLIENT{i % 3}",
            order_id=f"ORDER{i:06d}",
            execution_id=f"EXEC{i:06d}",
            trader_id=f"TRADER{i % 2}",
            desk='EQUITY_DESK',
            algorithmic=i % 3 == 0
        )
        
        test_transactions.append(transaction)
    
    # Test transaction reporting
    logger.info("Testing transaction reporting...")
    for txn in test_transactions:
        await system.transaction_reporter.capture_transaction(txn)
    
    # Force batch processing
    for jurisdiction in Jurisdiction:
        if system.transaction_reporter.transaction_buffer[jurisdiction]:
            await system.transaction_reporter._process_transaction_batch(jurisdiction)
    
    # Test position reporting
    logger.info("Testing position reporting...")
    for txn in test_transactions:
        await system.position_reporter.update_position(txn)
    
    # Test surveillance
    logger.info("Testing market surveillance...")
    alerts = await system.surveillance.analyze_transaction_stream(test_transactions)
    logger.info(f"Generated {len(alerts)} surveillance alerts")
    
    for alert in alerts:
        logger.info(f"Alert: {alert.alert_type.value} - {alert.description}")
    
    # Test best execution reporting
    logger.info("Testing best execution analysis...")
    metrics = await system.best_execution_reporter.analyze_execution_quality(test_transactions)
    logger.info(f"Execution metrics: {json.dumps(metrics, default=str, indent=2)}")
    
    logger.info("Test completed successfully")

# Define the main class
class RegulatoryReportingSystem:
    """Automated regulatory reporting system"""
    def __init__(self, config=None):
        self.config = config or {}
        self.reports = []
    
    def generate_report(self, report_type, data):
        """Generate regulatory report"""
        report = {}
            'type': report_type,
            'data': data,
            'timestamp': datetime.now(),
            'status': 'generated'
        }
        self.reports.append(report)
        return report

# Create alias
ReportingSystem = RegulatoryReportingSystem

if __name__ == "__main__":
    main()