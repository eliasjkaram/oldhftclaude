
class KubernetesDeploymentConfig:
    """Configuration for Kubernetes deployments"""
    def __init__(self, name, namespace='default'):
        self.name = name
        self.namespace = namespace
        self.replicas = 1
        self.image = 'alpine:latest'
        self.resources = {}
            'requests': {'memory': '64Mi', 'cpu': '250m'},
            'limits': {'memory': '128Mi', 'cpu': '500m'}
        }
        self.env_vars = {}
        self.ports = []
    
    def to_dict(self):
        return {}
            'apiVersion': 'apps/v1',
            'kind': 'Deployment',
            'metadata': {}
                'name': self.name,
                'namespace': self.namespace
            },
            'spec': {}
                'replicas': self.replicas,
                'selector': {}
                    'matchLabels': {}
                        'app': self.name
                    }
                },
                'template': {}
                    'metadata': {}
                        'labels': {}
                            'app': self.name
                        }
                    },
                    'spec': {}
                        'containers': [{]
                            'name': self.name,
                            'image': self.image,
                            'resources': self.resources,
                            'env': [{'name': k, 'value': v} for k, v in self.env_vars.items()],
                            'ports': self.ports
                        }]
                    }
                }
            }
        }

#!/usr/bin/env python3
"""
Kubernetes Deployment Configuration Generator for Trading System

This script generates YAML configurations for deploying a trading system to Kubernetes,
including deployments, services, configmaps, secrets, and horizontal pod autoscaling.
"""

import yaml
import base64
import os
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class ServiceType(Enum):
    """Kubernetes service types"""
    CLUSTER_IP = "ClusterIP"
    NODE_PORT = "NodePort"
    LOAD_BALANCER = "LoadBalancer"


class DeploymentStrategy(Enum):
    """Deployment strategies"""
    ROLLING_UPDATE = "RollingUpdate"
    RECREATE = "Recreate"


@dataclass
class ResourceRequirements:
    """Container resource requirements"""
    cpu_request: str = "100m"
    memory_request: str = "128Mi"
    cpu_limit: str = "500m"
    memory_limit: str = "512Mi"


@dataclass
class ServiceConfig:
    """Service configuration"""
    name: str
    port: int
    target_port: int
    service_type: ServiceType = ServiceType.CLUSTER_IP
    node_port: Optional[int] = None


@dataclass
class ComponentConfig:
    """Configuration for a single component"""
    name: str
    image: str
    replicas: int = 1
    port: int = 8080
    env_vars: Dict[str, str] = field(default_factory=dict)
    secrets: Dict[str, str] = field(default_factory=dict)
    config_files: Dict[str, str] = field(default_factory=dict)
    resources: ResourceRequirements = field(default_factory=ResourceRequirements)
    health_check_path: str = "/health"
    ready_check_path: str = "/ready"
    service_config: Optional[ServiceConfig] = None
    hpa_enabled: bool = True
    min_replicas: int = 1
    max_replicas: int = 10
    target_cpu_utilization: int = 70
    target_memory_utilization: int = 80


class KubernetesConfigGenerator:
    """Generates Kubernetes configurations for trading system components"""
    
    def __init__(self, namespace: str = "trading-system", 
                 image_registry: str = "docker.io/trading"):
        self.namespace = namespace
        self.image_registry = image_registry
        self.configs: List[Dict[str, Any]] = []
    
    def add_namespace(self) -> None:
        """Add namespace configuration"""
        namespace_config = {}
            "apiVersion": "v1",
            "kind": "Namespace",
            "metadata": {}
                "name": self.namespace,
                "labels": {}
                    "name": self.namespace,
                    "app": "trading-system"
                }
            }
        }
        self.configs.append(namespace_config)
    
    def create_configmap(self, component: ComponentConfig) -> Optional[Dict[str, Any]]:
        """Create ConfigMap for component configuration files"""
        if not component.config_files:
            return None
        
        configmap = {}
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {}
                "name": f"{component.name}-config",
                "namespace": self.namespace,
                "labels": {}
                    "app": "trading-system",
                    "component": component.name
                }
            },
            "data": component.config_files
        }
        return configmap
    
    def create_secret(self, component: ComponentConfig) -> Optional[Dict[str, Any]]:
        """Create Secret for sensitive data"""
        if not component.secrets:
            return None
        
        # Encode secrets in base64
        encoded_secrets = {}
            key: base64.b64encode(value.encode()).decode()
            for key, value in component.secrets.items()
        }
        
        secret = {}
            "apiVersion": "v1",
            "kind": "Secret",
            "metadata": {}
                "name": f"{component.name}-secret",
                "namespace": self.namespace,
                "labels": {}
                    "app": "trading-system",
                    "component": component.name
                }
            },
            "type": "Opaque",
            "data": encoded_secrets
        }
        return secret
    
    def create_deployment(self, component: ComponentConfig) -> Dict[str, Any]:
        """Create Deployment configuration"""
        container = {}
            "name": component.name,
            "image": f"{self.image_registry}/{component.image}",
            "imagePullPolicy": "Always",
            "ports": [{]
                "containerPort": component.port,
                "name": "http"
            }],
            "env": [],
            "resources": {}
                "requests": {}
                    "cpu": component.resources.cpu_request,
                    "memory": component.resources.memory_request
                },
                "limits": {}
                    "cpu": component.resources.cpu_limit,
                    "memory": component.resources.memory_limit
                }
            },
            "livenessProbe": {}
                "httpGet": {}
                    "path": component.health_check_path,
                    "port": component.port
                },
                "initialDelaySeconds": 30,
                "periodSeconds": 10,
                "timeoutSeconds": 5,
                "failureThreshold": 3
            },
            "readinessProbe": {}
                "httpGet": {}
                    "path": component.ready_check_path,
                    "port": component.port
                },
                "initialDelaySeconds": 10,
                "periodSeconds": 5,
                "timeoutSeconds": 3,
                "failureThreshold": 3
            }
        }
        
        # Add environment variables
        for key, value in component.env_vars.items():
            container["env"].append({)
                "name": key,
                "value": value
            })
        
        # Add secrets as environment variables
        if component.secrets:
            for key in component.secrets.keys():
                container["env"].append({)
                    "name": key,
                    "valueFrom": {}
                        "secretKeyRef": {}
                            "name": f"{component.name}-secret",
                            "key": key
                        }
                    }
                })
        
        # Add volume mounts for config files
        if component.config_files:
            container["volumeMounts"] = [{]
                "name": "config",
                "mountPath": "/config",
                "readOnly": True
            }]
        
        deployment = {}
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {}
                "name": component.name,
                "namespace": self.namespace,
                "labels": {}
                    "app": "trading-system",
                    "component": component.name
                }
            },
            "spec": {}
                "replicas": component.replicas,
                "selector": {}
                    "matchLabels": {}
                        "app": "trading-system",
                        "component": component.name
                    }
                },
                "strategy": {}
                    "type": DeploymentStrategy.ROLLING_UPDATE.value,
                    "rollingUpdate": {}
                        "maxSurge": 1,
                        "maxUnavailable": 0
                    }
                },
                "template": {}
                    "metadata": {}
                        "labels": {}
                            "app": "trading-system",
                            "component": component.name
                        }
                    },
                    "spec": {}
                        "containers": [container]
                    }
                }
            }
        }
        
        # Add volumes for config files
        if component.config_files:
            deployment["spec"]["template"]["spec"]["volumes"] = [{]
                "name": "config",
                "configMap": {}
                    "name": f"{component.name}-config"
                }
            }]
        
        return deployment
    
    def create_service(self, component: ComponentConfig) -> Optional[Dict[str, Any]]:
        """Create Service configuration"""
        if not component.service_config:
            return None
        
        service = {}
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {}
                "name": component.service_config.name,
                "namespace": self.namespace,
                "labels": {}
                    "app": "trading-system",
                    "component": component.name
                }
            },
            "spec": {}
                "type": component.service_config.service_type.value,
                "selector": {}
                    "app": "trading-system",
                    "component": component.name
                },
                "ports": [{]
                    "port": component.service_config.port,
                    "targetPort": component.service_config.target_port,
                    "protocol": "TCP",
                    "name": "http"
                }]
            }
        }
        
        if component.service_config.node_port:
            service["spec"]["ports"][0]["nodePort"] = component.service_config.node_port
        
        return service
    
    def create_hpa(self, component: ComponentConfig) -> Optional[Dict[str, Any]]:
        """Create Horizontal Pod Autoscaler configuration"""
        if not component.hpa_enabled:
            return None
        
        hpa = {}
            "apiVersion": "autoscaling/v2",
            "kind": "HorizontalPodAutoscaler",
            "metadata": {}
                "name": f"{component.name}-hpa",
                "namespace": self.namespace,
                "labels": {}
                    "app": "trading-system",
                    "component": component.name
                }
            },
            "spec": {}
                "scaleTargetRef": {}
                    "apiVersion": "apps/v1",
                    "kind": "Deployment",
                    "name": component.name
                },
                "minReplicas": component.min_replicas,
                "maxReplicas": component.max_replicas,
                "metrics": []
                    {}
                        "type": "Resource",
                        "resource": {}
                            "name": "cpu",
                            "target": {}
                                "type": "Utilization",
                                "averageUtilization": component.target_cpu_utilization
                            }
                        }
                    },
                    {}
                        "type": "Resource",
                        "resource": {}
                            "name": "memory",
                            "target": {}
                                "type": "Utilization",
                                "averageUtilization": component.target_memory_utilization
                            }
                        }
                    }
                ]
            }
        }
        return hpa
    
    def add_component(self, component: ComponentConfig) -> None:
        """Add all configurations for a component"""
        # Create ConfigMap
        configmap = self.create_configmap(component)
        if configmap:
            self.configs.append(configmap)
        
        # Create Secret
        secret = self.create_secret(component)
        if secret:
            self.configs.append(secret)
        
        # Create Deployment
        deployment = self.create_deployment(component)
        self.configs.append(deployment)
        
        # Create Service
        service = self.create_service(component)
        if service:
            self.configs.append(service)
        
        # Create HPA
        hpa = self.create_hpa(component)
        if hpa:
            self.configs.append(hpa)
    
    def add_ingress(self, host: str, tls_enabled: bool = True) -> None:
        """Add Ingress configuration for external access"""
        ingress = {}
            "apiVersion": "networking.k8s.io/v1",
            "kind": "Ingress",
            "metadata": {}
                "name": "trading-system-ingress",
                "namespace": self.namespace,
                "labels": {}
                    "app": "trading-system"
                },
                "annotations": {}
                    "nginx.ingress.kubernetes.io/rewrite-target": "/",
                    "nginx.ingress.kubernetes.io/ssl-redirect": str(tls_enabled).lower(),
                    "cert-manager.io/cluster-issuer": "letsencrypt-prod" if tls_enabled else ""
                }
            },
            "spec": {}
                "ingressClassName": "nginx",
                "rules": [{]
                    "host": host,
                    "http": {}
                        "paths": []
                            {}
                                "path": "/api/trading",
                                "pathType": "Prefix",
                                "backend": {}
                                    "service": {}
                                        "name": "trading-engine-service",
                                        "port": {}
                                            "number": 80
                                        }
                                    }
                                }
                            },
                            {}
                                "path": "/api/market-data",
                                "pathType": "Prefix",
                                "backend": {}
                                    "service": {}
                                        "name": "market-data-service",
                                        "port": {}
                                            "number": 80
                                        }
                                    }
                                }
                            },
                            {}
                                "path": "/api/risk",
                                "pathType": "Prefix",
                                "backend": {}
                                    "service": {}
                                        "name": "risk-manager-service",
                                        "port": {}
                                            "number": 80
                                        }
                                    }
                                }
                            }
                        ]
                    }
                }]
            }
        }
        
        if tls_enabled:
            ingress["spec"]["tls"] = [{]
                "hosts": [host],
                "secretName": "trading-system-tls"
            }]
        
        self.configs.append(ingress)
    
    def add_network_policy(self) -> None:
        """Add NetworkPolicy for security"""
        network_policy = {}
            "apiVersion": "networking.k8s.io/v1",
            "kind": "NetworkPolicy",
            "metadata": {}
                "name": "trading-system-network-policy",
                "namespace": self.namespace
            },
            "spec": {}
                "podSelector": {}
                    "matchLabels": {}
                        "app": "trading-system"
                    }
                },
                "policyTypes": ["Ingress", "Egress"],
                "ingress": [{]
                    "from": []
                        {}
                            "namespaceSelector": {}
                                "matchLabels": {}
                                    "name": self.namespace
                                }
                            }
                        },
                        {}
                            "namespaceSelector": {}
                                "matchLabels": {}
                                    "name": "ingress-nginx"
                                }
                            }
                        }
                    ]
                }],
                "egress": [{]
                    "to": []
                        {}
                            "namespaceSelector": {}
                                "matchLabels": {}
                                    "name": self.namespace
                                }
                            }
                        }
                    ]
                }]
            }
        }
        self.configs.append(network_policy)
    
    def generate_yaml(self, output_file: str = "trading-system-k8s.yaml") -> None:
        """Generate YAML file with all configurations"""
        with open(output_file, 'w') as f:
            yaml.dump_all(self.configs, f, default_flow_style=False, sort_keys=False)
        print(f"Kubernetes configurations written to {output_file}")
    
    def generate_separate_files(self, output_dir: str = "k8s-configs") -> None:
        """Generate separate YAML files for each resource"""
        os.makedirs(output_dir, exist_ok=True)
        
        for i, config in enumerate(self.configs):
            kind = config.get("kind", "unknown").lower()
            name = config.get("metadata", {}).get("name", f"resource-{i}")
            filename = f"{kind}-{name}.yaml"
            filepath = os.path.join(output_dir, filename)
            
            with open(filepath, 'w') as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)
            
            print(f"Generated {filepath}")


def create_trading_system_configs():
    """Create complete trading system Kubernetes configurations"""
    generator = KubernetesConfigGenerator()
        namespace="trading-system",
        image_registry="docker.io/trading"
    )
    
    # Add namespace
    generator.add_namespace()
    
    # Trading Engine Component
    trading_engine = ComponentConfig()
        name="trading-engine",
        image="trading-engine:latest",
        replicas=3,
        port=8080,
        env_vars={}
            "ENVIRONMENT": "production",
            "LOG_LEVEL": "INFO",
            "KAFKA_BROKERS": "kafka-service.kafka:9092",
            "REDIS_HOST": "redis-service.redis",
            "REDIS_PORT": "6379"
        },
        secrets={}
            "DATABASE_URL": "postgresql://trading:password@postgres-service.postgres:5432/trading",
            "API_KEY": "your-secure-api-key",
            "JWT_SECRET": "your-jwt-secret"
        },
        config_files={}
            "trading-config.yaml": """
# Trading Engine Configuration
exchange:
  name: "binance"
  api_version: "v3"
  rate_limit: 1200

strategies:
  enabled:
    - "market_making"
    - "arbitrage"
    - "momentum"

risk_management:
  max_position_size: 100000
  max_drawdown: 0.05
  stop_loss: 0.02
"""
        },
        resources=ResourceRequirements()
            cpu_request="500m",
            memory_request="1Gi",
            cpu_limit="2000m",
            memory_limit="4Gi"
        ),
        service_config=ServiceConfig()
            name="trading-engine-service",
            port=80,
            target_port=8080,
            service_type=ServiceType.CLUSTER_IP
        ),
        hpa_enabled=True,
        min_replicas=2,
        max_replicas=10,
        target_cpu_utilization=70
    )
    generator.add_component(trading_engine)
    
    # Market Data Service
    market_data = ComponentConfig()
        name="market-data-service",
        image="market-data-service:latest",
        replicas=2,
        port=8081,
        env_vars={}
            "ENVIRONMENT": "production",
            "LOG_LEVEL": "INFO",
            "WEBSOCKET_ENABLED": "true",
            "CACHE_TTL": "60"
        },
        secrets={}
            "EXCHANGE_API_KEY": "exchange-api-key",
            "EXCHANGE_SECRET": "exchange-secret"
        },
        config_files={}
            "markets.json": """
{}
  "markets": []
    {"symbol": "BTC/USDT", "enabled": true},
    {"symbol": "ETH/USDT", "enabled": true},
    {"symbol": "BNB/USDT", "enabled": true}
  ],
  "update_interval": 1000,
  "depth": 20
}
"""
        },
        resources=ResourceRequirements()
            cpu_request="250m",
            memory_request="512Mi",
            cpu_limit="1000m",
            memory_limit="2Gi"
        ),
        service_config=ServiceConfig()
            name="market-data-service",
            port=80,
            target_port=8081,
            service_type=ServiceType.CLUSTER_IP
        ),
        hpa_enabled=True,
        min_replicas=2,
        max_replicas=8
    )
    generator.add_component(market_data)
    
    # Risk Manager Service
    risk_manager = ComponentConfig()
        name="risk-manager",
        image="risk-manager:latest",
        replicas=2,
        port=8082,
        env_vars={}
            "ENVIRONMENT": "production",
            "LOG_LEVEL": "INFO",
            "CHECK_INTERVAL": "5000",
            "ALERT_WEBHOOK": "https://alerts.example.com/webhook"
        },
        secrets={}
            "DATABASE_URL": "postgresql://risk:password@postgres-service.postgres:5432/risk",
            "NOTIFICATION_TOKEN": "notification-token"
        },
        config_files={}
            "risk-rules.yaml": """
# Risk Management Rules
rules:
  - name: "position_limit"
    enabled: true
    threshold: 1000000
    action: "reject"
  
  - name: "daily_loss_limit"
    enabled: true
    threshold: 50000
    action: "halt_trading"
  
  - name: "volatility_check"
    enabled: true
    threshold: 0.1
    action: "reduce_position"

alerts:
  email:
    - "risk@trading.com"
  slack:
    channel: "#risk-alerts"
"""
        },
        resources=ResourceRequirements()
            cpu_request="200m",
            memory_request="256Mi",
            cpu_limit="500m",
            memory_limit="1Gi"
        ),
        service_config=ServiceConfig()
            name="risk-manager-service",
            port=80,
            target_port=8082,
            service_type=ServiceType.CLUSTER_IP
        ),
        hpa_enabled=True,
        min_replicas=1,
        max_replicas=5
    )
    generator.add_component(risk_manager)
    
    # Order Manager Service
    order_manager = ComponentConfig()
        name="order-manager",
        image="order-manager:latest",
        replicas=3,
        port=8083,
        env_vars={}
            "ENVIRONMENT": "production",
            "LOG_LEVEL": "INFO",
            "ORDER_TIMEOUT": "30000",
            "RETRY_ATTEMPTS": "3"
        },
        secrets={}
            "DATABASE_URL": "postgresql://orders:password@postgres-service.postgres:5432/orders",
            "ENCRYPTION_KEY": "order-encryption-key"
        },
        resources=ResourceRequirements()
            cpu_request="300m",
            memory_request="512Mi",
            cpu_limit="1000m",
            memory_limit="2Gi"
        ),
        service_config=ServiceConfig()
            name="order-manager-service",
            port=80,
            target_port=8083,
            service_type=ServiceType.CLUSTER_IP
        ),
        hpa_enabled=True,
        min_replicas=2,
        max_replicas=8
    )
    generator.add_component(order_manager)
    
    # Portfolio Service
    portfolio_service = ComponentConfig()
        name="portfolio-service",
        image="portfolio-service:latest",
        replicas=2,
        port=8084,
        env_vars={}
            "ENVIRONMENT": "production",
            "LOG_LEVEL": "INFO",
            "CALCULATION_INTERVAL": "60000",
            "CACHE_ENABLED": "true"
        },
        secrets={}
            "DATABASE_URL": "postgresql://portfolio:password@postgres-service.postgres:5432/portfolio",
            "ANALYTICS_API_KEY": "analytics-key"
        },
        resources=ResourceRequirements()
            cpu_request="200m",
            memory_request="256Mi",
            cpu_limit="500m",
            memory_limit="1Gi"
        ),
        service_config=ServiceConfig()
            name="portfolio-service",
            port=80,
            target_port=8084,
            service_type=ServiceType.CLUSTER_IP
        ),
        hpa_enabled=True,
        min_replicas=1,
        max_replicas=4
    )
    generator.add_component(portfolio_service)
    
    # Add Ingress
    generator.add_ingress(host="trading.example.com", tls_enabled=True)
    
    # Add Network Policy
    generator.add_network_policy()
    
    # Add additional infrastructure components
    
    # Redis Configuration
    redis_config = {}
        "apiVersion": "v1",
        "kind": "ConfigMap",
        "metadata": {}
            "name": "redis-config",
            "namespace": generator.namespace
        },
        "data": {}
            "redis.conf": """
maxmemory 2gb
maxmemory-policy allkeys-lru
save 900 1
save 300 10
save 60 10000
appendonly yes
appendfsync everysec
"""
        }
    }
    generator.configs.append(redis_config)
    
    # Prometheus ServiceMonitor for monitoring
    service_monitor = {}
        "apiVersion": "monitoring.coreos.com/v1",
        "kind": "ServiceMonitor",
        "metadata": {}
            "name": "trading-system-monitor",
            "namespace": generator.namespace,
            "labels": {}
                "app": "trading-system"
            }
        },
        "spec": {}
            "selector": {}
                "matchLabels": {}
                    "app": "trading-system"
                }
            },
            "endpoints": [{]
                "port": "http",
                "interval": "30s",
                "path": "/metrics"
            }]
        }
    }
    generator.configs.append(service_monitor)
    
    # PodDisruptionBudget for high availability
    pdb = {}
        "apiVersion": "policy/v1",
        "kind": "PodDisruptionBudget",
        "metadata": {}
            "name": "trading-engine-pdb",
            "namespace": generator.namespace
        },
        "spec": {}
            "minAvailable": 1,
            "selector": {}
                "matchLabels": {}
                    "app": "trading-system",
                    "component": "trading-engine"
                }
            }
        }
    }
    generator.configs.append(pdb)
    
    return generator


def main():
    """Main function to generate Kubernetes configurations"""
    print("Generating Kubernetes configurations for Trading System...")
    
    generator = create_trading_system_configs()
    
    # Generate single YAML file
    generator.generate_yaml("trading-system-k8s.yaml")
    
    # Generate separate files
    generator.generate_separate_files("k8s-configs")
    
    print("\nConfiguration generation complete!")
    print("\nTo deploy to Kubernetes:")
    print("  kubectl apply -f trading-system-k8s.yaml")
    print("\nOr deploy individual components:")
    print("  kubectl apply -f k8s-configs/")
    
    print("\nTo check deployment status:")
    print("  kubectl get all -n trading-system")
    print("\nTo view logs:")
    print("  kubectl logs -n trading-system -l app=trading-system")


if __name__ == "__main__":
    main()
# Export main class
KubernetesDeployment = KubernetesDeploymentConfig
