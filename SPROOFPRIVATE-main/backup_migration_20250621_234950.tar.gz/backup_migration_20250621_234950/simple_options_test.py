
#!/usr/bin/env python3
"""
Simple test to verify Alpaca options API access
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
from dotenv import load_dotenv
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import GetOptionContractsRequest

load_dotenv()

def test_options_access():
    """Test basic options API access"""
    print("Testing Alpaca Options API Access...")
    
    api_key = os.getenv('ALPACA_PAPER_API_KEY')
    api_secret = os.getenv('ALPACA_PAPER_API_SECRET')
    
    if not api_key or not api_secret:
        print("✗ API credentials not found")
        return
        
    try:
        # Initialize client
        client = TradingClient(api_key, api_secret, paper=True)
        print("✓ Trading client initialized")
        
        # Test getting option contracts for SPY
        print("\nTesting option contracts for SPY...")
        request = GetOptionContractsRequest()
            underlying_symbols=['SPY']
        )
        
        contracts = client.get_option_contracts(request)
        print(f"✓ Found {len(contracts.option_contracts)} option contracts for SPY")
        
        # Show first few contracts
        for i, contract in enumerate(contracts.option_contracts[:5]):
            print(f"  {i+1}. {contract.symbol} - ${contract.strike_price} {contract.type.value} exp: {contract.expiration_date}")
            
        print("\n✓ Options API is working!")
        
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    test_options_access()