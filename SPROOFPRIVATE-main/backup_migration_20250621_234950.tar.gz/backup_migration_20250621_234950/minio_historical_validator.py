
#!/usr/bin/env python3
"""
MinIO Historical Data Validator and Backtesting Engine
Validates data quality and runs comprehensive backtests using MinIO historical data
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import json
import zipfile
import io
from pathlib import Path
import requests
from dataclasses import dataclass

from minio_config import MINIO_CONFIG, VALIDATION_CONFIG, PROCESSING_CONFIG

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class DataQualityReport:
    """Data quality assessment"""
    symbol: str
    year: int
    total_records: int
    completeness_score: float  # 0-1
    consistency_score: float   # 0-1
    volume_quality: float      # 0-1
    price_quality: float       # 0-1
    gaps_detected: int
    outliers_detected: int
    overall_score: float       # 0-1

@dataclass
class BacktestResult:
    """Comprehensive backtest result"""
    strategy: str
    symbol: str
    start_date: datetime
    end_date: datetime
    total_return: float
    annualized_return: float
    volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    calmar_ratio: float
    win_rate: float
    profit_factor: float
    total_trades: int
    avg_trade_duration: float
    best_trade: float
    worst_trade: float
    consecutive_wins: int
    consecutive_losses: int
    data_quality_score: float

class MinIOHistoricalValidator:
    """Validate and analyze MinIO historical data"""
    
    def __init__(self):
        self.minio_config = MINIO_CONFIG
        self.validation_config = VALIDATION_CONFIG
        self.base_url = f"https://{self.minio_config['endpoint']}"
        
        # Cache for downloaded data
        self.data_cache = {}
        self.quality_reports = {}
        
    async def download_year_data(self, year: int) -> Optional[Dict]:
        """Download and extract data for a specific year"""
        try:
            zip_url = f"{self.base_url}/stockdb/{year}.zip"
            
            logger.info(f"📥 Downloading {year} data from MinIO...")
            
            # Download the zip file
            response = requests.get(zip_url, stream=True)
            response.raise_for_status()
            
            # Extract and parse the data
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_file:
                year_data = {}
                
                for file_name in zip_file.namelist():
                    if file_name.endswith('.csv'):
                        # Extract symbol from filename
                        symbol = file_name.replace('.csv', '').upper()
                        
                        with zip_file.open(file_name) as csv_file:
                            try:
                                df = pd.read_csv(csv_file)
                                
                                # Standardize column names
                                df.columns = df.columns.str.lower()
                                
                                # Convert timestamp
                                if 'date' in df.columns:
                                    df['timestamp'] = pd.to_datetime(df['date'])
                                elif 'timestamp' in df.columns:
                                    df['timestamp'] = pd.to_datetime(df['timestamp'])
                                else:
                                    continue
                                    
                                # Validate required columns
                                required_cols = ['open', 'high', 'low', 'close', 'volume']
                                if all(col in df.columns for col in required_cols):
                                    year_data[symbol] = df
                                    
                            except Exception as e:
                                logger.debug(f"Error processing {file_name}: {e}")
                                continue
                                
            logger.info(f"✅ Loaded {len(year_data)} symbols for {year}")
            self.data_cache[year] = year_data
            return year_data
            
        except Exception as e:
            logger.error(f"Error downloading {year} data: {e}")
            return None
            
    def validate_data_quality(self, data: pd.DataFrame, symbol: str, year: int) -> DataQualityReport:
        """Comprehensive data quality validation"""
        
        # Basic metrics
        total_records = len(data)
        
        # Completeness score - check for missing values
        missing_pct = data[self.validation_config['required_columns']].isnull().sum().sum() / (len(data) * len(self.validation_config['required_columns']))
        completeness_score = max(0, 1 - missing_pct)
        
        # Price quality - check for valid price ranges and relationships
        price_issues = 0
        
        # Check price ranges
        for col in ['open', 'high', 'low', 'close']:
            if col in data.columns:
                out_of_range = ((data[col] < self.validation_config['price_range'][0]) |)
                               (data[col] > self.validation_config['price_range'][1])).sum()
                price_issues += out_of_range
                
        # Check OHLC relationships
        if all(col in data.columns for col in ['open', 'high', 'low', 'close']):
            # High should be >= Open, Low, Close
            invalid_high = ((data['high'] < data['open']) |)
                           (data['high'] < data['low']) | 
                           (data['high'] < data['close'])).sum()
            
            # Low should be <= Open, High, Close  
            invalid_low = ((data['low'] > data['open']) |)
                          (data['low'] > data['high']) | 
                          (data['low'] > data['close'])).sum()
                          
            price_issues += invalid_high + invalid_low
            
        price_quality = max(0, 1 - (price_issues / total_records))
        
        # Volume quality
        volume_issues = 0
        if 'volume' in data.columns:
            # Check volume range
            out_of_range_vol = ((data['volume'] < 0) |)
                               (data['volume'] > self.validation_config['volume_range'][1])).sum()
            volume_issues += out_of_range_vol
            
            # Check for suspiciously low volume
            low_volume = (data['volume'] < self.validation_config['min_volume_threshold']).sum()
            volume_issues += low_volume * 0.1  # Smaller penalty for low volume
            
        volume_quality = max(0, 1 - (volume_issues / total_records))
        
        # Consistency score - check for gaps and outliers
        data_sorted = data.sort_values('timestamp')
        
        # Detect gaps (missing trading days)
        gaps_detected = 0
        if len(data_sorted) > 1:
            time_diffs = data_sorted['timestamp'].diff()
            # Gaps longer than 5 days (weekends + holidays)
            long_gaps = (time_diffs > pd.Timedelta(days=5)).sum()
            gaps_detected = long_gaps
            
        # Detect price outliers (> 50% daily change)
        outliers_detected = 0
        if 'close' in data.columns and len(data_sorted) > 1:
            price_changes = data_sorted['close'].pct_change()
            outliers = (abs(price_changes) > self.validation_config['max_price_change_pct'] / 100).sum()
            outliers_detected = outliers
            
        consistency_score = max(0, 1 - (gaps_detected + outliers_detected) / total_records)
        
        # Overall score (weighted average)
        overall_score = ()
            completeness_score * 0.25 +
            price_quality * 0.35 +
            volume_quality * 0.25 +
            consistency_score * 0.15
        )
        
        return DataQualityReport()
            symbol=symbol,
            year=year,
            total_records=total_records,
            completeness_score=completeness_score,
            consistency_score=consistency_score,
            volume_quality=volume_quality,
            price_quality=price_quality,
            gaps_detected=gaps_detected,
            outliers_detected=outliers_detected,
            overall_score=overall_score
        )
        
    async def run_strategy_backtest(self, strategy: str, data: pd.DataFrame, 
                                  symbol: str) -> BacktestResult:
        """Run comprehensive backtest for a strategy"""
        
        if len(data) < 50:
            # Return empty result for insufficient data
            return BacktestResult()
                strategy=strategy, symbol=symbol,
                start_date=datetime.now(), end_date=datetime.now(),
                total_return=0, annualized_return=0, volatility=0,
                sharpe_ratio=0, sortino_ratio=0, max_drawdown=0,
                calmar_ratio=0, win_rate=0, profit_factor=0,
                total_trades=0, avg_trade_duration=0,
                best_trade=0, worst_trade=0,
                consecutive_wins=0, consecutive_losses=0,
                data_quality_score=0
            )
            
        # Prepare data
        data = data.sort_values('timestamp').copy()
        data = self._add_technical_indicators(data)
        
        # Initialize backtest
        initial_capital = 10000
        position = 0
        cash = initial_capital
        portfolio_value = initial_capital
        
        trades = []
        equity_curve = []
        
        # Strategy-specific logic
        if strategy == 'momentum':
            signals = self._generate_momentum_signals(data)
        elif strategy == 'mean_reversion':
            signals = self._generate_mean_reversion_signals(data)
        elif strategy == 'breakout':
            signals = self._generate_breakout_signals(data)
        else:
            signals = pd.Series([0] * len(data), index=data.index)
            
        # Execute trades
        for i, (idx, row) in enumerate(data.iterrows()):
            signal = signals.iloc[i] if i < len(signals) else 0
            price = row['close']
            
            # Calculate current portfolio value
            portfolio_value = cash + (position * price)
            equity_curve.append(portfolio_value)
            
            # Process signals
            if signal == 1 and position == 0:  # Buy signal
                shares_to_buy = int(cash * 0.95 / price)  # Use 95% of cash
                if shares_to_buy > 0:
                    position = shares_to_buy
                    cash -= shares_to_buy * price
                    trades.append({)
                        'type': 'entry',
                        'date': row['timestamp'],
                        'price': price,
                        'shares': shares_to_buy
                    })
                    
            elif signal == -1 and position > 0:  # Sell signal
                cash += position * price
                trades.append({)
                    'type': 'exit',
                    'date': row['timestamp'],
                    'price': price,
                    'shares': position
                })
                position = 0
                
        # Final portfolio value
        final_value = cash + (position * data['close'].iloc[-1])
        
        # Calculate metrics
        total_return = (final_value - initial_capital) / initial_capital
        
        # Calculate trade-level metrics
        trade_returns = []
        trade_durations = []
        entry_trade = None
        
        for trade in trades:
            if trade['type'] == 'entry':
                entry_trade = trade
            elif trade['type'] == 'exit' and entry_trade:
                trade_return = (trade['price'] - entry_trade['price']) / entry_trade['price']
                trade_returns.append(trade_return)
                
                duration = (trade['date'] - entry_trade['date']).days
                trade_durations.append(duration)
                entry_trade = None
                
        # Performance metrics
        win_rate = len([r for r in trade_returns if r > 0]) / len(trade_returns) if trade_returns else 0
        
        winning_trades = [r for r in trade_returns if r > 0]
        losing_trades = [r for r in trade_returns if r < 0]
        
        avg_win = np.mean(winning_trades) if winning_trades else 0
        avg_loss = np.mean(losing_trades) if losing_trades else 0
        
        profit_factor = abs(avg_win * len(winning_trades) / (avg_loss * len(losing_trades))) if losing_trades else float('inf')
        
        # Risk metrics
        if len(equity_curve) > 1:
            returns = pd.Series(equity_curve).pct_change().dropna()
            
            volatility = returns.std() * np.sqrt(252)  # Annualized
            sharpe_ratio = (returns.mean() * 252) / (volatility + 1e-10)
            
            # Sortino ratio (downside deviation)
            downside_returns = returns[returns < 0]
            downside_deviation = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0
            sortino_ratio = (returns.mean() * 252) / (downside_deviation + 1e-10)
            
            # Maximum drawdown
            peak = np.maximum.accumulate(equity_curve)
            drawdown = (peak - equity_curve) / peak
            max_drawdown = np.max(drawdown)
            
            # Calmar ratio
            annualized_return = total_return * (252 / len(equity_curve))
            calmar_ratio = annualized_return / (max_drawdown + 1e-10)
            
        else:
            volatility = sharpe_ratio = sortino_ratio = max_drawdown = calmar_ratio = annualized_return = 0
            
        # Consecutive wins/losses
        consecutive_wins = consecutive_losses = 0
        current_streak = 0
        is_winning_streak = None
        
        for ret in trade_returns:
            if ret > 0:
                if is_winning_streak:
                    current_streak += 1
                else:
                    consecutive_losses = max(consecutive_losses, current_streak)
                    current_streak = 1
                    is_winning_streak = True
            else:
                if not is_winning_streak:
                    current_streak += 1
                else:
                    consecutive_wins = max(consecutive_wins, current_streak)
                    current_streak = 1
                    is_winning_streak = False
                    
        if is_winning_streak:
            consecutive_wins = max(consecutive_wins, current_streak)
        else:
            consecutive_losses = max(consecutive_losses, current_streak)
            
        return BacktestResult()
            strategy=strategy,
            symbol=symbol,
            start_date=data['timestamp'].iloc[0],
            end_date=data['timestamp'].iloc[-1],
            total_return=total_return,
            annualized_return=annualized_return,
            volatility=volatility,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            calmar_ratio=calmar_ratio,
            win_rate=win_rate,
            profit_factor=profit_factor,
            total_trades=len(trade_returns),
            avg_trade_duration=np.mean(trade_durations) if trade_durations else 0,
            best_trade=max(trade_returns) if trade_returns else 0,
            worst_trade=min(trade_returns) if trade_returns else 0,
            consecutive_wins=consecutive_wins,
            consecutive_losses=consecutive_losses,
            data_quality_score=0.8  # Would calculate from data quality report
        )
        
    def _add_technical_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        """Add technical indicators for trading strategies"""
        # Simple moving averages
        data['sma_20'] = data['close'].rolling(20).mean()
        data['sma_50'] = data['close'].rolling(50).mean()
        
        # RSI
        delta = data['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
        rs = gain / loss
        data['rsi'] = 100 - (100 / (1 + rs))
        
        # Bollinger Bands
        data['bb_middle'] = data['close'].rolling(20).mean()
        bb_std = data['close'].rolling(20).std()
        data['bb_upper'] = data['bb_middle'] + (bb_std * 2)
        data['bb_lower'] = data['bb_middle'] - (bb_std * 2)
        
        # MACD
        ema_12 = data['close'].ewm(span=12).mean()
        ema_26 = data['close'].ewm(span=26).mean()
        data['macd'] = ema_12 - ema_26
        data['macd_signal'] = data['macd'].ewm(span=9).mean()
        
        return data
        
    def _generate_momentum_signals(self, data: pd.DataFrame) -> pd.Series:
        """Generate momentum trading signals"""
        signals = pd.Series([0] * len(data), index=data.index)
        
        for i in range(50, len(data)):
            # Buy signal: price above SMA20, RSI between 50-70, rising volume
            if (data['close'].iloc[i] > data['sma_20'].iloc[i] and)
                50 < data['rsi'].iloc[i] < 70 and
                data['volume'].iloc[i] > data['volume'].iloc[i-5:i].mean() * 1.2):
                signals.iloc[i] = 1
                
            # Sell signal: price below SMA20 or RSI > 80
            elif (data['close'].iloc[i] < data['sma_20'].iloc[i] or)
                  data['rsi'].iloc[i] > 80):
                signals.iloc[i] = -1
                
        return signals
        
    def _generate_mean_reversion_signals(self, data: pd.DataFrame) -> pd.Series:
        """Generate mean reversion signals"""
        signals = pd.Series([0] * len(data), index=data.index)
        
        for i in range(20, len(data)):
            # Buy signal: price hits lower Bollinger Band, RSI oversold
            if (data['close'].iloc[i] <= data['bb_lower'].iloc[i] and)
                data['rsi'].iloc[i] < 30):
                signals.iloc[i] = 1
                
            # Sell signal: price hits upper Bollinger Band or middle
            elif (data['close'].iloc[i] >= data['bb_middle'].iloc[i]):
                signals.iloc[i] = -1
                
        return signals
        
    def _generate_breakout_signals(self, data: pd.DataFrame) -> pd.Series:
        """Generate breakout trading signals"""
        signals = pd.Series([0] * len(data), index=data.index)
        
        for i in range(20, len(data)):
            # Buy signal: breakout above 20-day high with volume
            high_20 = data['high'].iloc[i-20:i].max()
            if (data['close'].iloc[i] > high_20 and)
                data['volume'].iloc[i] > data['volume'].iloc[i-10:i].mean() * 1.5):
                signals.iloc[i] = 1
                
            # Sell signal: breakdown below 10-day low
            low_10 = data['low'].iloc[i-10:i].min()
            if data['close'].iloc[i] < low_10:
                signals.iloc[i] = -1
                
        return signals
        
    async def run_comprehensive_analysis(self, years: List[int] = None) -> Dict:
        """Run comprehensive analysis on historical data"""
        if years is None:
            years = [2020, 2021, 2022, 2023]
            
        logger.info(f"🔍 Starting comprehensive analysis for years: {years}")
        
        all_quality_reports = []
        all_backtest_results = []
        
        strategies = ['momentum', 'mean_reversion', 'breakout']
        
        for year in years:
            logger.info(f"\n📅 Analyzing {year}...")
            
            # Download year data
            year_data = await self.download_year_data(year)
            if not year_data:
                continue
                
            # Analyze each symbol
            for symbol, data in year_data.items():
                if len(data) < 100:  # Skip symbols with insufficient data
                    continue
                    
                # Data quality validation
                quality_report = self.validate_data_quality(data, symbol, year)
                all_quality_reports.append(quality_report)
                
                # Skip low quality data
                if quality_report.overall_score < 0.7:
                    continue
                    
                # Run backtests for each strategy
                for strategy in strategies:
                    try:
                        backtest_result = await self.run_strategy_backtest(strategy, data, symbol)
                        backtest_result.data_quality_score = quality_report.overall_score
                        all_backtest_results.append(backtest_result)
                    except Exception as e:
                        logger.debug(f"Backtest error for {strategy} on {symbol} {year}: {e}")
                        
        # Generate summary report
        report = self._generate_analysis_report(all_quality_reports, all_backtest_results)
        
        # Save detailed results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save quality reports
        quality_df = pd.DataFrame([)
            {}
                'symbol': r.symbol,
                'year': r.year,
                'total_records': r.total_records,
                'completeness_score': r.completeness_score,
                'consistency_score': r.consistency_score,
                'volume_quality': r.volume_quality,
                'price_quality': r.price_quality,
                'overall_score': r.overall_score,
                'gaps_detected': r.gaps_detected,
                'outliers_detected': r.outliers_detected
            }
            for r in all_quality_reports
        ])
        quality_df.to_csv(f'minio_data_quality_{timestamp}.csv', index=False)
        
        # Save backtest results
        backtest_df = pd.DataFrame([)
            {}
                'strategy': r.strategy,
                'symbol': r.symbol,
                'start_date': r.start_date,
                'end_date': r.end_date,
                'total_return': r.total_return,
                'annualized_return': r.annualized_return,
                'sharpe_ratio': r.sharpe_ratio,
                'max_drawdown': r.max_drawdown,
                'win_rate': r.win_rate,
                'profit_factor': r.profit_factor,
                'total_trades': r.total_trades,
                'data_quality_score': r.data_quality_score
            }
            for r in all_backtest_results
        ])
        backtest_df.to_csv(f'minio_backtest_results_{timestamp}.csv', index=False)
        
        logger.info(f"📁 Results saved:")
        logger.info(f"   Quality Report: minio_data_quality_{timestamp}.csv")
        logger.info(f"   Backtest Results: minio_backtest_results_{timestamp}.csv")
        
        return report
        
    def _generate_analysis_report(self, quality_reports: List[DataQualityReport], 
                                backtest_results: List[BacktestResult]) -> Dict:
        """Generate comprehensive analysis report"""
        
        # Data quality summary
        quality_df = pd.DataFrame([)
            {}
                'symbol': r.symbol,
                'year': r.year,
                'overall_score': r.overall_score,
                'completeness_score': r.completeness_score,
                'price_quality': r.price_quality,
                'volume_quality': r.volume_quality,
                'total_records': r.total_records
            }
            for r in quality_reports
        ])
        
        # Backtest summary
        backtest_df = pd.DataFrame([)
            {}
                'strategy': r.strategy,
                'symbol': r.symbol,
                'total_return': r.total_return,
                'sharpe_ratio': r.sharpe_ratio,
                'win_rate': r.win_rate,
                'max_drawdown': r.max_drawdown,
                'total_trades': r.total_trades,
                'data_quality_score': r.data_quality_score
            }
            for r in backtest_results
        ])
        
        report = {}
            'analysis_timestamp': datetime.now().isoformat(),
            'data_quality_summary': {}
                'total_symbol_years': len(quality_reports),
                'avg_quality_score': quality_df['overall_score'].mean(),
                'high_quality_data_pct': (quality_df['overall_score'] > 0.8).mean() * 100,
                'avg_records_per_symbol': quality_df['total_records'].mean(),
                'quality_by_year': quality_df.groupby('year')['overall_score'].mean().to_dict()
            },
            'backtest_summary': {}
                'total_backtests': len(backtest_results),
                'strategies_tested': backtest_df['strategy'].unique().tolist(),
                'avg_return_by_strategy': backtest_df.groupby('strategy')['total_return'].mean().to_dict(),
                'avg_sharpe_by_strategy': backtest_df.groupby('strategy')['sharpe_ratio'].mean().to_dict(),
                'avg_win_rate_by_strategy': backtest_df.groupby('strategy')['win_rate'].mean().to_dict(),
                'best_performing_combinations': backtest_df.nlargest(10, 'total_return')[['strategy', 'symbol', 'total_return', 'sharpe_ratio']].to_dict('records')
            },
            'recommendations': self._generate_recommendations(quality_df, backtest_df)
        }
        
        return report
        
    def _generate_recommendations(self, quality_df: pd.DataFrame, 
                                backtest_df: pd.DataFrame) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        # Data quality recommendations
        low_quality_pct = (quality_df['overall_score'] < 0.7).mean() * 100
        if low_quality_pct > 20:
            recommendations.append(f"⚠️ {low_quality_pct:.1f}% of data has quality issues - consider data cleaning")
            
        # Strategy recommendations
        best_strategy = backtest_df.groupby('strategy')['total_return'].mean().idxmax()
        recommendations.append(f"🎯 Best performing strategy: {best_strategy}")
        
        # Symbol recommendations
        consistent_performers = backtest_df.groupby('symbol').agg({)
            'total_return': ['mean', 'std'],
            'win_rate': 'mean'
        }).round(3)
        
        # Find symbols with high return and low volatility
        consistent_performers['score'] = (consistent_performers[('total_return', 'mean')] /)
                                         (consistent_performers[('total_return', 'std')] + 0.01))
        
        top_symbols = consistent_performers.nlargest(3, 'score').index.tolist()
        recommendations.append(f"📈 Most consistent symbols: {', '.join(top_symbols)}")
        
        return recommendations

async def main():
    """Main analysis function"""
    validator = MinIOHistoricalValidator()
    
    logger.info("🚀 MinIO Historical Data Validation & Backtesting")
    logger.info("=" * 60)
    
    # Run comprehensive analysis
    report = await validator.run_comprehensive_analysis([2022, 2023])
    
    # Print summary
    logger.info("\n📊 ANALYSIS COMPLETE")
    logger.info("=" * 60)
    
    quality_summary = report['data_quality_summary']
    logger.info(f"📈 Data Quality Summary:")
    logger.info(f"   Average Quality Score: {quality_summary['avg_quality_score']:.3f}")
    logger.info(f"   High Quality Data: {quality_summary['high_quality_data_pct']:.1f}%")
    
    backtest_summary = report['backtest_summary']
    logger.info(f"\n🎯 Backtest Summary:")
    logger.info(f"   Total Backtests: {backtest_summary['total_backtests']}")
    logger.info(f"   Strategies: {', '.join(backtest_summary['strategies_tested'])}")
    
    for strategy, avg_return in backtest_summary['avg_return_by_strategy'].items():
        sharpe = backtest_summary['avg_sharpe_by_strategy'][strategy]
        win_rate = backtest_summary['avg_win_rate_by_strategy'][strategy]
        logger.info(f"   {strategy}: {avg_return:.2%} return, {sharpe:.2f} Sharpe, {win_rate:.1%} win rate")
        
    logger.info(f"\n💡 Recommendations:")
    for rec in report['recommendations']:
        logger.info(f"   {rec}")
        
    # Save full report
    with open('minio_comprehensive_report.json', 'w') as f:
        json.dump(report, f, indent=2, default=str)
        
    logger.info(f"\n📁 Full report saved to: minio_comprehensive_report.json")

if __name__ == "__main__":
    asyncio.run(main())