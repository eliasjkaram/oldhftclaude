#!/usr/bin/env python3
"""
Comprehensive Options Complete Directory Explorer
Specifically explores the "options_complete" directory in MinIO stockdb bucket
and provides detailed analysis of the more complete/recent options data
"""

import os
import sys
import json
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict, Counter
import re
import traceback

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


from minio import Minio
from minio.error import S3Error

# MinIO Configuration
MINIO_CONFIG = {}
    'endpoint': 'https://uschristmas.us',
    'access_key': os.getenv('MINIO_ACCESS_KEY'),
    'secret_key': os.getenv('MINIO_SECRET_KEY'),
    'bucket_name': 'stockdb',
    'secure': True
}

class OptionsCompleteExplorer:
    """Specialized explorer for options_complete directory"""
    
    def __init__(self):
        self.endpoint = MINIO_CONFIG['endpoint']
        self.access_key = MINIO_CONFIG['access_key']
        self.secret_key = MINIO_CONFIG['secret_key']
        self.bucket_name = MINIO_CONFIG['bucket_name']
        self.secure = MINIO_CONFIG['secure']
        
        # Clean endpoint for MinIO client
        self.clean_endpoint = self.endpoint.replace('https://', '').replace('http://', '')
        
        # Initialize client
        self.client = None
        self._connect()
    
    def _connect(self):
        """Connect to MinIO server"""
        try:
            self.client = Minio()
                self.clean_endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=self.secure
            )
            print(f"✓ Connected to MinIO server: {self.endpoint}")
        except Exception as e:
            print(f"✗ Failed to connect to MinIO: {e}")
            sys.exit(1)
    
    def explore_options_complete_directory(self) -> Dict[str, Any]:
        """Main exploration of options_complete directory"""
        print("\n" + "="*80)
        print("EXPLORING OPTIONS_COMPLETE DIRECTORY")
        print("="*80)
        
        # First check if options-complete exists (note the hyphen)
        options_complete_objects = self._get_directory_objects("options-complete/")
        
        if not options_complete_objects:
            print("❌ options-complete directory not found!")
            print("Let's check what directories exist...")
            return self._explore_root_directories()
        
        print(f"✓ Found options-complete directory with {len(options_complete_objects)} objects")
        
        # Analyze the directory structure
        analysis = {}
            'directory_found': True,
            'total_objects': len(options_complete_objects),
            'total_size': sum(obj.size for obj in options_complete_objects if obj.size),
            'file_analysis': self._analyze_options_complete_files(options_complete_objects),
            'year_coverage': self._analyze_year_coverage(options_complete_objects),
            'structure_analysis': self._analyze_directory_structure(options_complete_objects),
            'sample_files': self._get_sample_files(options_complete_objects),
            'comparison_with_options': self._compare_with_original_options()
        }
        
        return analysis
    
    def _get_directory_objects(self, prefix: str):
        """Get all objects in a directory"""
        try:
            objects = list(self.client.list_objects())
                self.bucket_name,
                prefix=prefix,
                recursive=True
            )
            return objects
        except Exception as e:
            print(f"Error getting objects for {prefix}: {e}")
            return []
    
    def _explore_root_directories(self):
        """Explore root directories to understand structure"""
        print("\n📁 Exploring root directory structure...")
        
        try:
            all_objects = list(self.client.list_objects(self.bucket_name, recursive=False)
            directories = set()
            
            for obj in all_objects:
                if obj.object_name.endswith('/'):
                    directories.add(obj.object_name.rstrip('/')
                elif '/' in obj.object_name:
                    directories.add(obj.object_name.split('/')[0])
            
            print(f"\n📂 Found {len(directories)} root directories:")
            for directory in sorted(directories):
                print(f"   - {directory}/")
            
            # Check for options-related directories
            options_dirs = [d for d in directories if 'options' in d.lower()]
            if options_dirs:
                print(f"\n🎯 Options-related directories found:")
                for opt_dir in options_dirs:
                    print(f"   - {opt_dir}/")
                    objects = self._get_directory_objects(f"{opt_dir}/")
                    print(f"     → {len(objects)} objects")
            
            return {}
                'directory_found': False,
                'root_directories': list(directories),
                'options_related_directories': options_dirs
            }
            
        except Exception as e:
            print(f"Error exploring root directories: {e}")
            return {'directory_found': False, 'error': str(e)}
    
    def _analyze_options_complete_files(self, objects) -> Dict[str, Any]:
        """Analyze file types and patterns in options_complete"""
        print("\n📊 Analyzing file types and patterns...")
        
        file_extensions = Counter()
        file_sizes = []
        naming_patterns = Counter()
        
        for obj in objects:
            # File extension analysis
            if '.' in obj.object_name:
                ext = obj.object_name.split('.')[-1].lower()
                file_extensions[ext] += 1
            
            # Size analysis
            if obj.size:
                file_sizes.append(obj.size)
            
            # Naming pattern analysis
            filename = os.path.basename(obj.object_name)
            if filename:
                # Extract patterns like year, date formats, etc.
                if re.search(r'\d{4}', filename):  # Contains year
                    naming_patterns['contains_year'] += 1
                if re.search(r'\d{4}-\d{2}-\d{2}', filename):  # Date format
                    naming_patterns['date_format'] += 1
                if 'options' in filename.lower():
                    naming_patterns['contains_options'] += 1
        
        print(f"   📄 File Extensions:")
        for ext, count in file_extensions.most_common(10):
            print(f"      .{ext}: {count:,} files")
        
        print(f"   📏 File Size Stats:")
        if file_sizes:
            avg_size = sum(file_sizes) / len(file_sizes)
            max_size = max(file_sizes)
            min_size = min(file_sizes)
            print(f"      Average: {avg_size / (1024**2):.2f} MB")
            print(f"      Largest: {max_size / (1024**2):.2f} MB")
            print(f"      Smallest: {min_size / 1024:.2f} KB")
        
        return {}
            'file_extensions': dict(file_extensions),
            'file_count': len(objects),
            'avg_file_size': sum(file_sizes) / len(file_sizes) if file_sizes else 0,
            'total_size': sum(file_sizes),
            'naming_patterns': dict(naming_patterns)
        }
    
    def _analyze_year_coverage(self, objects) -> Dict[str, Any]:
        """Analyze what years of data are available"""
        print("\n📅 Analyzing year coverage...")
        
        years_found = set()
        year_file_counts = Counter()
        year_ranges = []
        
        for obj in objects:
            filename = obj.object_name
            
            # Look for 4-digit years (2000-2024)
            year_matches = re.findall(r'20[0-2]\d', filename)
            for year in year_matches:
                years_found.add(int(year)
                year_file_counts[int(year)] += 1
        
        if years_found:
            min_year = min(years_found)
            max_year = max(years_found)
            year_ranges = [min_year, max_year]
            
            print(f"   📊 Year Coverage: {min_year} - {max_year}")
            print(f"   📈 Total Years: {len(years_found)}")
            
            # Check for 2009-2024 specifically
            target_years = set(range(2009, 2025)
            covered_target_years = years_found.intersection(target_years)
            missing_target_years = target_years - years_found
            
            print(f"   🎯 Target Years (2009-2024) Coverage:")
            print(f"      Covered: {len(covered_target_years)}/16 years")
            print(f"      Missing: {sorted(missing_target_years) if missing_target_years else 'None'}")
            
            # Show top years by file count
            print(f"   📁 Top years by file count:")
            for year, count in year_file_counts.most_common(10):
                print(f"      {year}: {count:,} files")
        
        return {}
            'years_found': sorted(list(years_found),
            'year_range': year_ranges,
            'year_file_counts': dict(year_file_counts),
            'target_coverage': {}
                'covered_years': sorted(list(years_found.intersection(set(range(2009, 2025))),
                'missing_years': sorted(list(set(range(2009, 2025) - years_found),
                'coverage_percentage': len(years_found.intersection(set(range(2009, 2025)) / 16 * 100))
            }
        }
    
    def _analyze_directory_structure(self, objects) -> Dict[str, Any]:
        """Analyze the internal structure of options_complete"""
        print("\n🏗️  Analyzing directory structure...")
        
        subdirectories = defaultdict(list)
        depth_analysis = Counter()
        
        for obj in objects:
            # Remove the options-complete/ prefix
            path = obj.object_name.replace('options-complete/', '', 1)
            
            # Analyze depth
            depth = path.count('/')
            depth_analysis[depth] += 1
            
            # Track subdirectories
            if '/' in path:
                subdir = path.split('/')[0]
                subdirectories[subdir].append(obj)
        
        print(f"   📁 Subdirectories found: {len(subdirectories)}")
        for subdir, files in subdirectories.items():
            if len(files) > 0:
                total_size = sum(f.size for f in files if f.size)
                print(f"      {subdir}/: {len(files):,} files, {total_size / (1024**2):.1f} MB")
        
        print(f"   📊 Directory Depth Distribution:")
        for depth, count in sorted(depth_analysis.items():
            print(f"      Depth {depth}: {count:,} files")
        
        return {}
            'subdirectories': {k: len(v) for k, v in subdirectories.items()},
            'depth_distribution': dict(depth_analysis),
            'total_subdirs': len(subdirectories)
        }
    
    def _get_sample_files(self, objects, samples_per_year: int = 3) -> Dict[str, List[str]]:
        """Get sample files from different years"""
        print("\n🎲 Selecting sample files...")
        
        # Group files by year
        year_files = defaultdict(list)
        
        for obj in objects:
            year_matches = re.findall(r'20[0-2]\d', obj.object_name)
            if year_matches:
                year = int(year_matches[0])
                year_files[year].append(obj)
        
        # Select samples
        samples = {}
        for year in sorted(year_files.keys():
            files = year_files[year][:samples_per_year]
            samples[str(year)] = []
            
            for file_obj in files:
                samples[str(year)].append({)
                    'filename': file_obj.object_name,
                    'size_mb': file_obj.size / (1024**2) if file_obj.size else 0,
                    'last_modified': str(file_obj.last_modified)
                })
        
        print(f"   📋 Sample files selected from {len(samples)} years")
        for year, files in samples.items():
            if files:
                print(f"      {year}: {len(files)} samples")
        
        return samples
    
    def _compare_with_original_options(self) -> Dict[str, Any]:
        """Compare options_complete with original options directory"""
        print("\n🔄 Comparing with original options/ directory...")
        
        # Get original options directory  
        options_objects = self._get_directory_objects("options/")
        
        # Also get options-complete objects for comparison
        options_complete_objects = self._get_directory_objects("options-complete/")
        
        if not options_objects:
            print("   ⚠️  Original options/ directory not found for comparison")
            return {'comparison_available': False}
        
        # Basic comparison metrics (already retrieved above)
        
        comparison = {}
            'comparison_available': True,
            'options_complete': {}
                'file_count': len(options_complete_objects),
                'total_size': sum(obj.size for obj in options_complete_objects if obj.size)
            },
            'options_original': {}
                'file_count': len(options_objects),
                'total_size': sum(obj.size for obj in options_objects if obj.size)
            }
        }
        
        # Calculate differences
        size_diff = comparison['options_complete']['total_size'] - comparison['options_original']['total_size']
        count_diff = comparison['options_complete']['file_count'] - comparison['options_original']['file_count']
        
        print(f"   📊 Comparison Results:")
        print(f"      options-complete/: {comparison['options_complete']['file_count']:,} files, ")
              f"{comparison['options_complete']['total_size'] / (1024**3):.2f} GB")
        print(f"      options/: {comparison['options_original']['file_count']:,} files, ")
              f"{comparison['options_original']['total_size'] / (1024**3):.2f} GB")
        print(f"   📈 Differences:")
        print(f"      Files: {count_diff:+,}")
        print(f"      Size: {size_diff / (1024**3):+.2f} GB")
        
        comparison['differences'] = {}
            'file_count_diff': count_diff,
            'size_diff_bytes': size_diff,
            'size_diff_gb': size_diff / (1024**3)
        }
        
        return comparison
    
    def download_and_analyze_sample(self, sample_files: Dict[str, List[str]], max_downloads: int = 5):
        """Download and analyze sample files"""
        print(f"\n📥 Downloading and analyzing sample files (max {max_downloads})...")
        
        downloads = []
        download_count = 0
        
        for year, files in sample_files.items():
            if download_count >= max_downloads:
                break
                
            for file_info in files:
                if download_count >= max_downloads:
                    break
                    
                filename = file_info['filename']
                local_path = f"/tmp/sample_{os.path.basename(filename)}"
                
                try:
                    print(f"   📦 Downloading: {filename}")
                    self.client.fget_object(self.bucket_name, filename, local_path)
                    
                    # Analyze the file
                    analysis = self._analyze_sample_file(local_path, filename)
                    downloads.append({)
                        'filename': filename,
                        'local_path': local_path,
                        'analysis': analysis
                    })
                    
                    download_count += 1
                    
                except Exception as e:
                    print(f"   ❌ Error downloading {filename}: {e}")
        
        return downloads
    
    def _analyze_sample_file(self, local_path: str, original_filename: str) -> Dict[str, Any]:
        """Analyze a downloaded sample file"""
        analysis = {}
            'filename': original_filename,
            'local_size': os.path.getsize(local_path),
            'file_type': 'unknown',
            'data_quality': {}
        }
        
        try:
            # Determine file type and analyze accordingly
            if local_path.endswith('.csv'):
                df = pd.read_csv(local_path, nrows=1000)  # Sample first 1000 rows
                analysis['file_type'] = 'csv'
                analysis['data_quality'] = {}
                    'columns': list(df.columns),
                    'sample_rows': len(df),
                    'data_types': df.dtypes.to_dict(),
                    'null_counts': df.isnull().sum().to_dict()
                }
                
            elif local_path.endswith('.zip'):
                import zipfile
                with zipfile.ZipFile(local_path, 'r') as zip_ref:
                    file_list = zip_ref.namelist()
                    analysis['file_type'] = 'zip'
                    analysis['data_quality'] = {}
                        'files_in_zip': len(file_list),
                        'sample_files': file_list[:10]
                    }
                    
        except Exception as e:
            analysis['error'] = str(e)
        
        return analysis
    
    def generate_comprehensive_report(self, analysis_results: Dict[str, Any]):
        """Generate a comprehensive report"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"/home/harry/alpaca-mcp/options_complete_analysis_{timestamp}.json"
        
        # Add metadata
        full_report = {}
            'generated_at': datetime.now().isoformat(),
            'bucket_name': self.bucket_name,
            'endpoint': self.endpoint,
            'directory_analyzed': 'options-complete/',
            'analysis_results': analysis_results,
            'summary': self._generate_summary(analysis_results)
        }
        
        try:
            with open(report_file, 'w') as f:
                json.dump(full_report, f, indent=2, default=str)
            print(f"\n📄 Comprehensive report saved: {report_file}")
            return report_file
        except Exception as e:
            print(f"❌ Error saving report: {e}")
            return None
    
    def _generate_summary(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a summary of key findings"""
        summary = {}
            'directory_exists': analysis_results.get('directory_found', False),
            'key_metrics': {},
            'recommendations': []
        }
        
        if analysis_results.get('directory_found'):
            summary['key_metrics'] = {}
                'total_files': analysis_results.get('total_objects', 0),
                'total_size_gb': analysis_results.get('total_size', 0) / (1024**3),
                'year_coverage': analysis_results.get('year_coverage', {}).get('target_coverage', {}).get('coverage_percentage', 0),
                'years_available': len(analysis_results.get('year_coverage', {}).get('years_found', [])
            }
            
            # Generate recommendations
            coverage = analysis_results.get('year_coverage', {}).get('target_coverage', {})
            if coverage.get('coverage_percentage', 0) > 80:
                summary['recommendations'].append("Excellent year coverage for 2009-2024 period")
            else:
                missing = coverage.get('missing_years', [])
                summary['recommendations'].append(f"Consider finding data for missing years: {missing}")
        
        return summary

def main():
    """Main execution function"""
    print("OPTIONS_COMPLETE DIRECTORY COMPREHENSIVE EXPLORER")
    print("=" * 60)
    print(f"Target: {MINIO_CONFIG['endpoint']}/{MINIO_CONFIG['bucket_name']}/options-complete/")
    print()
    
    try:
        # Initialize explorer
        explorer = OptionsCompleteExplorer()
        
        # Perform comprehensive exploration
        analysis_results = explorer.explore_options_complete_directory()
        
        # If directory was found, do additional analysis
        if analysis_results.get('directory_found'):
            # Download and analyze samples
            sample_files = analysis_results.get('sample_files', {})
            if sample_files:
                downloads = explorer.download_and_analyze_sample(sample_files, max_downloads=3)
                analysis_results['sample_analysis'] = downloads
        
        # Generate comprehensive report
        report_file = explorer.generate_comprehensive_report(analysis_results)
        
        # Print final summary
        print("\n" + "="*80)
        print("EXPLORATION COMPLETE - SUMMARY")
        print("="*80)
        
        if analysis_results.get('directory_found'):
            print(f"✅ options-complete/ directory found and analyzed")
            print(f"📊 {analysis_results['total_objects']:,} files, {analysis_results['total_size'] / (1024**3):.2f} GB")
            
            year_coverage = analysis_results.get('year_coverage', {})
            if year_coverage:
                years = year_coverage.get('years_found', [])
                print(f"📅 Year coverage: {min(years) if years else 'N/A'} - {max(years) if years else 'N/A'}")
                target_cov = year_coverage.get('target_coverage', {})
                print(f"🎯 2009-2024 coverage: {target_cov.get('coverage_percentage', 0):.1f}%")
            
            comparison = analysis_results.get('comparison_with_options', {})
            if comparison.get('comparison_available'):
                diff = comparison.get('differences', {})
                print(f"🔄 vs options/: {diff.get('file_count_diff', 0):+,} files, {diff.get('size_diff_gb', 0):+.2f} GB")
        else:
            print("❌ options-complete/ directory not found")
            options_dirs = analysis_results.get('options_related_directories', [])
            if options_dirs:
                print(f"📁 Found options-related directories: {', '.join(options_dirs)}")
        
        if report_file:
            print(f"📄 Detailed report: {report_file}")
        
        print("\n🚀 Next steps:")
        print("1. Review the detailed JSON report")
        print("2. Download more sample files for analysis")
        print("3. Compare data quality with original options directory")
        print("4. Integrate best data source into trading system")
        
    except Exception as e:
        print(f"❌ Error during exploration: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()