
#!/usr/bin/env python3
"""
Demo MinIO Integration with Historical Data
Demonstrates enhanced trading system using simulated historical data from MinIO
"""

# Alpaca imports
from typing import Dict, List, Optional, Tuple
import sys
import os
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import json
from pathlib import Path

from universal_market_data import get_current_market_data, get_realistic_price

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class DemoMinIODataProvider:
    """Demo data provider simulating MinIO historical data"""
    
    def __init__(self):
        self.available_years = list(range(2018, 2025)
        self.symbols = []
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'TSLA',
            'SPY', 'QQQ', 'IWM', 'DIA', 'XLF', 'XLE', 'XLK', 'XLV'
        ]
        
    async def get_historical_data(self, symbol: str, start_year: int, end_year: int) -> pd.DataFrame:
        """Get simulated historical data for a symbol"""
        logger.info(f"📊 Loading historical data: {symbol} ({start_year}-{end_year})")
        
        # Generate realistic price data
        start_date = datetime(start_year, 1, 1)
        end_date = datetime(end_year, 12, 31)
        
        # Generate trading days (excluding weekends)
        dates = pd.bdate_range(start=start_date, end=end_date, freq='B')
        
        # Simulate price evolution
        initial_prices = get_current_market_data(['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA'])  # Real prices.get(symbol, 100)
        
        # Simulate market characteristics
        volatility = {}
            'AAPL': 0.25, 'MSFT': 0.22, 'GOOGL': 0.28, 'AMZN': 0.32,
            'META': 0.35, 'NVDA': 0.45, 'TSLA': 0.55, 'SPY': 0.18,
            'QQQ': 0.22, 'IWM': 0.24, 'DIA': 0.16, 'XLF': 0.30,
            'XLE': 0.35, 'XLK': 0.25, 'XLV': 0.20
        }.get(symbol, 0.25)
        
        trend = np.self.get_price_in_range(-0.05, 0.15)  # Annual trend
        
        # Generate price series
        prices = []
        current_price = initial_price
        
        for i, date in enumerate(dates):
            # Daily return with trend and volatility
            daily_trend = trend / 252  # Convert annual to daily
            daily_vol = volatility / np.sqrt(252)
            
            # Add market regime effects
            market_factor = self._get_market_factor(date)
            
            daily_return = self.get_price_distribution(daily_trend + market_factor, daily_vol)
            current_price *= (1 + daily_return)
            
            # Generate OHLC
            daily_vol_factor = np.self.get_price_in_range(0.5, 1.5)
            intraday_range = current_price * daily_vol * daily_vol_factor
            
            high = current_price + self.get_uniform_prices(0, intraday_range)
            low = current_price - self.get_uniform_prices(0, intraday_range)
            
            # Ensure OHLC relationships
            open_price = self.get_uniform_prices(low, high)
            close_price = current_price
            
            # Volume (higher during volatility)
            base_volume = {}
                'AAPL': 50000000, 'MSFT': 30000000, 'GOOGL': 25000000,
                'SPY': 80000000, 'QQQ': 40000000
            }.get(symbol, 10000000)
            
            volume_factor = 1 + abs(daily_return) * 5  # Higher volume on big moves
            volume = int(base_volume * np.self.get_price_in_range(0.5, 2.0) * volume_factor)
            
            prices.append({)
                'timestamp': date,
                'open': round(open_price, 2),
                'high': round(high, 2),
                'low': round(low, 2),
                'close': round(close_price, 2),
                'volume': volume
            })
            
        df = pd.DataFrame(prices)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Add technical indicators
        df = self._add_technical_indicators(df)
        
        return df
        
    def _get_market_factor(self, date: datetime) -> float:
        """Simulate market regime effects"""
        # COVID crash (March 2020)
        if datetime(2020, 2, 15) <= date <= datetime(2020, 4, 1):
            return -0.002  # Bear market
        
        # COVID recovery (April 2020 - Jan 2022)
        elif datetime(2020, 4, 1) <= date <= datetime(2022, 1, 1):
            return 0.001  # Bull market
            
        # 2022 Bear market
        elif datetime(2022, 1, 1) <= date <= datetime(2022, 10, 1):
            return -0.0005  # Bear market
            
        # 2023-2024 AI boom
        elif datetime(2023, 1, 1) <= date <= datetime(2024, 12, 31):
            return 0.0005  # Moderate bull
            
        return 0  # Neutral
        
    def _add_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add technical indicators"""
        # Moving averages
        df['sma_20'] = df['close'].rolling(20).mean()
        df['sma_50'] = df['close'].rolling(50).mean()
        df['sma_200'] = df['close'].rolling(200).mean()
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0).rolling(14).mean())
        loss = (-delta.where(delta < 0, 0).rolling(14).mean())
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs)
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(20).mean()
        bb_std = df['close'].rolling(20).std()
        df['bb_upper'] = df['bb_middle'] + (bb_std * 2)
        df['bb_lower'] = df['bb_middle'] - (bb_std * 2)
        
        # MACD
        ema_12 = df['close'].ewm(span=12).mean()
        ema_26 = df['close'].ewm(span=26).mean()
        df['macd'] = ema_12 - ema_26
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_histogram'] = df['macd'] - df['macd_signal']
        
        # Volume indicators
        df['volume_sma'] = df['volume'].rolling(20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        
        # ATR (Average True Range)
        df['tr'] = np.maximum()
            df['high'] - df['low'],
            np.maximum()
                abs(df['high'] - df['close'].shift(1),
                abs(df['low'] - df['close'].shift(1)
            )
        )
        df['atr'] = df['tr'].rolling(14).mean()
        
        return df

class EnhancedBacktester:
    """Enhanced backtesting engine with MinIO data"""
    
    def __init__(self, data_provider: DemoMinIODataProvider):
        self.data_provider = data_provider
        
    async def run_strategy_backtest(self, strategy: str, symbol: str, 
                                  start_year: int, end_year: int) -> Dict:
        """Run comprehensive backtest"""
        # Get historical data
        data = await self.data_provider.get_historical_data(symbol, start_year, end_year)
        
        if len(data) < 100:
            return self._empty_result(strategy, symbol)
            
        # Strategy-specific backtesting
        if strategy == 'momentum':
            return await self._backtest_momentum(data, symbol)
        elif strategy == 'mean_reversion':
            return await self._backtest_mean_reversion(data, symbol)
        elif strategy == 'breakout':
            return await self._backtest_breakout(data, symbol)
        elif strategy == 'trend_following':
            return await self._backtest_trend_following(data, symbol)
        else:
            return self._empty_result(strategy, symbol)
            
    def _empty_result(self, strategy: str, symbol: str) -> Dict:
        """Return empty result for insufficient data"""
        return {}
            'strategy': strategy,
            'symbol': symbol,
            'total_return': 0,
            'annualized_return': 0,
            'sharpe_ratio': 0,
            'max_drawdown': 0,
            'win_rate': 0,
            'total_trades': 0,
            'profit_factor': 0,
            'calmar_ratio': 0
        }
        
    async def _backtest_momentum(self, data: pd.DataFrame, symbol: str) -> Dict:
        """Momentum strategy backtest"""
        # Strategy: Buy when price > SMA20 and RSI 50-70, sell when price < SMA20
        signals = []
        
        for i in range(50, len(data):
            row = data.iloc[i]
            
            # Buy signal
            if (row['close'] > row['sma_20'] and)
                50 <= row['rsi'] <= 70 and
                row['volume_ratio'] > 1.2 and
                row['macd'] > row['macd_signal']):
                signals.append(1)
            # Sell signal
            elif (row['close'] < row['sma_20'] or)
                  row['rsi'] > 80 or
                  row['macd'] < row['macd_signal']):
                signals.append(-1)
            else:
                signals.append(0)
                
        return self._calculate_performance(data[50:], signals, 'momentum', symbol)
        
    async def _backtest_mean_reversion(self, data: pd.DataFrame, symbol: str) -> Dict:
        """Mean reversion strategy backtest"""
        # Strategy: Buy at lower BB, sell at middle BB
        signals = []
        
        for i in range(20, len(data):
            row = data.iloc[i]
            
            # Buy signal
            if (row['close'] <= row['bb_lower'] and)
                row['rsi'] < 30):
                signals.append(1)
            # Sell signal
            elif (row['close'] >= row['bb_middle'] or)
                  row['rsi'] > 70):
                signals.append(-1)
            else:
                signals.append(0)
                
        return self._calculate_performance(data[20:], signals, 'mean_reversion', symbol)
        
    async def _backtest_breakout(self, data: pd.DataFrame, symbol: str) -> Dict:
        """Breakout strategy backtest"""
        signals = []
        
        for i in range(50, len(data):
            row = data.iloc[i]
            
            # 20-day high/low
            high_20 = data['high'].iloc[i-20:i].max()
            low_20 = data['low'].iloc[i-20:i].min()
            
            # Buy signal - breakout above 20-day high
            if (row['close'] > high_20 and)
                row['volume_ratio'] > 1.5):
                signals.append(1)
            # Sell signal - breakdown below 20-day low
            elif row['close'] < low_20:
                signals.append(-1)
            else:
                signals.append(0)
                
        return self._calculate_performance(data[50:], signals, 'breakout', symbol)
        
    async def _backtest_trend_following(self, data: pd.DataFrame, symbol: str) -> Dict:
        """Trend following strategy"""
        signals = []
        
        for i in range(200, len(data):
            row = data.iloc[i]
            
            # Buy signal - price above SMA200 and SMA20 > SMA50
            if (row['close'] > row['sma_200'] and)
                row['sma_20'] > row['sma_50'] and
                row['macd'] > 0):
                signals.append(1)
            # Sell signal - opposite conditions
            elif (row['close'] < row['sma_200'] or)
                  row['sma_20'] < row['sma_50'] or
                  row['macd'] < 0):
                signals.append(-1)
            else:
                signals.append(0)
                
        return self._calculate_performance(data[200:], signals, 'trend_following', symbol)
        
    def _calculate_performance(self, data: pd.DataFrame, signals: List[int], 
                             strategy: str, symbol: str) -> Dict:
        """Calculate comprehensive performance metrics"""
        
        if len(signals) != len(data):
            signals = signals[:len(data)]
            
        # Simulate trading
        initial_capital = 10000
        position = 0
        cash = initial_capital
        trades = []
        equity_curve = [initial_capital]
        
        entry_price = 0
        entry_date = None
        
        for i, (idx, row) in enumerate(data.iterrows():
            signal = signals[i] if i < len(signals) else 0
            price = row['close']
            
            # Calculate portfolio value
            portfolio_value = cash + (position * price)
            equity_curve.append(portfolio_value)
            
            # Entry signal
            if signal == 1 and position == 0:
                shares = int(cash * 0.95 / price)  # Use 95% of cash
                if shares > 0:
                    position = shares
                    cash -= shares * price
                    entry_price = price
                    entry_date = row['timestamp']
                    
            # Exit signal
            elif signal == -1 and position > 0:
                cash += position * price
                
                # Record trade
                trade_return = (price - entry_price) / entry_price
                holding_days = (row['timestamp'] - entry_date).days
                
                trades.append({)
                    'entry_date': entry_date,
                    'exit_date': row['timestamp'],
                    'entry_price': entry_price,
                    'exit_price': price,
                    'return': trade_return,
                    'holding_days': holding_days
                })
                
                position = 0
                
        # Calculate metrics
        final_value = cash + (position * data['close'].iloc[-1])
        total_return = (final_value - initial_capital) / initial_capital
        
        # Trade statistics
        if trades:
            trade_returns = [t['return'] for t in trades]
            winning_trades = [r for r in trade_returns if r > 0]
            losing_trades = [r for r in trade_returns if r < 0]
            
            win_rate = len(winning_trades) / len(trades)
            avg_win = np.mean(winning_trades) if winning_trades else 0
            avg_loss = np.mean(losing_trades) if losing_trades else 0
            
            profit_factor = (avg_win * len(winning_trades) / abs(avg_loss * len(losing_trades) if losing_trades else float('inf')
            
            avg_holding_days = np.mean([t['holding_days'] for t in trades])
        else:
            win_rate = 0
            profit_factor = 0
            avg_holding_days = 0
            
        # Risk metrics
        if len(equity_curve) > 1:
            returns = pd.Series(equity_curve).pct_change().dropna()
            
            # Annualized metrics
            trading_days = len(data)
            years = trading_days / 252
            annualized_return = (final_value / initial_capital) ** (1/years) - 1
            
            volatility = returns.std() * np.sqrt(252)
            sharpe_ratio = (annualized_return) / volatility if volatility > 0 else 0
            
            # Maximum drawdown
            peak = np.maximum.accumulate(equity_curve)
            drawdown = (peak - equity_curve) / peak
            max_drawdown = np.max(drawdown)
            
            # Calmar ratio
            calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0
            
        else:
            annualized_return = 0
            sharpe_ratio = 0
            max_drawdown = 0
            calmar_ratio = 0
            
        return {}
            'strategy': strategy,
            'symbol': symbol,
            'start_date': data['timestamp'].iloc[0],
            'end_date': data['timestamp'].iloc[-1],
            'total_return': total_return,
            'annualized_return': annualized_return,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'total_trades': len(trades),
            'profit_factor': profit_factor,
            'calmar_ratio': calmar_ratio,
            'avg_holding_days': avg_holding_days,
            'final_value': final_value
        }

class MinIOEnhancedOrchestrator:
    """Enhanced orchestrator with MinIO historical analysis"""
    
    def __init__(self):
        self.data_provider = DemoMinIODataProvider()
        self.backtester = EnhancedBacktester(self.data_provider)
        self.strategies = ['momentum', 'mean_reversion', 'breakout', 'trend_following']
        
    async def analyze_symbol_performance(self, symbol: str) -> Dict:
        """Analyze historical performance for a symbol across all strategies"""
        logger.info(f"🔍 Analyzing {symbol} across all strategies...")
        
        results = {}
        
        # Test different time periods
        periods = []
            (2020, 2022, "COVID Era"),
            (2022, 2023, "Bear Market 2022"),
            (2023, 2024, "AI Boom"),
            (2020, 2024, "Full Period")
        ]
        
        for start_year, end_year, period_name in periods:
            period_results = {}
            
            for strategy in self.strategies:
                try:
                    result = await self.backtester.run_strategy_backtest()
                        strategy, symbol, start_year, end_year
                    )
                    period_results[strategy] = result
                except Exception as e:
                    logger.error(f"Error backtesting {strategy} on {symbol}: {e}")
                    
            results[period_name] = period_results
            
        return results
        
    async def find_best_strategy_combinations(self) -> Dict:
        """Find best strategy-symbol combinations"""
        logger.info("🎯 Finding best strategy combinations...")
        
        all_results = []
        
        # Test key symbols
        test_symbols = ['AAPL', 'MSFT', 'SPY', 'QQQ', 'NVDA']
        
        for symbol in test_symbols:
            for strategy in self.strategies:
                try:
                    result = await self.backtester.run_strategy_backtest()
                        strategy, symbol, 2020, 2024
                    )
                    all_results.append(result)
                except Exception as e:
                    logger.error(f"Error in backtest: {e}")
                    
        # Sort by different criteria
        by_return = sorted(all_results, key=lambda x: x['total_return'], reverse=True)
        by_sharpe = sorted(all_results, key=lambda x: x['sharpe_ratio'], reverse=True)
        by_calmar = sorted(all_results, key=lambda x: x['calmar_ratio'], reverse=True)
        
        return {}
            'best_returns': by_return[:10],
            'best_sharpe': by_sharpe[:10],
            'best_calmar': by_calmar[:10],
            'summary_stats': self._calculate_summary_stats(all_results)
        }
        
    def _calculate_summary_stats(self, results: List[Dict]) -> Dict:
        """Calculate summary statistics across all backtests"""
        if not results:
            return {}
            
        df = pd.DataFrame(results)
        
        return {}
            'total_backtests': len(results),
            'avg_return': df['total_return'].mean(),
            'avg_sharpe': df['sharpe_ratio'].mean(),
            'avg_win_rate': df['win_rate'].mean(),
            'best_strategy': df.groupby('strategy')['total_return'].mean().idxmax(),
            'most_consistent': df.groupby('strategy')['sharpe_ratio'].mean().idxmax(),
            'strategy_performance': df.groupby('strategy').agg({)
                'total_return': ['mean', 'std'],
                'sharpe_ratio': 'mean',
                'win_rate': 'mean',
                'max_drawdown': 'mean'
            }).round(3).to_dict()
        }
        
    async def run_comprehensive_analysis(self):
        """Run comprehensive MinIO-enhanced analysis"""
        logger.info("🚀 MINIO-ENHANCED TRADING ORCHESTRATOR")
        logger.info("=" * 80)
        logger.info("📊 Simulating comprehensive historical analysis...")
        logger.info(f"🗂️ Data Years: {self.data_provider.available_years}")
        logger.info(f"📈 Symbols: {len(self.data_provider.symbols)}")
        logger.info(f"🎯 Strategies: {len(self.strategies)}")
        logger.info("=" * 80)
        
        # 1. Analyze key symbols
        key_symbols = ['AAPL', 'SPY', 'QQQ']
        symbol_analysis = {}
        
        for symbol in key_symbols:
            symbol_analysis[symbol] = await self.analyze_symbol_performance(symbol)
            
        # 2. Find best combinations
        best_combinations = await self.find_best_strategy_combinations()
        
        # 3. Generate comprehensive report
        report = {}
            'analysis_timestamp': datetime.now().isoformat(),
            'data_source': 'MinIO Historical Database (Simulated)',
            'analysis_scope': {}
                'symbols_analyzed': key_symbols,
                'strategies_tested': self.strategies,
                'years_covered': '2020-2024',
                'total_backtests': len(key_symbols) * len(self.strategies) * 4  # 4 periods each
            },
            'symbol_analysis': symbol_analysis,
            'best_combinations': best_combinations,
            'recommendations': self._generate_recommendations(best_combinations)
        }
        
        # 4. Display results
        await self._display_results(report)
        
        # 5. Save detailed report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f'minio_enhanced_analysis_{timestamp}.json'
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2, default=str)
            
        logger.info(f"📁 Comprehensive report saved to: {filename}")
        
        return report
        
    def _generate_recommendations(self, combinations: Dict) -> List[str]:
        """Generate trading recommendations based on analysis"""
        recommendations = []
        
        # Best overall strategy
        best_returns = combinations['best_returns']
        if best_returns:
            best = best_returns[0]
            recommendations.append()
                f"🥇 Top Performer: {best['strategy']} on {best['symbol']} "
                f"({best['total_return']:.1%} return, {best['sharpe_ratio']:.2f} Sharpe)"
            )
            
        # Most consistent strategy
        best_sharpe = combinations['best_sharpe']
        if best_sharpe:
            consistent = best_sharpe[0]
            recommendations.append()
                f"🎯 Most Consistent: {consistent['strategy']} on {consistent['symbol']} "
                f"(Sharpe: {consistent['sharpe_ratio']:.2f})"
            )
            
        # Risk-adjusted recommendation
        best_calmar = combinations['best_calmar']
        if best_calmar:
            risk_adj = best_calmar[0]
            recommendations.append()
                f"⚖️ Best Risk-Adjusted: {risk_adj['strategy']} on {risk_adj['symbol']} "
                f"(Calmar: {risk_adj['calmar_ratio']:.2f})"
            )
            
        # Strategy insights
        summary = combinations['summary_stats']
        if summary:
            recommendations.append()
                f"📊 Best Strategy Overall: {summary['best_strategy']} "
                f"(avg return: {summary['avg_return']:.1%})"
            )
            recommendations.append()
                f"🎲 Most Consistent Strategy: {summary['most_consistent']}"
            )
            
        return recommendations
        
    async def _display_results(self, report: Dict):
        """Display comprehensive results"""
        logger.info("\n📊 COMPREHENSIVE ANALYSIS RESULTS")
        logger.info("=" * 80)
        
        # Summary statistics
        combinations = report['best_combinations']
        summary = combinations['summary_stats']
        
        logger.info(f"Total Backtests Run: {summary['total_backtests']}")
        logger.info(f"Average Return: {summary['avg_return']:.2%}")
        logger.info(f"Average Sharpe Ratio: {summary['avg_sharpe']:.2f}")
        logger.info(f"Average Win Rate: {summary['avg_win_rate']:.1%}")
        
        # Top performers
        logger.info(f"\n🏆 TOP 5 PERFORMERS BY RETURN")
        logger.info("-" * 60)
        for i, result in enumerate(combinations['best_returns'][:5], 1):
            logger.info(f"{i}. {result['strategy']} on {result['symbol']}: ")
                       f"{result['total_return']:.1%} return, "
                       f"{result['sharpe_ratio']:.2f} Sharpe, "
                       f"{result['win_rate']:.1%} win rate")
                       
        # Strategy breakdown
        logger.info(f"\n📈 STRATEGY PERFORMANCE BREAKDOWN")
        logger.info("-" * 60)
        
        strategy_perf = summary['strategy_performance']
        for strategy in self.strategies:
            if strategy in strategy_perf:
                perf = strategy_perf[strategy]
                logger.info(f"{strategy.upper()}:")
                logger.info(f"  Avg Return: {perf['total_return']['mean']:.2%} ± {perf['total_return']['std']:.2%}")
                logger.info(f"  Avg Sharpe: {perf['sharpe_ratio']['mean']:.2f}")
                logger.info(f"  Avg Win Rate: {perf['win_rate']['mean']:.1%}")
                logger.info(f"  Avg Max DD: {perf['max_drawdown']['mean']:.2%}")
                
        # Recommendations
        logger.info(f"\n💡 KEY RECOMMENDATIONS")
        logger.info("-" * 60)
        for rec in report['recommendations']:
            logger.info(f"  {rec}")
            
        logger.info("\n" + "=" * 80)

async def main():
    """Main demonstration"""
    orchestrator = MinIOEnhancedOrchestrator()
    
    # Run comprehensive analysis
    await orchestrator.run_comprehensive_analysis()
    
    logger.info("\n✅ MinIO-Enhanced Trading Analysis Complete!")
    logger.info("🎯 Ready for live trading integration with historical insights")

if __name__ == "__main__":
    asyncio.run(main()