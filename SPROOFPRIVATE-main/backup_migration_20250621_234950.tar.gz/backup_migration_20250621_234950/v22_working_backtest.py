#!/usr/bin/env python3
"""
V22 Working Backtest System - Fixed version with proper Alpaca integration
"""

import pandas as pd
import numpy as np
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import json
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


class TradingAlgorithms:
    """Trading algorithms with proper implementations"""
    
    @staticmethod
    def calculate_rsi(prices: pd.Series, period: int = 14) -> pd.Series:
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
        rs = gain / loss.replace(0, 1e-10)
        return 100 - (100 / (1 + rs)
    
    @staticmethod
    def calculate_macd(prices: pd.Series) -> Tuple[pd.Series, pd.Series]:
        """Calculate MACD and signal line"""
        exp1 = prices.ewm(span=12, adjust=False).mean()
        exp2 = prices.ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        return macd, signal
    
    @staticmethod
    def calculate_bollinger_bands(prices: pd.Series, period: int = 20, std_dev: int = 2) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Calculate Bollinger Bands"""
        middle = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        upper = middle + (std_dev * std)
        lower = middle - (std_dev * std)
        return upper, middle, lower
    
    def rsi_oversold(self, data: pd.DataFrame) -> pd.Series:
        """RSI Oversold/Overbought strategy"""
        rsi = self.calculate_rsi(data['close'])
        signals = pd.Series(0, index=data.index)
        signals[rsi < 30] = 1  # Buy when oversold
        signals[rsi > 70] = -1  # Sell when overbought
        return signals
    
    def macd_crossover(self, data: pd.DataFrame) -> pd.Series:
        """MACD Crossover strategy"""
        macd, signal = self.calculate_macd(data['close'])
        signals = pd.Series(0, index=data.index)
        
        # Buy when MACD crosses above signal
        signals[(macd > signal) & (macd.shift(1) <= signal.shift(1)] = 1)
        # Sell when MACD crosses below signal
        signals[(macd < signal) & (macd.shift(1) >= signal.shift(1)] = -1)
        
        return signals
    
    def bollinger_squeeze(self, data: pd.DataFrame) -> pd.Series:
        """Bollinger Band squeeze strategy"""
        upper, middle, lower = self.calculate_bollinger_bands(data['close'])
        band_width = upper - lower
        
        signals = pd.Series(0, index=data.index)
        
        # Buy when price touches lower band
        signals[data['close'] <= lower] = 1
        # Sell when price touches upper band
        signals[data['close'] >= upper] = -1
        
        return signals
    
    def mean_reversion(self, data: pd.DataFrame) -> pd.Series:
        """Mean reversion strategy"""
        sma = data['close'].rolling(window=20).mean()
        std = data['close'].rolling(window=20).std()
        
        signals = pd.Series(0, index=data.index)
        
        # Buy when price is 2 std devs below mean
        signals[data['close'] < (sma - 2 * std)] = 1
        # Sell when price is 2 std devs above mean
        signals[data['close'] > (sma + 2 * std)] = -1
        
        return signals
    
    def momentum_alpha(self, data: pd.DataFrame) -> pd.Series:
        """Momentum strategy"""
        returns = data['close'].pct_change()
        momentum = returns.rolling(window=20).mean()
        
        signals = pd.Series(0, index=data.index)
        
        # Buy when momentum is positive and increasing
        signals[(momentum > 0) & (momentum > momentum.shift(1)] = 1)
        # Sell when momentum is negative and decreasing
        signals[(momentum < 0) & (momentum < momentum.shift(1)] = -1)
        
        return signals
    
    def volume_breakout(self, data: pd.DataFrame) -> pd.Series:
        """Volume breakout strategy"""
        avg_volume = data['volume'].rolling(window=20).mean()
        price_change = data['close'].pct_change()
        
        signals = pd.Series(0, index=data.index)
        
        # Buy on high volume with positive price change
        signals[(data['volume'] > 2 * avg_volume) & (price_change > 0.01)] = 1
        # Sell on high volume with negative price change
        signals[(data['volume'] > 2 * avg_volume) & (price_change < -0.01)] = -1
        
        return signals

class WorkingBacktester:
    """Simple but working backtester"""
    
    def __init__(self):
        # Load Alpaca config
        with open('alpaca_config.json', 'r') as f:
            config = json.load(f)
        
        self.client = TradingClient()
            config.get('paper_api_key'),
            config.get('paper_secret_key'),
            config.get('paper_base_url')
        )
        
        self.algorithms = TradingAlgorithms()
        self.results = {}
    
    def fetch_data(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Fetch daily data from Alpaca"""
        bars = self.client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=start_date,
            end=end_date,
            adjustment='raw'
        ).df
        
        if not bars.empty:
            # Ensure proper data types
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in bars.columns:
                    bars[col] = bars[col].astype(float)
        
        return bars
    
    def backtest_strategy(self, data: pd.DataFrame, signals: pd.Series, 
                         initial_capital: float = 100000) -> Dict:
        """Run backtest for a single strategy"""
        cash = initial_capital
        shares = 0
        trades = []
        equity_curve = []
        
        for i in range(len(data):
            current_price = data['close'].iloc[i]
            signal = signals.iloc[i] if i < len(signals) else 0
            
            # Track equity
            current_equity = cash + (shares * current_price)
            equity_curve.append(current_equity)
            
            # Execute trades
            if signal == 1 and shares == 0:  # Buy signal
                shares = int(cash * 0.95 / current_price)  # Use 95% of cash
                cost = shares * current_price
                cash -= cost
                trades.append({)
                    'date': data.index[i],
                    'action': 'BUY',
                    'price': current_price,
                    'shares': shares
                })
            
            elif signal == -1 and shares > 0:  # Sell signal
                revenue = shares * current_price
                cash += revenue
                trades.append({)
                    'date': data.index[i],
                    'action': 'SELL',
                    'price': current_price,
                    'shares': shares
                })
                shares = 0
        
        # Close any open position
        if shares > 0:
            final_price = data['close'].iloc[-1]
            cash += shares * final_price
            equity_curve[-1] = cash
        
        # Calculate metrics
        final_value = cash
        total_return = (final_value - initial_capital) / initial_capital
        
        # Calculate Sharpe ratio
        equity_series = pd.Series(equity_curve)
        daily_returns = equity_series.pct_change().dropna()
        sharpe_ratio = np.sqrt(252) * daily_returns.mean() / daily_returns.std() if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
        
        # Calculate win rate
        win_rate = 0
        if len(trades) >= 2:
            wins = 0
            for i in range(0, len(trades)-1, 2):
                if i+1 < len(trades):
                    if trades[i]['action'] == 'BUY' and trades[i+1]['action'] == 'SELL':
                        if trades[i+1]['price'] > trades[i]['price']:
                            wins += 1
            
            total_round_trips = len(trades) // 2
            win_rate = wins / total_round_trips if total_round_trips > 0 else 0
        
        return {}
            'total_return': total_return,
            'sharpe_ratio': sharpe_ratio,
            'win_rate': win_rate,
            'num_trades': len(trades),
            'final_value': final_value,
            'equity_curve': equity_curve,
            'trades': trades
        }
    
    def run_full_backtest(self, symbols: List[str], start_date: str, end_date: str):
        """Run backtest for multiple symbols and strategies"""
        
        algorithms = []
            'rsi_oversold',
            'macd_crossover',
            'bollinger_squeeze',
            'mean_reversion',
            'momentum_alpha',
            'volume_breakout'
        ]
        
        print("\n" + "="*80)
        print("🚀 V22 WORKING BACKTEST SYSTEM")
        print("="*80)
        print(f"📅 Period: {start_date} to {end_date}")
        print(f"📊 Symbols: {', '.join(symbols)}")
        print(f"🤖 Algorithms: {len(algorithms)}")
        print("="*80 + "\n")
        
        all_results = {}
        
        for symbol in symbols:
            print(f"\n📊 Processing {symbol}...")
            
            # Fetch data
            data = self.fetch_data(symbol, start_date, end_date)
            
            if data.empty:
                print(f"  ❌ No data available")
                continue
            
            print(f"  ✅ Fetched {len(data)} days, price range: ${data['close'].min():.2f}-${data['close'].max():.2f}")
            
            symbol_results = {}
            
            for algo_name in algorithms:
                if hasattr(self.algorithms, algo_name):
                    # Get algorithm function
                    algo_func = getattr(self.algorithms, algo_name)
                    
                    try:
                        # Generate signals
                        signals = algo_func(data)
                        
                        # Run backtest
                        results = self.backtest_strategy(data, signals)
                        
                        symbol_results[algo_name] = results
                        
                        # Print summary
                        if results['num_trades'] > 0:
                            print(f"  • {algo_name}: Return={results['total_return']:.2%}, ")
                                  f"Sharpe={results['sharpe_ratio']:.2f}, "
                                  f"Trades={results['num_trades']}")
                    
                    except Exception as e:
                        print(f"  • {algo_name}: Error - {e}")
            
            all_results[symbol] = symbol_results
        
        self.results = all_results
        self.generate_summary()
    
    def generate_summary(self):
        """Generate and print summary of results"""
        print("\n" + "="*80)
        print("📊 BACKTEST SUMMARY")
        print("="*80)
        
        # Aggregate results by algorithm
        algo_performance = {}
        
        for symbol, symbol_results in self.results.items():
            for algo_name, results in symbol_results.items():
                if algo_name not in algo_performance:
                    algo_performance[algo_name] = {}
                        'returns': [],
                        'sharpes': [],
                        'win_rates': [],
                        'trades': []
                    }
                
                algo_performance[algo_name]['returns'].append(results['total_return'])
                algo_performance[algo_name]['sharpes'].append(results['sharpe_ratio'])
                algo_performance[algo_name]['win_rates'].append(results['win_rate'])
                algo_performance[algo_name]['trades'].append(results['num_trades'])
        
        # Sort by average return
        sorted_algos = sorted(algo_performance.items(), 
                            key=lambda x: np.mean(x[1]['returns']), 
                            reverse=True)
        
        print("\n🏆 ALGORITHM RANKINGS:")
        print(f"{'Rank':<6} {'Algorithm':<20} {'Avg Return':<12} {'Avg Sharpe':<12} {'Avg Win Rate':<12} {'Total Trades':<12}")
        print("-" * 80)
        
        for i, (algo_name, perf) in enumerate(sorted_algos, 1):
            avg_return = np.mean(perf['returns'])
            avg_sharpe = np.mean(perf['sharpes'])
            avg_win_rate = np.mean(perf['win_rates'])
            total_trades = sum(perf['trades'])
            
            print(f"{i:<6} {algo_name:<20} {avg_return:>10.2%} {avg_sharpe:>11.2f} ")
                  f"{avg_win_rate:>11.1%} {total_trades:>11}")
        
        # Best performing combinations
        print("\n🌟 TOP SYMBOL-ALGORITHM COMBINATIONS:")
        all_combos = []
        
        for symbol, symbol_results in self.results.items():
            for algo_name, results in symbol_results.items():
                if results['num_trades'] > 0:
                    all_combos.append({)
                        'symbol': symbol,
                        'algorithm': algo_name,
                        'return': results['total_return'],
                        'sharpe': results['sharpe_ratio'],
                        'trades': results['num_trades']
                    })
        
        # Sort by return
        all_combos.sort(key=lambda x: x['return'], reverse=True)
        
        print(f"{'Symbol':<10} {'Algorithm':<20} {'Return':<12} {'Sharpe':<10} {'Trades':<10}")
        print("-" * 60)
        
        for combo in all_combos[:10]:
            print(f"{combo['symbol']:<10} {combo['algorithm']:<20} ")
                  f"{combo['return']:>10.2%} {combo['sharpe']:>8.2f} {combo['trades']:>8}")
        
        print("\n✅ Backtest complete!")

def main():
    """Run the backtest"""
    backtester = WorkingBacktester()
    
    # Test with major stocks
    symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'SPY']
    
    # Run for 2023
    backtester.run_full_backtest(symbols, '2023-01-01', '2023-12-31')

if __name__ == "__main__":
    main()