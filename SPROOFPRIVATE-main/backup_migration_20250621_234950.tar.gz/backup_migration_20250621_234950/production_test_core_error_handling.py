#!/usr/bin/env python3
"""
Comprehensive Test Suite for Core Error Handling Module
======================================================

Tests the unified error handling and retry framework including:
- Error classification and severity
- Retry strategies with backoff
- Circuit breaker pattern
- Error tracking and pattern detection
- Context managers for safe execution
"""

from datetime import datetime, timedelta
import sys
import os
import unittest
import asyncio
import time
import random
import threading

import logging
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from datetime import datetime

# Import error handling module
from core.error_handling import ()
    ErrorSeverity,
    BackoffStrategy,
    ErrorInfo,
    RetryableError,
    RateLimitError,
    NetworkError,
    DataError,
    SystemResourceError,
    TradingSystemError,
    BackoffCalculator,
    CircuitBreaker
)


# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class TestErrorClassification(unittest.TestCase):
    """Test error classification and hierarchy"""
    
    def test_error_severity_enum(self):
        """Test error severity enumeration"""
        self.assertEqual(ErrorSeverity.LOW.value, "low")
        self.assertEqual(ErrorSeverity.MEDIUM.value, "medium")
        self.assertEqual(ErrorSeverity.HIGH.value, "high")
        self.assertEqual(ErrorSeverity.CRITICAL.value, "critical")
    
    def test_retryable_error_hierarchy(self):
        """Test retryable error hierarchy"""
        # Base retryable error
        error = RetryableError("Test error")
        self.assertEqual(error.severity, ErrorSeverity.MEDIUM)
        self.assertIsInstance(error, Exception)
        
        # Custom severity
        error = RetryableError("Critical error", ErrorSeverity.CRITICAL)
        self.assertEqual(error.severity, ErrorSeverity.CRITICAL)
    
    def test_specific_error_types(self):
        """Test specific error type classifications"""
        # Rate limit error
        rate_error = RateLimitError()
        self.assertEqual(rate_error.severity, ErrorSeverity.MEDIUM)
        self.assertIsInstance(rate_error, RetryableError)
        
        # Network error
        network_error = NetworkError("Connection timeout")
        self.assertEqual(network_error.severity, ErrorSeverity.MEDIUM)
        
        # Data error
        data_error = DataError("Invalid data format")
        self.assertEqual(data_error.severity, ErrorSeverity.LOW)
        
        # System resource error
        resource_error = SystemResourceError("Out of memory")
        self.assertEqual(resource_error.severity, ErrorSeverity.HIGH)
    
    def test_trading_system_error(self):
        """Test non-retryable trading system error"""
        error = TradingSystemError("Critical trading error")
        self.assertNotIsInstance(error, RetryableError)
        self.assertIsInstance(error, Exception)
    
    def test_error_info_dataclass(self):
        """Test ErrorInfo dataclass functionality"""
        test_exception = ValueError("Test exception")
        error_info = ErrorInfo()
            exception=test_exception,
            severity=ErrorSeverity.HIGH,
            timestamp=time.time(),
            function_name="test_function",
            args=(1, 2, 3),
            kwargs={'key': 'value'},
            attempt_number=2,
            total_attempts=5
        )
        
        # Test to_dict conversion
        error_dict = error_info.to_dict()
        self.assertEqual(error_dict['exception_type'], 'ValueError')
        self.assertEqual(error_dict['exception_message'], 'Test exception')
        self.assertEqual(error_dict['severity'], 'high')
        self.assertEqual(error_dict['function_name'], 'test_function')
        self.assertEqual(error_dict['attempt_number'], 2)
        self.assertEqual(error_dict['total_attempts'], 5)


class TestBackoffCalculator(unittest.TestCase):
    """Test backoff delay calculation strategies"""
    
    def test_fixed_backoff(self):
        """Test fixed backoff strategy"""
        for attempt in range(1, 6):
            delay = BackoffCalculator.calculate_delay()
                BackoffStrategy.FIXED, 
                attempt, 
                base_delay=2.0,
                jitter=False
            )
            self.assertEqual(delay, 2.0)
    
    def test_linear_backoff(self):
        """Test linear backoff strategy"""
        for attempt in range(1, 6):
            delay = BackoffCalculator.calculate_delay()
                BackoffStrategy.LINEAR,
                attempt,
                base_delay=2.0,
                jitter=False
            )
            self.assertEqual(delay, 2.0 * attempt)
    
    def test_exponential_backoff(self):
        """Test exponential backoff strategy"""
        expected_delays = [2.0, 4.0, 8.0, 16.0, 32.0]
        
        for attempt, expected in enumerate(expected_delays, 1):
            delay = BackoffCalculator.calculate_delay()
                BackoffStrategy.EXPONENTIAL,
                attempt,
                base_delay=2.0,
                jitter=False
            )
            self.assertEqual(delay, expected)
    
    def test_fibonacci_backoff(self):
        """Test Fibonacci backoff strategy"""
        expected_multipliers = [1, 2, 3, 5, 8, 13, 21]
        
        for attempt, multiplier in enumerate(expected_multipliers, 1):
            delay = BackoffCalculator.calculate_delay()
                BackoffStrategy.FIBONACCI,
                attempt,
                base_delay=1.0,
                jitter=False
            )
            self.assertEqual(delay, float(multiplier))
    
    def test_max_delay_cap(self):
        """Test maximum delay capping"""
        # Exponential backoff with low cap
        delay = BackoffCalculator.calculate_delay()
            BackoffStrategy.EXPONENTIAL,
            10,  # Would be 512 seconds without cap
            base_delay=1.0,
            max_delay=60.0,
            jitter=False
        )
        self.assertEqual(delay, 60.0)
    
    def test_jitter_application(self):
        """Test jitter adds randomness"""
        delays = []
        for _ in range(10):
            delay = BackoffCalculator.calculate_delay()
                BackoffStrategy.FIXED,
                1,
                base_delay=10.0,
                jitter=True,
                jitter_factor=0.2
            )
            delays.append(delay)
        
        # All delays should be different due to jitter
        self.assertEqual(len(set(delays)), 10)
        
        # All should be within jitter range
        for delay in delays:
            self.assertGreaterEqual(delay, 9.0)  # 10 - 10*0.2/2
            self.assertLessEqual(delay, 11.0)    # 10 + 10*0.2/2
    
    def test_invalid_attempt_number(self):
        """Test invalid attempt number handling"""
        with self.assertRaises(ValueError):
            BackoffCalculator.calculate_delay(BackoffStrategy.FIXED, 0)
        
        with self.assertRaises(ValueError):
            BackoffCalculator.calculate_delay(BackoffStrategy.FIXED, -1)
    
    def test_minimum_delay_enforcement(self):
        """Test minimum delay is enforced"""
        delay = BackoffCalculator.calculate_delay()
            BackoffStrategy.FIXED,
            1,
            base_delay=0.01,
            jitter=False
        )
        self.assertGreaterEqual(delay, 0.1)
    
    def test_fibonacci_cache(self):
        """Test Fibonacci calculation caching"""
        # Clear cache
        BackoffCalculator._fib_cache.clear()
        
        # First calculation
        start = time.time()
        result1 = BackoffCalculator._fibonacci(20)
        first_time = time.time() - start
        
        # Second calculation (cached)
        start = time.time()
        result2 = BackoffCalculator._fibonacci(20)
        second_time = time.time() - start
        
        self.assertEqual(result1, result2)
        # Cached access should be much faster
        self.assertLess(second_time, first_time / 10)


class TestCircuitBreaker(unittest.TestCase):
    """Test circuit breaker implementation"""
    
    def setUp(self):
        """Set up test circuit breaker"""
        self.breaker = CircuitBreaker()
            failure_threshold=3,
            recovery_time=1.0,
            expected_exception=ValueError,
            name="TestBreaker"
        )
    
    def test_initial_state(self):
        """Test circuit breaker initial state"""
        self.assertEqual(self.breaker._state, "CLOSED")
        self.assertEqual(self.breaker._failure_count, 0)
        self.assertEqual(self.breaker._success_count, 0)
    
    def test_successful_calls(self):
        """Test successful calls don't open circuit"""
        def success_func():
            return "success"
        
        for _ in range(10):
            result = self.breaker.call(success_func)
            self.assertEqual(result, "success")
        
        self.assertEqual(self.breaker._state, "CLOSED")
        self.assertEqual(self.breaker._failure_count, 0)
        self.assertEqual(self.breaker._success_count, 10)
    
    def test_circuit_opens_on_threshold(self):
        """Test circuit opens after failure threshold"""
        def failing_func():
            raise ValueError("Test failure")
        
        # Fail up to threshold
        for i in range(self.breaker.failure_threshold):
            with self.assertRaises(ValueError):
                self.breaker.call(failing_func)
            
            if i < self.breaker.failure_threshold - 1:
                self.assertEqual(self.breaker._state, "CLOSED")
            else:
                self.assertEqual(self.breaker._state, "OPEN")
        
        # Circuit should be open
        self.assertEqual(self.breaker._failure_count, self.breaker.failure_threshold)
    
    def test_open_circuit_blocks_calls(self):
        """Test open circuit blocks calls"""
        # Open the circuit
        def failing_func():
            raise ValueError("Test failure")
        
        for _ in range(self.breaker.failure_threshold):
            with self.assertRaises(ValueError):
                self.breaker.call(failing_func)
        
        # Now circuit is open, calls should be blocked
        def success_func():
            return "success"
        
        with self.assertRaises(Exception) as cm:
            self.breaker.call(success_func)
        
        self.assertIn("Circuit breaker is OPEN", str(cm.exception))
    
    def test_circuit_recovery(self):
        """Test circuit recovery after timeout"""
        # Open the circuit
        def failing_func():
            raise ValueError("Test failure")
        
        for _ in range(self.breaker.failure_threshold):
            with self.assertRaises(ValueError):
                self.breaker.call(failing_func)
        
        # Wait for recovery time
        time.sleep(self.breaker.recovery_time + 0.1)
        
        # Circuit should attempt half-open on next call
        def success_func():
            return "success"
        
        result = self.breaker.call(success_func)
        self.assertEqual(result, "success")
        self.assertEqual(self.breaker._state, "CLOSED")
        self.assertEqual(self.breaker._failure_count, 0)
    
    def test_half_open_failure_reopens(self):
        """Test failure in half-open state reopens circuit"""
        # Open the circuit
        def failing_func():
            raise ValueError("Test failure")
        
        for _ in range(self.breaker.failure_threshold):
            with self.assertRaises(ValueError):
                self.breaker.call(failing_func)
        
        # Wait for recovery time
        time.sleep(self.breaker.recovery_time + 0.1)
        
        # Fail in half-open state
        with self.assertRaises(ValueError):
            self.breaker.call(failing_func)
        
        self.assertEqual(self.breaker._state, "OPEN")
    
    def test_unexpected_exceptions_not_counted(self):
        """Test unexpected exceptions don't affect circuit state"""
        def unexpected_error():
            raise RuntimeError("Unexpected error")
        
        # Unexpected errors shouldn't open circuit
        for _ in range(5):
            with self.assertRaises(RuntimeError):
                self.breaker.call(unexpected_error)
        
        self.assertEqual(self.breaker._state, "CLOSED")
        self.assertEqual(self.breaker._failure_count, 0)
    
    def test_async_call(self):
        """Test async call functionality"""
        async def async_success():
            await asyncio.sleep(0.01)
            return "async_success"
        
        async def async_failure():
            await asyncio.sleep(0.01)
            raise ValueError("Async failure")
        
        async def run_test():
            # Test successful async call
            result = await self.breaker.acall(async_success)
            self.assertEqual(result, "async_success")
            
            # Test failing async calls
            for _ in range(self.breaker.failure_threshold):
                with self.assertRaises(ValueError):
                    await self.breaker.acall(async_failure)
            
            # Circuit should be open
            self.assertEqual(self.breaker._state, "OPEN")
        
        asyncio.run(run_test())
    
    def test_thread_safety(self):
        """Test circuit breaker thread safety"""
        success_count = 0
        failure_count = 0
        
        def thread_func(should_fail):
            nonlocal success_count, failure_count
            
            def test_func():
                if should_fail:
                    raise ValueError("Thread failure")
                return "success"
            
            try:
                self.breaker.call(test_func)
                success_count += 1
            except Exception:
                failure_count += 1
        
        # Create multiple threads
        threads = []
        for i in range(10):
            should_fail = i < 5  # First 5 fail, last 5 succeed
            t = threading.Thread(target=thread_func, args=(should_fail,))
            threads.append(t)
            t.start()
        
        # Wait for all threads
        for t in threads:
            t.join()
        
        # Verify results (exact counts may vary due to circuit opening)
        self.assertGreater(failure_count, 0)
        self.assertLessEqual(self.breaker._failure_count, 5)


class TestIntegrationScenarios(unittest.TestCase):
    """Test integration scenarios combining multiple components"""
    
    def test_retry_with_backoff(self):
        """Test retry logic with backoff strategy"""
        attempt_count = 0
        attempt_times = []
        
        def flaky_function():
            nonlocal attempt_count
            attempt_count += 1
            attempt_times.append(time.time())
            
            if attempt_count < 3:
                raise NetworkError("Network timeout")
            return "success"
        
        # Simulate retry logic
        max_attempts = 5
        for attempt in range(1, max_attempts + 1):
            try:
                result = flaky_function()
                break
            except NetworkError:
                if attempt < max_attempts:
                    delay = BackoffCalculator.calculate_delay()
                        BackoffStrategy.EXPONENTIAL,
                        attempt,
                        base_delay=0.1,
                        jitter=False
                    )
                    time.sleep(delay)
                else:
                    raise
        
        self.assertEqual(result, "success")
        self.assertEqual(attempt_count, 3)
        
        # Verify delays between attempts
        if len(attempt_times) > 1:
            delay1 = attempt_times[1] - attempt_times[0]
            self.assertAlmostEqual(delay1, 0.1, places=1)
            
            if len(attempt_times) > 2:
                delay2 = attempt_times[2] - attempt_times[1]
                self.assertAlmostEqual(delay2, 0.2, places=1)
    
    def test_circuit_breaker_with_error_tracking(self):
        """Test circuit breaker with error tracking"""
        errors = []
        
        def error_tracking_wrapper(func):
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    error_info = ErrorInfo()
                        exception=e,
                        severity=ErrorSeverity.HIGH if isinstance(e, SystemResourceError) else ErrorSeverity.MEDIUM,
                        timestamp=time.time(),
                        function_name=func.__name__,
                        args=args,
                        kwargs=kwargs,
                        attempt_number=len(errors) + 1,
                        total_attempts=5
                    )
                    errors.append(error_info)
                    raise
            return wrapper
        
        breaker = CircuitBreaker(failure_threshold=3, recovery_time=1.0)
        
        @error_tracking_wrapper
        def failing_service():
            raise SystemResourceError("Service unavailable")
        
        # Fail until circuit opens
        for _ in range(3):
            with self.assertRaises(SystemResourceError):
                breaker.call(failing_service)
        
        # Verify error tracking
        self.assertEqual(len(errors), 3)
        for error in errors:
            self.assertEqual(error.severity, ErrorSeverity.HIGH)
            self.assertEqual(error.function_name, 'failing_service')
            self.assertIsInstance(error.exception, SystemResourceError)


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and boundary conditions"""
    
    def test_backoff_overflow_protection(self):
        """Test exponential backoff overflow protection"""
        # Very high attempt number
        delay = BackoffCalculator.calculate_delay()
            BackoffStrategy.EXPONENTIAL,
            100,  # Would overflow without protection
            base_delay=1.0,
            max_delay=3600.0,
            jitter=False
        )
        self.assertEqual(delay, 3600.0)
    
    def test_circuit_breaker_rapid_state_changes(self):
        """Test rapid circuit breaker state changes"""
        breaker = CircuitBreaker()
            failure_threshold=2,
            recovery_time=0.1,
            expected_exception=ValueError
        )
        
        def failing_func():
            raise ValueError("Fail")
        
        def success_func():
            return "success"
        
        # Open circuit
        for _ in range(2):
            with self.assertRaises(ValueError):
                breaker.call(failing_func)
        
        # Wait for recovery
        time.sleep(0.15)
        
        # Success should close circuit
        result = breaker.call(success_func)
        self.assertEqual(result, "success")
        self.assertEqual(breaker._state, "CLOSED")
        
        # Immediately fail again
        for _ in range(2):
            with self.assertRaises(ValueError):
                breaker.call(failing_func)
        
        self.assertEqual(breaker._state, "OPEN")
    
    def test_zero_recovery_time(self):
        """Test circuit breaker with zero recovery time"""
        breaker = CircuitBreaker()
            failure_threshold=1,
            recovery_time=0.0,
            expected_exception=ValueError
        )
        
        def failing_func():
            raise ValueError("Fail")
        
        # Open circuit
        with self.assertRaises(ValueError):
            breaker.call(failing_func)
        
        # Should immediately allow retry
        def success_func():
            return "success"
        
        result = breaker.call(success_func)
        self.assertEqual(result, "success")
    
    def test_jitter_boundary_values(self):
        """Test jitter with boundary values"""
        # Zero jitter factor
        delay = BackoffCalculator.calculate_delay()
            BackoffStrategy.FIXED,
            1,
            base_delay=10.0,
            jitter=True,
            jitter_factor=0.0
        )
        self.assertEqual(delay, 10.0)
        
        # Jitter factor > 1.0 (should be capped)
        delays = []
        for _ in range(10):
            delay = BackoffCalculator.calculate_delay()
                BackoffStrategy.FIXED,
                1,
                base_delay=10.0,
                jitter=True,
                jitter_factor=2.0  # Should be capped to 1.0
            )
            delays.append(delay)
        
        # All delays should be within valid range
        for delay in delays:
            self.assertGreaterEqual(delay, 5.0)   # 10 - 10*1.0/2
            self.assertLessEqual(delay, 15.0)    # 10 + 10*1.0/2


class TestPerformance(unittest.TestCase):
    """Test performance characteristics"""
    
    def test_fibonacci_cache_performance(self):
        """Test Fibonacci calculation performance with caching"""
        # Clear cache
        BackoffCalculator._fib_cache.clear()
        
        # Time uncached calculations
        start = time.time()
        for i in range(1, 31):
            BackoffCalculator._fibonacci(i)
        uncached_time = time.time() - start
        
        # Time cached calculations
        start = time.time()
        for i in range(1, 31):
            BackoffCalculator._fibonacci(i)
        cached_time = time.time() - start
        
        # Cached should be significantly faster
        self.assertLess(cached_time, uncached_time / 10)
    
    def test_circuit_breaker_overhead(self):
        """Test circuit breaker performance overhead"""
        breaker = CircuitBreaker(failure_threshold=5, recovery_time=60.0)
        
        def fast_function():
            return sum(range(100))
        
        # Time without circuit breaker
        start = time.time()
        for _ in range(1000):
            result = fast_function()
        direct_time = time.time() - start
        
        # Time with circuit breaker
        start = time.time()
        for _ in range(1000):
            result = breaker.call(fast_function)
        breaker_time = time.time() - start
        
        # Overhead should be minimal (less than 50%)
        overhead = (breaker_time - direct_time) / direct_time
        self.assertLess(overhead, 0.5)
    
    def test_concurrent_circuit_breaker_access(self):
        """Test circuit breaker under concurrent access"""
        breaker = CircuitBreaker(failure_threshold=10, recovery_time=1.0)
        results = {'success': 0, 'failure': 0}
        lock = threading.Lock()
        
        def concurrent_function(thread_id):
            def test_func():
                if thread_id % 3 == 0:
                    raise ValueError("Simulated failure")
                return "success"
            
            try:
                result = breaker.call(test_func)
                with lock:
                    results['success'] += 1
            except Exception:
                with lock:
                    results['failure'] += 1
        
        # Create many concurrent threads
        threads = []
        for i in range(100):
            t = threading.Thread(target=concurrent_function, args=(i,))
            threads.append(t)
            t.start()
        
        # Wait for all threads
        for t in threads:
            t.join()
        
        # Verify results
        total = results['success'] + results['failure']
        self.assertEqual(total, 100)
        
        # Some should fail due to circuit opening
        self.assertGreater(results['failure'], 30)  # At least the failing ones


if __name__ == '__main__':
    unittest.main(verbosity=2)