
#!/usr/bin/env python3
# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get credentials
api_key = os.getenv('ALPACA_PAPER_API_KEY')
api_secret = os.getenv('ALPACA_PAPER_API_SECRET')

print(f"API Key: {api_key[:10]}..." if api_key else "No API key found")

# Initialize client
client = TradingClient(api_key, api_secret, paper=True)

# Test connection by getting account info
try:
    account = client.get_account()
    print(f"✓ Connection successful!")
    print(f"Account Status: {account.status}")
    print(f"Buying Power: ${account.buying_power}")
    print(f"Portfolio Value: ${account.portfolio_value}")
except Exception as e:
    print(f"✗ Connection failed: {e}")