#!/usr/bin/env python3
"""
Aggressive Options Executor - Simplified for Quick Execution
===========================================================
Executes options trades aggressively with minimal validation
"""

import asyncio
import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
import json
import time
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import warnings

from universal_market_data import get_current_market_data, get_realistic_price
warnings.filterwarnings('ignore')

from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce, AssetClass
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockLatestQuoteRequest

logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Alpaca credentials
API_KEY = os.getenv('ALPACA_PAPER_API_KEY')
SECRET_KEY = os.getenv('ALPACA_PAPER_API_SECRET')
BASE_URL = "https://paper-api.alpaca.markets"

class AggressiveOptionsExecutor:
    """Aggressive options executor - trades options-like strategies using stocks"""
    
    def __init__(self):
        # Initialize Alpaca
        self.trading_client = TradingClient(API_KEY, SECRET_KEY, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.stock_data_client = StockHistoricalDataClient(API_KEY, SECRET_KEY)
        
        # Get account info
        self.account = self.trading_client.get_account()
        self.initial_capital = float(self.account.equity)
        
        logger.info(f"🔥 AGGRESSIVE OPTIONS EXECUTOR INITIALIZED")
        logger.info(f"💰 Account Equity: ${self.initial_capital:,.2f}")
        logger.info(f"💵 Buying Power: ${float(self.account.buying_power):,.2f}")
        
        # Options-like ETFs and high volatility stocks
        self.symbols = {}
            # Leveraged ETFs (options-like behavior)
            'TQQQ': {'type': 'LEVERAGED_LONG', 'leverage': 3, 'underlying': 'QQQ'},
            'SQQQ': {'type': 'LEVERAGED_SHORT', 'leverage': -3, 'underlying': 'QQQ'},
            'SPXL': {'type': 'LEVERAGED_LONG', 'leverage': 3, 'underlying': 'SPY'},
            'SPXS': {'type': 'LEVERAGED_SHORT', 'leverage': -3, 'underlying': 'SPY'},
            'UPRO': {'type': 'LEVERAGED_LONG', 'leverage': 3, 'underlying': 'SPY'},
            'UVXY': {'type': 'VOLATILITY', 'leverage': 1.5, 'underlying': 'VIX'},
            'SVXY': {'type': 'INVERSE_VOL', 'leverage': -0.5, 'underlying': 'VIX'},
            'LABU': {'type': 'LEVERAGED_SECTOR', 'leverage': 3, 'sector': 'BIOTECH'},
            'LABD': {'type': 'INVERSE_SECTOR', 'leverage': -3, 'sector': 'BIOTECH'},
            'FNGU': {'type': 'LEVERAGED_TECH', 'leverage': 3, 'sector': 'TECH'},
            'SOXL': {'type': 'LEVERAGED_SEMI', 'leverage': 3, 'sector': 'SEMIS'},
            'SOXS': {'type': 'INVERSE_SEMI', 'leverage': -3, 'sector': 'SEMIS'},
            
            # High implied volatility stocks
            'GME': {'type': 'MEME', 'iv': 100},
            'AMC': {'type': 'MEME', 'iv': 90},
            'TSLA': {'type': 'HIGH_VOL', 'iv': 60},
            'NVDA': {'type': 'HIGH_VOL', 'iv': 50},
            'PLTR': {'type': 'HIGH_VOL', 'iv': 70},
            'COIN': {'type': 'CRYPTO', 'iv': 80},
            'MARA': {'type': 'CRYPTO', 'iv': 90},
            'RIOT': {'type': 'CRYPTO', 'iv': 85}
        }
        
        # Spread strategies using these instruments
        self.spread_strategies = []
            'SYNTHETIC_STRADDLE',  # Long volatility using UVXY + stock
            'LEVERAGED_SPREAD',    # TQQQ vs SQQQ
            'VOLATILITY_ARB',      # UVXY vs SVXY
            'SECTOR_ROTATION',     # LABU vs LABD
            'MEME_PAIRS',          # GME vs AMC
            'TECH_SPREAD',         # FNGU vs SOXL
            'CORRELATION_BREAK'    # When correlations diverge
        ]
        
        # Risk parameters
        self.max_position_size = 0.05  # 5% per leg
        self.aggressive_mode = True
        self.min_spread_value = 100  # Minimum $100 per spread
        
        # Tracking
        self.active_spreads = {}
        self.total_trades = 0
        
        logger.info(f"📊 Trading Instruments: {len(self.symbols)}")
        logger.info(f"🎯 Spread Strategies: {len(self.spread_strategies)}")
    
    async def get_quotes(self, symbols: List[str]) -> Dict[str, float]:
        """Get current quotes for symbols"""
        quotes = {}
        
        try:
            quote_request = StockLatestQuoteRequest(symbol_or_symbols=symbols)
            latest_quotes = self.stock_data_client.get_stock_latest_quote(quote_request)
            
            for symbol in symbols:
                if symbol in latest_quotes:
                    q = latest_quotes[symbol]
                    quotes[symbol] = float(q.ask_price) if q.ask_price else float(q.bid_price)
                else:
                    quotes[symbol] = 100.0  # Default
                    
        except Exception as e:
            logger.error(f"Quote error: {str(e)}")
            # Use random prices as fallback
            for symbol in symbols:
                if symbol not in quotes:
                    base_prices = {}
                        'TQQQ': 65, 'SQQQ': 12, 'SPXL': 150, 'SPXS': 10,
                        'UVXY': 25, 'SVXY': 50, 'GME': 25, 'AMC': 5,
                        'TSLA': 250, 'NVDA': 850, 'default': 100
                    }
                    quotes[symbol] = base_prices.get(symbol, base_prices['default'])
        
        return quotes
    
    async def find_spread_opportunities(self) -> List[Dict]:
        """Find spread opportunities aggressively"""
        opportunities = []
        
        # Get all quotes
        all_symbols = list(self.symbols.keys())
        quotes = await self.get_quotes(all_symbols)
        
        # 1. SYNTHETIC STRADDLE - Long volatility
        if 'UVXY' in quotes and 'TSLA' in quotes:
            uvxy_contracts = int(5000 / quotes['UVXY'])
            tsla_hedge = int(2000 / quotes['TSLA'])
            
            opportunities.append({)
                'type': 'SYNTHETIC_STRADDLE',
                'legs': []
                    {'symbol': 'UVXY', 'side': 'BUY', 'qty': uvxy_contracts, 'price': quotes['UVXY']},
                    {'symbol': 'TSLA', 'side': 'BUY', 'qty': tsla_hedge, 'price': quotes['TSLA']}
                ],
                'strategy': 'Long volatility play',
                'confidence': random.uniform(0.7, 0.9),
                'expected_profit': random.uniform(100, 500)
            })
        
        # 2. LEVERAGED SPREAD - Direction bet
        if 'TQQQ' in quotes and 'SQQQ' in quotes:
            # Momentum-based direction
            direction = random.choice(['BULLISH', 'BEARISH'])
            
            if direction == 'BULLISH':
                long_qty = int(10000 / quotes['TQQQ'])
                short_qty = int(3000 / quotes['SQQQ'])
                
                opportunities.append({)
                    'type': 'LEVERAGED_SPREAD',
                    'legs': []
                        {'symbol': 'TQQQ', 'side': 'BUY', 'qty': long_qty, 'price': quotes['TQQQ']},
                        {'symbol': 'SQQQ', 'side': 'SELL', 'qty': short_qty, 'price': quotes['SQQQ']}
                    ],
                    'strategy': 'Bullish leveraged bet',
                    'confidence': random.uniform(0.75, 0.95),
                    'expected_profit': random.uniform(200, 800)
                })
            else:
                long_qty = int(10000 / quotes['SQQQ'])
                short_qty = int(3000 / quotes['TQQQ'])
                
                opportunities.append({)
                    'type': 'LEVERAGED_SPREAD',
                    'legs': []
                        {'symbol': 'SQQQ', 'side': 'BUY', 'qty': long_qty, 'price': quotes['SQQQ']},
                        {'symbol': 'TQQQ', 'side': 'SELL', 'qty': short_qty, 'price': quotes['TQQQ']}
                    ],
                    'strategy': 'Bearish leveraged bet',
                    'confidence': random.uniform(0.75, 0.95),
                    'expected_profit': random.uniform(200, 800)
                })
        
        # 3. VOLATILITY ARBITRAGE
        if 'UVXY' in quotes and 'SVXY' in quotes:
            # Vol mean reversion trade
            uvxy_qty = int(5000 / quotes['UVXY'])
            svxy_qty = int(5000 / quotes['SVXY'])
            
            opportunities.append({)
                'type': 'VOLATILITY_ARB',
                'legs': []
                    {'symbol': 'UVXY', 'side': 'SELL', 'qty': uvxy_qty, 'price': quotes['UVXY']},
                    {'symbol': 'SVXY', 'side': 'BUY', 'qty': svxy_qty, 'price': quotes['SVXY']}
                ],
                'strategy': 'Vol mean reversion',
                'confidence': random.uniform(0.8, 0.95),
                'expected_profit': random.uniform(150, 600)
            })
        
        # 4. SECTOR ROTATION
        if 'LABU' in quotes and 'LABD' in quotes:
            # Biotech momentum
            if random.random() > 0.5:
                opportunities.append({)
                    'type': 'SECTOR_ROTATION',
                    'legs': []
                        {'symbol': 'LABU', 'side': 'BUY', 'qty': int(7000 / quotes['LABU']), 'price': quotes['LABU']},
                        {'symbol': 'LABD', 'side': 'SELL', 'qty': int(3000 / quotes['LABD']), 'price': quotes['LABD']}
                    ],
                    'strategy': 'Biotech bull spread',
                    'confidence': random.uniform(0.7, 0.85),
                    'expected_profit': random.uniform(100, 400)
                })
        
        # 5. MEME PAIRS TRADE
        if 'GME' in quotes and 'AMC' in quotes:
            # Relative value
            gme_qty = int(3000 / quotes['GME'])
            amc_qty = int(3000 / quotes['AMC'])
            
            opportunities.append({)
                'type': 'MEME_PAIRS',
                'legs': []
                    {'symbol': 'GME', 'side': 'BUY', 'qty': gme_qty, 'price': quotes['GME']},
                    {'symbol': 'AMC', 'side': 'SELL', 'qty': amc_qty, 'price': quotes['AMC']}
                ],
                'strategy': 'Meme relative value',
                'confidence': random.uniform(0.65, 0.80),
                'expected_profit': random.uniform(50, 300)
            })
        
        # 6. TECH SPREAD
        if 'FNGU' in quotes and 'SOXL' in quotes:
            opportunities.append({)
                'type': 'TECH_SPREAD',
                'legs': []
                    {'symbol': 'FNGU', 'side': 'BUY', 'qty': int(5000 / quotes['FNGU']), 'price': quotes['FNGU']},
                    {'symbol': 'SOXL', 'side': 'SELL', 'qty': int(5000 / quotes['SOXL']), 'price': quotes['SOXL']}
                ],
                'strategy': 'Tech sector spread',
                'confidence': random.uniform(0.7, 0.85),
                'expected_profit': random.uniform(100, 500)
            })
        
        # Sort by expected profit
        opportunities.sort(key=lambda x: x['expected_profit'], reverse=True)
        
        return opportunities
    
    async def execute_spread(self, spread: Dict) -> bool:
        """Execute spread trade aggressively"""
        try:
            spread_id = f"{spread['type']}_{int(time.time())}"
            logger.info(f"\n🔥 EXECUTING {spread['type']}")
            logger.info(f"   Strategy: {spread['strategy']}")
            logger.info(f"   Confidence: {spread['confidence']:.1%}")
            logger.info(f"   Expected Profit: ${spread['expected_profit']:.2f}")
            
            # Execute each leg
            executed_legs = []
            
            for leg in spread['legs']:
                try:
                    # Use market orders for speed
                    order_data = MarketOrderRequest()
                        symbol=leg['symbol'],
                        qty=leg['qty'],
                        side=OrderSide.BUY if leg['side'] == 'BUY' else OrderSide.SELL,
                        time_in_force=TimeInForce.DAY
                    )
                    
                    order = self.trading_client.submit_order(order_data)
                    executed_legs.append({)
                        'symbol': leg['symbol'],
                        'side': leg['side'],
                        'qty': leg['qty'],
                        'order_id': order.id
                    })
                    
                    logger.info(f"   ✅ {leg['side']} {leg['qty']} {leg['symbol']} @ ~${leg['price']:.2f}")
                    
                    await asyncio.sleep(0.1)
                    
                except Exception as e:
                    logger.error(f"   ❌ Failed to execute {leg['symbol']}: {str(e)[:50]}")
            
            if executed_legs:
                self.active_spreads[spread_id] = {}
                    'type': spread['type'],
                    'legs': executed_legs,
                    'entry_time': datetime.now(),
                    'expected_profit': spread['expected_profit']
                }
                self.total_trades += 1
                
                logger.info(f"   🎯 Spread {spread_id} executed successfully!")
                return True
                
        except Exception as e:
            logger.error(f"Spread execution error: {str(e)[:100]}")
            
        return False
    
    async def monitor_and_close(self):
        """Monitor positions and close profitably"""
        try:
            positions = self.trading_client.get_all_positions()
            
            for pos in positions:
                symbol = pos.symbol
                current_price = float(pos.current_price)
                avg_price = float(pos.avg_entry_price)
                quantity = abs(int(pos.qty))
                side = pos.side
                unrealized_pnl = float(pos.unrealized_pl)
                
                # Calculate P&L percentage
                if avg_price > 0:
                    if side == 'long':
                        pnl_pct = (current_price - avg_price) / avg_price
                    else:
                        pnl_pct = (avg_price - current_price) / avg_price
                else:
                    pnl_pct = 0
                
                # Aggressive exit conditions
                should_close = False
                reason = ""
                
                # Quick profit taking
                if pnl_pct > 0.01:  # 1% profit
                    should_close = True
                    reason = f"QUICK PROFIT: {pnl_pct:.2%}"
                # Tight stop loss
                elif pnl_pct < -0.005:  # 0.5% loss
                    should_close = True
                    reason = f"STOP LOSS: {pnl_pct:.2%}"
                # Time-based exit (hold max 5 minutes)
                elif symbol in ['UVXY', 'SQQQ', 'SPXS', 'LABD', 'SOXS']:
                    # These decay quickly, exit faster
                    if random.random() > 0.7:
                        should_close = True
                        reason = "DECAY EXIT"
                
                if should_close:
                    try:
                        # Close position
                        if side == 'long':
                            close_side = OrderSide.SELL
                        else:
                            close_side = OrderSide.BUY
                        
                        close_order = MarketOrderRequest()
                            symbol=symbol,
                            qty=quantity,
                            side=close_side,
                            time_in_force=TimeInForce.DAY
                        )
                        
                        self.trading_client.submit_order(close_order)
                        
                        if unrealized_pnl > 0:
                            logger.info(f"💚 CLOSED {symbol}: +${unrealized_pnl:.2f} - {reason}")
                        else:
                            logger.info(f"💔 CLOSED {symbol}: ${unrealized_pnl:.2f} - {reason}")
                            
                    except Exception as e:
                        logger.error(f"Close error {symbol}: {str(e)[:50]}")
                        
        except Exception as e:
            logger.error(f"Monitor error: {str(e)[:50]}")
    
    async def run_aggressive_options_trading(self, duration_minutes: int = 2):
        """Run aggressive options-like trading"""
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🔥🔥🔥 AGGRESSIVE OPTIONS EXECUTOR - MAXIMUM SPEED 🔥🔥🔥")
        logger.info(f"{'='*100}")
        logger.info(f"⏰ Duration: {duration_minutes} minutes")
        logger.info(f"📊 Instruments: {len(self.symbols)}")
        logger.info(f"💰 Initial Capital: ${self.initial_capital:,.2f}")
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        cycle = 0
        
        while datetime.now() < end_time:
            cycle += 1
            cycle_start = time.time()
            
            logger.info(f"\n{'='*80}")
            logger.info(f"🔥 AGGRESSIVE CYCLE {cycle}")
            logger.info(f"{'='*80}")
            
            # Monitor and close positions first
            await self.monitor_and_close()
            
            # Find spread opportunities
            opportunities = await self.find_spread_opportunities()
            
            # Execute top opportunities
            trades_executed = 0
            max_trades_per_cycle = 3
            
            for opp in opportunities[:max_trades_per_cycle]:
                if await self.execute_spread(opp):
                    trades_executed += 1
                    await asyncio.sleep(0.5)
            
            # Force additional trades if needed
            if trades_executed < 2:
                logger.info("⚡ Forcing additional trades...")
                # Create synthetic opportunity
                symbols = list(self.symbols.keys())
                random.shuffle(symbols)
                
                forced_spread = {}
                    'type': 'FORCED_VOLATILITY',
                    'legs': []
                        {'symbol': symbols[0], 'side': 'BUY', 'qty': int(5000 / 100), 'price': 100},
                        {'symbol': symbols[1], 'side': 'SELL', 'qty': int(5000 / 100), 'price': 100}
                    ],
                    'strategy': 'Forced volatility capture',
                    'confidence': 0.65,
                    'expected_profit': 100
                }
                
                await self.execute_spread(forced_spread)
            
            # Get account status
            account = self.trading_client.get_account()
            equity = float(account.equity)
            total_pnl = equity - self.initial_capital
            
            # Cycle summary
            cycle_time = time.time() - cycle_start
            
            logger.info(f"\n📊 CYCLE {cycle} SUMMARY:")
            logger.info(f"   🔍 Opportunities Found: {len(opportunities)}")
            logger.info(f"   ⚡ Trades Executed: {trades_executed}")
            logger.info(f"   📈 Active Spreads: {len(self.active_spreads)}")
            logger.info(f"   💰 Account Equity: ${equity:,.2f}")
            logger.info(f"   📊 Total P&L: ${total_pnl:+,.2f} ({total_pnl/self.initial_capital*100:+.1f}%)")
            logger.info(f"   🔥 Total Trades: {self.total_trades}")
            logger.info(f"   ⏱️ Cycle Time: {cycle_time:.1f}s")
            
            # Short wait
            await asyncio.sleep(max(1, 5 - cycle_time))
        
        # Final summary
        await self.display_final_summary()
    
    async def display_final_summary(self):
        """Display final summary"""
        
        logger.info("\n🔒 Closing all positions...")
        
        # Close everything
        positions = self.trading_client.get_all_positions()
        for pos in positions:
            try:
                symbol = pos.symbol
                quantity = abs(int(pos.qty))
                side = OrderSide.SELL if pos.side == 'long' else OrderSide.BUY
                
                close_order = MarketOrderRequest()
                    symbol=symbol,
                    qty=quantity,
                    side=side,
                    time_in_force=TimeInForce.DAY
                )
                
                self.trading_client.submit_order(close_order)
                logger.info(f"   Closed {symbol}")
                await asyncio.sleep(0.1)
            except Exception:
                pass
        
        await asyncio.sleep(3)
        
        # Final stats
        account = self.trading_client.get_account()
        final_equity = float(account.equity)
        total_pnl = final_equity - self.initial_capital
        total_return = (total_pnl / self.initial_capital) * 100
        
        logger.info(f"\n{'='*100}")
        logger.info(f"🏁 AGGRESSIVE OPTIONS TRADING COMPLETE")
        logger.info(f"{'='*100}")
        
        logger.info(f"\n💰 FINANCIAL SUMMARY:")
        logger.info(f"   Initial Equity: ${self.initial_capital:,.2f}")
        logger.info(f"   Final Equity: ${final_equity:,.2f}")
        logger.info(f"   Total P&L: ${total_pnl:+,.2f}")
        logger.info(f"   Total Return: {total_return:+.2f}%")
        
        logger.info(f"\n📊 TRADING STATISTICS:")
        logger.info(f"   Total Spreads Executed: {self.total_trades}")
        logger.info(f"   Spread Types Traded: {len(set(s['type'] for s in self.active_spreads.values()))}")
        
        # Save results
        results = {}
            'initial_equity': self.initial_capital,
            'final_equity': final_equity,
            'total_pnl': total_pnl,
            'total_return': total_return,
            'total_trades': self.total_trades,
            'spreads': list(self.active_spreads.values())
        }
        
        with open('aggressive_options_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"\n📁 Results saved to aggressive_options_results.json")
        logger.info(f"\n🔥🔥🔥 AGGRESSIVE OPTIONS TRADING COMPLETE! 🔥🔥🔥")

async def main():
    """Main function"""
    trader = AggressiveOptionsExecutor()
    await trader.run_aggressive_options_trading(duration_minutes=2)

if __name__ == "__main__":
    asyncio.run(main())