#!/usr/bin/env python3
"""
Run TLT covered call backtest using comprehensive system
Focus on IV prediction algorithms for covered calls
"""

import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from scipy import stats

# Import from existing infrastructure
from comprehensive_backtest_system import ComprehensiveBacktester

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('TLT_Backtest')

class TLTCoveredCallBacktester(ComprehensiveBacktester):
    """Extended backtester for TLT covered calls with IV algorithms"""
    
    def __init__(self):
        # Last 6 months
        end_date = datetime.now()
        start_date = end_date - timedelta(days=180)
        
        super().__init__(
            start_date=start_date.strftime("%Y-%m-%d"),
            end_date=end_date.strftime("%Y-%m-%d")
        )
        
        # Only test TLT
        self.test_symbols = ['TLT']
        
        # Override algorithms with IV-specific ones for covered calls
        self.algorithms = [
            "Local_Peak_IV",
            "Regional_Peak_IV",
            "Strike_IV_Anomaly",
            "Expiry_IV_Anomaly",
            "IV_Term_Structure",
            "IV_Smile_Anomaly",
            "IV_Mean_Reversion",
            "IV_Momentum",
            "IV_Percentile_75",
            "Combined_IV_Signal",
            "Covered_Call_Traditional"  # Baseline
        ]
    
    def _generate_algorithm_signal(self, algorithm, data):
        """Override to generate IV-based signals for covered calls"""
        try:
            current = data.iloc[-1]
            
            # Add IV metrics to data if not present
            if 'IV_Proxy' not in data.columns:
                data = self._calculate_iv_metrics(data)
                current = data.iloc[-1]
            
            # For covered calls, we want to SELL when signal is high
            if algorithm == "Local_Peak_IV":
                if 'IV_Local_Peak' in current:
                    return 0.9 if current['IV_Local_Peak'] else 0.1
                    
            elif algorithm == "Regional_Peak_IV":
                if 'IV_Regional_Peak' in current:
                    return 0.85 if current['IV_Regional_Peak'] else 0.15
                    
            elif algorithm == "Strike_IV_Anomaly":
                if 'Strike_IV_Skew' in current:
                    return 0.8 if abs(current['Strike_IV_Skew']) > 0.04 else 0.2
                    
            elif algorithm == "Expiry_IV_Anomaly":
                if 'Term_Structure_Slope' in current:
                    return 0.8 if current['Term_Structure_Slope'] < -0.02 else 0.3
                    
            elif algorithm == "IV_Term_Structure":
                if 'HV_10' in current and 'HV_30' in current:
                    if not pd.isna(current['HV_10']) and not pd.isna(current['HV_30']) and current['HV_30'] > 0:
                        return 0.8 if current['HV_10'] > current['HV_30'] * 1.2 else 0.2
                        
            elif algorithm == "IV_Smile_Anomaly":
                if 'IV_Proxy' in current:
                    rolling_mean = data['IV_Proxy'].rolling(20).mean().iloc[-1]
                    if not pd.isna(current['IV_Proxy']) and not pd.isna(rolling_mean):
                        return 0.8 if current['IV_Proxy'] > rolling_mean * 1.15 else 0.3
                        
            elif algorithm == "IV_Mean_Reversion":
                if 'IV_Z_Score' in current:
                    return 0.9 if current['IV_Z_Score'] > 2.0 else 0.1
                    
            elif algorithm == "IV_Momentum":
                if 'IV_Momentum' in current:
                    return 0.8 if current['IV_Momentum'] > 0.15 else 0.2
                    
            elif algorithm == "IV_Percentile_75":
                if 'IV_Percentile' in current:
                    return 0.9 if current['IV_Percentile'] >= 75 else 0.1
                    
            elif algorithm == "Combined_IV_Signal":
                signals = 0
                if 'IV_Percentile' in current and current['IV_Percentile'] >= 70:
                    signals += 1
                if 'IV_Z_Score' in current and current['IV_Z_Score'] > 1.5:
                    signals += 1
                if 'IV_Momentum' in current and current['IV_Momentum'] > 0.05:
                    signals += 1
                return 0.85 if signals >= 2 else 0.15
                
            elif algorithm == "Covered_Call_Traditional":
                # Traditional approach - sell when price is above SMA
                if 'SMA_20' in current and not pd.isna(current['SMA_20']):
                    return 0.7 if current['Close'] > current['SMA_20'] else 0.3
                    
            # Default to parent implementation
            return super()._generate_algorithm_signal(algorithm, data)
            
        except Exception as e:
            logger.debug(f"Error in {algorithm}: {e}")
            return 0.5

async def main():
    """Run TLT covered call backtest"""
    logger.info("="*80)
    logger.info("TLT COVERED CALL BACKTEST - IV ALGORITHM COMPARISON")
    logger.info("="*80)
    
    # Create custom backtester
    backtester = TLTCoveredCallBacktester()
    
    # Run algorithm backtests
    results = await backtester.backtest_algorithms()
    
    # Display results
    if results:
        logger.info("\n" + "="*80)
        logger.info("ALGORITHM PERFORMANCE SUMMARY")
        logger.info("="*80)
        
        # Sort by average return
        sorted_algos = sorted(results.items(), 
                            key=lambda x: x[1].get('avg_return', 0), 
                            reverse=True)
        
        logger.info(f"\n{'Algorithm':<25} {'Avg Return':<12} {'Win Rate':<10} {'Sharpe':<10} {'Consistency':<12}")
        logger.info("-"*80)
        
        for algo, metrics in sorted_algos:
            logger.info(
                f"{algo:<25} "
                f"{metrics.get('avg_return', 0)*100:>10.2f}% "
                f"{metrics.get('avg_win_rate', 0)*100:>8.1f}% "
                f"{metrics.get('avg_sharpe', 0):>9.2f} "
                f"{metrics.get('consistency', 0):>11.3f}"
            )
    
    # Run option spread backtests focused on covered calls
    logger.info("\nRunning covered call spread analysis...")
    spread_results = await backtester.backtest_option_spreads()
    
    # Find covered call results
    if 'Covered_Call' in spread_results:
        cc_result = spread_results['Covered_Call']
        logger.info("\n" + "="*80)
        logger.info("COVERED CALL SPREAD PERFORMANCE")
        logger.info("="*80)
        logger.info(f"Average Return: {cc_result['avg_return']*100:.2f}%")
        logger.info(f"Win Rate: {cc_result['win_rate']*100:.1f}%")
        logger.info(f"Average Profit: ${cc_result['avg_profit']:.2f}")
        logger.info(f"Symbols Tested: {cc_result['symbols_tested']}")
    
    return {
        'algorithm_results': results,
        'spread_results': spread_results
    }

if __name__ == "__main__":
    asyncio.run(main())