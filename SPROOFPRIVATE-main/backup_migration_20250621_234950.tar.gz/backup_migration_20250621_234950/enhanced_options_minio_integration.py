#!/usr/bin/env python3
"""
Enhanced Options Trading Integration with MinIO
==============================================
Integrates MinIO options data to enhance options trading strategies
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple
import json
from pathlib import Path
from dotenv import load_dotenv

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# JSON serialization helper
class NumpyJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer, np.int64):)
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64):)
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)

# Load environment variables
load_dotenv()

class EnhancedOptionsMinIOIntegration:
    """Enhanced options trading integration with MinIO data"""
    
    def __init__(self):
        self.mc_path = "./mc"
        self.alias = "uschristmas"
        self.bucket = os.getenv('MINIO_BUCKET', 'stockdb')
        self.cache_dir = "./minio_cache"
        self.enhanced_dir = "./enhanced_algorithms"
        
        # Create directories
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(self.enhanced_dir, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
    def load_options_data(self) -> pd.DataFrame:
        """Load options data from MinIO cache"""
        options_file = os.path.join(self.cache_dir, "options_sample.csv")
        
        if not os.path.exists(options_file):
            self.logger.error("Options data not found. Please download first.")
            return pd.DataFrame()
            
        # Load data
        df = pd.read_csv(options_file)
        
        # Parse dates
        df['expiration'] = pd.to_datetime(df['expiration'])
        df['quote_date'] = pd.to_datetime(df['quote_date'])
        
        # Calculate derived fields
        df['days_to_expiry'] = (df['expiration'] - df['quote_date']).dt.days
        df['bid_ask_spread'] = df['ask'] - df['bid']
        df['mid_price'] = (df['bid'] + df['ask']) / 2
        df['moneyness'] = df['strike'] / df['underlying'].map(self._get_underlying_prices(df)
        
        self.logger.info(f"Loaded {len(df)} options contracts")
        
        return df
    
    def _get_underlying_prices(self, options_df: pd.DataFrame) -> Dict[str, float]:
        """Estimate underlying prices from options data"""
        # For now, estimate from ATM options
        underlying_prices = {}
        
        for underlying in options_df['underlying'].unique():
            underlying_data = options_df[options_df['underlying'] == underlying]
            
            # Find ATM calls
            atm_calls = underlying_data[underlying_data['type'] == 'call'].copy()
            if not atm_calls.empty:
                # Estimate price from deep ITM calls
                deep_itm = atm_calls[atm_calls['strike'] < atm_calls['strike'].min() * 1.5]
                if not deep_itm.empty:
                    # Intrinsic value approximation
                    price_estimate = deep_itm['mid_price'].max() + deep_itm['strike'].min()
                    underlying_prices[underlying] = price_estimate / 2  # Rough estimate
                else:
                    underlying_prices[underlying] = atm_calls['strike'].median()
            else:
                underlying_prices[underlying] = 100  # Default
                
        return underlying_prices
    
    def enhance_options_strategies(self) -> Dict[str, any]:
        """Enhance options trading strategies with MinIO data"""
        self.logger.info("Enhancing options strategies with MinIO data")
        
        # Load options data
        df = self.load_options_data()
        
        if df.empty:
            return {}
            
        # Analyze options market
        strategies = {}
            'covered_calls': self._analyze_covered_call_opportunities(df),
            'cash_secured_puts': self._analyze_put_selling_opportunities(df),
            'vertical_spreads': self._analyze_vertical_spreads(df),
            'iron_condors': self._analyze_iron_condors(df),
            'calendar_spreads': self._analyze_calendar_spreads(df),
            'straddles_strangles': self._analyze_volatility_plays(df)
        }
        
        # Market analysis
        market_analysis = self._analyze_options_market(df)
        
        enhanced_config = {}
            'strategies': strategies,
            'market_analysis': market_analysis,
            'timestamp': datetime.now().isoformat()
        }
        
        # Save configuration
        with open(os.path.join(self.enhanced_dir, "enhanced_options_config.json"), "w") as f:
            json.dump(enhanced_config, f, indent=2, cls=NumpyJSONEncoder)
            
        return enhanced_config
    
    def _analyze_covered_call_opportunities(self, df: pd.DataFrame) -> Dict:
        """Analyze covered call opportunities"""
        # Filter for calls with good liquidity
        calls = df[(df['type'] == 'call') &]
                  (df['volume'] > 10) & 
                  (df['open_interest'] > 50) &
                  (df['days_to_expiry'] <= 45)]
        
        opportunities = []
        
        for underlying in calls['underlying'].unique():
            underlying_calls = calls[calls['underlying'] == underlying]
            
            # Find OTM calls with good premium
            otm_calls = underlying_calls[underlying_calls['moneyness'] > 1.02]
            
            for _, option in otm_calls.iterrows():
                premium_yield = option['bid'] / option['strike']
                
                if premium_yield > 0.01:  # 1% yield threshold
                    opportunities.append({)
                        'underlying': option['underlying'],
                        'strike': float(option['strike']),
                        'expiration': option['expiration'].strftime('%Y-%m-%d'),
                        'premium': float(option['bid']),
                        'yield': float(premium_yield),
                        'days_to_expiry': int(option['days_to_expiry']),
                        'volume': int(option['volume']),
                        'open_interest': int(option['open_interest'])
                    })
                    
        # Sort by yield
        opportunities = sorted(opportunities, key=lambda x: x['yield'], reverse=True)[:20]
        
        return {}
            'opportunities': opportunities,
            'avg_yield': np.mean([o['yield'] for o in opportunities]) if opportunities else 0,
            'count': len(opportunities)
        }
    
    def _analyze_put_selling_opportunities(self, df: pd.DataFrame) -> Dict:
        """Analyze cash-secured put opportunities"""
        # Filter for puts with good liquidity
        puts = df[(df['type'] == 'put') &]
                 (df['volume'] > 10) & 
                 (df['open_interest'] > 50) &
                 (df['days_to_expiry'] <= 45)]
        
        opportunities = []
        
        for underlying in puts['underlying'].unique():
            underlying_puts = puts[puts['underlying'] == underlying]
            
            # Find OTM puts with good premium
            otm_puts = underlying_puts[underlying_puts['moneyness'] < 0.98]
            
            for _, option in otm_puts.iterrows():
                premium_yield = option['bid'] / option['strike']
                
                if premium_yield > 0.01:  # 1% yield threshold
                    opportunities.append({)
                        'underlying': option['underlying'],
                        'strike': float(option['strike']),
                        'expiration': option['expiration'].strftime('%Y-%m-%d'),
                        'premium': float(option['bid']),
                        'yield': float(premium_yield),
                        'days_to_expiry': int(option['days_to_expiry']),
                        'volume': int(option['volume']),
                        'open_interest': int(option['open_interest'])
                    })
                    
        # Sort by yield
        opportunities = sorted(opportunities, key=lambda x: x['yield'], reverse=True)[:20]
        
        return {}
            'opportunities': opportunities,
            'avg_yield': np.mean([o['yield'] for o in opportunities]) if opportunities else 0,
            'count': len(opportunities)
        }
    
    def _analyze_vertical_spreads(self, df: pd.DataFrame) -> Dict:
        """Analyze vertical spread opportunities"""
        spreads = []
        
        # Group by underlying and expiration
        for (underlying, expiration), group in df.groupby(['underlying', 'expiration']):
            calls = group[group['type'] == 'call'].sort_values('strike')
            puts = group[group['type'] == 'put'].sort_values('strike')
            
            # Bull call spreads
            if len(calls) >= 2:
                for i in range(len(calls) - 1):
                    lower = calls.iloc[i]
                    upper = calls.iloc[i + 1]
                    
                    if lower['ask'] > 0 and upper['bid'] > 0:
                        spread_cost = lower['ask'] - upper['bid']
                        max_profit = upper['strike'] - lower['strike'] - spread_cost
                        
                        if max_profit > 0 and spread_cost > 0:
                            spreads.append({)
                                'type': 'bull_call_spread',
                                'underlying': underlying,
                                'expiration': expiration.strftime('%Y-%m-%d'),
                                'long_strike': lower['strike'],
                                'short_strike': upper['strike'],
                                'cost': spread_cost,
                                'max_profit': max_profit,
                                'risk_reward': max_profit / spread_cost if spread_cost > 0 else 0
                            })
            
            # Bear put spreads
            if len(puts) >= 2:
                for i in range(len(puts) - 1):
                    upper = puts.iloc[i + 1]
                    lower = puts.iloc[i]
                    
                    if upper['ask'] > 0 and lower['bid'] > 0:
                        spread_cost = upper['ask'] - lower['bid']
                        max_profit = upper['strike'] - lower['strike'] - spread_cost
                        
                        if max_profit > 0 and spread_cost > 0:
                            spreads.append({)
                                'type': 'bear_put_spread',
                                'underlying': underlying,
                                'expiration': expiration.strftime('%Y-%m-%d'),
                                'long_strike': upper['strike'],
                                'short_strike': lower['strike'],
                                'cost': spread_cost,
                                'max_profit': max_profit,
                                'risk_reward': max_profit / spread_cost if spread_cost > 0 else 0
                            })
        
        # Sort by risk/reward ratio
        spreads = sorted(spreads, key=lambda x: x['risk_reward'], reverse=True)[:20]
        
        return {}
            'spreads': spreads,
            'avg_risk_reward': np.mean([s['risk_reward'] for s in spreads]) if spreads else 0,
            'count': len(spreads)
        }
    
    def _analyze_iron_condors(self, df: pd.DataFrame) -> Dict:
        """Analyze iron condor opportunities"""
        condors = []
        
        # Group by underlying and expiration
        for (underlying, expiration), group in df.groupby(['underlying', 'expiration']):
            calls = group[group['type'] == 'call'].sort_values('strike')
            puts = group[group['type'] == 'put'].sort_values('strike')
            
            if len(calls) >= 2 and len(puts) >= 2:
                # Find potential iron condor setup
                # Sell OTM call and put, buy further OTM call and put
                
                # Get ATM estimate
                atm_estimate = calls['strike'].median()
                
                # Find strikes
                otm_puts = puts[puts['strike'] < atm_estimate * 0.95]
                otm_calls = calls[calls['strike'] > atm_estimate * 1.05]
                
                if len(otm_puts) >= 2 and len(otm_calls) >= 2:
                    # Put spread
                    short_put = otm_puts.iloc[-1]  # Highest OTM put
                    long_put = otm_puts.iloc[-2]   # Next lower put
                    
                    # Call spread
                    short_call = otm_calls.iloc[0]  # Lowest OTM call
                    long_call = otm_calls.iloc[1]   # Next higher call
                    
                    # Calculate credit
                    put_credit = short_put['bid'] - long_put['ask']
                    call_credit = short_call['bid'] - long_call['ask']
                    total_credit = put_credit + call_credit
                    
                    if total_credit > 0:
                        width = min(short_put['strike'] - long_put['strike'],
                                  long_call['strike'] - short_call['strike'])
                        max_loss = width - total_credit
                        
                        condors.append({)
                            'underlying': underlying,
                            'expiration': expiration.strftime('%Y-%m-%d'),
                            'put_strikes': [long_put['strike'], short_put['strike']],
                            'call_strikes': [short_call['strike'], long_call['strike']],
                            'credit': total_credit,
                            'max_loss': max_loss,
                            'risk_reward': total_credit / max_loss if max_loss > 0 else 0,
                            'days_to_expiry': group.iloc[0]['days_to_expiry']
                        })
        
        # Sort by risk/reward
        condors = sorted(condors, key=lambda x: x['risk_reward'], reverse=True)[:10]
        
        return {}
            'condors': condors,
            'avg_risk_reward': np.mean([c['risk_reward'] for c in condors]) if condors else 0,
            'count': len(condors)
        }
    
    def _analyze_calendar_spreads(self, df: pd.DataFrame) -> Dict:
        """Analyze calendar spread opportunities"""
        calendars = []
        
        # Group by underlying
        for underlying, group in df.groupby('underlying'):
            # Get unique expiration dates
            expirations = sorted(group['expiration'].unique()
            
            if len(expirations) >= 2:
                # Compare near-term with next expiration
                near_exp = expirations[0]
                far_exp = expirations[1]
                
                near_options = group[group['expiration'] == near_exp]
                far_options = group[group['expiration'] == far_exp]
                
                # Find matching strikes
                common_strikes = set(near_options['strike']) & set(far_options['strike'])
                
                for strike in common_strikes:
                    near_call = near_options[(near_options['strike'] == strike) &]
                                           (near_options['type'] == 'call')]
                    far_call = far_options[(far_options['strike'] == strike) &]
                                         (far_options['type'] == 'call')]
                    
                    if not near_call.empty and not far_call.empty:
                        near_call = near_call.iloc[0]
                        far_call = far_call.iloc[0]
                        
                        # Calendar spread: buy far, sell near
                        spread_cost = far_call['ask'] - near_call['bid']
                        
                        if spread_cost > 0:
                            calendars.append({)
                                'underlying': underlying,
                                'strike': strike,
                                'near_expiration': near_exp.strftime('%Y-%m-%d'),
                                'far_expiration': far_exp.strftime('%Y-%m-%d'),
                                'near_bid': near_call['bid'],
                                'far_ask': far_call['ask'],
                                'spread_cost': spread_cost,
                                'days_difference': (far_exp - near_exp).days
                            })
        
        # Sort by cost efficiency
        calendars = sorted(calendars, key=lambda x: x['spread_cost'])[:15]
        
        return {}
            'calendars': calendars,
            'avg_cost': np.mean([c['spread_cost'] for c in calendars]) if calendars else 0,
            'count': len(calendars)
        }
    
    def _analyze_volatility_plays(self, df: pd.DataFrame) -> Dict:
        """Analyze straddle and strangle opportunities"""
        volatility_plays = []
        
        # Group by underlying and expiration
        for (underlying, expiration), group in df.groupby(['underlying', 'expiration']):
            calls = group[group['type'] == 'call']
            puts = group[group['type'] == 'put']
            
            # Find ATM options for straddles
            atm_strike = calls['strike'].median()
            
            atm_call = calls[calls['strike'] == atm_strike]
            atm_put = puts[puts['strike'] == atm_strike]
            
            if not atm_call.empty and not atm_put.empty:
                atm_call = atm_call.iloc[0]
                atm_put = atm_put.iloc[0]
                
                # Straddle cost
                straddle_cost = atm_call['ask'] + atm_put['ask']
                
                if straddle_cost > 0:
                    volatility_plays.append({)
                        'type': 'straddle',
                        'underlying': underlying,
                        'expiration': expiration.strftime('%Y-%m-%d'),
                        'strike': atm_strike,
                        'cost': straddle_cost,
                        'breakeven_up': atm_strike + straddle_cost,
                        'breakeven_down': atm_strike - straddle_cost,
                        'days_to_expiry': group.iloc[0]['days_to_expiry']
                    })
            
            # Find OTM options for strangles
            otm_calls = calls[calls['strike'] > atm_strike * 1.02]
            otm_puts = puts[puts['strike'] < atm_strike * 0.98]
            
            if not otm_calls.empty and not otm_puts.empty:
                # Take nearest OTM options
                otm_call = otm_calls.iloc[0]
                otm_put = otm_puts.iloc[-1]
                
                strangle_cost = otm_call['ask'] + otm_put['ask']
                
                if strangle_cost > 0:
                    volatility_plays.append({)
                        'type': 'strangle',
                        'underlying': underlying,
                        'expiration': expiration.strftime('%Y-%m-%d'),
                        'call_strike': otm_call['strike'],
                        'put_strike': otm_put['strike'],
                        'cost': strangle_cost,
                        'breakeven_up': otm_call['strike'] + strangle_cost,
                        'breakeven_down': otm_put['strike'] - strangle_cost,
                        'days_to_expiry': group.iloc[0]['days_to_expiry']
                    })
        
        # Sort by cost
        volatility_plays = sorted(volatility_plays, key=lambda x: x['cost'])[:15]
        
        return {}
            'plays': volatility_plays,
            'avg_cost': np.mean([p['cost'] for p in volatility_plays]) if volatility_plays else 0,
            'count': len(volatility_plays)
        }
    
    def _analyze_options_market(self, df: pd.DataFrame) -> Dict:
        """Analyze overall options market conditions"""
        analysis = {}
            'market_stats': {}
                'total_contracts': len(df),
                'unique_underlyings': df['underlying'].nunique(),
                'avg_bid_ask_spread': df['bid_ask_spread'].mean(),
                'total_volume': df['volume'].sum(),
                'total_open_interest': df['open_interest'].sum()
            },
            'liquidity_analysis': {}
                'high_volume_contracts': len(df[df['volume'] > 100]),
                'high_oi_contracts': len(df[df['open_interest'] > 1000]),
                'avg_volume': df['volume'].mean(),
                'avg_open_interest': df['open_interest'].mean()
            },
            'expiration_analysis': {}
                'unique_expirations': df['expiration'].nunique(),
                'avg_days_to_expiry': df['days_to_expiry'].mean(),
                'near_term_contracts': len(df[df['days_to_expiry'] <= 7]),
                'monthly_contracts': len(df[(df['days_to_expiry'] > 25) & (df['days_to_expiry'] <= 35)])
            },
            'moneyness_distribution': {}
                'itm_calls': len(df[(df['type'] == 'call') & (df['moneyness'] < 1)]),
                'otm_calls': len(df[(df['type'] == 'call') & (df['moneyness'] > 1)]),
                'itm_puts': len(df[(df['type'] == 'put') & (df['moneyness'] > 1)]),
                'otm_puts': len(df[(df['type'] == 'put') & (df['moneyness'] < 1)])
            }
        }
        
        return analysis
    
    def create_options_trading_config(self) -> Dict:
        """Create comprehensive options trading configuration"""
        self.logger.info("Creating options trading configuration...")
        
        # Load options data
        df = self.load_options_data()
        
        if df.empty:
            return {}
            
        config = {}
            'data_source': 'MinIO options data',
            'timestamp': datetime.now().isoformat(),
            'trading_rules': {}
                'min_volume': 10,
                'min_open_interest': 50,
                'max_days_to_expiry': 60,
                'min_bid_ask_ratio': 0.8,  # Bid must be at least 80% of ask
                'position_limits': {}
                    'max_contracts_per_trade': 10,
                    'max_percentage_of_oi': 0.05,  # Don't exceed 5% of open interest
                    'max_percentage_of_volume': 0.10  # Don't exceed 10% of daily volume
                }
            },
            'strategy_preferences': {}
                'covered_calls': {}
                    'enabled': True,
                    'min_yield': 0.01,  # 1% minimum
                    'max_days_to_expiry': 45,
                    'delta_range': [0.15, 0.35]
                },
                'cash_secured_puts': {}
                    'enabled': True,
                    'min_yield': 0.01,
                    'max_days_to_expiry': 45,
                    'delta_range': [-0.35, -0.15]
                },
                'spreads': {}
                    'enabled': True,
                    'min_risk_reward': 0.5,
                    'max_spread_width': 10
                },
                'iron_condors': {}
                    'enabled': True,
                    'min_credit': 0.25,
                    'delta_range': [-0.20, 0.20]
                }
            },
            'risk_management': {}
                'max_loss_per_trade': 0.02,  # 2% of capital
                'profit_target': 0.5,  # Take profit at 50% of max profit
                'stop_loss': 2.0,  # Stop at 2x expected loss
                'days_to_expiry_exit': 5  # Close positions 5 days before expiry
            },
            'scanner_filters': self._create_scanner_filters(df)
        }
        
        # Save configuration
        with open(os.path.join(self.enhanced_dir, "options_trading_config.json"), "w") as f:
            json.dump(config, f, indent=2, cls=NumpyJSONEncoder)
            
        return config
    
    def _create_scanner_filters(self, df: pd.DataFrame) -> Dict:
        """Create scanner filters based on data analysis"""
        return {}
            'high_volume': {}
                'min_volume': df['volume'].quantile(0.75),
                'min_open_interest': df['open_interest'].quantile(0.75)
            },
            'tight_spreads': {}
                'max_bid_ask_spread': df['bid_ask_spread'].quantile(0.25)
            },
            'liquid_underlyings': df.groupby('underlying')['volume'].sum().nlargest(20).index.tolist()
        }
    
    def generate_options_report(self) -> Dict:
        """Generate comprehensive options trading report"""
        self.logger.info("Generating options trading report...")
        
        # Get enhanced strategies
        strategies = self.enhance_options_strategies()
        
        # Get trading config
        config = self.create_options_trading_config()
        
        report = {}
            'report_date': datetime.now().isoformat(),
            'data_summary': {}
                'source': 'MinIO stockdb options sample',
                'date': '2022-08-24'
            },
            'strategy_opportunities': {}
                'covered_calls': {}
                    'count': strategies['strategies']['covered_calls']['count'],
                    'avg_yield': strategies['strategies']['covered_calls']['avg_yield'],
                    'top_opportunities': strategies['strategies']['covered_calls']['opportunities'][:5]
                },
                'cash_secured_puts': {}
                    'count': strategies['strategies']['cash_secured_puts']['count'],
                    'avg_yield': strategies['strategies']['cash_secured_puts']['avg_yield'],
                    'top_opportunities': strategies['strategies']['cash_secured_puts']['opportunities'][:5]
                },
                'spreads': {}
                    'count': strategies['strategies']['vertical_spreads']['count'],
                    'avg_risk_reward': strategies['strategies']['vertical_spreads']['avg_risk_reward']
                },
                'volatility_plays': {}
                    'count': strategies['strategies']['straddles_strangles']['count'],
                    'avg_cost': strategies['strategies']['straddles_strangles']['avg_cost']
                }
            },
            'market_conditions': strategies['market_analysis'],
            'recommendations': {}
                'immediate_actions': []
                    "Focus on high-volume options for better fills",
                    "Prioritize covered calls on TSLA due to high premiums",
                    "Consider put selling on high IV stocks",
                    "Monitor spread opportunities with risk/reward > 1.0"
                ],
                'strategy_allocation': {}
                    'covered_calls': 0.30,
                    'cash_secured_puts': 0.25,
                    'spreads': 0.25,
                    'iron_condors': 0.10,
                    'other': 0.10
                }
            }
        }
        
        # Save report
        with open(os.path.join(self.enhanced_dir, "options_trading_report.json"), "w") as f:
            json.dump(report, f, indent=2, cls=NumpyJSONEncoder)
            
        return report


def demonstrate_options_enhancements():
    """Demonstrate enhanced options trading with MinIO data"""
    print("🎯 Enhanced Options Trading with MinIO Data")
    print("=" * 60)
    
    # Initialize integration
    options = EnhancedOptionsMinIOIntegration()
    
    # Load and analyze options data
    print("\n📊 Loading Options Data...")
    df = options.load_options_data()
    
    if not df.empty:
        print(f"✅ Loaded {len(df)} options contracts")
        print(f"   Underlyings: {df['underlying'].nunique()}")
        print(f"   Expirations: {df['expiration'].nunique()}")
        
        # Generate strategies
        print("\n🔍 Analyzing Options Strategies...")
        strategies = options.enhance_options_strategies()
        
        # Show top opportunities
        print("\n💡 Top Opportunities:")
        
        # Covered Calls
        cc = strategies['strategies']['covered_calls']
        print(f"\n1. Covered Calls ({cc['count']} found, avg yield: {cc['avg_yield']:.2%}):")
        for i, opp in enumerate(cc['opportunities'][:3]):
            print(f"   • {opp['underlying']} ${opp['strike']} exp {opp['expiration']}: ")
                  f"{opp['yield']:.2%} yield (${opp['premium']:.2f} premium)")
            
        # Cash Secured Puts
        csp = strategies['strategies']['cash_secured_puts']
        print(f"\n2. Cash Secured Puts ({csp['count']} found, avg yield: {csp['avg_yield']:.2%}):")
        for i, opp in enumerate(csp['opportunities'][:3]):
            print(f"   • {opp['underlying']} ${opp['strike']} exp {opp['expiration']}: ")
                  f"{opp['yield']:.2%} yield (${opp['premium']:.2f} premium)")
            
        # Spreads
        spreads = strategies['strategies']['vertical_spreads']
        print(f"\n3. Vertical Spreads ({spreads['count']} found, avg R/R: {spreads['avg_risk_reward']:.2f}):")
        for i, spread in enumerate(spreads['spreads'][:3]):
            print(f"   • {spread['underlying']} {spread['type']}: ")
                  f"${spread['long_strike']}/{spread['short_strike']} "
                  f"R/R: {spread['risk_reward']:.2f}")
            
        # Market Analysis
        market = strategies['market_analysis']
        print("\n📈 Market Analysis:")
        print(f"   Total Volume: {market['market_stats']['total_volume']:,}")
        print(f"   Total OI: {market['market_stats']['total_open_interest']:,}")
        print(f"   Avg Bid-Ask Spread: ${market['market_stats']['avg_bid_ask_spread']:.2f}")
        
        # Generate report
        print("\n📋 Generating Options Trading Report...")
        report = options.generate_options_report()
        
        print("\n✅ Options Enhancement Complete!")
        print(f"   Files created in: {options.enhanced_dir}/")
        print("   • enhanced_options_config.json")
        print("   • options_trading_config.json")
        print("   • options_trading_report.json")
        
    else:
        print("❌ No options data available")
    
    return options


def integrate_options_with_system():
    """Show how to integrate options enhancements with trading system"""
    print("\n🔗 Integrating Options with Trading System")
    print("=" * 60)
    
    print("\n1. Options Strategy Integration:")
    print("   - Use covered call scanner for income generation")
    print("   - Implement put selling for entry strategies")
    print("   - Add spread trading for defined risk trades")
    
    print("\n2. Risk Management Integration:")
    print("   - Apply position sizing based on max loss")
    print("   - Monitor days to expiry for timely exits")
    print("   - Use delta limits for directional exposure")
    
    print("\n3. Portfolio Integration:")
    print("   - Allocate portion to options strategies")
    print("   - Balance directional and neutral strategies")
    print("   - Track options P&L separately")
    
    print("\n4. Execution Integration:")
    print("   - Use limit orders based on bid-ask spreads")
    print("   - Monitor volume for liquidity")
    print("   - Implement multi-leg order types")


if __name__ == "__main__":
    # Run demonstration
    options = demonstrate_options_enhancements()
    
    # Show integration
    integrate_options_with_system()
    
    print("\n🎯 Next Steps:")
    print("1. Download more options data from MinIO")
    print("2. Implement Greeks calculations")
    print("3. Add IV rank and percentile analysis")
    print("4. Create automated options scanners")
    print("5. Integrate with portfolio margin calculations")