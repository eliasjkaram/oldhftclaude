
#!/usr/bin/env python3
"""
YFinance Wrapper Integration Example
====================================

Shows how to integrate the yfinance_wrapper into existing code
with minimal changes for drop-in replacement.
"""

# Method 1: Direct replacement
# Replace: import yfinance as yf
# With:
# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import yfinance_wrapper as yf

# Method 2: Import specific functions
# from yfinance_wrapper import download, Ticker

# Method 3: Use the wrapper class directly for more control
from yfinance_wrapper import YFinanceWrapper

def example_basic_usage():
    """Basic usage with drop-in replacement"""
    print("Example 1: Basic Usage (Drop-in Replacement)")
    print("-" * 50)
    
    # This works exactly like yfinance but with error handling
    try:
        # Download historical data
        data = yf.download('AAPL', period='1mo', interval='1d')
        print(f"✅ Downloaded {len(data)} days of AAPL data")
        print(f"   Latest close: ${data['Close'].iloc[-1]:.2f}")
        
        # Get ticker object
        ticker = yf.Ticker('MSFT')
        info = ticker.info if ticker else {}
        print(f"✅ Got MSFT info: {info.get('longName', 'Unknown')}")
        
    except Exception as e:
        print(f"❌ Error: {e}")


def example_advanced_usage():
    """Advanced usage with custom configuration"""
    print("\nExample 2: Advanced Usage with Custom Config")
    print("-" * 50)
    
    # Create wrapper with custom configuration
    wrapper = YFinanceWrapper({)
        'max_retries': 5,                # More retries for unreliable connections
        'retry_delay': 2.0,               # Longer initial delay
        'backoff_factor': 3.0,            # More aggressive backoff
        'calls_per_minute': 30,           # Conservative rate limit
        'cache_duration_minutes': 30,     # Longer cache
        'timeout': 20,                    # Longer timeout
        'log_level': 'INFO'
    })
    
    # Download multiple tickers with error handling
    tickers = ['SPY', 'QQQ', 'IWM', 'DIA', 'INVALID_TICKER']
    
    for ticker in tickers:
        try:
            data = wrapper.download(ticker, period='5d', interval='1h')
            if not data.empty:
                print(f"✅ {ticker}: {len(data)} bars, ")
                      f"Latest: ${data['Close'].iloc[-1]:.2f}")
            else:
                print(f"⚠️  {ticker}: No data available")
        except Exception as e:
            print(f"❌ {ticker}: {e}")


def example_options_handling():
    """Example of options chain handling"""
    print("\nExample 3: Options Chain with Error Handling")
    print("-" * 50)
    
    wrapper = YFinanceWrapper()
    
    symbols = ['AAPL', 'SPY', 'INVALID']
    
    for symbol in symbols:
        try:
            options = wrapper.get_options(symbol)
            if options['calls'].empty and options['puts'].empty:
                print(f"⚠️  {symbol}: No options data")
            else:
                print(f"✅ {symbol}: {len(options['calls'])} calls, ")
                      f"{len(options['puts'])} puts")
        except Exception as e:
            print(f"❌ {symbol}: {e}")


def example_migration_pattern():
    """Show how to migrate existing code"""
    print("\nExample 4: Migration Pattern")
    print("-" * 50)
    
    # Original code that might fail:
    # import yfinance as yf
    # data = yf.download('AAPL', period='1d')  # Might get JSON error
    
    # Fixed code with wrapper:
    wrapper = YFinanceWrapper()
    
    # Method 1: Use wrapper methods
    data = wrapper.download('AAPL', period='1d')
    
    # Method 2: Use convenience functions
    data = yf.download('AAPL', period='1d')
    
    # Both methods now handle errors gracefully
    if not data.empty:
        print("✅ Successfully downloaded data with error handling")
    else:
        print("⚠️  No data available (handled gracefully)")


def example_batch_processing():
    """Example of batch processing with rate limiting"""
    print("\nExample 5: Batch Processing with Rate Limiting")
    print("-" * 50)
    
    wrapper = YFinanceWrapper({)
        'calls_per_minute': 20,  # Strict rate limit
        'cache_duration_minutes': 60  # Long cache for repeated requests
    })
    
    # Process many tickers
    tech_stocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'TSLA']
    
    results = {}
    for symbol in tech_stocks:
        try:
            # First call might be slow due to rate limiting
            data = wrapper.get_history(symbol, period='1mo')
            if not data.empty:
                results[symbol] = {}
                    'last_price': data['Close'].iloc[-1],
                    'change_pct': ((data['Close'].iloc[-1] / data['Close'].iloc[0]) - 1) * 100
                }
                print(f"✅ {symbol}: ${results[symbol]['last_price']:.2f} ")
                      f"({results[symbol]['change_pct']:+.1f}%)")
        except Exception as e:
            print(f"❌ {symbol}: {e}")
    
    # Second call to same symbols will use cache (fast)
    print("\n🔄 Testing cache (should be instant)...")
    start_time = time.time()
    for symbol in tech_stocks[:3]:
        data = wrapper.get_history(symbol, period='1mo')
    print(f"✅ Cached requests completed in {time.time() - start_time:.2f}s")


def example_error_recovery():
    """Example showing error recovery patterns"""
    print("\nExample 6: Error Recovery Patterns")
    print("-" * 50)
    
    wrapper = YFinanceWrapper()
    
    def get_price_with_fallback(symbol: str) -> float:
        """Get price with multiple fallback options"""
        # Try 1: Get latest price from history
        try:
            data = wrapper.get_history(symbol, period='1d', interval='1m')
            if not data.empty:
                return data['Close'].iloc[-1]
        except Exception as e:
            print(f"   History failed: {e}")
        
        # Try 2: Get from ticker info
        try:
            ticker = wrapper.get_ticker(symbol)
            if ticker and ticker.info:
                return ticker.info.get('regularMarketPrice', 0)
        except Exception as e:
            print(f"   Ticker info failed: {e}")
        
        # Try 3: Get daily data
        try:
            data = wrapper.download(symbol, period='5d')
            if not data.empty:
                return data['Close'].iloc[-1]
        except Exception as e:
            print(f"   Daily download failed: {e}")
        
        return 0.0  # Failed all attempts
    
    # Test with various symbols
    test_symbols = ['AAPL', 'INVALID_SYM', 'SPY']
    
    for symbol in test_symbols:
        print(f"\nTrying {symbol}...")
        price = get_price_with_fallback(symbol)
        if price > 0:
            print(f"✅ {symbol}: ${price:.2f}")
        else:
            print(f"❌ {symbol}: Failed to get price")


if __name__ == "__main__":
    import time
    
    print("YFinance Wrapper Integration Examples")
    print("====================================\n")
    
    # Run all examples
    example_basic_usage()
    example_advanced_usage()
    example_options_handling()
    example_migration_pattern()
    example_batch_processing()
    example_error_recovery()
    
    print("\n✅ All examples completed!")