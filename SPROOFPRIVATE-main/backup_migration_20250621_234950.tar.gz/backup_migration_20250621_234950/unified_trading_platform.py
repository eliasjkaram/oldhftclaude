
#!/usr/bin/env python3
"""
Unified Trading Platform
========================
Integrates all trading components into a single, cohesive system:
- Master Orchestrator V2 for process management
- Options trading (scanner, executor, spread strategies)
- Stock trading (live bot, comprehensive system)
- Spread execution engine
- AI/ML models (DGM, transformers, multi-agent)
- Real-time monitoring and performance tracking
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
import sys
import json
import time
import logging
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import subprocess
import signal

# Import orchestrator components
from master_orchestrator_v2 import MasterOrchestratorV2, ProcessConfig, ProcessHealth

# Configure logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('unified_platform.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class UnifiedTradingPlatform:
    """Unified platform that integrates all trading components"""
    
    def __init__(self, mode='paper', runtime_hours=24):
        self.mode = mode  # 'paper' or 'live'
        self.runtime_hours = runtime_hours
        self.orchestrator = MasterOrchestratorV2(runtime_hours=runtime_hours)
        self.configure_trading_systems()
        
    def configure_trading_systems(self):
        """Configure all trading systems with proper priorities and dependencies"""
        
        # Priority 1: Core Infrastructure & Data Collection
        infrastructure = []
            ProcessConfig()
                name="Market Data Collector",
                script="market_data_collector.py",
                priority=1,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Collects real-time market data from multiple sources"
            ),
            ProcessConfig()
                name="Cross Platform Validator",
                script="cross_platform_validator.py",
                priority=1,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Validates data across different platforms"
            ),
            ProcessConfig()
                name="Data API Fixer",
                script="data_api_fixer.py",
                priority=1,
                restart_on_failure=True,
                description="Ensures data API connectivity"
            ),
        ]
        
        # Priority 2: Analysis & Signal Generation
        analysis = []
            # AI/ML Models
            ProcessConfig()
                name="DGM Deep Learning",
                script="dgm_deep_learning_system.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Self-improving neural network trading system"
            ),
            ProcessConfig()
                name="Transformer Predictions",
                script="transformer_prediction_system.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Advanced transformer model for price predictions"
            ),
            ProcessConfig()
                name="Multi-Agent System",
                script="multi_agent_trading_system.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Multiple AI agents working in ensemble"
            ),
            ProcessConfig()
                name="Mamba Trading Model",
                script="mamba_trading_model.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="State-space model for long sequences"
            ),
            
            # Scanners
            ProcessConfig()
                name="Options Scanner",
                script="options_scanner.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Scans for profitable options opportunities"
            ),
            ProcessConfig()
                name="Arbitrage Scanner",
                script="arbitrage_scanner.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Identifies arbitrage opportunities"
            ),
            ProcessConfig()
                name="LEAPS Scanner",
                script="leaps_arbitrage_scanner.py",
                priority=2,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Long-term options arbitrage scanner"
            ),
        ]
        
        # Priority 3: Trading Execution
        trading = []
        
        if self.mode == 'paper':
            # Paper trading systems
            trading.extend([)
                ProcessConfig()
                    name="Paper Trading Bot",
                    script="simple_paper_trader.py",
                    priority=3,
                    restart_on_failure=True,
                    loop_wrapper=True,
                    description="Simple paper trading with basic strategies"
                ),
                ProcessConfig()
                    name="Enhanced Options Bot",
                    script="enhanced_options_bot.py",
                    priority=3,
                    restart_on_failure=True,
                    loop_wrapper=True,
                    description="Advanced options trading strategies"
                ),
                ProcessConfig()
                    name="Comprehensive Trading",
                    script="comprehensive_trading_system.py",
                    priority=3,
                    restart_on_failure=True,
                    loop_wrapper=True,
                    description="All-in-one trading system"
                ),
                ProcessConfig()
                    name="Options Executor",
                    script="comprehensive_options_executor.py",
                    priority=3,
                    restart_on_failure=True,
                    loop_wrapper=True,
                    description="Executes complex option spreads"
                ),
                ProcessConfig()
                    name="Spread Executor",
                    script="spread_execution_engine.py",
                    priority=3,
                    restart_on_failure=True,
                    loop_wrapper=True,
                    description="Advanced multi-leg spread execution"
                ),
            ])
        else:
            # Live trading (use with caution)
            trading.extend([)
                ProcessConfig()
                    name="Live Trading Bot",
                    script="live_trading_bot.py",
                    priority=3,
                    restart_on_failure=True,
                    loop_wrapper=True,
                    description="Production live trading system"
                ),
            ])
        
        # Priority 4: Monitoring & Optimization
        monitoring = []
            ProcessConfig()
                name="System Monitor",
                script="system_monitor.py",
                priority=4,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Monitors system health and performance"
            ),
            ProcessConfig()
                name="Performance Tracker",
                script="performance_tracker.py",
                priority=4,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Tracks trading performance metrics"
            ),
            ProcessConfig()
                name="Continuous Improvement",
                script="continuous_improvement_engine.py",
                priority=4,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Optimizes strategies based on performance"
            ),
            ProcessConfig()
                name="Strategy Enhancement",
                script="strategy_enhancement_engine.py",
                priority=4,
                restart_on_failure=True,
                loop_wrapper=True,
                description="Enhances trading strategies using AI"
            ),
        ]
        
        # Priority 5: Specialized Systems (Optional)
        specialized = []
            ProcessConfig()
                name="Production AI System",
                script="production_ai_system.py",
                priority=5,
                restart_on_failure=False,
                loop_wrapper=True,
                description="Multi-LLM powered trading system"
            ),
            ProcessConfig()
                name="GPU HFT Cluster",
                script="ultra_optimized_hft_cluster.py",
                priority=5,
                restart_on_failure=False,
                description="GPU-accelerated high-frequency trading"
            ),
        ]
        
        # Add all processes to orchestrator
        all_processes = infrastructure + analysis + trading + monitoring
        
        # Add specialized systems only if resources are available
        if self.check_gpu_available():
            all_processes.extend(specialized)
        
        for process in all_processes:
            self.orchestrator.add_process(process)
    
    def check_gpu_available(self):
        """Check if GPU is available for specialized systems"""
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False
    
    def display_startup_banner(self):
        """Display startup information"""
        print("\n" + "="*80)
        print("🚀 UNIFIED TRADING PLATFORM")
        print("="*80)
        print(f"Mode: {self.mode.upper()}")
        print(f"Runtime: {self.runtime_hours} hours")
        print(f"Processes: {len(self.orchestrator.processes)}")
        print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*80)
        
        # List all configured processes
        print("\n📋 Configured Trading Systems:")
        for priority in range(1, 6):
            processes = [p for p in self.orchestrator.processes.values() if p.priority == priority]
            if processes:
                print(f"\nPriority {priority}:")
                for proc in processes:
                    status = "🟡 Ready" if not proc.process else "🟢 Running"
                    print(f"  {status} {proc.name}")
                    print(f"       {proc.description}")
    
    def create_monitoring_dashboard(self):
        """Create a real-time monitoring dashboard"""
        dashboard_script = """
import time
import os
import sqlite3
from datetime import datetime

from universal_market_data import get_current_market_data, validate_price


def display_dashboard():
    while True:
        os.system('clear' if os.name == 'posix' else 'cls')
        
        print("="*80)
        print(f"📊 UNIFIED TRADING PLATFORM DASHBOARD - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*80)
        
        # Display process status
        try:
            conn = sqlite3.connect('orchestration_v2.db')
            cursor = conn.cursor()
            
            cursor.execute(''')
                SELECT name, status, health_score, cpu_usage, memory_usage, last_heartbeat
                FROM process_health
                ORDER BY name
            ''')
            
            processes = cursor.fetchall()
            
            print("\\n🔧 Process Status:")
            print("-"*80)
            print(f"{'Process':<30} {'Status':<10} {'Health':<10} {'CPU':<10} {'Memory':<10} {'Last Update':<20}")
            print("-"*80)
            
            for proc in processes:
                name, status, health, cpu, memory, heartbeat = proc
                status_icon = "🟢" if status == "running" else "🔴"
                print(f"{name[:28]:<30} {status_icon} {status:<8} {health:.1f}% {cpu:.1f}% {memory:.1f}MB {heartbeat[:19]}")
            
            conn.close()
        except Exception as e:
            print(f"Error reading process status: {e}")
        
        # Display recent trades
        try:
            conn = sqlite3.connect('paper_trading.db')
            cursor = conn.cursor()
            
            cursor.execute(''')
                SELECT timestamp, symbol, action, quantity, price, profit_loss
                FROM trades
                ORDER BY timestamp DESC
                LIMIT 5
            ''')
            
            trades = cursor.fetchall()
            
            if trades:
                print("\\n💹 Recent Trades:")
                print("-"*80)
                for trade in trades:
                    timestamp, symbol, action, qty, price, pnl = trade
                    pnl_str = f"+${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
                    print(f"{timestamp[:19]} | {action} {qty} {symbol} @ ${price:.2f} | P&L: {pnl_str}")
            
            conn.close()
        except Exception:
            pass
        
        # Display performance metrics
        try:
            conn = sqlite3.connect('performance.db')
            cursor = conn.cursor()
            
            cursor.execute(''')
                SELECT 
                    COUNT(*) as total_trades,
                    SUM(CASE WHEN profit_loss > 0 THEN 1 ELSE 0 END) as wins,
                    SUM(profit_loss) as total_pnl,
                    AVG(profit_loss) as avg_pnl
                FROM trades
                WHERE timestamp > datetime('now', '-1 day')
            ''')
            
            metrics = cursor.fetchone()
            if metrics and metrics[0] > 0:
                total, wins, total_pnl, avg_pnl = metrics
                win_rate = (wins / total * 100) if total > 0 else 0
                
                print("\\n📈 24-Hour Performance:")
                print("-"*80)
                print(f"Total Trades: {total} | Win Rate: {win_rate:.1f}% | Total P&L: ${total_pnl:.2f} | Avg P&L: ${avg_pnl:.2f}")
            
            conn.close()
        except Exception:
            pass
        
        print("\\n" + "="*80)
        time.sleep(5)  # Update every 5 seconds

if __name__ == "__main__":
    display_dashboard()
"""
        
        # Save dashboard script
        with open('platform_dashboard.py', 'w') as f:
            f.write(dashboard_script)
    
    def run(self):
        """Run the unified trading platform"""
        try:
            # Display startup banner
            self.display_startup_banner()
            
            # Create monitoring dashboard
            self.create_monitoring_dashboard()
            
            # Start the dashboard in a separate process
            dashboard_proc = subprocess.Popen([sys.executable, 'platform_dashboard.py'])
            
            # Start the orchestrator
            logger.info("Starting Unified Trading Platform...")
            self.orchestrator.run()
            
        except KeyboardInterrupt:
            logger.info("Shutdown requested...")
        except Exception as e:
            logger.error(f"Platform error: {e}")
        finally:
            # Clean shutdown
            if 'dashboard_proc' in locals():
                dashboard_proc.terminate()
            logger.info("Platform shutdown complete")

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Unified Trading Platform')
    parser.add_argument('--mode', choices=['paper', 'live'], default='paper',
                       help='Trading mode (default: paper)')
    parser.add_argument('--runtime', type=int, default=24,
                       help='Runtime in hours (default: 24)')
    
    args = parser.parse_args()
    
    # Safety check for live mode
    if args.mode == 'live':
        print("\n⚠️  WARNING: Live trading mode selected!")
        print("This will trade with REAL MONEY. Are you sure? (yes/no): ", end='')
        confirm = input().strip().lower()
        if confirm != 'yes':
            print("Aborting...")
            return
    
    # Create and run platform
    platform = UnifiedTradingPlatform(mode=args.mode, runtime_hours=args.runtime)
    platform.run()

if __name__ == "__main__":
    main()