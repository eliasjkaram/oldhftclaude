#!/usr/bin/env python3
"""
Simplified Sentiment Analysis Pipeline for Production
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict, deque
import numpy as np

logger = logging.getLogger(__name__)

@dataclass
class SentimentScore:
    """Sentiment score with confidence"""
    symbol: str
    source: str
    timestamp: datetime
    headline: str
    content: str
    sentiment: float
    confidence: float
    model_scores: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

class SentimentAnalysisPipeline:
    """Simplified sentiment analysis pipeline"""
    
    def __init__(self, config=None):
        self.symbols = ["AAPL", "GOOGL", "MSFT", "TSLA", "AMZN"]
        self.sentiment_cache = defaultdict(lambda: deque(maxlen=1000))
        logger.info("Sentiment Analysis Pipeline initialized (simplified)")
        
    async def analyze_text(self, text: str, symbol: str, source: str) -> SentimentScore:
        """Analyze sentiment using simple heuristics"""
        # Positive words
        positive_words = ['good', 'great', 'excellent', 'positive', 'strong', 'buy', 
                         'outperform', 'bullish', 'growth', 'profit', 'gain', 'up']
        negative_words = ['bad', 'poor', 'negative', 'weak', 'sell', 'underperform',
                         'bearish', 'loss', 'decline', 'down', 'risk']
        
        text_lower = text.lower()
        
        # Count positive and negative words
        pos_count = sum(1 for word in positive_words if word in text_lower)
        neg_count = sum(1 for word in negative_words if word in text_lower)
        
        # Calculate sentiment
        total = pos_count + neg_count
        if total > 0:
            sentiment = (pos_count - neg_count) / total
            confidence = min(total / 10, 1.0)  # Higher word count = higher confidence
        else:
            sentiment = 0
            confidence = 0.1
            
        return SentimentScore()
            symbol=symbol,
            source=source,
            timestamp=datetime.utcnow(),
            headline=text[:100],
            content=text,
            sentiment=float(sentiment),
            confidence=float(confidence),
            model_scores={'simple': sentiment}
        )
        
    async def collect_and_analyze(self):
        """Collect and analyze sentiment data"""
        scores = []
        
        # Simulate news collection
        for symbol in self.symbols:
            # Generate sample news
            news_items = []
                f"{symbol} shows strong growth in Q4 earnings",
                f"Analysts upgrade {symbol} to buy rating",
                f"{symbol} faces regulatory challenges",
                f"Market volatility affects {symbol} stock price"
            ]
            
            for news in news_items:
                score = await self.analyze_text(news, symbol, "news")
                scores.append(score)
                self.sentiment_cache[symbol].append(score)
                
        return scores
        
    def get_aggregate_sentiment(self, symbol: str, window_hours: int = 24) -> Dict[str, float]:
        """Get aggregate sentiment for a symbol"""
        cutoff_time = datetime.utcnow() - timedelta(hours=window_hours)
        
        recent_scores = []
            score for score in self.sentiment_cache[symbol]
            if score.timestamp > cutoff_time
        ]
        
        if not recent_scores:
            return {}
                'sentiment': 0,
                'confidence': 0,
                'num_articles': 0
            }
            
        sentiments = [score.sentiment for score in recent_scores]
        confidences = [score.confidence for score in recent_scores]
        
        return {}
            'sentiment': float(np.mean(sentiments)),
            'confidence': float(np.mean(confidences)),
            'num_articles': len(recent_scores)
        }
        
    def get_sentiment_signals(self) -> Dict[str, Dict[str, Any]]:
        """Generate trading signals based on sentiment"""
        signals = {}
        
        for symbol in self.symbols:
            sentiment_data = self.get_aggregate_sentiment(symbol)
            
            signal = {}
                'symbol': symbol,
                'timestamp': datetime.utcnow(),
                'sentiment': sentiment_data['sentiment'],
                'confidence': sentiment_data['confidence'],
                'signal': 'NEUTRAL'
            }
            
            # Determine signal
            if sentiment_data['sentiment'] > 0.3:
                signal['signal'] = 'BULLISH'
            elif sentiment_data['sentiment'] < -0.3:
                signal['signal'] = 'BEARISH'
                
            signals[symbol] = signal
            
        return signals
        
    async def start(self):
        """Start the pipeline"""
        logger.info("Starting sentiment analysis pipeline")
        await self.collect_and_analyze()
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get pipeline metrics"""
        return {}
            'cache_sizes': {}
                symbol: len(scores)
                for symbol, scores in self.sentiment_cache.items()
            }
        }