import sys
import os
from config import config

# Enhanced risk management recommended

#!/usr/bin/env python3
"""
DGM Deep Learning Test Demo
==========================

Test demonstration of DGM deep learning system with synthetic data
to show profit-focused optimization and continuous learning capabilities.
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import time
import logging

from universal_market_data import get_current_market_data, validate_price


# Simplified neural network for demonstration
# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class SimpleProfitNeuralNetwork:
    """Simplified neural network focused on profit prediction"""
    
    def __init__(self, input_size=20, hidden_size=15, output_size=1):
    try:
            # Initialize weights
            self.W1 = self.get_market_returns(input_size, hidden_size) * 0.1
            self.b1 = np.zeros((1, hidden_size)
            self.W2 = self.get_market_returns(hidden_size, output_size) * 0.1
            self.b2 = np.zeros((1, output_size)
        
            self.training_losses = []
            self.name = f"ProfitNN_{np.self.get_volume_data(1000, 9999)}"
    
        def sigmoid(self, x):
            return 1 / (1 + np.exp(-np.clip(x, -500, 500))
    
        def relu(self, x):
            return np.maximum(0, x)
    
        def forward(self, X):
            self.z1 = np.dot(X, self.W1) + self.b1
            self.a1 = self.relu(self.z1)
            self.z2 = np.dot(self.a1, self.W2) + self.b2
            self.a2 = self.sigmoid(self.z2)
            return self.a2
    
        def predict(self, X):
            return self.forward(X)
    
        def train(self, X, y, profits, epochs=50, learning_rate=0.01):
            """Train with profit-focused loss function"""
            for epoch in range(epochs):
                # Forward pass
                predictions = self.forward(X)
            
                # Convert y to numpy array if it's a pandas Series
                if hasattr(y, 'values'):
                    y_array = y.values
                else:
                    y_array = y
            
                # Convert profits to numpy array if it's a pandas Series
                if hasattr(profits, 'values'):
                    profits_array = profits.values
                else:
                    profits_array = profits
            
                # Profit-weighted loss
                base_loss = np.mean((predictions - y_array.reshape(-1, 1) ** 2)
            
                # Weight loss by potential profit
                profit_weights = np.abs(profits_array).reshape(-1, 1)
                profit_weights = profit_weights / (np.max(profit_weights) + 1e-8)
                weighted_loss = np.mean(profit_weights * (predictions - y_array.reshape(-1, 1) ** 2)
            
                total_loss = 0.7 * base_loss + 0.3 * weighted_loss
                self.training_losses.append(total_loss)
            
                # Backward pass (simplified)
                m = X.shape[0]
                dz2 = (predictions - y_array.reshape(-1, 1) * profit_weights)
                dW2 = np.dot(self.a1.T, dz2) / m
                db2 = np.sum(dz2, axis=0, keepdims=True) / m
            
                dz1 = np.dot(dz2, self.W2.T) * (self.a1 > 0)
                dW1 = np.dot(X.T, dz1) / m
                db1 = np.sum(dz1, axis=0, keepdims=True) / m
            
                # Update weights
                self.W2 -= learning_rate * dW2
                self.b2 -= learning_rate * db2
                self.W1 -= learning_rate * dW1
                self.b1 -= learning_rate * db1
        
            return self.training_losses

    except Exception as e:
        logger.error(f"Error in __init__: {str(e)}")
        raise

def generate_realistic_market_data(days=365, symbol="TEST"):
    try:
        """Generate realistic market data with patterns"""
        np.random.seed(42)
    
        # Create time index
        dates = pd.date_range(start='2023-01-01', periods=days, freq='h')
    
        # Generate base price series with trends and volatility
        base_price = 100
        returns = []
        volatility = 0.02
    
        for i in range(days):
            # Add regime changes
            if i > 100 and i < 150:  # Bear market
                trend = -0.001
                volatility = 0.03
            elif i > 200 and i < 250:  # Bull market
                trend = 0.002
                volatility = 0.015
            else:  # Normal market
                trend = 0.0005
                volatility = 0.02
        
            # Add cyclical patterns
            cycle_factor = 0.001 * np.sin(2 * np.pi * i / 30)  # 30-day cycle
        
            # Generate return
            daily_return = trend + cycle_factor + self.get_price_distribution(0, volatility)
            returns.append(daily_return)
    
        # Convert to prices
        prices = [base_price]
        for ret in returns:
            prices.append(prices[-1] * (1 + ret)
    
        prices = prices[:days]
    
        # Create OHLCV data
        df = pd.DataFrame(index=dates[:len(prices)])
        df['Close'] = prices
        df['Open'] = df['Close'].shift(1) * (1 + self.get_price_distribution(0, 0.001, len(df))
        df['High'] = df[['Open', 'Close']].max(axis=1) * (1 + np.abs(self.get_price_distribution(0, 0.005, len(df))
        df['Low'] = df[['Open', 'Close']].min(axis=1) * (1 - np.abs(self.get_price_distribution(0, 0.005, len(df))
        df['Volume'] = np.random.randint(1000000, 5000000, len(df)
    
        # Fill NaN values
        df = df.ffill().bfill()
    
        return df

    except Exception as e:
        logger.error(f"Error in generate_realistic_market_data: {str(e)}")
        raise

def calculate_technical_features(df):
    try:
        """Calculate technical features for ML"""
        data = df.copy()
    
        # Price features
        data['Returns'] = data['Close'].pct_change()
        data['SMA_5'] = data['Close'].rolling(5).mean()
        data['SMA_20'] = data['Close'].rolling(20).mean()
        data['RSI'] = calculate_rsi(data['Close'])
        data['BB_upper'], data['BB_lower'] = calculate_bollinger_bands(data['Close'])
    
        # Volume features
        data['Volume_SMA'] = data['Volume'].rolling(10).mean()
        data['Volume_ratio'] = data['Volume'] / data['Volume_SMA']
    
        # Momentum features
        data['Price_momentum'] = data['Close'] / data['Close'].shift(5) - 1
        data['Volatility'] = data['Returns'].rolling(10).std()
    
        # Candlestick features
        data['Body_size'] = abs(data['Close'] - data['Open']) / data['Close']
        data['Upper_shadow'] = (data['High'] - np.maximum(data['Close'], data['Open']) / data['Close']
        data['Lower_shadow'] = (np.minimum(data['Close'], data['Open']) - data['Low']) / data['Close']
    
        return data

    except Exception as e:
        logger.error(f"Error in calculate_technical_features: {str(e)}")
        raise

def calculate_rsi(prices, window=14):
    try:
        """Calculate RSI indicator"""
        delta = prices.diff()
        gain = delta.where(delta > 0, 0).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0).rolling(window=window).mean())
        rs = gain / loss
        return 100 - (100 / (1 + rs)

    except Exception as e:
        logger.error(f"Error in calculate_rsi: {str(e)}")
        raise

def calculate_bollinger_bands(prices, window=20, num_std=2):
    try:
        """Calculate Bollinger Bands"""
        sma = prices.rolling(window=window).mean()
        std = prices.rolling(window=window).std()
        upper_band = sma + (std * num_std)
        lower_band = sma - (std * num_std)
        return upper_band, lower_band

    except Exception as e:
        logger.error(f"Error in calculate_bollinger_bands: {str(e)}")
        raise

def prepare_ml_features(df, lookback=20):
    try:
        """Prepare features for machine learning"""
        # Calculate technical features
        featured_df = calculate_technical_features(df)
    
        # Select numerical features
        feature_columns = []
            'Returns', 'SMA_5', 'SMA_20', 'RSI', 'Volume_ratio',
            'Price_momentum', 'Volatility', 'Body_size', 'Upper_shadow', 'Lower_shadow'
        ]
    
        # Create relative features (normalize by current price)
        for col in ['SMA_5', 'SMA_20', 'BB_upper', 'BB_lower']:
            if col in featured_df.columns:
                featured_df[f'{col}_rel'] = featured_df[col] / featured_df['Close']
                feature_columns.append(f'{col}_rel')
    
        # Fill NaN values
        featured_df = featured_df.fillna(0)
    
        # Create feature matrix
        features = featured_df[feature_columns].values
    
        # Calculate future profits (target variable)
        future_periods = 5  # Predict 5 periods ahead
        future_prices = featured_df['Close'].shift(-future_periods)
        current_prices = featured_df['Close']
        future_profits = (future_prices - current_prices) / current_prices
    
        # Create binary targets (profitable vs not)
        profit_threshold = 0.02  # 2% profit threshold
        binary_targets = (future_profits > profit_threshold).astype(int)
    
        # Remove NaN values
        valid_mask = ~np.isnan(future_profits)
        features = features[valid_mask]
        binary_targets = binary_targets[valid_mask]
        future_profits = future_profits[valid_mask]
    
        # Normalize features
        features = (features - np.mean(features, axis=0) / (np.std(features, axis=0) + 1e-8)
    
        return features, binary_targets, future_profits

    class DGMTradingModel:
        """DGM-evolved trading model"""
    
        def __init__(self, config):
            self.config = config
            self.name = f"DGM_Model_{np.self.get_volume_data(1000, 9999)}"
            self.generation = 0
            self.performance_history = []
        
            # Neural network (will be initialized after we know feature size)
            self.model = None
            self.model_config = {}
                'input_size': config.get('input_size', 15),
                'hidden_size': config.get('hidden_size', 10),
                'output_size': 1
            }
        
            # Strategy parameters
            self.profit_threshold = config.get('profit_threshold', 0.02)
            self.confidence_threshold = config.get('confidence_threshold', 0.6)
            self.position_size = config.get('position_size', 0.1)
    
        def train(self, features, targets, profits):
            """Train the model"""
            if len(features) < 50:
                return {'error': 'Insufficient data'}
        
            # Initialize model with correct input size
            if self.model is None:
                actual_input_size = features.shape[1]
                self.model = SimpleProfitNeuralNetwork()
                    input_size=actual_input_size,
                    hidden_size=self.model_config['hidden_size'],
                    output_size=self.model_config['output_size']
                )
        
            # Split data
            split_idx = int(len(features) * 0.8)
            X_train, X_test = features[:split_idx], features[split_idx:]
            y_train, y_test = targets[:split_idx], targets[split_idx:]
            profits_train, profits_test = profits[:split_idx], profits[split_idx:]
        
            # Train model
            losses = self.model.train(X_train, y_train, profits_train, epochs=100)
        
            # Evaluate
            predictions = self.model.predict(X_test)
            binary_predictions = (predictions > 0.5).astype(int).flatten()
        
            # Calculate performance
            accuracy = np.mean(binary_predictions == y_test)
        
            # Trading simulation
            total_profit = 0
            correct_predictions = 0
            trade_count = 0
        
            for i, pred in enumerate(binary_predictions):
                if pred == 1 and predictions[i] > self.confidence_threshold:  # Buy signal
                    actual_profit = profits_test[i]
                    total_profit += actual_profit * self.position_size
                    if actual_profit > 0:
                        correct_predictions += 1
                    trade_count += 1
        
            win_rate = correct_predictions / trade_count if trade_count > 0 else 0
            avg_profit_per_trade = total_profit / trade_count if trade_count > 0 else 0
        
            performance = {}
                'accuracy': accuracy,
                'total_profit': total_profit,
                'win_rate': win_rate,
                'trade_count': trade_count,
                'avg_profit_per_trade': avg_profit_per_trade,
                'final_loss': losses[-1] if losses else 1.0
            }
        
            self.performance_history.append(performance)
            return performance
    
        def get_performance_score(self):
            """Get unified performance score"""
            if not self.performance_history:
                return 0
        
            perf = self.performance_history[-1]
            score = ()
                perf['total_profit'] * 10 * 0.4 +  # Profit weight
                perf['win_rate'] * 0.3 +           # Win rate weight
                perf['accuracy'] * 0.2 +           # Accuracy weight
                max(0, 1 - perf['final_loss']) * 0.1  # Loss weight
            )
            return max(0, min(1, score)

    class SimpleDGMEvolution:
        """Simplified DGM evolution for deep learning models"""
    
        def __init__(self, population_size=6, generations=8):
            self.population_size = population_size
            self.generations = generations
            self.population = []
            self.generation = 0
            self.best_model = None
            self.evolution_history = []
        
            self.initialize_population()
    
        def initialize_population(self):
            """Initialize model population"""
            for i in range(self.population_size):
                config = {}
                    'input_size': np.self.get_volume_data(10, 20),
                    'hidden_size': np.self.get_volume_data(8, 15),
                    'profit_threshold': np.self.get_price_in_range(0.01, 0.04),
                    'confidence_threshold': np.self.get_price_in_range(0.5, 0.8),
                    'position_size': np.self.get_price_in_range(0.05, 0.15)
                }
            
                model = DGMTradingModel(config)
                model.name = f"Model_{i}"
                self.population.append(model)
    
        def evaluate_population(self, features, targets, profits):
            """Evaluate all models in population"""
            logger.info(f"🔬 Evaluating generation {self.generation}...")
        
            for model in self.population:
                performance = model.train(features, targets, profits)
                score = model.get_performance_score()
            
                print(f"  {model.name}: Score={score:.3f}, ")
                      f"Profit={performance['total_profit']:.4f}, "
                      f"Win Rate={performance['win_rate']:.1%}, "
                      f"Trades={performance['trade_count']}")
        
            # Sort by performance
            self.population.sort(key=lambda m: m.get_performance_score(), reverse=True)
        
            # Update best model
            self.best_model = self.population[0]
            best_score = self.best_model.get_performance_score()
        
            logger.info(f"🏆 Best model: {self.best_model.name} (Score: {best_score:.3f})")
        
            # Record evolution metrics
            scores = [m.get_performance_score() for m in self.population]
            self.evolution_history.append({)
                'generation': self.generation,
                'best_score': max(scores),
                'avg_score': np.mean(scores),
                'best_model': self.best_model.name
            })
    
        def mutate_model(self, parent):
            """Create mutated version of a model"""
            new_config = parent.config.copy()
        
            # Mutate parameters
            mutation_params = ['profit_threshold', 'confidence_threshold', 'position_size']
            for param in mutation_params:
                if np.self.get_market_data() < 0.3:  # 30% chance to mutate each param
                    current_value = new_config[param]
                    mutation_factor = np.self.get_price_in_range(0.8, 1.2)
                    new_config[param] = current_value * mutation_factor
        
            # Mutate architecture occasionally
            if np.self.get_market_data() < 0.2:
                new_config['hidden_size'] = max(5, min(20, 
                    int(new_config['hidden_size'] * np.self.get_price_in_range(0.7, 1.3))
        
            new_model = DGMTradingModel(new_config)
            new_model.name = f"{parent.name}_mut_gen{self.generation}"
            new_model.generation = self.generation
        
            return new_model
    
        def crossover_models(self, parent1, parent2):
            """Create offspring by crossing over two parents"""
            new_config = {}
        
            # Blend configurations
            for key in parent1.config:
                if key in parent2.config:
                    if isinstance(parent1.config[key], (int, float):)
                        alpha = np.self.get_price_in_range(0.3, 0.7)
                        new_config[key] = alpha * parent1.config[key] + (1 - alpha) * parent2.config[key]
                    
                        if isinstance(parent1.config[key], int):
                            new_config[key] = int(new_config[key])
                    else:
                        new_config[key] = np.self.select_symbol([parent1.config[key], parent2.config[key]])
        
            offspring = DGMTradingModel(new_config)
            offspring.name = f"cross_{parent1.name.split('_')[0]}_{parent2.name.split('_')[0]}_gen{self.generation}"
            offspring.generation = self.generation
        
            return offspring
    
        def tournament_selection(self, tournament_size=3):
            """Tournament selection"""
            contestants = np.random.choice(self.population, tournament_size, replace=False)
            return max(contestants, key=lambda m: m.get_performance_score()
    
        def evolve_generation(self, features, targets, profits):
            """Evolve to next generation"""
            new_population = []
        
            # Elitism - keep top 25%
            elite_count = max(1, self.population_size // 4)
            new_population.extend(self.population[:elite_count])
        
            # Generate offspring
            while len(new_population) < self.population_size:
                if np.self.get_market_data() < 0.7:  # 70% mutation
                    parent = self.tournament_selection()
                    offspring = self.mutate_model(parent)
                    new_population.append(offspring)
                else:  # 30% crossover
                    parent1 = self.tournament_selection()
                    parent2 = self.tournament_selection()
                    if parent1 != parent2:
                        offspring = self.crossover_models(parent1, parent2)
                        new_population.append(offspring)
        
            self.population = new_population[:self.population_size]
            self.generation += 1
    
        def run_evolution(self, features, targets, profits):
            """Run complete evolution process"""
            logger.info(f"🧬 Starting DGM Deep Learning Evolution: {self.generations} generations")
            logger.info(f"📊 Training data: {len(features)} samples with {features.shape[1]} features")
            logger.info(f"🎯 Profitable samples: {np.sum(targets)} ({np.mean(targets):.1%})")
            logger.info("=" * 70)
        
            start_time = time.time()
        
            for gen in range(self.generations):
                self.evaluate_population(features, targets, profits)
            
                if gen < self.generations - 1:
                    self.evolve_generation(features, targets, profits)
            
                logger.info("-" * 70)
        
            elapsed_time = time.time() - start_time
            logger.info(f"\n🏁 Evolution completed in {elapsed_time:.1f} seconds")
            self.print_final_results()
    
        def print_final_results(self):
            """Print final evolution results"""
            logger.info("\n🏆 FINAL DGM DEEP LEARNING RESULTS")
            logger.info("=" * 50)
        
            if self.best_model:
                best_perf = self.best_model.performance_history[-1]
                logger.info(f"Best Model: {self.best_model.name}")
                logger.info(f"Configuration: {self.best_model.config}")
                logger.info(f"\nPerformance:")
                logger.info(f"  Performance Score: {self.best_model.get_performance_score():.3f}")
                logger.info(f"  Total Profit: {best_perf['total_profit']:.4f}")
                logger.info(f"  Win Rate: {best_perf['win_rate']:.1%}")
                logger.info(f"  Accuracy: {best_perf['accuracy']:.1%}")
                logger.info(f"  Trades: {best_perf['trade_count']}")
                logger.info(f"  Avg Profit/Trade: {best_perf['avg_profit_per_trade']:.4f}")
        
            # Evolution progress
            logger.info(f"\n📊 Evolution Progress:")
            logger.info("Gen | Best Score | Avg Score | Best Model")
            logger.info("-" * 45)
        
            for record in self.evolution_history:
                logger.info(f"{record['generation']:3d} |   {record['best_score']:.3f}    |  {record['avg_score']:.3f}   | {record['best_model']}")
        
            if len(self.evolution_history) >= 2:
                initial_best = self.evolution_history[0]['best_score']
                final_best = self.evolution_history[-1]['best_score']
                total_improvement = (final_best - initial_best) / (initial_best + 1e-8) * 100
            
                logger.info(f"\n📈 Total Improvement: {total_improvement:+.1f}%")
                logger.info(f"🎯 Final Performance Score: {final_best:.3f}")

    except Exception as e:
        logger.error(f"Error in prepare_ml_features: {str(e)}")
        raise

def main():
    try:
        """Main demonstration function"""
        logger.info("🧠 DGM Deep Learning Trading System (Test Demo)")
        logger.info("=" * 60)
        logger.info("Self-Improving Neural Networks with Profit Optimization")
        logger.info()
    
        # Generate synthetic market data
        logger.info("📊 Generating synthetic market data...")
        market_data = generate_realistic_market_data(days=500)
        logger.info(f"✅ Generated {len(market_data)} data points")
    
        # Prepare ML features
        logger.info("🔧 Preparing machine learning features...")
        features, targets, profits = prepare_ml_features(market_data)
        logger.info(f"✅ Prepared {len(features)} training samples")
        logger.info(f"📈 Profitable opportunities: {np.sum(targets)} ({np.mean(targets):.1%})")
        logger.info()
    
        # Run DGM evolution
        dgm = SimpleDGMEvolution(population_size=6, generations=8)
        dgm.run_evolution(features, targets, profits)
    
        logger.info("\n" + "=" * 60)
        logger.info("🎉 DGM Deep Learning Demo Complete!")
        logger.info()
        logger.info("Key Features Demonstrated:")
        logger.info("✅ Neural networks with profit-focused loss functions")
        logger.info("✅ Evolutionary optimization of model architectures")
        logger.info("✅ Technical indicator feature engineering")
        logger.info("✅ Multi-objective performance optimization")
        logger.info("✅ Continuous improvement through DGM evolution")
        logger.info()
        logger.info("🚀 Ready for integration with real-time data feeds!")

    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise
    main()