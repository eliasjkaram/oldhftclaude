#!/usr/bin/env python3
"""
Detailed 2023 Data Investigation
This script investigates the specific 2023 files found in the options-complete directory.
"""

import pandas as pd
import json
import requests
from datetime import datetime, timedelta
import logging
import re
import os
from typing import Dict, List, Any
import xml.etree.ElementTree as ET
import warnings
warnings.filterwarnings('ignore')

# Set up logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('detailed_2023_investigation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class Detailed2023Investigation:
    def __init__(self):
        """Initialize the detailed 2023 investigation."""
        self.base_url = "https://uschristmas.us"
        self.bucket = "stockdb"
        self.options_complete_url = f"{self.base_url}/{self.bucket}/options-complete/"
        
        self.investigation_results = {}
            "investigation_timestamp": datetime.now().isoformat(),
            "focus": "Detailed analysis of 2023 options data",
            "files_analyzed": [],
            "data_samples": {},
            "file_details": {},
            "data_quality_report": {},
            "date_coverage": {},
            "recommendations": []
        }
        
        # 2023 patterns found in previous search
        self.found_2023_patterns = []
            "2023",
            "230013", 
            "230200",
            "231309",
            "230718", 
            "230816",
            "230928"
        ]

    def get_options_complete_directory_listing(self) -> List[str]:
        """Get full directory listing from options-complete directory."""
        logger.info("Getting options-complete directory listing...")
        
        try:
            response = requests.get(f"{self.options_complete_url}?max-keys=2000")
            if response.status_code == 200:
                # Parse XML response
                root = ET.fromstring(response.content)
                files = []
                
                # Find all Key elements
                for key_elem in root.findall('.//{http://s3.amazonaws.com/doc/2006-03-01/}Key'):
                    if key_elem.text:
                        files.append(key_elem.text.replace('options-complete/', ''))
                
                logger.info(f"Found {len(files)} files in options-complete directory")
                return files
            else:
                logger.error(f"Failed to get directory listing: HTTP {response.status_code}")
                return []
                
        except Exception as e:
            logger.error(f"Error getting directory listing: {str(e)}")
            return []

    def find_actual_2023_files(self, all_files: List[str]) -> List[str]:
        """Find actual files that contain 2023 data."""
        logger.info("Searching for actual 2023 files...")
        
        actual_2023_files = []
        
        # Look for files that actually contain 2023 dates
        for file_name in all_files:
            # Check various 2023 patterns
            if any(pattern in file_name for pattern in [)
                '2023',
                '2023-01', '2023-02', '2023-03', '2023-04', '2023-05', '2023-06',
                '2023-07', '2023-08', '2023-09', '2023-10', '2023-11', '2023-12',
                '20230101', '20230201', '20230301', '20230401', '20230501', '20230601',
                '20230701', '20230801', '20230901', '20231001', '20231101', '20231201'
            ]):
                actual_2023_files.append(file_name)
                logger.info(f"Found actual 2023 file: {file_name}")
        
        return actual_2023_files

    def analyze_file_details(self, file_name: str) -> Dict[str, Any]:
        """Analyze details of a specific file."""
        logger.info(f"Analyzing file: {file_name}")
        
        file_details = {}
            "file_name": file_name,
            "exists": False,
            "size": "unknown",
            "last_modified": "unknown",
            "content_type": "unknown",
            "sample_data": None,
            "data_quality": "unknown",
            "record_count": "unknown"
        }
        
        try:
            # Check if file exists and get metadata
            file_url = f"{self.options_complete_url}{file_name}"
            head_response = requests.head(file_url)
            
            if head_response.status_code == 200:
                file_details["exists"] = True
                file_details["size"] = head_response.headers.get('Content-Length', 'unknown')
                file_details["last_modified"] = head_response.headers.get('Last-Modified', 'unknown')
                file_details["content_type"] = head_response.headers.get('Content-Type', 'unknown')
                
                # Try to get sample data
                sample_response = requests.get(file_url, stream=True)
                if sample_response.status_code == 200:
                    # Read first few lines
                    lines = []
                    for i, line in enumerate(sample_response.iter_lines(decode_unicode=True)):
                        if i >= 10:  # Get first 10 lines
                            break
                        lines.append(line)
                    
                    file_details["sample_data"] = lines
                    
                    # Estimate record count if CSV
                    if file_name.lower().endswith('.csv'):
                        try:
                            # Try to parse first few lines as CSV
                            if len(lines) > 1:
                                # Assume first line is header
                                header = lines[0]
                                sample_row = lines[1] if len(lines) > 1 else ""
                                
                                file_details["header"] = header
                                file_details["sample_row"] = sample_row
                                file_details["columns"] = len(header.split(',')) if header else 0
                                
                                # Try to estimate total rows
                                if file_details["size"] != "unknown":
                                    try:
                                        file_size = int(file_details["size"])
                                        avg_line_length = len(sample_row) + 1  # +1 for newline
                                        if avg_line_length > 0:
                                            estimated_rows = file_size // avg_line_length
                                            file_details["estimated_rows"] = estimated_rows
                                    except Exception:
                                        pass
                        except Exception as e:
                            logger.debug(f"Could not parse CSV structure for {file_name}: {e}")
                
                logger.info(f"File {file_name} analyzed successfully (size: {file_details['size']})")
                
            else:
                logger.warning(f"File {file_name} not accessible: HTTP {head_response.status_code}")
                
        except Exception as e:
            logger.error(f"Error analyzing file {file_name}: {str(e)}")
        
        return file_details

    def investigate_2023_data(self) -> Dict[str, Any]:
        """Perform detailed investigation of 2023 data."""
        logger.info("Starting detailed 2023 data investigation...")
        
        # Get directory listing
        all_files = self.get_options_complete_directory_listing()
        
        # Find actual 2023 files
        actual_2023_files = self.find_actual_2023_files(all_files)
        
        # Analyze each 2023 file
        for file_name in actual_2023_files:
            file_details = self.analyze_file_details(file_name)
            self.investigation_results["files_analyzed"].append(file_name)
            self.investigation_results["file_details"][file_name] = file_details
            
            # Store sample data
            if file_details.get("sample_data"):
                self.investigation_results["data_samples"][file_name] = file_details["sample_data"][:5]  # First 5 lines
        
        # Generate analysis summary
        self.generate_analysis_summary()
        
        return self.investigation_results

    def generate_analysis_summary(self):
        """Generate comprehensive analysis summary."""
        logger.info("Generating analysis summary...")
        
        total_files = len(self.investigation_results["files_analyzed"])
        total_size = 0
        accessible_files = 0
        csv_files = 0
        estimated_total_records = 0
        
        file_dates = []
        
        for file_name, details in self.investigation_results["file_details"].items():
            if details["exists"]:
                accessible_files += 1
                
                # Calculate total size
                if details["size"] != "unknown":
                    try:
                        total_size += int(details["size"])
                    except Exception:
                        pass
                
                # Count CSV files
                if file_name.lower().endswith('.csv'):
                    csv_files += 1
                
                # Estimate total records
                if details.get("estimated_rows"):
                    estimated_total_records += details["estimated_rows"]
                
                # Extract dates from filename
                date_patterns = re.findall(r'(\d{4}-\d{2}-\d{2})', file_name)
                if date_patterns:
                    file_dates.extend(date_patterns)
        
        # Date coverage analysis
        if file_dates:
            unique_dates = sorted(list(set(file_dates)))
            self.investigation_results["date_coverage"] = {}
                "unique_dates": len(unique_dates),
                "date_range": {}
                    "earliest": unique_dates[0] if unique_dates else None,
                    "latest": unique_dates[-1] if unique_dates else None
                },
                "sample_dates": unique_dates[:10]  # First 10 dates
            }
        
        # Data quality report
        self.investigation_results["data_quality_report"] = {}
            "total_2023_files_found": total_files,
            "accessible_files": accessible_files,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "csv_files": csv_files,
            "estimated_total_records": estimated_total_records,
            "data_availability_status": "EXCELLENT" if accessible_files > 0 else "NO_ACCESS"
        }
        
        # Generate recommendations
        if accessible_files > 0:
            self.investigation_results["recommendations"] = []
                f"✅ CONFIRMED: {accessible_files} 2023 options data files are accessible",
                f"📊 Data Volume: {self.investigation_results['data_quality_report']['total_size_mb']} MB of 2023 data available",
                f"📈 Estimated Records: ~{estimated_total_records:,} options records for 2023",
                "🔄 Priority: Download and integrate this data immediately into trading systems",
                "📋 Validate: Check data completeness and quality before production use",
                "⚡ Optimize: Consider caching frequently accessed 2023 data locally"
            ]
            
            if len(file_dates) > 0:
                self.investigation_results["recommendations"].append()
                    f"📅 Date Coverage: 2023 data spans from {self.investigation_results['date_coverage']['date_range']['earliest']} to {self.investigation_results['date_coverage']['date_range']['latest']}"
                )
        else:
            self.investigation_results["recommendations"] = []
                "❌ No accessible 2023 files found despite pattern matches",
                "🔍 Investigate: Check file permissions and access patterns",
                "📞 Contact: Reach out to data provider for 2023 data access",
                "🔄 Retry: Attempt connection with different access methods"
            ]

    def save_investigation_results(self, filename: str = None):
        """Save investigation results to file."""
        if filename is None:
            filename = f"detailed_2023_investigation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.investigation_results, f, indent=2)
        
        logger.info(f"Investigation results saved to {filename}")
        return filename

def main():
    """Main execution function."""
    logger.info("Starting detailed 2023 data investigation...")
    
    try:
        investigator = Detailed2023Investigation()
        results = investigator.investigate_2023_data()
        
        # Save results
        results_file = investigator.save_investigation_results()
        
        # Print detailed summary
        print("\n" + "="*80)
        print("DETAILED 2023 OPTIONS DATA INVESTIGATION RESULTS")
        print("="*80)
        
        print(f"\nInvestigation completed at: {results['investigation_timestamp']}")
        
        quality_report = results["data_quality_report"]
        print(f"\n📊 DATA QUALITY REPORT:")
        print(f"  • Total 2023 files found: {quality_report['total_2023_files_found']}")
        print(f"  • Accessible files: {quality_report['accessible_files']}")
        print(f"  • Total data size: {quality_report['total_size_mb']} MB ({quality_report['total_size_bytes']:,} bytes)")
        print(f"  • CSV files: {quality_report['csv_files']}")
        print(f"  • Estimated records: {quality_report['estimated_total_records']:,}")
        print(f"  • Status: {quality_report['data_availability_status']}")
        
        if results.get("date_coverage"):
            date_coverage = results["date_coverage"]
            print(f"\n📅 DATE COVERAGE:")
            print(f"  • Unique dates: {date_coverage['unique_dates']}")
            print(f"  • Date range: {date_coverage['date_range']['earliest']} to {date_coverage['date_range']['latest']}")
            print(f"  • Sample dates: {', '.join(date_coverage['sample_dates'])}")
        
        if results["files_analyzed"]:
            print(f"\n📁 FILES ANALYZED:")
            for file_name in results["files_analyzed"][:10]:  # Show first 10
                details = results["file_details"][file_name]
                status = "✅ Accessible" if details["exists"] else "❌ Not accessible"
                size = f"({details['size']} bytes)" if details["size"] != "unknown" else ""
                print(f"  • {file_name} {status} {size}")
            
            if len(results["files_analyzed"]) > 10:
                print(f"  ... and {len(results['files_analyzed']) - 10} more files")
        
        print(f"\n💡 RECOMMENDATIONS:")
        for i, rec in enumerate(results["recommendations"], 1):
            print(f"  {i}. {rec}")
        
        print(f"\n📄 Full investigation results saved to: {results_file}")
        print("="*80)
        
        return results
        
    except Exception as e:
        logger.error(f"Investigation failed: {str(e)}")
        raise

if __name__ == "__main__":
    main()