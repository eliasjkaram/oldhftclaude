#!/usr/bin/env python3
"""
Low-Latency Inference Endpoint

Production-ready ultra-low latency model inference system with sub-10ms response times
using ONNX Runtime, TensorRT, model quantization, caching, and hardware acceleration.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import aiohttp
from collections import deque, OrderedDict
import json
import pickle
import time
import threading
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import mmap
import struct
import logging

# Deep learning optimization imports
import onnx
import onnxruntime as ort
import torch
import torch.nn as nn
import torch.jit
import torch.quantization as quantization
from torch.nn.quantized import FloatFunctional

# Performance optimization imports
import numba
from numba import jit, cuda
import cupy as cp  # GPU arrays
import pyarrow as pa
# import pyarrow.plasma as plasma  # Plasma is deprecated
plasma = None

# Networking imports
import zmq
import uvloop
import redis.asyncio as aioredis
from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import ORJSONResponse
import orjson

# Internal imports
from unified_logging import get_logger
from unified_error_handling import retry, ErrorCategory, ErrorSeverity, handle_errors
from monitoring_alerting import MetricsCollector

logger = get_logger(__name__)


class InferenceBackend(Enum):
    """Available inference backends"""
    ONNX_CPU = "onnx_cpu"
    ONNX_GPU = "onnx_gpu"
    TENSORRT = "tensorrt"
    TORCH_JIT = "torch_jit"
    TORCH_QUANTIZED = "torch_quantized"
    OPENVINO = "openvino"
    TFLITE = "tflite"


class OptimizationLevel(Enum):
    """Model optimization levels"""
    NONE = 0
    BASIC = 1      # Basic optimizations
    AGGRESSIVE = 2  # Aggressive optimizations (may affect accuracy)
    EXTREME = 3    # Extreme optimizations (for latency-critical paths)


@dataclass
class ModelConfig:
    """Model configuration for inference"""
    model_id: str
    model_path: str
    backend: InferenceBackend
    
    # Input/output configuration
    input_shapes: Dict[str, List[int]]
    output_names: List[str]
    
    # Optimization settings
    optimization_level: OptimizationLevel = OptimizationLevel.BASIC
    quantization_bits: int = 8  # INT8 quantization
    use_gpu: bool = True
    gpu_device_id: int = 0
    
    # Batching configuration
    max_batch_size: int = 32
    dynamic_batching: bool = True
    batch_timeout_ms: float = 5.0
    
    # Memory settings
    use_shared_memory: bool = True
    memory_pool_size_mb: int = 1024
    
    # Cache settings
    enable_cache: bool = True
    cache_size: int = 10000
    cache_ttl_seconds: int = 300


@dataclass
class InferenceRequest:
    """Single inference request"""
    request_id: str
    model_id: str
    inputs: Dict[str, np.ndarray]
    timestamp: datetime = field(default_factory=datetime.now)
    priority: int = 0  # Higher = more priority
    timeout_ms: float = 10.0
    
    # Response tracking
    future: Optional[asyncio.Future] = None
    
    def __hash__(self):
        return hash(self.request_id)


@dataclass
class InferenceResponse:
    """Inference response"""
    request_id: str
    outputs: Dict[str, np.ndarray]
    latency_ms: float
    timestamp: datetime = field(default_factory=datetime.now)
    
    # Performance metrics
    preprocessing_ms: float = 0.0
    inference_ms: float = 0.0
    postprocessing_ms: float = 0.0
    queue_wait_ms: float = 0.0
    
    # Debug info
    batch_size: int = 1
    cache_hit: bool = False
    backend_used: str = ""


@dataclass
class LatencyStats:
    """Latency statistics tracking"""
    count: int = 0
    total_ms: float = 0.0
    min_ms: float = float('inf')
    max_ms: float = 0.0
    
    # Percentiles
    p50_ms: float = 0.0
    p95_ms: float = 0.0
    p99_ms: float = 0.0
    
    # Recent samples for percentile calculation
    recent_samples: deque = field(default_factory=lambda: deque(maxlen=1000))
    
    def update(self, latency_ms: float):
        """Update statistics with new latency measurement"""
        self.count += 1
        self.total_ms += latency_ms
        self.min_ms = min(self.min_ms, latency_ms)
        self.max_ms = max(self.max_ms, latency_ms)
        self.recent_samples.append(latency_ms)
        
        # Update percentiles
        if len(self.recent_samples) >= 10:
            sorted_samples = sorted(self.recent_samples)
            self.p50_ms = sorted_samples[len(sorted_samples) // 2]
            self.p95_ms = sorted_samples[int(len(sorted_samples) * 0.95)]
            self.p99_ms = sorted_samples[int(len(sorted_samples) * 0.99)]
    
    @property
    def avg_ms(self) -> float:
        return self.total_ms / self.count if self.count > 0 else 0.0


class ModelInferenceEngine:
    """High-performance model inference engine"""
    
    def __init__(self, model_config: ModelConfig):
        self.config = model_config
        self.model = None
        self.session = None
        self.metrics_collector = MetricsCollector()
        
        # Request queue for batching
        self.request_queue: asyncio.Queue = asyncio.Queue()
        self.batch_queue: List[InferenceRequest] = []
        self.batch_lock = asyncio.Lock()
        
        # Response cache
        self.cache: OrderedDict = OrderedDict()
        self.cache_lock = threading.Lock()
        
        # Performance tracking
        self.latency_stats = LatencyStats()
        
        # Shared memory for zero-copy
        self.plasma_client = None
        self.memory_pool = None
        
        # Initialize backend
        self._initialize_backend()
        
        logger.info(f"Model inference engine initialized for {model_config.model_id}")
    
    def _initialize_backend(self):
        """Initialize the inference backend"""
        
        if self.config.backend == InferenceBackend.ONNX_CPU:
            self._initialize_onnx_cpu()
        elif self.config.backend == InferenceBackend.ONNX_GPU:
            self._initialize_onnx_gpu()
        elif self.config.backend == InferenceBackend.TENSORRT:
            self._initialize_tensorrt()
        elif self.config.backend == InferenceBackend.TORCH_JIT:
            self._initialize_torch_jit()
        elif self.config.backend == InferenceBackend.TORCH_QUANTIZED:
            self._initialize_torch_quantized()
        else:
            raise ValueError(f"Unsupported backend: {self.config.backend}")
        
        # Initialize shared memory if enabled
        if self.config.use_shared_memory:
            self._initialize_shared_memory()
    
    def _initialize_onnx_cpu(self):
        """Initialize ONNX Runtime for CPU inference"""
        
        # Session options for optimization
        sess_options = ort.SessionOptions()
        
        # Enable all optimizations
        sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        # Set number of threads
        sess_options.intra_op_num_threads = mp.cpu_count()
        sess_options.inter_op_num_threads = 1
        
        # Enable CPU execution provider optimizations
        sess_options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        
        # Additional optimizations
        if self.config.optimization_level >= OptimizationLevel.AGGRESSIVE:
            sess_options.enable_cpu_mem_arena = True
            sess_options.enable_mem_pattern = True
        
        # Create inference session
        providers = ['CPUExecutionProvider']
        self.session = ort.InferenceSession()
            self.config.model_path,
            sess_options,
            providers=providers
        )
        
        logger.info("ONNX CPU backend initialized")
    
    def _initialize_onnx_gpu(self):
        """Initialize ONNX Runtime for GPU inference"""
        
        sess_options = ort.SessionOptions()
        sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        # GPU-specific optimizations
        cuda_provider_options = {}
            'device_id': self.config.gpu_device_id,
            'arena_extend_strategy': 'kSameAsRequested',
            'gpu_mem_limit': self.config.memory_pool_size_mb * 1024 * 1024,
            'cudnn_conv_algo_search': 'HEURISTIC',
            'do_copy_in_default_stream': True,
        }
        
        providers = []
            ('CUDAExecutionProvider', cuda_provider_options),
            'CPUExecutionProvider'
        ]
        
        self.session = ort.InferenceSession()
            self.config.model_path,
            sess_options,
            providers=providers
        )
        
        # Warm up GPU
        self._warmup_gpu()
        
        logger.info("ONNX GPU backend initialized")
    
    def _initialize_tensorrt(self):
        """Initialize TensorRT for ultra-low latency GPU inference"""
        
        try:
            import tensorrt as trt
            
            # TensorRT logger
            TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
            
            # Load TensorRT engine
            with open(self.config.model_path, 'rb') as f:
                engine_data = f.read()
            
            runtime = trt.Runtime(TRT_LOGGER)
            self.engine = runtime.deserialize_cuda_engine(engine_data)
            self.context = self.engine.create_execution_context()
            
            # Allocate GPU memory for inputs/outputs
            self._allocate_tensorrt_buffers()
            
            logger.info("TensorRT backend initialized")
            
        except ImportError:
            logger.error("TensorRT not available, falling back to ONNX GPU")
            self.config.backend = InferenceBackend.ONNX_GPU
            self._initialize_onnx_gpu()
    
    def _initialize_torch_jit(self):
        """Initialize PyTorch JIT for optimized inference"""
        
        # Load JIT model
        self.model = torch.jit.load(self.config.model_path)
        self.model.eval()
        
        if self.config.use_gpu and torch.cuda.is_available():
            self.model = self.model.cuda(self.config.gpu_device_id)
        
        # Optimize for inference
        if hasattr(torch.jit, 'optimize_for_inference'):
            self.model = torch.jit.optimize_for_inference(self.model)
        
        # Warm up
        self._warmup_torch()
        
        logger.info("PyTorch JIT backend initialized")
    
    def _initialize_torch_quantized(self):
        """Initialize quantized PyTorch model for low-latency CPU inference"""
        
        # Load model
        model = torch.load(self.config.model_path, map_location='cpu')
        
        # Quantize model
        model.eval()
        model.qconfig = torch.quantization.get_default_qconfig('fbgemm')
        torch.quantization.prepare(model, inplace=True)
        torch.quantization.convert(model, inplace=True)
        
        self.model = model
        
        logger.info("PyTorch Quantized backend initialized")
    
    def _initialize_shared_memory(self):
        """Initialize shared memory for zero-copy data transfer"""
        
        try:
            # Start Plasma store if not running
            # self.plasma_client = plasma.connect("/tmp/plasma") if plasma else None
            self.plasma_client = None
            
            # Pre-allocate memory pool
            self.memory_pool = {}
            
            logger.info("Shared memory initialized")
            
        except Exception as e:
            logger.warning(f"Failed to initialize shared memory: {e}")
            self.config.use_shared_memory = False
    
    def _warmup_gpu(self):
        """Warm up GPU with dummy inference"""
        
        # Create dummy inputs
        dummy_inputs = {}
        for name, shape in self.config.input_shapes.items():
            dummy_inputs[name] = np.random.randn(*shape).astype(np.float32)
        
        # Run inference multiple times
        for _ in range(10):
            self._run_onnx_inference(dummy_inputs)
        
        logger.info("GPU warmup completed")
    
    def _warmup_torch(self):
        """Warm up PyTorch model"""
        
        # Create dummy input
        dummy_shape = list(self.config.input_shapes.values())[0]
        dummy_input = torch.randn(1, *dummy_shape[1:])
        
        if self.config.use_gpu and torch.cuda.is_available():
            dummy_input = dummy_input.cuda(self.config.gpu_device_id)
        
        # Run inference
        with torch.no_grad():
            for _ in range(10):
                _ = self.model(dummy_input)
        
        if self.config.use_gpu:
            torch.cuda.synchronize()
    
    def _allocate_tensorrt_buffers(self):
        """Allocate GPU memory for TensorRT"""
        
        import tensorrt as trt
        import pycuda.driver as cuda
        
        self.inputs = []
        self.outputs = []
        self.bindings = []
        self.stream = cuda.Stream()
        
        for binding in self.engine:
            shape = self.engine.get_binding_shape(binding)
            size = trt.volume(shape) * self.config.max_batch_size
            dtype = trt.nptype(self.engine.get_binding_dtype(binding))
            
            # Allocate host and device buffers
            host_mem = cuda.pagelocked_empty(size, dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)
            
            # Append to the appropriate list
            self.bindings.append(int(device_mem))
            
            if self.engine.binding_is_input(binding):
                self.inputs.append({'host': host_mem, 'device': device_mem})
            else:
                self.outputs.append({'host': host_mem, 'device': device_mem})
    
    @handle_errors("inference", ErrorCategory.INFERENCE, ErrorSeverity.HIGH)
    async def infer(self, request: InferenceRequest) -> InferenceResponse:
        """Perform inference on a single request"""
        
        start_time = time.perf_counter()
        
        # Check cache first
        if self.config.enable_cache:
            cached_response = self._check_cache(request)
            if cached_response:
                latency_ms = (time.perf_counter() - start_time) * 1000
                cached_response.latency_ms = latency_ms
                cached_response.cache_hit = True
                self._record_latency(latency_ms)
                return cached_response
        
        # Add to batch queue
        request.future = asyncio.Future()
        queue_start = time.perf_counter()
        
        await self.request_queue.put(request)
        
        # Wait for response
        try:
            response = await asyncio.wait_for()
                request.future,
                timeout=request.timeout_ms / 1000
            )
            
            # Update timing
            response.queue_wait_ms = (time.perf_counter() - queue_start) * 1000
            response.latency_ms = (time.perf_counter() - start_time) * 1000
            
            # Cache response
            if self.config.enable_cache:
                self._cache_response(request, response)
            
            self._record_latency(response.latency_ms)
            
            return response
            
        except asyncio.TimeoutError:
            raise HTTPException(status_code=408, detail="Inference timeout")
    
    async def batch_infer(self, requests: List[InferenceRequest]) -> List[InferenceResponse]:
        """Perform batched inference"""
        
        start_time = time.perf_counter()
        
        # Prepare batch
        batch_inputs = self._prepare_batch(requests)
        
        # Run inference based on backend
        if self.config.backend in [InferenceBackend.ONNX_CPU, InferenceBackend.ONNX_GPU]:
            outputs = await self._run_onnx_batch_inference(batch_inputs)
        elif self.config.backend == InferenceBackend.TENSORRT:
            outputs = await self._run_tensorrt_batch_inference(batch_inputs)
        elif self.config.backend in [InferenceBackend.TORCH_JIT, InferenceBackend.TORCH_QUANTIZED]:
            outputs = await self._run_torch_batch_inference(batch_inputs)
        else:
            raise ValueError(f"Unsupported backend: {self.config.backend}")
        
        # Create responses
        inference_ms = (time.perf_counter() - start_time) * 1000
        responses = self._create_batch_responses(requests, outputs, inference_ms)
        
        return responses
    
    def _prepare_batch(self, requests: List[InferenceRequest]) -> Dict[str, np.ndarray]:
        """Prepare batched inputs"""
        
        batch_inputs = {}
        
        for input_name in self.config.input_shapes:
            # Stack inputs from all requests
            input_list = [req.inputs[input_name] for req in requests]
            batch_inputs[input_name] = np.stack(input_list, axis=0)
        
        return batch_inputs
    
    async def _run_onnx_batch_inference(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Run ONNX batch inference"""
        
        # Convert to ONNX format
        ort_inputs = {name: inputs[name] for name in inputs}
        
        # Run inference
        if self.config.use_gpu:
            # Ensure GPU execution
            outputs = await asyncio.get_event_loop().run_in_executor()
                None,
                lambda: self.session.run(None, ort_inputs)
            )
        else:
            outputs = self.session.run(None, ort_inputs)
        
        # Convert to dict
        output_dict = {}
        for i, name in enumerate(self.config.output_names):
            output_dict[name] = outputs[i]
        
        return output_dict
    
    async def _run_tensorrt_batch_inference(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Run TensorRT batch inference"""
        
        import pycuda.driver as cuda
        
        # Copy inputs to GPU
        for i, input_name in enumerate(self.config.input_shapes):
            np.copyto(self.inputs[i]['host'], inputs[input_name].ravel())
            cuda.memcpy_htod_async()
                self.inputs[i]['device'],
                self.inputs[i]['host'],
                self.stream
            )
        
        # Run inference
        self.context.execute_async_v2()
            bindings=self.bindings,
            stream_handle=self.stream.handle
        )
        
        # Copy outputs from GPU
        output_dict = {}
        for i, output_name in enumerate(self.config.output_names):
            cuda.memcpy_dtoh_async()
                self.outputs[i]['host'],
                self.outputs[i]['device'],
                self.stream
            )
            self.stream.synchronize()
            
            # Reshape output
            output_shape = self.engine.get_binding_shape(output_name)
            output_dict[output_name] = self.outputs[i]['host'].reshape(output_shape)
        
        return output_dict
    
    async def _run_torch_batch_inference(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Run PyTorch batch inference"""
        
        # Convert to tensor
        input_tensor = torch.from_numpy(list(inputs.values())[0]).float()
        
        if self.config.use_gpu and torch.cuda.is_available():
            input_tensor = input_tensor.cuda(self.config.gpu_device_id)
        
        # Run inference
        with torch.no_grad():
            if self.config.use_gpu:
                torch.cuda.synchronize()
            
            output = self.model(input_tensor)
            
            if self.config.use_gpu:
                torch.cuda.synchronize()
                output = output.cpu()
        
        # Convert to numpy
        output_dict = {}
        if isinstance(output, tuple):
            for i, name in enumerate(self.config.output_names):
                output_dict[name] = output[i].numpy()
        else:
            output_dict[self.config.output_names[0]] = output.numpy()
        
        return output_dict
    
    def _create_batch_responses(self, 
                               requests: List[InferenceRequest],
                               outputs: Dict[str, np.ndarray],
                               inference_ms: float) -> List[InferenceResponse]:
        """Create individual responses from batch output"""
        
        responses = []
        batch_size = len(requests)
        
        for i, request in enumerate(requests):
            # Extract outputs for this request
            request_outputs = {}
            for name, batch_output in outputs.items():
                request_outputs[name] = batch_output[i]
            
            response = InferenceResponse()
                request_id=request.request_id,
                outputs=request_outputs,
                latency_ms=inference_ms,
                inference_ms=inference_ms / batch_size,  # Amortized
                batch_size=batch_size,
                backend_used=self.config.backend.value
            )
            
            responses.append(response)
        
        return responses
    
    def _check_cache(self, request: InferenceRequest) -> Optional[InferenceResponse]:
        """Check if request result is cached"""
        
        # Generate cache key
        cache_key = self._generate_cache_key(request)
        
        with self.cache_lock:
            if cache_key in self.cache:
                # Move to end (LRU)
                self.cache.move_to_end(cache_key)
                cached_response = self.cache[cache_key]
                
                # Check TTL
                age_seconds = (datetime.now() - cached_response.timestamp).total_seconds()
                if age_seconds < self.config.cache_ttl_seconds:
                    return cached_response
                else:
                    # Expired
                    del self.cache[cache_key]
        
        return None
    
    def _cache_response(self, request: InferenceRequest, response: InferenceResponse):
        """Cache inference response"""
        
        cache_key = self._generate_cache_key(request)
        
        with self.cache_lock:
            # Add to cache
            self.cache[cache_key] = response
            
            # Evict oldest if cache is full
            if len(self.cache) > self.config.cache_size:
                self.cache.popitem(last=False)
    
    def _generate_cache_key(self, request: InferenceRequest) -> str:
        """Generate cache key from request inputs"""
        
        # Hash inputs
        input_hashes = []
        for name in sorted(request.inputs.keys()):
            input_hash = hash(request.inputs[name].tobytes())
            input_hashes.append(f"{name}:{input_hash}")
        
        return f"{request.model_id}:{'_'.join(input_hashes)}"
    
    def _record_latency(self, latency_ms: float):
        """Record latency measurement"""
        
        self.latency_stats.update(latency_ms)
        
        # Emit metrics
        self.metrics_collector.record('inference.latency_ms', latency_ms, {)
            'model_id': self.config.model_id,
            'backend': self.config.backend.value
        })
        
        # Log if exceeds threshold
        if latency_ms > 10.0:
            logger.warning(f"High inference latency: {latency_ms:.2f}ms for model {self.config.model_id}")
    
    def _run_onnx_inference(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Run single ONNX inference (for warmup)"""
        
        outputs = self.session.run(None, inputs)
        
        output_dict = {}
        for i, name in enumerate(self.config.output_names):
            output_dict[name] = outputs[i]
        
        return output_dict


class DynamicBatchProcessor:
    """Dynamic batching processor for optimal throughput"""
    
    def __init__(self, 
                 engine: ModelInferenceEngine,
                 max_batch_size: int = 32,
                 batch_timeout_ms: float = 5.0):
        
        self.engine = engine
        self.max_batch_size = max_batch_size
        self.batch_timeout_ms = batch_timeout_ms
        
        # Request queue
        self.request_queue = asyncio.Queue()
        self.current_batch: List[InferenceRequest] = []
        self.batch_lock = asyncio.Lock()
        
        # Processing task
        self._processing_task = None
        self._running = False
        
        logger.info(f"Dynamic batch processor initialized (max_batch={max_batch_size})")
    
    async def start(self):
        """Start batch processing"""
        self._running = True
        self._processing_task = asyncio.create_task(self._process_batches())
        logger.info("Batch processor started")
    
    async def stop(self):
        """Stop batch processing"""
        self._running = False
        if self._processing_task:
            await self._processing_task
        logger.info("Batch processor stopped")
    
    async def submit_request(self, request: InferenceRequest) -> InferenceResponse:
        """Submit request for processing"""
        
        # Create future for response
        request.future = asyncio.Future()
        
        # Add to queue
        await self.request_queue.put(request)
        
        # Wait for response
        return await request.future
    
    async def _process_batches(self):
        """Main batch processing loop"""
        
        while self._running:
            try:
                # Collect batch
                batch = await self._collect_batch()
                
                if batch:
                    # Process batch
                    await self._process_batch(batch)
                
            except Exception as e:
                logger.error(f"Batch processing error: {e}")
                
                # Set error on all requests in batch
                for req in batch:
                    if req.future and not req.future.done():
                        req.future.set_exception(e)
    
    async def _collect_batch(self) -> List[InferenceRequest]:
        """Collect requests into a batch"""
        
        batch = []
        deadline = time.perf_counter() + (self.batch_timeout_ms / 1000)
        
        while len(batch) < self.max_batch_size:
            timeout = max(0, deadline - time.perf_counter())
            
            try:
                # Wait for request with timeout
                request = await asyncio.wait_for()
                    self.request_queue.get(),
                    timeout=timeout
                )
                batch.append(request)
                
                # Check if we should process immediately (high priority)
                if request.priority > 5 and len(batch) >= self.max_batch_size // 2:
                    break
                    
            except asyncio.TimeoutError:
                # Timeout reached, process what we have
                break
        
        return batch
    
    async def _process_batch(self, batch: List[InferenceRequest]):
        """Process a batch of requests"""
        
        try:
            # Run batch inference
            responses = await self.engine.batch_infer(batch)
            
            # Set responses on futures
            for request, response in zip(batch, responses):
                if request.future and not request.future.done():
                    request.future.set_result(response)
                    
        except Exception as e:
            # Set exception on all futures
            for request in batch:
                if request.future and not request.future.done():
                    request.future.set_exception(e)


class LowLatencyInferenceEndpoint:
    """Ultra-low latency inference endpoint with FastAPI"""
    
    def __init__(self, 
                 host: str = "0.0.0.0",
                 port: int = 8000,
                 num_workers: int = 1):
        
        self.host = host
        self.port = port
        self.num_workers = num_workers
        self.metrics_collector = MetricsCollector()
        
        # Model registry
        self.models: Dict[str, ModelInferenceEngine] = {}
        self.batch_processors: Dict[str, DynamicBatchProcessor] = {}
        
        # FastAPI app
        self.app = FastAPI()
            title="Low-Latency Inference API",
            default_response_class=ORJSONResponse
        )
        
        # Setup routes
        self._setup_routes()
        
        # Performance optimizations
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        
        logger.info(f"Low-latency inference endpoint initialized on {host}:{port}")
    
    def _setup_routes(self):
        """Setup FastAPI routes"""
        
        @self.app.get("/health")
        async def health():
            """Health check endpoint"""
            return {"status": "healthy", "models": list(self.models.keys())}
        
        @self.app.post("/infer/{model_id}")
        async def infer(model_id: str, request: Dict[str, Any]):
            """Single inference endpoint"""
            
            if model_id not in self.models:
                raise HTTPException(status_code=404, detail=f"Model {model_id} not found")
            
            # Parse request
            try:
                # Convert inputs to numpy arrays
                inputs = {}
                for name, values in request.get("inputs", {}).items():
                    inputs[name] = np.array(values, dtype=np.float32)
                
                # Create inference request
                inf_request = InferenceRequest()
                    request_id=request.get("request_id", str(time.time())),
                    model_id=model_id,
                    inputs=inputs,
                    priority=request.get("priority", 0),
                    timeout_ms=request.get("timeout_ms", 10.0)
                )
                
                # Submit to batch processor
                processor = self.batch_processors[model_id]
                response = await processor.submit_request(inf_request)
                
                # Convert response
                return {}
                    "request_id": response.request_id,
                    "outputs": {name: output.tolist() for name, output in response.outputs.items()},
                    "latency_ms": response.latency_ms,
                    "cache_hit": response.cache_hit
                }
                
            except Exception as e:
                logger.error(f"Inference error: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/batch_infer/{model_id}")
        async def batch_infer(model_id: str, requests: List[Dict[str, Any]]):
            """Batch inference endpoint"""
            
            if model_id not in self.models:
                raise HTTPException(status_code=404, detail=f"Model {model_id} not found")
            
            # Parse requests
            inf_requests = []
            for req in requests:
                inputs = {}
                for name, values in req.get("inputs", {}).items():
                    inputs[name] = np.array(values, dtype=np.float32)
                
                inf_request = InferenceRequest()
                    request_id=req.get("request_id", str(time.time())),
                    model_id=model_id,
                    inputs=inputs
                )
                inf_requests.append(inf_request)
            
            # Run batch inference directly
            engine = self.models[model_id]
            responses = await engine.batch_infer(inf_requests)
            
            # Convert responses
            return [{]
                "request_id": resp.request_id,
                "outputs": {name: output.tolist() for name, output in resp.outputs.items()},
                "latency_ms": resp.latency_ms
            } for resp in responses]
        
        @self.app.get("/stats/{model_id}")
        async def get_stats(model_id: str):
            """Get model inference statistics"""
            
            if model_id not in self.models:
                raise HTTPException(status_code=404, detail=f"Model {model_id} not found")
            
            stats = self.models[model_id].latency_stats
            
            return {}
                "model_id": model_id,
                "total_requests": stats.count,
                "average_latency_ms": stats.avg_ms,
                "min_latency_ms": stats.min_ms,
                "max_latency_ms": stats.max_ms,
                "p50_latency_ms": stats.p50_ms,
                "p95_latency_ms": stats.p95_ms,
                "p99_latency_ms": stats.p99_ms
            }
    
    async def register_model(self, config: ModelConfig):
        """Register a model for inference"""
        
        # Create inference engine
        engine = ModelInferenceEngine(config)
        self.models[config.model_id] = engine
        
        # Create batch processor
        processor = DynamicBatchProcessor()
            engine,
            max_batch_size=config.max_batch_size,
            batch_timeout_ms=config.batch_timeout_ms
        )
        await processor.start()
        self.batch_processors[config.model_id] = processor
        
        logger.info(f"Model {config.model_id} registered for inference")
    
    async def unregister_model(self, model_id: str):
        """Unregister a model"""
        
        if model_id in self.batch_processors:
            await self.batch_processors[model_id].stop()
            del self.batch_processors[model_id]
        
        if model_id in self.models:
            del self.models[model_id]
        
        logger.info(f"Model {model_id} unregistered")
    
    def run(self):
        """Run the inference endpoint"""
        
        import uvicorn
        
        uvicorn.run()
            self.app,
            host=self.host,
            port=self.port,
            workers=self.num_workers,
            loop="uvloop",
            log_level="warning"
        )


# Numba-accelerated preprocessing functions
@jit(nopython=True, parallel=True)
def normalize_features_numba(features: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    """Fast feature normalization using Numba"""
    return (features - mean) / std


@jit(nopython=True)
def quantize_features_numba(features: np.ndarray, scale: float, zero_point: int) -> np.ndarray:
    """Fast feature quantization using Numba"""
    return np.round(features / scale + zero_point).astype(np.int8)


# CUDA kernels for GPU preprocessing
CUDA_AVAILABLE = False
try:
    from numba import cuda
    CUDA_AVAILABLE = cuda.is_available()
except:
    pass

if CUDA_AVAILABLE:
    @cuda.jit
    def normalize_features_cuda(features, mean, std, output):
        """CUDA kernel for feature normalization"""
        i, j = cuda.grid(2)
        if i < features.shape[0] and j < features.shape[1]:
            output[i, j] = (features[i, j] - mean[j]) / std[j]


class OptimizedPreprocessor:
    """Optimized preprocessor for ultra-low latency"""
    
    def __init__(self, use_gpu: bool = True):
        self.use_gpu = use_gpu and CUDA_AVAILABLE
        
        # Pre-computed statistics
        self.feature_mean = None
        self.feature_std = None
        self.quantization_scale = 0.1
        self.quantization_zero_point = 0
        
    def fit(self, training_data: np.ndarray):
        """Fit preprocessor on training data"""
        self.feature_mean = np.mean(training_data, axis=0).astype(np.float32)
        self.feature_std = np.std(training_data, axis=0).astype(np.float32) + 1e-7
        
        # Calculate quantization parameters
        min_val = np.min(training_data)
        max_val = np.max(training_data)
        self.quantization_scale = (max_val - min_val) / 255.0
        self.quantization_zero_point = int(-min_val / self.quantization_scale)
    
    def transform(self, features: np.ndarray) -> np.ndarray:
        """Transform features with minimal latency"""
        
        if self.use_gpu:
            return self._transform_gpu(features)
        else:
            return self._transform_cpu(features)
    
    def _transform_cpu(self, features: np.ndarray) -> np.ndarray:
        """CPU transformation using Numba"""
        return normalize_features_numba(features, self.feature_mean, self.feature_std)
    
    def _transform_gpu(self, features: np.ndarray) -> np.ndarray:
        """GPU transformation using CUDA"""
        
        # Transfer to GPU
        features_gpu = cuda.to_device(features)
        mean_gpu = cuda.to_device(self.feature_mean)
        std_gpu = cuda.to_device(self.feature_std)
        output_gpu = cuda.device_array_like(features_gpu)
        
        # Configure grid
        threads_per_block = (16, 16)
        blocks_per_grid = ()
            (features.shape[0] + threads_per_block[0] - 1) // threads_per_block[0],
            (features.shape[1] + threads_per_block[1] - 1) // threads_per_block[1]
        )
        
        # Launch kernel
        normalize_features_cuda[blocks_per_grid, threads_per_block]()
            features_gpu, mean_gpu, std_gpu, output_gpu
        )
        
        # Transfer back
        return output_gpu.copy_to_host()


# Integration function
def integrate_low_latency_inference(master_system):
    """
    Integrate low-latency inference endpoint with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from low_latency_inference_endpoint import integrate_low_latency_inference
    integrate_low_latency_inference(self)
    """
    
    # Create inference endpoint
    master_system.inference_endpoint = LowLatencyInferenceEndpoint()
        host="0.0.0.0",
        port=8000,
        num_workers=4
    )
    
    # Add methods
    async def register_model_for_inference(self, model_id: str, model_path: str,
                                         backend: InferenceBackend,
                                         input_shapes: Dict[str, List[int]],
                                         output_names: List[str],
                                         **kwargs):
        """Register a model for low-latency inference"""
        
        config = ModelConfig()
            model_id=model_id,
            model_path=model_path,
            backend=backend,
            input_shapes=input_shapes,
            output_names=output_names,
            **kwargs
        )
        
        await self.inference_endpoint.register_model(config)
    
    async def run_inference(self, model_id: str, inputs: Dict[str, np.ndarray],
                          priority: int = 0, timeout_ms: float = 10.0) -> Dict[str, np.ndarray]:
        """Run low-latency inference"""
        
        request = InferenceRequest()
            request_id=str(time.time()),
            model_id=model_id,
            inputs=inputs,
            priority=priority,
            timeout_ms=timeout_ms
        )
        
        processor = self.inference_endpoint.batch_processors[model_id]
        response = await processor.submit_request(request)
        
        return response.outputs
    
    def get_inference_stats(self, model_id: str) -> Dict[str, float]:
        """Get inference latency statistics"""
        
        if model_id not in self.inference_endpoint.models:
            return {}
        
        stats = self.inference_endpoint.models[model_id].latency_stats
        
        return {}
            "avg_latency_ms": stats.avg_ms,
            "min_latency_ms": stats.min_ms,
            "max_latency_ms": stats.max_ms,
            "p50_latency_ms": stats.p50_ms,
            "p95_latency_ms": stats.p95_ms,
            "p99_latency_ms": stats.p99_ms,
            "total_requests": stats.count
        }
    
    # Bind methods
    master_system.register_model_for_inference = register_model_for_inference.__get__(master_system)
    master_system.run_inference = run_inference.__get__(master_system)
    master_system.get_inference_stats = get_inference_stats.__get__(master_system)
    
    logger.info("Low-latency inference endpoint integrated with master system")


if __name__ == "__main__":
    # Example usage
    import asyncio
    
    async def test_inference():
        # Create endpoint
        endpoint = LowLatencyInferenceEndpoint()
        
        # Register a test model (would use real model in production)
        config = ModelConfig()
            model_id="price_predictor",
            model_path="models/price_predictor.onnx",  # Path to ONNX model
            backend=InferenceBackend.ONNX_GPU,
            input_shapes={"features": [1, 10]},  # Batch size x features
            output_names=["price_prediction"],
            max_batch_size=32,
            batch_timeout_ms=5.0,
            enable_cache=True
        )
        
        # In production, would register real model
        # await endpoint.register_model(config)
        
        print("Low-Latency Inference Endpoint Test")
        print("=" * 60)
        
        # Simulate inference requests
        print("\nSimulating inference requests...")
        
        # Create test inputs
        test_features = np.random.randn(10).astype(np.float32)
        
        # Single inference
        request = {}
            "inputs": {}
                "features": test_features.tolist()
            },
            "request_id": "test_001",
            "priority": 1,
            "timeout_ms": 10.0
        }
        
        print(f"\nTest request: {request}")
        
        # Batch inference
        batch_requests = []
            {}
                "inputs": {}
                    "features": np.random.randn(10).tolist()
                },
                "request_id": f"batch_{i}"
            }
            for i in range(5)
        ]
        
        print(f"\nBatch size: {len(batch_requests)}")
        
        # Performance test
        print("\n\nPerformance Test Results:")
        print("-" * 40)
        
        # Test preprocessing speed
        preprocessor = OptimizedPreprocessor(use_gpu=CUDA_AVAILABLE)
        test_data = np.random.randn(1000, 10).astype(np.float32)
        preprocessor.fit(test_data)
        
        # CPU preprocessing
        start = time.perf_counter()
        for _ in range(1000):
            _ = preprocessor._transform_cpu(test_features.reshape(1, -1))
        cpu_time = (time.perf_counter() - start) / 1000 * 1000  # ms
        
        print(f"CPU Preprocessing: {cpu_time:.3f} ms")
        
        if CUDA_AVAILABLE:
            # GPU preprocessing
            start = time.perf_counter()
            for _ in range(1000):
                _ = preprocessor._transform_gpu(test_features.reshape(1, -1))
            gpu_time = (time.perf_counter() - start) / 1000 * 1000  # ms
            
            print(f"GPU Preprocessing: {gpu_time:.3f} ms")
            print(f"GPU Speedup: {cpu_time/gpu_time:.1f}x")
        
        # Test latency stats
        stats = LatencyStats()
        for i in range(100):
            latency = np.random.gamma(2, 2)  # Simulate latency distribution
            stats.update(latency)
        
        print(f"\nSimulated Latency Statistics:")
        print(f"  Average: {stats.avg_ms:.2f} ms")
        print(f"  Min: {stats.min_ms:.2f} ms")
        print(f"  Max: {stats.max_ms:.2f} ms")
        print(f"  P50: {stats.p50_ms:.2f} ms")
        print(f"  P95: {stats.p95_ms:.2f} ms")
        print(f"  P99: {stats.p99_ms:.2f} ms")
        
        print("\n\nTo run the inference server:")
        print("python low_latency_inference_endpoint.py --serve")
        
        print("\nEndpoint URLs:")
        print("  Health: http://localhost:8000/health")
        print("  Inference: POST http://localhost:8000/infer/{model_id}")
        print("  Batch: POST http://localhost:8000/batch_infer/{model_id}")
        print("  Stats: GET http://localhost:8000/stats/{model_id}")
    
    # Check if serving
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--serve":
        # Run server
        endpoint = LowLatencyInferenceEndpoint()
        endpoint.run()
    else:
        # Run test
        asyncio.run(test_inference())