#!/usr/bin/env python3
"""
Enhanced MinIO Algorithm Integration
====================================
Integrates MinIO historical data with trading algorithms to improve performance
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple
import subprocess
import json
from pathlib import Path
from dotenv import load_dotenv

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Load environment variables
load_dotenv()

# Import existing trading components
try:
    from portfolio_optimization_mpt import ModernPortfolioTheory
    from advanced_risk_management_system import AdvancedRiskManager
    from v27_lightweight_ml_models import LightweightEnsemble, LightweightFeatureEngineering
    from monte_carlo_backtesting import MonteCarloBacktester
except ImportError as e:
    print(f"Warning: Some components not available: {e}")

class EnhancedMinIOIntegration:
    """Enhanced integration of MinIO data with trading algorithms"""
    
    def __init__(self):
        self.mc_path = "./mc"
        self.alias = "uschristmas"
        self.bucket = os.getenv('MINIO_BUCKET', 'stockdb')
        self.cache_dir = "./minio_cache"
        self.enhanced_dir = "./enhanced_algorithms"
        
        # Create directories
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(self.enhanced_dir, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
    def download_sample_data(self) -> pd.DataFrame:
        """Download and load sample data for testing"""
        # Download sample stock data
        stock_file = os.path.join(self.cache_dir, "2022-08-24stocks.csv")
        
        if not os.path.exists(stock_file):
            self.logger.info("Downloading sample stock data...")
            cmd = f"{self.mc_path} cp {self.alias}/{self.bucket}/samples/2022-08-24/2022-08-24stocks.csv {stock_file}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"Failed to download sample data: {result.stderr}")
                
        # Load data
        df = pd.read_csv(stock_file)
        self.logger.info(f"Loaded {len(df)} stock records from sample data")
        
        return df
    
    def enhance_portfolio_optimization_with_minio(self) -> Dict[str, any]:
        """Enhance portfolio optimization using MinIO data"""
        self.logger.info("Enhancing portfolio optimization with MinIO data")
        
        # Load sample data
        df = self.download_sample_data()
        
        # Filter for liquid stocks (high volume)
        liquid_stocks = df[df['volume'] > 1000000].copy()
        liquid_stocks = liquid_stocks.sort_values('volume', ascending=False).head(50)
        
        # Calculate metrics for portfolio optimization
        metrics = {}
        
        for _, row in liquid_stocks.iterrows():
            symbol = row['symbol']
            
            # Calculate simple metrics from available data
            price_range = (row['high'] - row['low']) / row['close']
            volume_ratio = row['volume'] / liquid_stocks['volume'].mean()
            
            metrics[symbol] = {}
                'close_price': row['close'],
                'volume': row['volume'],
                'volatility_proxy': price_range,  # Daily range as volatility proxy
                'liquidity_score': min(volume_ratio, 2.0),  # Cap at 2x average
                'momentum': (row['close'] - row['open']) / row['open']
            }
            
        # Create enhanced portfolio optimizer
        enhanced_optimizer = {}
            'universe': list(metrics.keys(),
            'metrics': metrics,
            'recommendations': self._generate_portfolio_recommendations(metrics),
            'risk_factors': self._calculate_risk_factors(liquid_stocks)
        }
        
        # Save enhanced configuration
        with open(os.path.join(self.enhanced_dir, "enhanced_portfolio_config.json"), "w") as f:
            json.dump(enhanced_optimizer, f, indent=2)
            
        self.logger.info(f"Enhanced portfolio optimization for {len(metrics)} symbols")
        
        return enhanced_optimizer
    
    def _generate_portfolio_recommendations(self, metrics: Dict) -> Dict[str, float]:
        """Generate portfolio weight recommendations based on metrics"""
        recommendations = {}
        
        # Score each stock
        scores = {}
        for symbol, data in metrics.items():
            # Simple scoring based on liquidity and low volatility
            liquidity_score = data['liquidity_score']
            volatility_penalty = 1 / (1 + data['volatility_proxy'])
            
            scores[symbol] = liquidity_score * volatility_penalty
            
        # Normalize to weights (top 20 stocks)
        top_symbols = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:20]
        total_score = sum(score for _, score in top_symbols)
        
        for symbol, score in top_symbols:
            recommendations[symbol] = score / total_score
            
        return recommendations
    
    def _calculate_risk_factors(self, df: pd.DataFrame) -> Dict[str, any]:
        """Calculate risk factors from data"""
        return {}
            'market_volatility': df['volume'].std() / df['volume'].mean(),
            'price_dispersion': df['close'].std() / df['close'].mean(),
            'liquidity_concentration': df['volume'].head(10).sum() / df['volume'].sum()
        }
    
    def enhance_risk_management_with_minio(self) -> Dict[str, any]:
        """Enhance risk management using MinIO data"""
        self.logger.info("Enhancing risk management with MinIO data")
        
        # Load sample data
        df = self.download_sample_data()
        
        # Calculate market-wide risk metrics
        risk_metrics = {}
            'market_breadth': {}
                'advancing': len(df[df['close'] > df['open']]),
                'declining': len(df[df['close'] < df['open']]),
                'unchanged': len(df[df['close'] == df['open']])
            },
            'volatility_distribution': {}
                'high_volatility': len(df[(df['high'] - df['low']) / df['close'] > 0.03]),
                'medium_volatility': len(df[(df['high'] - df['low']) / df['close'] > 0.01]),
                'low_volatility': len(df[(df['high'] - df['low']) / df['close'] <= 0.01])
            },
            'liquidity_analysis': {}
                'total_volume': df['volume'].sum(),
                'average_volume': df['volume'].mean(),
                'volume_concentration': df.nlargest(20, 'volume')['volume'].sum() / df['volume'].sum()
            }
        }
        
        # Identify high-risk symbols
        df['volatility'] = (df['high'] - df['low']) / df['close']
        high_risk_symbols = df[df['volatility'] > df['volatility'].quantile(0.9)]['symbol'].tolist()
        
        enhanced_risk = {}
            'market_metrics': risk_metrics,
            'high_risk_symbols': high_risk_symbols,
            'risk_limits': {}
                'max_position_volatility': df['volatility'].quantile(0.8),
                'min_liquidity_requirement': df['volume'].quantile(0.2),
                'concentration_limit': 0.05  # 5% max per position
            }
        }
        
        # Save enhanced risk configuration
        with open(os.path.join(self.enhanced_dir, "enhanced_risk_config.json"), "w") as f:
            json.dump(enhanced_risk, f, indent=2, default=str)
            
        return enhanced_risk
    
    def enhance_ml_models_with_minio(self) -> pd.DataFrame:
        """Create enhanced ML training features from MinIO data"""
        self.logger.info("Creating enhanced ML features from MinIO data")
        
        # Load sample data
        df = self.download_sample_data()
        
        # Create ML features
        ml_features = df.copy()
        
        # Price-based features
        ml_features['price_range'] = (df['high'] - df['low']) / df['close']
        ml_features['close_to_high'] = (df['high'] - df['close']) / df['high']
        ml_features['close_to_low'] = (df['close'] - df['low']) / df['low']
        ml_features['open_close_ratio'] = df['close'] / df['open']
        
        # Volume features
        ml_features['volume_zscore'] = (df['volume'] - df['volume'].mean() / df['volume'].std())
        ml_features['volume_rank'] = df['volume'].rank(pct=True)
        
        # Market microstructure
        ml_features['bid_ask_proxy'] = (df['high'] - df['low']) / 2
        ml_features['price_efficiency'] = abs(df['close'] - (df['high'] + df['low']) / 2) / df['close']
        
        # Sector/Market features (would need sector data)
        ml_features['relative_volume'] = df['volume'] / df['volume'].mean()
        ml_features['relative_price'] = df['close'] / df['close'].mean()
        
        # Save ML features
        ml_features.to_csv(os.path.join(self.enhanced_dir, "ml_training_features.csv"), index=False)
        
        self.logger.info(f"Created {len(ml_features.columns)} ML features for {len(ml_features)} stocks")
        
        return ml_features
    
    def create_backtesting_universe(self) -> Dict[str, List[str]]:
        """Create universe of stocks for backtesting"""
        self.logger.info("Creating backtesting universe from MinIO data")
        
        # Load sample data
        df = self.download_sample_data()
        
        # Categorize stocks by characteristics
        universe = {}
            'large_cap': df[df['close'] > 100]['symbol'].tolist()[:20],
            'high_volume': df.nlargest(30, 'volume')['symbol'].tolist(),
            'momentum': df[(df['close'] > df['open']) & (df['volume'] > 500000)]['symbol'].tolist()[:20],
            'value': df[(df['close'] < 50) & (df['volume'] > 100000)]['symbol'].tolist()[:20],
            'tech_sector': [s for s in df['symbol'] if s in ['AAPL', 'MSFT', 'GOOGL', 'META', 'NVDA', 'AMD', 'INTC']],
            'etfs': [s for s in df['symbol'] if any(etf in s for etf in ['SPY', 'QQQ', 'IWM', 'DIA', 'VTI'])]
        }
        
        # Save universe configuration
        with open(os.path.join(self.enhanced_dir, "backtesting_universe.json"), "w") as f:
            json.dump(universe, f, indent=2)
            
        return universe
    
    def generate_integration_report(self) -> Dict[str, any]:
        """Generate comprehensive integration report"""
        self.logger.info("Generating MinIO integration report")
        
        report = {}
            'timestamp': datetime.now().isoformat(),
            'data_source': 'MinIO stockdb',
            'enhancements': {}
                'portfolio_optimization': self.enhance_portfolio_optimization_with_minio(),
                'risk_management': self.enhance_risk_management_with_minio(),
                'ml_features': f"{len(self.enhance_ml_models_with_minio().columns)} features created",
                'backtesting_universe': self.create_backtesting_universe()
            },
            'recommendations': {}
                'data_freshness': "Consider downloading more recent data for production use",
                'data_quality': "Implement data validation and cleaning pipelines",
                'feature_engineering': "Add technical indicators and fundamental data",
                'backtesting': "Use multiple years of data for robust backtesting"
            }
        }
        
        # Save report
        with open(os.path.join(self.enhanced_dir, "integration_report.json"), "w") as f:
            json.dump(report, f, indent=2, default=str)
            
        return report


def demonstrate_enhanced_algorithms():
    """Demonstrate enhanced trading algorithms with MinIO data"""
    print("🚀 Enhanced Trading Algorithms with MinIO Data")
    print("=" * 60)
    
    # Initialize integration
    integration = EnhancedMinIOIntegration()
    
    # 1. Enhanced Portfolio Optimization
    print("\n📊 Enhanced Portfolio Optimization")
    print("-" * 40)
    
    portfolio_config = integration.enhance_portfolio_optimization_with_minio()
    
    print(f"Universe: {len(portfolio_config['universe'])} liquid stocks")
    print(f"Top 5 recommendations:")
    
    top_5 = sorted(portfolio_config['recommendations'].items(), 
                   key=lambda x: x[1], reverse=True)[:5]
    
    for symbol, weight in top_5:
        metrics = portfolio_config['metrics'][symbol]
        print(f"  {symbol}: {weight:.2%} (volume: {metrics['volume']:,})")
        
    # 2. Enhanced Risk Management
    print("\n🛡️ Enhanced Risk Management")
    print("-" * 40)
    
    risk_config = integration.enhance_risk_management_with_minio()
    
    market_breadth = risk_config['market_metrics']['market_breadth']
    print(f"Market Breadth: {market_breadth['advancing']} advancing, ")
          f"{market_breadth['declining']} declining")
    
    print(f"High Risk Symbols: {len(risk_config['high_risk_symbols'])}")
    print(f"Volume Concentration: ")
          f"{risk_config['market_metrics']['liquidity_analysis']['volume_concentration']:.1%}")
    
    # 3. ML Feature Engineering
    print("\n🧠 ML Feature Engineering")
    print("-" * 40)
    
    ml_features = integration.enhance_ml_models_with_minio()
    
    print(f"Created {len(ml_features.columns)} features for {len(ml_features)} stocks")
    print(f"Feature categories:")
    print("  • Price-based features")
    print("  • Volume features")
    print("  • Market microstructure")
    print("  • Relative metrics")
    
    # 4. Backtesting Universe
    print("\n🔄 Backtesting Universe")
    print("-" * 40)
    
    universe = integration.create_backtesting_universe()
    
    for category, symbols in universe.items():
        print(f"{category}: {len(symbols)} stocks")
        
    # 5. Integration Summary
    print("\n✅ Integration Complete!")
    print("-" * 40)
    
    report = integration.generate_integration_report()
    
    print("Enhanced components:")
    print("  ✓ Portfolio optimization with liquidity filtering")
    print("  ✓ Risk management with market-wide metrics")
    print("  ✓ ML features for prediction models")
    print("  ✓ Categorized universe for backtesting")
    print("  ✓ Integration report generated")
    
    print(f"\nAll configurations saved to: {integration.enhanced_dir}/")
    
    return integration


def integrate_with_existing_algorithms():
    """Show how to integrate MinIO data with existing algorithms"""
    print("\n🔗 Integrating with Existing Algorithms")
    print("=" * 60)
    
    # Example integrations
    print("\n1. Portfolio Optimization Integration:")
    print("   - Load enhanced universe from MinIO")
    print("   - Use historical volatility estimates")
    print("   - Apply liquidity constraints")
    
    print("\n2. Risk Management Integration:")
    print("   - Use market breadth indicators")
    print("   - Apply high-risk symbol filters")
    print("   - Implement volume-based position limits")
    
    print("\n3. ML Model Integration:")
    print("   - Load pre-engineered features")
    print("   - Use for training ensemble models")
    print("   - Validate on out-of-sample MinIO data")
    
    print("\n4. Backtesting Integration:")
    print("   - Use categorized universes")
    print("   - Apply realistic volume constraints")
    print("   - Test strategies on different market segments")


if __name__ == "__main__":
    # Run demonstration
    integration = demonstrate_enhanced_algorithms()
    
    # Show integration examples
    integrate_with_existing_algorithms()
    
    print("\n🎯 Next Steps:")
    print("1. Download historical year data when zip extraction is fixed")
    print("2. Implement streaming data updates from MinIO")
    print("3. Create automated data pipeline for daily updates")
    print("4. Integrate with production trading system")
    print("5. Set up monitoring and alerts for data quality")