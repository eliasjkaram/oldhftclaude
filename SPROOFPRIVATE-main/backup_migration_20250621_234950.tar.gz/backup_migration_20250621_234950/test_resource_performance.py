#!/usr/bin/env python3
"""
Resource Management and Performance Optimization Test Suite
==========================================================

This test suite validates:
- Memory management and leak detection
- Database connection pooling
- API rate limiting
- Caching strategies
- Concurrent request handling
- Performance benchmarks
- Resource cleanup
"""

import unittest
import asyncio
import time
import threading
import gc
import psutil
import sqlite3
import tempfile
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from datetime import datetime, timedelta
import aiohttp
from typing import List, Dict, Any
import weakref

# Import from production fixes
from PRODUCTION_FIXES import ()
from universal_market_data import get_current_market_data, get_realistic_price
    ResourceManager,
    PerformanceOptimizer,
    ResilientAPIClient,
    SafeDatabase
)


class ResourceMonitor:
    """Monitor system resources for testing"""
    
    def __init__(self):
        self.process = psutil.Process()
        self.initial_memory = None
        self.initial_handles = None
        self.initial_threads = None
        self._cache = {}
    
    def start_monitoring(self):
        """Start resource monitoring"""
        gc.collect()  # Force garbage collection
        self.initial_memory = self.process.memory_info().rss
        self.initial_handles = len(self.process.open_files())
        self.initial_threads = self.process.num_threads()
    
    def get_resource_usage(self) -> Dict[str, Any]:
        """Get current resource usage"""
        gc.collect()  # Force garbage collection
        current_memory = self.process.memory_info().rss
        current_handles = len(self.process.open_files())
        current_threads = self.process.num_threads()
        
        return {}
            'memory_mb': current_memory / 1024 / 1024,
            'memory_delta_mb': (current_memory - self.initial_memory) / 1024 / 1024 if self.initial_memory else 0,
            'open_files': current_handles,
            'file_delta': current_handles - self.initial_handles if self.initial_handles else 0,
            'threads': current_threads,
            'thread_delta': current_threads - self.initial_threads if self.initial_threads else 0,
            'cpu_percent': self.process.cpu_percent(interval=0.1)
        }


class TestMemoryManagement(unittest.TestCase):
    """Test memory management and leak detection"""
    
    def setUp(self):
        """Set up resource monitor"""
        self.monitor = ResourceMonitor()
    
    def test_no_memory_leak_in_resource_manager(self):
        """Test ResourceManager doesn't leak memory"""
        self.monitor.start_monitoring()
        
        manager = ResourceManager()
        
        # Create and cleanup many resources
        for _ in range(100):
            with patch('aiohttp.ClientSession') as mock_session_class:
                mock_session = MagicMock()
                mock_session.close = AsyncMock()
                mock_session_class.return_value = mock_session
                
                with manager.managed_session() as session:
                    pass
        
        # Cleanup
        asyncio.run(manager.cleanup_all())
        
        # Check memory usage
        usage = self.monitor.get_resource_usage()
        
        # Memory increase should be minimal (< 10MB)
        self.assertLess(usage['memory_delta_mb'], 10)
    
    def test_weak_references_for_caching(self):
        """Test using weak references to prevent memory leaks"""
        class CacheWithWeakRefs:
            def __init__(self):
                self._cache = weakref.WeakValueDictionary()
            
            def set(self, key, value):
                self._cache[key] = value
            
            def get(self, key):
                return self._cache.get(key)
        
        cache = CacheWithWeakRefs()
        
        # Create large object
        class LargeObject:
            def __init__(self):
                self.data = [0] * 1000000  # ~8MB
        
        # Store in cache
        obj = LargeObject()
        cache.set('key1', obj)
        self.assertIsNotNone(cache.get('key1'))
        
        # Delete reference
        del obj
        gc.collect()
        
        # Object should be garbage collected
        self.assertIsNone(cache.get('key1'))
    
    def test_circular_reference_handling(self):
        """Test handling of circular references"""
        class Node:
            d
                self.value = value
                self.next = None
        self._cache = {}
        
        # Create circular reference
        node1 = Node(1)
        node2 = Node(2)
        node1.next = node2
        node2.next = node1
        
        # Track with weak reference
        weak_ref = weakref.ref(node1)
        
        # Delete references
        del node1
        del node2
        
        # Force garbage collection
        gc.collect()
        
        # Objects should be collected despite circular reference
        self.assertIsNone(weak_ref())
    rtIsNone(weak_ref())
    
    def test_memory_pool_for_frequent_allocations(self):
        """Test memory pooling for frequent allocations"""
        class ObjectPool:
   
                self.factory = factory
                self.pool = []
                self.max_size = max_size
        self._cache = {}
            
            def acquire(self):
                if self.pool:
                    return self.pool.pop()
                return self.factory()
            
            def release(self, obj):
                if len(self.pool) < self.max_size:
                    # Reset object state here if needed
                    self.pool.append(obj)
        
        # Test with dictionary pool
        dict_pool = ObjectPool(dict)
        
        # Acquire and release many objects
        for _ in range(1000):
            obj = dict_pool.acquire()
            obj['data'] = 'test'
            dict_pool.release(obj)
        
        # Pool should have objects ready
        self.assertGreater(len(dict_pool.pool), 0)
        self.assertLessEqual(len(dict_pool.pool), dict_pool.max_size)
essEqual(len(dict_pool.pool), dict_pool.max_size)


class TestDatabaseConnectionPooling(unittest.TestCase):
    """Test database connection pooling"""
    
    def test_connection_pool_implementation(self):
        """Test basic connection pool implementation"""
        class 
                self.db_path = db_path
                self.max_connections = max_connections
                self.pool = []
                self.in_use = set()
                self.lock = threading.Lock()
            
            def get_connection(self):
                with self.lock:
                    # Reuse from pool if available
                    if self.pool:
                        conn = self.pool.pop()
                    else:
                        conn = sqlite3.connect(self.db_path)
        self._cache = {}
                    
                    self.in_use.add(conn)
                    return conn
            
            def release_connection(self, conn):
                with self.lock:
                    self.in_use.discard(conn)
                    
                    if len(self.pool) < self.max_connections:
                        self.pool.append(conn)
                    else:
                        conn.close()
            
            def close_all(self):
                with self.lock:
                    for conn in self.pool:
                        conn.close()
                    self.pool.clear()
                    
                    for conn in self.in_use:
                        conn.close()
                    self.in_use.clear()
        
        # Test the pool
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            db_path = tmp.name
        
        try:
            pool = ConnectionPool(db_path, max_connections=3)
            
            # Get multiple connections
            connections = []
            for _ in range(5):
                conn = pool.get_connection()
                connections.append(conn)
            
            # Should have 5 in use
            self.assertEqual(len(pool.in_use), 5)
            
            # Release connections
            for conn in connections:
                pool.release_connection(conn)
            
            # Pool should have max 3
            self.assertLessEqual(len(pool.pool), 3)
            
            # Cleanup
            pool.close_all()
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_connection_pool_thread_safety(self):
        """Test connection pool thread safety"""
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            db_path = tmp.name
        
        try:
            # Simple thread-safe pool using SafeDatabase
            active_connections = []
            lock = threading.Lock()
            
            def worker():
                conn = sqlite3.connect(db_path)
                with lock:
                    active_connections.append(conn)
                
                try:
                    # Perform database operations
                    SafeDatabase.execute_query()
                        conn,
                        "CREATE TABLE IF NOT EXISTS test (id INTEGER, value TEXT)"
                    )
                    
                    for i in range(10):
                        SafeDatabase.execute_query()
                            conn,
                            "INSERT INTO test (id, value) VALUES (?, ?)",
                            (i, f"value_{i}")
                        )
                finally:
                    conn.close()
                    with lock:
                        active_connections.remove(conn)
            
            # Run concurrent workers
            threads = []
            for _ in range(10):
                t = threading.Thread(target=worker)
                threads.append(t)
                t.start()
            
            # Wait for completion
            for t in threads:
                t.join()
            
            # All connections should be closed
            self.assertEqual(len(active_connections), 0)
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)


class TestAPIRateLimiting(unittest.TestCase):
    """Test API rate limiting and throttling"""
    
    def test_rate_limiter_implementation(self):
        """Test basic rate limiter imp
                self.max_requests = max_requests
                self.time_window = time_window  # seconds
                self.requests = []
                self.lock = threading.Lock()
            
            def allow_request(self) -> bool:
                with self.lock:
                    now = time.time()
                    
                    # Remove old requests outside time window
                    self.requests = []
                        req_time for req_time in self.requests
                        if now - req_time < self.time_window
                    ]
                    
                    # Check if we can make request
                    if len(self.requests) < self.max_requests:
                        self.requests.append(now)
                        return True
                    
                    return False
            
            def time_until_next_request(self) -> float:
                with self.lock:
                    if not self.requests:
                        return 0.0
                    
                    oldest_request = min(self.requests)
                    time_elapsed = time.time() - oldest_request
                    
                    if time_elapsed >= self.time_window:
        self._cache = {}
                        return 0.0
                    
                    return self.time_window - time_elapsed
        
        # Test rate limiter
        limiter = RateLimiter(max_requests=5, time_window=1.0)
        
        # Should allow first 5 requests
        for i in range(5):
            self.assertTrue(limiter.allow_request())
        
        # 6th request should be denied
        self.assertFalse(limiter.allow_request())
        
        # Wait for window to pass
        wait_time = limiter.time_until_next_request()
        self.assertGreater(wait_time, 0)
        
        time.sleep(wait_time + 0.1)
        
        # Should allow request now
        self.assertTrue(limiter.allow_request())
    1)
        
        # Should allow request now
        self.assertTrue(limiter.allow_request())
    
    def test_token_bucket_algorithm(self):
        """T
                self.capacity = capacity
                self.tokens = capacity
                self.refill_rate = refill_rate  # tokens per second
                self.last_refill = time.time()
                self.lock = threading.Lock()
            
            def consume(self, tokens=1) -> bool:
                with self.lock:
                    self._refill()
                    
                    if self.tokens >= tokens:
                        self.tokens -= tokens
                        return True
                    return False
            
            def _refill(self):
                now = time.time()
                elapsed = now - self.last_refill
                
                # Add tokens based on elapsed time
                tokens_to_add = elapsed * self.refill_rate
                self.tokens = min(self.capacity, self.tokens + tokens_to_add)
                self.last_refill = now
        self._cache = {}
        
        # Test token bucket
        bucket = TokenBucket(capacity=10, refill_rate=5)
        
        # Consume all tokens
        for _ in range(10):
            self.assertTrue(bucket.consume())
        
        # Should be empty
        self.assertFalse(bucket.consume())
        
        # Wait for refill
        time.sleep(0.5)  # Should refill 2.5 tokens
        
        # Should allow 2 requests
        self.assertTrue(bucket.consume())
        self.assertFalse(bucket.consume())
      self.assertTrue(bucket.consume())
        self.assertTrue(bucket.consume())
        self.assertFalse(bucket.consume())


class TestCachingStrategies(unittest.TestCase):
    """Test various caching strategies"""
    
    def test_lru_cache_implementation(self):
        """T
                self.capacity = capacity
                self.cache = OrderedDict()
                self.lock = threading.Lock()
            
            def get(self, key):
                with self.lock:
                    if key not in self.cache:
                        return None
                    
                    # Move to end (most recently used)
                    self.cache.move_to_end(key)
                    return self.cache[key]
            
            def put(self, key, value):
                with self.lock:
                    if key in self.cache:
                        # Update and move to end
                        self.cache.move_to_end(key)
                        self.cache[key] = value
                    else:
                        self.cache[key] = value
                        
                        # Remove least recently used if over capacity
                        if len(self.cache) > self.capacity:
                            self.cache.popitem(last=False)
        self._cache = {}
            
            def clear(self):
                with self.lock:
                    self.cache.clear()
        
        # Test LRU behavior
        cache = LRUCache(capacity=3)
        
        # Fill cache
        cache.put('a', 1)
        cache.put('b', 2)
        cache.put('c', 3)
        
        # Access 'a' to make it recently used
        self.assertEqual(cache.get('a'), 1)
        
        # Add new item, 'b' should be evicted
        cache.put('d', 4)
        
        self.assertIsNone(cache.get('b'))
        self.assertEqual(cache.get('a'), 1)
        self.assertEqual(cache.get('c'), 3)
        self.assertEqual(cache.get('d'), 4)
    che.get('b'))
        self.assertEqual(cache.get('a'), 1)
        self.assertEqual(cache.get('c'), 3)
        self.assertEqual(cache.get('d'), 4)
    
    def test_ttl_cache_with_performance_optimizer(self):
        """Test TTL cache using PerformanceOptimizer"""
        optimizer = PerformanceOptimizer()
        
        call_count = 0
        
        @optimizer.memoize(ttl_seconds=0.5)
        def expensive_calculation(x, y):
            nonlocal call_count
            call_count += 1
            time.sleep(0.1)  # Simulate expensive operation
            return x + y
        
        # First call
        start = time.time()
        result1 = expensive_calculation(5, 10)
        first_call_time = time.time() - start
        
        self.assertEqual(result1, 15)
        self.assertEqual(call_count, 1)
        self.assertGreater(first_call_time, 0.09)
        
        # Cached call
        start = time.time()
        result2 = expensive_calculation(5, 10)
        cached_call_time = time.time() - start
        
        self.assertEqual(result2, 15)
        self.assertEqual(call_count, 1)  # Not incremented
        self.assertLess(cached_call_time, 0.01)
        
        # After TTL expires
        time.sleep(0.6)
        result3 = expensive_calculation(5, 10)
        
        self.assertEqual(result3, 15)
        self.assertEqual(call_count, 2)  # Recalculated
   
                self.cache = cache
            
            async def warm_cache(self, keys, fetch_func):
                """Warm cache with multiple keys concurrently"""
                tasks = []
                
                for key in keys:
                    if self.cache.get(key) is None:
                        task = asyncio.create_task(self._fetch_and_cache(key, fetch_func))
        self._cache = {}
                        tasks.append(task)
                
                await asyncio.gather(*tasks)
            
            async def _fetch_and_cache(self, key, fetch_func):
                value = await fetch_func(key)
                self.cache.put(key, value)
        
        # Test cache warming
        async def run_test():
            cache = {'get': lambda k: None, 'put': lambda k, v: None}
            cache_data = {}
            
            def get(key):
                return cache_data.get(key)
            
            def put(key, value):
                cache_data[key] = value
            
            cache['get'] = get
            cache['put'] = put
            
            warmer = CacheWarmer(cache)
            
            # Mock fetch function
            async def fetch_data(key):
                await asyncio.sleep(0.01)  # Simulate API call
                return f"data_{key}"
            
            # Warm cache with multiple keys
            keys = ['key1', 'key2', 'key3']
            await warmer.warm_cache(keys, fetch_data)
            
            # All keys should be cached
            for key in keys:
                self.assertEqual(cache['get'](key), f"data_{key}")
        
        asyncio.run(run_test())
          # All keys should be cached
            for key in keys:
                self.assertEqual(cache['get'](key), f"data_{key}")
        
        asyncio.run(run_test())


class TestConcurrentRequestHandling(unittest.TestCase):
    """Test concurrent request handling"""
    
    def test_parallel_request_performance(self):
        """Test parallel request execution performance"""
        optimizer = PerformanceOptimizer()
        
        # Mock delayed response
        async def mock_api_call(url):
            await asyncio.sleep(0.1)  # 100ms delay
            return {'url': url, 'data': 'response'}
        
        # Patch aiohttp
        with patch('aiohttp.ClientSession') as mock_session_class:
            mock_session = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.json = mock_api_call
            mock_session.request = AsyncMock(return_value=mock_resp)
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock()
            mock_session_class.return_value = mock_session
            
            async def run_test():
                # Sequential would take 1 second for 10 requests
                requests = [{'url': f'http://api.test.com/{i}'} for i in range(10)]
                
                start = time.time()
                results = await optimizer.parallel_requests(requests)
                elapsed = time.time() - start
                
                # Should complete in ~0.1 seconds (parallel)
                self.assertLess(elapsed, 0.3)
                self.assertEqual(len(results), 10)
        
        asyncio.run(run_test())
    
    def test_semaphore_for_connection_limiting(self):
        """Test using semaphore to limit concurrent connections"""
        async def limited_concurrent_requests(urls, max_concurrent=3):
            semaphore = asyncio.Semaphore(max_concurrent)
            
            async def fetch_with_limit(session, url):
                async with semaphore:
                    # Simulate API call
                    await asyncio.sleep(0.1)
                    return {'url': url, 'status': 'success'}
            
            async with aiohttp.ClientSession() as session:
                tasks = [fetch_with_limit(session, url) for url in urls]
                return await asyncio.gather(*tasks)
        
        async def run_test():
            urls = [f'http://api.test.com/{i}' for i in range(10)]
            
            start = time.time()
            results = await limited_concurrent_requests(urls, max_concurrent=3)
            elapsed = time.time() - start
            
            # With max 3 concurrent, 10 requests should take ~0.4 seconds
            self.assertGreater(elapsed, 0.3)
            self.assertLess(elapsed, 0.5)
            self.assertEqual(len(results), 10)
        
        asy
                self.pending = {}
                self.lock = asyncio.Lock()
            
            async def fetch(self, key, fetch_func):
                async with self.lock:
                    if key in self.pending:
                        # Wait for existing request
                        return await self.pending[key]
                    
                    # Create new request
                    future = asyncio.create_task(fetch_func(key))
                    self.pending[key] = future
        self._cache = {}
                
                try:
                    result = await future
                    return result
                finally:
                    async with self.lock:
                        self.pending.pop(key, None)
        
        # Test deduplication
        async def run_test():
            dedup = RequestDeduplicator()
            call_count = 0
            
            async def mock_fetch(key):
                nonlocal call_count
                call_count += 1
                await asyncio.sleep(0.1)
                return f"data_{key}"
            
            # Launch multiple identical requests
            tasks = []
            for _ in range(5):
                task = asyncio.create_task(dedup.fetch('key1', mock_fetch))
                tasks.append(task)
            
            results = await asyncio.gather(*tasks)
            
            # Should only call fetch once
            self.assertEqual(call_count, 1)
            
            # All results should be identical
            self.assertEqual(len(set(results)), 1)
            self.assertEqual(results[0], "data_key1")
        
        asyncio.run(run_test())
       
            # All results should be identical
            self.assertEqual(len(set(results)), 1)
            self.assertEqual(results[0], "data_key1")
        
        asyncio.run(run_test())


class TestPerformanceBenchmarks(unittest.TestCase):
    """Performance benchmark tests"""
    
    def test_data_serialization_performance(self):
        """Test performance of different serialization methods"""
        import json
        import pickle
        
        # Create test data
        test_data = get_current_market_data()  # Use real data in tests', 'price': 100.0 + i, 'volume': 1000000 + i} 
                      for i in range(1000)],
            'timestamp': datetime.now().isoformat(),
            'metadata': {'source': 'test', 'version': '1.0'}
        }
        
        # JSON serialization
        start = time.time()
        for _ in range(100):
            json_str = json.dumps(test_data)
            json_data = json.loads(json_str)
        json_time = time.time() - start
        
        # Pickle serialization
        start = time.time()
        for _ in range(100):
            pickle_bytes = pickle.dumps(test_data)
            pickle_data = pickle.loads(pickle_bytes)
        pickle_time = time.time() - start
        
        # JSON should be reasonably fast
        self.assertLess(json_time, 1.0)
        
        # Compare sizes
        json_size = len(json_str.encode())
        pickle_size = len(pickle_bytes)
        
        # Results will vary, but both should work
        self.assertGreater(json_size, 0)
        self.assertGreater(pickle_size, 0)
    
    def test_batch_processing_performance(self):
        """Test batch vs individual processing performance"""
        def process_individual(items):
            results = []
            for item in items:
                # Simulate processing
                result = item * 2
                results.append(result)
            return results
        
        def process_batch(items):
            # Simulate batch processing (vectorized)
            return [item * 2 for item in items]
        
        # Large dataset
        data = list(range(10000))
        
        # Individual processing
        start = time.time()
        individual_results = process_individual(data)
        individual_time = time.time() - start
        
        # Batch processing
        start = time.time()
        batch_results = process_batch(data)
        batch_time = time.time() - start
        
        # Results should be identical
        self.assertEqual(individual_results, batch_results)
        
        # Both should complete quickly
        self.assertLess(individual_time, 0.1)
        self.assertLess(batch_time, 0.1)
    
    def test_thread_pool_vs_async_performance(self):
        """Test ThreadPoolExecutor vs asyncio performance"""
        def cpu_bound_task(n):
            """CPU-bound task"""
            return sum(i * i for i in range(n))
        
        async def io_bound_task(n):
            """I/O-bound task"""
            await asyncio.sleep(0.01)
            return n * 2
        
        # Test CPU-bound with threads
        start = time.time()
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(cpu_bound_task, 1000) for _ in range(20)]
            thread_results = [f.result() for f in as_completed(futures)]
        thread_time = time.time() - start
        
        # Test I/O-bound with asyncio
        async def run_async_tasks():
            tasks = [io_bound_task(i) for i in range(20)]
            return await asyncio.gather(*tasks)
        
        start = time.time()
        async_results = asyncio.run(run_async_tasks())
        async_time = time.time() - start
        
        # Async should be faster for I/O-bound tasks
        self.assertLess(async_time, 0.5)
        
        # Thread pool reasonable for CPU-bound
        self.assertLess(thread_time, 2.0)


class TestResourceCleanup()
                self.resources = []
                self.cleaned_up = False
            
            def __enter__(self):
                # Acquire resources
                self.resources.append("resource1")
                self.resources.append("resource2")
                return self
            
            def __exit__(self, exc_type, exc_val, exc_tb):
                # Cleanup resources
                self.resources.clear()
                self.cleaned_up = True
        self._cache = {}
                return False
        
        # Test normal exit
        handler = ResourceHandler()
        with handler:
            self.assertEqual(len(handler.resources), 2)
        
        self.assertTrue(handler.cleaned_up)
        self.assertEqual(len(handler.resources), 0)
        
        # Test exception exit
        handler2 = ResourceHandler()
        try:
            with handler2:
                raise ValueError("Test error")
        except ValueError:
            pass
        
        self.assertTrue(handler2.cleaned_up)
        self.assertEqual(len(handler2.resources), 0)
            with handler2:
                raise ValueError("Test error")
        except ValueError:
            pass
        
        self.assertTrue(handler2.cleaned_up)
        
                self.resource_id = resource_id
                self.finalizer = weakref.finalize(self, self._cleanup, resource_id, cleaned_up)
        self._cache = {}
            
            @staticmethod
            def _cleanup(resource_id, cleanup_list):
                cleanup_list.append(resource_id)
        
        # Create resources
        res1 = ResourceWithFinalizer("res1")
        res2 = ResourceWithFinalizer("res2")
        
        # Delete one resource
        del res1
        gc.collect()
        
        # Should be cleaned up
        self.assertIn("res1", cleaned_up)
        self.assertNotIn("res2", cleaned_up)
        
        # Delete second resource
        del res2
        gc.collect()
        
        # Both should be cleaned up
        self.assertIn("res2", cleaned_up)
    self.assertIn("res1", cleaned_up)
        self.assertNotIn("res2", cleaned_up)
        
        # Delete second resource
        del res2
        gc.collect()
        
        # Both should be cleaned up
        self.assertIn("res2", cleaned_up)
    
    def test_async_cleanup_with_shield(self):
        """Test async cleanup with cancellation protection"""
        async def protected_cleanup():
            cleanup_done = False
            
            async def cleanup_task():
                nonlocal cleanup_done
                await asyncio.sleep(0.1)  # Simulate cleanup
                cleanup_done = True
            
            # Shield cleanup from cancellation
            try:
                await asyncio.shield(cleanup_task())
            except asyncio.CancelledError:
                # Still wait for cleanup
                await cleanup_task()
                raise
            
            return cleanup_done
        
        async def run_test():
            # Normal completion
            result = await protected_cleanup()
            self.assertTrue(result)
            
            # With cancellation (would need more complex setup to test properly)
            # The shield ensures cleanup completes even if cancelled
        
        asyncio.run(run_test())


class TestIntegrationPerformance(unittest.TestCase):
    """Integration tests for resource and performance management"""
    
    def test_complete_request_pipeline(self):
        """Test complete request pipeline with all optimizations"""
        # Components
        rate_limiter = Mock()
        rate_limiter.allow_request.return_value = True
        
        cache = {}
        optimizer = PerformanceOptimizer()
        
        @optimizer.memoize(ttl_seconds=60)
        def cached_api_call(endpoint):
            # Simulate API call
            time.sleep(0.01)
            return {'endpoint': endpoint, 'data': 'cached_response'}
        
        # Simulate request pipeline
        def handle_request(endpoint):
            # 1. Check rate limit
            if not rate_limiter.allow_request():
                raise Exception("Rate limit exceeded")
            
            # 2. Check cache (via memoization)
            result = cached_api_call(endpoint)
            
            # 3. Return result
            return result
        
        # First request (cache miss)
        start = time.time()
        result1 = handle_request('/api/data')
        first_time = time.time() - start
        
        # Second request (cache hit)
        start = time.time()
        result2 = handle_request('/api/data')
        second_time = time.time() - start
        
        # Cache should make second request faster
        self.assertLess(second_time, first_time / 10)
        self.assertEqual(result1, result2)
    
    def test_resource_monitoring_during_load(self):
        """Test resource monitoring during high load"""
        monitor = ResourceMonitor()
        monitor.start_monitoring()
        
        # Simulate high load
        tasks = []
        
        async def simulated_load():
            # Create some memory pressure
            data = [i for i in range(100000)]
            
            # Simulate concurrent operations
            await asyncio.sleep(0.1)
            
            # Process data
            result = sum(data)
            return result
        
        async def run_load_test():
            tasks = [simulated_load() for _ in range(50)]
            results = await asyncio.gather(*tasks)
            return results
        
        # Run load test
        results = asyncio.run(run_load_test())
        
        # Check resource usage
        usage = monitor.get_resource_usage()
        
        # Memory increase should be reasonable
        self.assertLess(usage['memory_delta_mb'], 100)
        
        # CPU should have spiked
        self.assertGreater(usage['cpu_percent'], 0)
        
        # All tasks should complete
        self.assertEqual(len(results), 50)


if __name__ == '__main__':
    unittest.main(verbosity=2)