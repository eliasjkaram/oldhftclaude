#!/usr/bin/env python3
"""
Run TLT Covered Call Backtest with Real Data
Uses MinIO historical data and Alpaca API
"""

import os
import asyncio
import logging
from datetime import datetime, timedelta

# Set up Alpaca credentials if available
if os.path.exists('.env'):
    from dotenv import load_dotenv
    load_dotenv()

# Import the comprehensive backtest system
from comprehensive_backtest_system import ComprehensiveBacktester

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('RealDataBacktest')

async def main():
    """Run TLT backtest with real data"""
    
    # Use last 6 months for backtest
    end_date = datetime.now()
    start_date = end_date - timedelta(days=180)
    
    logger.info("="*80)
    logger.info("🎯 TLT COVERED CALL BACKTEST - REAL DATA")
    logger.info("="*80)
    logger.info(f"Period: {start_date.date()} to {end_date.date()}")
    logger.info("Data Sources: MinIO Historical → Alpaca API → yfinance → Synthetic")
    logger.info("="*80)
    
    # Create backtester
    backtester = ComprehensiveBacktester(
        start_date=start_date.strftime("%Y-%m-%d"),
        end_date=end_date.strftime("%Y-%m-%d")
    )
    
    # Focus on TLT
    backtester.test_symbols = ['TLT']
    
    # Run full backtest
    results = await backtester.run_comprehensive_backtest()
    
    # Display summary
    if results and 'overall_summary' in results:
        summary = results['overall_summary']
        logger.info("\n" + "="*80)
        logger.info("📊 BACKTEST COMPLETE")
        logger.info("="*80)
        
        if 'algorithm_performance' in results and results['algorithm_performance']:
            logger.info("\n🧠 ALGORITHM PERFORMANCE:")
            # Show top 5 algorithms
            algos = results['algorithm_performance']
            if isinstance(algos, dict) and algos:
                sorted_algos = sorted(algos.items(), 
                                    key=lambda x: x[1].get('avg_return', 0) if isinstance(x[1], dict) else 0, 
                                    reverse=True)[:5]
                for algo, perf in sorted_algos:
                    if isinstance(perf, dict):
                        logger.info(f"  {algo}: {perf.get('avg_return', 0)*100:.2f}% return")
        
        if 'spread_performance' in results and results['spread_performance']:
            logger.info("\n📈 TOP OPTION SPREADS:")
            spreads = results['spread_performance']
            sorted_spreads = sorted(spreads.items(), 
                                  key=lambda x: x[1].get('avg_return', 0), 
                                  reverse=True)[:5]
            for spread, perf in sorted_spreads:
                logger.info(f"  {spread}: {perf.get('avg_return', 0)*100:.2f}% return")
        
        logger.info(f"\n⏱️  Total execution time: {summary.get('backtest_duration', 0):.1f} seconds")
        
    return results

if __name__ == "__main__":
    # Check for MinIO connection
    try:
        from minio import Minio
        client = Minio(
            "localhost:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
            secure=False
        )
        if client.bucket_exists("stockdb"):
            logger.info("✅ MinIO connection available")
        else:
            logger.info("⚠️  MinIO bucket 'stockdb' not found")
    except Exception as e:
        logger.info(f"⚠️  MinIO not available: {e}")
    
    # Check for Alpaca credentials
    alpaca_key = os.getenv('ALPACA_API_KEY') or os.getenv('APCA_API_KEY_ID')
    alpaca_secret = os.getenv('ALPACA_SECRET_KEY') or os.getenv('APCA_API_SECRET_KEY')
    
    if alpaca_key and alpaca_secret:
        logger.info("✅ Alpaca API credentials found")
    else:
        logger.info("⚠️  Alpaca API credentials not found")
    
    # Run the backtest
    asyncio.run(main())