
#!/usr/bin/env python3
"""
Market Data Collector
Collects data from Alpaca, YFinance, and OptionData.org
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import aiohttp
import pandas as pd
import numpy as np
import yfinance as yf
from yfinance_wrapper import YFinanceWrapper
from datetime import datetime, timedelta, time
import sqlite3
import json
import logging
import os
import sys
from typing import Dict, List, Any, Optional
from alpaca.trading.client import TradingClient
from bs4 import BeautifulSoup
import requests
from PRODUCTION_FIXES import SecureConfigManager

from universal_market_data import get_current_market_data, validate_price


# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('/home/harry/alpaca-mcp/logs/market_data_collector.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class MarketDataCollector:
    """Collects market data from multiple sources"""
    
    def __init__(self):
        # API Configuration
        # Try to use secure config, fall back to env vars
        paper_key = None
        paper_secret = None
        live_key = None
        live_secret = None
        
        try:
            secure_config = SecureConfigManager()
            paper_key = secure_config.get_credential('ALPACA_PAPER_KEY')
            paper_secret = secure_config.get_credential('ALPACA_PAPER_SECRET')
            live_key = secure_config.get_credential('ALPACA_LIVE_KEY')
            live_secret = secure_config.get_credential('ALPACA_LIVE_SECRET')
            logger.info("Loaded credentials from SecureConfigManager")
        except Exception as e:
            logger.info(f"SecureConfigManager not available: {e}, using environment variables")
            # Fall back to environment variables
            paper_key = os.getenv('ALPACA_PAPER_API_KEY') or os.getenv('ALPACA_API_KEY')
            paper_secret = os.getenv('ALPACA_PAPER_API_SECRET') or os.getenv('ALPACA_SECRET_KEY')
            live_key = os.getenv('ALPACA_LIVE_API_KEY') or paper_key
            live_secret = os.getenv('ALPACA_LIVE_API_SECRET') or paper_secret
        
        # Log credential status (without exposing actual keys)
        logger.info(f"Paper credentials: {'Found' if paper_key and paper_secret else 'Missing'}")
        logger.info(f"Live credentials: {'Found' if live_key and live_secret else 'Missing'}")
        
        # Initialize Alpaca clients only if credentials are available
        if paper_key and paper_secret:
            self.alpaca_paper = TradingClient()
                paper_key,
                paper_secret,
                paper=True
            )
        else:
            logger.warning("Paper trading credentials not found, paper trading disabled")
            self.alpaca_paper = None
        
        if live_key and live_secret:
            self.alpaca_live = TradingClient()
                live_key,
                live_secret,
                paper=False
            )
        else:
            logger.warning("Live trading credentials not found, live trading disabled")
            self.alpaca_live = None
        
        # Database setup
        self.db_path = '/home/harry/alpaca-mcp/market_data.db'
        self.init_database()
        
        # Symbols to track
                # Initialize yfinance wrapper
        self.yf_wrapper = YFinanceWrapper({)
            'max_retries': 3,
            'calls_per_minute': 30,
            'cache_duration_minutes': 15,
            'log_level': 'INFO'
        })
        
        self.symbols = self.load_symbols()
        
    def init_database(self):
        """Initialize market data database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Stock data table
            cursor.execute(''')
                CREATE TABLE IF NOT EXISTS stock_data ()
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    symbol TEXT,
                    source TEXT,
                    open REAL,
                    high REAL,
                    low REAL,
                    close REAL,
                    volume INTEGER,
                    vwap REAL,
                    trade_count INTEGER,
                    UNIQUE(timestamp, symbol, source)
                )
            ''')
            
            # Options data table
            cursor.execute(''')
                CREATE TABLE IF NOT EXISTS options_data ()
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    symbol TEXT,
                    expiration DATE,
                    strike REAL,
                    option_type TEXT,
                    bid REAL,
                    ask REAL,
                    last REAL,
                    volume INTEGER,
                    open_interest INTEGER,
                    implied_volatility REAL,
                    delta REAL,
                    gamma REAL,
                    theta REAL,
                    vega REAL,
                    UNIQUE(timestamp, symbol, expiration, strike, option_type)
                )
            ''')
            
            # Market indicators table
            cursor.execute(''')
                CREATE TABLE IF NOT EXISTS market_indicators ()
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    indicator TEXT,
                    value REAL,
                    UNIQUE(timestamp, indicator)
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_stock_symbol_timestamp ON stock_data(symbol, timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_options_symbol_timestamp ON options_data(symbol, timestamp)')
            
            conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {e}")
            raise
        finally:
            conn.close()
        
    def load_symbols(self):
        """Load comprehensive symbol list"""
        # Major indices and ETFs
        indices = ['SPY', 'QQQ', 'IWM', 'DIA', 'VOO', 'VTI', 'EFA', 'EEM', 'VNQ', 'GLD', 'SLV', 'TLT']
        
        # S&P 100 components
        sp100 = ['AAPL', 'MSFT', 'AMZN', 'GOOGL', 'GOOG', 'META', 'TSLA', 'NVDA', 'JPM', 'JNJ',
                 'V', 'PG', 'UNH', 'HD', 'MA', 'DIS', 'BAC', 'ADBE', 'NFLX', 'CRM',
                 'PFE', 'TMO', 'CSCO', 'PEP', 'ABBV', 'CVX', 'LLY', 'WMT', 'MRK', 'VZ',
                 'KO', 'AVGO', 'NKE', 'INTC', 'CMCSA', 'ORCL', 'ACN', 'COST', 'TXN', 'DHR',
                 'NEE', 'HON', 'BMY', 'UNP', 'PM', 'QCOM', 'LIN', 'LOW', 'MDT', 'SBUX',
                 'AMD', 'RTX', 'AMT', 'INTU', 'ISRG', 'UPS', 'BLK', 'SPGI', 'CVS', 'AXP',
                 'GILD', 'SCHW', 'CAT', 'MO', 'ZTS', 'BKNG', 'MDLZ', 'TMUS', 'DE', 'CI',
                 'SYK', 'VRTX', 'NOW', 'AMGN', 'ADI', 'ANTM', 'GS', 'TGT', 'BDX', 'MMC',
                 'CHTR', 'TJX', 'USB', 'PLD', 'DUK', 'SO', 'CL', 'C', 'WFC', 'MS']
        
        # High volume options
        options_symbols = ['TSLA', 'AAPL', 'SPY', 'QQQ', 'NVDA', 'AMD', 'META', 'AMZN', 'GOOGL', 'MSFT']
        
        # Combine all symbols
        all_symbols = list(set(indices + sp100 + options_symbols))
        logger.info(f"Tracking {len(all_symbols)} symbols")
        
        return all_symbols
        
    async def collect_alpaca_data(self, use_paper=True):
        """Collect data from Alpaca API"""
        api = self.alpaca_paper if use_paper else self.alpaca_live
        source = 'alpaca_paper' if use_paper else 'alpaca_live'
        
        logger.info(f"Collecting Alpaca data ({source})...")
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for symbol in self.symbols:
                try:
                    # Get latest bars
                    bars = api.get_latest_bar(symbol)
                    
                    if bars:
                        cursor.execute(''')
                            INSERT OR REPLACE INTO stock_data 
                            (timestamp, symbol, source, open, high, low, close, volume, vwap, trade_count)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', ()
                            bars.t,
                            symbol,
                            source,
                            bars.o,
                            bars.h,
                            bars.l,
                            bars.c,
                            bars.v,
                            bars.vw,
                            bars.n
                        ))
                        
                except Exception as e:
                    logger.error(f"Error collecting Alpaca data for {symbol}: {e}")
                        
            conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Database error in Alpaca data collection: {e}")
            raise
        finally:
            conn.close()
        
        logger.info(f"Alpaca data collection complete ({source})")
        
    def collect_yfinance_data(self):
        """Collect data from Yahoo Finance using robust wrapper"""
        logger.info("Collecting Yahoo Finance data...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for symbol in self.symbols:
            try:
                # Use wrapper to get data with error handling
                hist = self.yf_wrapper.get_history(symbol, period="1d", interval="1m")
                
                if hist is not None and not hist.empty:
                    latest = hist.iloc[-1]
                    
                    cursor.execute(''')
                        INSERT OR REPLACE INTO stock_data 
                        (timestamp, symbol, source, open, high, low, close, volume)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', ()
                        datetime.now(),
                        symbol,
                        'yfinance',
                        latest.get('open', 0),
                        latest.get('high', 0),
                        latest.get('low', 0),
                        latest.get('close', 0),
                        latest.get('volume', 0)
                    ))
                    
                # Get options data using wrapper
                try:
                    options_data = self.yf_wrapper.get_options(symbol)
                    if options_data and options_data.get('calls') is not None:
                        # Get expiration from first row if available
                        calls_df = options_data['calls']
                        puts_df = options_data['puts']
                        
                        if not calls_df.empty:
                            # Process calls
                            for _, row in calls_df.iterrows():
                                self.store_option_data(cursor, symbol, 'N/A', row, 'call')
                                
                        if not puts_df.empty:
                            # Process puts
                            for _, row in puts_df.iterrows():
                                self.store_option_data(cursor, symbol, 'N/A', row, 'put')
                                
                except Exception as e:
                    logger.debug(f"No options data for {symbol}: {e}")
                    
            except Exception as e:
                logger.error(f"Error collecting YFinance data for {symbol}: {e}")
                
        conn.commit()
        conn.close()
        
        logger.info("Yahoo Finance data collection complete")
    def store_option_data(self, cursor, symbol, expiration, row, option_type):
        """Store option data in database"""
        try:
            cursor.execute(''')
                INSERT OR REPLACE INTO options_data
                (timestamp, symbol, expiration, strike, option_type, bid, ask, last, 
                 volume, open_interest, implied_volatility)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', ()
                datetime.now(),
                symbol,
                expiration,
                row['strike'],
                option_type,
                row.get('bid', 0),
                row.get('ask', 0),
                row.get('lastPrice', 0),
                row.get('volume', 0),
                row.get('openInterest', 0),
                row.get('impliedVolatility', 0)
            ))
        except Exception as e:
            logger.error(f"Error storing option data: {e}")
            
    async def collect_optiondata_org(self):
        """Collect data from OptionData.org"""
        logger.info("Collecting OptionData.org data...")
        
        # Note: OptionData.org requires authentication
        # This is a template for when API access is available
        base_url = "https://optiondata.org/api/v1"
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Market indicators
            indicators = ['VIX', 'SKEW', 'PUT_CALL_RATIO', 'TERM_STRUCTURE']
            
            for indicator in indicators:
                # Simulated data - replace with actual API calls
                value = np.random.uniform(10, 30) if indicator == 'VIX' else np.random.uniform(0.8, 1.2)
                
                cursor.execute(''')
                    INSERT OR REPLACE INTO market_indicators
                    (timestamp, indicator, value)
                    VALUES (?, ?, ?)
                ''', (datetime.now(), indicator, value))
                
        except Exception as e:
            logger.error(f"Error collecting OptionData.org data: {e}")
            
        conn.commit()
        conn.close()
        
        logger.info("OptionData.org data collection complete")
        
    def collect_market_indicators(self):
        """Collect market indicators"""
        logger.info("Collecting market indicators...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # VIX
            vix = yf.Ticker("^VIX")
            vix_data = vix.history(period="1d")
            if not vix_data.empty:
                cursor.execute(''')
                    INSERT OR REPLACE INTO market_indicators
                    (timestamp, indicator, value)
                    VALUES (?, ?, ?)
                ''', (datetime.now(), 'VIX', vix_data['Close'].iloc[-1]))
                
            # Dollar Index
            dxy_data = self.yf_wrapper.get_history("DX-Y.NYB", period="1d")
            # Already fetched above
            if not dxy_data.empty:
                cursor.execute(''')
                    INSERT OR REPLACE INTO market_indicators
                    (timestamp, indicator, value)
                    VALUES (?, ?, ?)
                ''', (datetime.now(), 'DXY', dxy_data['Close'].iloc[-1]))
                
            # 10-Year Treasury
            tnx_data = self.yf_wrapper.get_history("^TNX", period="1d")
            # Already fetched above
            if not tnx_data.empty:
                cursor.execute(''')
                    INSERT OR REPLACE INTO market_indicators
                    (timestamp, indicator, value)
                    VALUES (?, ?, ?)
                ''', (datetime.now(), 'TNX', tnx_data['Close'].iloc[-1]))
                
        except Exception as e:
            logger.error(f"Error collecting market indicators: {e}")
            
        conn.commit()
        conn.close()
        
        logger.info("Market indicators collection complete")
        
    async def run_collection_cycle(self):
        """Run complete data collection cycle"""
        logger.info(f"Starting data collection cycle at {datetime.now()}")
        
        # Collect from all sources
        tasks = []
            self.collect_alpaca_data(use_paper=True),
            self.collect_alpaca_data(use_paper=False),
            asyncio.to_thread(self.collect_yfinance_data),
            self.collect_optiondata_org(),
            asyncio.to_thread(self.collect_market_indicators)
        ]
        
        await asyncio.gather(*tasks, return_exceptions=True)
        
        logger.info(f"Data collection cycle complete at {datetime.now()}")
        
    def cleanup_old_data(self, days_to_keep=30):
        """Clean up old data from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        cursor.execute('DELETE FROM stock_data WHERE timestamp < ?', (cutoff_date,))
        cursor.execute('DELETE FROM options_data WHERE timestamp < ?', (cutoff_date,))
        cursor.execute('DELETE FROM market_indicators WHERE timestamp < ?', (cutoff_date,))
        
        deleted_rows = cursor.rowcount
        conn.commit()
        conn.close()
        
        logger.info(f"Cleaned up {deleted_rows} old records")

async def main():
    """Main collection function"""
    collector = MarketDataCollector()
    await collector.run_collection_cycle()
    
    # Cleanup old data
    collector.cleanup_old_data()

if __name__ == "__main__":
    # Create logs directory if it doesn't exist
    os.makedirs('/home/harry/alpaca-mcp/logs', exist_ok=True)
    
    asyncio.run(main())