#!/usr/bin/env python3
"""
Comprehensive MinIO Options Data Discovery Script - 2025 Update
=============================================================

This script performs an exhaustive search of the MinIO bucket to find:
1. ALL options data across all directories
2. New data that covers 2017-2025 period
3. Compressed archives that might contain recent data
4. Any new directories or files added since last search
5. Complete inventory of what years are actually available now

User requested to check if historical options data now covers 2016-2025
as they mentioned data is "slowly transferring"
"""

import json
import logging
from datetime import datetime, timedelta
from minio import Minio
from minio.error import S3Error
import pandas as pd
import io
import zipfile
import gzip
import re
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Set
import os

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class Comprehensive2025MinIODataDiscovery:
    def __init__(self):
        """Initialize MinIO client connection."""
        self.endpoint = "uschristmas.us"
        self.bucket_name = "stockdb"
        self.client = None
        self.discovery_report = {}
            "search_timestamp": datetime.now().isoformat(),
            "search_purpose": "Comprehensive 2025 data discovery - checking for 2017-2025 coverage",
            "directories_analyzed": {},
            "year_coverage_analysis": {},
            "new_discoveries": [],
            "file_inventory": {},
            "compressed_archives": {},
            "data_quality_assessment": {},
            "coverage_summary": {},
            "recommendations": []
        }
        
    def connect_to_minio(self):
        """Establish connection to MinIO bucket."""
        try:
            self.client = Minio()
                self.endpoint,
                secure=True
            )
            
            # Test connection
            exists = self.client.bucket_exists(self.bucket_name)
            if exists:
                logger.info(f"✅ Successfully connected to MinIO bucket: {self.bucket_name}")
                return True
            else:
                logger.error(f"❌ Bucket {self.bucket_name} does not exist")
                return False
                
        except Exception as e:
            logger.error(f"❌ Failed to connect to MinIO: {e}")
            return False
    
    def get_all_directories(self) -> List[str]:
        """Get all directories in the bucket."""
        directories = set()
        try:
            objects = self.client.list_objects(self.bucket_name, recursive=False, include_version=False)
            for obj in objects:
                if obj.object_name.endswith('/'):
                    directories.add(obj.object_name.rstrip('/')
                    
            logger.info(f"Found {len(directories)} top-level directories")
            return sorted(list(directories)
            
        except S3Error as e:
            logger.error(f"Error listing directories: {e}")
            return []
    
    def analyze_directory_deeply(self, directory: str) -> Dict:
        """Perform deep analysis of a directory looking for options data."""
        logger.info(f"🔍 Deep analysis of directory: {directory}")
        
        analysis = {}
            "directory": directory,
            "total_files": 0,
            "total_size_mb": 0,
            "file_types": Counter(),
            "years_detected": set(),
            "date_patterns": [],
            "sample_files": [],
            "compressed_files": [],
            "potential_options_files": [],
            "file_name_patterns": Counter(),
            "size_distribution": {},
            "recent_additions": []
        }
        
        try:
            # List all objects in directory
            objects = self.client.list_objects()
                self.bucket_name, 
                prefix=f"{directory}/", 
                recursive=True
            )
            
            for obj in objects:
                if obj.object_name.endswith('/'):
                    continue
                    
                analysis["total_files"] += 1
                size_mb = obj.size / (1024 * 1024)
                analysis["total_size_mb"] += size_mb
                
                # File extension analysis
                ext = os.path.splitext(obj.object_name)[1].lower()
                analysis["file_types"][ext] += 1
                
                # Check for compressed files
                if ext in ['.zip', '.gz', '.bz2', '.7z', '.tar']:
                    analysis["compressed_files"].append({)
                        "file": obj.object_name,
                        "size_mb": size_mb,
                        "last_modified": obj.last_modified.isoformat() if obj.last_modified else None
                    })
                
                # Look for options-related files
                filename = obj.object_name.lower()
                if any(keyword in filename for keyword in ['option', 'opt', 'call', 'put', 'strike', 'expir']):
                    analysis["potential_options_files"].append(obj.object_name)
                
                # Extract years from filename
                years = re.findall(r'20[0-9]{2}', obj.object_name)
                for year in years:
                    analysis["years_detected"].add(int(year)
                
                # Look for date patterns
                date_matches = re.findall(r'20[0-9]{2}[-_][0-9]{2}[-_][0-9]{2}', obj.object_name)
                analysis["date_patterns"].extend(date_matches)
                
                # Sample files for detailed inspection
                if len(analysis["sample_files"]) < 10:
                    analysis["sample_files"].append({)
                        "file": obj.object_name,
                        "size_mb": size_mb,
                        "extension": ext,
                        "last_modified": obj.last_modified.isoformat() if obj.last_modified else None
                    })
                
                # Track file name patterns
                base_name = os.path.basename(obj.object_name)
                pattern = re.sub(r'20[0-9]{2}[-_][0-9]{2}[-_][0-9]{2}', 'YYYY-MM-DD', base_name)
                pattern = re.sub(r'20[0-9]{2}', 'YYYY', pattern)
                analysis["file_name_patterns"][pattern] += 1
                
                # Recent additions (last 30 days)
                if obj.last_modified:
                    days_old = (datetime.now(obj.last_modified.tzinfo) - obj.last_modified).days
                    if days_old <= 30:
                        analysis["recent_additions"].append({)
                            "file": obj.object_name,
                            "days_old": days_old,
                            "size_mb": size_mb
                        })
            
            # Size distribution
            if analysis["total_files"] > 0:
                avg_size = analysis["total_size_mb"] / analysis["total_files"]
                analysis["size_distribution"] = {}
                    "average_file_size_mb": avg_size,
                    "total_size_gb": analysis["total_size_mb"] / 1024,
                    "largest_files": sorted(analysis["sample_files"], key=lambda x: x["size_mb"], reverse=True)[:5]
                }
            
            # Convert sets to lists for JSON serialization
            analysis["years_detected"] = sorted(list(analysis["years_detected"])
            
            logger.info(f"✅ Analyzed {directory}: {analysis['total_files']} files, {analysis['total_size_mb']:.1f}MB")
            
        except S3Error as e:
            logger.error(f"Error analyzing directory {directory}: {e}")
            analysis["error"] = str(e)
        
        return analysis
    
    def inspect_compressed_file(self, filepath: str) -> Dict:
        """Inspect contents of compressed files to find options data."""
        logger.info(f"🔍 Inspecting compressed file: {filepath}")
        
        inspection = {}
            "file": filepath,
            "type": "unknown",
            "contents": [],
            "years_found": set(),
            "options_related": False,
            "error": None
        }
        
        try:
            # Download file content
            response = self.client.get_object(self.bucket_name, filepath)
            content = response.read()
            
            if filepath.endswith('.zip'):
                inspection["type"] = "zip"
                try:
                    with zipfile.ZipFile(io.BytesIO(content) as zf:
                        for info in zf.infolist()[:50]:  # Limit to first 50 files
                            inspection["contents"].append({)
                                "filename": info.filename,
                                "size": info.file_size,
                                "date": f"{info.date_time[0]}-{info.date_time[1]:02d}-{info.date_time[2]:02d}"
                            })
                            
                            # Check for years and options keywords
                            years = re.findall(r'20[0-9]{2}', info.filename)
                            for year in years:
                                inspection["years_found"].add(int(year)
                            
                            if any(keyword in info.filename.lower() for keyword in ['option', 'opt', 'call', 'put']):
                                inspection["options_related"] = True
                                
                except zipfile.BadZipFile:
                    inspection["error"] = "Bad ZIP file"
                    
            elif filepath.endswith('.gz'):
                inspection["type"] = "gzip"
                try:
                    decompressed = gzip.decompress(content)
                    # Try to read as text to see contents
                    text_content = decompressed.decode('utf-8', errors='ignore')[:1000]
                    inspection["sample_content"] = text_content
                    
                    # Look for CSV headers or data patterns
                    if 'option' in text_content.lower() or 'strike' in text_content.lower():
                        inspection["options_related"] = True
                        
                except Exception as e:
                    inspection["error"] = f"Failed to decompress: {e}"
            
            # Convert sets to lists
            inspection["years_found"] = sorted(list(inspection["years_found"])
            
        except Exception as e:
            inspection["error"] = str(e)
            
        return inspection
    
    def sample_file_content(self, filepath: str) -> Dict:
        """Sample file content to determine data type and years covered."""
        logger.info(f"📄 Sampling file content: {filepath}")
        
        sample = {}
            "file": filepath,
            "type": "unknown",
            "columns": [],
            "years_in_data": set(),
            "options_data": False,
            "sample_rows": [],
            "error": None
        }
        
        try:
            # Download first part of file
            response = self.client.get_object(self.bucket_name, filepath)
            content = response.read(10000)  # First 10KB
            
            if filepath.endswith('.csv'):
                try:
                    text_content = content.decode('utf-8', errors='ignore')
                    lines = text_content.split('\n')[:20]  # First 20 lines
                    
                    if lines:
                        # Try to parse as CSV
                        from io import StringIO
                        df = pd.read_csv(StringIO('\n'.join(lines), nrows=10)
                        
                        sample["columns"] = df.columns.tolist()
                        sample["sample_rows"] = df.head(5).to_dict('records')
                        
                        # Check if this looks like options data
                        options_keywords = ['strike', 'expiration', 'call', 'put', 'option', 'underlying', 'bid', 'ask']
                        if any(keyword in ' '.join(sample["columns"]).lower() for keyword in options_keywords):
                            sample["options_data"] = True
                            sample["type"] = "options_csv"
                        
                        # Extract years from data
                        for col in df.columns:
                            if 'date' in col.lower() or 'expir' in col.lower():
                                for value in df[col].dropna():
                                    years = re.findall(r'20[0-9]{2}', str(value)
                                    for year in years:
                                        sample["years_in_data"].add(int(year)
                        
                except Exception as e:
                    sample["error"] = f"CSV parsing error: {e}"
                    sample["raw_content"] = text_content[:500]
            
            # Convert sets to lists
            sample["years_in_data"] = sorted(list(sample["years_in_data"])
            
        except Exception as e:
            sample["error"] = str(e)
            
        return sample
    
    def run_comprehensive_discovery(self):
        """Run the complete comprehensive discovery process."""
        logger.info("🚀 Starting Comprehensive 2025 MinIO Data Discovery...")
        
        if not self.connect_to_minio():
            return None
        
        # Get all directories
        directories = self.get_all_directories()
        logger.info(f"Found {len(directories)} directories to analyze")
        
        # Analyze each directory
        for directory in directories:
            logger.info(f"📁 Analyzing directory: {directory}")
            
            analysis = self.analyze_directory_deeply(directory)
            self.discovery_report["directories_analyzed"][directory] = analysis
            
            # If we found potential options files, sample them
            if analysis.get("potential_options_files"):
                logger.info(f"Found {len(analysis['potential_options_files'])} potential options files in {directory}")
                
                # Sample up to 3 files
                for filepath in analysis["potential_options_files"][:3]:
                    sample = self.sample_file_content(filepath)
                    if "file_samples" not in self.discovery_report:
                        self.discovery_report["file_samples"] = {}
                    self.discovery_report["file_samples"][filepath] = sample
            
            # Inspect compressed files
            for compressed_file in analysis.get("compressed_files", [])[:5]:  # Limit to 5 per directory
                inspection = self.inspect_compressed_file(compressed_file["file"])
                if "compressed_inspections" not in self.discovery_report:
                    self.discovery_report["compressed_inspections"] = {}
                self.discovery_report["compressed_inspections"][compressed_file["file"]] = inspection
        
        # Generate comprehensive analysis
        self.generate_comprehensive_analysis()
        
        # Save report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"comprehensive_2025_minio_discovery_{timestamp}.json"
        
        with open(report_file, 'w') as f:
            json.dump(self.discovery_report, f, indent=2)
        
        logger.info(f"✅ Comprehensive discovery complete. Report saved to: {report_file}")
        return self.discovery_report
    
    def generate_comprehensive_analysis(self):
        """Generate comprehensive analysis and recommendations."""
        logger.info("📊 Generating comprehensive analysis...")
        
        # Collect all years found across all directories
        all_years = set()
        options_directories = {}
        total_options_files = 0
        total_options_size_gb = 0
        
        for dir_name, analysis in self.discovery_report["directories_analyzed"].items():
            years = set(analysis.get("years_detected", [])
            all_years.update(years)
            
            # Check if this looks like options data
            has_options = ()
                analysis.get("potential_options_files") or
                'option' in dir_name.lower() or
                any(sample.get("options_data", False) for sample in self.discovery_report.get("file_samples", {}).values()
            )
            
            if has_options:
                options_directories[dir_name] = {}
                    "years_covered": sorted(list(years),
                    "file_count": analysis["total_files"],
                    "size_gb": analysis["total_size_mb"] / 1024,
                    "recent_additions": len(analysis.get("recent_additions", []),
                    "compressed_files": len(analysis.get("compressed_files", [])
                }
                total_options_files += analysis["total_files"]
                total_options_size_gb += analysis["total_size_mb"] / 1024
        
        # Year coverage analysis
        target_years = list(range(2016, 2026)  # 2016-2025)
        available_years = sorted(list(all_years)
        missing_years = [y for y in target_years if y not in all_years]
        coverage_percentage = (len([y for y in target_years if y in all_years]) / len(target_years) * 100)
        
        # Check for 2017-2025 specifically
        recent_years = list(range(2017, 2026)
        recent_available = [y for y in recent_years if y in all_years]
        recent_missing = [y for y in recent_years if y not in all_years]
        recent_coverage = (len(recent_available) / len(recent_years) * 100)
        
        self.discovery_report["coverage_summary"] = {}
            "search_purpose": "Check if data now covers 2016-2025 as user mentioned 'slowly transferring'",
            "target_period": "2016-2025 (10 years)",
            "all_years_found": available_years,
            "target_years_available": [y for y in target_years if y in all_years],
            "missing_years": missing_years,
            "coverage_percentage": round(coverage_percentage, 1),
            "recent_focus_analysis": {}
                "target_period": "2017-2025 (9 years)",
                "years_available": recent_available,
                "years_missing": recent_missing,
                "coverage_percentage": round(recent_coverage, 1)
            },
            "options_data_summary": {}
                "directories_with_options": len(options_directories),
                "total_options_files": total_options_files,
                "total_size_gb": round(total_options_size_gb, 1),
                "options_directories": options_directories
            }
        }
        
        # Generate recommendations
        recommendations = []
        
        if recent_coverage < 100:
            recommendations.append(f"❌ INCOMPLETE: Only {recent_coverage:.1f}% coverage of 2017-2025 period")
            recommendations.append(f"Missing years: {recent_missing}")
        else:
            recommendations.append("✅ COMPLETE: Full coverage of 2017-2025 period found!")
        
        if missing_years:
            recommendations.append(f"Overall missing years from 2016-2025: {missing_years}")
        
        # Check for recent additions
        recent_additions_found = False
        for dir_name, analysis in self.discovery_report["directories_analyzed"].items():
            if analysis.get("recent_additions"):
                recent_additions_found = True
                recommendations.append(f"🆕 Recent additions found in {dir_name}: {len(analysis['recent_additions'])} files")
        
        if not recent_additions_found:
            recommendations.append("ℹ️ No files added in the last 30 days")
        
        # Check compressed files for potential data
        compressed_with_years = []
        for filepath, inspection in self.discovery_report.get("compressed_inspections", {}).items():
            if inspection.get("years_found"):
                compressed_with_years.append(f"{filepath}: {inspection['years_found']}")
        
        if compressed_with_years:
            recommendations.append("🗜️ Compressed files found with year data:")
            recommendations.extend([f"  - {item}" for item in compressed_with_years])
        
        self.discovery_report["recommendations"] = recommendations
        
        # Final verdict
        if recent_coverage >= 50:
            verdict = f"SIGNIFICANT PROGRESS: {recent_coverage:.1f}% of 2017-2025 data found"
        elif recent_coverage > 0:
            verdict = f"LIMITED PROGRESS: Only {recent_coverage:.1f}% of 2017-2025 data found"
        else:
            verdict = "NO PROGRESS: No 2017-2025 data found yet"
        
        self.discovery_report["final_verdict"] = verdict
        
        logger.info(f"📊 Analysis complete. {verdict}")

def main():
    """Main execution function."""
    discovery = Comprehensive2025MinIODataDiscovery()
    report = discovery.run_comprehensive_discovery()
    
    if report:
        print("\n" + "="*80)
        print("COMPREHENSIVE 2025 MINIO DATA DISCOVERY SUMMARY")
        print("="*80)
        
        coverage = report["coverage_summary"]
        print(f"\n🎯 TARGET: Check if data now covers 2016-2025")
        print(f"📊 OVERALL COVERAGE: {coverage['coverage_percentage']}% of 2016-2025")
        print(f"🔍 RECENT FOCUS (2017-2025): {coverage['recent_focus_analysis']['coverage_percentage']}%")
        print(f"📈 YEARS AVAILABLE: {coverage['all_years_found']}")
        print(f"❌ MISSING YEARS: {coverage['missing_years']}")
        
        print(f"\n📁 OPTIONS DATA FOUND:")
        options_summary = coverage["options_data_summary"]
        print(f"   - {options_summary['directories_with_options']} directories with options data")
        print(f"   - {options_summary['total_options_files']} total files")
        print(f"   - {options_summary['total_size_gb']} GB total size")
        
        print(f"\n🎯 FINAL VERDICT: {report['final_verdict']}")
        
        print(f"\n💡 KEY RECOMMENDATIONS:")
        for rec in report["recommendations"][:10]:  # Show first 10 recommendations
            print(f"   {rec}")
        
        print("\n" + "="*80)
        
    else:
        print("❌ Discovery failed - could not connect to MinIO bucket")

if __name__ == "__main__":
    main()