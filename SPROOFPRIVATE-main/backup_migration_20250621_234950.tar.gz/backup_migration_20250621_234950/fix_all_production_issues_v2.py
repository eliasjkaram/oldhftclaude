#!/usr/bin/env python3
"""
Comprehensive Fix for ALL Production Import and Reference Issues
================================================================

This script fixes:
1. All "from alpaca import tradeapi" to use correct alpaca-py imports
2. All self.trading_client vs self.api inconsistencies
3. Missing attribute initializations (self._max_drawdown, self._query_cache, etc.)
4. Duplicate enum definitions
5. Ensures all imports are correct for production use
"""

import os
import re
import sys
import glob
import json
import shutil
from pathlib import Path
from typing import List, Dict, Tuple, Set, Optional
from datetime import datetime

class ProductionIssueFixer:
    def __init__(self):
        self.fixed_files = []
        self.errors = []
        self.backup_dir = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.issues_fixed = {}
            'imports': 0,
            'api_client': 0,
            'method_calls': 0,
            'attributes': 0,
            'duplicates': 0,
            'enums': 0,
            'syntax': 0
        }
        
        # Create backup directory
        os.makedirs(self.backup_dir, exist_ok=True)
        
    def backup_file(self, filepath: str):
        """Create backup of file before modifying"""
        try:
            backup_path = os.path.join(self.backup_dir, os.path.basename(filepath))
            shutil.copy2(filepath, backup_path)
        except Exception as e:
            print(f"Warning: Could not backup {filepath}: {e}")
    
    def fix_file(self, filepath: str) -> bool:
        """Fix all issues in a single file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # Apply all fixes in correct order
            content = self.fix_imports(content, filepath)
            content = self.fix_api_client_initialization(content)
            content = self.fix_api_method_calls(content)
            content = self.fix_missing_attributes(content)
            content = self.fix_duplicate_enums(content)
            content = self.fix_broken_syntax(content)
            content = self.fix_order_submissions(content)
            content = self.fix_data_requests(content)
            
            # Only write if changes were made
            if content != original_content:
                self.backup_file(filepath)
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                self.fixed_files.append(filepath)
                return True
            
            return False
            
        except Exception as e:
            self.errors.append(f"Error fixing {filepath}: {str(e)}")
            return False
    
    def fix_imports(self, content: str, filepath: str) -> str:
        """Fix all import statements comprehensively"""
        lines = content.split('\n')
        new_lines = []
        imports_section_done = False
        alpaca_imports_added = False
        
        # Standard alpaca-py imports
        alpaca_py_imports = []
            "from alpaca.trading.client import TradingClient",
            "from alpaca.data.historical import StockHistoricalDataClient",
            "from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest",
            "from alpaca.data.timeframe import TimeFrame",
            "from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass",
            "from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest",
            "from alpaca.common.exceptions import APIError"
        ]
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Detect import section
            if line.strip().startswith(('import ', 'from ')) and not imports_section_done:
                # Remove old alpaca imports
                if any(old in line for old in [)
                    'alpaca_trade_api',
                    'from alpaca import tradeapi',
                    'alpaca.REST',
                    'alpaca_trade_api.REST'
                ]):
                    self.issues_fixed['imports'] += 1
                    # Skip this line, we'll add correct imports later
                    i += 1
                    continue
                
                # Check if this is the last import line
                if i + 1 < len(lines) and not lines[i + 1].strip().startswith(('import ', 'from ')):
                    # Add alpaca-py imports after the last import
                    new_lines.append(line)
                    if not alpaca_imports_added:
                        new_lines.append("")  # Empty line
                        new_lines.extend(alpaca_py_imports)
                        new_lines.append("")  # Empty line
                        alpaca_imports_added = True
                        self.issues_fixed['imports'] += 1
                    imports_section_done = True
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)
            
            i += 1
        
        # If no imports were found, add at the beginning after initial comments/docstrings
        if not alpaca_imports_added:
            insert_idx = 0
            for idx, line in enumerate(new_lines):
                if line.strip() and not line.strip().startswith('#') and not line.strip().startswith('"""'):
                    insert_idx = idx
                    break
            
            new_lines[insert_idx:insert_idx] = alpaca_py_imports + [""]
            self.issues_fixed['imports'] += 1
        
        return '\n'.join(new_lines)
    
    def fix_api_client_initialization(self, content: str) -> str:
        """Fix API client initialization patterns"""
        # Fix REST initialization
        patterns = []
            # Old REST API
            (r'self\.api\s*=\s*REST\s*\((.*?)\)', self._create_new_client_init),
            (r'self\.api\s*=\s*tradeapi\.REST\s*\((.*?)\)', self._create_new_client_init),
            (r'api\s*=\s*REST\s*\((.*?)\)', lambda m: self._create_new_client_init(m, False)),
            
            # Fix incorrect client usage
            (r'self\.trading_client\s*=\s*TradingClient\s*\((.*?)\)(?!\s*\n\s*self\.data_client)', 
             self._add_data_client),
        ]
        
        for pattern, replacement in patterns:
            matches = list(re.finditer(pattern, content, re.DOTALL))
            for match in reversed(matches):  # Process in reverse to maintain positions
                if callable(replacement):
                    new_text = replacement(match)
                else:
                    new_text = replacement
                content = content[:match.start()] + new_text + content[match.end():]
                self.issues_fixed['api_client'] += 1
        
        return content
    
    def _create_new_client_init(self, match, is_self=True):
        """Create new client initialization from old REST init"""
        args = match.group(1)
        prefix = "self." if is_self else ""
        
        # Extract API key and secret from args
        # Handle various patterns
        if 'key_id' in args or 'api_key' in args:
            return f"""{prefix}trading_client = TradingClient({args}, paper=True)
        {prefix}data_client = StockHistoricalDataClient({args})"""
        else:
            # Try to extract from simple positional args
            return f"""{prefix}trading_client = TradingClient({args}, paper=True)
        {prefix}data_client = StockHistoricalDataClient({args})"""
    
    def _add_data_client(self, match):
        """Add data client after trading client"""
        original = match.group(0)
        args = match.group(1)
        
        # Extract key arguments
        key_match = re.search(r'api_key\s*=\s*([^,\)]+)', args)
        secret_match = re.search(r'secret_key\s*=\s*([^,\)]+)', args)
        
        if key_match and secret_match:
            key = key_match.group(1)
            secret = secret_match.group(1)
            return f"""{original}
        self.data_client = StockHistoricalDataClient(api_key={key}, secret_key={secret})"""
        else:
            # Fallback - assume same args structure
            return f"""{original}
        self.data_client = StockHistoricalDataClient({args.replace(', paper=True', '')})"""
    
    def fix_api_method_calls(self, content: str) -> str:
        """Fix all API method calls"""
        replacements = []
            # Account/Trading methods -> trading_client
            (r'self\.api\.get_account\s*\(', 'self.trading_client.get_account('),
            (r'self\.api\.list_positions\s*\(', 'self.trading_client.get_all_positions('),
            (r'self\.api\.get_position\s*\(', 'self.trading_client.get_open_position('),
            (r'self\.api\.list_orders\s*\(', 'self.trading_client.get_orders('),
            (r'self\.api\.submit_order\s*\(', 'self.trading_client.submit_order('),
            (r'self\.api\.cancel_order\s*\(', 'self.trading_client.cancel_order_by_id('),
            (r'self\.api\.cancel_all_orders\s*\(', 'self.trading_client.cancel_orders('),
            (r'self\.api\.get_order\s*\(', 'self.trading_client.get_order_by_id('),
            
            # Data methods -> data_client
            (r'self\.api\.get_bars\s*\(', 'self.data_client.get_stock_bars('),
            (r'self\.api\.get_barset\s*\(', 'self.data_client.get_stock_bars('),
            (r'self\.api\.get_latest_quote\s*\(', 'self.data_client.get_stock_latest_quote('),
            (r'self\.api\.get_latest_trade\s*\(', 'self.data_client.get_stock_latest_trade('),
            (r'self\.api\.get_latest_bar\s*\(', 'self.data_client.get_stock_latest_bar('),
            
            # Fix incorrect client usage
            (r'self\.trading_client\.get_bars\s*\(', 'self.data_client.get_stock_bars('),
            (r'self\.trading_client\.get_latest_quote\s*\(', 'self.data_client.get_stock_latest_quote('),
            
            # Generic self.api -> self.trading_client (for remaining cases)
            (r'self\.api\.', 'self.trading_client.'),
        ]
        
        for pattern, replacement in replacements:
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                self.issues_fixed['method_calls'] += 1
        
        return content
    
    def fix_order_submissions(self, content: str) -> str:
        """Fix order submission calls"""
        # Pattern for old-style submit_order
        old_pattern = r'submit_order\s*\(\s*(?:symbol\s*=\s*([^,\)]+),\s*)?(?:qty\s*=\s*([^,\)]+),\s*)?(?:side\s*=\s*([^,\)]+),\s*)?(?:type\s*=\s*([^,\)]+),\s*)?(?:time_in_force\s*=\s*([^,\)]+))?[^)]*\)'
        
        def fix_submit_order(match):
            # Extract parameters
            full_match = match.group(0)
            
            # Try to extract each parameter
            symbol_match = re.search(r'symbol\s*=\s*([^,\)]+)', full_match)
            qty_match = re.search(r'qty\s*=\s*([^,\)]+)', full_match)
            side_match = re.search(r'side\s*=\s*([^,\)]+)', full_match)
            type_match = re.search(r'type\s*=\s*([^,\)]+)', full_match)
            tif_match = re.search(r'time_in_force\s*=\s*([^,\)]+)', full_match)
            limit_match = re.search(r'limit_price\s*=\s*([^,\)]+)', full_match)
            
            if not all([symbol_match, qty_match, side_match]):
                return full_match  # Can't fix without minimum params
            
            symbol = symbol_match.group(1).strip()
            qty = qty_match.group(1).strip()
            side = side_match.group(1).strip()
            order_type = type_match.group(1).strip() if type_match else 'OrderType.MARKET'
            tif = tif_match.group(1).strip() if tif_match else 'TimeInForce.DAY'
            
            # Create appropriate order request
            if limit_match or 'limit' in order_type.lower():
                limit_price = limit_match.group(1).strip() if limit_match else 'limit_price'
                return f'submit_order(order_data=LimitOrderRequest(symbol={symbol}, qty={qty}, side={side}, time_in_force={tif}, limit_price={limit_price}))'
            else:
                return f'submit_order(order_data=MarketOrderRequest(symbol={symbol}, qty={qty}, side={side}, time_in_force={tif}))'
        
        # Apply fixes
        if 'submit_order' in content and 'order_data=' not in content:
            content = re.sub(old_pattern, fix_submit_order, content)
            self.issues_fixed['method_calls'] += 1
        
        return content
    
    def fix_data_requests(self, content: str) -> str:
        """Fix data request patterns"""
        # Fix get_bars/get_stock_bars calls
        bars_pattern = r'get_stock_bars\s*\(\s*([^,\)]+)(?:\s*,\s*([^,\)]+))?(?:\s*,\s*start\s*=\s*([^,\)]+))?(?:\s*,\s*end\s*=\s*([^,\)]+))?[^)]*\)'
        
        def fix_bars_call(match):
            full_match = match.group(0)
            
            # If already has StockBarsRequest, skip
            if 'StockBarsRequest' in full_match:
                return full_match
            
            # Extract parameters
            symbol = match.group(1).strip() if match.group(1) else None
            timeframe = match.group(2).strip() if match.group(2) else 'TimeFrame.Day'
            
            # Build request parameters
            params = [f'symbol_or_symbols={symbol}']
            if timeframe and 'TimeFrame' not in timeframe:
                params.append(f'timeframe=TimeFrame.{timeframe}')
            else:
                params.append(f'timeframe={timeframe}')
            
            # Add optional parameters
            start_match = re.search(r'start\s*=\s*([^,\)]+)', full_match)
            end_match = re.search(r'end\s*=\s*([^,\)]+)', full_match)
            limit_match = re.search(r'limit\s*=\s*([^,\)]+)', full_match)
            
            if start_match:
                params.append(f'start={start_match.group(1).strip()}')
            if end_match:
                params.append(f'end={end_match.group(1).strip()}')
            if limit_match:
                params.append(f'limit={limit_match.group(1).strip()}')
            
            return f'get_stock_bars(StockBarsRequest({", ".join(params)}))'
        
        if 'get_stock_bars' in content:
            content = re.sub(bars_pattern, fix_bars_call, content)
            self.issues_fixed['method_calls'] += 1
        
        return content
    
    def fix_missing_attributes(self, content: str) -> str:
        """Add missing attribute initializations"""
        # Find class definitions with __init__ methods
        class_pattern = r'class\s+(\w+).*?:\s*\n(.*?)(?=\nclass|\Z)'
        
        for class_match in re.finditer(class_pattern, content, re.DOTALL):
            class_name = class_match.group(1)
            class_body = class_match.group(2)
            
            # Find __init__ method
            init_pattern = r'def\s+__init__\s*\(self[^)]*\)\s*:\s*\n((?:\s+.*\n)*)'
            init_match = re.search(init_pattern, class_body)
            
            if init_match:
                init_body = init_match.group(1)
                init_start = class_match.start(2) + init_match.start(1)
                init_end = class_match.start(2) + init_match.end(1)
                
                # Get indentation
                first_line = init_body.split('\n')[0] if init_body else '        '
                indent = len(first_line) - len(first_line.lstrip())
                if indent == 0:
                    indent = 8
                
                # Check for missing attributes used in class
                missing_attrs = []
                
                # Common patterns
                attr_patterns = []
                    (r'self\.(_max_drawdown)', '0.0'),
                    (r'self\.(_query_cache)', '{}'),
                    (r'self\.(_last_update)', 'None'),
                    (r'self\.(_performance_metrics)', '{}'),
                    (r'self\.(_risk_metrics)', '{}'),
                    (r'self\.(_cache)', '{}'),
                    (r'self\.(_session)', 'None'),
                    (r'self\.(_lock)', 'threading.Lock()'),
                    (r'self\.(api_key)', 'None'),
                    (r'self\.(api_secret)', 'None'),
                    (r'self\.(base_url)', 'None'),
                ]
                
                for attr_pattern, default_value in attr_patterns:
                    if re.search(attr_pattern, class_body) and not re.search(f'self\\.{attr_pattern[6:-1]}\\s*=', init_body):
                        attr_name = attr_pattern[6:-1]  # Extract attribute name
                        missing_attrs.append(f'{" " * indent}self.{attr_name} = {default_value}\n')
                        self.issues_fixed['attributes'] += 1
                
                # Add missing attributes to __init__
                if missing_attrs:
                    # Check if we need to import threading
                    if any('threading.Lock()' in attr for attr in missing_attrs):
                        if 'import threading' not in content:
                            # Add import at the top
                            import_idx = content.find('\n') + 1
                            content = content[:import_idx] + 'import threading\n' + content[import_idx:]
                    
                    # Add attributes after existing initializations
                    new_init_body = init_body + ''.join(missing_attrs)
                    content = content[:init_start] + new_init_body + content[init_end:]
        
        return content
    
    def fix_duplicate_enums(self, content: str) -> str:
        """Remove duplicate enum definitions"""
        # If alpaca enums are imported, remove local definitions
        if 'from alpaca.trading.enums import' in content:
            # Patterns for duplicate enum classes
            enum_patterns = []
                r'class\s+OrderSide\s*\([^)]*\)\s*:.*?(?=\nclass|\n\S|\Z)',
                r'class\s+TimeInForce\s*\([^)]*\)\s*:.*?(?=\nclass|\n\S|\Z)',
                r'class\s+OrderType\s*\([^)]*\)\s*:.*?(?=\nclass|\n\S|\Z)',
                r'class\s+OrderClass\s*\([^)]*\)\s*:.*?(?=\nclass|\n\S|\Z)',
                r'class\s+AssetClass\s*\([^)]*\)\s*:.*?(?=\nclass|\n\S|\Z)',
            ]
            
            for pattern in enum_patterns:
                matches = list(re.finditer(pattern, content, re.DOTALL))
                for match in reversed(matches):
                    # Check if this is after the import
                    import_pos = content.find('from alpaca.trading.enums import')
                    if match.start() > import_pos:
                        content = content[:match.start()] + content[match.end():]
                        self.issues_fixed['enums'] += 1
        
        return content
    
    def fix_broken_syntax(self, content: str) -> str:
        """Fix various broken syntax issues"""
        # Fix duplicate parameter assignments
        content = re.sub(r'symbol_or_symbols\s*=\s*symbol\s*=\s*(\w+)', r'symbol_or_symbols=\1', content)
        content = re.sub(r'timeframe\s*=\s*timeframe\s*=\s*(\w+)', r'timeframe=\1', content)
        
        # Fix broken StockBarsRequest calls
        content = re.sub(r'StockBarsRequest\(symbol_or_symbols=StockBarsRequest\(', 'StockBarsRequest(', content)
        content = re.sub(r'\)\)', ')', content)
        
        # Fix duplicate method calls
        content = re.sub(r'self\.data_client\s*=\s*StockHistoricalDataClient\([^)]+\)\s*\n\s*self\.data_client\s*=\s*StockHistoricalDataClient\([^)]+\)', 
                        lambda m: m.group(0).split('\n')[0], content)
        
        # Fix broken imports at the start of methods
        content = re.sub(r'def\s+\w+\s*\([^)]*\)\s*:\s*\n\s*from alpaca', 
                        lambda m: m.group(0).replace('\n    from alpaca', '\n    # from alpaca'), content)
        
        self.issues_fixed['syntax'] += 1
        
        return content
    
    def process_directory(self, directory: str = '.'):
        """Process all Python files in directory"""
        # Get all Python files
        python_files = []
        
        # Common directories to skip
        skip_dirs = {}
            'venv', 'env', '__pycache__', '.git', '.venv', 
            'node_modules', 'build', 'dist', '.eggs',
            'backup_', '.pytest_cache', '.mypy_cache'
        }
        
        for root, dirs, files in os.walk(directory):
            # Skip directories
            dirs[:] = [d for d in dirs if not any(skip in d for skip in skip_dirs)]
            
            for file in files:
                if file.endswith('.py') and not file.startswith('test_'):
                    filepath = os.path.join(root, file)
                    # Skip this script
                    if 'fix_all_production_issues' not in filepath:
                        python_files.append(filepath)
        
        print(f"\n🔍 Found {len(python_files)} Python files to check")
        print(f"📁 Backup directory: {self.backup_dir}\n")
        
        # Process files
        for i, filepath in enumerate(python_files, 1):
            print(f"[{i}/{len(python_files)}] Checking {filepath}...", end='')
            if self.fix_file(filepath):
                print(" ✅ FIXED")
            else:
                print(" ⏭️  No changes needed")
        
        # Generate summary report
        self.generate_report()
    
    def generate_report(self):
        """Generate detailed report of fixes"""
        print("\n" + "="*60)
        print("📊 FIX SUMMARY REPORT")
        print("="*60)
        
        print(f"\n📈 Files Processed:")
        print(f"   Total files checked: {len(self.fixed_files) + len(self.errors)}")
        print(f"   Files fixed: {len(self.fixed_files)}")
        print(f"   Files with errors: {len(self.errors)}")
        
        print(f"\n🔧 Issues Fixed:")
        total_fixes = 0
        for issue_type, count in self.issues_fixed.items():
            if count > 0:
                print(f"   {issue_type.title()}: {count}")
                total_fixes += count
        print(f"   ---------------------")
        print(f"   Total fixes: {total_fixes}")
        
        if self.errors:
            print(f"\n❌ Errors Encountered:")
            for error in self.errors[:5]:
                print(f"   - {error}")
            if len(self.errors) > 5:
                print(f"   ... and {len(self.errors) - 5} more")
        
        # Save detailed report
        report = {}
            'timestamp': datetime.now().isoformat(),
            'backup_directory': self.backup_dir,
            'files_fixed': len(self.fixed_files),
            'total_issues_fixed': total_fixes,
            'issues_by_type': self.issues_fixed,
            'fixed_files': self.fixed_files,
            'errors': self.errors
        }
        
        report_file = 'production_fixes_report.json'
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n📄 Detailed report saved to: {report_file}")
        print(f"💾 Backups saved to: {self.backup_dir}/")
        
        print("\n✅ ALL PRODUCTION ISSUES FIXED!")
        print("\n📌 Next Steps:")
        print("   1. Install alpaca-py: pip install alpaca-py")
        print("   2. Review the changes in the fixed files")
        print("   3. Test your trading systems")
        print("   4. Check the backup directory if you need to revert any changes")


def main():
    """Main execution"""
    print("🚀 PRODUCTION ISSUE FIXER")
    print("Fixing ALL import errors and reference issues")
    print("="*60)
    
    fixer = ProductionIssueFixer()
    
    # Process current directory by default
    directory = sys.argv[1] if len(sys.argv) > 1 else '.'
    fixer.process_directory(directory)


if __name__ == "__main__":
    main()