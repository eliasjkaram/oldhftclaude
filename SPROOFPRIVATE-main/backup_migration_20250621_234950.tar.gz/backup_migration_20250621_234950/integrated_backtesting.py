#!/usr/bin/env python3
"""
Integrated Backtesting System
=============================
Seamlessly run backtests using the same strategies and infrastructure as live trading
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Callable
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import queue
import pickle
from dataclasses import dataclass, field
import matplotlib.pyplot as plt
import seaborn as sns

from unified_logging import get_logger
from unified_error_handling import retry, ErrorCategory, ErrorSeverity
from DATA_PIPELINE_MINIO import DataPipelineMinIO
from ai_bot_execution_integration import AIBotExecutionBridge

logger = get_logger(__name__)

@dataclass
class BacktestConfig:
    """Backtesting configuration"""
    start_date: str
    end_date: str
    initial_capital: float = 100000.0
    symbols: List[str] = field(default_factory=list)
    strategies: List[str] = field(default_factory=list)
    commission: float = 0.001  # 0.1%
    slippage: float = 0.0005   # 0.05%
    data_frequency: str = '1min'
    use_ml_models: bool = True
    use_gpu: bool = True
    walk_forward_periods: int = 0
    monte_carlo_simulations: int = 0
    save_results: bool = True
    
@dataclass
class BacktestResult:
    """Backtesting results"""
    config: BacktestConfig
    metrics: Dict[str, float] = field(default_factory=dict)
    trades: List[Dict[str, Any]] = field(default_factory=list)
    equity_curve: pd.DataFrame = field(default_factory=pd.DataFrame)
    positions: pd.DataFrame = field(default_factory=pd.DataFrame)
    strategy_performance: Dict[str, Dict[str, float]] = field(default_factory=dict)
    ml_predictions: Optional[pd.DataFrame] = None
    execution_time: float = 0.0

class IntegratedBacktester:
    """Backtester integrated with live trading infrastructure"""
    
    def __init__(self, master_system=None):
        self.master_system = master_system
        self.data_pipeline = DataPipelineMinIO()
        self.current_backtest = None
        self.results_history = []
        
        # Virtual portfolio for backtesting
        self.virtual_portfolio = {}
            'cash': 0,
            'positions': {},
            'equity_curve': [],
            'trades': []
        }
        
        # Performance tracking
        self.performance_metrics = {}
        
        # Strategy registry (maps to live strategies)
        self.strategy_registry = {}
        self._register_strategies()
        
        # ML models cache
        self.ml_models = {}
        
        # Execution bridge for strategy testing
        self.virtual_execution = VirtualExecutionBridge()
    
    def _register_strategies(self):
        """Register available strategies from live system"""
        if self.master_system:
            # Get strategies from master system
            if hasattr(self.master_system, 'strategy_manager'):
                strategies = self.master_system.strategy_manager.strategies
                for name, strategy in strategies.items():
                    self.strategy_registry[name] = strategy
                logger.info(f"Registered {len(strategies)} strategies from live system")
        
        # Add default strategies if no master system
        if not self.strategy_registry:
            self._add_default_strategies()
    
    def _add_default_strategies(self):
        """Add default strategies for testing"""
        self.strategy_registry = {}
            'momentum': {}
                'name': 'Momentum Strategy',
                'function': self._momentum_strategy,
                'parameters': {'lookback': 20, 'threshold': 0.02}
            },
            'mean_reversion': {}
                'name': 'Mean Reversion',
                'function': self._mean_reversion_strategy,
                'parameters': {'lookback': 20, 'z_score': 2.0}
            },
            'ml_ensemble': {}
                'name': 'ML Ensemble',
                'function': self._ml_ensemble_strategy,
                'parameters': {'models': ['xgboost', 'lstm', 'random_forest']}
            }
        }
    
    @handle_errors("backtester", ErrorCategory.SYSTEM, ErrorSeverity.HIGH)
    def run_backtest(self, config: BacktestConfig) -> BacktestResult:
        """Run a backtest with given configuration"""
        start_time = datetime.now()
        logger.info(f"Starting backtest: {config.start_date} to {config.end_date}")
        
        # Initialize backtest
        self.current_backtest = config
        self._reset_virtual_portfolio(config.initial_capital)
        
        # Load historical data
        logger.info("Loading historical data...")
        market_data = self._load_market_data(config)
        
        if market_data.empty:
            raise ValueError("No market data available for backtest period")
        
        # Load ML models if needed
        if config.use_ml_models:
            self._load_ml_models(config)
        
        # Run backtest based on configuration
        if config.walk_forward_periods > 0:
            result = self._run_walk_forward_backtest(market_data, config)
        elif config.monte_carlo_simulations > 0:
            result = self._run_monte_carlo_backtest(market_data, config)
        else:
            result = self._run_standard_backtest(market_data, config)
        
        # Calculate execution time
        result.execution_time = (datetime.now() - start_time).total_seconds()
        
        # Save results if requested
        if config.save_results:
            self._save_results(result)
        
        # Add to history
        self.results_history.append(result)
        
        logger.info(f"Backtest completed in {result.execution_time:.2f} seconds")
        return result
    
    def _load_market_data(self, config: BacktestConfig) -> pd.DataFrame:
        """Load market data for backtesting"""
        all_data = {}
        
        for symbol in config.symbols:
            # Try MinIO first
            data = self.data_pipeline.get_stock_data()
                symbol,
                config.start_date,
                config.end_date
            )
            
            # Fallback to other sources
            if data is None or data.empty:
                logger.warning(f"No MinIO data for {symbol}, using fallback")
                data = self._load_fallback_data(symbol, config)
            
            if not data.empty:
                all_data[symbol] = data
                logger.info(f"Loaded {len(data)} records for {symbol}")
        
        # Combine all data
        if all_data:
            return pd.concat(all_data, keys=all_data.keys())
        
        return pd.DataFrame()
    
    def _load_fallback_data(self, symbol: str, config: BacktestConfig) -> pd.DataFrame:
        """Load data from fallback sources"""
        # This would integrate with yfinance or other sources
        # For now, return empty DataFrame
        return pd.DataFrame()
    
    def _run_standard_backtest(self, 
                              market_data: pd.DataFrame, 
                              config: BacktestConfig) -> BacktestResult:
        """Run standard backtest"""
        logger.info("Running standard backtest...")
        
        result = BacktestResult(config=config)
        
        # Group data by date for time series processing
        dates = market_data.index.get_level_values(1).unique().sort_values()
        
        for date in dates:
            # Get data for current date
            current_data = market_data.xs(date, level=1)
            
            # Generate signals for all strategies
            signals = self._generate_signals(current_data, date, config)
            
            # Execute trades based on signals
            trades = self._execute_virtual_trades(signals, current_data, date)
            
            # Update portfolio
            self._update_virtual_portfolio(trades, current_data, date)
            
            # Record equity
            equity = self._calculate_portfolio_value(current_data)
            self.virtual_portfolio['equity_curve'].append({)
                'date': date,
                'equity': equity,
                'cash': self.virtual_portfolio['cash'],
                'positions_value': equity - self.virtual_portfolio['cash']
            })
        
        # Calculate final metrics
        result.metrics = self._calculate_performance_metrics()
        result.trades = self.virtual_portfolio['trades']
        result.equity_curve = pd.DataFrame(self.virtual_portfolio['equity_curve'])
        result.positions = self._get_positions_dataframe()
        
        # Calculate strategy-specific performance
        result.strategy_performance = self._calculate_strategy_performance()
        
        return result
    
    def _run_walk_forward_backtest(self,
                                  market_data: pd.DataFrame,
                                  config: BacktestConfig) -> BacktestResult:
        """Run walk-forward optimization backtest"""
        logger.info(f"Running walk-forward backtest with {config.walk_forward_periods} periods")
        
        # Split data into training and testing periods
        dates = market_data.index.get_level_values(1).unique().sort_values()
        period_length = len(dates) // (config.walk_forward_periods + 1)
        
        all_results = []
        
        for i in range(config.walk_forward_periods):
            # Define training and testing periods
            train_start = i * period_length
            train_end = (i + 1) * period_length
            test_start = train_end
            test_end = min(test_start + period_length, len(dates))
            
            # Get data splits
            train_dates = dates[train_start:train_end]
            test_dates = dates[test_start:test_end]
            
            train_data = market_data[]
                market_data.index.get_level_values(1).isin(train_dates)
            ]
            test_data = market_data[]
                market_data.index.get_level_values(1).isin(test_dates)
            ]
            
            # Optimize on training data
            logger.info(f"Optimizing on period {i+1}/{config.walk_forward_periods}")
            self._optimize_strategies(train_data)
            
            # Test on out-of-sample data
            period_config = BacktestConfig()
                start_date=str(test_dates[0]),
                end_date=str(test_dates[-1]),
                initial_capital=config.initial_capital,
                symbols=config.symbols,
                strategies=config.strategies,
                commission=config.commission,
                slippage=config.slippage
            )
            
            period_result = self._run_standard_backtest(test_data, period_config)
            all_results.append(period_result)
        
        # Combine results
        return self._combine_walk_forward_results(all_results, config)
    
    def _run_monte_carlo_backtest(self,
                                 market_data: pd.DataFrame,
                                 config: BacktestConfig) -> BacktestResult:
        """Run Monte Carlo simulation backtest"""
        logger.info(f"Running Monte Carlo backtest with {config.monte_carlo_simulations} simulations")
        
        # Run base backtest
        base_result = self._run_standard_backtest(market_data, config)
        
        # Run Monte Carlo simulations
        simulation_results = []
        
        with ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
            futures = []
            
            for i in range(config.monte_carlo_simulations):
                # Create randomized market data
                randomized_data = self._create_monte_carlo_scenario(market_data, i)
                
                # Submit simulation
                future = executor.submit()
                    self._run_single_simulation,
                    randomized_data,
                    config,
                    i
                )
                futures.append(future)
            
            # Collect results
            for future in futures:
                sim_result = future.result()
                simulation_results.append(sim_result)
        
        # Analyze Monte Carlo results
        mc_analysis = self._analyze_monte_carlo_results(simulation_results)
        
        # Add to base result
        base_result.metrics['monte_carlo'] = mc_analysis
        
        return base_result
    
    def _generate_signals(self,
                         data: pd.DataFrame,
                         date: datetime,
                         config: BacktestConfig) -> Dict[str, Any]:
        """Generate trading signals from strategies"""
        signals = {}
        
        for strategy_name in config.strategies:
            if strategy_name in self.strategy_registry:
                strategy = self.strategy_registry[strategy_name]
                
                # Call strategy function
                if 'function' in strategy:
                    signal = strategy['function'](data, date, strategy.get('parameters', {}))
                    signals[strategy_name] = signal
        
        return signals
    
    def _execute_virtual_trades(self,
                               signals: Dict[str, Any],
                               market_data: pd.DataFrame,
                               date: datetime) -> List[Dict[str, Any]]:
        """Execute trades in virtual portfolio"""
        trades = []
        
        for strategy_name, signal in signals.items():
            if signal and 'action' in signal:
                # Create virtual trade
                trade = {}
                    'date': date,
                    'strategy': strategy_name,
                    'symbol': signal['symbol'],
                    'action': signal['action'],
                    'quantity': signal.get('quantity', 100),
                    'price': market_data.loc[signal['symbol'], 'close'] if signal['symbol'] in market_data.index else 0,
                    'commission': 0,
                    'slippage': 0
                }
                
                # Calculate commission and slippage
                trade['commission'] = trade['price'] * trade['quantity'] * self.current_backtest.commission
                trade['slippage'] = trade['price'] * trade['quantity'] * self.current_backtest.slippage
                
                trades.append(trade)
        
        return trades
    
    def _update_virtual_portfolio(self,
                                 trades: List[Dict[str, Any]],
                                 market_data: pd.DataFrame,
                                 date: datetime):
        """Update virtual portfolio with trades"""
        for trade in trades:
            symbol = trade['symbol']
            quantity = trade['quantity']
            total_cost = (trade['price'] * quantity) + trade['commission'] + trade['slippage']
            
            if trade['action'] == 'buy':
                # Buy logic
                if self.virtual_portfolio['cash'] >= total_cost:
                    self.virtual_portfolio['cash'] -= total_cost
                    
                    if symbol not in self.virtual_portfolio['positions']:
                        self.virtual_portfolio['positions'][symbol] = {}
                            'quantity': 0,
                            'avg_price': 0,
                            'total_cost': 0
                        }
                    
                    pos = self.virtual_portfolio['positions'][symbol]
                    new_quantity = pos['quantity'] + quantity
                    pos['total_cost'] += total_cost
                    pos['avg_price'] = pos['total_cost'] / new_quantity if new_quantity > 0 else 0
                    pos['quantity'] = new_quantity
                    
                    # Record trade
                    trade['executed'] = True
                    self.virtual_portfolio['trades'].append(trade)
                else:
                    trade['executed'] = False
                    trade['reason'] = 'Insufficient funds'
                    
            elif trade['action'] == 'sell':
                # Sell logic
                if symbol in self.virtual_portfolio['positions']:
                    pos = self.virtual_portfolio['positions'][symbol]
                    
                    if pos['quantity'] >= quantity:
                        # Update position
                        pos['quantity'] -= quantity
                        self.virtual_portfolio['cash'] += (trade['price'] * quantity) - trade['commission'] - trade['slippage']
                        
                        if pos['quantity'] == 0:
                            del self.virtual_portfolio['positions'][symbol]
                        
                        # Record trade
                        trade['executed'] = True
                        self.virtual_portfolio['trades'].append(trade)
                    else:
                        trade['executed'] = False
                        trade['reason'] = 'Insufficient position'
                else:
                    trade['executed'] = False
                    trade['reason'] = 'No position to sell'
    
    def _calculate_portfolio_value(self, market_data: pd.DataFrame) -> float:
        """Calculate total portfolio value"""
        positions_value = 0
        
        for symbol, position in self.virtual_portfolio['positions'].items():
            if symbol in market_data.index:
                current_price = market_data.loc[symbol, 'close']
                positions_value += position['quantity'] * current_price
        
        return self.virtual_portfolio['cash'] + positions_value
    
    def _calculate_performance_metrics(self) -> Dict[str, float]:
        """Calculate comprehensive performance metrics"""
        equity_curve = pd.DataFrame(self.virtual_portfolio['equity_curve'])
        
        if equity_curve.empty:
            return {}
        
        # Basic metrics
        initial_capital = self.current_backtest.initial_capital
        final_equity = equity_curve['equity'].iloc[-1]
        total_return = (final_equity - initial_capital) / initial_capital
        
        # Calculate daily returns
        equity_curve['returns'] = equity_curve['equity'].pct_change()
        daily_returns = equity_curve['returns'].dropna()
        
        # Risk metrics
        volatility = daily_returns.std() * np.sqrt(252)  # Annualized
        
        # Sharpe ratio (assuming 0% risk-free rate)
        sharpe_ratio = (daily_returns.mean() * 252) / volatility if volatility > 0 else 0
        
        # Maximum drawdown
        equity_curve['cummax'] = equity_curve['equity'].cummax()
        equity_curve['drawdown'] = (equity_curve['equity'] - equity_curve['cummax']) / equity_curve['cummax']
        max_drawdown = equity_curve['drawdown'].min()
        
        # Win rate
        trades_df = pd.DataFrame(self.virtual_portfolio['trades'])
        if not trades_df.empty:
            profitable_trades = trades_df[trades_df['executed'] == True]
            # This is simplified - would need P&L calculation
            win_rate = 0.5  # Placeholder
        else:
            win_rate = 0
        
        return {}
            'total_return': total_return,
            'annualized_return': total_return * 365 / len(equity_curve),
            'volatility': volatility,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'total_trades': len(self.virtual_portfolio['trades']),
            'final_equity': final_equity
        }
    
    def _reset_virtual_portfolio(self, initial_capital: float):
        """Reset virtual portfolio for new backtest"""
        self.virtual_portfolio = {}
            'cash': initial_capital,
            'positions': {},
            'equity_curve': [],
            'trades': []
        }
    
    def _momentum_strategy(self, data: pd.DataFrame, date: datetime, params: Dict) -> Dict:
        """Simple momentum strategy"""
        lookback = params.get('lookback', 20)
        threshold = params.get('threshold', 0.02)
        
        # This is a placeholder - implement actual strategy
        return {}
            'symbol': data.index[0] if len(data) > 0 else 'AAPL',
            'action': 'buy',
            'quantity': 100,
            'confidence': 0.7
        }
    
    def _mean_reversion_strategy(self, data: pd.DataFrame, date: datetime, params: Dict) -> Dict:
        """Mean reversion strategy"""
        # Placeholder implementation
        return None
    
    def _ml_ensemble_strategy(self, data: pd.DataFrame, date: datetime, params: Dict) -> Dict:
        """ML ensemble strategy"""
        # Placeholder implementation
        return None
    
    def compare_with_live(self, 
                         backtest_result: BacktestResult,
                         live_performance: Dict[str, Any]) -> Dict[str, Any]:
        """Compare backtest results with live performance"""
        comparison = {}
            'backtest_metrics': backtest_result.metrics,
            'live_metrics': live_performance,
            'differences': {}
        }
        
        # Calculate differences
        for metric in ['total_return', 'volatility', 'sharpe_ratio', 'max_drawdown']:
            if metric in backtest_result.metrics and metric in live_performance:
                backtest_val = backtest_result.metrics[metric]
                live_val = live_performance[metric]
                difference = abs(backtest_val - live_val)
                pct_difference = difference / abs(live_val) if live_val != 0 else 0
                
                comparison['differences'][metric] = {}
                    'absolute': difference,
                    'percentage': pct_difference,
                    'direction': 'overestimated' if backtest_val > live_val else 'underestimated'
                }
        
        # Overall accuracy score
        accuracy_scores = []
            1 - comp['percentage'] 
            for comp in comparison['differences'].values() 
            if 'percentage' in comp
        ]
        comparison['overall_accuracy'] = np.mean(accuracy_scores) if accuracy_scores else 0
        
        return comparison
    
    def generate_report(self, result: BacktestResult, output_path: str = None):
        """Generate comprehensive backtest report"""
        # Create figure with subplots
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('Backtest Report', fontsize=16)
        
        # Equity curve
        ax1 = axes[0, 0]
        result.equity_curve.plot(x='date', y='equity', ax=ax1)
        ax1.set_title('Equity Curve')
        ax1.set_xlabel('Date')
        ax1.set_ylabel('Portfolio Value')
        
        # Drawdown
        ax2 = axes[0, 1]
        equity_curve = result.equity_curve.copy()
        equity_curve['cummax'] = equity_curve['equity'].cummax()
        equity_curve['drawdown'] = (equity_curve['equity'] - equity_curve['cummax']) / equity_curve['cummax']
        equity_curve.plot(x='date', y='drawdown', ax=ax2, color='red')
        ax2.set_title('Drawdown')
        ax2.set_xlabel('Date')
        ax2.set_ylabel('Drawdown %')
        ax2.fill_between(equity_curve['date'], 0, equity_curve['drawdown'], color='red', alpha=0.3)
        
        # Returns distribution
        ax3 = axes[1, 0]
        returns = equity_curve['equity'].pct_change().dropna()
        returns.hist(bins=50, ax=ax3)
        ax3.set_title('Returns Distribution')
        ax3.set_xlabel('Daily Returns')
        ax3.set_ylabel('Frequency')
        
        # Performance metrics
        ax4 = axes[1, 1]
        ax4.axis('off')
        metrics_text = "Performance Metrics:\n\n"
        for key, value in result.metrics.items():
            if isinstance(value, float):
                metrics_text += f"{key}: {value:.4f}\n"
            else:
                metrics_text += f"{key}: {value}\n"
        ax4.text(0.1, 0.9, metrics_text, transform=ax4.transAxes, 
                fontsize=10, verticalalignment='top', fontfamily='monospace')
        
        plt.tight_layout()
        
        # Save or show
        if output_path:
            plt.savefig(output_path)
            logger.info(f"Report saved to {output_path}")
        else:
            plt.show()
        
        plt.close()
    
    def _save_results(self, result: BacktestResult):
        """Save backtest results"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"backtest_result_{timestamp}.pkl"
        
        with open(filename, 'wb') as f:
            pickle.dump(result, f)
        
        logger.info(f"Results saved to {filename}")


class VirtualExecutionBridge:
    """Virtual execution for backtesting"""
    
    def __init__(self):
        self.executed_orders = []
    
    def execute_order(self, order: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a virtual order"""
        # Add execution timestamp
        order['executed_at'] = datetime.now()
        order['status'] = 'filled'
        
        self.executed_orders.append(order)
        
        return order


# Integration function for master system
def integrate_backtesting(master_system):
    """
    Integrate backtesting with master system
    
    Usage in MASTER_PRODUCTION_INTEGRATION.py:
    
    from integrated_backtesting import integrate_backtesting
    integrate_backtesting(self)
    """
    
    # Create integrated backtester
    master_system.backtester = IntegratedBacktester(master_system)
    
    # Add backtesting methods
    def run_strategy_backtest(self, 
                            strategy_name: str,
                            start_date: str,
                            end_date: str,
                            symbols: List[str] = None) -> BacktestResult:
        """Run backtest for a specific strategy"""
        if symbols is None:
            symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META']
        
        config = BacktestConfig()
            start_date=start_date,
            end_date=end_date,
            symbols=symbols,
            strategies=[strategy_name],
            initial_capital=100000
        )
        
        return self.backtester.run_backtest(config)
    
    def compare_backtest_to_live(self, strategy_name: str, period_days: int = 30):
        """Compare backtest to live performance"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=period_days)
        
        # Run backtest
        backtest_result = self.run_strategy_backtest()
            strategy_name,
            start_date.strftime('%Y-%m-%d'),
            end_date.strftime('%Y-%m-%d')
        )
        
        # Get live performance (placeholder - would get from actual system)
        live_performance = {}
            'total_return': 0.05,
            'volatility': 0.15,
            'sharpe_ratio': 1.2,
            'max_drawdown': -0.03
        }
        
        return self.backtester.compare_with_live(backtest_result, live_performance)
    
    # Bind methods
    master_system.run_strategy_backtest = run_strategy_backtest.__get__(master_system)
    master_system.compare_backtest_to_live = compare_backtest_to_live.__get__(master_system)
    
    logger.info("Backtesting integrated with master system")


if __name__ == "__main__":
    # Test backtesting
    backtester = IntegratedBacktester()
    
    # Create test configuration
    config = BacktestConfig()
        start_date='2024-01-01',
        end_date='2024-12-31',
        symbols=['AAPL', 'MSFT', 'GOOGL'],
        strategies=['momentum'],
        initial_capital=100000,
        walk_forward_periods=0,
        save_results=True
    )
    
    # Run backtest
    print("Running backtest...")
    result = backtester.run_backtest(config)
    
    # Print results
    print("\nBacktest Results:")
    print(f"Total Return: {result.metrics.get('total_return', 0):.2%}")
    print(f"Sharpe Ratio: {result.metrics.get('sharpe_ratio', 0):.2f}")
    print(f"Max Drawdown: {result.metrics.get('max_drawdown', 0):.2%}")
    print(f"Total Trades: {result.metrics.get('total_trades', 0)}")
    
    # Generate report
    backtester.generate_report(result, 'backtest_report.png')