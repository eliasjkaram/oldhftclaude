#!/usr/bin/env python3
"""
SECURE TRADING CONFIGURATION
===========================

Production-ready configuration management without hardcoded credentials.
All sensitive data must be provided via environment variables or secure storage.
"""

import os
import json
import logging
from typing import Dict, Optional, Any
from dataclasses import dataclass
from pathlib import Path
import warnings

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TradingConfig:
    """Trading system configuration"""
    # API Configuration
    alpaca_paper_key: Optional[str] = None
    alpaca_paper_secret: Optional[str] = None
    alpaca_paper_base_url: str = "https://paper-api.alpaca.markets"
    
    alpaca_live_key: Optional[str] = None
    alpaca_live_secret: Optional[str] = None
    alpaca_live_base_url: str = "https://api.alpaca.markets"
    
    openrouter_api_key: Optional[str] = None
    
    # Risk Management
    risk_limits: Dict[str, float] = None
    
    # Trading Settings
    trading_settings: Dict[str, Any] = None
    
    # System Settings
    environment: str = "development"
    debug_mode: bool = False
    
    def __post_init__(self):
        """Initialize default values"""
        if self.risk_limits is None:
            self.risk_limits = {}
                'max_position_size_pct': 0.1,      # 10% max per position
                'max_portfolio_risk_pct': 0.02,    # 2% daily VaR
                'max_drawdown_pct': 0.15,          # 15% max drawdown
                'min_cash_ratio': 0.2,             # 20% minimum cash
                'max_leverage': 1.0,               # No leverage by default
                'max_correlation': 0.7,            # Max correlation between positions
                'position_limit': 20,              # Max number of positions
                'daily_loss_limit_pct': 0.02       # 2% daily loss limit
            }
        
        if self.trading_settings is None:
            self.trading_settings = {}
                'default_order_type': 'limit',
                'default_time_in_force': 'day',
                'enable_extended_hours': False,
                'enable_fractional_shares': True,
                'max_order_value': 10000,
                'min_order_value': 1,
                'rate_limit_orders_per_minute': 10,
                'cancel_orders_on_disconnect': True,
                'require_confirmation': True        # Require confirmation for orders
            }

class SecureConfigManager:
    """Secure configuration management"""
    
    def __init__(self, config_dir: Optional[Path] = None):
        """Initialize configuration manager"""
        self.config_dir = config_dir or Path.home() / ".alpaca_mcp"
        self.config_dir.mkdir(exist_ok=True)
        self.config_file = self.config_dir / "config.json"
        self.env_file = self.config_dir / ".env"
        
        # Security warning for production
        if os.getenv('TRADING_ENVIRONMENT') == 'production':
            logger.warning("🔴 PRODUCTION ENVIRONMENT DETECTED - Ensure all security measures are in place!")
    
    def load_from_environment(self) -> TradingConfig:
        """Load configuration from environment variables"""
        config = TradingConfig()
        
        # Load from environment variables (highest priority)
        config.alpaca_paper_key = os.getenv('ALPACA_PAPER_KEY')
        config.alpaca_paper_secret = os.getenv('ALPACA_PAPER_SECRET')
        config.alpaca_paper_base_url = os.getenv('ALPACA_PAPER_BASE_URL', config.alpaca_paper_base_url)
        
        config.alpaca_live_key = os.getenv('ALPACA_LIVE_KEY')
        config.alpaca_live_secret = os.getenv('ALPACA_LIVE_SECRET')
        config.alpaca_live_base_url = os.getenv('ALPACA_LIVE_BASE_URL', config.alpaca_live_base_url)
        
        config.openrouter_api_key = os.getenv('OPENROUTER_API_KEY')
        
        config.environment = os.getenv('TRADING_ENVIRONMENT', 'development')
        config.debug_mode = os.getenv('DEBUG_MODE', 'false').lower() == 'true'
        
        # Load risk limits from environment if provided
        risk_limit_prefix = 'RISK_LIMIT_'
        for key, value in os.environ.items():
            if key.startswith(risk_limit_prefix):
                risk_key = key[len(risk_limit_prefix):].lower()
                try:
                    config.risk_limits[risk_key] = float(value)
                except ValueError:
                    logger.warning(f"Invalid risk limit value for {key}: {value}")
        
        return config
    
    def load_from_file(self, config_file: Optional[Path] = None) -> TradingConfig:
        """Load configuration from JSON file (non-sensitive data only)"""
        file_path = config_file or self.config_file
        
        if not file_path.exists():
            logger.info(f"Config file not found: {file_path}")
            return TradingConfig()
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Only load non-sensitive configuration
            config = TradingConfig()
            config.risk_limits.update(data.get('risk_limits', {})
            config.trading_settings.update(data.get('trading_settings', {})
            config.environment = data.get('environment', config.environment)
            
            logger.info(f"Loaded configuration from {file_path}")
            return config
            
        except Exception as e:
            logger.error(f"Failed to load config file: {e}")
            return TradingConfig()
    
    def merge_configs(self, *configs: TradingConfig) -> TradingConfig:
        """Merge multiple configurations (later configs override earlier ones)"""
        result = TradingConfig()
        
        for config in configs:
            # Merge credentials (only if not None)
            if config.alpaca_paper_key:
                result.alpaca_paper_key = config.alpaca_paper_key
            if config.alpaca_paper_secret:
                result.alpaca_paper_secret = config.alpaca_paper_secret
            if config.alpaca_live_key:
                result.alpaca_live_key = config.alpaca_live_key
            if config.alpaca_live_secret:
                result.alpaca_live_secret = config.alpaca_live_secret
            if config.openrouter_api_key:
                result.openrouter_api_key = config.openrouter_api_key
            
            # Merge settings
            result.risk_limits.update(config.risk_limits)
            result.trading_settings.update(config.trading_settings)
            result.environment = config.environment
            result.debug_mode = config.debug_mode or result.debug_mode
        
        return result
    
    def validate_config(self, config: TradingConfig) -> Dict[str, bool]:
        """Validate configuration completeness"""
        validation = {}
            'has_paper_credentials': bool(config.alpaca_paper_key and config.alpaca_paper_secret),
            'has_live_credentials': bool(config.alpaca_live_key and config.alpaca_live_secret),
            'has_openrouter_key': bool(config.openrouter_api_key),
            'risk_limits_valid': self._validate_risk_limits(config.risk_limits),
            'trading_settings_valid': self._validate_trading_settings(config.trading_settings)
        }
        
        # Overall validation
        if config.environment == 'production':
            validation['production_ready'] = all([)
                validation['has_live_credentials'],
                validation['risk_limits_valid'],
                validation['trading_settings_valid']
            ])
        else:
            validation['development_ready'] = validation['has_paper_credentials']
        
        return validation
    
    def _validate_risk_limits(self, risk_limits: Dict[str, float]) -> bool:
        """Validate risk limit values"""
        try:
            assert 0 < risk_limits['max_position_size_pct'] <= 0.5
            assert 0 < risk_limits['max_portfolio_risk_pct'] <= 0.1
            assert 0 < risk_limits['max_drawdown_pct'] <= 0.5
            assert 0 <= risk_limits['min_cash_ratio'] <= 1.0
            assert risk_limits['max_leverage'] >= 1.0
            assert 0 < risk_limits['position_limit'] <= 100
            return True
        except (AssertionError, KeyError):
            return False
    
    def _validate_trading_settings(self, trading_settings: Dict[str, Any]) -> bool:
        """Validate trading settings"""
        try:
            assert trading_settings['default_order_type'] in ['market', 'limit', 'stop', 'stop_limit']
            assert trading_settings['default_time_in_force'] in ['day', 'gtc', 'ioc', 'fok']
            assert trading_settings['max_order_value'] > trading_settings['min_order_value']
            assert trading_settings['rate_limit_orders_per_minute'] > 0
            return True
        except (AssertionError, KeyError):
            return False
    
    def create_template_files(self):
        """Create template configuration files"""
        # Create .env.template
        env_template = """# Alpaca Paper Trading (for development/testing)
ALPACA_PAPER_KEY=your_paper_api_key_here
ALPACA_PAPER_SECRET=your_paper_secret_key_here

# Alpaca Live Trading (for production - handle with extreme care!)
# ALPACA_LIVE_KEY=your_live_api_key_here
# ALPACA_LIVE_SECRET=your_live_secret_key_here

# OpenRouter API (for AI features)
OPENROUTER_API_KEY=your_openrouter_key_here

# Environment Settings
TRADING_ENVIRONMENT=development  # Options: development, staging, production
DEBUG_MODE=false

# Risk Limits (optional - defaults are conservative)
# RISK_LIMIT_MAX_POSITION_SIZE_PCT=0.1
# RISK_LIMIT_MAX_PORTFOLIO_RISK_PCT=0.02
# RISK_LIMIT_MAX_DRAWDOWN_PCT=0.15
"""
        
        template_path = self.config_dir / ".env.template"
        with open(template_path, 'w') as f:
            f.write(env_template)
        
        # Create config.json template
        config_template = {}
            "risk_limits": {}
                "max_position_size_pct": 0.1,
                "max_portfolio_risk_pct": 0.02,
                "max_drawdown_pct": 0.15,
                "min_cash_ratio": 0.2,
                "max_leverage": 1.0,
                "max_correlation": 0.7,
                "position_limit": 20,
                "daily_loss_limit_pct": 0.02
            },
            "trading_settings": {}
                "default_order_type": "limit",
                "default_time_in_force": "day",
                "enable_extended_hours": False,
                "enable_fractional_shares": True,
                "max_order_value": 10000,
                "min_order_value": 1,
                "rate_limit_orders_per_minute": 10,
                "cancel_orders_on_disconnect": True,
                "require_confirmation": True
            }
        }
        
        config_template_path = self.config_dir / "config.template.json"
        with open(config_template_path, 'w') as f:
            json.dump(config_template, f, indent=2)
        
        logger.info(f"✅ Created template files in {self.config_dir}")
        logger.info(f"   - {template_path}")
        logger.info(f"   - {config_template_path}")
        
        # Security reminder
        print("\n⚠️  SECURITY REMINDERS:")
        print("1. NEVER commit .env files to version control")
        print("2. Use strong, unique API keys")
        print("3. Enable 2FA on your trading accounts")
        print("4. Restrict API key permissions to minimum required")
        print("5. Rotate keys regularly")
        print("6. Monitor for unauthorized access")

def get_config() -> TradingConfig:
    """Get merged configuration from all sources"""
    manager = SecureConfigManager()
    
    # Load configurations in order of priority (lowest to highest)
    file_config = manager.load_from_file()
    env_config = manager.load_from_environment()
    
    # Merge configurations
    config = manager.merge_configs(file_config, env_config)
    
    # Validate
    validation = manager.validate_config(config)
    
    # Log validation results
    logger.info("Configuration validation results:")
    for check, passed in validation.items():
        status = "✅" if passed else "❌"
        logger.info(f"  {status} {check}")
    
    # Warnings for missing configurations
    if not validation.get('has_paper_credentials'):
        logger.warning("⚠️  Paper trading credentials not configured")
    
    if config.environment == 'production' and not validation.get('production_ready'):
        raise ValueError("🔴 PRODUCTION CONFIGURATION INCOMPLETE - Cannot proceed!")
    
    return config

def setup_production_config():
    """Setup production configuration templates"""
    manager = SecureConfigManager()
    manager.create_template_files()
    
    print("\n📋 NEXT STEPS:")
    print("1. Copy .env.template to .env")
    print("2. Fill in your API credentials")
    print("3. Review and adjust risk limits in config.json")
    print("4. Set TRADING_ENVIRONMENT appropriately")
    print("5. Test with paper trading first!")

if __name__ == "__main__":
    # Setup templates
    setup_production_config()
    
    # Test configuration loading
    print("\n🔍 Testing configuration loading...")
    try:
        config = get_config()
        print("✅ Configuration loaded successfully")
    except Exception as e:
        print(f"❌ Configuration error: {e}")