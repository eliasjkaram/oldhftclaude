
#!/usr/bin/env python3
"""
Next-Generation Integrated Trading System
========================================
Bringing together all advanced improvements into a unified platform
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import asyncio
import logging
from typing import Dict, List, Optional, Set
from datetime import datetime, timedelta
from dataclasses import dataclass
import json

# Import all core improvements
from core.config_manager import get_config_manager, get_config, update_market_regime, MarketRegime
from core.gpu_resource_manager import get_gpu_resource_manager, GPUResourceRequest, GPUResourceType
from core.error_handling import retry, circuit_breaker, safe_async_execute
from core.database_manager import get_database_manager, execute_query, bulk_insert
from core.health_monitor import get_health_monitor, ComponentType
from core.trading_base import TradingBot, TradingSignal, TradingStrategy, OrderSide
from core.data_coordination import get_data_coordinator, DataSource, DataType
from core.ml_management import get_model_manager, ModelConfig, ModelType

# Import next-generation improvements
from core.market_microstructure import ()
    MarketMicrostructureAnalyzer, OrderBookSnapshot, OrderBookLevel,
    MicrostructureSignal, MarketRegime as MicroRegime
)
from core.execution_algorithms import ()
    AdvancedExecutionEngine, ExecutionOrder, ExecutionStrategy, 
    OrderUrgency, ExecutionResult
)
from core.multi_exchange_arbitrage import ()
    MultiExchangeArbitrageSystem, Exchange, ArbitrageOpportunity
)
from core.nlp_market_intelligence import ()

from universal_market_data import get_current_market_data, validate_price

    NLPMarketIntelligence, NewsItem, SentimentSource, 
    NewsCategory, TradingSignalNLP
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class UnifiedSignal:
    """Unified trading signal from all sources"""
    signal_id: str
    symbol: str
    action: OrderSide
    source: str  # 'microstructure', 'arbitrage', 'nlp', 'ml', 'technical'
    confidence: float
    expected_return: float
    time_horizon: int  # minutes
    size_recommendation: int
    execution_strategy: ExecutionStrategy
    metadata: Dict

class NextGenTradingSystem:
    """Next-generation integrated trading system with all improvements"""
    
    def __init__(self):
        logger.info("🚀 Initializing Next-Generation Trading System")
        
        # Core infrastructure
        self.config = get_config()
        self.gpu_manager = get_gpu_resource_manager()
        self.db_manager = get_database_manager()
        self.health_monitor = get_health_monitor()
        self.data_coordinator = get_data_coordinator()
        self.model_manager = get_model_manager()
        
        # Next-gen components
        self.microstructure = MarketMicrostructureAnalyzer()
        self.execution_engine = AdvancedExecutionEngine()
        self.arbitrage_system = None  # Initialized separately
        self.nlp_intelligence = NLPMarketIntelligence()
        
        # System state
        self.active_positions: Dict[str, Dict] = {}
        self.signal_queue: asyncio.Queue = asyncio.Queue()
        self.unified_signals: List[UnifiedSignal] = []
        self.performance_tracker = PerformanceTracker()
        
        # Register with health monitor
        self.health_monitor.register_component("next_gen_system", ComponentType.TRADING_BOT)
        
    async def initialize(self):
        """Initialize all system components"""
        logger.info("Initializing system components...")
        
        # Start health monitoring
        await self.health_monitor.start_monitoring()
        
        # Initialize arbitrage system
        exchanges = [Exchange.ALPACA, Exchange.BINANCE, Exchange.COINBASE]
        self.arbitrage_system = MultiExchangeArbitrageSystem(exchanges)
        await self.arbitrage_system.initialize()
        
        # Start data coordination
        asyncio.create_task(self.data_coordinator.start_scraping()
        
        # Initialize ML models
        await self._initialize_ml_models()
        
        logger.info("✅ System initialization complete")
        
    async def _initialize_ml_models(self):
        """Initialize advanced ML models"""
        # Microstructure prediction model
        micro_config = ModelConfig()
            model_id="microstructure_predictor",
            model_type=ModelType.NEURAL_NETWORK,
            feature_columns=["order_imbalance", "spread", "volume_profile", "liquidity_score"],
            target_column="price_movement",
            hyperparameters={"hidden_size": 256, "dropout": 0.3}
        )
        self.model_manager.create_model(micro_config)
        
        # Arbitrage opportunity scorer
        arb_config = ModelConfig()
            model_id="arbitrage_scorer",
            model_type=ModelType.XGBOOST,
            feature_columns=["price_diff", "volume", "spread", "transfer_time"],
            target_column="success_rate"
        )
        self.model_manager.create_model(arb_config)
        
    async def run(self):
        """Main system loop"""
        logger.info("🎯 Starting main trading loop")
        
        # Start all subsystem tasks
        tasks = []
            asyncio.create_task(self._microstructure_analysis_loop(),
            asyncio.create_task(self._arbitrage_scanning_loop(),
            asyncio.create_task(self._nlp_analysis_loop(),
            asyncio.create_task(self._signal_processing_loop(),
            asyncio.create_task(self._execution_loop(),
            asyncio.create_task(self._risk_monitoring_loop()
        ]
        
        try:
            await asyncio.gather(*tasks)
        except KeyboardInterrupt:
            logger.info("Shutdown requested")
        finally:
            await self.shutdown()
            
    async def _microstructure_analysis_loop(self):
        """Continuous market microstructure analysis"""
        logger.info("Starting microstructure analysis loop")
        
        symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]
        
        while True:
            try:
                for symbol in symbols:
                    # Get order book data (simulated)
                    order_book = await self._get_order_book(symbol)
                    
                    # Analyze microstructure
                    signals = await self.microstructure.analyze_order_book(order_book)
                    
                    # Process microstructure signals
                    for signal in signals:
                        if signal.confidence > 0.7:
                            unified = self._convert_microstructure_signal(signal)
                            await self.signal_queue.put(unified)
                            
                await asyncio.sleep(0.1)  # 100ms cycle
                
            except Exception as e:
                logger.error(f"Error in microstructure loop: {e}")
                await asyncio.sleep(1)
                
    async def _arbitrage_scanning_loop(self):
        """Continuous arbitrage opportunity scanning"""
        logger.info("Starting arbitrage scanning loop")
        
        await self.arbitrage_system.start_scanning()
        
    async def _nlp_analysis_loop(self):
        """Continuous news and sentiment analysis"""
        logger.info("Starting NLP analysis loop")
        
        while True:
            try:
                # Fetch latest news (simulated)
                news_items = await self._fetch_news()
                
                if news_items:
                    # Process news through NLP
                    nlp_signals = await self.nlp_intelligence.process_news_stream(news_items)
                    
                    # Convert to unified signals
                    for signal in nlp_signals:
                        if signal.confidence > 0.6:
                            unified = self._convert_nlp_signal(signal)
                            await self.signal_queue.put(unified)
                            
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in NLP loop: {e}")
                await asyncio.sleep(60)
                
    async def _signal_processing_loop(self):
        """Process and prioritize signals from all sources"""
        logger.info("Starting signal processing loop")
        
        while True:
            try:
                # Get signal from queue
                signal = await self.signal_queue.get()
                
                # Validate and enrich signal
                enriched = await self._enrich_signal(signal)
                
                if enriched:
                    # Check risk limits
                    if await self._check_risk_limits(enriched):
                        # Add to execution queue
                        self.unified_signals.append(enriched)
                        
                        # Log signal
                        logger.info(f"Signal queued: {enriched.action.value} {enriched.symbol} ")
                                  f"from {enriched.source} (confidence: {enriched.confidence:.1%})")
                        
            except Exception as e:
                logger.error(f"Error processing signal: {e}")
                
    async def _execution_loop(self):
        """Execute trades using advanced algorithms"""
        logger.info("Starting execution loop")
        
        while True:
            try:
                # Process queued signals
                if self.unified_signals:
                    # Sort by expected return and confidence
                    self.unified_signals.sort()
                        key=lambda s: s.expected_return * s.confidence, 
                        reverse=True
                    )
                    
                    # Execute top signal
                    signal = self.unified_signals.pop(0)
                    
                    # Create execution order
                    order = ExecutionOrder()
                        order_id=f"NG_{signal.signal_id}",
                        symbol=signal.symbol,
                        side="buy" if signal.action == OrderSide.BUY else "sell",
                        total_quantity=signal.size_recommendation,
                        strategy=signal.execution_strategy,
                        urgency=self._determine_urgency(signal),
                        metadata=signal.metadata
                    )
                    
                    # Execute with advanced algorithms
                    result = await self.execution_engine.execute_order(order)
                    
                    # Track performance
                    await self._track_execution(signal, result)
                    
                await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Error in execution loop: {e}")
                await asyncio.sleep(1)
                
    async def _risk_monitoring_loop(self):
        """Continuous risk monitoring and adjustment"""
        logger.info("Starting risk monitoring loop")
        
        while True:
            try:
                # Calculate current risk metrics
                risk_metrics = await self._calculate_risk_metrics()
                
                # Check if adjustment needed
                if risk_metrics['var_95'] > self.config.risk.max_var:
                    logger.warning(f"VaR limit exceeded: {risk_metrics['var_95']:.2%}")
                    await self._reduce_risk_exposure()
                    
                # Adjust market regime if needed
                market_conditions = await self._assess_market_conditions()
                if market_conditions['volatility'] > 0.03:
                    update_market_regime(MarketRegime.VOLATILE)
                elif market_conditions['trend_strength'] > 0.7:
                    update_market_regime(MarketRegime.TRENDING)
                else:
                    update_market_regime(MarketRegime.SIDEWAYS)
                    
                # Update health metrics
                self.health_monitor.update_component_health()
                    "next_gen_system",
                    healthy=risk_metrics['health_score'] > 0.7,
                    metrics=risk_metrics
                )
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Error in risk monitoring: {e}")
                await asyncio.sleep(30)
                
    async def _get_order_book(self, symbol: str) -> OrderBookSnapshot:
        """Get order book data (simulated for demo)"""
        import random
        import time
        
        base_price = 100.0 + random.gauss(0, 1)
        
        # Generate bid levels
        bids = []
        for i in range(10):
            price = base_price - (i * 0.01) - random.uniform(0, 0.005)
            size = random.randint(100, 5000)
            bids.append(OrderBookLevel(price, size, random.randint(1, 20), time.time())
            
        # Generate ask levels
        asks = []
        for i in range(10):
            price = base_price + (i * 0.01) + random.uniform(0, 0.005)
            size = random.randint(100, 5000)
            asks.append(OrderBookLevel(price, size, random.randint(1, 20), time.time())
            
        return OrderBookSnapshot(symbol, time.time(), bids, asks)
        
    async def _fetch_news(self) -> List[NewsItem]:
        """Fetch latest news (simulated for demo)"""
        # In production, would connect to news APIs
        import random
        
        if random.random() < 0.1:  # 10% chance of news
            return []
                NewsItem()
                    item_id=f"NEWS_{int(datetime.now().timestamp()}",
                    source=SentimentSource.NEWS,
                    timestamp=datetime.now(),
                    headline=f"Breaking: Major tech company announces {random.choice(['earnings beat', 'new product', 'acquisition'])}",
                    content="Detailed news content here...",
                    symbols=[random.choice(["AAPL", "MSFT", "GOOGL"])],
                    category=NewsCategory.MARKET_MOVING,
                    urgency=random.uniform(0.6, 0.9),
                    credibility=0.9
                )
            ]
        return []
        
    def _convert_microstructure_signal(self, signal: MicrostructureSignal) -> UnifiedSignal:
        """Convert microstructure signal to unified format"""
        # Determine action based on signal type
        if signal.signal_type == "order_book_imbalance":
            imbalance = signal.metadata.get("weighted_imbalance", 0)
            action = OrderSide.BUY if imbalance > 0 else OrderSide.SELL
            expected_return = abs(imbalance) * 0.001  # 0.1% per unit imbalance
        else:
            action = OrderSide.BUY  # Default
            expected_return = 0.0005
            
        return UnifiedSignal()
            signal_id=f"MICRO_{int(time.time()*1000)}",
            symbol=signal.symbol,
            action=action,
            source="microstructure",
            confidence=signal.confidence,
            expected_return=expected_return,
            time_horizon=1,  # Very short term
            size_recommendation=self._calculate_position_size(signal.symbol, signal.confidence),
            execution_strategy=ExecutionStrategy.ADAPTIVE,
            metadata=signal.metadata
        )
        
    def _convert_nlp_signal(self, signal: TradingSignalNLP) -> UnifiedSignal:
        """Convert NLP signal to unified format"""
        action = OrderSide.BUY if signal.action == "buy" else OrderSide.SELL
        
        # Execution strategy based on urgency
        if signal.time_horizon < 10:
            strategy = ExecutionStrategy.TWAP
        elif signal.time_horizon < 60:
            strategy = ExecutionStrategy.VWAP
        else:
            strategy = ExecutionStrategy.ICEBERG
            
        return UnifiedSignal()
            signal_id=f"NLP_{signal.signal_id}",
            symbol=signal.symbol,
            action=action,
            source="nlp",
            confidence=signal.confidence,
            expected_return=signal.expected_impact / 100,
            time_horizon=signal.time_horizon,
            size_recommendation=self._calculate_position_size(signal.symbol, signal.confidence),
            execution_strategy=strategy,
            metadata={"trigger": signal.trigger_event, "evidence": signal.supporting_evidence}
        )
        
    async def _enrich_signal(self, signal: UnifiedSignal) -> Optional[UnifiedSignal]:
        """Enrich signal with additional data"""
        try:
            # Get current market data
            market_data = await self.data_coordinator.get_recent_data()
                signal.symbol, DataType.STOCK_PRICE, limit=1
            )
            
            if market_data:
                current_price = market_data[0]['data'].get('close', 100)
                signal.metadata['entry_price'] = current_price
                
            # Get microstructure recommendation
            order_book = await self._get_order_book(signal.symbol)
            exec_rec = self.microstructure.generate_execution_recommendation()
                signal.size_recommendation,
                "buy" if signal.action == OrderSide.BUY else "sell",
                order_book
            )
            
            # Update execution strategy based on microstructure
            if exec_rec['execution_urgency'] == 'immediate':
                signal.execution_strategy = ExecutionStrategy.MARKET
            elif exec_rec['execution_urgency'] == 'iceberg':
                signal.execution_strategy = ExecutionStrategy.ICEBERG
                
            signal.metadata['microstructure_rec'] = exec_rec
            
            return signal
            
        except Exception as e:
            logger.error(f"Error enriching signal: {e}")
            return None
            
    async def _check_risk_limits(self, signal: UnifiedSignal) -> bool:
        """Check if signal passes risk limits"""
        # Position limits
        current_positions = len(self.active_positions)
        if current_positions >= self.config.trading.max_positions:
            return False
            
        # Exposure limits
        position_value = signal.size_recommendation * signal.metadata.get('entry_price', 100)
        current_exposure = sum()
            pos['size'] * pos['entry_price'] 
            for pos in self.active_positions.values()
        )
        
        if current_exposure + position_value > self.config.risk.max_portfolio_risk * 1000000:
            return False
            
        return True
        
    def _calculate_position_size(self, symbol: str, confidence: float) -> int:
        """Calculate appropriate position size"""
        base_size = 100  # Base position size
        
        # Adjust for confidence
        confidence_multiplier = confidence
        
        # Adjust for volatility (would use real volatility in production)
        volatility = 0.02  # 2% daily volatility
        volatility_multiplier = 1 / (1 + volatility * 10)
        
        # Final size
        size = int(base_size * confidence_multiplier * volatility_multiplier)
        
        return max(1, min(size, 1000)  # Between 1 and 1000 shares)
        
    def _determine_urgency(self, signal: UnifiedSignal) -> OrderUrgency:
        """Determine order urgency from signal"""
        if signal.time_horizon < 5:
            return OrderUrgency.IMMEDIATE
        elif signal.time_horizon < 30:
            return OrderUrgency.URGENT
        elif signal.time_horizon < 120:
            return OrderUrgency.NORMAL
        else:
            return OrderUrgency.PASSIVE
            
    async def _track_execution(self, signal: UnifiedSignal, result: ExecutionResult):
        """Track execution performance"""
        # Store in database
        execution_data = {}
            "signal_id": signal.signal_id,
            "symbol": signal.symbol,
            "source": signal.source,
            "action": signal.action.value,
            "expected_return": signal.expected_return,
            "filled_quantity": result.filled_quantity,
            "average_price": result.average_price,
            "market_impact_bps": result.market_impact_bps,
            "slippage_bps": result.slippage_bps,
            "execution_time": result.execution_time_seconds,
            "timestamp": datetime.now().isoformat()
        }
        
        bulk_insert("trading", "executions", [execution_data])
        
        # Update active positions
        if result.filled_quantity > 0:
            self.active_positions[signal.symbol] = {}
                "size": result.filled_quantity,
                "entry_price": result.average_price,
                "entry_time": datetime.now(),
                "source": signal.source
            }
            
        logger.info(f"Execution tracked: {signal.symbol} - ")
                   f"Impact: {result.market_impact_bps:.1f}bps, "
                   f"Slippage: {result.slippage_bps:.1f}bps")
        
    async def _calculate_risk_metrics(self) -> Dict:
        """Calculate current risk metrics"""
        if not self.active_positions:
            return {}
                "var_95": 0.0,
                "expected_shortfall": 0.0,
                "sharpe_ratio": 0.0,
                "max_drawdown": 0.0,
                "health_score": 1.0
            }
            
        # Simplified VaR calculation
        position_values = []
            pos['size'] * pos['entry_price'] 
            for pos in self.active_positions.values()
        ]
        total_value = sum(position_values)
        
        # Assume 2% daily volatility, 95% VaR
        var_95 = total_value * 0.02 * 1.645
        
        return {}
            "var_95": var_95 / 1000000,  # In millions
            "expected_shortfall": var_95 * 1.2 / 1000000,
            "sharpe_ratio": 1.5,  # Placeholder
            "max_drawdown": 0.05,  # 5%
            "health_score": 0.9 if var_95 < 50000 else 0.5
        }
        
    async def _assess_market_conditions(self) -> Dict:
        """Assess overall market conditions"""
        # Would use real market data in production
        return {}
            "volatility": 0.015,  # 1.5% daily vol
            "trend_strength": 0.3,  # Weak trend
            "correlation": 0.6,  # Moderate correlation
            "liquidity": 0.8  # Good liquidity
        }
        
    async def _reduce_risk_exposure(self):
        """Reduce risk by closing positions"""
        logger.warning("Reducing risk exposure...")
        
        # Close least profitable positions first
        positions_by_pnl = sorted()
            self.active_positions.items(),
            key=lambda x: x[1]['entry_price']  # Simplified
        )
        
        # Close bottom 20% of positions
        to_close = positions_by_pnl[:len(positions_by_pnl)//5]
        
        for symbol, position in to_close:
            logger.info(f"Closing position: {symbol}")
            # Would execute close order here
            del self.active_positions[symbol]
            
    async def shutdown(self):
        """Graceful shutdown"""
        logger.info("Shutting down Next-Gen Trading System...")
        
        # Stop all loops
        await self.arbitrage_system.stop_scanning()
        await self.data_coordinator.stop_scraping()
        await self.health_monitor.stop_monitoring()
        
        # Close all positions
        if self.active_positions:
            logger.info(f"Closing {len(self.active_positions)} open positions...")
            for symbol in list(self.active_positions.keys():
                # Would execute close orders here
                pass
                
        logger.info("✅ Shutdown complete")

class PerformanceTracker:
    """Track system performance metrics"""
    
    def __init__(self):
        self.executions = []
        self.daily_pnl = 0.0
        self.total_pnl = 0.0
        
    def track_execution(self, execution: Dict):
        """Track execution performance"""
        self.executions.append(execution)
        
    def get_performance_summary(self) -> Dict:
        """Get performance summary"""
        if not self.executions:
            return {"message": "No executions yet"}
            
        return {}
            "total_executions": len(self.executions),
            "daily_pnl": self.daily_pnl,
            "total_pnl": self.total_pnl,
            "avg_slippage_bps": sum(e.get('slippage_bps', 0) for e in self.executions) / len(self.executions),
            "avg_impact_bps": sum(e.get('market_impact_bps', 0) for e in self.executions) / len(self.executions)
        }

async def main():
    """Main entry point"""
    print(""")
    ╔══════════════════════════════════════════════════════════╗
    ║        NEXT-GENERATION INTEGRATED TRADING SYSTEM         ║
    ╠══════════════════════════════════════════════════════════╣
    ║  ✓ Market Microstructure Intelligence                    ║
    ║  ✓ Advanced Execution Algorithms                         ║
    ║  ✓ Multi-Exchange Arbitrage                            ║
    ║  ✓ NLP Market Intelligence                              ║
    ║  ✓ Unified Signal Processing                            ║
    ║  ✓ Comprehensive Risk Management                         ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    
    # Create and initialize system
    system = NextGenTradingSystem()
    
    try:
        await system.initialize()
        
        # Run system
        await system.run()
        
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:
        logger.error(f"System error: {e}")
    finally:
        await system.shutdown()

if __name__ == "__main__":
    asyncio.run(main()