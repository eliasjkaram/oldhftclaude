#!/usr/bin/env python3
from integrated_wheel_bot import IntegratedWheelBot

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


bot = IntegratedWheelBot()
print('Testing wheel strategy opportunity finding...')
puts = bot.wheel_strategy.find_puts_to_sell()
print(f'Found {len(puts)} put opportunities')
for symbol, option in puts[:3]:
    print(f'{symbol}: ${option.get("strike_price")} PUT exp {option.get("expiration_date")}')

print('\nTesting premium opportunities...')
premium_opps = bot.find_premium_opportunities()
print(f'Found {len(premium_opps)} premium opportunities')
for opp in premium_opps[:2]:
    print(f'{opp.underlying}: ${opp.strike} {opp.option_type.upper()} premium ${opp.mid:.2f}')