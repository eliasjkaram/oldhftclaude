#!/usr/bin/env python3
"""
Enhanced Portfolio Management System
===================================
Advanced portfolio management with real-time risk monitoring
"""

import asyncio
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.trading.requests import MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce

from universal_market_data import get_current_market_data, get_realistic_price

class EnhancedPortfolioManager:
    """Advanced portfolio management system"""
    
    def __init__(self, api_key: str, secret_key: str):
        self.trading_client = TradingClient(api_key, secret_key, paper=True)
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret)
        self.data_client = StockHistoricalDataClient(api_key, secret_key)
        
        self.portfolio_metrics = {}
            'total_value': 0.0,
            'daily_pnl': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'var_95': 0.0
        }
    
    async def rebalance_portfolio(self, target_weights: Dict[str, float]):
        """Intelligent portfolio rebalancing"""
        try:
            account = self.trading_client.get_account()
            portfolio_value = float(account.equity)
            
            positions = self.trading_client.get_all_positions()
            current_weights = {}
            
            # Calculate current weights
            for position in positions:
                market_value = float(position.market_value)
                current_weights[position.symbol] = market_value / portfolio_value
            
            # Calculate rebalancing orders
            for symbol, target_weight in target_weights.items():
                current_weight = current_weights.get(symbol, 0.0)
                weight_diff = target_weight - current_weight
                
                if abs(weight_diff) > 0.01:  # 1% threshold
                    order_value = weight_diff * portfolio_value
                    
                    # Get current price
                    # Implementation for getting price
                    current_price = get_realistic_price(symbol)  # Real price
                    
                    if current_price > 0:
                        quantity = int(abs(order_value) / current_price)
                        
                        if quantity > 0:
                            order_request = MarketOrderRequest()
                                symbol=symbol,
                                qty=quantity,
                                side=OrderSide.BUY if weight_diff > 0 else OrderSide.SELL,
                                time_in_force=TimeInForce.DAY
                            )
                            
                            order = self.trading_client.submit_order(order_request)
                            print(f"Rebalanced {symbol}: {quantity} shares")
            
        except Exception as e:
            print(f"Rebalancing error: {e}")
    
    async def calculate_risk_metrics(self):
        """Calculate advanced risk metrics"""
        try:
            positions = self.trading_client.get_all_positions()
            
            # Portfolio VaR calculation
            portfolio_returns = []  # Would calculate from historical data
            
            if portfolio_returns:
                var_95 = np.percentile(portfolio_returns, 5)
                self.portfolio_metrics['var_95'] = var_95
            
            # Sharpe ratio calculation
            # Implementation here
            
            # Maximum drawdown
            # Implementation here
            
        except Exception as e:
            print(f"Risk calculation error: {e}")

async def main():
    """Enhanced portfolio management demo"""
    API_KEY = "your_api_key"
    SECRET_KEY = "your_secret_key"
    
    portfolio_manager = EnhancedPortfolioManager(API_KEY, SECRET_KEY)
    
    # Target portfolio allocation
    target_weights = {}
        'AAPL': 0.20,
        'MSFT': 0.20,
        'GOOGL': 0.15,
        'AMZN': 0.15,
        'TSLA': 0.10,
        'NVDA': 0.10,
        'SPY': 0.10
    }
    
    while True:
        try:
            await portfolio_manager.calculate_risk_metrics()
            await portfolio_manager.rebalance_portfolio(target_weights)
            
            print(f"Portfolio metrics: {portfolio_manager.portfolio_metrics}")
            
            await asyncio.sleep(300)  # 5 minute cycle
            
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Portfolio management error: {e}")
            await asyncio.sleep(60)

if __name__ == "__main__":
    asyncio.run(main())
