#!/usr/bin/env python3
"""
Cross-Exchange Arbitrage Engine
Ultra-low latency arbitrage system for cryptocurrency markets
"""

import asyncio
import numpy as np
from decimal import Decimal, ROUND_DOWN
from typing import Dict, List, Optional, Tuple, Set, Any, Callable
from dataclasses import dataclass, field
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
import time
import json
import logging
import websockets
import aiohttp
try:
    import uvloop
except ImportError:
    uvloop = None
from sortedcontainers import SortedDict
import threading
import multiprocessing as mp
from multiprocessing import shared_memory
import struct
import mmap
import os
import sys
import signal
import hashlib
import hmac
from enum import Enum, auto
from abc import ABC, abstractmethod
import pandas as pd
from datetime import datetime, timedelta
import redis
import prometheus_client as prom
import ctypes
import socket

# Configure ultra-low latency event loop
if uvloop is not None:
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

# Monitoring metrics
latency_histogram = prom.Histogram('arbitrage_latency_microseconds', 
                                  'Arbitrage detection to execution latency',
                                  buckets=(1, 5, 10, 50, 100, 500, 1000, 5000))
profit_counter = prom.Counter('arbitrage_profit_usd', 'Total arbitrage profit in USD')
opportunity_counter = prom.Counter('arbitrage_opportunities', 'Total arbitrage opportunities detected')
execution_success_rate = prom.Gauge('execution_success_rate', 'Order execution success rate')

class ExchangeType(Enum):
    BINANCE = auto()
    COINBASE = auto()
    KRAKEN = auto()
    FTX = auto()
    HUOBI = auto()
    OKEX = auto()
    BITFINEX = auto()
    GEMINI = auto()

class OrderType(Enum):
    MARKET = auto()
    LIMIT = auto()
    LIMIT_MAKER = auto()
    STOP = auto()
    STOP_LIMIT = auto()

class OrderSide(Enum):
    BUY = auto()
    SELL = auto()

class ArbitrageType(Enum):
    TRIANGULAR = auto()
    CROSS_EXCHANGE = auto()
    STATISTICAL = auto()
    MARKET_MAKING = auto()
    FUNDING_RATE = auto()

@dataclass
class OrderBook:
    """Lock-free order book implementation"""
    exchange: ExchangeType
    symbol: str
    bids: SortedDict  # price -> quantity
    asks: SortedDict  # price -> quantity
    timestamp: int  # nanoseconds
    sequence: int
    
    def __post_init__(self):
        self.lock = threading.RLock()
    
    def update_atomic(self, bids: List[Tuple[float, float]], asks: List[Tuple[float, float]]):
        """Atomic order book update"""
        with self.lock:
            # Update bids
            for price, quantity in bids:
                if quantity == 0:
                    self.bids.pop(price, None)
                else:
                    self.bids[price] = quantity
            
            # Update asks
            for price, quantity in asks:
                if quantity == 0:
                    self.asks.pop(price, None)
                else:
                    self.asks[price] = quantity
            
            self.timestamp = time.time_ns()

@dataclass
class ArbitrageOpportunity:
    """Arbitrage opportunity with execution plan"""
    opportunity_id: str
    arbitrage_type: ArbitrageType
    exchanges: List[ExchangeType]
    symbols: List[str]
    orders: List['Order']
    expected_profit: Decimal
    expected_profit_pct: float
    detected_at: int  # nanoseconds
    expires_at: int
    confidence: float
    risk_score: float
    
    def is_valid(self) -> bool:
        return time.time_ns() < self.expires_at and self.expected_profit > 0

@dataclass
class Order:
    """Order representation with hardware timestamping"""
    order_id: str
    exchange: ExchangeType
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: Decimal
    price: Optional[Decimal]
    timestamp: int  # hardware timestamp in nanoseconds
    status: str = "PENDING"
    filled_quantity: Decimal = Decimal("0")
    average_price: Optional[Decimal] = None
    fees: Decimal = Decimal("0")
    
    def __hash__(self):
        return hash(self.order_id)

class ExchangeConnector(ABC):
    """Abstract base class for exchange connectors"""
    
    def __init__(self, exchange_type: ExchangeType, api_key: str, api_secret: str):
        self.exchange_type = exchange_type
        self.api_key = api_key
        self.api_secret = api_secret
        self.ws_connection = None
        self.rest_session = None
        self.order_books: Dict[str, OrderBook] = {}
        self.pending_orders: Dict[str, Order] = {}
        self.rate_limiter = self._create_rate_limiter()
        
    @abstractmethod
    async def connect_websocket(self):
        """Establish WebSocket connection"""
        pass
    
    @abstractmethod
    async def subscribe_orderbook(self, symbol: str):
        """Subscribe to order book updates"""
        pass
    
    @abstractmethod
    async def place_order(self, order: Order) -> Dict[str, Any]:
        """Place order via REST API"""
        pass
    
    @abstractmethod
    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        """Cancel order"""
        pass
    
    def _create_rate_limiter(self):
        """Create exchange-specific rate limiter"""
        limits = {}
            ExchangeType.BINANCE: {"orders": 50, "window": 10},
            ExchangeType.COINBASE: {"orders": 30, "window": 1},
            ExchangeType.KRAKEN: {"orders": 60, "window": 60},
            ExchangeType.FTX: {"orders": 30, "window": 1},
        }
        return RateLimiter(**limits.get(self.exchange_type, {"orders": 10, "window": 1}))

class BinanceConnector(ExchangeConnector):
    """Optimized Binance connector with colocated server support"""
    
    WEBSOCKET_URLS = {}
        "main": "wss://stream.binance.com:9443/ws",
        "coloc_tokyo": "wss://stream.binance.jp:9443/ws",
        "coloc_singapore": "wss://stream.binance.sg:9443/ws",
    }
    
    REST_URLS = {}
        "main": "https://api.binance.com",
        "coloc_tokyo": "https://api.binance.jp",
        "coloc_singapore": "https://api.binance.sg",
    }
    
    def __init__(self, api_key: str, api_secret: str, colocation: str = "main"):
        super().__init__(ExchangeType.BINANCE, api_key, api_secret)
        self.ws_url = self.WEBSOCKET_URLS[colocation]
        self.rest_url = self.REST_URLS[colocation]
        self.listen_key = None
        
    async def connect_websocket(self):
        """Connect to Binance WebSocket with automatic reconnection"""
        while True:
            try:
                self.ws_connection = await websockets.connect()
                    self.ws_url,
                    ping_interval=20,
                    ping_timeout=10,
                    close_timeout=10,
                    max_size=2**23,  # 8MB max message size
                    compression=None  # Disable compression for lower latency
                )
                
                # Start message handler
                asyncio.create_task(self._handle_messages())
                logging.info(f"Connected to Binance WebSocket: {self.ws_url}")
                break
                
            except Exception as e:
                logging.error(f"Binance WebSocket connection failed: {e}")
                await asyncio.sleep(1)
    
    async def _handle_messages(self):
        """Zero-copy message processing"""
        async for message in self.ws_connection:
            try:
                # Parse message without creating intermediate objects
                data = json.loads(message)
                
                if "e" in data and data["e"] == "depthUpdate":
                    await self._process_orderbook_update(data)
                elif "e" in data and data["e"] == "executionReport":
                    await self._process_execution_report(data)
                    
            except Exception as e:
                logging.error(f"Error processing Binance message: {e}")
    
    async def _process_orderbook_update(self, data: Dict):
        """Process order book update with minimal latency"""
        symbol = data["s"]
        
        if symbol not in self.order_books:
            self.order_books[symbol] = OrderBook()
                exchange=self.exchange_type,
                symbol=symbol,
                bids=SortedDict(),
                asks=SortedDict(),
                timestamp=time.time_ns(),
                sequence=data["u"]
            )
        
        orderbook = self.order_books[symbol]
        
        # Convert and update bids
        bids = [(float(price), float(qty)) for price, qty in data["b"]]
        asks = [(float(price), float(qty)) for price, qty in data["a"]]
        
        orderbook.update_atomic(bids, asks)
        orderbook.sequence = data["u"]
    
    async def subscribe_orderbook(self, symbol: str):
        """Subscribe to order book updates"""
        subscribe_message = {}
            "method": "SUBSCRIBE",
            "params": [f"{symbol.lower()}@depth@100ms"],
            "id": int(time.time() * 1000)
        }
        await self.ws_connection.send(json.dumps(subscribe_message))
    
    async def place_order(self, order: Order) -> Dict[str, Any]:
        """Place order with optimal routing"""
        if not await self.rate_limiter.acquire():
            raise Exception("Rate limit exceeded")
        
        # Prepare order parameters
        params = {}
            "symbol": order.symbol,
            "side": order.side.name,
            "type": order.order_type.name,
            "quantity": str(order.quantity),
            "timestamp": int(time.time() * 1000),
            "recvWindow": 5000
        }
        
        if order.price and order.order_type != OrderType.MARKET:
            params["price"] = str(order.price)
        
        # Sign request
        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        signature = hmac.new()
            self.api_secret.encode(),
            query_string.encode(),
            hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        
        # Execute order
        headers = {"X-MBX-APIKEY": self.api_key}
        
        async with aiohttp.ClientSession() as session:
            async with session.post()
                f"{self.rest_url}/api/v3/order",
                headers=headers,
                params=params,
                timeout=aiohttp.ClientTimeout(total=2)  # 2 second timeout
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    order.order_id = result["orderId"]
                    order.status = result["status"]
                    self.pending_orders[order.order_id] = order
                    
                return result
    
    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        """Cancel order"""
        params = {}
            "symbol": symbol,
            "orderId": order_id,
            "timestamp": int(time.time() * 1000),
            "recvWindow": 5000
        }
        
        # Sign request
        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        signature = hmac.new()
            self.api_secret.encode(),
            query_string.encode(),
            hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        
        headers = {"X-MBX-APIKEY": self.api_key}
        
        async with aiohttp.ClientSession() as session:
            async with session.delete()
                f"{self.rest_url}/api/v3/order",
                headers=headers,
                params=params,
                timeout=aiohttp.ClientTimeout(total=2)
            ) as response:
                return response.status == 200
    
    async def _process_execution_report(self, data: Dict):
        """Process order execution reports"""
        order_id = str(data["i"])
        
        if order_id in self.pending_orders:
            order = self.pending_orders[order_id]
            order.status = data["X"]
            order.filled_quantity = Decimal(data["z"])
            
            if data["Z"] != "0":  # Average price available
                order.average_price = Decimal(data["Z"])
            
            if order.status in ["FILLED", "CANCELED", "REJECTED", "EXPIRED"]:
                del self.pending_orders[order_id]

class ArbitrageDetector:
    """Ultra-low latency arbitrage detection engine"""
    
    def __init__(self, exchanges: Dict[ExchangeType, ExchangeConnector]):
        self.exchanges = exchanges
        self.opportunity_queue = asyncio.Queue(maxsize=10000)
        self.active_opportunities: Set[str] = set()
        self.detection_thread_pool = ThreadPoolExecutor(max_workers=4)
        self.min_profit_threshold = Decimal("10")  # $10 minimum profit
        self.min_profit_pct = 0.001  # 0.1% minimum profit percentage
        
        # Statistical arbitrage parameters
        self.price_history: Dict[Tuple[ExchangeType, str], deque] = defaultdict()
            lambda: deque(maxlen=1000)
        )
        self.spread_stats: Dict[Tuple[str, str], SpreadStatistics] = {}
        
    async def start_detection(self):
        """Start arbitrage detection loops"""
        tasks = []
            asyncio.create_task(self._detect_triangular_arbitrage()),
            asyncio.create_task(self._detect_cross_exchange_arbitrage()),
            asyncio.create_task(self._detect_statistical_arbitrage()),
            asyncio.create_task(self._detect_funding_rate_arbitrage()),
        ]
        await asyncio.gather(*tasks)
    
    async def _detect_cross_exchange_arbitrage(self):
        """Detect price discrepancies across exchanges"""
        while True:
            try:
                # Get common symbols across exchanges
                common_symbols = self._get_common_symbols()
                
                for symbol in common_symbols:
                    opportunities = await self._check_cross_exchange_opportunity(symbol)
                    
                    for opp in opportunities:
                        if opp.expected_profit >= self.min_profit_threshold:
                            await self.opportunity_queue.put(opp)
                            opportunity_counter.inc()
                
                await asyncio.sleep(0.001)  # 1ms loop
                
            except Exception as e:
                logging.error(f"Cross-exchange detection error: {e}")
    
    def _get_common_symbols(self) -> Set[str]:
        """Get symbols traded on multiple exchanges"""
        symbol_sets = []
        
        for exchange in self.exchanges.values():
            symbol_sets.append(set(exchange.order_books.keys()))
        
        if not symbol_sets:
            return set()
        
        # Find intersection of all symbols
        common = symbol_sets[0]
        for s in symbol_sets[1:]:
            common = common.intersection(s)
        
        return common
    
    async def _check_cross_exchange_opportunity(self, symbol: str) -> List[ArbitrageOpportunity]:
        """Check for arbitrage opportunity on a symbol across exchanges"""
        opportunities = []
        
        # Get order books from all exchanges
        orderbooks = []
        for exchange_type, connector in self.exchanges.items():
            if symbol in connector.order_books:
                ob = connector.order_books[symbol]
                if ob.bids and ob.asks:
                    orderbooks.append((exchange_type, ob))
        
        if len(orderbooks) < 2:
            return opportunities
        
        # Check all exchange pairs
        for i in range(len(orderbooks)):
            for j in range(i + 1, len(orderbooks)):
                ex1_type, ob1 = orderbooks[i]
                ex2_type, ob2 = orderbooks[j]
                
                # Check if we can buy on ex1 and sell on ex2
                if ob1.asks and ob2.bids:
                    best_ask_ex1 = float(list(ob1.asks.keys())[0])
                    best_bid_ex2 = float(list(ob2.bids.keys())[-1])
                    
                    spread_pct = (best_bid_ex2 - best_ask_ex1) / best_ask_ex1
                    
                    if spread_pct > self.min_profit_pct:
                        opportunity = self._create_cross_exchange_opportunity()
                            symbol, ex1_type, ex2_type, ob1, ob2, "buy_ex1_sell_ex2"
                        )
                        if opportunity:
                            opportunities.append(opportunity)
                
                # Check if we can buy on ex2 and sell on ex1
                if ob2.asks and ob1.bids:
                    best_ask_ex2 = float(list(ob2.asks.keys())[0])
                    best_bid_ex1 = float(list(ob1.bids.keys())[-1])
                    
                    spread_pct = (best_bid_ex1 - best_ask_ex2) / best_ask_ex2
                    
                    if spread_pct > self.min_profit_pct:
                        opportunity = self._create_cross_exchange_opportunity()
                            symbol, ex2_type, ex1_type, ob2, ob1, "buy_ex2_sell_ex1"
                        )
                        if opportunity:
                            opportunities.append(opportunity)
        
        return opportunities
    
    def _create_cross_exchange_opportunity()
        self,
        symbol: str,
        buy_exchange: ExchangeType,
        sell_exchange: ExchangeType,
        buy_orderbook: OrderBook,
        sell_orderbook: OrderBook,
        direction: str
    ) -> Optional[ArbitrageOpportunity]:
        """Create cross-exchange arbitrage opportunity"""
        
        # Calculate optimal order size
        buy_price = float(list(buy_orderbook.asks.keys())[0])
        buy_quantity = float(list(buy_orderbook.asks.values())[0])
        
        sell_price = float(list(sell_orderbook.bids.keys())[-1])
        sell_quantity = float(list(sell_orderbook.bids.values())[-1])
        
        # Take minimum of available quantities
        max_quantity = min(buy_quantity, sell_quantity)
        
        # Apply position limits
        max_quantity = min(max_quantity, self._get_position_limit(symbol, buy_exchange))
        max_quantity = min(max_quantity, self._get_position_limit(symbol, sell_exchange))
        
        if max_quantity < 0.001:  # Minimum order size
            return None
        
        # Calculate expected profit
        buy_cost = Decimal(str(buy_price)) * Decimal(str(max_quantity))
        sell_revenue = Decimal(str(sell_price)) * Decimal(str(max_quantity))
        
        # Account for fees
        buy_fee = buy_cost * Decimal("0.001")  # 0.1% taker fee
        sell_fee = sell_revenue * Decimal("0.001")
        
        expected_profit = sell_revenue - buy_cost - buy_fee - sell_fee
        expected_profit_pct = float(expected_profit / buy_cost)
        
        if expected_profit < self.min_profit_threshold:
            return None
        
        # Create orders
        buy_order = Order()
            order_id=f"{buy_exchange.name}_{symbol}_{time.time_ns()}",
            exchange=buy_exchange,
            symbol=symbol,
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            quantity=Decimal(str(max_quantity)),
            price=Decimal(str(buy_price)),
            timestamp=time.time_ns()
        )
        
        sell_order = Order()
            order_id=f"{sell_exchange.name}_{symbol}_{time.time_ns()}",
            exchange=sell_exchange,
            symbol=symbol,
            side=OrderSide.SELL,
            order_type=OrderType.LIMIT,
            quantity=Decimal(str(max_quantity)),
            price=Decimal(str(sell_price)),
            timestamp=time.time_ns()
        )
        
        opportunity = ArbitrageOpportunity()
            opportunity_id=f"CROSS_{symbol}_{buy_exchange.name}_{sell_exchange.name}_{time.time_ns()}",
            arbitrage_type=ArbitrageType.CROSS_EXCHANGE,
            exchanges=[buy_exchange, sell_exchange],
            symbols=[symbol],
            orders=[buy_order, sell_order],
            expected_profit=expected_profit,
            expected_profit_pct=expected_profit_pct,
            detected_at=time.time_ns(),
            expires_at=time.time_ns() + 1_000_000_000,  # 1 second expiry
            confidence=0.95,
            risk_score=self._calculate_risk_score(opportunity_id, [buy_order, sell_order])
        )
        
        return opportunity
    
    def _get_position_limit(self, symbol: str, exchange: ExchangeType) -> float:
        """Get position limit for symbol on exchange"""
        # TODO: Implement dynamic position limits based on risk parameters
        limits = {}
            ExchangeType.BINANCE: 10000,
            ExchangeType.COINBASE: 5000,
            ExchangeType.KRAKEN: 8000,
            ExchangeType.FTX: 15000,
        }
        return limits.get(exchange, 1000)
    
    def _calculate_risk_score(self, opportunity_id: str, orders: List[Order]) -> float:
        """Calculate risk score for opportunity"""
        risk_score = 0.0
        
        # Execution risk based on order book depth
        for order in orders:
            if order.order_type == OrderType.MARKET:
                risk_score += 0.2
            else:
                risk_score += 0.1
        
        # Transfer risk for cross-exchange
        if len(set(order.exchange for order in orders)) > 1:
            risk_score += 0.3
        
        # Normalize to 0-1 range
        return min(risk_score, 1.0)
    
    async def _detect_triangular_arbitrage(self):
        """Detect triangular arbitrage within single exchange"""
        while True:
            try:
                for exchange_type, connector in self.exchanges.items():
                    opportunities = await self._check_triangular_opportunities(connector)
                    
                    for opp in opportunities:
                        if opp.expected_profit >= self.min_profit_threshold:
                            await self.opportunity_queue.put(opp)
                            opportunity_counter.inc()
                
                await asyncio.sleep(0.001)
                
            except Exception as e:
                logging.error(f"Triangular detection error: {e}")
    
    async def _check_triangular_opportunities()
        self, 
        connector: ExchangeConnector
    ) -> List[ArbitrageOpportunity]:
        """Check for triangular arbitrage opportunities"""
        opportunities = []
        
        # Find triangular paths (e.g., BTC/USDT -> ETH/BTC -> ETH/USDT)
        base_currencies = {"USDT", "BUSD", "USDC", "BTC", "ETH"}
        
        for base in base_currencies:
            # Get all pairs with this base
            pairs_with_base = []
                symbol for symbol in connector.order_books.keys()
                if symbol.endswith(base)
            ]
            
            # Check triangular paths
            for pair1 in pairs_with_base:
                asset1 = pair1.replace(base, "")
                
                for pair2 in connector.order_books.keys():
                    if pair2.startswith(asset1) and pair2 != pair1:
                        asset2 = pair2.replace(asset1, "")
                        
                        # Find closing pair
                        closing_pair = f"{asset2}{base}"
                        if closing_pair in connector.order_books:
                            # Check profitability
                            opportunity = self._calculate_triangular_profit()
                                connector, base, pair1, pair2, closing_pair
                            )
                            if opportunity:
                                opportunities.append(opportunity)
        
        return opportunities
    
    def _calculate_triangular_profit()
        self,
        connector: ExchangeConnector,
        base: str,
        pair1: str,
        pair2: str,
        pair3: str
    ) -> Optional[ArbitrageOpportunity]:
        """Calculate triangular arbitrage profit"""
        # Get order books
        ob1 = connector.order_books.get(pair1)
        ob2 = connector.order_books.get(pair2)
        ob3 = connector.order_books.get(pair3)
        
        if not all([ob1, ob2, ob3]) or not all([ob1.asks, ob2.asks, ob3.bids]):
            return None
        
        # Calculate forward path profit
        # Buy pair1, sell pair2, sell pair3
        try:
            # Step 1: Buy asset1 with base
            ask1 = float(list(ob1.asks.keys())[0])
            qty1 = float(list(ob1.asks.values())[0])
            
            # Step 2: Sell asset1 for asset2
            bid2 = float(list(ob2.bids.keys())[-1])
            qty2 = float(list(ob2.bids.values())[-1])
            
            # Step 3: Sell asset2 for base
            bid3 = float(list(ob3.bids.keys())[-1])
            qty3 = float(list(ob3.bids.values())[-1])
            
            # Calculate quantities through the path
            base_amount = Decimal("1000")  # Start with $1000
            asset1_amount = base_amount / Decimal(str(ask1))
            asset2_amount = asset1_amount * Decimal(str(bid2))
            final_base_amount = asset2_amount * Decimal(str(bid3))
            
            # Account for fees (3 trades * 0.1% each)
            fees = base_amount * Decimal("0.003")
            profit = final_base_amount - base_amount - fees
            profit_pct = float(profit / base_amount)
            
            if profit > self.min_profit_threshold and profit_pct > self.min_profit_pct:
                # Create orders
                orders = []
                    Order()
                        order_id=f"{connector.exchange_type.name}_{pair1}_{time.time_ns()}_1",
                        exchange=connector.exchange_type,
                        symbol=pair1,
                        side=OrderSide.BUY,
                        order_type=OrderType.LIMIT,
                        quantity=asset1_amount,
                        price=Decimal(str(ask1)),
                        timestamp=time.time_ns()
                    ),
                    Order()
                        order_id=f"{connector.exchange_type.name}_{pair2}_{time.time_ns()}_2",
                        exchange=connector.exchange_type,
                        symbol=pair2,
                        side=OrderSide.SELL,
                        order_type=OrderType.LIMIT,
                        quantity=asset1_amount,
                        price=Decimal(str(bid2)),
                        timestamp=time.time_ns()
                    ),
                    Order()
                        order_id=f"{connector.exchange_type.name}_{pair3}_{time.time_ns()}_3",
                        exchange=connector.exchange_type,
                        symbol=pair3,
                        side=OrderSide.SELL,
                        order_type=OrderType.LIMIT,
                        quantity=asset2_amount,
                        price=Decimal(str(bid3)),
                        timestamp=time.time_ns()
                    )
                ]
                
                return ArbitrageOpportunity()
                    opportunity_id=f"TRI_{connector.exchange_type.name}_{base}_{time.time_ns()}",
                    arbitrage_type=ArbitrageType.TRIANGULAR,
                    exchanges=[connector.exchange_type],
                    symbols=[pair1, pair2, pair3],
                    orders=orders,
                    expected_profit=profit,
                    expected_profit_pct=profit_pct,
                    detected_at=time.time_ns(),
                    expires_at=time.time_ns() + 500_000_000,  # 500ms expiry
                    confidence=0.9,
                    risk_score=0.2
                )
                
        except Exception as e:
            logging.error(f"Triangular calculation error: {e}")
            
        return None
    
    async def _detect_statistical_arbitrage(self):
        """Detect statistical arbitrage based on historical spreads"""
        while True:
            try:
                # Update price history
                for exchange_type, connector in self.exchanges.items():
                    for symbol, orderbook in connector.order_books.items():
                        if orderbook.bids and orderbook.asks:
                            mid_price = ()
                                float(list(orderbook.bids.keys())[-1]) + 
                                float(list(orderbook.asks.keys())[0])
                            ) / 2
                            
                            self.price_history[(exchange_type, symbol)].append({)
                                "price": mid_price,
                                "timestamp": orderbook.timestamp
                            })
                
                # Check for statistical arbitrage opportunities
                opportunities = await self._check_statistical_opportunities()
                
                for opp in opportunities:
                    if opp.expected_profit >= self.min_profit_threshold:
                        await self.opportunity_queue.put(opp)
                        opportunity_counter.inc()
                
                await asyncio.sleep(0.01)  # 10ms loop
                
            except Exception as e:
                logging.error(f"Statistical arbitrage detection error: {e}")
    
    async def _check_statistical_opportunities(self) -> List[ArbitrageOpportunity]:
        """Check for mean-reversion opportunities"""
        opportunities = []
        
        # Check spreads between correlated pairs
        correlated_pairs = []
            ("BTCUSDT", "ETHUSDT", 0.8),  # correlation coefficient
            ("ETHUSDT", "BNBUSDT", 0.7),
            ("BTCUSDT", "LTCUSDT", 0.75),
        ]
        
        for pair1, pair2, correlation in correlated_pairs:
            for exchange in self.exchanges.values():
                if pair1 in exchange.order_books and pair2 in exchange.order_books:
                    # Calculate z-score of spread
                    spread_key = (pair1, pair2)
                    
                    if spread_key not in self.spread_stats:
                        self.spread_stats[spread_key] = SpreadStatistics()
                    
                    stats = self.spread_stats[spread_key]
                    
                    # Get current prices
                    ob1 = exchange.order_books[pair1]
                    ob2 = exchange.order_books[pair2]
                    
                    if ob1.bids and ob1.asks and ob2.bids and ob2.asks:
                        mid1 = (float(list(ob1.bids.keys())[-1]) +)
                               float(list(ob1.asks.keys())[0])) / 2
                        mid2 = (float(list(ob2.bids.keys())[-1]) +)
                               float(list(ob2.asks.keys())[0])) / 2
                        
                        spread = mid1 / mid2
                        stats.update(spread)
                        
                        # Check if spread deviates significantly
                        if stats.count > 100:  # Need sufficient history
                            z_score = stats.get_z_score(spread)
                            
                            if abs(z_score) > 2.0:  # 2 standard deviations
                                opportunity = self._create_statistical_opportunity()
                                    exchange.exchange_type,
                                    pair1, pair2, ob1, ob2,
                                    spread, stats, z_score
                                )
                                if opportunity:
                                    opportunities.append(opportunity)
        
        return opportunities
    
    def _create_statistical_opportunity()
        self,
        exchange: ExchangeType,
        pair1: str,
        pair2: str,
        ob1: OrderBook,
        ob2: OrderBook,
        current_spread: float,
        stats: 'SpreadStatistics',
        z_score: float
    ) -> Optional[ArbitrageOpportunity]:
        """Create statistical arbitrage opportunity"""
        
        # Determine trade direction based on z-score
        if z_score > 2.0:  # Spread is too high, expect mean reversion down
            # Sell pair1, buy pair2
            orders = []
                Order()
                    order_id=f"STAT_{exchange.name}_{pair1}_{time.time_ns()}",
                    exchange=exchange,
                    symbol=pair1,
                    side=OrderSide.SELL,
                    order_type=OrderType.LIMIT,
                    quantity=Decimal("0.1"),  # Example quantity
                    price=Decimal(str(list(ob1.bids.keys())[-1])),
                    timestamp=time.time_ns()
                ),
                Order()
                    order_id=f"STAT_{exchange.name}_{pair2}_{time.time_ns()}",
                    exchange=exchange,
                    symbol=pair2,
                    side=OrderSide.BUY,
                    order_type=OrderType.LIMIT,
                    quantity=Decimal("1.0"),  # Adjusted for price ratio
                    price=Decimal(str(list(ob2.asks.keys())[0])),
                    timestamp=time.time_ns()
                )
            ]
        else:  # z_score < -2.0, spread is too low
            # Buy pair1, sell pair2
            orders = []
                Order()
                    order_id=f"STAT_{exchange.name}_{pair1}_{time.time_ns()}",
                    exchange=exchange,
                    symbol=pair1,
                    side=OrderSide.BUY,
                    order_type=OrderType.LIMIT,
                    quantity=Decimal("0.1"),
                    price=Decimal(str(list(ob1.asks.keys())[0])),
                    timestamp=time.time_ns()
                ),
                Order()
                    order_id=f"STAT_{exchange.name}_{pair2}_{time.time_ns()}",
                    exchange=exchange,
                    symbol=pair2,
                    side=OrderSide.SELL,
                    order_type=OrderType.LIMIT,
                    quantity=Decimal("1.0"),
                    price=Decimal(str(list(ob2.bids.keys())[-1])),
                    timestamp=time.time_ns()
                )
            ]
        
        # Calculate expected profit based on mean reversion
        expected_spread = stats.mean
        spread_change = abs(current_spread - expected_spread) / current_spread
        expected_profit = Decimal("1000") * Decimal(str(spread_change))
        
        return ArbitrageOpportunity()
            opportunity_id=f"STAT_{exchange.name}_{pair1}_{pair2}_{time.time_ns()}",
            arbitrage_type=ArbitrageType.STATISTICAL,
            exchanges=[exchange],
            symbols=[pair1, pair2],
            orders=orders,
            expected_profit=expected_profit,
            expected_profit_pct=float(spread_change),
            detected_at=time.time_ns(),
            expires_at=time.time_ns() + 30_000_000_000,  # 30 second expiry
            confidence=0.7 + min(0.2, abs(z_score) / 10),  # Higher confidence with larger z-score
            risk_score=0.4  # Higher risk for statistical arb
        )
    
    async def _detect_funding_rate_arbitrage(self):
        """Detect funding rate arbitrage opportunities"""
        while True:
            try:
                # Check funding rates across exchanges
                funding_rates = await self._get_funding_rates()
                
                # Look for significant funding rate differences
                for symbol in funding_rates:
                    if len(funding_rates[symbol]) >= 2:
                        # Sort by funding rate
                        sorted_rates = sorted()
                            funding_rates[symbol].items(),
                            key=lambda x: x[1]
                        )
                        
                        lowest = sorted_rates[0]
                        highest = sorted_rates[-1]
                        
                        rate_diff = highest[1] - lowest[1]
                        
                        # Funding rate arbitrage if difference > 0.01% (annualized ~3.65%)
                        if rate_diff > 0.0001:
                            opportunity = self._create_funding_rate_opportunity()
                                symbol, lowest[0], highest[0], lowest[1], highest[1]
                            )
                            if opportunity:
                                await self.opportunity_queue.put(opportunity)
                                opportunity_counter.inc()
                
                await asyncio.sleep(60)  # Check funding rates every minute
                
            except Exception as e:
                logging.error(f"Funding rate detection error: {e}")
    
    async def _get_funding_rates(self) -> Dict[str, Dict[ExchangeType, float]]:
        """Get current funding rates from exchanges"""
        # TODO: Implement funding rate fetching from each exchange
        # This is a placeholder
        return {}
    
    def _create_funding_rate_opportunity()
        self,
        symbol: str,
        long_exchange: ExchangeType,
        short_exchange: ExchangeType,
        long_rate: float,
        short_rate: float
    ) -> Optional[ArbitrageOpportunity]:
        """Create funding rate arbitrage opportunity"""
        # TODO: Implement funding rate arbitrage opportunity creation
        pass

class SpreadStatistics:
    """Track spread statistics for mean reversion"""
    
    def __init__(self, window_size: int = 1000):
        self.window_size = window_size
        self.values = deque(maxlen=window_size)
        self.sum = 0.0
        self.sum_squares = 0.0
        self.count = 0
        self.mean = 0.0
        self.variance = 0.0
        self.std_dev = 0.0
    
    def update(self, value: float):
        """Update statistics with new value"""
        if len(self.values) >= self.window_size:
            # Remove oldest value
            old_value = self.values[0]
            self.sum -= old_value
            self.sum_squares -= old_value ** 2
            self.count -= 1
        
        # Add new value
        self.values.append(value)
        self.sum += value
        self.sum_squares += value ** 2
        self.count += 1
        
        # Update statistics
        if self.count > 0:
            self.mean = self.sum / self.count
            
            if self.count > 1:
                self.variance = (self.sum_squares / self.count) - (self.mean ** 2)
                self.std_dev = self.variance ** 0.5
    
    def get_z_score(self, value: float) -> float:
        """Calculate z-score for a value"""
        if self.std_dev == 0:
            return 0.0
        return (value - self.mean) / self.std_dev

class ExecutionEngine:
    """Ultra-low latency execution engine with parallel order submission"""
    
    def __init__(self, exchanges: Dict[ExchangeType, ExchangeConnector]):
        self.exchanges = exchanges
        self.execution_queue = asyncio.Queue(maxsize=1000)
        self.active_executions: Dict[str, ArbitrageOpportunity] = {}
        self.execution_history: deque = deque(maxlen=10000)
        self.circuit_breaker = CircuitBreaker()
        
        # Performance tracking
        self.total_executions = 0
        self.successful_executions = 0
        self.failed_executions = 0
        self.total_profit = Decimal("0")
        
    async def start_execution(self):
        """Start execution loop"""
        # Create multiple execution workers for parallel processing
        workers = []
        for i in range(4):  # 4 parallel execution workers
            workers.append(asyncio.create_task(self._execution_worker(i)))
        
        await asyncio.gather(*workers)
    
    async def _execution_worker(self, worker_id: int):
        """Execution worker for processing opportunities"""
        while True:
            try:
                opportunity = await self.execution_queue.get()
                
                if not opportunity.is_valid():
                    continue
                
                # Check circuit breaker
                if self.circuit_breaker.is_open():
                    logging.warning("Circuit breaker open, skipping execution")
                    continue
                
                # Execute opportunity
                start_time = time.time_ns()
                success = await self._execute_opportunity(opportunity)
                execution_time = time.time_ns() - start_time
                
                # Record metrics
                latency_histogram.observe(execution_time / 1000)  # Convert to microseconds
                
                if success:
                    self.successful_executions += 1
                    profit_counter.inc(float(opportunity.expected_profit))
                else:
                    self.failed_executions += 1
                    self.circuit_breaker.record_failure()
                
                self.total_executions += 1
                execution_success_rate.set()
                    self.successful_executions / self.total_executions
                )
                
            except Exception as e:
                logging.error(f"Execution worker {worker_id} error: {e}")
                self.circuit_breaker.record_failure()
    
    async def _execute_opportunity(self, opportunity: ArbitrageOpportunity) -> bool:
        """Execute arbitrage opportunity with atomic execution groups"""
        
        # Create execution plan
        execution_plan = self._create_execution_plan(opportunity)
        
        # Execute orders in parallel with proper synchronization
        if opportunity.arbitrage_type == ArbitrageType.CROSS_EXCHANGE:
            return await self._execute_cross_exchange(opportunity, execution_plan)
        elif opportunity.arbitrage_type == ArbitrageType.TRIANGULAR:
            return await self._execute_triangular(opportunity, execution_plan)
        elif opportunity.arbitrage_type == ArbitrageType.STATISTICAL:
            return await self._execute_statistical(opportunity, execution_plan)
        else:
            return False
    
    def _create_execution_plan(self, opportunity: ArbitrageOpportunity) -> Dict[str, Any]:
        """Create optimal execution plan"""
        plan = {}
            "opportunity_id": opportunity.opportunity_id,
            "orders": opportunity.orders,
            "execution_groups": [],
            "rollback_strategy": "full",
            "timeout_ms": 2000,
            "retry_count": 1
        }
        
        # Group orders that can be executed in parallel
        if opportunity.arbitrage_type == ArbitrageType.CROSS_EXCHANGE:
            # Both orders can be executed in parallel
            plan["execution_groups"] = [opportunity.orders]
        elif opportunity.arbitrage_type == ArbitrageType.TRIANGULAR:
            # Sequential execution required
            plan["execution_groups"] = [[order] for order in opportunity.orders]
        elif opportunity.arbitrage_type == ArbitrageType.STATISTICAL:
            # Parallel execution
            plan["execution_groups"] = [opportunity.orders]
        
        return plan
    
    async def _execute_cross_exchange()
        self, 
        opportunity: ArbitrageOpportunity,
        execution_plan: Dict[str, Any]
    ) -> bool:
        """Execute cross-exchange arbitrage with atomic guarantees"""
        
        # Place orders in parallel
        tasks = []
        for order in opportunity.orders:
            connector = self.exchanges[order.exchange]
            tasks.append(connector.place_order(order))
        
        # Wait for all orders with timeout
        try:
            results = await asyncio.wait_for()
                asyncio.gather(*tasks, return_exceptions=True),
                timeout=execution_plan["timeout_ms"] / 1000
            )
            
            # Check if all orders succeeded
            success_count = 0
            failed_orders = []
            
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    failed_orders.append(opportunity.orders[i])
                elif result.get("status") in ["NEW", "PARTIALLY_FILLED", "FILLED"]:
                    success_count += 1
                else:
                    failed_orders.append(opportunity.orders[i])
            
            # If not all succeeded, cancel successful orders
            if success_count < len(opportunity.orders):
                await self._rollback_orders(opportunity.orders, failed_orders)
                return False
            
            # Monitor fills
            filled = await self._monitor_fills(opportunity.orders, timeout=5)
            
            if filled:
                # Record successful execution
                self._record_execution(opportunity, "SUCCESS", results)
                return True
            else:
                # Partial fills - handle appropriately
                await self._handle_partial_fills(opportunity.orders)
                return False
                
        except asyncio.TimeoutError:
            logging.error(f"Execution timeout for {opportunity.opportunity_id}")
            await self._rollback_orders(opportunity.orders, [])
            return False
        except Exception as e:
            logging.error(f"Execution error: {e}")
            return False
    
    async def _execute_triangular()
        self,
        opportunity: ArbitrageOpportunity,
        execution_plan: Dict[str, Any]
    ) -> bool:
        """Execute triangular arbitrage with sequential order placement"""
        
        for i, order_group in enumerate(execution_plan["execution_groups"]):
            for order in order_group:
                try:
                    connector = self.exchanges[order.exchange]
                    result = await connector.place_order(order)
                    
                    if result.get("status") not in ["NEW", "PARTIALLY_FILLED", "FILLED"]:
                        # Rollback previous orders
                        await self._rollback_orders(opportunity.orders[:i], [])
                        return False
                    
                    # Wait for fill before proceeding
                    filled = await self._wait_for_fill(order, timeout=2)
                    if not filled:
                        await self._rollback_orders(opportunity.orders[:i+1], [])
                        return False
                        
                except Exception as e:
                    logging.error(f"Triangular execution error at step {i}: {e}")
                    await self._rollback_orders(opportunity.orders[:i], [])
                    return False
        
        self._record_execution(opportunity, "SUCCESS", {})
        return True
    
    async def _execute_statistical()
        self,
        opportunity: ArbitrageOpportunity,
        execution_plan: Dict[str, Any]
    ) -> bool:
        """Execute statistical arbitrage"""
        # Similar to cross-exchange but with different risk parameters
        return await self._execute_cross_exchange(opportunity, execution_plan)
    
    async def _rollback_orders(self, all_orders: List[Order], failed_orders: List[Order]):
        """Cancel successful orders when execution fails"""
        cancel_tasks = []
        
        for order in all_orders:
            if order not in failed_orders and order.status in ["NEW", "PARTIALLY_FILLED"]:
                connector = self.exchanges[order.exchange]
                cancel_tasks.append()
                    connector.cancel_order(order.order_id, order.symbol)
                )
        
        if cancel_tasks:
            await asyncio.gather(*cancel_tasks, return_exceptions=True)
    
    async def _monitor_fills(self, orders: List[Order], timeout: float) -> bool:
        """Monitor order fills with timeout"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            all_filled = True
            
            for order in orders:
                connector = self.exchanges[order.exchange]
                if order.order_id in connector.pending_orders:
                    pending_order = connector.pending_orders[order.order_id]
                    if pending_order.status != "FILLED":
                        all_filled = False
                        break
            
            if all_filled:
                return True
            
            await asyncio.sleep(0.1)
        
        return False
    
    async def _wait_for_fill(self, order: Order, timeout: float) -> bool:
        """Wait for single order to fill"""
        start_time = time.time()
        connector = self.exchanges[order.exchange]
        
        while time.time() - start_time < timeout:
            if order.order_id in connector.pending_orders:
                if connector.pending_orders[order.order_id].status == "FILLED":
                    return True
            
            await asyncio.sleep(0.05)
        
        return False
    
    async def _handle_partial_fills(self, orders: List[Order]):
        """Handle partial fills by canceling remaining orders"""
        # Cancel all partially filled orders
        cancel_tasks = []
        
        for order in orders:
            if order.status == "PARTIALLY_FILLED":
                connector = self.exchanges[order.exchange]
                cancel_tasks.append()
                    connector.cancel_order(order.order_id, order.symbol)
                )
        
        if cancel_tasks:
            await asyncio.gather(*cancel_tasks, return_exceptions=True)
    
    def _record_execution(self, opportunity: ArbitrageOpportunity, status: str, details: Any):
        """Record execution for analysis"""
        execution_record = {}
            "opportunity_id": opportunity.opportunity_id,
            "arbitrage_type": opportunity.arbitrage_type.name,
            "status": status,
            "expected_profit": float(opportunity.expected_profit),
            "actual_profit": self._calculate_actual_profit(opportunity),
            "executed_at": time.time_ns(),
            "latency_ns": time.time_ns() - opportunity.detected_at,
            "details": details
        }
        
        self.execution_history.append(execution_record)
        
        # Update total profit
        if status == "SUCCESS":
            self.total_profit += Decimal(str(execution_record["actual_profit"]))
    
    def _calculate_actual_profit(self, opportunity: ArbitrageOpportunity) -> float:
        """Calculate actual profit from executed orders"""
        total_cost = Decimal("0")
        total_revenue = Decimal("0")
        total_fees = Decimal("0")
        
        for order in opportunity.orders:
            if order.average_price and order.filled_quantity > 0:
                value = order.average_price * order.filled_quantity
                
                if order.side == OrderSide.BUY:
                    total_cost += value
                else:
                    total_revenue += value
                
                total_fees += order.fees
        
        actual_profit = total_revenue - total_cost - total_fees
        return float(actual_profit)

class CircuitBreaker:
    """Circuit breaker for system protection"""
    
    def __init__(self, failure_threshold: int = 5, timeout: float = 60.0):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failure_count = 0
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self.lock = threading.Lock()
    
    def is_open(self) -> bool:
        """Check if circuit breaker is open"""
        with self.lock:
            if self.state == "OPEN":
                # Check if timeout has passed
                if time.time() - self.last_failure_time > self.timeout:
                    self.state = "HALF_OPEN"
                    return False
                return True
            return False
    
    def record_failure(self):
        """Record execution failure"""
        with self.lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
                logging.warning(f"Circuit breaker opened after {self.failure_count} failures")
    
    def record_success(self):
        """Record execution success"""
        with self.lock:
            if self.state == "HALF_OPEN":
                self.state = "CLOSED"
                self.failure_count = 0
                logging.info("Circuit breaker closed after successful execution")

class RateLimiter:
    """Token bucket rate limiter"""
    
    def __init__(self, orders: int, window: float):
        self.capacity = orders
        self.tokens = orders
        self.window = window
        self.last_update = time.time()
        self.lock = threading.Lock()
    
    async def acquire(self) -> bool:
        """Acquire permission to make request"""
        with self.lock:
            now = time.time()
            elapsed = now - self.last_update
            
            # Refill tokens
            self.tokens = min()
                self.capacity,
                self.tokens + (elapsed * self.capacity / self.window)
            )
            self.last_update = now
            
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            
            return False

class RiskManager:
    """Comprehensive risk management system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.position_tracker = PositionTracker()
        self.exposure_limits = config.get("exposure_limits", {})
        self.max_position_usd = config.get("max_position_usd", 100000)
        self.max_orders_per_symbol = config.get("max_orders_per_symbol", 10)
        self.transfer_risk_threshold = config.get("transfer_risk_threshold", 0.3)
        
    def check_risk_limits(self, opportunity: ArbitrageOpportunity) -> bool:
        """Check if opportunity passes risk limits"""
        
        # Check position limits
        for order in opportunity.orders:
            current_position = self.position_tracker.get_position()
                order.exchange, order.symbol
            )
            
            order_value = float(order.quantity * (order.price or Decimal("0")))
            
            if current_position + order_value > self.max_position_usd:
                logging.warning(f"Position limit exceeded for {order.symbol}")
                return False
        
        # Check exposure netting
        net_exposure = self._calculate_net_exposure(opportunity)
        if net_exposure > self.max_position_usd * 0.5:
            logging.warning(f"Net exposure too high: {net_exposure}")
            return False
        
        # Check transfer risk
        if opportunity.arbitrage_type == ArbitrageType.CROSS_EXCHANGE:
            if opportunity.risk_score > self.transfer_risk_threshold:
                logging.warning(f"Transfer risk too high: {opportunity.risk_score}")
                return False
        
        return True
    
    def _calculate_net_exposure(self, opportunity: ArbitrageOpportunity) -> float:
        """Calculate net exposure across all positions"""
        buy_exposure = Decimal("0")
        sell_exposure = Decimal("0")
        
        for order in opportunity.orders:
            value = order.quantity * (order.price or Decimal("0"))
            
            if order.side == OrderSide.BUY:
                buy_exposure += value
            else:
                sell_exposure += value
        
        return float(abs(buy_exposure - sell_exposure))

class PositionTracker:
    """Track positions across exchanges"""
    
    def __init__(self):
        self.positions: Dict[Tuple[ExchangeType, str], float] = defaultdict(float)
        self.lock = threading.Lock()
    
    def update_position(self, exchange: ExchangeType, symbol: str, delta: float):
        """Update position for symbol on exchange"""
        with self.lock:
            self.positions[(exchange, symbol)] += delta
    
    def get_position(self, exchange: ExchangeType, symbol: str) -> float:
        """Get current position"""
        with self.lock:
            return self.positions[(exchange, symbol)]
    
    def get_total_exposure(self) -> float:
        """Get total USD exposure across all positions"""
        with self.lock:
            return sum(abs(pos) for pos in self.positions.values())

class PerformanceMonitor:
    """Real-time performance monitoring and analytics"""
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.metrics_buffer = []
        self.buffer_lock = threading.Lock()
        
    async def start_monitoring(self):
        """Start performance monitoring tasks"""
        tasks = []
            asyncio.create_task(self._collect_metrics()),
            asyncio.create_task(self._publish_metrics()),
            asyncio.create_task(self._calculate_analytics()),
        ]
        await asyncio.gather(*tasks)
    
    async def _collect_metrics(self):
        """Collect performance metrics"""
        while True:
            metrics = {}
                "timestamp": time.time_ns(),
                "latency_p50": prom.generate_latest(latency_histogram),
                "total_profit": prom.generate_latest(profit_counter),
                "opportunities_detected": prom.generate_latest(opportunity_counter),
                "success_rate": prom.generate_latest(execution_success_rate),
            }
            
            with self.buffer_lock:
                self.metrics_buffer.append(metrics)
                
                # Flush to Redis if buffer is full
                if len(self.metrics_buffer) >= 100:
                    await self._flush_metrics()
            
            await asyncio.sleep(1)
    
    async def _flush_metrics(self):
        """Flush metrics to Redis"""
        with self.buffer_lock:
            if self.metrics_buffer:
                # Store in Redis time series
                pipeline = self.redis.pipeline()
                
                for metric in self.metrics_buffer:
                    key = f"arbitrage:metrics:{metric['timestamp']}"
                    pipeline.hset(key, mapping=metric)
                    pipeline.expire(key, 86400)  # 24 hour expiry
                
                pipeline.execute()
                self.metrics_buffer.clear()
    
    async def _publish_metrics(self):
        """Publish metrics to monitoring systems"""
        while True:
            # Publish to Prometheus gateway
            try:
                prom.push_to_gateway()
                    'localhost:9091', 
                    job='arbitrage_engine',
                    registry=prom.REGISTRY
                )
            except Exception as e:
                logging.error(f"Failed to push metrics: {e}")
            
            await asyncio.sleep(10)
    
    async def _calculate_analytics(self):
        """Calculate advanced analytics"""
        while True:
            try:
                # Calculate Sharpe ratio
                returns = await self._get_returns_history()
                if len(returns) > 30:
                    sharpe = self._calculate_sharpe_ratio(returns)
                    
                    # Store in Redis
                    self.redis.hset("arbitrage:analytics", "sharpe_ratio", sharpe)
                
                # Calculate other metrics
                await self._calculate_slippage()
                await self._calculate_transaction_costs()
                
            except Exception as e:
                logging.error(f"Analytics calculation error: {e}")
            
            await asyncio.sleep(60)
    
    async def _get_returns_history(self) -> List[float]:
        """Get historical returns"""
        # TODO: Implement returns calculation from execution history
        return []
    
    def _calculate_sharpe_ratio(self, returns: List[float]) -> float:
        """Calculate Sharpe ratio"""
        if not returns:
            return 0.0
        
        returns_array = np.array(returns)
        mean_return = np.mean(returns_array)
        std_return = np.std(returns_array)
        
        if std_return == 0:
            return 0.0
        
        # Assuming risk-free rate of 2% annually
        risk_free_rate = 0.02 / 365  # Daily rate
        sharpe = (mean_return - risk_free_rate) / std_return * np.sqrt(365)
        
        return float(sharpe)
    
    async def _calculate_slippage(self):
        """Calculate execution slippage"""
        # TODO: Compare expected vs actual execution prices
        pass
    
    async def _calculate_transaction_costs(self):
        """Calculate total transaction costs"""
        # TODO: Aggregate fees from execution history
        pass

class CrossExchangeArbitrageEngine:
    """Main arbitrage engine orchestrator"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.exchanges: Dict[ExchangeType, ExchangeConnector] = {}
        self.detector: Optional[ArbitrageDetector] = None
        self.executor: Optional[ExecutionEngine] = None
        self.risk_manager: Optional[RiskManager] = None
        self.performance_monitor: Optional[PerformanceMonitor] = None
        self.redis_client = redis.Redis()
            host=config.get("redis_host", "localhost"),
            port=config.get("redis_port", 6379),
            decode_responses=True
        )
        
    async def initialize(self):
        """Initialize all components"""
        
        # Initialize exchange connectors
        await self._initialize_exchanges()
        
        # Initialize components
        self.detector = ArbitrageDetector(self.exchanges)
        self.executor = ExecutionEngine(self.exchanges)
        self.risk_manager = RiskManager(self.config.get("risk", {}))
        self.performance_monitor = PerformanceMonitor(self.redis_client)
        
        # Connect components
        await self._connect_components()
        
        logging.info("Arbitrage engine initialized successfully")
    
    async def _initialize_exchanges(self):
        """Initialize exchange connectors"""
        exchange_configs = self.config.get("exchanges", {})
        
        for exchange_name, exchange_config in exchange_configs.items():
            if not exchange_config.get("enabled", False):
                continue
            
            exchange_type = ExchangeType[exchange_name.upper()]
            
            if exchange_type == ExchangeType.BINANCE:
                connector = BinanceConnector()
                    api_key=exchange_config["api_key"],
                    api_secret=exchange_config["api_secret"],
                    colocation=exchange_config.get("colocation", "main")
                )
            # TODO: Add other exchange connectors
            else:
                continue
            
            await connector.connect_websocket()
            
            # Subscribe to configured symbols
            for symbol in exchange_config.get("symbols", []):
                await connector.subscribe_orderbook(symbol)
            
            self.exchanges[exchange_type] = connector
            
            logging.info(f"Initialized {exchange_name} connector")
    
    async def _connect_components(self):
        """Connect components for data flow"""
        
        # Connect detector to executor
        asyncio.create_task(self._opportunity_processor())
    
    async def _opportunity_processor(self):
        """Process detected opportunities"""
        while True:
            try:
                # Get opportunity from detector
                opportunity = await self.detector.opportunity_queue.get()
                
                # Check risk limits
                if not self.risk_manager.check_risk_limits(opportunity):
                    continue
                
                # Send to executor
                await self.executor.execution_queue.put(opportunity)
                
            except Exception as e:
                logging.error(f"Opportunity processor error: {e}")
    
    async def start(self):
        """Start the arbitrage engine"""
        await self.initialize()
        
        # Start all components
        tasks = []
            asyncio.create_task(self.detector.start_detection()),
            asyncio.create_task(self.executor.start_execution()),
            asyncio.create_task(self.performance_monitor.start_monitoring()),
        ]
        
        # Start Prometheus HTTP server
        prom.start_http_server(8000)
        
        logging.info("Arbitrage engine started")
        
        # Wait for tasks
        await asyncio.gather(*tasks)
    
    async def shutdown(self):
        """Graceful shutdown"""
        logging.info("Shutting down arbitrage engine...")
        
        # Close exchange connections
        for connector in self.exchanges.values():
            if connector.ws_connection:
                await connector.ws_connection.close()
        
        # Flush metrics
        await self.performance_monitor._flush_metrics()
        
        logging.info("Arbitrage engine shutdown complete")

def main():
    """Main entry point"""
    
    # Load configuration
    config = {}
        "exchanges": {}
            "binance": {}
                "enabled": True,
                "api_key": os.environ.get("BINANCE_API_KEY", ""),
                "api_secret": os.environ.get("BINANCE_API_SECRET", ""),
                "colocation": "main",
                "symbols": ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT"]
            },
            "coinbase": {}
                "enabled": True,
                "api_key": os.environ.get("COINBASE_API_KEY", ""),
                "api_secret": os.environ.get("COINBASE_API_SECRET", ""),
                "symbols": ["BTC-USD", "ETH-USD", "ADA-USD"]
            }
        },
        "risk": {}
            "max_position_usd": 50000,
            "max_orders_per_symbol": 5,
            "transfer_risk_threshold": 0.4,
            "exposure_limits": {}
                "BTCUSDT": 20000,
                "ETHUSDT": 15000
            }
        },
        "redis_host": "localhost",
        "redis_port": 6379
    }
    
    # Configure logging
    logging.basicConfig()
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[]
            logging.StreamHandler(),
            logging.FileHandler('arbitrage_engine.log')
        ]
    )
    
    # Create and start engine
    engine = ArbitrageEngine(config)
    
    # Handle signals
    def signal_handler(signum, frame):
        logging.info(f"Received signal {signum}")
        asyncio.create_task(engine.shutdown())
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run engine
    try:
        asyncio.run(engine.start())
    except KeyboardInterrupt:
        logging.info("Keyboard interrupt received")
        asyncio.run(engine.shutdown())

if __name__ == "__main__":
    main()