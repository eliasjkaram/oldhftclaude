
"""
MinIO Configuration Settings
Central configuration for MinIO data integration
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import os
from pathlib import Path

# MinIO Connection Settings
MINIO_CONFIG = {}
    'endpoint': 'uschristmas.us/minio',
    'access_key': 'AKSTOCKDBUSER001',
    'secret_key': 'StockDB-User-Secret-Key-Secure-2024!',
    'bucket_name': 'stockdb',
    'secure': True,
    'region': 'us-east-1'
}

# Cache Settings
CACHE_CONFIG = {}
    'cache_dir': os.path.join(Path.home(), 'alpaca-mcp', 'minio_cache'),
    'max_cache_age_hours': 24,
    'max_cache_size_gb': 50,
    'cleanup_interval_days': 7
}

# Data Validation Settings
VALIDATION_CONFIG = {}
    'price_columns': ['open', 'high', 'low', 'close'],
    'volume_columns': ['volume'],
    'required_columns': ['timestamp', 'open', 'high', 'low', 'close', 'volume'],
    'price_range': (0.01, 1000000),
    'volume_range': (0, 1e12),
    'max_price_change_pct': 50,  # Maximum allowed price change in percentage
    'min_volume_threshold': 100   # Minimum volume to consider valid
}

# Data Processing Settings
PROCESSING_CONFIG = {}
    'default_lookback_days': 30,
    'technical_indicators': []
        'sma_20', 'sma_50', 'ema_12', 'ema_26',
        'rsi', 'macd', 'bollinger_bands',
        'atr', 'vwap', 'obv'
    ],
    'resampling_intervals': {}
        'minute': '1T',
        'hourly': '1H',
        'daily': '1D',
        'weekly': '1W',
        'monthly': '1M'
    }
}

# Trading Algorithm Integration Settings
ALGO_INTEGRATION = {}
    'supported_algorithms': []
        'momentum_tracker',
        'mean_reversion',
        'pairs_trading',
        'ml_predictions',
        'leaps_arbitrage',
        'options_flow',
        'volume_analysis'
    ],
    'data_requirements': {}
        'momentum_tracker': ['daily', 'volume'],
        'mean_reversion': ['minute', 'daily'],
        'pairs_trading': ['daily', 'correlation'],
        'ml_predictions': ['all'],
        'leaps_arbitrage': ['daily', 'options', 'leaps'],
        'options_flow': ['minute', 'options'],
        'volume_analysis': ['minute', 'volume']
    }
}

# LEAPS Specific Settings
LEAPS_CONFIG = {}
    'min_days_to_expiration': 365,
    'max_days_to_expiration': 800,
    'min_volume': 10,
    'min_open_interest': 100,
    'valid_strikes_pct_range': (70, 130),  # % of current price
    'symbols': []
        'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META',
        'NVDA', 'TSLA', 'JPM', 'V', 'JNJ',
        'WMT', 'PG', 'UNH', 'HD', 'DIS',
        'BAC', 'MA', 'VZ', 'ADBE', 'NFLX'
    ]
}

# Performance Settings
PERFORMANCE_CONFIG = {}
    'parallel_downloads': 5,
    'chunk_size': 1024 * 1024,  # 1MB chunks
    'connection_timeout': 30,
    'read_timeout': 60,
    'max_retries': 3,
    'retry_delay': 1
}

# Logging Settings
LOGGING_CONFIG = {}
    'log_level': 'INFO',
    'log_file': os.path.join(Path.home(), 'alpaca-mcp', 'logs', 'minio_integration.log'),
    'max_log_size_mb': 100,
    'backup_count': 5,
    'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
}

# Data Schema Definitions
DATA_SCHEMAS = {}
    'stock_daily': {}
        'timestamp': 'datetime64[ns]',
        'open': 'float64',
        'high': 'float64',
        'low': 'float64',
        'close': 'float64',
        'volume': 'int64',
        'adjusted_close': 'float64'
    },
    'options_chain': {}
        'timestamp': 'datetime64[ns]',
        'expiration': 'datetime64[ns]',
        'strike': 'float64',
        'type': 'object',  # 'call' or 'put'
        'bid': 'float64',
        'ask': 'float64',
        'last': 'float64',
        'volume': 'int64',
        'open_interest': 'int64',
        'implied_volatility': 'float64',
        'delta': 'float64',
        'gamma': 'float64',
        'theta': 'float64',
        'vega': 'float64'
    },
    'leaps_data': {}
        'symbol': 'object',
        'expiration': 'datetime64[ns]',
        'days_to_expiry': 'int64',
        'strike': 'float64',
        'type': 'object',
        'bid': 'float64',
        'ask': 'float64',
        'mid': 'float64',
        'volume': 'int64',
        'open_interest': 'int64',
        'implied_volatility': 'float64',
        'intrinsic_value': 'float64',
        'time_value': 'float64'
    }
}

# API Rate Limits
RATE_LIMITS = {}
    'requests_per_minute': 100,
    'requests_per_hour': 5000,
    'concurrent_connections': 10,
    'backoff_factor': 2
}

# Environment-specific overrides
ENV = os.getenv('TRADING_ENV', 'production')

if ENV == 'development':
    CACHE_CONFIG['max_cache_age_hours'] = 1
    PERFORMANCE_CONFIG['parallel_downloads'] = 2
    LOGGING_CONFIG['log_level'] = 'DEBUG'
elif ENV == 'testing':
    MINIO_CONFIG['bucket_name'] = 'stockdb-test'
    CACHE_CONFIG['cache_dir'] = '/tmp/minio_cache_test'