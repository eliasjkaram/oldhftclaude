import sys
import os
from config import config

from universal_market_data import get_current_market_data, get_realistic_price
#!/usr/bin/env python3
"""
Portfolio Optimization Demo
Demonstrates Modern Portfolio Theory optimization techniques
"""

import numpy as np
import pandas as pd
import json

import logging
from datetime import datetime, timedelta
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

warnings.filterwarnings('ignore')

from portfolio_optimization_mpt import ()
    ModernPortfolioTheory,
    BlackLittermanModel,
    RiskParityOptimizer,
    HierarchicalRiskParity
)

# Setup logging
logger = logging.getLogger(__name__)


# Production Configuration
PRODUCTION_CONFIG = {}
    "api_endpoint": os.getenv("ALPACA_API_ENDPOINT", "https://api.alpaca.markets"),
    "data_endpoint": os.getenv("ALPACA_DATA_ENDPOINT", "https://data.alpaca.markets"),
    "paper_trading": os.getenv("PAPER_TRADING", "false").lower() == "true",
    "max_position_size": float(os.getenv("MAX_POSITION_SIZE", "0.1")),
    "risk_limit": float(os.getenv("RISK_LIMIT", "0.02")),
    "trading_symbols": os.getenv("TRADING_SYMBOLS", "SPY,QQQ,AAPL,MSFT,GOOGL").split(","),
    "log_level": os.getenv("LOG_LEVEL", "INFO"),
    "enable_notifications": os.getenv("ENABLE_NOTIFICATIONS", "true").lower() == "true",
    "database_url": os.getenv("DATABASE_URL", "sqlite:///trading.db"),
    "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
    "min_confidence": float(os.getenv("MIN_CONFIDENCE", "0.7")),
}

# Configure logging
logging.basicConfig()
    level=getattr(logging, PRODUCTION_CONFIG["log_level"]),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('trading_system.log'),
        logging.StreamHandler()
    ]
)

class PortfolioOptimizationDemo:
    """Demo class for portfolio optimization techniques"""
    
    def __init__(self):
    try:
            # Load configuration
            with open('alpaca_config.json', 'r') as f:
                config = json.load(f)
        
            self.client = TradingClient()
                config.get('paper_api_key'),
                config.get('paper_secret_key'),
                config.get('paper_base_url')
            )
        
            self.assets = None
            self.returns_data = None
            self.prices_data = None
        
        def fetch_portfolio_data(self, symbols, start_date='2020-01-01', end_date = config.get("end_date", datetime.now())):
            """Fetch historical data for portfolio assets"""
            logger.info(f"\n📊 Fetching data for portfolio: {symbols}")
        
            all_data = {}
        
            for symbol in symbols:
                logger.info(f"  Downloading {symbol}...")
                bars = self.client.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Day, start=start_date,
                    end=end_date,
                    adjustment='raw'
                ).df
            
                if not bars.empty:
                    all_data[symbol] = bars['close']
        
            if all_data:
                # Create price DataFrame
                self.prices_data = pd.DataFrame(all_data)
                self.prices_data = self.prices_data.dropna()
            
                # Calculate returns
                self.returns_data = self.prices_data.pct_change().dropna()
                self.assets = list(self.prices_data.columns)
            
                logger.info(f"✅ Data fetched successfully: {len(self.prices_data)} days")
                return True
            else:
                logger.info("❌ Failed to fetch data")
                return False
    
        def run_markowitz_optimization(self):
            """Run Markowitz mean-variance optimization"""
            logger.info("\n" + "="*80)
            logger.info("🎯 MARKOWITZ MEAN-VARIANCE OPTIMIZATION")
            logger.info("="*80)
        
            mpt = ModernPortfolioTheory(risk_free_rate=0.02)
        
            # 1. Maximum Sharpe Ratio Portfolio
            logger.info("\n1️⃣ Maximum Sharpe Ratio Portfolio:")
            sharpe_result = mpt.optimize_portfolio(self.returns_data, objective='sharpe')
            self.display_portfolio_result(sharpe_result)
        
            # 2. Minimum Variance Portfolio
            logger.info("\n2️⃣ Minimum Variance Portfolio:")
            min_var_result = mpt.optimize_portfolio(self.returns_data, objective='min_variance')
            self.display_portfolio_result(min_var_result)
        
            # 3. Risk Parity Portfolio
            logger.info("\n3️⃣ Risk Parity Portfolio:")
            risk_parity_result = mpt.optimize_portfolio(self.returns_data, objective='risk_parity')
            self.display_portfolio_result(risk_parity_result)
        
            # 4. Constrained Portfolio (max 30% per asset)
            logger.info("\n4️⃣ Constrained Portfolio (Max 30% per asset):")
            constrained_result = mpt.optimize_portfolio()
                self.returns_data, 
                objective='sharpe',
                max_weight=0.3
            )
            self.display_portfolio_result(constrained_result)
        
            return {}
                'sharpe': sharpe_result,
                'min_variance': min_var_result,
                'risk_parity': risk_parity_result,
                'constrained': constrained_result
            }
    
        def run_efficient_frontier(self):
            """Calculate and plot efficient frontier"""
            logger.info("\n" + "="*80)
            logger.info("📈 EFFICIENT FRONTIER ANALYSIS")
            logger.info("="*80)
        
            mpt = ModernPortfolioTheory(risk_free_rate=0.02)
        
            # Calculate efficient frontier
            frontier = mpt.efficient_frontier(self.returns_data, n_portfolios=50)
        
            if not frontier.empty:
                logger.info(f"\n✅ Calculated {len(frontier)} portfolios on efficient frontier")
            
                # Find optimal portfolio (max Sharpe)
                optimal_idx = frontier['sharpe'].idxmax()
                optimal = frontier.iloc[optimal_idx]
            
                logger.info(f"\n🏆 Optimal Portfolio (Max Sharpe):")
                logger.info(f"  Return: {optimal['return']:.2%}")
                logger.info(f"  Risk: {optimal['risk']:.2%}")
                logger.info(f"  Sharpe: {optimal['sharpe']:.2f}")
            
                # Plot efficient frontier
                plt.figure(figsize=(10, 6)
                plt.scatter(frontier['risk'], frontier['return'], c=frontier['sharpe'], 
                           cmap='viridis', alpha=0.6)
                plt.colorbar(label='Sharpe Ratio')
                plt.scatter(optimal['risk'], optimal['return'], color='red', s=100, 
                           marker='*', label='Optimal Portfolio')
                plt.xlabel('Risk (Standard Deviation)')
                plt.ylabel('Expected Return')
                plt.title('Efficient Frontier')
                plt.legend()
                plt.grid(True, alpha=0.3)
            
                # Save plot
                plt.savefig('efficient_frontier.png', dpi=150, bbox_inches='tight')
                logger.info("\n📊 Efficient frontier plot saved to: efficient_frontier.png")
            
            return frontier
    
        def run_black_litterman(self):
            """Run Black-Litterman optimization with investor views"""
            logger.info("\n" + "="*80)
            logger.info("🔮 BLACK-LITTERMAN MODEL")
            logger.info("="*80)
        
            # Market cap weights (example - equal weight as proxy)
            market_cap_weights = pd.Series(1/len(self.assets), index=self.assets)
        
            # Initialize Black-Litterman model
            bl_model = BlackLittermanModel(market_cap_weights)
        
            # Calculate covariance matrix
            cov_matrix = self.returns_data.cov() * 252
        
            # Example views
            views = {}
                'AAPL': 0.15,    # 15% expected return for AAPL
                'MSFT': 0.18,    # 18% expected return for MSFT
            }
        
            view_confidences = {}
                'AAPL': 0.8,     # 80% confidence in AAPL view
                'MSFT': 0.9,     # 90% confidence in MSFT view
            }
        
            logger.info("\n📊 Investor Views:")
            for asset, view in views.items():
                if asset in self.assets:
                    conf = view_confidences[asset]
                    logger.info(f"  {asset}: {view:.1%} return (confidence: {conf:.0%})")
        
            # Calculate Black-Litterman returns
            bl_returns = bl_model.black_litterman_returns(cov_matrix, views, view_confidences)
        
            logger.info("\n📈 Black-Litterman Expected Returns:")
            for asset in self.assets:
                equilibrium = bl_model.implied_equilibrium_returns(cov_matrix)[asset]
                bl = bl_returns[asset]
                logger.info(f"  {asset}: Equilibrium {equilibrium:.2%} → BL {bl:.2%}")
        
            # Optimize using BL returns
            mpt = ModernPortfolioTheory()
        
            # Create synthetic returns data with BL expected returns
            bl_returns_data = self.returns_data.copy()
            for asset in self.assets:
                # Adjust returns to match BL expectations
                current_mean = self.returns_data[asset].mean() * 252
                adjustment = bl_returns[asset] - current_mean
                bl_returns_data[asset] = self.returns_data[asset] + adjustment / 252
        
            # Optimize portfolio
            bl_result = mpt.optimize_portfolio(bl_returns_data, objective='sharpe')
        
            logger.info("\n🎯 Black-Litterman Optimal Portfolio:")
            self.display_portfolio_result(bl_result)
        
            return bl_result
    
        def run_risk_parity(self):
            """Run standalone Risk Parity optimization"""
            logger.info("\n" + "="*80)
            logger.info("⚖️ RISK PARITY OPTIMIZATION")
            logger.info("="*80)
        
            # Calculate covariance matrix
            cov_matrix = self.returns_data.cov() * 252
        
            # Risk Parity optimization
            rp_optimizer = RiskParityOptimizer()
            rp_result = rp_optimizer.optimize(cov_matrix.values)
        
            logger.info("\n📊 Risk Parity Portfolio:")
            logger.info(f"\nAsset Weights and Risk Contributions:")
            for i, asset in enumerate(self.assets):
                weight = rp_result['weights'][i]
                risk_contrib = rp_result['risk_contributions'][i]
                logger.info(f"  {asset}: Weight {weight:.2%}, Risk Contribution {risk_contrib:.2%}")
        
            logger.info(f"\n📈 Portfolio Volatility: {rp_result['portfolio_volatility']:.2%}")
        
            # Compare with equal weight
            equal_weight = np.ones(len(self.assets) / len(self.assets)
            equal_vol = np.sqrt(equal_weight @ cov_matrix.values @ equal_weight)
            logger.info(f"📊 Equal Weight Volatility: {equal_vol:.2%}")
            logger.info(f"📉 Risk Reduction: {(equal_vol - rp_result['portfolio_volatility']) / equal_vol:.1%}")
        
            return rp_result
    
        def run_hierarchical_risk_parity(self):
            """Run Hierarchical Risk Parity optimization"""
            logger.info("\n" + "="*80)
            logger.info("🏗️ HIERARCHICAL RISK PARITY (HRP)")
            logger.info("="*80)
        
            # Calculate covariance matrix
            cov_matrix = self.returns_data.cov() * 252
        
            # HRP optimization
            hrp = HierarchicalRiskParity()
            hrp_result = hrp.optimize(cov_matrix)
        
            logger.info("\n📊 HRP Portfolio Weights:")
            for i, asset in enumerate(hrp_result['assets']):
                weight = hrp_result['weights'][i]
                logger.info(f"  {asset}: {weight:.2%}")
        
            # Calculate portfolio metrics
            weights = hrp_result['weights']
            portfolio_return = np.dot(weights, self.returns_data.mean().values * 252)
            portfolio_vol = np.sqrt(weights @ cov_matrix.values @ weights)
            sharpe = (portfolio_return - 0.02) / portfolio_vol
        
            logger.info(f"\n📈 HRP Portfolio Metrics:")
            logger.info(f"  Expected Return: {portfolio_return:.2%}")
            logger.info(f"  Volatility: {portfolio_vol:.2%}")
            logger.info(f"  Sharpe Ratio: {sharpe:.2f}")
        
            return hrp_result
    
        def display_portfolio_result(self, result):
            """Display portfolio optimization results"""
            metrics = result['metrics']
            allocation = result['allocation']
        
            logger.info(f"\n📊 Portfolio Metrics:")
            logger.info(f"  Expected Return: {metrics['return']:.2%}")
            logger.info(f"  Risk (Std Dev): {metrics['risk']:.2%}")
            logger.info(f"  Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            logger.info(f"  Effective Assets: {result['effective_assets']} of {result['total_assets']}")
        
            logger.info(f"\n💼 Asset Allocation:")
            for _, row in allocation.iterrows():
                if row['Weight'] > 0.01:  # Show only >1% allocations
                    print(f"  {row['Asset']}: {row['Weight']:.1%} ")
                          f"(Return Contrib: {row['Contribution to Return']:.2%}, ")
                          f"Risk Contrib: {row['Risk Contribution']:.1%})")
    
        def compare_all_methods(self):
            """Compare all portfolio optimization methods"""
            logger.info("\n" + "="*80)
            logger.info("📊 PORTFOLIO OPTIMIZATION METHODS COMPARISON")
            logger.info("="*80)
        
            results = {}
        
            # 1. Markowitz
            mpt = ModernPortfolioTheory()
            mpt_result = mpt.optimize_portfolio(self.returns_data, objective='sharpe')
            results['Markowitz'] = self.extract_metrics(mpt_result)
        
            # 2. Minimum Variance
            min_var_result = mpt.optimize_portfolio(self.returns_data, objective='min_variance')
            results['Min Variance'] = self.extract_metrics(min_var_result)
        
            # 3. Risk Parity (MPT)
            rp_mpt_result = mpt.optimize_portfolio(self.returns_data, objective='risk_parity')
            results['Risk Parity (MPT)'] = self.extract_metrics(rp_mpt_result)
        
            # 4. Risk Parity (Standalone)
            cov_matrix = self.returns_data.cov() * 252
            rp_optimizer = RiskParityOptimizer()
            rp_result = rp_optimizer.optimize(cov_matrix.values)
            results['Risk Parity'] = self.calculate_rp_metrics(rp_result, cov_matrix)
        
            # 5. HRP
            hrp = HierarchicalRiskParity()
            hrp_result = hrp.optimize(cov_matrix)
            results['HRP'] = self.calculate_hrp_metrics(hrp_result, cov_matrix)
        
            # Create comparison DataFrame
            comparison_df = pd.DataFrame(results).T
        
            logger.info("\n📊 Methods Comparison:")
            logger.info(comparison_df.round(3)
        
            # Find best by each metric
            logger.info("\n🏆 Best Performers:")
            logger.info(f"  Highest Return: {comparison_df['Return'].idxmax()} ({comparison_df['Return'].max():.2%})")
            logger.info(f"  Lowest Risk: {comparison_df['Risk'].idxmin()} ({comparison_df['Risk'].min():.2%})")
            logger.info(f"  Best Sharpe: {comparison_df['Sharpe'].idxmax()} ({comparison_df['Sharpe'].max():.2f})")
        
            # Save comparison
            comparison_df.to_csv('portfolio_optimization_comparison.csv')
            logger.info("\n💾 Comparison saved to: portfolio_optimization_comparison.csv")
        
            return comparison_df
    
        def extract_metrics(self, result):
            """Extract metrics from optimization result"""
            metrics = result['metrics']
            return {}
                'Return': metrics['return'],
                'Risk': metrics['risk'],
                'Sharpe': metrics['sharpe_ratio']
            }
    
        def calculate_rp_metrics(self, rp_result, cov_matrix):
            """Calculate metrics for Risk Parity result"""
            weights = rp_result['weights']
            returns = self.returns_data.mean().values * 252
        
            portfolio_return = np.dot(weights, returns)
            portfolio_vol = rp_result['portfolio_volatility']
            sharpe = (portfolio_return - 0.02) / portfolio_vol
        
            return {}
                'Return': portfolio_return,
                'Risk': portfolio_vol,
                'Sharpe': sharpe
            }
    
        def calculate_hrp_metrics(self, hrp_result, cov_matrix):
            """Calculate metrics for HRP result"""
            weights = hrp_result['weights']
            returns = self.returns_data.mean().values * 252
        
            portfolio_return = np.dot(weights, returns)
            portfolio_vol = np.sqrt(weights @ cov_matrix.values @ weights)
            sharpe = (portfolio_return - 0.02) / portfolio_vol
        
            return {}
                'Return': portfolio_return,
                'Risk': portfolio_vol,
                'Sharpe': sharpe
            }
    
        def run_full_demo(self):
            """Run complete portfolio optimization demo"""
            logger.info("="*80)
            logger.info("🚀 ADVANCED PORTFOLIO OPTIMIZATION DEMO")
            logger.info("="*80)
        
            # Define portfolio assets
            symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'TSLA', 'JPM', 'JNJ', 'XOM']
        
            # Fetch data
            if not self.fetch_portfolio_data(symbols):
                return
        
            # Display basic statistics
            logger.info("\n📊 Portfolio Statistics:")
            logger.info(f"  Assets: {len(self.assets)}")
            logger.info(f"  Time Period: {self.prices_data.index[0].date()} to {self.prices_data.index[-1].date()}")
            logger.info(f"  Total Days: {len(self.prices_data)}")
        
            logger.info("\n📈 Annual Returns:")
            annual_returns = self.returns_data.mean() * 252
            for asset in self.assets:
                logger.info(f"  {asset}: {annual_returns[asset]:.2%}")
        
            # Run all optimization methods
            markowitz_results = self.run_markowitz_optimization()
            efficient_frontier = self.run_efficient_frontier()
            bl_result = self.run_black_litterman()
            rp_result = self.run_risk_parity()
            hrp_result = self.run_hierarchical_risk_parity()
        
            # Compare all methods
            comparison = self.compare_all_methods()
        
            logger.info("\n" + "="*80)
            logger.info("✅ PORTFOLIO OPTIMIZATION DEMO COMPLETE!")
            logger.info("="*80)
            logger.info("\n📁 Generated Files:")
            logger.info("  - efficient_frontier.png")
            logger.info("  - portfolio_optimization_comparison.csv")
        
            return {}
                'markowitz': markowitz_results,
                'efficient_frontier': efficient_frontier,
                'black_litterman': bl_result,
                'risk_parity': rp_result,
                'hrp': hrp_result,
                'comparison': comparison
            }

    except Exception as e:
        logger.error(f"Error in __init__: {str(e)}")
        raise

def main():
    try:
        """Run the portfolio optimization demo"""
        demo = PortfolioOptimizationDemo()
        results = demo.run_full_demo()
    
        if results:
            logger.info("\n🎯 Key Takeaways:")
            logger.info("  1. Different optimization methods suit different objectives")
            logger.info("  2. Markowitz maximizes risk-adjusted returns (Sharpe)")
            logger.info("  3. Risk Parity equalizes risk contributions")
            logger.info("  4. HRP uses machine learning for robust portfolios")
            logger.info("  5. Black-Litterman incorporates investor views")
        
            logger.info("\n💡 Next Steps:")
            logger.info("  - Implement portfolio rebalancing strategies")
            logger.info("  - Add transaction cost optimization")
            logger.info("  - Integrate with live trading system")
            logger.info("  - Create dynamic asset selection")
            logger.info("  - Add alternative data sources")


    if __name__ == "__main__":

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise
    main()