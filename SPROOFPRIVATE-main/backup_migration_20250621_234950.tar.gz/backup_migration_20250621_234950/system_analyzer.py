#!/usr/bin/env python3
"""
System Analyzer - Understand the complete trading system architecture
Analyzes all components, their relationships, and provides insights
"""

import os
import ast
import json
from pathlib import Path
from collections import defaultdict
import re
from datetime import datetime

class TradingSystemAnalyzer:
    def __init__(self, root_path="."):
        self.root_path = Path(root_path)
        self.components = defaultdict(dict)
        self.imports = defaultdict(set)
        self.classes = defaultdict(list)
        self.functions = defaultdict(list)
        self.dependencies = defaultdict(set)
        self.categories = defaultdict(list)
        
    def analyze_system(self):
        """Run complete system analysis"""
        print("🔍 Analyzing Trading System Architecture...")
        print("=" * 80)
        
        # 1. Discover all Python files
        py_files = self._discover_python_files()
        print(f"\n📁 Found {len(py_files)} Python files")
        
        # 2. Analyze each file
        for py_file in py_files:
            self._analyze_file(py_file)
        
        # 3. Categorize components
        self._categorize_components()
        
        # 4. Generate report
        self._generate_report()
        
    def _discover_python_files(self):
        """Find all Python files, excluding venv and __pycache__"""
        py_files = []
        for root, dirs, files in os.walk(self.root_path):
            # Skip virtual environments and cache
            dirs[:] = [d for d in dirs if d not in {'venv', '__pycache__', '.git'}]
            
            for file in files:
                if file.endswith('.py'):
                    py_files.append(Path(root) / file)
        
        return sorted(py_files)
    
    def _analyze_file(self, file_path):
        """Analyze a single Python file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Basic info
            rel_path = file_path.relative_to(self.root_path)
            self.components[str(rel_path)] = {
                'size': len(content),
                'lines': content.count('\n'),
                'path': str(rel_path),
                'type': self._determine_file_type(rel_path, content)
            }
            
            # Parse AST
            try:
                tree = ast.parse(content)
                self._extract_ast_info(tree, str(rel_path))
            except SyntaxError:
                self.components[str(rel_path)]['has_syntax_error'] = True
            
            # Extract imports via regex (backup for syntax errors)
            self._extract_imports_regex(content, str(rel_path))
            
        except Exception as e:
            self.components[str(rel_path)]['error'] = str(e)
    
    def _determine_file_type(self, path, content):
        """Determine the type/category of the file"""
        path_str = str(path).lower()
        
        # Check by directory
        if 'core/' in path_str:
            return 'core_infrastructure'
        elif 'advanced/' in path_str:
            return 'advanced_trading'
        elif 'test' in path_str:
            return 'test'
        elif 'demo' in path_str:
            return 'demo'
        elif 'fix' in path_str or 'FIX' in path_str:
            return 'maintenance'
        elif 'gui' in path_str:
            return 'gui'
        elif 'backtest' in path_str:
            return 'backtesting'
        elif 'ml_' in path_str or 'ai_' in path_str:
            return 'ml_ai'
        elif 'options' in path_str:
            return 'options_trading'
        elif 'arbitrage' in path_str:
            return 'arbitrage'
        elif 'production' in path_str:
            return 'production'
        
        # Check by content
        if 'class.*Bot' in content:
            return 'trading_bot'
        elif 'alpaca' in content.lower():
            return 'broker_integration'
        elif 'minio' in content.lower():
            return 'data_storage'
        
        return 'utility'
    
    def _extract_ast_info(self, tree, file_path):
        """Extract classes, functions, and imports from AST"""
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                self.classes[file_path].append({
                    'name': node.name,
                    'bases': [self._get_name(base) for base in node.bases],
                    'methods': [n.name for n in node.body if isinstance(n, ast.FunctionDef)]
                })
            
            elif isinstance(node, ast.FunctionDef):
                if not any(node.name == method for cls in self.classes[file_path] for method in cls.get('methods', [])):
                    self.functions[file_path].append(node.name)
            
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        self.imports[file_path].add(alias.name)
                else:
                    module = node.module or ''
                    self.imports[file_path].add(module)
    
    def _get_name(self, node):
        """Get name from AST node"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{self._get_name(node.value)}.{node.attr}"
        return str(node)
    
    def _extract_imports_regex(self, content, file_path):
        """Extract imports using regex (for files with syntax errors)"""
        import_pattern = r'(?:from\s+(\S+)\s+)?import\s+([^#\n]+)'
        for match in re.finditer(import_pattern, content):
            module = match.group(1) or match.group(2).split()[0]
            self.imports[file_path].add(module.split('.')[0])
    
    def _categorize_components(self):
        """Categorize all components by type"""
        for path, info in self.components.items():
            category = info.get('type', 'unknown')
            self.categories[category].append(path)
    
    def _generate_report(self):
        """Generate comprehensive analysis report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_files': len(self.components),
            'total_lines': sum(c.get('lines', 0) for c in self.components.values()),
            'categories': {},
            'key_components': {},
            'entry_points': [],
            'dependencies': {}
        }
        
        # Category summary
        for category, files in self.categories.items():
            report['categories'][category] = {
                'count': len(files),
                'files': files[:5]  # Top 5 examples
            }
        
        # Find key components
        self._identify_key_components(report)
        
        # Find entry points
        self._identify_entry_points(report)
        
        # Save report
        with open('system_analysis_report.json', 'w') as f:
            json.dump(report, f, indent=2)
        
        # Print summary
        self._print_summary(report)
    
    def _identify_key_components(self, report):
        """Identify the most important components"""
        # Large files (likely important)
        large_files = sorted(
            [(p, c['lines']) for p, c in self.components.items() if c.get('lines', 0) > 500],
            key=lambda x: x[1],
            reverse=True
        )[:10]
        
        # Files with many classes
        class_rich = sorted(
            [(p, len(self.classes[p])) for p in self.classes if len(self.classes[p]) > 3],
            key=lambda x: x[1],
            reverse=True
        )[:10]
        
        # Hub files (many imports)
        import_hubs = sorted(
            [(p, len(self.imports[p])) for p in self.imports if len(self.imports[p]) > 10],
            key=lambda x: x[1],
            reverse=True
        )[:10]
        
        report['key_components'] = {
            'large_files': large_files,
            'class_rich_files': class_rich,
            'import_hubs': import_hubs
        }
    
    def _identify_entry_points(self, report):
        """Identify main entry points"""
        entry_points = []
        
        for path, info in self.components.items():
            # Check for main execution patterns
            if path.startswith('run_') or path.startswith('launch_'):
                entry_points.append(path)
            elif path.endswith('_launcher.py') or path.endswith('_demo.py'):
                entry_points.append(path)
            elif 'main' in self.functions.get(path, []):
                entry_points.append(path)
        
        report['entry_points'] = sorted(entry_points)[:20]
    
    def _print_summary(self, report):
        """Print a readable summary"""
        print("\n" + "="*80)
        print("📊 TRADING SYSTEM ANALYSIS SUMMARY")
        print("="*80)
        
        print(f"\n📈 System Size:")
        print(f"   Total Files: {report['total_files']}")
        print(f"   Total Lines: {report['total_lines']:,}")
        
        print(f"\n📁 Component Categories:")
        for cat, info in sorted(report['categories'].items(), key=lambda x: x[1]['count'], reverse=True):
            print(f"   {cat:20} {info['count']:4} files")
        
        print(f"\n🔑 Key Components:")
        print(f"\n   Largest Files:")
        for file, lines in report['key_components']['large_files'][:5]:
            print(f"      {file:50} {lines:,} lines")
        
        print(f"\n   Most Complex (Classes):")
        for file, count in report['key_components']['class_rich_files'][:5]:
            print(f"      {file:50} {count} classes")
        
        print(f"\n🚀 Main Entry Points:")
        for ep in report['entry_points'][:10]:
            print(f"   - {ep}")
        
        print(f"\n📝 Full report saved to: system_analysis_report.json")
        print("="*80)

if __name__ == "__main__":
    analyzer = TradingSystemAnalyzer()
    analyzer.analyze_system()