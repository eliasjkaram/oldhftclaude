#!/usr/bin/env python3
"""
Mock gym module for when OpenAI Gym is not installed
"""

import numpy as np
from typing import Tuple, Dict, Any, Optional

class Env:
    """Base environment class"""
    def __init__(self):
        self.action_space = None
        self.observation_space = None
        self.reward_range = (-float('inf'), float('inf'))
        
    def step(self, action):
        raise NotImplementedError
        
    def reset(self):
        raise NotImplementedError
        
    def render(self, mode='human'):
        pass
        
    def close(self):
        pass

class Space:
    """Base space class"""
    def __init__(self, shape=None, dtype=None):
        self.shape = shape
        self.dtype = dtype
        
    def sample(self):
        raise NotImplementedError
        
    def contains(self, x):
        raise NotImplementedError

class Box(Space):
    """Box space for continuous values"""
    def __init__(self, low, high, shape=None, dtype=np.float32):
        super().__init__(shape, dtype)
        self.low = low
        self.high = high
        if shape is None:
            self.shape = np.array(low).shape
            
    def sample(self):
        return np.random.uniform(self.low, self.high, self.shape).astype(self.dtype)
        
    def contains(self, x):
        return x.shape == self.shape and np.all(x >= self.low) and np.all(x <= self.high)

class Discrete(Space):
    """Discrete space"""
    def __init__(self, n):
        super().__init__((), np.int64)
        self.n = n
        
    def sample(self):
        return np.random.randint(self.n)
        
    def contains(self, x):
        return isinstance(x, int) and 0 <= x < self.n

# Create spaces module
class spaces:
    Box = Box
    Discrete = Discrete

def make(env_id: str, **kwargs):
    """Create an environment"""
    if env_id == "TradingEnv-v0":
        from reinforcement_learning_agent import TradingEnvironment
        return TradingEnvironment()
    else:
        # Return a simple mock environment
        class MockEnv(Env):
            def __init__(self):
                super().__init__()
                self.observation_space = Box(low=-1, high=1, shape=(10,))
                self.action_space = Discrete(3)
                self.state = None
                
            def reset(self):
                self.state = self.observation_space.sample()
                return self.state
                
            def step(self, action):
                self.state = self.observation_space.sample()
                reward = np.random.randn()
                done = np.random.random() < 0.01
                info = {}
                return self.state, reward, done, info
                
        return MockEnv()

# Re-export common items
__all__ = ['Env', 'Space', 'Box', 'Discrete', 'make', 'spaces']
