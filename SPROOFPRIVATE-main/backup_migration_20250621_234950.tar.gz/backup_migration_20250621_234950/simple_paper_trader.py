
# Enhanced risk management recommended

#!/usr/bin/env python3
"""
Simple Alpaca Paper Trading Bot
Makes real paper trades using the Alpaca API
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import os
import time
import random
from datetime import datetime
from alpaca.trading.client import TradingClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class SimplePaperTrader:
    def __init__(self):
        # Initialize Alpaca API
        self.trading_client = TradingClient(os.getenv('ALPACA_PAPER_API_KEY')
        self.data_client = StockHistoricalDataClient(self.api_key, self.api_secret), os.getenv('ALPACA_PAPER_API_SECRET'), paper=True)
        
        # Trading parameters
        self.symbols = ['SPY', 'QQQ', 'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA']
        self.max_position_size = 0.05  # 5% of portfolio per position
        self.min_cash_reserve = 0.2    # Keep 20% cash
        
    def get_account_info(self):
        """Get current account information"""
        account = self.trading_client.get_account()
        return {}
            'portfolio_value': float(account.portfolio_value),
            'cash': float(account.cash),
            'buying_power': float(account.buying_power),
            'positions': len(self.trading_client.get_all_positions())
        }
    
    def get_current_positions(self):
        """Get list of current position symbols"""
        positions = self.trading_client.get_all_positions()
        return [pos.symbol for pos in positions]
    
    def get_tradeable_symbols(self):
        """Get symbols that can be traded right now"""
        tradeable = []
        current_positions = self.get_current_positions()
        
        for symbol in self.symbols:
            if symbol not in current_positions:
                try:
                    # Check if asset is tradeable
                    asset = self.trading_client.get_asset(symbol)
                    if asset.tradable and asset.status == 'active':
                        tradeable.append(symbol)
                except Exception as e:
                    print(f"⚠️ Error checking {symbol}: {e}")
        
        return tradeable
    
    def calculate_position_size(self, symbol, account_info):
        """Calculate how many shares to buy"""
        try:
            # Get current price
            quote = self.data_client.get_stock_latest_trade(symbol)
            price = quote.price
            
            # Calculate position size
            max_position_value = account_info['portfolio_value'] * self.max_position_size
            shares = int(max_position_value / price)
            
            # Ensure we have enough buying power
            if shares * price > account_info['buying_power'] * 0.9:
                shares = int((account_info['buying_power'] * 0.9) / price)
            
            return max(1, shares)  # At least 1 share
        except Exception as e:
            print(f"⚠️ Error calculating position size for {symbol}: {e}")
            return 0
    
    def place_buy_order(self, symbol, qty):
        """Place a market buy order"""
        try:
            order = self.trading_client.submit_order(order_data=MarketOrderRequest(symbol=symbol, qty=qty, side='buy', time_in_force='day'))
            )
            print(f"✅ BUY ORDER PLACED: {qty} shares of {symbol}")
            print(f"   Order ID: {order.id}")
            return order
        except Exception as e:
            print(f"❌ Error placing buy order for {symbol}: {e}")
            return None
    
    def place_sell_order(self, symbol, qty):
        """Place a market sell order"""
        try:
            order = self.trading_client.submit_order(order_data=MarketOrderRequest(symbol=symbol, qty=qty, side='sell', time_in_force='day'))
            )
            print(f"✅ SELL ORDER PLACED: {qty} shares of {symbol}")
            print(f"   Order ID: {order.id}")
            return order
        except Exception as e:
            print(f"❌ Error placing sell order for {symbol}: {e}")
            return None
    
    def check_exit_conditions(self, position):
        """Check if we should exit a position"""
        symbol = position.symbol
        entry_price = float(position.avg_entry_price)
        current_price = float(position.current_price)
        pnl_pct = float(position.unrealized_plpc)
        
        # Exit conditions
        take_profit = 0.02  # 2% profit
        stop_loss = -0.01   # 1% loss
        
        if pnl_pct >= take_profit:
            print(f"🎯 Take profit triggered for {symbol}: {pnl_pct:.2%}")
            return True
        elif pnl_pct <= stop_loss:
            print(f"🛑 Stop loss triggered for {symbol}: {pnl_pct:.2%}")
            return True
        
        return False
    
    def run_trading_cycle(self):
        """Run one trading cycle"""
        print(f"\n{'='*60}")
        print(f"🔄 Trading Cycle - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*60}")
        
        # Get account info
        account_info = self.get_account_info()
        print(f"💰 Portfolio: ${account_info['portfolio_value']:,.2f}")
        print(f"💵 Cash: ${account_info['cash']:,.2f}")
        print(f"📊 Positions: {account_info['positions']}")
        
        # Check existing positions for exits
        positions = self.trading_client.get_all_positions()
        for position in positions:
            if self.check_exit_conditions(position):
                self.place_sell_order(position.symbol, position.qty)
        
        # Look for new opportunities
        tradeable = self.get_tradeable_symbols()
        if tradeable and account_info['positions'] < 5:  # Max 5 positions
            # Pick a random symbol to trade
            symbol = random.choice(tradeable)
            qty = self.calculate_position_size(symbol, account_info)
            
            if qty > 0:
                print(f"\n🎯 Trading Opportunity: {symbol}")
                self.place_buy_order(symbol, qty)
        
        # Display current positions
        print("\n📈 Current Positions:")
        positions = self.trading_client.get_all_positions()
        if positions:
            for pos in positions:
                pnl = float(pos.unrealized_pl)
                pnl_pct = float(pos.unrealized_plpc) * 100
                print(f"  {pos.symbol}: {pos.qty} shares @ ${float(pos.avg_entry_price):.2f}")
                print(f"    Current: ${float(pos.current_price):.2f} | P&L: ${pnl:,.2f} ({pnl_pct:+.2f}%)")
        else:
            print("  No open positions")
    
    def run(self, cycles=None):
        """Run the trading bot"""
        print("🚀 Starting Simple Paper Trading Bot")
        print("Press Ctrl+C to stop\n")
        
        cycle_count = 0
        try:
            while True:
                self.run_trading_cycle()
                
                cycle_count += 1
                if cycles and cycle_count >= cycles:
                    break
                
                # Wait before next cycle
                wait_time = 60  # 1 minute between cycles
                print(f"\n⏳ Waiting {wait_time} seconds before next cycle...")
                time.sleep(wait_time)
                
        except KeyboardInterrupt:
            print("\n\n👋 Trading bot stopped")
        except Exception as e:
            print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    trader = SimplePaperTrader()
    trader.run(cycles=5)  # Run 5 cycles for demo