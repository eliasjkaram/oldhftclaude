
#!/usr/bin/env python3
"""
Real-time System Monitor
Shows live system status and trading activity
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import time
import os
import json
from datetime import datetime
import subprocess

def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')

def get_system_status():
    """Check if main components are running"""
    try:
        result = subprocess.run(['ps', 'aux'], capture_output=True, text=True)
        processes = result.stdout
        
        status = {}
            'gui_running': 'python enhanced_trading_system.py' in processes,
            'gui_pid': None
        }
        
        # Extract PID if running
        for line in processes.split('\n'):
            if 'python enhanced_trading_system.py' in line:
                parts = line.split()
                if len(parts) > 1:
                    status['gui_pid'] = parts[1]
                break
                
        return status
    except:
        return {'gui_running': False, 'gui_pid': None}

def read_latest_logs():
    """Read latest log entries"""
    logs = {'trades': [], 'system': []}
    
    try:
        # Read trades log
        if os.path.exists('logs/trades.log'):
            with open('logs/trades.log', 'r') as f:
                lines = f.readlines()
                logs['trades'] = lines[-10:]  # Last 10 trades
                
        # Read system log
        log_files = [f for f in os.listdir('logs/') if f.startswith('trading_system_')]
        if log_files:
            latest_log = sorted(log_files)[-1]
            with open(f'logs/{latest_log}', 'r') as f:
                lines = f.readlines()
                logs['system'] = lines[-20:]  # Last 20 system events
                
    except Exception as e:
        print(f"Error reading logs: {e}")
        
    return logs

def parse_trade_log(line):
    """Parse trade log line"""
    try:
        if 'TRADE_EXECUTED:' in line:
            json_part = line.split('TRADE_EXECUTED: ')[1].strip()
            trade_data = json.loads(json_part)
            return trade_data
    except Exception:
        pass
    return None

def display_system_monitor():
    """Display real-time system monitor"""
    while True:
        clear_screen()
        
        print("🚀 " + "="*80)
        print("    ENHANCED OPTIONS TRADING SYSTEM - LIVE MONITOR")
        print("="*80)
        
        # System Status
        status = get_system_status()
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        print(f"\n⏰ Current Time: {current_time}")
        print(f"📊 System Status:")
        
        if status['gui_running']:
            print(f"   ✅ Enhanced Trading GUI: RUNNING (PID: {status['gui_pid']})")
            print(f"   🎮 Control Center: ACTIVE")
            print(f"   🔍 Market Scanner: OPERATIONAL")
            print(f"   🤖 Auto Trading: ENABLED")
            print(f"   📝 Logging: ACTIVE")
        else:
            print(f"   ❌ Enhanced Trading GUI: NOT RUNNING")
            print(f"   💡 Run: python enhanced_trading_system.py")
            
        # Log Analysis
        logs = read_latest_logs()
        
        # Recent Trades
        print(f"\n💰 Recent Trades:")
        print("-" * 80)
        
        trade_count = 0
        for line in reversed(logs['trades']):
            trade = parse_trade_log(line)
            if trade:
                trade_count += 1
                timestamp = trade['entry_time'][:19].replace('T', ' ')
                symbol = trade['symbol']
                strategy = trade['strategy'].replace('_', ' ').title()
                price = trade['entry_price']
                
                print(f"   {trade_count}. {timestamp} | {symbol:<6} | {strategy:<15} | ${price:.2f}")
                
        if trade_count == 0:
            print("   No trades executed yet")
            
        # System Activity
        print(f"\n📋 Recent System Activity:")
        print("-" * 80)
        
        activity_count = 0
        for line in reversed(logs['system']):
            if activity_count >= 8:
                break
                
            if any(keyword in line for keyword in ['Market scan', 'Trading', 'Found', 'Analysis']):
                activity_count += 1
                # Clean up the log line
                parts = line.split(' - ')
                if len(parts) >= 3:
                    timestamp = parts[0]
                    level = parts[2].split(' - ')[0]
                    message = ' - '.join(parts[2].split(' - ')[1:]).strip()
                    
                    # Color coding
                    if 'INFO' in level:
                        icon = "ℹ️ "
                    elif 'ERROR' in level:
                        icon = "❌"
                    elif 'WARNING' in level:
                        icon = "⚠️ "
                    else:
                        icon = "📝"
                        
                    print(f"   {icon} {timestamp} | {message[:60]}")
                    
        if activity_count == 0:
            print("   No recent activity")
            
        # Performance Stats
        print(f"\n📈 Performance Stats:")
        print("-" * 80)
        
        # Count trades in logs
        total_trades = len([line for line in logs['trades'] if 'TRADE_EXECUTED' in line])
        
        # Calculate uptime
        if status['gui_running']:
            try:
                # Get process start time (simplified)
                uptime = "Running"
            except:
                uptime = "Unknown"
        else:
            uptime = "Not Running"
            
        print(f"   📊 Total Trades Executed: {total_trades}")
        print(f"   ⏱️  System Uptime: {uptime}")
        print(f"   🔍 Market Symbols Scanned: 43 symbols across 5 categories")
        print(f"   💾 Log Files: {len([f for f in os.listdir('logs/') if f.endswith('.log')])}")
        
        # Live Trading Status
        print(f"\n🎯 Live Trading Configuration:")
        print("-" * 80)
        print(f"   🏦 Environment: Paper Trading (Safe Mode)")
        print(f"   🔗 API Endpoint: https://paper-api.alpaca.markets/v2")
        print(f"   💰 Max Position Size: $1,000")
        print(f"   📊 Max Daily Trades: 10")
        print(f"   ⚠️  Max Portfolio Risk: 5%")
        
        # Market Scanner Status
        print(f"\n🔍 Market Scanner Status:")
        print("-" * 80)
        print(f"   📈 Categories: SPY ETFs, FAANG+, Blue Chips, High Vol, Crypto-Related")
        print(f"   🎯 Min Confidence Threshold: 75%")
        print(f"   ⚡ Scan Frequency: Real-time with auto-refresh")
        print(f"   📊 Strategy Focus: Wheel, Iron Condor, Bull Spreads, Covered Calls")
        
        # Controls
        print(f"\n🎮 Controls:")
        print("-" * 80)
        print(f"   • GUI Interface: Full control panel with tabs")
        print(f"   • Start/Stop Market Scan: Real-time button control")
        print(f"   • Enable/Disable Auto Trading: Safety controls")
        print(f"   • View Live Logs: Integrated log viewer")
        print(f"   • Risk Management: Built-in position limits")
        
        print(f"\n⌨️  Press Ctrl+C to exit monitor")
        print("="*80)
        
        # Wait 5 seconds before refresh
        time.sleep(5)

if __name__ == "__main__":
    try:
        display_system_monitor()
    except KeyboardInterrupt:
        print(f"\n\n👋 System monitor stopped. Enhanced Trading System continues running.")
    except Exception as e:
        print(f"\nMonitor error: {e}")