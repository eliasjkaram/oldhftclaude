#!/usr/bin/env python3
"""
Run TLT Covered Call Backtest with Different IV Prediction Algorithms
Uses the comprehensive backtest system to test various IV anomaly detection methods
"""

import asyncio
import sys
sys.path.append('/home/harry/alpaca-mcp')

from comprehensive_backtest_system import ComprehensiveBacktester
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('TLT_IV_Backtest')

class TLTIVBacktester(ComprehensiveBacktester):
    """Extended backtester focused on TLT covered calls with IV algorithms"""
    
    def __init__(self):
        # Last 6 months
        end_date = datetime.now()
        start_date = end_date - timedelta(days=180)
        
        super().__init__(
            start_date=start_date.strftime("%Y-%m-%d"),
            end_date=end_date.strftime("%Y-%m-%d")
        )
        
        # Focus only on TLT
        self.test_symbols = ['TLT']
        
        # IV-specific algorithms for covered call timing
        self.iv_algorithms = [
            "Local_Peak_IV",       # Localized IV peaks (5-day window)
            "Regional_Peak_IV",    # Regional IV peaks (20-day window)  
            "Strike_IV_Anomaly",   # Strike price IV anomalies
            "Expiry_IV_Anomaly",   # Expiration date IV anomalies
            "IV_Term_Structure",   # Term structure anomalies
            "IV_Smile_Anomaly",    # Volatility smile distortions
            "IV_Mean_Reversion",   # Mean reversion opportunities
            "IV_Momentum",         # IV momentum signals
            "IV_Percentile_75",    # Traditional 75th percentile
            "Combined_IV_Signal"   # Multiple signal combination
        ]
        
    def _generate_algorithm_signal(self, algorithm: str, data):
        """Override to implement IV-specific signals for TLT"""
        
        # Extract current data
        try:
            current = data.iloc[-1]
            
            # Calculate IV metrics
            hv_20 = data['Returns'].rolling(20).std().iloc[-1] * 15.87  # Annualized
            hv_percentile = (data['Returns'].rolling(20).std().rank(pct=True).iloc[-1]) * 100
            
            if algorithm == "Local_Peak_IV":
                # Detect local peaks in volatility
                hv_series = data['Returns'].rolling(20).std()
                if len(hv_series) > 5:
                    is_peak = (hv_series.iloc[-1] > hv_series.iloc[-2] and 
                              hv_series.iloc[-1] > hv_series.iloc[-3] and
                              hv_series.iloc[-1] > hv_series.rolling(5).mean().iloc[-1] * 1.1)
                    return 0.9 if is_peak else 0.1
                    
            elif algorithm == "Regional_Peak_IV":
                # Detect regional peaks (20-day high)
                hv_series = data['Returns'].rolling(20).std()
                if len(hv_series) > 20:
                    is_regional_peak = hv_series.iloc[-1] == hv_series.rolling(20).max().iloc[-1]
                    return 0.85 if is_regional_peak else 0.15
                    
            elif algorithm == "Strike_IV_Anomaly":
                # Simulate strike price anomalies based on price movement
                price_change_5d = (current['Close'] - data['Close'].shift(5).iloc[-1]) / data['Close'].shift(5).iloc[-1]
                # Anomaly when price moves significantly
                return 0.8 if abs(price_change_5d) > 0.03 else 0.2
                
            elif algorithm == "Expiry_IV_Anomaly":
                # Simulate term structure anomalies
                if 'Volatility' in current and not pd.isna(current['Volatility']):
                    # High vol = potential anomaly
                    return 0.8 if current['Volatility'] > 0.20 else 0.3
                    
            elif algorithm == "IV_Term_Structure":
                # Compare short vs long term volatility
                hv_10 = data['Returns'].rolling(10).std().iloc[-1]
                hv_30 = data['Returns'].rolling(30).std().iloc[-1]
                if pd.notna(hv_10) and pd.notna(hv_30) and hv_30 > 0:
                    ratio = hv_10 / hv_30
                    return 0.8 if ratio > 1.2 else 0.2
                    
            elif algorithm == "IV_Smile_Anomaly":
                # Simulate smile based on moneyness
                rsi = current.get('RSI', 50)
                # Extreme RSI = potential smile anomaly
                return 0.8 if rsi > 70 or rsi < 30 else 0.3
                
            elif algorithm == "IV_Mean_Reversion":
                # Check if IV is elevated vs mean
                if pd.notna(hv_20):
                    hv_mean = data['Returns'].rolling(60).std().mean() * 15.87
                    if pd.notna(hv_mean) and hv_mean > 0:
                        z_score = (hv_20 - hv_mean) / (hv_mean * 0.2)  # Approximate std
                        return 0.9 if z_score > 2 else 0.1
                        
            elif algorithm == "IV_Momentum":
                # IV momentum signal
                hv_series = data['Returns'].rolling(20).std()
                if len(hv_series) > 5:
                    momentum = (hv_series.iloc[-1] - hv_series.iloc[-5]) / hv_series.iloc[-5]
                    return 0.8 if momentum > 0.15 else 0.2
                    
            elif algorithm == "IV_Percentile_75":
                # Traditional percentile approach  
                return 0.9 if hv_percentile >= 75 else 0.1
                
            elif algorithm == "Combined_IV_Signal":
                # Combine multiple signals
                signals = []
                
                # Percentile signal
                if hv_percentile >= 70:
                    signals.append(1)
                    
                # Momentum signal
                hv_series = data['Returns'].rolling(20).std()
                if len(hv_series) > 5:
                    momentum = (hv_series.iloc[-1] - hv_series.iloc[-5]) / hv_series.iloc[-5]
                    if momentum > 0.05:
                        signals.append(1)
                        
                # Mean reversion signal
                if pd.notna(hv_20):
                    hv_mean = data['Returns'].rolling(60).std().mean() * 15.87
                    if pd.notna(hv_mean) and hv_mean > 0:
                        z_score = (hv_20 - hv_mean) / (hv_mean * 0.2)
                        if z_score > 1.5:
                            signals.append(1)
                            
                # Require at least 2 signals
                return 0.85 if sum(signals) >= 2 else 0.15
                
        except Exception as e:
            logger.debug(f"Error in {algorithm}: {e}")
            
        return 0.5  # Neutral if error
        
    async def run_tlt_iv_backtest(self):
        """Run focused TLT covered call backtest with IV algorithms"""
        
        logger.info("="*80)
        logger.info("🎯 TLT COVERED CALL BACKTEST - IV PREDICTION ALGORITHMS")
        logger.info("="*80)
        logger.info(f"Period: {self.start_date} to {self.end_date}")
        logger.info(f"Testing {len(self.iv_algorithms)} IV algorithms")
        logger.info("="*80)
        
        # Get TLT data
        tlt_data = await self.get_historical_data('TLT', period='6mo')
        
        if tlt_data.empty:
            logger.error("Failed to get TLT data")
            return {}
            
        results = {}
        
        # Test each IV algorithm
        for iv_algo in self.iv_algorithms:
            logger.info(f"\nTesting {iv_algo}...")
            
            # Temporarily set algorithm
            original_algos = self.algorithms
            self.algorithms = [iv_algo]
            
            # Run test
            performance = await self._test_algorithm(iv_algo, 'TLT', tlt_data)
            
            # Calculate covered call specific metrics
            trades = performance.get('trades', 0)
            total_return = performance.get('total_return', 0)
            
            # Estimate premium income (simplified)
            avg_premium_pct = 0.015  # 1.5% per trade
            premium_income = trades * avg_premium_pct * 100000  # On $100k position
            
            results[iv_algo] = {
                'total_return': total_return * 100,  # Percentage
                'annualized_return': total_return * 100 * (365/180),  # 6-month to annual
                'trades': trades,
                'win_rate': performance.get('win_rate', 0) * 100,
                'sharpe_ratio': performance.get('sharpe_ratio', 0),
                'max_drawdown': performance.get('max_drawdown', 0) * 100,
                'est_premium_income': premium_income,
                'trades_per_month': trades / 6
            }
            
            # Restore algorithms
            self.algorithms = original_algos
            
        # Display results
        logger.info("\n" + "="*80)
        logger.info("📊 TLT COVERED CALL RESULTS - IV ALGORITHM COMPARISON")
        logger.info("="*80)
        
        # Sort by total return
        sorted_results = sorted(results.items(), key=lambda x: x[1]['total_return'], reverse=True)
        
        logger.info(f"\n{'Algorithm':<20} {'Return':<10} {'Annual':<10} {'Trades':<8} {'Win%':<8} {'Sharpe':<8} {'MaxDD':<8}")
        logger.info("-" * 80)
        
        for algo, metrics in sorted_results:
            logger.info(
                f"{algo:<20} "
                f"{metrics['total_return']:>7.1f}% "
                f"{metrics['annualized_return']:>7.1f}% "
                f"{metrics['trades']:>6} "
                f"{metrics['win_rate']:>6.1f}% "
                f"{metrics['sharpe_ratio']:>7.2f} "
                f"{metrics['max_drawdown']:>6.1f}%"
            )
            
        # Best algorithm
        best_algo = sorted_results[0]
        logger.info("\n" + "="*80)
        logger.info(f"🏆 BEST IV ALGORITHM: {best_algo[0]}")
        logger.info(f"   6-Month Return: {best_algo[1]['total_return']:.1f}%")
        logger.info(f"   Annualized Return: {best_algo[1]['annualized_return']:.1f}%")
        logger.info(f"   Number of Trades: {best_algo[1]['trades']}")
        logger.info(f"   Trades per Month: {best_algo[1]['trades_per_month']:.1f}")
        logger.info(f"   Estimated Premium Income: ${best_algo[1]['est_premium_income']:,.0f}")
        logger.info("="*80)
        
        return results

async def main():
    """Run TLT IV algorithm comparison"""
    backtester = TLTIVBacktester()
    results = await backtester.run_tlt_iv_backtest()
    return results

if __name__ == "__main__":
    asyncio.run(main())