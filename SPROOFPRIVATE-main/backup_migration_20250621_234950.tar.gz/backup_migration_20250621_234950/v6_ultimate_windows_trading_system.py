#!/usr/bin/env python3
"""
v6.0 Ultimate Windows Trading System - Beautiful Modern GUI
===========================================================
Features:
- Beautiful dark theme with neon accents
- Live market data with real-time updates
- Smooth animations and transitions
- Professional trading interface
- Windows-optimized design
- All v5 features enhanced
"""

import tkinter as tk
from tkinter import ttk, messagebox, font
import customtkinter as ctk
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import requests
import yfinance as yf
from threading import Thread, Event
import time
import os
import pickle
import asyncio
from typing import Dict, List, Optional, Any, Tuple
import logging
import sys
import queue
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.animation as animation
from collections import deque
import random

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError

from universal_market_data import get_current_market_data, validate_price



# Configure CustomTkinter
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Setup logging
logging.basicConfig()
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[]
        logging.FileHandler('v6_windows_trading.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Import enhanced price provider
try:
    from enhanced_price_provider import EnhancedPriceProvider, PriceData
except ImportError:
    logger.warning("Enhanced price provider not found, using fallback")
    class PriceData:
        def __init__(self, symbol, price, source="", timestamp=None, bid=0, ask=0, 
                     volume=0, confidence=0, is_market_hours=True):
            self.symbol = symbol
            self.price = price
            self.source = source
            self.timestamp = timestamp or datetime.now()
            self.bid = bid
            self.ask = ask
            self.volume = volume
            self.confidence = confidence
            self.is_market_hours = is_market_hours

# ============================================================================
# MODERN COLOR SCHEME
# ============================================================================
class ColorScheme:
    # Dark theme base colors
    BG_PRIMARY = "#0a0e27"      # Deep blue-black
    BG_SECONDARY = "#151932"    # Slightly lighter
    BG_TERTIARY = "#1f2341"     # Card background
    
    # Neon accent colors
    NEON_GREEN = "#00ff41"      # Profit/Buy
    NEON_RED = "#ff0040"        # Loss/Sell
    NEON_BLUE = "#00d4ff"       # Primary accent
    NEON_PURPLE = "#bd00ff"     # Secondary accent
    NEON_YELLOW = "#ffea00"     # Warning/Highlight
    
    # Text colors
    TEXT_PRIMARY = "#ffffff"    # White
    TEXT_SECONDARY = "#b8bcc8"  # Light gray
    TEXT_TERTIARY = "#6c7293"   # Dark gray
    
    # Chart colors
    CHART_LINE = "#00d4ff"
    CHART_FILL = "#00d4ff20"
    CHART_GRID = "#2a2e4a"
    
    # Status colors
    SUCCESS = "#00ff41"
    WARNING = "#ffea00"
    ERROR = "#ff0040"
    INFO = "#00d4ff"

# ============================================================================
# LIVE MARKET DATA PROVIDER
# ============================================================================
class LiveMarketDataProvider:
    """Enhanced live market data provider with multiple sources"""
    
    def __init__(self):
        self.cache = {}
        self.last_update = {}
        self.price_history = {}  # Store price history for charts
        self.update_callbacks = []
        self.is_updating = False
        self.update_thread = None
        self.stop_event = Event()
        
        # Initialize enhanced price provider if available
        try:
            config = {}
                'cache_ttl_seconds': 30,
                'max_price_deviation': 0.05,
                'alpaca_api_key': os.getenv('ALPACA_API_KEY', ''),
                'alpaca_api_secret': os.getenv('ALPACA_API_SECRET', '')
            }
            self.enhanced_provider = EnhancedPriceProvider(config)
            logger.info("Enhanced price provider initialized")
        except Exception:
            self.enhanced_provider = None
            logger.warning("Using fallback price provider")
        
        # Start update thread
        self.start_updates()
    
    def start_updates(self):
        """Start background price updates"""
        if not self.is_updating:
            self.is_updating = True
            self.stop_event.clear()
            self.update_thread = Thread(target=self._update_loop, daemon=True)
            self.update_thread.start()
            logger.info("Started live market data updates")
    
    def stop_updates(self):
        """Stop background price updates"""
        self.is_updating = False
        self.stop_event.set()
        if self.update_thread:
            self.update_thread.join(timeout=5)
        logger.info("Stopped live market data updates")
    
    def _update_loop(self):
        """Background update loop"""
        while self.is_updating and not self.stop_event.is_set():
            try:
                # Update watchlist symbols
                watchlist = list(self.cache.keys()
                if watchlist:
                    for symbol in watchlist:
                        if self.stop_event.is_set():
                            break
                        self._update_symbol_price(symbol)
                    
                    # Notify callbacks
                    for callback in self.update_callbacks:
                        try:
                            callback()
                        except Exception as e:
                            logger.error(f"Callback error: {e}", exc_info=True)
                
                # Wait before next update
                self.stop_event.wait(2)  # Update every 2 seconds
                
            except Exception as e:
                logger.error(f"Update loop error: {e}", exc_info=True)
                self.stop_event.wait(5)
    
    def _update_symbol_price(self, symbol: str):
        """Update price for a single symbol"""
        try:
            # Try enhanced provider first
            if self.enhanced_provider:
                price_data = self.enhanced_provider.get_price(symbol)
                if price_data:
                    self._store_price_data(symbol, price_data)
                    return
            
            # Fallback to yfinance
            price_data = self._get_yfinance_price(symbol)
            if price_data:
                self._store_price_data(symbol, price_data)
            
        except Exception as e:
            logger.error(f"Error updating {symbol}: {e}", exc_info=True)
    
    def _get_yfinance_price(self, symbol: str) -> Optional[PriceData]:
        """Get price from yfinance"""
        try:
            ticker = yf.Ticker(symbol)
            
            # Get current data
            info = ticker.info
            fast_info = ticker.fast_info
            
            # Extract price
            price = None
            if hasattr(fast_info, 'last_price') and fast_info.last_price:
                price = float(fast_info.last_price)
            elif 'currentPrice' in info:
                price = float(info['currentPrice'])
            elif 'regularMarketPrice' in info:
                price = float(info['regularMarketPrice'])
            
            if price and price > 0:
                # Get additional data
                bid = info.get('bid', price)
                ask = info.get('ask', price)
                volume = info.get('volume', 0)
                
                # Check market hours
                market_open = info.get('marketState', 'REGULAR') == 'REGULAR'
                
                return PriceData()
                    symbol=symbol,
                    price=price,
                    source='Yahoo Finance',
                    timestamp=datetime.now(),
                    bid=bid,
                    ask=ask,
                    volume=volume,
                    confidence=0.85,
                    is_market_hours=market_open
                )
                
        except Exception as e:
            logger.warning(f"YFinance error for {symbol}: {e}")
        
        return None
    
    def _store_price_data(self, symbol: str, price_data: PriceData):
        """Store price data and update history"""
        # Update cache
        old_price = self.cache.get(symbol, {}).get('price', price_data.price)
        
        self.cache[symbol] = {}
            'price': price_data.price,
            'bid': price_data.bid,
            'ask': price_data.ask,
            'volume': price_data.volume,
            'source': price_data.source,
            'confidence': price_data.confidence,
            'is_market_hours': price_data.is_market_hours,
            'timestamp': price_data.timestamp,
            'change': price_data.price - old_price,
            'change_pct': ((price_data.price - old_price) / old_price * 100) if old_price else 0
        }
        
        self.last_update[symbol] = datetime.now()
        
        # Update price history for charts
        if symbol not in self.price_history:
            self.price_history[symbol] = deque(maxlen=100)
        
        self.price_history[symbol].append({)
            'time': price_data.timestamp,
            'price': price_data.price,
            'volume': price_data.volume
        })
    
    def get_price(self, symbol: str) -> Dict[str, Any]:
        """Get current price data for symbol"""
        # Add to watchlist if not present
        if symbol not in self.cache:
            self._update_symbol_price(symbol)
        
        return self.cache.get(symbol, {)
            'price': 0,
            'bid': 0,
            'ask': 0,
            'volume': 0,
            'source': 'N/A',
            'confidence': 0,
            'is_market_hours': False,
            'timestamp': datetime.now(),
            'change': 0,
            'change_pct': 0
        })
    
    def get_price_history(self, symbol: str) -> List[Dict]:
        """Get price history for charts"""
        return list(self.price_history.get(symbol, [])
    
    def add_update_callback(self, callback):
        """Add callback for price updates"""
        self.update_callbacks.append(callback)
    
    def remove_update_callback(self, callback):
        """Remove update callback"""
        if callback in self.update_callbacks:
            self.update_callbacks.remove(callback)

# ============================================================================
# ENHANCED ALGORITHM CONNECTOR
# ============================================================================
class V6AlgorithmConnector:
    """Enhanced algorithm connector with visual indicators"""
    
    def __init__(self):
        self.algorithm_status = {}
        self.performance_metrics = {}
        self.algorithms = self._initialize_algorithms()
        logger.info(f"v6: Initialized {len(self.algorithms)} algorithms")
    
    def _initialize_algorithms(self) -> Dict[str, Dict]:
        """Initialize algorithms with metadata"""
        algorithms = {}
            # Momentum algorithms
            'momentum_trader': {'type': 'momentum', 'icon': '📈', 'color': ColorScheme.NEON_GREEN},
            'trend_follower': {'type': 'momentum', 'icon': '📊', 'color': ColorScheme.NEON_GREEN},
            'breakout_detector': {'type': 'momentum', 'icon': '🚀', 'color': ColorScheme.NEON_GREEN},
            'momentum_reversal': {'type': 'momentum', 'icon': '🔄', 'color': ColorScheme.NEON_GREEN},
            
            # Mean reversion algorithms
            'mean_reversion_bot': {'type': 'reversion', 'icon': '⚖️', 'color': ColorScheme.NEON_BLUE},
            'bollinger_bands': {'type': 'reversion', 'icon': '📉', 'color': ColorScheme.NEON_BLUE},
            'rsi_reversal': {'type': 'reversion', 'icon': '🔁', 'color': ColorScheme.NEON_BLUE},
            'support_resistance': {'type': 'reversion', 'icon': '🛡️', 'color': ColorScheme.NEON_BLUE},
            
            # Options algorithms
            'options_arbitrage': {'type': 'options', 'icon': '🎯', 'color': ColorScheme.NEON_PURPLE},
            'volatility_harvester': {'type': 'options', 'icon': '🌪️', 'color': ColorScheme.NEON_PURPLE},
            'gamma_scalper': {'type': 'options', 'icon': '📐', 'color': ColorScheme.NEON_PURPLE},
            'theta_collector': {'type': 'options', 'icon': '⏰', 'color': ColorScheme.NEON_PURPLE},
            'delta_neutral': {'type': 'options', 'icon': '⚡', 'color': ColorScheme.NEON_PURPLE},
            'vega_trader': {'type': 'options', 'icon': '📊', 'color': ColorScheme.NEON_PURPLE},
            'iron_condor_bot': {'type': 'options', 'icon': '🦅', 'color': ColorScheme.NEON_PURPLE},
            'straddle_strategy': {'type': 'options', 'icon': '🎪', 'color': ColorScheme.NEON_PURPLE},
            
            # Statistical algorithms
            'pairs_trader': {'type': 'statistical', 'icon': '👥', 'color': ColorScheme.NEON_YELLOW},
            'statistical_arbitrage': {'type': 'statistical', 'icon': '📊', 'color': ColorScheme.NEON_YELLOW},
            'correlation_trader': {'type': 'statistical', 'icon': '🔗', 'color': ColorScheme.NEON_YELLOW},
            'cointegration_bot': {'type': 'statistical', 'icon': '📈', 'color': ColorScheme.NEON_YELLOW},
            
            # Market making algorithms
            'market_maker': {'type': 'market_making', 'icon': '💹', 'color': ColorScheme.NEON_RED},
            'bid_ask_spreader': {'type': 'market_making', 'icon': '💰', 'color': ColorScheme.NEON_RED},
            'liquidity_provider': {'type': 'market_making', 'icon': '💧', 'color': ColorScheme.NEON_RED},
            'order_flow_trader': {'type': 'market_making', 'icon': '🌊', 'color': ColorScheme.NEON_RED},
            
            # AI/ML algorithms
            'neural_network_predictor': {'type': 'ai_ml', 'icon': '🧠', 'color': ColorScheme.INFO},
            'random_forest_trader': {'type': 'ai_ml', 'icon': '🌲', 'color': ColorScheme.INFO},
            'svm_classifier': {'type': 'ai_ml', 'icon': '🤖', 'color': ColorScheme.INFO},
            'lstm_predictor': {'type': 'ai_ml', 'icon': '🔮', 'color': ColorScheme.INFO},
            
            # Pattern recognition
            'pattern_recognizer': {'type': 'pattern', 'icon': '🎨', 'color': ColorScheme.SUCCESS},
            'harmonic_patterns': {'type': 'pattern', 'icon': '🎵', 'color': ColorScheme.SUCCESS},
            'elliott_wave': {'type': 'pattern', 'icon': '🌊', 'color': ColorScheme.SUCCESS},
            'fibonacci_trader': {'type': 'pattern', 'icon': '🐚', 'color': ColorScheme.SUCCESS},
            
            # Volume analysis
            'volume_analyzer': {'type': 'volume', 'icon': '📊', 'color': ColorScheme.WARNING},
            'dark_pool_detector': {'type': 'volume', 'icon': '🕵️', 'color': ColorScheme.WARNING},
            'unusual_activity_scanner': {'type': 'volume', 'icon': '🚨', 'color': ColorScheme.WARNING},
            'options_flow_analyzer': {'type': 'volume', 'icon': '💸', 'color': ColorScheme.WARNING},
            
            # Event-driven
            'earnings_player': {'type': 'event', 'icon': '💰', 'color': ColorScheme.ERROR},
            'dividend_capturer': {'type': 'event', 'icon': '💵', 'color': ColorScheme.ERROR},
            'merger_arbitrage': {'type': 'event', 'icon': '🤝', 'color': ColorScheme.ERROR},
            'news_sentiment_trader': {'type': 'event', 'icon': '📰', 'color': ColorScheme.ERROR},
            
            # Sector/index
            'sector_rotator': {'type': 'sector', 'icon': '🔄', 'color': ColorScheme.NEON_GREEN},
            'index_rebalancer': {'type': 'sector', 'icon': '⚖️', 'color': ColorScheme.NEON_GREEN},
            'etf_arbitrage': {'type': 'sector', 'icon': '📦', 'color': ColorScheme.NEON_GREEN}
        }
        
        # Initialize status
        for algo_name in algorithms:
            self.algorithm_status[algo_name] = {}
                'active': True,
                'last_signal': 'neutral',
                'confidence': 0.5,
                'performance': 0.0
            }
        
        return algorithms
    
    def analyze_with_algorithms(self, symbol: str, market_data: Dict, 
                               user_bias: Dict) -> Dict[str, Any]:
        """Enhanced algorithm analysis with visual feedback"""
        logger.info(f"v6: Running {len(self.algorithms)} algorithms for {symbol}")
        
        results = {}
            'symbol': symbol,
            'timestamp': datetime.now(),
            'algorithms_analyzed': 0,
            'consensus_direction': 'neutral',
            'average_confidence': 0.0,
            'predictions': {},
            'algorithm_breakdown': {}
                'bullish': [],
                'bearish': [],
                'neutral': []
            },
            'type_breakdown': {},
            'top_strategies': []
        }
        
        # Run each algorithm
        predictions = {}
        for algo_name, algo_info in self.algorithms.items():
            if self.algorithm_status[algo_name]['active']:
                try:
                    prediction = self._simulate_algorithm(algo_name, symbol, market_data, user_bias)
                    predictions[algo_name] = prediction
                    
                    # Update status
                    self.algorithm_status[algo_name]['last_signal'] = prediction['direction']
                    self.algorithm_status[algo_name]['confidence'] = prediction['confidence']
                    
                    # Categorize by direction
                    results['algorithm_breakdown'][prediction['direction']].append({)
                        'name': algo_name,
                        'confidence': prediction['confidence'],
                        'icon': algo_info['icon'],
                        'color': algo_info['color'],
                        'type': algo_info['type']
                    })
                    
                    # Track by type
                    algo_type = algo_info['type']
                    if algo_type not in results['type_breakdown']:
                        results['type_breakdown'][algo_type] = {}
                            'bullish': 0, 'bearish': 0, 'neutral': 0
                        }
                    results['type_breakdown'][algo_type][prediction['direction']] += 1
                    
                    results['algorithms_analyzed'] += 1
                    
                except Exception as e:
                    logger.error(f"Algorithm {algo_name} error: {e}", exc_info=True)
        
        # Calculate consensus
        if predictions:
            confidences = [p['confidence'] for p in predictions.values()]
            results['average_confidence'] = np.mean(confidences)
            
            # Count directions
            bullish = len(results['algorithm_breakdown']['bullish'])
            bearish = len(results['algorithm_breakdown']['bearish'])
            total = results['algorithms_analyzed']
            
            if bullish > total * 0.6:
                results['consensus_direction'] = 'bullish'
            elif bearish > total * 0.6:
                results['consensus_direction'] = 'bearish'
            else:
                results['consensus_direction'] = 'neutral'
        
        results['predictions'] = predictions
        
        # Generate strategies
        results['top_strategies'] = self._generate_strategies()
            symbol, market_data, results['consensus_direction'], 
            results['average_confidence'], user_bias
        )
        
        return results
    
    def _simulate_algorithm(self, algo_name: str, symbol: str, 
                          market_data: Dict, user_bias: Dict) -> Dict:
        """Simulate algorithm prediction"""
        # Base prediction on algorithm type and market data
        algo_type = self.algorithms[algo_name]['type']
        
        # Simulate based on type
        if algo_type == 'momentum':
            signal = np.random.normal(0.1, 0.3)
        elif algo_type == 'reversion':
            signal = np.random.normal(-0.1, 0.3)
        elif algo_type == 'options':
            signal = np.random.normal(0, 0.4)
        else:
            signal = np.random.normal(0, 0.2)
        
        # Add market influence
        if market_data.get('change_pct', 0) > 1:
            signal += 0.2
        elif market_data.get('change_pct', 0) < -1:
            signal -= 0.2
        
        # Apply user bias
        if user_bias['direction'] == 'bullish':
            signal += user_bias['confidence'] * 0.2
        elif user_bias['direction'] == 'bearish':
            signal -= user_bias['confidence'] * 0.2
        
        # Convert to direction
        if signal > 0.2:
            direction = 'bullish'
            confidence = min(0.95, 0.5 + abs(signal) * 0.3)
        elif signal < -0.2:
            direction = 'bearish'
            confidence = min(0.95, 0.5 + abs(signal) * 0.3)
        else:
            direction = 'neutral'
            confidence = 0.5 + abs(signal) * 0.2
        
        return {}
            'algorithm': algo_name,
            'direction': direction,
            'confidence': confidence,
            'signal_strength': signal,
            'type': algo_type
        }
    
    def _generate_strategies(self, symbol: str, market_data: Dict,
                           consensus: str, confidence: float, 
                           user_bias: Dict) -> List[Dict]:
        """Generate trading strategies"""
        strategies = []
        current_price = market_data.get('price', 100)
        
        if consensus == 'bullish':
            strategies.append({)
                'name': 'Long Stock',
                'type': 'stock',
                'entry': current_price,
                'target': current_price * 1.05,
                'stop_loss': current_price * 0.98,
                'confidence': confidence,
                'risk_reward': 2.5
            })
            
            strategies.append({)
                'name': 'Bull Call Spread',
                'type': 'options',
                'legs': []
                    {'action': 'BUY', 'type': 'CALL', 'strike': current_price * 1.02},
                    {'action': 'SELL', 'type': 'CALL', 'strike': current_price * 1.05}
                ],
                'max_profit': current_price * 0.03,
                'max_loss': current_price * 0.01,
                'confidence': confidence * 0.9
            })
            
        elif consensus == 'bearish':
            strategies.append({)
                'name': 'Short Stock',
                'type': 'stock',
                'entry': current_price,
                'target': current_price * 0.95,
                'stop_loss': current_price * 1.02,
                'confidence': confidence,
                'risk_reward': 2.5
            })
            
            strategies.append({)
                'name': 'Bear Put Spread',
                'type': 'options',
                'legs': []
                    {'action': 'BUY', 'type': 'PUT', 'strike': current_price * 0.98},
                    {'action': 'SELL', 'type': 'PUT', 'strike': current_price * 0.95}
                ],
                'max_profit': current_price * 0.03,
                'max_loss': current_price * 0.01,
                'confidence': confidence * 0.9
            })
        
        else:
            strategies.append({)
                'name': 'Iron Condor',
                'type': 'options',
                'legs': []
                    {'action': 'SELL', 'type': 'PUT', 'strike': current_price * 0.95},
                    {'action': 'BUY', 'type': 'PUT', 'strike': current_price * 0.90},
                    {'action': 'SELL', 'type': 'CALL', 'strike': current_price * 1.05},
                    {'action': 'BUY', 'type': 'CALL', 'strike': current_price * 1.10}
                ],
                'max_profit': current_price * 0.02,
                'max_loss': current_price * 0.03,
                'confidence': confidence * 0.85
            })
        
        return strategies

# ============================================================================
# MODERN GUI COMPONENTS
# ============================================================================
class ModernPriceCard(ctk.CTkFrame):
    """Modern price display card with animations"""
    
    def __init__(self, parent, symbol: str, **kwargs):
        super().__init__(parent, fg_color=ColorScheme.BG_TERTIARY, 
                        corner_radius=15, **kwargs)
        
        self.symbol = symbol
        self.last_price = 0
        self.create_widgets()
    
    def create_widgets(self):
        """Create card widgets"""
        # Symbol label
        self.symbol_label = ctk.CTkLabel()
            self, text=self.symbol,
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY
        )
        self.symbol_label.pack(pady=(10, 5)
        
        # Price label
        self.price_label = ctk.CTkLabel()
            self, text="$0.00",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=ColorScheme.NEON_BLUE
        )
        self.price_label.pack()
        
        # Change label
        self.change_label = ctk.CTkLabel()
            self, text="0.00 (0.00%)",
            font=ctk.CTkFont(size=14),
            text_color=ColorScheme.TEXT_SECONDARY
        )
        self.change_label.pack(pady=(0, 10)
        
        # Volume label
        self.volume_label = ctk.CTkLabel()
            self, text="Vol: 0",
            font=ctk.CTkFont(size=12),
            text_color=ColorScheme.TEXT_TERTIARY
        )
        self.volume_label.pack(pady=(0, 10)
    
    def update_price(self, price_data: Dict):
        """Update price with animation effect"""
        new_price = price_data.get('price', 0)
        change = price_data.get('change', 0)
        change_pct = price_data.get('change_pct', 0)
        volume = price_data.get('volume', 0)
        
        # Update price label with color
        self.price_label.configure(text=f"${new_price:.2f}")
        
        # Update change with color
        if change > 0:
            change_color = ColorScheme.NEON_GREEN
            arrow = "▲"
        elif change < 0:
            change_color = ColorScheme.NEON_RED
            arrow = "▼"
        else:
            change_color = ColorScheme.TEXT_SECONDARY
            arrow = "→"
        
        self.change_label.configure()
            text=f"{arrow} {abs(change):.2f} ({abs(change_pct):.2f}%)",
            text_color=change_color
        )
        
        # Update volume
        if volume > 1000000:
            vol_text = f"Vol: {volume/1000000:.1f}M"
        elif volume > 1000:
            vol_text = f"Vol: {volume/1000:.1f}K"
        else:
            vol_text = f"Vol: {volume}"
        
        self.volume_label.configure(text=vol_text)
        
        # Flash effect on price change
        if new_price != self.last_price:
            self.flash_effect(change_color)
            self.last_price = new_price
    
    def flash_effect(self, color):
        """Create flash effect on price change"""
        original_color = self._fg_color
        self.configure(fg_color=color)
        self.after(100, lambda: self.configure(fg_color=original_color)

class ModernChart(ctk.CTkFrame):
    """Modern chart widget with live updates"""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color=ColorScheme.BG_TERTIARY, 
                        corner_radius=15, **kwargs)
        
        self.figure = Figure(figsize=(8, 4), facecolor=ColorScheme.BG_TERTIARY)
        self.ax = self.figure.add_subplot(111)
        self.configure_chart()
        
        self.canvas = FigureCanvasTkAgg(self.figure, self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        self.price_line = None
        self.volume_bars = None
    
    def configure_chart(self):
        """Configure chart appearance"""
        self.ax.set_facecolor(ColorScheme.BG_TERTIARY)
        self.ax.grid(True, alpha=0.2, color=ColorScheme.CHART_GRID)
        self.ax.spines['top'].set_visible(False)
        self.ax.spines['right'].set_visible(False)
        self.ax.spines['bottom'].set_color(ColorScheme.CHART_GRID)
        self.ax.spines['left'].set_color(ColorScheme.CHART_GRID)
        self.ax.tick_params(colors=ColorScheme.TEXT_SECONDARY)
        self.ax.set_xlabel('Time', color=ColorScheme.TEXT_SECONDARY)
        self.ax.set_ylabel('Price ($)', color=ColorScheme.TEXT_SECONDARY)
    
    def update_chart(self, price_history: List[Dict]):
        """Update chart with new data"""
        if not price_history:
            return
        
        self.ax.clear()
        self.configure_chart()
        
        # Extract data
        times = [p['time'] for p in price_history]
        prices = [p['price'] for p in price_history]
        volumes = [p['volume'] for p in price_history]
        
        # Plot price line
        self.ax.plot(times, prices, color=ColorScheme.CHART_LINE, 
                    linewidth=2, label='Price')
        
        # Fill under line
        self.ax.fill_between(times, prices, alpha=0.1, 
                           color=ColorScheme.CHART_LINE)
        
        # Add volume bars on secondary axis
        ax2 = self.ax.twinx()
        ax2.bar(times, volumes, alpha=0.3, color=ColorScheme.NEON_PURPLE, 
               width=0.0001, label='Volume')
        ax2.set_ylabel('Volume', color=ColorScheme.TEXT_SECONDARY)
        ax2.tick_params(colors=ColorScheme.TEXT_SECONDARY)
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_color(ColorScheme.CHART_GRID)
        
        # Format x-axis
        self.figure.autofmt_xdate()
        
        # Redraw
        self.canvas.draw()

class AlgorithmDashboard(ctk.CTkFrame):
    """Modern algorithm status dashboard"""
    
    def __init__(self, parent, algorithm_connector, **kwargs):
        super().__init__(parent, fg_color=ColorScheme.BG_SECONDARY, **kwargs)
        
        self.algorithm_connector = algorithm_connector
        self.algo_widgets = {}
        self.create_widgets()
    
    def create_widgets(self):
        """Create algorithm dashboard"""
        # Title
        title = ctk.CTkLabel()
            self, text="Algorithm Status",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY
        )
        title.pack(pady=10)
        
        # Algorithm grid
        self.algo_frame = ctk.CTkScrollableFrame()
            self, fg_color=ColorScheme.BG_SECONDARY
        )
        self.algo_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create algorithm widgets
        row = 0
        col = 0
        for algo_name, algo_info in self.algorithm_connector.algorithms.items():
            widget = self.create_algo_widget(algo_name, algo_info)
            widget.grid(row=row, column=col, padx=5, pady=5, sticky="ew")
            self.algo_widgets[algo_name] = widget
            
            col += 1
            if col >= 4:
                col = 0
                row += 1
    
    def create_algo_widget(self, algo_name: str, algo_info: Dict) -> ctk.CTkFrame:
        """Create individual algorithm widget"""
        frame = ctk.CTkFrame(self.algo_frame, fg_color=ColorScheme.BG_TERTIARY,
                           corner_radius=10, width=150, height=80)
        frame.grid_propagate(False)
        
        # Icon and name
        icon_label = ctk.CTkLabel()
            frame, text=algo_info['icon'],
            font=ctk.CTkFont(size=20)
        )
        icon_label.pack(pady=(5, 0)
        
        name_label = ctk.CTkLabel()
            frame, text=algo_name.replace('_', ' ').title(),
            font=ctk.CTkFont(size=10),
            text_color=ColorScheme.TEXT_SECONDARY
        )
        name_label.pack()
        
        # Status indicator
        status = self.algorithm_connector.algorithm_status[algo_name]
        signal_color = {}
            'bullish': ColorScheme.NEON_GREEN,
            'bearish': ColorScheme.NEON_RED,
            'neutral': ColorScheme.TEXT_TERTIARY
        }.get(status['last_signal'], ColorScheme.TEXT_TERTIARY)
        
        signal_label = ctk.CTkLabel()
            frame, text=status['last_signal'].upper(),
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=signal_color
        )
        signal_label.pack()
        
        # Store references
        frame.signal_label = signal_label
        
        return frame
    
    def update_status(self, analysis_results: Dict):
        """Update algorithm status display"""
        predictions = analysis_results.get('predictions', {})
        
        for algo_name, widget in self.algo_widgets.items():
            if algo_name in predictions:
                prediction = predictions[algo_name]
                signal_color = {}
                    'bullish': ColorScheme.NEON_GREEN,
                    'bearish': ColorScheme.NEON_RED,
                    'neutral': ColorScheme.TEXT_TERTIARY
                }.get(prediction['direction'], ColorScheme.TEXT_TERTIARY)
                
                widget.signal_label.configure()
                    text=f"{prediction['direction'].upper()}\n{prediction['confidence']:.0%}",
                    text_color=signal_color
                )

# ============================================================================
# MAIN WINDOWS GUI APPLICATION
# ============================================================================
class V6UltimateWindowsTradingGUI:
    """Ultimate Windows Trading System with Beautiful Modern GUI"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Ultimate Trading System v6.0 - Professional Windows Edition")
        self.root.geometry("1920x1080")
        
        # Set window icon (if available)
        try:
            self.root.iconbitmap('trading_icon.ico')
        except Exception:
            pass
        
        # Initialize components
        self.market_data_provider = LiveMarketDataProvider()
        self.algorithm_connector = V6AlgorithmConnector()
        
        # State variables
        self.current_symbol = "AAPL"
        self.watchlist = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "NVDA"]
        self.user_bias = {}
            'direction': 'neutral',
            'confidence': 0.5,
            'timeframe': 30
        }
        
        # Create GUI
        self.create_widgets()
        
        # Register update callback
        self.market_data_provider.add_update_callback(self.on_market_update)
        
        # Start initial analysis
        self.root.after(1000, self.analyze_current_symbol)
        
        logger.info("v6.0 Ultimate Windows Trading GUI initialized")
    
    def create_widgets(self):
        """Create the main GUI layout"""
        # Configure grid
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        
        # Main container
        self.main_container = ctk.CTkFrame(self.root, fg_color=ColorScheme.BG_PRIMARY)
        self.main_container.grid(row=0, column=0, sticky="nsew")
        self.main_container.grid_columnconfigure(1, weight=1)
        self.main_container.grid_rowconfigure(0, weight=1)
        
        # Create sections
        self.create_sidebar()
        self.create_main_area()
    
    def create_sidebar(self):
        """Create modern sidebar"""
        self.sidebar = ctk.CTkFrame()
            self.main_container, 
            width=300,
            fg_color=ColorScheme.BG_SECONDARY,
            corner_radius=0
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        
        # Logo/Title
        title_label = ctk.CTkLabel()
            self.sidebar,
            text="ULTIMATE\nTRADING v6.0",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=ColorScheme.NEON_BLUE
        )
        title_label.pack(pady=30)
        
        # Symbol search
        self.create_symbol_search()
        
        # User bias controls
        self.create_bias_controls()
        
        # Watchlist
        self.create_watchlist()
        
        # Bot trading controls
        self.create_bot_controls()
    
    def create_symbol_search(self):
        """Create symbol search with autocomplete"""
        search_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        search_frame.pack(fill="x", padx=20, pady=20)
        
        search_label = ctk.CTkLabel()
            search_frame, text="Symbol Search",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY
        )
        search_label.pack(anchor="w", pady=(0, 10)
        
        # Search entry with modern styling
        self.symbol_entry = ctk.CTkEntry()
            search_frame,
            placeholder_text="Enter symbol...",
            height=40,
            font=ctk.CTkFont(size=14),
            fg_color=ColorScheme.BG_TERTIARY,
            border_color=ColorScheme.NEON_BLUE,
            border_width=2
        )
        self.symbol_entry.pack(fill="x", pady=(0, 10)
        self.symbol_entry.bind("<Return>", self.on_symbol_enter)
        
        # Search button
        search_btn = ctk.CTkButton()
            search_frame,
            text="Analyze",
            height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ColorScheme.NEON_BLUE,
            hover_color=ColorScheme.INFO,
            command=self.on_analyze_click
        )
        search_btn.pack(fill="x")
    
    def create_bias_controls(self):
        """Create user bias controls"""
        bias_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        bias_frame.pack(fill="x", padx=20, pady=20)
        
        bias_label = ctk.CTkLabel()
            bias_frame, text="Market Bias",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY
        )
        bias_label.pack(anchor="w", pady=(0, 10)
        
        # Direction buttons
        direction_frame = ctk.CTkFrame(bias_frame, fg_color="transparent")
        direction_frame.pack(fill="x", pady=(0, 10)
        
        self.direction_var = tk.StringVar(value="neutral")
        
        bullish_btn = ctk.CTkRadioButton()
            direction_frame, text="Bullish",
            variable=self.direction_var, value="bullish",
            font=ctk.CTkFont(size=12),
            fg_color=ColorScheme.NEON_GREEN,
            hover_color=ColorScheme.SUCCESS,
            command=self.update_bias
        )
        bullish_btn.pack(side="left", padx=(0, 10)
        
        neutral_btn = ctk.CTkRadioButton()
            direction_frame, text="Neutral",
            variable=self.direction_var, value="neutral",
            font=ctk.CTkFont(size=12),
            fg_color=ColorScheme.TEXT_TERTIARY,
            command=self.update_bias
        )
        neutral_btn.pack(side="left", padx=(0, 10)
        
        bearish_btn = ctk.CTkRadioButton()
            direction_frame, text="Bearish",
            variable=self.direction_var, value="bearish",
            font=ctk.CTkFont(size=12),
            fg_color=ColorScheme.NEON_RED,
            hover_color=ColorScheme.ERROR,
            command=self.update_bias
        )
        bearish_btn.pack(side="left")
        
        # Confidence slider
        conf_label = ctk.CTkLabel()
            bias_frame, text="Confidence: 50%",
            font=ctk.CTkFont(size=12),
            text_color=ColorScheme.TEXT_SECONDARY
        )
        conf_label.pack(anchor="w", pady=(10, 5)
        
        self.confidence_slider = ctk.CTkSlider()
            bias_frame,
            from_=0, to=100,
            number_of_steps=20,
            button_color=ColorScheme.NEON_BLUE,
            button_hover_color=ColorScheme.INFO,
            progress_color=ColorScheme.NEON_BLUE,
            command=lambda v: self.update_confidence(v, conf_label)
        )
        self.confidence_slider.set(50)
        self.confidence_slider.pack(fill="x")
    
    def create_watchlist(self):
        """Create watchlist section"""
        watchlist_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        watchlist_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        watchlist_label = ctk.CTkLabel()
            watchlist_frame, text="Watchlist",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY
        )
        watchlist_label.pack(anchor="w", pady=(0, 10)
        
        # Watchlist items
        self.watchlist_frame = ctk.CTkScrollableFrame()
            watchlist_frame,
            fg_color=ColorScheme.BG_TERTIARY,
            corner_radius=10
        )
        self.watchlist_frame.pack(fill="both", expand=True)
        
        # Add watchlist items
        self.watchlist_items = {}
        for symbol in self.watchlist:
            self.add_watchlist_item(symbol)
    
    def add_watchlist_item(self, symbol: str):
        """Add item to watchlist"""
        item_frame = ctk.CTkFrame()
            self.watchlist_frame,
            fg_color=ColorScheme.BG_SECONDARY,
            corner_radius=8,
            height=60
        )
        item_frame.pack(fill="x", padx=5, pady=5)
        item_frame.pack_propagate(False)
        
        # Symbol
        symbol_label = ctk.CTkLabel()
            item_frame, text=symbol,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY
        )
        symbol_label.pack(side="left", padx=10)
        
        # Price
        price_label = ctk.CTkLabel()
            item_frame, text="$0.00",
            font=ctk.CTkFont(size=14),
            text_color=ColorScheme.TEXT_SECONDARY
        )
        price_label.pack(side="left", expand=True)
        
        # Change
        change_label = ctk.CTkLabel()
            item_frame, text="0.00%",
            font=ctk.CTkFont(size=12),
            text_color=ColorScheme.TEXT_TERTIARY
        )
        change_label.pack(side="right", padx=10)
        
        # Click handler
        item_frame.bind("<Button-1>", lambda e: self.select_symbol(symbol)
        for child in item_frame.winfo_children():
            child.bind("<Button-1>", lambda e: self.select_symbol(symbol)
        
        self.watchlist_items[symbol] = {}
            'frame': item_frame,
            'price_label': price_label,
            'change_label': change_label
        }
    
    def create_bot_controls(self):
        """Create bot trading controls"""
        bot_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        bot_frame.pack(fill="x", padx=20, pady=20)
        
        # Bot status
        self.bot_status_label = ctk.CTkLabel()
            bot_frame, text="Bot Trading: INACTIVE",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=ColorScheme.TEXT_TERTIARY
        )
        self.bot_status_label.pack(pady=(0, 10)
        
        # Bot toggle button
        self.bot_toggle_btn = ctk.CTkButton()
            bot_frame,
            text="ACTIVATE BOT",
            height=50,
            font=ctk.CTkFont(size=16, weight="bold"),
            fg_color=ColorScheme.SUCCESS,
            hover_color=ColorScheme.NEON_GREEN,
            command=self.toggle_bot_trading
        )
        self.bot_toggle_btn.pack(fill="x")
    
    def create_main_area(self):
        """Create main content area"""
        self.main_area = ctk.CTkFrame()
            self.main_container,
            fg_color=ColorScheme.BG_PRIMARY
        )
        self.main_area.grid(row=0, column=1, sticky="nsew", padx=(0, 10), pady=10)
        self.main_area.grid_columnconfigure(0, weight=1)
        self.main_area.grid_rowconfigure(1, weight=1)
        
        # Top section - Price cards
        self.create_price_section()
        
        # Middle section - Tabbed content
        self.create_tabbed_content()
        
        # Bottom section - Algorithm dashboard
        self.create_algorithm_section()
    
    def create_price_section(self):
        """Create price display section"""
        price_section = ctk.CTkFrame()
            self.main_area,
            fg_color="transparent",
            height=150
        )
        price_section.grid(row=0, column=0, sticky="ew", pady=(0, 10)
        price_section.grid_propagate(False)
        
        # Price cards
        self.price_cards = {}
        for i, symbol in enumerate(self.watchlist[:4]):
            card = ModernPriceCard(price_section, symbol)
            card.grid(row=0, column=i, padx=5, sticky="nsew")
            price_section.grid_columnconfigure(i, weight=1)
            self.price_cards[symbol] = card
    
    def create_tabbed_content(self):
        """Create tabbed content area"""
        self.tabview = ctk.CTkTabview()
            self.main_area,
            fg_color=ColorScheme.BG_SECONDARY,
            segmented_button_fg_color=ColorScheme.BG_TERTIARY,
            segmented_button_selected_color=ColorScheme.NEON_BLUE,
            segmented_button_selected_hover_color=ColorScheme.INFO,
            text_color=ColorScheme.TEXT_SECONDARY,
            corner_radius=15
        )
        self.tabview.grid(row=1, column=0, sticky="nsew", pady=(0, 10)
        
        # Add tabs
        self.tabview.add("Chart")
        self.tabview.add("Analysis")
        self.tabview.add("Strategies")
        self.tabview.add("Portfolio")
        self.tabview.add("News")
        
        # Create tab contents
        self.create_chart_tab()
        self.create_analysis_tab()
        self.create_strategies_tab()
        self.create_portfolio_tab()
        self.create_news_tab()
    
    def create_chart_tab(self):
        """Create chart tab"""
        chart_tab = self.tabview.tab("Chart")
        
        # Chart widget
        self.chart_widget = ModernChart(chart_tab)
        self.chart_widget.pack(fill="both", expand=True, padx=10, pady=10)
    
    def create_analysis_tab(self):
        """Create analysis tab"""
        analysis_tab = self.tabview.tab("Analysis")
        
        # Analysis text
        self.analysis_frame = ctk.CTkScrollableFrame()
            analysis_tab,
            fg_color=ColorScheme.BG_TERTIARY,
            corner_radius=15
        )
        self.analysis_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Analysis content
        self.analysis_content = ctk.CTkLabel()
            self.analysis_frame,
            text="Select a symbol to see analysis...",
            font=ctk.CTkFont(size=14),
            text_color=ColorScheme.TEXT_SECONDARY,
            justify="left"
        )
        self.analysis_content.pack(anchor="nw", padx=20, pady=20)
    
    def create_strategies_tab(self):
        """Create strategies tab"""
        strategies_tab = self.tabview.tab("Strategies")
        
        # Strategies frame
        self.strategies_frame = ctk.CTkScrollableFrame()
            strategies_tab,
            fg_color=ColorScheme.BG_TERTIARY,
            corner_radius=15
        )
        self.strategies_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.strategy_widgets = []
    
    def create_portfolio_tab(self):
        """Create portfolio tab"""
        portfolio_tab = self.tabview.tab("Portfolio")
        
        # Portfolio summary
        summary_frame = ctk.CTkFrame()
            portfolio_tab,
            fg_color=ColorScheme.BG_TERTIARY,
            corner_radius=15,
            height=100
        )
        summary_frame.pack(fill="x", padx=10, pady=10)
        summary_frame.pack_propagate(False)
        
        # Portfolio value
        value_label = ctk.CTkLabel()
            summary_frame,
            text="Portfolio Value",
            font=ctk.CTkFont(size=14),
            text_color=ColorScheme.TEXT_SECONDARY
        )
        value_label.pack(pady=(20, 5)
        
        self.portfolio_value_label = ctk.CTkLabel()
            summary_frame,
            text="$100,000.00",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=ColorScheme.NEON_GREEN
        )
        self.portfolio_value_label.pack()
        
        # Positions
        self.positions_frame = ctk.CTkScrollableFrame()
            portfolio_tab,
            fg_color=ColorScheme.BG_TERTIARY,
            corner_radius=15
        )
        self.positions_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10)
    
    def create_news_tab(self):
        """Create news tab"""
        news_tab = self.tabview.tab("News")
        
        # News frame
        self.news_frame = ctk.CTkScrollableFrame()
            news_tab,
            fg_color=ColorScheme.BG_TERTIARY,
            corner_radius=15
        )
        self.news_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Sample news
        self.add_news_item()
            "Market Update",
            "S&P 500 reaches new all-time high as tech stocks rally",
            "2 hours ago"
        )
    
    def add_news_item(self, title: str, summary: str, time: str):
        """Add news item"""
        item_frame = ctk.CTkFrame()
            self.news_frame,
            fg_color=ColorScheme.BG_SECONDARY,
            corner_radius=10
        )
        item_frame.pack(fill="x", padx=10, pady=5)
        
        # Title
        title_label = ctk.CTkLabel()
            item_frame,
            text=title,
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=ColorScheme.TEXT_PRIMARY,
            anchor="w"
        )
        title_label.pack(fill="x", padx=15, pady=(10, 5)
        
        # Summary
        summary_label = ctk.CTkLabel()
            item_frame,
            text=summary,
            font=ctk.CTkFont(size=12),
            text_color=ColorScheme.TEXT_SECONDARY,
            anchor="w",
            wraplength=600
        )
        summary_label.pack(fill="x", padx=15, pady=(0, 5)
        
        # Time
        time_label = ctk.CTkLabel()
            item_frame,
            text=time,
            font=ctk.CTkFont(size=10),
            text_color=ColorScheme.TEXT_TERTIARY,
            anchor="w"
        )
        time_label.pack(fill="x", padx=15, pady=(0, 10)
    
    def create_algorithm_section(self):
        """Create algorithm dashboard section"""
        self.algorithm_dashboard = AlgorithmDashboard()
            self.main_area,
            self.algorithm_connector
        )
        self.algorithm_dashboard.grid(row=2, column=0, sticky="ew")
    
    # ========================================================================
    # EVENT HANDLERS
    # ========================================================================
    
    def on_symbol_enter(self, event):
        """Handle enter key in symbol entry"""
        self.on_analyze_click()
    
    def on_analyze_click(self):
        """Handle analyze button click"""
        symbol = self.symbol_entry.get().strip().upper()
        if symbol:
            self.current_symbol = symbol
            self.analyze_current_symbol()
    
    def select_symbol(self, symbol: str):
        """Select symbol from watchlist"""
        self.current_symbol = symbol
        self.symbol_entry.delete(0, tk.END)
        self.symbol_entry.insert(0, symbol)
        self.analyze_current_symbol()
    
    def update_bias(self):
        """Update user bias"""
        self.user_bias['direction'] = self.direction_var.get()
        logger.info(f"Updated bias direction: {self.user_bias['direction']}")
        # Re-analyze with new bias
        self.analyze_current_symbol()
    
    def update_confidence(self, value: float, label: ctk.CTkLabel):
        """Update confidence level"""
        self.user_bias['confidence'] = value / 100
        label.configure(text=f"Confidence: {int(value)}%")
        
    def toggle_bot_trading(self):
        """Toggle bot trading"""
        # This would connect to actual bot trading system
        if self.bot_toggle_btn.cget("text") == "ACTIVATE BOT":
            self.bot_toggle_btn.configure()
                text="DEACTIVATE BOT",
                fg_color=ColorScheme.ERROR,
                hover_color=ColorScheme.NEON_RED
            )
            self.bot_status_label.configure()
                text="Bot Trading: ACTIVE",
                text_color=ColorScheme.NEON_GREEN
            )
            messagebox.showinfo("Bot Trading", "Bot trading activated!")
        else:
            self.bot_toggle_btn.configure()
                text="ACTIVATE BOT",
                fg_color=ColorScheme.SUCCESS,
                hover_color=ColorScheme.NEON_GREEN
            )
            self.bot_status_label.configure()
                text="Bot Trading: INACTIVE",
                text_color=ColorScheme.TEXT_TERTIARY
            )
            messagebox.showinfo("Bot Trading", "Bot trading deactivated!")
    
    def on_market_update(self):
        """Handle market data updates"""
        # Update watchlist prices
        for symbol, widgets in self.watchlist_items.items():
            price_data = self.market_data_provider.get_price(symbol)
            if price_data:
                # Update price
                widgets['price_label'].configure()
                    text=f"${price_data['price']:.2f}"
                )
                
                # Update change with color
                change_pct = price_data['change_pct']
                if change_pct > 0:
                    color = ColorScheme.NEON_GREEN
                    arrow = "▲"
                elif change_pct < 0:
                    color = ColorScheme.NEON_RED
                    arrow = "▼"
                else:
                    color = ColorScheme.TEXT_TERTIARY
                    arrow = ""
                
                widgets['change_label'].configure()
                    text=f"{arrow}{abs(change_pct):.2f}%",
                    text_color=color
                )
        
        # Update price cards
        for symbol, card in self.price_cards.items():
            price_data = self.market_data_provider.get_price(symbol)
            if price_data:
                card.update_price(price_data)
        
        # Update chart if current symbol
        if self.current_symbol:
            history = self.market_data_provider.get_price_history(self.current_symbol)
            if history:
                self.chart_widget.update_chart(history)
    
    def analyze_current_symbol(self):
        """Analyze current symbol"""
        if not self.current_symbol:
            return
        
        # Get market data
        price_data = self.market_data_provider.get_price(self.current_symbol)
        
        # Run algorithm analysis
        analysis = self.algorithm_connector.analyze_with_algorithms()
            self.current_symbol, price_data, self.user_bias
        )
        
        # Update displays
        self.update_analysis_display(analysis, price_data)
        self.update_strategies_display(analysis.get('top_strategies', [])
        self.algorithm_dashboard.update_status(analysis)
    
    def update_analysis_display(self, analysis: Dict, price_data: Dict):
        """Update analysis display"""
        content = f"""MARKET ANALYSIS - {self.current_symbol}
{'='*50}

Current Price: ${price_data.get('price', 0):.2f}
Change: {price_data.get('change_pct', 0):.2f}%
Volume: {price_data.get('volume', 0):,}
Source: {price_data.get('source', 'N/A')}
Confidence: {price_data.get('confidence', 0):.1%}

ALGORITHM CONSENSUS
{'='*50}
Direction: {analysis['consensus_direction'].upper()}
Confidence: {analysis['average_confidence']:.1%}
Algorithms Analyzed: {analysis['algorithms_analyzed']}

Bullish: {len(analysis['algorithm_breakdown']['bullish'])}
Bearish: {len(analysis['algorithm_breakdown']['bearish'])}
Neutral: {len(analysis['algorithm_breakdown']['neutral'])}

TYPE BREAKDOWN
{'='*50}"""

        for algo_type, breakdown in analysis['type_breakdown'].items():
            content += f"\n{algo_type.replace('_', ' ').title()}:"
            content += f"\n  Bullish: {breakdown['bullish']}"
            content += f"\n  Bearish: {breakdown['bearish']}"
            content += f"\n  Neutral: {breakdown['neutral']}"
        
        self.analysis_content.configure(text=content)
    
    def update_strategies_display(self, strategies: List[Dict]):
        """Update strategies display"""
        # Clear existing
        for widget in self.strategy_widgets:
            widget.destroy()
        self.strategy_widgets.clear()
        
        # Add strategies
        for strategy in strategies:
            strategy_frame = ctk.CTkFrame()
                self.strategies_frame,
                fg_color=ColorScheme.BG_SECONDARY,
                corner_radius=10
            )
            strategy_frame.pack(fill="x", padx=10, pady=5)
            
            # Strategy name
            name_label = ctk.CTkLabel()
                strategy_frame,
                text=strategy['name'],
                font=ctk.CTkFont(size=18, weight="bold"),
                text_color=ColorScheme.TEXT_PRIMARY
            )
            name_label.pack(anchor="w", padx=15, pady=(10, 5)
            
            # Strategy details
            if strategy['type'] == 'stock':
                details = f"Entry: ${strategy['entry']:.2f} | Target: ${strategy['target']:.2f} | Stop: ${strategy['stop_loss']:.2f}"
            else:
                details = f"Max Profit: ${strategy.get('max_profit', 0):.2f} | Max Loss: ${strategy.get('max_loss', 0):.2f}"
            
            details_label = ctk.CTkLabel()
                strategy_frame,
                text=details,
                font=ctk.CTkFont(size=12),
                text_color=ColorScheme.TEXT_SECONDARY
            )
            details_label.pack(anchor="w", padx=15, pady=(0, 5)
            
            # Confidence
            conf_label = ctk.CTkLabel()
                strategy_frame,
                text=f"Confidence: {strategy['confidence']:.1%}",
                font=ctk.CTkFont(size=12),
                text_color=ColorScheme.NEON_BLUE
            )
            conf_label.pack(anchor="w", padx=15, pady=(0, 10)
            
            self.strategy_widgets.append(strategy_frame)
    
    def on_closing(self):
        """Handle window closing"""
        self.market_data_provider.stop_updates()
        self.root.destroy()

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================
def main():
    """Run the Ultimate Windows Trading System"""
    # Create root window
    root = ctk.CTk()
    
    # Configure DPI awareness for Windows
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    
    # Create application
    app = V6UltimateWindowsTradingGUI(root)
    
    # Set close handler
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    
    # Start GUI
    logger.info("Starting v6.0 Ultimate Windows Trading System")
    root.mainloop()

if __name__ == "__main__":
    main()