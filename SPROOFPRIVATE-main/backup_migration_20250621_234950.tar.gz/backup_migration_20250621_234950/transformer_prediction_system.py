
#!/usr/bin/env python3
"""
Advanced Transformer Prediction System
Integrates transformer models for multi-asset price prediction with reinforcement learning
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest, StockTradesRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass, AssetClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, GetOrdersRequest
from alpaca.common.exceptions import APIError


import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
import logging
from collections import deque, defaultdict
import asyncio
import aiohttp
from dataclasses import dataclass
import pickle
import os
import sys

from universal_market_data import get_current_market_data, validate_price


# Add parent directory to path
sys.path.append('/home/harry/alpaca-mcp')

# Import our modules
try:
    from robust_data_fetcher import RobustDataFetcher
    from market_data_engine import MarketDataEngine
    from performance_tracker import PerformanceTracker
except ImportError as e:
    print(f"Warning: Some modules not available: {e}")

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class PredictionResult:
    """Structure for prediction results"""
    symbol: str
    current_price: float
    predicted_prices: List[float]
    confidence: float
    predicted_direction: str  # 'up', 'down', 'neutral'
    predicted_return: float
    risk_score: float
    timestamp: datetime
    model_version: str
    features_used: Dict[str, float]

class TransformerPricePredictor(nn.Module):
    """Enhanced Transformer model for price prediction"""
    
    def __init__(self, input_dim=10, output_dim=10, d_model=512, nhead=8, 
                 num_layers=6, dropout=0.1):
        super().__init__()
        
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Input embedding
        self.input_embedding = nn.Linear(input_dim, d_model)
        self.positional_encoding = self.create_positional_encoding(1000, d_model)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer()
            d_model=d_model, 
            nhead=nhead, 
            dropout=dropout,
            activation='gelu',
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # Output layers
        self.fc1 = nn.Linear(d_model, d_model // 2)
        self.fc2 = nn.Linear(d_model // 2, d_model // 4)
        self.fc_out = nn.Linear(d_model // 4, output_dim)
        
        # Additional components
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(d_model)
        self.activation = nn.GELU()
        
    def create_positional_encoding(self, max_len, d_model):
        """Create positional encoding"""
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        
        div_term = torch.exp(torch.arange(0, d_model, 2).float() *)
                           -(np.log(10000.0) / d_model))
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        return pe.unsqueeze(0)
        
    def forward(self, x):
        """Forward pass"""
        batch_size, seq_len, _ = x.shape
        
        # Input embedding
        x = self.input_embedding(x)
        x = self.layer_norm(x)
        
        # Add positional encoding
        x = x + self.positional_encoding[:, :seq_len, :].to(x.device)
        
        # Transformer encoding
        x = self.transformer(x)
        
        # Take the last hidden state
        x = x[:, -1, :]
        
        # Output layers
        x = self.activation(self.fc1(x))
        x = self.dropout(x)
        x = self.activation(self.fc2(x))
        x = self.dropout(x)
        x = self.fc_out(x)
        
        return x

class ReinforcementLearningOptimizer:
    """RL optimizer for trading decisions based on predictions"""
    
    def __init__(self, state_dim=50, action_dim=4, learning_rate=0.001):
        self.state_dim = state_dim
        self.action_dim = action_dim  # buy, sell, hold, size
        
        # Q-network
        self.q_network = self._build_q_network()
        self.target_network = self._build_q_network()
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=learning_rate)
        
        # Experience replay
        self.memory = deque(maxlen=10000)
        self.batch_size = 32
        self.gamma = 0.99
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01
        
    def _build_q_network(self):
        """Build Q-network for action-value estimation"""
        return nn.Sequential()
            nn.Linear(self.state_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, self.action_dim)
        )
        
    def remember(self, state, action, reward, next_state, done):
        """Store experience in replay buffer"""
        self.memory.append((state, action, reward, next_state, done))
        
    def act(self, state):
        """Choose action using epsilon-greedy policy"""
        if np.random.random() <= self.epsilon:
            return np.random.randint(self.action_dim)
            
        state_tensor = torch.FloatTensor(state).unsqueeze(0)
        q_values = self.q_network(state_tensor)
        return q_values.argmax().item()
        
    def replay(self):
        """Train Q-network on batch of experiences"""
        if len(self.memory) < self.batch_size:
            return
            
        batch = np.random.choice(len(self.memory), self.batch_size, replace=False)
        states = torch.FloatTensor([self.memory[i][0] for i in batch])
        actions = torch.LongTensor([self.memory[i][1] for i in batch])
        rewards = torch.FloatTensor([self.memory[i][2] for i in batch])
        next_states = torch.FloatTensor([self.memory[i][3] for i in batch])
        dones = torch.FloatTensor([self.memory[i][4] for i in batch])
        
        current_q_values = self.q_network(states).gather(1, actions.unsqueeze(1))
        next_q_values = self.target_network(next_states).max(1)[0].detach()
        target_q_values = rewards + (self.gamma * next_q_values * (1 - dones))
        
        loss = nn.MSELoss()(current_q_values.squeeze(), target_q_values)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        # Decay epsilon
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
            
    def update_target_network(self):
        """Update target network with current Q-network weights"""
        self.target_network.load_state_dict(self.q_network.state_dict())

class TransformerPredictionSystem:
    """Complete transformer-based prediction and trading system"""
    
    def __init__(self, config_path='/home/harry/alpaca-mcp/transformerpredictionmodel/transf_v2.2.json'):
        self.config = self.load_config(config_path)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {self.device}")
        
        # Initialize components
        self.transformer_model = self.load_transformer_model()
        self.rl_optimizer = ReinforcementLearningOptimizer()
        self.performance_db = self.init_performance_database()
        
        # Market data
        self.data_fetcher = RobustDataFetcher({)
            'alpaca_api_key': '<ALPACA_PAPER_KEY>',
            'alpaca_secret': '<ALPACA_PAPER_SECRET>'
        })
        
        # Expanded ticker coverage
        self.tickers = self.load_expanded_tickers()
        self.historical_data = {}
        self.predictions = {}
        
        # Performance tracking
        self.trade_history = deque(maxlen=10000)
        self.model_performance = defaultdict(list)
        
    def load_config(self, config_path):
        """Load transformer configuration"""
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            logger.info(f"Loaded config: {config.get('model_name', 'Unknown')}")
            return config
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            # Default config
            return {}
                'model_name': 'TransformerV2.2',
                'input_window': 30,
                'output_window': 10,
                'features': 10,
                'd_model': 512,
                'nhead': 6,
                'num_layers': 4
            }
            
    def load_transformer_model(self):
        """Load or create transformer model"""
        model_path = '/home/harry/alpaca-mcp/transformerpredictionmodel/transf_v2.2.pt'
        
        # Create model based on config
        # Ensure d_model is divisible by nhead
        d_model = self.config.get('d_model', 512)
        nhead = self.config.get('nhead', 8)
        
        # Adjust if needed
        if d_model % nhead != 0:
            nhead = 8  # Default to 8 heads for 512 dim
            
        model = TransformerPricePredictor()
            input_dim=self.config.get('features', 10),
            output_dim=self.config.get('output_window', 10),
            d_model=d_model,
            nhead=nhead,
            num_layers=self.config.get('num_layers', 4)
        ).to(self.device)
        
        # Load weights if available
        if os.path.exists(model_path):
            try:
                state_dict = torch.load(model_path, map_location=self.device)
                model.load_state_dict(state_dict)
                logger.info("Loaded pre-trained transformer weights")
            except Exception as e:
                logger.warning(f"Could not load weights: {e}")
                
        return model
        
    def init_performance_database(self):
        """Initialize SQLite database for performance tracking"""
        db_path = '/home/harry/alpaca-mcp/transformer_performance.db'
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS predictions ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                current_price REAL,
                predicted_price REAL,
                actual_price REAL,
                predicted_direction TEXT,
                actual_direction TEXT,
                confidence REAL,
                error_percentage REAL,
                model_version TEXT
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS trades ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                symbol TEXT,
                action TEXT,
                quantity INTEGER,
                price REAL,
                predicted_price REAL,
                profit_loss REAL,
                total_return REAL,
                rl_reward REAL,
                features TEXT
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS model_performance ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                model_version TEXT,
                accuracy REAL,
                precision REAL,
                recall REAL,
                sharpe_ratio REAL,
                max_drawdown REAL,
                total_return REAL,
                win_rate REAL
            )
        ''')
        
        cursor.execute(''')
            CREATE TABLE IF NOT EXISTS arbitrage_opportunities ()
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                type TEXT,
                symbols TEXT,
                predicted_profit REAL,
                actual_profit REAL,
                confidence REAL,
                execution_time REAL,
                success BOOLEAN
            )
        ''')
        
        conn.commit()
        return conn
        
    def load_expanded_tickers(self):
        """Load expanded list of tickers for comprehensive coverage"""
        # Major indices and ETFs
        indices = ['SPY', 'QQQ', 'IWM', 'DIA', 'VOO', 'VTI', 'EFA', 'EEM', 'VNQ', 'GLD', 'SLV', 'TLT']
        
        # Tech giants
        tech = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'TSLA', 'AMD', 'INTC', 'CRM', 
                'ADBE', 'NFLX', 'PYPL', 'SQ', 'SHOP', 'SNAP', 'PINS', 'TWTR', 'UBER', 'LYFT']
        
        # Financial
        financial = ['JPM', 'BAC', 'WFC', 'GS', 'MS', 'C', 'BLK', 'SCHW', 'AXP', 'V', 'MA', 'COF']
        
        # Healthcare
        healthcare = ['JNJ', 'PFE', 'UNH', 'CVS', 'ABBV', 'TMO', 'ABT', 'MRK', 'LLY', 'BMY']
        
        # Energy
        energy = ['XOM', 'CVX', 'COP', 'SLB', 'EOG', 'KMI', 'PSX', 'VLO', 'MPC', 'OXY']
        
        # Consumer
        consumer = ['WMT', 'HD', 'PG', 'KO', 'PEP', 'MCD', 'NKE', 'SBUX', 'TGT', 'COST']
        
        # Crypto-related
        crypto = ['COIN', 'MARA', 'RIOT', 'MSTR', 'GBTC', 'SOS', 'CAN', 'BTBT']
        
        # High volatility
        volatile = ['GME', 'AMC', 'BB', 'NOK', 'BBBY', 'CLOV', 'WISH', 'SOFI', 'PLTR', 'SPCE']
        
        # Combine all
        all_tickers = list(set(indices + tech + financial + healthcare + energy + consumer + crypto + volatile))
        
        logger.info(f"Loaded {len(all_tickers)} tickers for analysis")
        return all_tickers
        
    def prepare_features(self, data: pd.DataFrame) -> torch.Tensor:
        """Prepare features for transformer model"""
        features = []
        
        # Price features
        features.append(data['Close'].pct_change().fillna(0))
        features.append((data['High'] - data['Low']) / data['Close'])  # Daily range
        features.append((data['Close'] - data['Open']) / data['Open'])  # Daily return
        
        # Volume features
        features.append(data['Volume'] / data['Volume'].rolling(20).mean())
        
        # Technical indicators
        features.append(data['Close'].rolling(5).mean() / data['Close'].rolling(20).mean())  # MA ratio
        features.append(self.calculate_rsi(data['Close']))
        
        # Volatility
        features.append(data['Close'].pct_change().rolling(20).std())
        
        # Market microstructure
        features.append((data['Close'] - data['Low']) / (data['High'] - data['Low']))  # Close position
        
        # Momentum
        features.append(data['Close'] / data['Close'].shift(5) - 1)  # 5-day momentum
        features.append(data['Close'] / data['Close'].shift(20) - 1)  # 20-day momentum
        
        # Stack features
        feature_matrix = np.column_stack(features)
        
        # Handle NaN values
        feature_matrix = np.nan_to_num(feature_matrix, 0)
        
        # Normalize
        mean = feature_matrix.mean(axis=0)
        std = feature_matrix.std(axis=0) + 1e-8
        feature_matrix = (feature_matrix - mean) / std
        
        return torch.FloatTensor(feature_matrix)
        
    def calculate_rsi(self, prices, period=14):
        """Calculate RSI indicator"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0).rolling(window=period).mean())
        loss = (-delta.where(delta < 0, 0).rolling(window=period).mean())
        rs = gain / (loss + 1e-8)
        rsi = 100 - (100 / (1 + rs))
        return rsi.fillna(50) / 100  # Normalize to [0, 1]
        
    async def fetch_market_data(self, symbol: str) -> pd.DataFrame:
        """Fetch market data for symbol"""
        try:
            data = self.data_fetcher.fetch_data(symbol, timeframe='1h', period='60d')
            if data is not None and len(data) > 0:
                self.historical_data[symbol] = data
                return data
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            
        return pd.DataFrame()
        
    def make_prediction(self, symbol: str, data: pd.DataFrame) -> PredictionResult:
        """Make price prediction using transformer model"""
        try:
            # Prepare features
            features = self.prepare_features(data)
            
            # Use last input_window days
            input_window = self.config.get('input_window', 30)
            if len(features) < input_window:
                logger.warning(f"Insufficient data for {symbol}")
                return None
                
            # Get input sequence
            input_seq = features[-input_window:].unsqueeze(0).to(self.device)
            
            # Make prediction
            self.transformer_model.eval()
            with torch.no_grad():
                predictions = self.transformer_model(input_seq)
                
            # Convert predictions to prices
            current_price = data['Close'].iloc[-1]
            predicted_returns = predictions.cpu().numpy()[0]
            predicted_prices = current_price * (1 + predicted_returns)
            
            # Calculate metrics
            avg_return = predicted_returns.mean()
            direction = 'up' if avg_return > 0.001 else ('down' if avg_return < -0.001 else 'neutral')
            
            # Confidence based on prediction consistency
            confidence = 1 - predicted_returns.std()
            confidence = max(0.1, min(0.95, confidence))
            
            # Risk score based on volatility
            recent_volatility = data['Close'].pct_change().iloc[-20:].std()
            risk_score = min(1.0, recent_volatility * np.sqrt(252))
            
            # Create result
            result = PredictionResult()
                symbol=symbol,
                current_price=current_price,
                predicted_prices=predicted_prices.tolist(),
                confidence=confidence,
                predicted_direction=direction,
                predicted_return=avg_return,
                risk_score=risk_score,
                timestamp=datetime.now(),
                model_version=self.config.get('model_name', 'Unknown'),
                features_used={}
                    'rsi': float(features[-1, 5]),
                    'momentum_5d': float(features[-1, 8]),
                    'momentum_20d': float(features[-1, 9]),
                    'volatility': recent_volatility
                }
            )
            
            # Store prediction
            self.store_prediction(result)
            
            return result
            
        except Exception as e:
            logger.error(f"Error making prediction for {symbol}: {e}")
            return None
            
    def store_prediction(self, prediction: PredictionResult):
        """Store prediction in database"""
        cursor = self.performance_db.cursor()
        
        cursor.execute(''')
            INSERT INTO predictions 
            (symbol, current_price, predicted_price, predicted_direction, confidence, model_version)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ()
            prediction.symbol,
            prediction.current_price,
            prediction.predicted_prices[0],  # Next period prediction
            prediction.predicted_direction,
            prediction.confidence,
            prediction.model_version
        ))
        
        self.performance_db.commit()
        
    def find_arbitrage_opportunities(self, predictions: Dict[str, PredictionResult]) -> List[Dict]:
        """Find arbitrage opportunities based on predictions"""
        opportunities = []
        
        # 1. Cross-sectional momentum arbitrage
        sorted_predictions = sorted(predictions.items(), 
                                  key=lambda x: x[1].predicted_return if x[1] else -999)
        
        if len(sorted_predictions) >= 10:
            # Long top 5, short bottom 5
            long_symbols = [s[0] for s in sorted_predictions[-5:]]
            short_symbols = [s[0] for s in sorted_predictions[:5]]
            
            expected_return = ()
                sum(predictions[s].predicted_return for s in long_symbols) -
                sum(predictions[s].predicted_return for s in short_symbols)
            ) / 10
            
            if expected_return > 0.002:  # 0.2% threshold
                opportunities.append({)
                    'type': 'momentum_arbitrage',
                    'long_symbols': long_symbols,
                    'short_symbols': short_symbols,
                    'expected_return': expected_return,
                    'confidence': np.mean([predictions[s].confidence for s in long_symbols + short_symbols]),
                    'timeframe': '1-10 days'
                })
                
        # 2. Volatility arbitrage
        for symbol, pred in predictions.items():
            if pred and pred.risk_score > 0.3:  # High volatility
                if abs(pred.predicted_return) > 0.01:  # Strong directional move
                    opportunities.append({)
                        'type': 'volatility_arbitrage',
                        'symbol': symbol,
                        'strategy': 'straddle' if pred.confidence < 0.7 else 'directional',
                        'expected_return': abs(pred.predicted_return) * pred.risk_score,
                        'confidence': pred.confidence,
                        'risk_score': pred.risk_score
                    })
                    
        # 3. Correlation arbitrage
        correlations = self.calculate_correlation_matrix(predictions)
        for i, (sym1, pred1) in enumerate(predictions.items()):
            for j, (sym2, pred2) in enumerate(list(predictions.items())[i+1:], i+1):
                if pred1 and pred2:
                    # Check for divergence in highly correlated pairs
                    if correlations.get((sym1, sym2), 0) > 0.8:
                        return_diff = pred1.predicted_return - pred2.predicted_return
                        if abs(return_diff) > 0.005:  # 0.5% divergence
                            opportunities.append({)
                                'type': 'pairs_arbitrage',
                                'symbols': [sym1, sym2],
                                'correlation': correlations.get((sym1, sym2), 0),
                                'return_difference': return_diff,
                                'confidence': (pred1.confidence + pred2.confidence) / 2
                            })
                            
        # 4. Sector rotation arbitrage
        sector_performance = self.analyze_sector_rotation(predictions)
        if sector_performance:
            top_sector = max(sector_performance, key=sector_performance.get)
            bottom_sector = min(sector_performance, key=sector_performance.get)
            
            if sector_performance[top_sector] - sector_performance[bottom_sector] > 0.01:
                opportunities.append({)
                    'type': 'sector_rotation',
                    'long_sector': top_sector,
                    'short_sector': bottom_sector,
                    'expected_return': sector_performance[top_sector] - sector_performance[bottom_sector],
                    'confidence': 0.75
                })
                
        return opportunities
        
    def calculate_correlation_matrix(self, predictions: Dict[str, PredictionResult]) -> Dict:
        """Calculate correlation between predicted returns"""
        correlations = {}
        
        # Simplified - in production, use historical correlation
        symbols = list(predictions.keys())
        for i, sym1 in enumerate(symbols):
            for j, sym2 in enumerate(symbols[i+1:], i+1):
                # Use feature similarity as proxy for correlation
                if predictions[sym1] and predictions[sym2]:
                    feat1 = predictions[sym1].features_used
                    feat2 = predictions[sym2].features_used
                    
                    # Simple correlation estimate
                    corr = 1 - abs(feat1['momentum_5d'] - feat2['momentum_5d'])
                    correlations[(sym1, sym2)] = corr
                    
        return correlations
        
    def analyze_sector_rotation(self, predictions: Dict[str, PredictionResult]) -> Dict[str, float]:
        """Analyze sector rotation opportunities"""
        sector_map = {}
            'XLK': ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'META'],
            'XLF': ['JPM', 'BAC', 'WFC', 'GS', 'MS'],
            'XLE': ['XOM', 'CVX', 'COP', 'SLB', 'EOG'],
            'XLV': ['JNJ', 'PFE', 'UNH', 'CVS', 'ABBV'],
            'XLY': ['AMZN', 'TSLA', 'HD', 'NKE', 'MCD'],
            'XLP': ['PG', 'KO', 'PEP', 'WMT', 'COST']
        }
        
        sector_performance = {}
        
        for sector_etf, components in sector_map.items():
            returns = []
            for symbol in components:
                if symbol in predictions and predictions[symbol]:
                    returns.append(predictions[symbol].predicted_return)
                    
            if returns:
                sector_performance[sector_etf] = np.mean(returns)
                
        return sector_performance
        
    def execute_rl_trading_decision(self, predictions: Dict[str, PredictionResult], 
                                   opportunities: List[Dict]) -> Dict[str, Any]:
        """Use RL to make trading decisions"""
        # Prepare state vector
        state_features = []
        
        # Market overview features
        avg_return = np.mean([p.predicted_return for p in predictions.values() if p])
        avg_confidence = np.mean([p.confidence for p in predictions.values() if p])
        avg_risk = np.mean([p.risk_score for p in predictions.values() if p])
        
        state_features.extend([avg_return, avg_confidence, avg_risk])
        
        # Opportunity features
        state_features.append(len(opportunities))
        state_features.append(max([o.get('expected_return', 0) for o in opportunities]) if opportunities else 0)
        
        # Portfolio features (simplified)
        state_features.extend([0.5, 0.3, 0.8])  # cash_ratio, position_count, portfolio_vol
        
        # Pad to state dimension
        while len(state_features) < self.rl_optimizer.state_dim:
            state_features.append(0)
            
        state = np.array(state_features[:self.rl_optimizer.state_dim])
        
        # Get action from RL
        action = self.rl_optimizer.act(state)
        
        # Map action to trading decision
        action_map = {}
            0: 'buy_best',
            1: 'sell_worst',
            2: 'hold',
            3: 'execute_arbitrage'
        }
        
        decision = {}
            'action': action_map[action],
            'confidence': 1 - self.rl_optimizer.epsilon,
            'state_features': state_features[:10],
            'top_opportunities': opportunities[:3] if opportunities else []
        }
        
        return decision
        
    def train_models_on_history(self):
        """Train models on historical performance"""
        logger.info("Training models on historical performance...")
        
        # Get historical predictions
        cursor = self.performance_db.cursor()
        cursor.execute(''')
            SELECT symbol, predicted_price, actual_price, confidence
            FROM predictions
            WHERE actual_price IS NOT NULL
            ORDER BY timestamp DESC
            LIMIT 10000
        ''')
        
        results = cursor.fetchall()
        
        if len(results) > 100:
            # Calculate performance metrics
            errors = []
            for symbol, predicted, actual, confidence in results:
                if actual > 0:
                    error = abs(predicted - actual) / actual
                    errors.append(error)
                    
            # Update model based on errors
            avg_error = np.mean(errors)
            logger.info(f"Average prediction error: {avg_error*100:.2f}%")
            
            # Fine-tune transformer if error is high
            if avg_error > 0.05:  # 5% error threshold
                self.fine_tune_transformer(results)
                
        # Train RL on trading outcomes
        cursor.execute(''')
            SELECT * FROM trades
            ORDER BY timestamp DESC
            LIMIT 1000
        ''')
        
        trades = cursor.fetchall()
        if len(trades) > 10:
            self.train_rl_on_trades(trades)
            
    def fine_tune_transformer(self, historical_results):
        """Fine-tune transformer model on recent predictions"""
        logger.info("Fine-tuning transformer model...")
        
        # Prepare training data
        X, y = [], []
        
        # Group by symbol
        symbol_data = defaultdict(list)
        for symbol, predicted, actual, confidence in historical_results:
            symbol_data[symbol].append((predicted, actual))
            
        # Create sequences
        for symbol, data in symbol_data.items():
            if len(data) > self.config['input_window']:
                for i in range(len(data) - self.config['input_window'] - 1):
                    # Input: historical predictions
                    X.append([d[0] for d in data[i:i+self.config['input_window']]])
                    # Target: actual price
                    y.append(data[i+self.config['input_window']][1])
                    
        if len(X) > 50:
            # Convert to tensors
            X = torch.FloatTensor(X).to(self.device)
            y = torch.FloatTensor(y).to(self.device)
            
            # Fine-tune
            optimizer = optim.Adam(self.transformer_model.parameters(), lr=0.0001)
            criterion = nn.MSELoss()
            
            self.transformer_model.train()
            for epoch in range(10):
                optimizer.zero_grad()
                predictions = self.transformer_model(X)
                loss = criterion(predictions[:, 0], y)
                loss.backward()
                optimizer.step()
                
                if epoch % 5 == 0:
                    logger.info(f"Fine-tuning epoch {epoch}, loss: {loss.item():.4f}")
                    
    def train_rl_on_trades(self, trades):
        """Train RL model on trading outcomes"""
        logger.info("Training RL on trading history...")
        
        for trade in trades:
            # Extract trade details
            state_features = json.loads(trade[9]) if trade[9] else [0] * 50
            action = {'buy': 0, 'sell': 1, 'hold': 2}.get(trade[3], 2)
            reward = trade[8] if trade[8] else 0
            
            # Store experience
            self.rl_optimizer.remember()
                state_features[:self.rl_optimizer.state_dim],
                action,
                reward,
                state_features[:self.rl_optimizer.state_dim],  # Simplified
                False
            )
            
        # Train on experiences
        for _ in range(50):
            self.rl_optimizer.replay()
            
        # Update target network
        self.rl_optimizer.update_target_network()
        
    async def run_prediction_cycle(self):
        """Run complete prediction cycle for all tickers"""
        logger.info("Starting prediction cycle...")
        
        predictions = {}
        
        # Fetch data and make predictions
        for symbol in self.tickers[:50]:  # Limit for performance
            try:
                data = await self.fetch_market_data(symbol)
                if not data.empty:
                    prediction = self.make_prediction(symbol, data)
                    if prediction:
                        predictions[symbol] = prediction
                        
            except Exception as e:
                logger.error(f"Error processing {symbol}: {e}")
                
        # Find arbitrage opportunities
        opportunities = self.find_arbitrage_opportunities(predictions)
        
        # Make RL trading decision
        decision = self.execute_rl_trading_decision(predictions, opportunities)
        
        # Log results
        logger.info(f"Completed prediction cycle: {len(predictions)} predictions, ")
                   f"{len(opportunities)} opportunities")
        logger.info(f"RL Decision: {decision['action']} (confidence: {decision['confidence']:.2f})")
        
        # Store arbitrage opportunities
        for opp in opportunities:
            self.store_arbitrage_opportunity(opp)
            
        return {}
            'predictions': predictions,
            'opportunities': opportunities,
            'decision': decision
        }
        
    def store_arbitrage_opportunity(self, opportunity: Dict):
        """Store arbitrage opportunity in database"""
        cursor = self.performance_db.cursor()
        
        cursor.execute(''')
            INSERT INTO arbitrage_opportunities
            (type, symbols, predicted_profit, confidence)
            VALUES (?, ?, ?, ?)
        ''', ()
            opportunity.get('type'),
            json.dumps(opportunity.get('symbols', opportunity.get('long_symbols', []))),
            opportunity.get('expected_return', 0) * 10000,  # Convert to dollar amount
            opportunity.get('confidence', 0.5)
        ))
        
        self.performance_db.commit()
        
    def generate_performance_report(self):
        """Generate comprehensive performance report"""
        cursor = self.performance_db.cursor()
        
        # Prediction accuracy
        cursor.execute(''')
            SELECT 
                COUNT(*) as total,
                AVG(ABS(predicted_price - actual_price) / actual_price) as avg_error,
                SUM(CASE WHEN predicted_direction = actual_direction THEN 1 ELSE 0 END) as correct_direction
            FROM predictions
            WHERE actual_price IS NOT NULL
        ''')
        
        pred_stats = cursor.fetchone()
        
        # Trading performance
        cursor.execute(''')
            SELECT 
                COUNT(*) as total_trades,
                SUM(profit_loss) as total_profit,
                AVG(profit_loss) as avg_profit,
                SUM(CASE WHEN profit_loss > 0 THEN 1 ELSE 0 END) as winning_trades
            FROM trades
        ''')
        
        trade_stats = cursor.fetchone()
        
        # Arbitrage success
        cursor.execute(''')
            SELECT 
                type,
                COUNT(*) as opportunities,
                AVG(actual_profit) as avg_profit,
                SUM(CASE WHEN success THEN 1 ELSE 0 END) as successful
            FROM arbitrage_opportunities
            WHERE actual_profit IS NOT NULL
            GROUP BY type
        ''')
        
        arb_stats = cursor.fetchall()
        
        # Generate report
        report = f"""
        TRANSFORMER PREDICTION SYSTEM PERFORMANCE REPORT
        ===============================================
        
        PREDICTION ACCURACY:
        - Total Predictions: {pred_stats[0]}
        - Average Error: {pred_stats[1]*100:.2f}%
        - Direction Accuracy: {(pred_stats[2]/pred_stats[0]*100) if pred_stats[0] > 0 else 0:.1f}%
        
        TRADING PERFORMANCE:
        - Total Trades: {trade_stats[0]}
        - Total Profit: ${trade_stats[1]:,.2f}
        - Average Profit: ${trade_stats[2]:,.2f}
        - Win Rate: {(trade_stats[3]/trade_stats[0]*100) if trade_stats[0] > 0 else 0:.1f}%
        
        ARBITRAGE OPPORTUNITIES:
        """
        
        for arb_type, count, avg_profit, successful in arb_stats:
            success_rate = (successful/count*100) if count > 0 else 0
            report += f"\n        {arb_type}:"
            report += f"\n        - Opportunities: {count}"
            report += f"\n        - Success Rate: {success_rate:.1f}%"
            report += f"\n        - Avg Profit: ${avg_profit:,.2f}"
            
        return report

async def main():
    """Main execution function"""
    system = TransformerPredictionSystem()
    
    # Initial training on historical data
    system.train_models_on_history()
    
    # Run prediction cycle
    results = await system.run_prediction_cycle()
    
    # Display results
    print("\n=== TRANSFORMER PREDICTION RESULTS ===")
    print(f"Predictions made: {len(results['predictions'])}")
    print(f"Arbitrage opportunities: {len(results['opportunities'])}")
    print(f"RL Decision: {results['decision']['action']}")
    
    # Show top predictions
    print("\nTOP PREDICTIONS:")
    sorted_preds = sorted(results['predictions'].items(), 
                         key=lambda x: abs(x[1].predicted_return) if x[1] else 0, 
                         reverse=True)
    
    for symbol, pred in sorted_preds[:5]:
        if pred:
            print(f"{symbol}: {pred.predicted_direction} ")
                  f"({pred.predicted_return*100:.2f}%) "
                  f"Confidence: {pred.confidence*100:.1f}%")
            
    # Show top opportunities
    if results['opportunities']:
        print("\nTOP ARBITRAGE OPPORTUNITIES:")
        for opp in results['opportunities'][:3]:
            print(f"{opp['type']}: Expected return {opp.get('expected_return', 0)*100:.2f}%")
            
    # Generate report
    print("\n" + system.generate_performance_report())

if __name__ == "__main__":
    asyncio.run(main())