#!/usr/bin/env python3
"""
Change Data Capture (CDC) Database Integration

Production-ready CDC implementation for real-time database synchronization,
audit trails, and event sourcing with PostgreSQL and Debezium.
"""

import asyncio
import json
import psycopg2
import asyncpg
from typing import Dict, List, Optional, Any, Union, Tuple, Set, Callable
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from collections import defaultdict, deque
import logging
from enum import Enum
import hashlib
import uuid
from confluent_kafka import Consumer, Producer, KafkaError
from confluent_kafka.admin import AdminClient, NewTopic
import threading
import queue

from unified_logging import get_logger
from unified_error_handling import UnifiedErrorHandler, log_performance
from monitoring_alerting import MetricsCollector
from kafka_streaming_pipeline import KafkaStreamingPipeline, StreamType, StreamMessage


logger = get_logger(__name__)


class ChangeType(Enum):
    """Types of database changes."""
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    TRUNCATE = "TRUNCATE"
    
    
class CDCEventType(Enum):
    """Types of CDC events."""
    TRADE_EXECUTED = "trade_executed"
    POSITION_UPDATED = "position_updated"
    ORDER_PLACED = "order_placed"
    ORDER_FILLED = "order_filled"
    ORDER_CANCELLED = "order_cancelled"
    RISK_LIMIT_UPDATED = "risk_limit_updated"
    MODEL_PREDICTION = "model_prediction"
    FEATURE_COMPUTED = "feature_computed"
    ALERT_TRIGGERED = "alert_triggered"
    SYSTEM_EVENT = "system_event"


@dataclass
class CDCEvent:
    """Change Data Capture event."""
    event_id: str
    event_type: CDCEventType
    table_name: str
    change_type: ChangeType
    timestamp: datetime
    transaction_id: Optional[str] = None
    schema_name: str = "public"
    
    # Data
    before: Optional[Dict[str, Any]] = None  # State before change
    after: Optional[Dict[str, Any]] = None   # State after change
    key_columns: List[str] = field(default_factory=list)
    
    # Metadata
    source_info: Dict[str, Any] = field(default_factory=dict)
    correlation_id: Optional[str] = None
    user_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {}
            'event_id': self.event_id,
            'event_type': self.event_type.value,
            'table_name': self.table_name,
            'change_type': self.change_type.value,
            'timestamp': self.timestamp.isoformat(),
            'transaction_id': self.transaction_id,
            'schema_name': self.schema_name,
            'before': self.before,
            'after': self.after,
            'key_columns': self.key_columns,
            'source_info': self.source_info,
            'correlation_id': self.correlation_id,
            'user_id': self.user_id
        }


@dataclass
class TableConfig:
    """Configuration for CDC on a table."""
    table_name: str
    key_columns: List[str]
    tracked_columns: Optional[List[str]] = None  # None means all columns
    event_type: Optional[CDCEventType] = None
    capture_deletes: bool = True
    capture_updates: bool = True
    capture_inserts: bool = True
    
    
class DatabaseCDCIntegration:
    """
    Change Data Capture integration for real-time database synchronization.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize CDC integration.
        
        Args:
            config: Configuration with database and Kafka settings
        """
        self.config = config
        self.logger = get_logger(__name__)
        self.error_handler = UnifiedErrorHandler()
        
        # Database configuration
        self.db_config = config['database']
        self.db_pool: Optional[asyncpg.Pool] = None
        
        # Kafka configuration
        self.kafka_config = config.get('kafka', {})
        self.kafka_producer: Optional[Producer] = None
        self.kafka_consumer: Optional[Consumer] = None
        self.kafka_admin: Optional[AdminClient] = None
        
        # Table configurations
        self.table_configs: Dict[str, TableConfig] = {}
        self._load_table_configs()
        
        # Event handlers
        self.event_handlers: Dict[CDCEventType, List[Callable]] = defaultdict(list)
        
        # Change tracking
        self.pending_changes: queue.Queue = queue.Queue()
        self.processed_events = deque(maxlen=10000)
        
        # Metrics
        self.metrics_collector: Optional[MetricsCollector] = None
        self.event_counts = defaultdict(int)
        self.processing_times = deque(maxlen=1000)
        
        # State
        self._running = False
        self._threads: List[threading.Thread] = []
        
    def _load_table_configs(self):
        """Load table configurations for CDC."""
        # Trading tables
        self.table_configs['trades'] = TableConfig()
            table_name='trades',
            key_columns=['trade_id'],
            event_type=CDCEventType.TRADE_EXECUTED
        )
        
        self.table_configs['positions'] = TableConfig()
            table_name='positions',
            key_columns=['position_id'],
            event_type=CDCEventType.POSITION_UPDATED
        )
        
        self.table_configs['orders'] = TableConfig()
            table_name='orders',
            key_columns=['order_id'],
            event_type=CDCEventType.ORDER_PLACED
        )
        
        self.table_configs['order_fills'] = TableConfig()
            table_name='order_fills',
            key_columns=['fill_id'],
            event_type=CDCEventType.ORDER_FILLED
        )
        
        # Risk tables
        self.table_configs['risk_limits'] = TableConfig()
            table_name='risk_limits',
            key_columns=['limit_id'],
            event_type=CDCEventType.RISK_LIMIT_UPDATED
        )
        
        # ML tables
        self.table_configs['model_predictions'] = TableConfig()
            table_name='model_predictions',
            key_columns=['prediction_id'],
            event_type=CDCEventType.MODEL_PREDICTION,
            capture_deletes=False  # Don't track deletions of predictions
        )
        
        self.table_configs['features'] = TableConfig()
            table_name='features',
            key_columns=['feature_id', 'timestamp'],
            event_type=CDCEventType.FEATURE_COMPUTED
        )
        
        # System tables
        self.table_configs['alerts'] = TableConfig()
            table_name='alerts',
            key_columns=['alert_id'],
            event_type=CDCEventType.ALERT_TRIGGERED
        )
        
        self.table_configs['audit_log'] = TableConfig()
            table_name='audit_log',
            key_columns=['log_id'],
            event_type=CDCEventType.SYSTEM_EVENT,
            capture_updates=False  # Audit logs are immutable
        )
        
    async def initialize(self):
        """Initialize CDC integration."""
        # Create database connection pool
        self.db_pool = await asyncpg.create_pool()
            host=self.db_config['host'],
            port=self.db_config['port'],
            user=self.db_config['user'],
            password=self.db_config['password'],
            database=self.db_config['database'],
            min_size=self.db_config.get('min_connections', 5),
            max_size=self.db_config.get('max_connections', 20)
        )
        
        # Initialize Kafka
        self._init_kafka()
        
        # Create CDC infrastructure
        await self._setup_cdc_infrastructure()
        
        # Start processing threads
        self._running = True
        self._start_processing_threads()
        
        self.logger.info("CDC integration initialized")
        
    def _init_kafka(self):
        """Initialize Kafka clients."""
        # Producer configuration
        producer_config = {}
            'bootstrap.servers': self.kafka_config.get('bootstrap_servers', 'localhost:9092'),
            'client.id': 'cdc-producer',
            'acks': 'all',
            'retries': 3,
            'max.in.flight.requests.per.connection': 1,
            'compression.type': 'snappy',
            'linger.ms': 5
        }
        
        self.kafka_producer = Producer(producer_config)
        
        # Admin client for topic management
        admin_config = {}
            'bootstrap.servers': self.kafka_config.get('bootstrap_servers', 'localhost:9092')
        }
        
        self.kafka_admin = AdminClient(admin_config)
        
        # Create CDC topic if it doesn't exist
        self._create_cdc_topics()
        
    def _create_cdc_topics(self):
        """Create Kafka topics for CDC events."""
        topics = []
        
        # Main CDC topic
        topics.append(NewTopic())
            topic='cdc-events',
            num_partitions=self.kafka_config.get('num_partitions', 12),
            replication_factor=self.kafka_config.get('replication_factor', 3),
            config={}
                'retention.ms': str(7 * 24 * 60 * 60 * 1000),  # 7 days
                'compression.type': 'snappy',
                'min.insync.replicas': '2'
            }
        ))
        
        # Table-specific topics
        for table_name in self.table_configs:
            topics.append(NewTopic())
                topic=f'cdc-{table_name}',
                num_partitions=self.kafka_config.get('num_partitions', 12),
                replication_factor=self.kafka_config.get('replication_factor', 3)
            ))
        
        # Create topics
        fs = self.kafka_admin.create_topics(topics, validate_only=False)
        
        for topic, f in fs.items():
            try:
                f.result()
                self.logger.info(f"Created Kafka topic: {topic}")
            except Exception as e:
                if 'already exists' not in str(e).lower():
                    self.logger.error(f"Failed to create topic {topic}: {e}")
                    
    async def _setup_cdc_infrastructure(self):
        """Set up database infrastructure for CDC."""
        async with self.db_pool.acquire() as conn:
            # Create CDC schema if not exists
            await conn.execute(""")
                CREATE SCHEMA IF NOT EXISTS cdc
            """)
            
            # Create change tracking table
            await conn.execute(""")
                CREATE TABLE IF NOT EXISTS cdc.change_log ()
                    change_id BIGSERIAL PRIMARY KEY,
                    event_id UUID NOT NULL,
                    table_name VARCHAR(255) NOT NULL,
                    change_type VARCHAR(20) NOT NULL,
                    transaction_id XID,
                    changed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                    key_values JSONB,
                    old_values JSONB,
                    new_values JSONB,
                    user_id VARCHAR(255),
                    correlation_id UUID,
                    processed BOOLEAN DEFAULT FALSE,
                    processed_at TIMESTAMPTZ,
                    INDEX idx_change_log_table (table_name),
                    INDEX idx_change_log_processed (processed),
                    INDEX idx_change_log_timestamp (changed_at)
                )
            """)
            
            # Create triggers for each tracked table
            for table_name, config in self.table_configs.items():
                await self._create_table_triggers(conn, table_name, config)
                
            self.logger.info("CDC infrastructure set up")
            
    async def _create_table_triggers(self, conn: asyncpg.Connection, 
                                   table_name: str, config: TableConfig):
        """Create CDC triggers for a table."""
        # Create trigger function
        function_name = f"cdc_track_{table_name}"
        
        await conn.execute(f""")
            CREATE OR REPLACE FUNCTION {function_name}()
            RETURNS TRIGGER AS $$
            DECLARE
                v_event_id UUID;
                v_key_values JSONB;
                v_old_values JSONB;
                v_new_values JSONB;
                v_change_type VARCHAR(20);
            BEGIN
                v_event_id := gen_random_uuid();
                
                -- Determine change type
                IF TG_OP = 'INSERT' THEN
                    v_change_type := 'INSERT';
                    v_new_values := to_jsonb(NEW);
                    v_key_values := to_jsonb(NEW) -> '{{{','.join(config.key_columns)}}}';
                ELSIF TG_OP = 'UPDATE' THEN
                    v_change_type := 'UPDATE';
                    v_old_values := to_jsonb(OLD);
                    v_new_values := to_jsonb(NEW);
                    v_key_values := to_jsonb(NEW) -> '{{{','.join(config.key_columns)}}}';
                ELSIF TG_OP = 'DELETE' THEN
                    v_change_type := 'DELETE';
                    v_old_values := to_jsonb(OLD);
                    v_key_values := to_jsonb(OLD) -> '{{{','.join(config.key_columns)}}}';
                END IF;
                
                -- Insert into change log
                INSERT INTO cdc.change_log ()
                    event_id, table_name, change_type, transaction_id,
                    key_values, old_values, new_values, user_id
                ) VALUES (
                    v_event_id, TG_TABLE_NAME, v_change_type, txid_current(),
                    v_key_values, v_old_values, v_new_values, current_setting('app.user_id', TRUE)
                );
                
                -- Notify listeners
                PERFORM pg_notify('cdc_changes', json_build_object())
                    'event_id', v_event_id,
                    'table', TG_TABLE_NAME,
                    'operation', TG_OP
                )::text);
                
                RETURN NEW;
            END;
            $$ LANGUAGE plpgsql;
        """)
        
        # Create triggers
        if config.capture_inserts:
            await conn.execute(f""")
                DROP TRIGGER IF EXISTS cdc_insert_{table_name} ON {table_name};
                CREATE TRIGGER cdc_insert_{table_name}
                AFTER INSERT ON {table_name}
                FOR EACH ROW EXECUTE FUNCTION {function_name}();
            """)
            
        if config.capture_updates:
            await conn.execute(f""")
                DROP TRIGGER IF EXISTS cdc_update_{table_name} ON {table_name};
                CREATE TRIGGER cdc_update_{table_name}
                AFTER UPDATE ON {table_name}
                FOR EACH ROW EXECUTE FUNCTION {function_name}();
            """)
            
        if config.capture_deletes:
            await conn.execute(f""")
                DROP TRIGGER IF EXISTS cdc_delete_{table_name} ON {table_name};
                CREATE TRIGGER cdc_delete_{table_name}
                AFTER DELETE ON {table_name}
                FOR EACH ROW EXECUTE FUNCTION {function_name}();
            """)
            
    def _start_processing_threads(self):
        """Start background processing threads."""
        # Change capture thread
        capture_thread = threading.Thread()
            target=self._run_change_capture,
            name="cdc-capture",
            daemon=True
        )
        capture_thread.start()
        self._threads.append(capture_thread)
        
        # Event processing thread
        process_thread = threading.Thread()
            target=self._run_event_processing,
            name="cdc-process",
            daemon=True
        )
        process_thread.start()
        self._threads.append(process_thread)
        
        # Notification listener thread
        listen_thread = threading.Thread()
            target=self._run_notification_listener,
            name="cdc-listener",
            daemon=True
        )
        listen_thread.start()
        self._threads.append(listen_thread)
        
    def _run_change_capture(self):
        """Capture changes from change log table."""
        while self._running:
            try:
                # Use asyncio in thread
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(self._capture_changes())
                
            except Exception as e:
                self.logger.error(f"Error in change capture: {e}")
                time.sleep(1)
                
    async def _capture_changes(self):
        """Capture pending changes from database."""
        async with self.db_pool.acquire() as conn:
            # Get unprocessed changes
            rows = await conn.fetch(""")
                SELECT * FROM cdc.change_log
                WHERE processed = FALSE
                ORDER BY change_id
                LIMIT 100
            """)
            
            for row in rows:
                try:
                    # Create CDC event
                    event = self._create_cdc_event(row)
                    
                    # Add to processing queue
                    self.pending_changes.put(event)
                    
                    # Mark as processed
                    await conn.execute(""")
                        UPDATE cdc.change_log
                        SET processed = TRUE, processed_at = CURRENT_TIMESTAMP
                        WHERE change_id = $1
                    """, row['change_id'])
                    
                except Exception as e:
                    self.logger.error(f"Error processing change {row['change_id']}: {e}")
                    
        # Small delay to prevent tight loop
        await asyncio.sleep(0.1)
        
    def _create_cdc_event(self, row: asyncpg.Record) -> CDCEvent:
        """Create CDC event from database row."""
        table_config = self.table_configs.get(row['table_name'])
        
        return CDCEvent()
            event_id=str(row['event_id']),
            event_type=table_config.event_type if table_config else CDCEventType.SYSTEM_EVENT,
            table_name=row['table_name'],
            change_type=ChangeType(row['change_type']),
            timestamp=row['changed_at'],
            transaction_id=str(row['transaction_id']) if row['transaction_id'] else None,
            before=dict(row['old_values']) if row['old_values'] else None,
            after=dict(row['new_values']) if row['new_values'] else None,
            key_columns=table_config.key_columns if table_config else [],
            user_id=row['user_id']
        )
        
    def _run_event_processing(self):
        """Process CDC events."""
        while self._running:
            try:
                # Get event from queue (timeout to allow checking _running)
                event = self.pending_changes.get(timeout=1)
                
                # Process event
                start_time = time.time()
                self._process_event(event)
                processing_time = (time.time() - start_time) * 1000
                
                # Track metrics
                self.processing_times.append(processing_time)
                self.event_counts[event.event_type] += 1
                
                # Store in processed events
                self.processed_events.append(event)
                
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Error processing event: {e}")
                
    def _process_event(self, event: CDCEvent):
        """Process a single CDC event."""
        # Publish to Kafka
        self._publish_to_kafka(event)
        
        # Call registered handlers
        handlers = self.event_handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                self.logger.error(f"Error in event handler: {e}")
                
        # Record metrics
        if self.metrics_collector:
            self.metrics_collector.increment('cdc_events_processed', {)
                'table': event.table_name,
                'operation': event.change_type.value
            })
            
    def _publish_to_kafka(self, event: CDCEvent):
        """Publish CDC event to Kafka."""
        if not self.kafka_producer:
            return
            
        # Main CDC topic
        self.kafka_producer.produce()
            topic='cdc-events',
            key=event.event_id.encode(),
            value=json.dumps(event.to_dict()).encode(),
            callback=self._kafka_delivery_callback
        )
        
        # Table-specific topic
        self.kafka_producer.produce()
            topic=f'cdc-{event.table_name}',
            key=event.event_id.encode(),
            value=json.dumps(event.to_dict()).encode(),
            callback=self._kafka_delivery_callback
        )
        
        # Trigger any pending callbacks
        self.kafka_producer.poll(0)
        
    def _kafka_delivery_callback(self, err, msg):
        """Kafka delivery callback."""
        if err:
            self.logger.error(f'Message delivery failed: {err}')
        else:
            self.logger.debug(f'Message delivered to {msg.topic()} [{msg.partition()}]')
            
    def _run_notification_listener(self):
        """Listen for PostgreSQL notifications."""
        # Create synchronous connection for LISTEN
        conn = psycopg2.connect()
            host=self.db_config['host'],
            port=self.db_config['port'],
            user=self.db_config['user'],
            password=self.db_config['password'],
            database=self.db_config['database']
        )
        conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
        
        cursor = conn.cursor()
        cursor.execute("LISTEN cdc_changes;")
        
        while self._running:
            try:
                # Wait for notifications
                if select.select([conn], [], [], 1) == ([], [], []):
                    continue
                    
                conn.poll()
                while conn.notifies:
                    notify = conn.notifies.pop(0)
                    self.logger.debug(f"Got NOTIFY: {notify.channel} - {notify.payload}")
                    
                    # Parse notification
                    try:
                        data = json.loads(notify.payload)
                        # Could trigger immediate processing here
                    except Exception as e:
                        self.logger.error(f"Error parsing notification: {e}")
                        
            except Exception as e:
                self.logger.error(f"Error in notification listener: {e}")
                time.sleep(1)
                
        cursor.close()
        conn.close()
        
    def register_handler(self, event_type: CDCEventType, handler: Callable):
        """Register an event handler."""
        self.event_handlers[event_type].append(handler)
        
    def unregister_handler(self, event_type: CDCEventType, handler: Callable):
        """Unregister an event handler."""
        if handler in self.event_handlers[event_type]:
            self.event_handlers[event_type].remove(handler)
            
    async def get_event_history(self, table_name: Optional[str] = None,
                              start_time: Optional[datetime] = None,
                              end_time: Optional[datetime] = None,
                              limit: int = 100) -> List[CDCEvent]:
        """Get historical CDC events."""
        async with self.db_pool.acquire() as conn:
            query = """
                SELECT * FROM cdc.change_log
                WHERE 1=1
            """
            params = []
            
            if table_name:
                params.append(table_name)
                query += f" AND table_name = ${len(params)}"
                
            if start_time:
                params.append(start_time)
                query += f" AND changed_at >= ${len(params)}"
                
            if end_time:
                params.append(end_time)
                query += f" AND changed_at <= ${len(params)}"
                
            query += " ORDER BY changed_at DESC"
            
            params.append(limit)
            query += f" LIMIT ${len(params)}"
            
            rows = await conn.fetch(query, *params)
            
            return [self._create_cdc_event(row) for row in rows]
            
    async def replay_events(self, table_name: str,
                          start_time: datetime,
                          end_time: datetime,
                          handler: Callable):
        """Replay historical events."""
        events = await self.get_event_history()
            table_name=table_name,
            start_time=start_time,
            end_time=end_time,
            limit=10000
        )
        
        self.logger.info(f"Replaying {len(events)} events for {table_name}")
        
        for event in reversed(events):  # Process in chronological order
            try:
                handler(event)
            except Exception as e:
                self.logger.error(f"Error replaying event {event.event_id}: {e}")
                
    def get_metrics(self) -> Dict[str, Any]:
        """Get CDC metrics."""
        processing_times = list(self.processing_times)
        
        return {}
            'pending_changes': self.pending_changes.qsize(),
            'processed_events': len(self.processed_events),
            'event_counts': dict(self.event_counts),
            'avg_processing_time_ms': np.mean(processing_times) if processing_times else 0,
            'p95_processing_time_ms': np.percentile(processing_times, 95) if processing_times else 0
        }
        
    async def shutdown(self):
        """Shutdown CDC integration."""
        self._running = False
        
        # Wait for threads to finish
        for thread in self._threads:
            thread.join(timeout=5)
            
        # Flush Kafka producer
        if self.kafka_producer:
            self.kafka_producer.flush()
            
        # Close database pool
        if self.db_pool:
            await self.db_pool.close()
            
        self.logger.info("CDC integration shut down")


# Specialized CDC handlers
class TradingCDCHandler:
    """CDC handler for trading events."""
    
    def __init__(self, feature_store=None, risk_manager=None):
        self.feature_store = feature_store
        self.risk_manager = risk_manager
        self.logger = get_logger(__name__)
        
    async def handle_trade_executed(self, event: CDCEvent):
        """Handle trade execution events."""
        if event.change_type != ChangeType.INSERT:
            return
            
        trade_data = event.after
        
        # Update feature store
        if self.feature_store:
            await self.feature_store.write_features()
                'trade_features',
                pd.DataFrame([{)
                    'symbol': trade_data['symbol'],
                    'timestamp': event.timestamp,
                    'price': trade_data['price'],
                    'quantity': trade_data['quantity'],
                    'side': trade_data['side'],
                    'trade_id': trade_data['trade_id']
                }])
            )
            
        # Update risk metrics
        if self.risk_manager:
            await self.risk_manager.update_position_risk()
                trade_data['symbol'],
                trade_data['quantity'],
                trade_data['price']
            )
            
        self.logger.info(f"Processed trade execution: {trade_data['trade_id']}")
        
    async def handle_position_updated(self, event: CDCEvent):
        """Handle position update events."""
        position_data = event.after
        
        # Check for risk breaches
        if self.risk_manager:
            risk_check = await self.risk_manager.check_position_limits()
                position_data['symbol'],
                position_data['quantity'],
                position_data['market_value']
            )
            
            if not risk_check['passed']:
                self.logger.warning()
                    f"Position risk breach for {position_data['symbol']}: "
                    f"{risk_check['message']}"
                )


# Example usage
if __name__ == "__main__":
    import time
    import select
    import numpy as np
    import pandas as pd
    
    async def demo_cdc():
        """Demonstrate CDC functionality."""
        
        # Configuration
        config = {}
            'database': {}
                'host': 'localhost',
                'port': 5432,
                'user': 'trading_user',
                'password': 'trading_pass',
                'database': 'trading_db',
                'min_connections': 5,
                'max_connections': 20
            },
            'kafka': {}
                'bootstrap_servers': 'localhost:9092',
                'num_partitions': 12,
                'replication_factor': 1  # For local testing
            }
        }
        
        # Create CDC integration
        cdc = DatabaseCDCIntegration(config)
        
        print("CDC Database Integration Demo")
        print("=" * 50)
        
        try:
            # Note: This demo requires PostgreSQL and Kafka to be running
            print("\nNote: This demo requires:")
            print("1. PostgreSQL database running with the specified config")
            print("2. Kafka broker running on localhost:9092")
            print("\nIf not available, showing example structure...")
            
            # Show table configurations
            print("\n\nConfigured Tables for CDC:")
            for table_name, config in cdc.table_configs.items():
                print(f"\n{table_name}:")
                print(f"  Key columns: {config.key_columns}")
                print(f"  Event type: {config.event_type.value if config.event_type else 'None'}")
                print(f"  Capture: INSERT={config.capture_inserts}, ")
                      f"UPDATE={config.capture_updates}, "
                      f"DELETE={config.capture_deletes}")
            
            # Example event handler
            def trade_handler(event: CDCEvent):
                print(f"\nTrade Event Received:")
                print(f"  Event ID: {event.event_id}")
                print(f"  Type: {event.change_type.value}")
                print(f"  Table: {event.table_name}")
                print(f"  Timestamp: {event.timestamp}")
                if event.after:
                    print(f"  Data: {json.dumps(event.after, indent=2)}")
            
            # Register handler
            cdc.register_handler(CDCEventType.TRADE_EXECUTED, trade_handler)
            
            # Example CDC event
            print("\n\nExample CDC Event:")
            example_event = CDCEvent()
                event_id=str(uuid.uuid4()),
                event_type=CDCEventType.TRADE_EXECUTED,
                table_name='trades',
                change_type=ChangeType.INSERT,
                timestamp=datetime.utcnow(),
                transaction_id='12345',
                after={}
                    'trade_id': 'TRD001',
                    'symbol': 'AAPL',
                    'price': 150.25,
                    'quantity': 100,
                    'side': 'BUY',
                    'executed_at': datetime.utcnow().isoformat()
                },
                key_columns=['trade_id']
            )
            
            print(json.dumps(example_event.to_dict(), indent=2, default=str))
            
            # SQL for creating example tables
            print("\n\nExample SQL for CDC-enabled tables:")
            print(""")
-- Create trades table
CREATE TABLE trades ()
    trade_id VARCHAR(50) PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INTEGER NOT NULL,
    side VARCHAR(10) NOT NULL,
    executed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    order_id VARCHAR(50),
    strategy_id VARCHAR(50),
    commission DECIMAL(10, 4),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create positions table
CREATE TABLE positions ()
    position_id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    quantity INTEGER NOT NULL,
    avg_price DECIMAL(10, 4),
    market_value DECIMAL(15, 2),
    unrealized_pnl DECIMAL(15, 2),
    realized_pnl DECIMAL(15, 2),
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(symbol)
);

-- Create risk_limits table
CREATE TABLE risk_limits ()
    limit_id SERIAL PRIMARY KEY,
    limit_type VARCHAR(50) NOT NULL,
    limit_name VARCHAR(100) NOT NULL,
    limit_value DECIMAL(15, 2),
    current_value DECIMAL(15, 2),
    threshold_pct DECIMAL(5, 2),
    active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
            """)
            
            # Example trigger output
            print("\n\nExample Trigger Function:")
            print(""")
CREATE OR REPLACE FUNCTION cdc_track_trades()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO cdc.change_log ()
        event_id, table_name, change_type, transaction_id,
        key_values, old_values, new_values
    ) VALUES (
        gen_random_uuid(), 
        'trades', 
        TG_OP, 
        txid_current(),
        jsonb_build_object('trade_id', NEW.trade_id),
        to_jsonb(OLD),
        to_jsonb(NEW)
    );
    
    PERFORM pg_notify('cdc_changes', json_build_object())
        'table', 'trades',
        'operation', TG_OP,
        'trade_id', NEW.trade_id
    )::text);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
            """)
            
            # CDC workflow
            print("\n\nCDC Workflow:")
            print("1. Database change occurs (INSERT/UPDATE/DELETE)")
            print("2. Trigger captures change and writes to change_log")
            print("3. CDC integration polls change_log table")
            print("4. Events are created and published to Kafka")
            print("5. Registered handlers process events")
            print("6. Feature stores, risk systems, etc. are updated")
            
            # Performance considerations
            print("\n\nPerformance Optimizations:")
            print("- Batch processing of changes")
            print("- Asynchronous event handling")
            print("- Kafka for reliable event delivery")
            print("- Connection pooling for database")
            print("- Configurable polling intervals")
            print("- Event deduplication")
            
            print("\n\nCDC demo completed!")
            
        except Exception as e:
            print(f"\nError in demo: {e}")
    
    # Run demo
    asyncio.run(demo_cdc())