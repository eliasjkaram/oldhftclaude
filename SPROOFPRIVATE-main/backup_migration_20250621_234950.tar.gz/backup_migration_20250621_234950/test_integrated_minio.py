
#!/usr/bin/env python3
"""
Test script for Integrated LEAPS Arbitrage System with MinIO integration
"""

# Alpaca imports
from alpaca.trading.client import TradingClient
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType, OrderClass
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, GetOrdersRequest

import asyncio
import logging
from datetime import datetime
from integrated_leaps_arbitrage_system import IntegratedLEAPSArbitrageSystem
from minio_data_integration import MinIODataIntegration

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_minio_integration():
    """Test MinIO integration with the integrated system"""
    
    logger.info("="*80)
    logger.info("Testing Integrated LEAPS System with MinIO")
    logger.info("="*80)
    
    # Test 1: Initialize with MinIO
    logger.info("\n1. Testing MinIO initialization...")
    try:
        system = IntegratedLEAPSArbitrageSystem(data_source='minio')
        if system.minio_integration:
            logger.info("✅ MinIO integration initialized successfully")
        else:
            logger.info("❌ MinIO integration failed, using fallback")
    except Exception as e:
        logger.error(f"❌ Failed to initialize system: {str(e)}")
        return
    
    # Test 2: Test data retrieval
    logger.info("\n2. Testing data retrieval...")
    test_symbols = ['AAPL', 'MSFT', 'SPY']
    
    for symbol in test_symbols:
        try:
            # Test historical data
            historical_data = await system._get_real_historical_data(symbol, lookback_days=30)
            if historical_data is not None and not historical_data.empty:
                logger.info(f"✅ {symbol}: Retrieved {len(historical_data)} days of historical data")
                logger.info(f"   Latest close: ${historical_data['Close'].iloc[-1]:.2f}")
            else:
                logger.info(f"⚠️  {symbol}: No historical data found")
            
            # Test options data
            options_data = await system._get_real_options_data(symbol)
            if options_data:
                logger.info(f"✅ {symbol}: Retrieved {len(options_data)} LEAPS contracts")
            else:
                logger.info(f"⚠️  {symbol}: No LEAPS data found")
                
        except Exception as e:
            logger.error(f"❌ Error processing {symbol}: {str(e)}")
    
    # Test 3: Run full analysis with real data
    logger.info("\n3. Testing full analysis with real data...")
    try:
        analysis = await system.analyze_leaps_opportunity()
            symbol='AAPL',
            use_real_data=True
        )
        
        logger.info(f"✅ Analysis completed successfully")
        logger.info(f"   Data source: {analysis['data_source']}")
        logger.info(f"   Models used: {', '.join(analysis['models_used'])}")
        logger.info(f"   Consensus score: {analysis['consensus_score']:.2%}")
        
        if 'data_quality' in analysis:
            logger.info(f"   Data quality:")
            logger.info(f"     - Historical records: {analysis['data_quality']['historical_records']}")
            logger.info(f"     - Options contracts: {analysis['data_quality']['options_contracts']}")
            logger.info(f"     - Data freshness: {analysis['data_quality']['data_freshness']}")
            
    except Exception as e:
        logger.error(f"❌ Analysis failed: {str(e)}")
    
    # Test 4: Test data source switching
    logger.info("\n4. Testing data source switching...")
    try:
        # Test with simulated data
        system_sim = IntegratedLEAPSArbitrageSystem(data_source='simulated')
        analysis_sim = await system_sim.analyze_leaps_opportunity()
            symbol='TEST',
            use_real_data=False
        )
        logger.info(f"✅ Simulated data analysis completed")
        logger.info(f"   Data source: {analysis_sim['data_source']}")
        
    except Exception as e:
        logger.error(f"❌ Simulated data test failed: {str(e)}")
    
    # Test 5: Cache statistics
    if system.minio_integration:
        logger.info("\n5. Testing cache functionality...")
        cache_stats = system.minio_integration.get_cache_stats()
        logger.info(f"✅ Cache statistics:")
        logger.info(f"   Total files: {cache_stats['total_files']}")
        logger.info(f"   Cache size: {cache_stats['total_size_mb']:.2f} MB")
        logger.info(f"   Cache directory: {cache_stats['cache_directory']}")

async def test_error_handling():
    """Test error handling and fallback mechanisms"""
    
    logger.info("\n" + "="*80)
    logger.info("Testing Error Handling and Fallbacks")
    logger.info("="*80)
    
    # Test with invalid MinIO credentials
    logger.info("\n1. Testing with invalid credentials...")
    try:
        invalid_config = {}
            'endpoint': 'invalid.endpoint.com',
            'access_key': 'invalid',
            'secret_key': 'invalid',
            'bucket_name': 'invalid',
            'secure': True
        }
        system = IntegratedLEAPSArbitrageSystem()
            data_source='minio',
            minio_config=invalid_config
        )
        
        if system.data_source == 'simulated':
            logger.info("✅ System correctly fell back to simulated data")
        else:
            logger.info("❌ System did not fall back as expected")
            
    except Exception as e:
        logger.error(f"❌ Unexpected error: {str(e)}")
    
    # Test with non-existent symbol
    logger.info("\n2. Testing with non-existent symbol...")
    try:
        system = IntegratedLEAPSArbitrageSystem(data_source='minio')
        analysis = await system.analyze_leaps_opportunity()
            symbol='FAKESYMBOL123',
            use_real_data=True
        )
        
        logger.info("✅ System handled non-existent symbol gracefully")
        if 'data_quality' in analysis:
            logger.info(f"   Used fallback data: {analysis['data_quality']['historical_records']} records")
            
    except Exception as e:
        logger.error(f"❌ Error handling non-existent symbol: {str(e)}")

async def main():
    """Run all tests"""
    
    # Run integration tests
    await test_minio_integration()
    
    # Run error handling tests
    await test_error_handling()
    
    logger.info("\n" + "="*80)
    logger.info("Testing Complete")
    logger.info("="*80)

if __name__ == "__main__":
    asyncio.run(main())