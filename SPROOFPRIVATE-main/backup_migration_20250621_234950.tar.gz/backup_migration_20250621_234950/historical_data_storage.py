#!/usr/bin/env python3
"""
Production Historical Data Storage System
Handles efficient storage and retrieval of historical market data
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
import gzip
import threading
from collections import defaultdict
import redis
from prometheus_client import Counter, Histogram, Gauge

# Configure logging
logger = logging.getLogger(__name__)

# Metrics
data_written = Counter('historical_data_written_bytes', 'Total bytes written', ['data_type'])
data_read = Counter('historical_data_read_bytes', 'Total bytes read', ['data_type'])
compression_ratio = Gauge('historical_data_compression_ratio', 'Data compression ratio')
query_latency = Histogram('historical_data_query_latency_seconds', 'Query latency')

@dataclass
class StorageConfig:
    """Configuration for historical data storage"""
    base_path: str = "/tmp/trading/historical_data"
    partition_by: str = "date"
    compression: str = "snappy"
    chunk_size: int = 10000
    retention_days: int = 365
    enable_tiering: bool = True
    hot_storage_days: int = 7
    warm_storage_days: int = 30
    s3_bucket: Optional[str] = None
    redis_host: str = "localhost"
    redis_port: int = 6379

@dataclass
class DataPoint:
    """Single market data point"""
    timestamp: datetime
    symbol: str
    open: float
    high: float
    low: float
    close: float
    volume: int
    bid: Optional[float] = None
    ask: Optional[float] = None
    bid_size: Optional[int] = None
    ask_size: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

class HistoricalDataStorage:
    """Main historical data storage system"""
    
    def __init__(self, config: Optional[StorageConfig] = None):
        self.config = config or StorageConfig()
        self.storage_path = Path(self.config.base_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize storage tiers
        self.hot_storage = self.storage_path / "hot"
        self.warm_storage = self.storage_path / "warm"
        self.cold_storage = self.storage_path / "cold"
        
        for tier in [self.hot_storage, self.warm_storage, self.cold_storage]:
            tier.mkdir(exist_ok=True)
            
        # Initialize cache
        self.redis_client = redis.Redis()
            host=self.config.redis_host,
            port=self.config.redis_port,
            decode_responses=True
        )
        
        # Buffer for batch writing
        self.write_buffer = defaultdict(list)
        self.buffer_lock = threading.Lock()
        self.last_flush = time.time()
        
        # Start background tasks
        self._start_background_tasks()
        
    def _start_background_tasks(self):
        """Start background maintenance tasks"""
        # Flush buffer periodically
        flush_thread = threading.Thread(target=self._periodic_flush, daemon=True)
        flush_thread.start()
        
        # Data tiering
        if self.config.enable_tiering:
            tiering_thread = threading.Thread(target=self._data_tiering, daemon=True)
            tiering_thread.start()
            
    def _periodic_flush(self):
        """Periodically flush write buffer"""
        while True:
            time.sleep(60)  # Flush every minute
            self.flush_all_buffers()
            
    def _data_tiering(self):
        """Move data between storage tiers based on age"""
        while True:
            try:
                self._tier_data()
            except Exception as e:
                logger.error(f"Data tiering error: {e}")
            time.sleep(3600)  # Check hourly
            
    async def write_data(self, data_points: List[DataPoint], data_type: str = "market_data"):
        """Write data points to storage"""
        with self.buffer_lock:
            self.write_buffer[data_type].extend(data_points)
            
        # Check if buffer should be flushed
        if len(self.write_buffer[data_type]) >= self.config.chunk_size:
            await self._flush_buffer(data_type)
            
    async def _flush_buffer(self, data_type: str):
        """Flush write buffer to disk"""
        with self.buffer_lock:
            if not self.write_buffer[data_type]:
                return
                
            data_points = self.write_buffer[data_type]
            self.write_buffer[data_type] = []
            
        # Convert to DataFrame
        df = pd.DataFrame([)
            {}
                'timestamp': dp.timestamp,
                'symbol': dp.symbol,
                'open': dp.open,
                'high': dp.high,
                'low': dp.low,
                'close': dp.close,
                'volume': dp.volume,
                'bid': dp.bid,
                'ask': dp.ask,
                'bid_size': dp.bid_size,
                'ask_size': dp.ask_size,
                **dp.metadata
            }
            for dp in data_points
        ])
        
        # Partition by date
        for date, group in df.groupby(df['timestamp'].dt.date):
            await self._write_partition(group, data_type, date)
            
    async def _write_partition(self, df: pd.DataFrame, data_type: str, date: datetime.date):
        """Write a single partition"""
        # Determine storage tier
        age_days = (datetime.now().date() - date).days
        
        if age_days <= self.config.hot_storage_days:
            storage_tier = self.hot_storage
        elif age_days <= self.config.warm_storage_days:
            storage_tier = self.warm_storage
        else:
            storage_tier = self.cold_storage
            
        # Create partition path
        partition_path = storage_tier / data_type / f"date={date}"
        partition_path.mkdir(parents=True, exist_ok=True)
        
        # Write parquet file
        file_path = partition_path / f"{data_type}_{int(time.time() * 1000)}.parquet"
        table = pa.Table.from_pandas(df)
        
        # Write with compression
        pq.write_table()
            table,
            file_path,
            compression=self.config.compression
        )
        
        # Update metrics
        file_size = file_path.stat().st_size
        data_written.labels(data_type=data_type).inc(file_size)
        
        # Calculate compression ratio
        uncompressed_size = df.memory_usage(deep=True).sum()
        compression_ratio.set(uncompressed_size / file_size)
        
        logger.info(f"Wrote {len(df)} records to {file_path}")
        
    async def read_data()
        self,
        symbols: List[str],
        start_date: datetime,
        end_date: datetime,
        data_type: str = "market_data",
        columns: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """Read historical data for specified symbols and date range"""
        with query_latency.time():
            # Check cache first
            cache_key = self._get_cache_key(symbols, start_date, end_date, data_type)
            cached_data = self._get_from_cache(cache_key)
            if cached_data is not None:
                return cached_data
                
            # Read from storage
            dfs = []
            
            # Iterate through date range
            current_date = start_date.date()
            while current_date <= end_date.date():
                # Determine storage tier
                age_days = (datetime.now().date() - current_date).days
                
                if age_days <= self.config.hot_storage_days:
                    storage_tiers = [self.hot_storage]
                elif age_days <= self.config.warm_storage_days:
                    storage_tiers = [self.warm_storage]
                else:
                    storage_tiers = [self.cold_storage]
                    
                # Check S3 for cold data if configured
                if age_days > self.config.warm_storage_days and self.config.s3_bucket:
                    df = await self._read_from_s3(data_type, current_date, symbols)
                    if df is not None:
                        dfs.append(df)
                        current_date += timedelta(days=1)
                        continue
                        
                # Read from local storage
                for storage_tier in storage_tiers:
                    partition_path = storage_tier / data_type / f"date={current_date}"
                    if partition_path.exists():
                        df = await self._read_partition(partition_path, symbols, columns)
                        if not df.empty:
                            dfs.append(df)
                            break
                            
                current_date += timedelta(days=1)
                
            # Combine results
            if dfs:
                result = pd.concat(dfs, ignore_index=True)
                
                # Filter by exact timestamp range
                result = result[]
                    (result['timestamp'] >= start_date) &
                    (result['timestamp'] <= end_date)
                ]
                
                # Cache result
                self._put_to_cache(cache_key, result)
                
                # Update metrics
                data_read.labels(data_type=data_type).inc(result.memory_usage(deep=True).sum())
                
                return result
            else:
                return pd.DataFrame()
                
    async def _read_partition()
        self,
        partition_path: Path,
        symbols: List[str],
        columns: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """Read data from a single partition"""
        dfs = []
        
        # Read all parquet files in partition
        for file_path in partition_path.glob("*.parquet"):
            # Read with filters
            filters = [('symbol', 'in', symbols)] if symbols else None
            
            try:
                df = pq.read_table()
                    file_path,
                    columns=columns,
                    filters=filters
                ).to_pandas()
                
                dfs.append(df)
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
                
        return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()
        
    async def _read_from_s3(self, data_type: str, date: datetime.date, symbols: List[str]) -> Optional[pd.DataFrame]:
        """Read data from S3 cold storage"""
        # Placeholder for S3 integration
        # In production, would use boto3 to read from S3
        return None
        
    def _tier_data(self):
        """Move data between storage tiers based on age"""
        now = datetime.now().date()
        
        # Move from hot to warm
        hot_cutoff = now - timedelta(days=self.config.hot_storage_days)
        self._move_data(self.hot_storage, self.warm_storage, hot_cutoff, older_than=True)
        
        # Move from warm to cold
        warm_cutoff = now - timedelta(days=self.config.warm_storage_days)
        self._move_data(self.warm_storage, self.cold_storage, warm_cutoff, older_than=True)
        
        # Archive to S3 if configured
        if self.config.s3_bucket:
            cold_cutoff = now - timedelta(days=self.config.retention_days)
            self._archive_to_s3(self.cold_storage, cold_cutoff)
            
    def _move_data(self, source_tier: Path, dest_tier: Path, cutoff_date: datetime.date, older_than: bool = True):
        """Move data between storage tiers"""
        for data_type_dir in source_tier.iterdir():
            if not data_type_dir.is_dir():
                continue
                
            for partition_dir in data_type_dir.iterdir():
                if not partition_dir.name.startswith("date="):
                    continue
                    
                date_str = partition_dir.name.split("=")[1]
                partition_date = datetime.strptime(date_str, "%Y-%m-%d").date()
                
                should_move = (partition_date < cutoff_date) if older_than else (partition_date >= cutoff_date)
                
                if should_move:
                    # Create destination
                    dest_path = dest_tier / data_type_dir.name / partition_dir.name
                    dest_path.mkdir(parents=True, exist_ok=True)
                    
                    # Move files
                    for file_path in partition_dir.glob("*.parquet"):
                        dest_file = dest_path / file_path.name
                        file_path.rename(dest_file)
                        
                    # Remove empty directory
                    try:
                        partition_dir.rmdir()
                    except:
                        pass
                        
                    logger.info(f"Moved {partition_dir} to {dest_tier}")
                    
    def _archive_to_s3(self, source_tier: Path, cutoff_date: datetime.date):
        """Archive old data to S3"""
        # Placeholder for S3 archival
        # In production, would use boto3 to upload to S3 and delete local files
        pass
        
    def _get_cache_key(self, symbols: List[str], start_date: datetime, end_date: datetime, data_type: str) -> str:
        """Generate cache key for query"""
        symbols_str = "_".join(sorted(symbols))
        return f"{data_type}:{symbols_str}:{start_date.date()}:{end_date.date()}"
        
    def _get_from_cache(self, cache_key: str) -> Optional[pd.DataFrame]:
        """Get data from cache"""
        try:
            cached_json = self.redis_client.get(cache_key)
            if cached_json:
                return pd.read_json(cached_json)
        except Exception as e:
            logger.warning(f"Cache read error: {e}")
        return None
        
    def _put_to_cache(self, cache_key: str, df: pd.DataFrame):
        """Put data to cache"""
        try:
            # Cache for 1 hour
            self.redis_client.setex()
                cache_key,
                3600,
                df.to_json()
            )
        except Exception as e:
            logger.warning(f"Cache write error: {e}")
            
    def flush_all_buffers(self):
        """Flush all write buffers"""
        data_types = list(self.write_buffer.keys())
        for data_type in data_types:
            asyncio.create_task(self._flush_buffer(data_type))
            
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics"""
        stats = {}
            'hot_storage_size': self._get_directory_size(self.hot_storage),
            'warm_storage_size': self._get_directory_size(self.warm_storage),
            'cold_storage_size': self._get_directory_size(self.cold_storage),
            'buffer_sizes': {dt: len(buf) for dt, buf in self.write_buffer.items()}
        }
        return stats
        
    def _get_directory_size(self, path: Path) -> int:
        """Get total size of directory in bytes"""
        total_size = 0
        for file_path in path.rglob("*"):
            if file_path.is_file():
                total_size += file_path.stat().st_size
        return total_size

# Example usage
async def main():
    config = StorageConfig()
        base_path="/tmp/historical_data",
        retention_days=365,
        enable_tiering=True
    )
    
    storage = HistoricalDataStorage(config)
    
    # Generate sample data
    data_points = []
    base_time = datetime.now(timezone.utc)
    
    for i in range(100):
        dp = DataPoint()
            timestamp=base_time - timedelta(minutes=i),
            symbol="AAPL",
            open=150.0 + np.random.randn(),
            high=151.0 + np.random.randn(),
            low=149.0 + np.random.randn(),
            close=150.5 + np.random.randn(),
            volume=int(1000000 + np.random.randint(-100000, 100000)),
            bid=150.4,
            ask=150.6,
            bid_size=100,
            ask_size=100
        )
        data_points.append(dp)
        
    # Write data
    await storage.write_data(data_points)
    
    # Flush buffers
    storage.flush_all_buffers()
    await asyncio.sleep(1)  # Wait for flush
    
    # Read data
    result = await storage.read_data()
        symbols=["AAPL"],
        start_date=base_time - timedelta(hours=2),
        end_date=base_time
    )
    
    print(f"Read {len(result)} records")
    print(f"Storage stats: {storage.get_storage_stats()}")

if __name__ == "__main__":
    asyncio.run(main())